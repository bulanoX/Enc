create view if not exists PXMGT_RATING.COVERAGE
AS
(
    SELECT
        BK_RATING_ID,
        BK_RATING_VERSION,
        BK_RATER_NAME,
        BK_CLIENT_SUPPLIED_ID,
        BK_OPTION_ID,
        COVERAGE_NAME,
        
        EVENT_LOAD_TIMESTAMP,
        RECORD_KAFKA_NPTS,
        RECORD_KAFKA_OFFSET,
        RECORD_KAFKA_PARTITION,
        CREATED_AT,
        CREATED_BY,
        CREATED_FROM,
        PROCESS_ID,
        SOURCE_NAME
    FROM
        PXMGT_RATING_020_STG.COVERAGE
);