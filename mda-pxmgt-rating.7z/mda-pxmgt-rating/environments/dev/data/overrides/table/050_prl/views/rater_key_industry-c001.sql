create view if not exists PXMGT_RATING.RATER_KEY_INDUSTRY(
	BK_RATER_NAME,
	BK_VERSION,
	BK_RATING_ID,
	KEY_INDUSTRY_KEY,
	BK_CLIENT_SUPPLIED_ID,
	CODE_NAME,
	CODE_TYPE,
	EVENT_LOAD_TIMESTAMP,
	RECORD_KAFKA_NPTS,
	RECORD_KAFKA_OFFSET,
	RECORD_KAFKA_PARTITION,
	CREATED_AT,
	CREATED_BY,
	CREATED_FROM,
	PROCESS_ID,
	SOURCE_NAME
) as
            SELECT       BK_RATER_NAME 
                    	,BK_VERSION 
                    	,BK_RATING_ID 
                    	,KEY_INDUSTRY_KEY 
                    	,BK_CLIENT_SUPPLIED_ID 
                    	,CODE_NAME 
                    	,CODE_TYPE
                        ,EVENT_LOAD_TIMESTAMP
                        ,RECORD_KAFKA_NPTS 
                        ,RECORD_KAFKA_OFFSET 
                        ,RECORD_KAFKA_PARTITION 
                        ,CREATED_AT 
                        ,CREATED_BY
                        ,CREATED_FROM 
                        ,PROCESS_ID 
                        ,SOURCE_NAME
            FROM        PXMGT_RATING_020_STG.RATER_KEY_INDUSTRY;