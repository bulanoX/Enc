create or replace view PXMGT_RATING.RATER_RATE_CHANGE_SELECTED_DETAILS(
	BK_RATER_NAME,
	BK_VERSION,
	BK_RATING_ID,
	SK_LAYER_SEQUENCE_NUMBER,
	BK_CLIENT_SUPPLIED_ID,
	MODEL_CALCULATED,
	UW_SELECTED,
	COMMENT,
	LLOYDS_LIMIT_ATTACHEMENT_POINT_CHANGE,
	LLOYDS_BREADTH_OF_COVER_CHANGE_CHANGE,
	OTHER_FACTORS_CHANGE,
	EVENT_LOAD_TIMESTAMP,
	RECORD_KAFKA_NPTS,
	RECORD_KAFKA_OFFSET,
	RECORD_KAFKA_PARTITION,
	CREATED_AT,
	CREATED_BY,
	CREATED_FROM,
	PROCESS_ID,
	SOURCE_NAME,
	RISK_ADJUSTED_RATE_CHANGE,
	RISK_ADJUSTED_RATE_CHANGE_GROSS_FOR_REPORTING
	
) as
            SELECT       BK_RATER_NAME 
                        ,BK_VERSION 
                        ,BK_RATING_ID 
                        ,SK_LAYER_SEQUENCE_NUMBER 
                        ,BK_CLIENT_SUPPLIED_ID 
                       -- ,BK_RATE_CHANGE_TYPE 
                        ,MODEL_CALCULATED 
                        ,UW_SELECTED 
                        ,COMMENT
                        ,LLOYDS_LIMIT_ATTACHEMENT_POINT_CHANGE 
                        ,LLOYDS_BREADTH_OF_COVER_CHANGE_CHANGE 
                        ,OTHER_FACTORS_CHANGE
                        ,EVENT_LOAD_TIMESTAMP
                        ,RECORD_KAFKA_NPTS 
                        ,RECORD_KAFKA_OFFSET 
                        ,RECORD_KAFKA_PARTITION 
                        ,CREATED_AT 
                        ,CREATED_BY
                        ,CREATED_FROM 
                        ,PROCESS_ID 
                        ,SOURCE_NAME
						,RISK_ADJUSTED_RATE_CHANGE
						,RISK_ADJUSTED_RATE_CHANGE_GROSS_FOR_REPORTING
            FROM        PXMGT_RATING_020_STG.RATER_RATE_CHANGE_SELECTED_DETAILS;