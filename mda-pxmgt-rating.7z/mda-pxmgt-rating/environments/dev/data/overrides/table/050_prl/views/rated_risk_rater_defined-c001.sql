create view if not exists PXMGT_RATING.RATED_RISK_RATER_DEFINED
AS
(
    SELECT
        BK_RATING_ID,
        BK_RATING_VERSION,
        BK_RATER_NAME,
        BK_CLIENT_SUPPLIED_ID,
        KEY,
        
        VALUE,
        
        EVENT_LOAD_TIMESTAMP,
        RECORD_KAFKA_NPTS,
        RECORD_KAFKA_OFFSET,
        RECORD_KAFKA_PARTITION,
        CREATED_AT,
        CREATED_BY,
        CREATED_FROM,
        PROCESS_ID,
        SOURCE_NAME
    FROM
        PXMGT_RATING_020_STG.RATED_RISK_RATER_DEFINED
);