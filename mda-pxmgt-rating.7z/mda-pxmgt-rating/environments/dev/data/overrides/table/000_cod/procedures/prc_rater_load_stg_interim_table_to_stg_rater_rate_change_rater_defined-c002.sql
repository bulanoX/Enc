CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_RATER_DEFINED()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_RATER_DEFINED ()
Create Date:        16 May 2024
Author:             Ionela Ciornei
Description:        Fetch data from interim table to RATER_RATE_CHANGE_RATER_DEFINED  table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_RATER_DEFINED ();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
24 Sep 2025         Khamarjaha         v1.2 - Updated SK_LAYER_SEQUENCE_NUMBER logic
18 July 2025        Andreea Macelaru   v1.1 - Add BK_RATE_CHANGE_KEY to the deduplication key
16 May 2024         Ionela Ciornei     v1.0 - Initial script
***************************************************************************************************/

INSERT  INTO PXMGT_RATING_020_STG.RATER_RATE_CHANGE_RATER_DEFINED  (
BK_RATING_ID,BK_RATER_NAME,BK_CLIENT_SUPPLIED_ID,BK_VERSION,SK_LAYER_SEQUENCE_NUMBER,BK_RATE_CHANGE_KEY,RATE_CHANGE_VALUE,EVENT_LOAD_TIMESTAMP,RECORD_KAFKA_NPTS,RECORD_KAFKA_OFFSET,RECORD_KAFKA_PARTITION ,CREATED_AT,CREATED_BY,CREATED_FROM,PROCESS_ID,SOURCE_NAME)

SELECT  inc.BK_RATING_ID
       ,inc.BK_RATER_NAME
       ,inc.BK_CLIENT_SUPPLIED_ID
       ,inc.BK_VERSION
       ,inc.Layer_Index --Modified on 24 Sep 2025, as part od sf2-22693 layer index
       ,inc.BK_RATE_CHANGE_KEY
       ,inc.RATE_CHANGE_VALUE
       ,inc.EVENT_LOAD_TIMESTAMP
       ,inc.RECORD_KAFKA_NPTS
       ,inc.RECORD_KAFKA_OFFSET
       ,inc.RECORD_KAFKA_PARTITION    
       ,inc.CREATED_AT
       ,inc.CREATED_BY
       ,inc.CREATED_FROM
       ,inc.PROCESS_ID
       ,inc.SOURCE_NAME 
FROM
(SELECT intr.BK_RATING_ID                                                                AS BK_RATING_ID
       ,intr.BK_RATER_NAME                                                               AS BK_RATER_NAME
       ,intr.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
       ,intr.BK_VERSION                                                                  AS BK_VERSION
       ,COALESCE(lf1.value:layer_index::Numeric(38,0), lf1.INDEX + 1)                                              AS Layer_Index --Modified on 24 Sep 2025, as part od sf2-22693 layer index
       ,lf2.KEY::STRING                                                                  AS BK_RATE_CHANGE_KEY
       ,lf2.VALUE::STRING                                                                AS RATE_CHANGE_VALUE
       ,intr.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
       ,intr.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
       ,intr.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
       ,intr.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
       ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                 AS CREATED_AT
       ,intr.CREATED_BY                                                                  AS CREATED_BY
       ,intr.CREATED_FROM                                                                AS CREATED_FROM
       ,intr.PROCESS_ID                                                                  AS PROCESS_ID
       ,intr.SOURCE_NAME                                                                 AS SOURCE_NAME
FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM intr
       ,LATERAL FLATTEN (intr.RECORD_CONTENT:Result.Layers) lf1
       ,LATERAL FLATTEN (parse_json(lf1.VALUE:Rate_Change.Rater_Defined)) lf2
WHERE   intr.RECORD_CONTENT:Result.Layers::STRING IS NOT NULL AND lf1.VALUE:Rate_Change.Rater_Defined::STRING IS NOT NULL
) AS inc
/*INNER JOIN  (SELECT BK_RATER_NAME,BK_VERSION,BK_RATING_ID,BK_CLIENT_SUPPLIED_ID,SK_LAYER_SEQUENCE_NUMBER
                    ,ROW_NUMBER() OVER (PARTITION BY BK_RATER_NAME,BK_VERSION,BK_RATING_ID,BK_CLIENT_SUPPLIED_ID ORDER BY SK_LAYER_SEQUENCE_NUMBER) AS RNK
              FROM PXMGT_RATING_020_STG.RATER_LAYER                
             )l 
                ON  l.BK_RATER_NAME = inc.BK_RATER_NAME
                AND l.BK_VERSION = inc.BK_VERSION --commented on 24 Sep 2025, as part od sf2-22693 layer index
                AND l.BK_RATING_ID = inc.BK_RATING_ID
                AND l.BK_CLIENT_SUPPLIED_ID = inc.BK_CLIENT_SUPPLIED_ID
                AND l.RNK = inc.FAKE_SEQ*/
LEFT JOIN  PXMGT_RATING_020_STG.RATER_RATE_CHANGE_RATER_DEFINED   rrr
                ON  inc.BK_RATER_NAME = rrr.BK_RATER_NAME
                AND inc.BK_VERSION = rrr.BK_VERSION
                AND inc.BK_RATING_ID = rrr.BK_RATING_ID
                AND inc.BK_RATE_CHANGE_KEY = rrr.BK_RATE_CHANGE_KEY
                AND inc.BK_CLIENT_SUPPLIED_ID = rrr.BK_CLIENT_SUPPLIED_ID
                AND inc.Layer_Index = rrr.SK_LAYER_SEQUENCE_NUMBER --Modified on 24 Sep 2025, as part od sf2-22693 layer index
WHERE  rrr.BK_RATING_ID IS NULL 
;

               
    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';