CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_JSON_PARSING_ERRORS
(
    interim_table VARCHAR
)
    RETURNS STRING
    LANGUAGE SQL
    EXECUTE AS OWNER
    AS
    $$
    
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_JSON_PARSING_ERRORS('GRS_USPE_INTERIM')
Create Date:        04 Jan 2024
Author:             Francisco Farto
Description:        Loads interim table records that have IS_CORRECT_RECORD_CONTENT = FALSE
                    or IS_CORRECT_RATER_DEFINED = FALSE to the JSON_PARSING_ERRORS table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_JSON_PARSING_ERRORS('GRS_USPE_INTERIM');
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
08 Jan 2024         Francisco Farto     v1.0 - Initial script
***************************************************************************************************/

    DECLARE
        -- Schemas
        stg_schema VARCHAR DEFAULT 'PXMGT_RATING_020_STG.';
        
        -- Tables
        interim_table_name VARCHAR DEFAULT stg_schema || interim_table;
    BEGIN
        LET rater_type VARCHAR := regexp_substr(interim_table, 'GRS_([^_]+)', 1, 1, 'e');
    
        LET process_id NUMBER := (SELECT ID FROM PXMGT_RATING_000_COD.LATEST_RUN_ID WHERE RATER_TYPE = :rater_type);

        LET json_parsing_errors_table varchar := '
        INSERT INTO PXMGT_RATING_020_STG.JSON_PARSING_ERRORS 
        SELECT
            ' || process_id || '                AS PROCESS_ID,
            \'GRS_' || rater_type || '\'        AS RATER_TYPE,
            CASE
                WHEN IS_CORRECT_RECORD_CONTENT = FALSE THEN \'RECORD_CONTENT\'
                WHEN IS_CORRECT_RATER_DEFINED = FALSE THEN \'RaterDefined\'
            END                                 AS ERROR_TYPE,
            CASE
                WHEN IS_CORRECT_RATER_DEFINED = FALSE THEN RATER_DEFINED_ERROR_LOCATION
                ELSE NULL
            END                                 AS RATER_DEFINED_ERROR_LOCATION,
            RECORD_METADATA                     AS RECORD_METADATA,
            RECORD_CONTENT                      AS RECORD_CONTENT,
            RECORD_LDTS                         AS RECORD_LDTS
        FROM ' || interim_table_name || '
        WHERE IS_CORRECT_RECORD_CONTENT = FALSE
        
        UNION ALL

        SELECT
            ' || process_id || '                AS PROCESS_ID,
            \'GRS_' || rater_type || '\'        AS RATER_TYPE,
            CASE
                WHEN IS_CORRECT_RECORD_CONTENT = FALSE THEN \'RECORD_CONTENT\'
                WHEN IS_CORRECT_RATER_DEFINED = FALSE THEN \'RaterDefined\'
            END                                 AS ERROR_TYPE,
            CASE
                WHEN IS_CORRECT_RATER_DEFINED = FALSE THEN RATER_DEFINED_ERROR_LOCATION
                ELSE NULL
            END                                 AS RATER_DEFINED_ERROR_LOCATION,
            RECORD_METADATA                     AS RECORD_METADATA,
            RECORD_CONTENT                      AS RECORD_CONTENT,
            RECORD_LDTS                         AS RECORD_LDTS
        FROM ' || interim_table_name || '
        WHERE IS_CORRECT_RATER_DEFINED = FALSE'; 

        EXECUTE IMMEDIATE :json_parsing_errors_table;


        EXCEPTION
            WHEN EXPRESSION_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN STATEMENT_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN OTHER THEN
                ROLLBACK;
                RAISE;
    END;
    $$;
