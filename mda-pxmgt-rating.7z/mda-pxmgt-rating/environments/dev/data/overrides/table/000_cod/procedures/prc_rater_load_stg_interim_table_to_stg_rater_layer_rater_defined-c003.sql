CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER_RATER_DEFINED()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER_RATER_DEFINED()
Create Date:        15 May 2024
Author:             Razvan Bucur
Description:        Fetch data from interim table to RATER_LAYER_RATER_DEFINED table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER_RATER_DEFINED();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
24 Sep 2025         Khamarjaha          v1.4 - updated SK_LAYER_SEQUENCE_NO logic
18 July 2025        Andreea Macelaru    v1.3 - Add BK_LAYER_KEY into the deduplication key
03 Dec 2024         Vojco Kraljevski    v1.2 - Changed processing from multiple batches to single batch
27 May 2024         Andreea-Elena Radu  v1.1 - Change SEQUENCE_IN_RATER_DEFINED 
15 May 2024         Razvan Bucur        v1.0 - Initial script
***************************************************************************************************/

INSERT INTO PXMGT_RATING_020_STG.RATER_LAYER_RATER_DEFINED ( BK_RATER_NAME, BK_VERSION, BK_RATING_ID, SK_LAYER_SEQUENCE_NO, 
                                                             BK_LAYER_KEY, BK_CLIENT_SUPPLIED_ID, LAYER_VALUE, 
                                                             EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, 
                                                             RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, 
                                                             PROCESS_ID, SOURCE_NAME)

WITH CTE (BK_RATER_NAME, BK_VERSION, BK_RATING_ID, SEQUENCE_IN_RATER_DEFINED, RD_KEY, BK_CLIENT_SUPPLIED_ID, RD_VALUE,  
          EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, 
          PROCESS_ID, SOURCE_NAME )
AS
(
  SELECT       g.BK_RATER_NAME                                       AS BK_RATER_NAME
              ,g.BK_VERSION                                          AS BK_VERSION
              ,g.BK_RATING_ID                                        AS BK_RATING_ID
              ,COALESCE(lf1.value:layer_index::Numeric(38,0), lf1.INDEX + 1)                   AS SEQUENCE_IN_RATER_DEFINED --Added on 24 Sep 2025, as part od sf2-22693 layer index
              ,lf2.KEY                                               AS RD_KEY
              ,g.BK_CLIENT_SUPPLIED_ID                               AS BK_CLIENT_SUPPLIED_ID
              ,lf2.VALUE                                             AS RD_VALUE                     
             
              ,g.EVENT_LOAD_TIMESTAMP                                AS EVENT_LOAD_TIMESTAMP                 
              ,g.RECORD_KAFKA_NPTS                                   AS RECORD_KAFKA_NPTS                               
              ,g.RECORD_KAFKA_OFFSET                                 AS RECORD_KAFKA_OFFSET   
              ,g.RECORD_KAFKA_PARTITION                              AS RECORD_KAFKA_PARTITION
              ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                      AS CREATED_AT                           
              ,g.CREATED_BY                                          AS CREATED_BY         
              ,g.CREATED_FROM                                        AS CREATED_FROM
              ,g.PROCESS_ID                                          AS PROCESS_ID
              ,g.SOURCE_NAME                                         AS SOURCE_NAME     
                              
FROM PXMGT_RATING_020_STG.RATER_GRS_INTERIM g 
  ,LATERAL FLATTEN(RECORD_CONTENT:Result:Layers) lf1    
  ,LATERAL FLATTEN (parse_json(VALUE:Rater_Defined)) lf2
  )

SELECT   x.BK_RATER_NAME                        AS BK_RATER_NAME
        ,x.BK_VERSION                           AS BK_VERSION
        ,x.BK_RATING_ID                         AS BK_RATING_ID
        ,x.SEQUENCE_IN_RATER_DEFINED            AS SK_LAYER_SEQUENCE_NO --Added on 24 Sep 2025, as part od sf2-22693 layer index
        ,x.RD_KEY::STRING                        AS BK_LAYER_KEY
        ,x.BK_CLIENT_SUPPLIED_ID                AS BK_CLIENT_SUPPLIED_ID
        ,x.RD_VALUE:: STRING                     AS LAYER_VALUE        
        ,x.EVENT_LOAD_TIMESTAMP          
        ,x.RECORD_KAFKA_NPTS             
        ,x.RECORD_KAFKA_OFFSET   
        ,x.RECORD_KAFKA_PARTITION
        ,x.CREATED_AT                    
        ,x.CREATED_BY         
        ,x.CREATED_FROM
        ,x.PROCESS_ID
        ,x.SOURCE_NAME     
FROM 
   /* ( SELECT bk_client_supplied_id
            ,bk_rater_name
            ,bk_rating_id  --commented on 24 Sep 2025, as part od sf2-22693 layer index
            ,bk_version,
             ROW_NUMBER() OVER(PARTITION BY bk_client_supplied_id, bk_rater_name, bk_rating_id, bk_version ORDER BY sk_layer_sequence_number) AS IDX,
             sk_layer_sequence_number
       FROM  PXMGT_RATING_020_STG.RATER_LAYER   
    )rl

INNER JOIN*/ CTE x 
     /*ON  rl.BK_RATER_NAME = x.BK_RATER_NAME
     AND rl.BK_VERSION = x.BK_VERSION  --commented on 24 Sep 2025, as part od sf2-22693 layer index
     AND rl.BK_RATING_ID = x.BK_RATING_ID
     AND rl.BK_CLIENT_SUPPLIED_ID = x.BK_CLIENT_SUPPLIED_ID
     AND rl.IDX = x.SEQUENCE_IN_RATER_DEFINED*/

LEFT JOIN PXMGT_RATING_020_STG.RATER_LAYER_RATER_DEFINED  rlrd
     ON  x.BK_RATER_NAME = rlrd.BK_RATER_NAME
     AND x.BK_VERSION = rlrd.BK_VERSION
     AND x.BK_RATING_ID = rlrd.BK_RATING_ID
     AND x.BK_CLIENT_SUPPLIED_ID = rlrd.BK_CLIENT_SUPPLIED_ID
     AND x.RD_KEY = rlrd.BK_LAYER_KEY
     AND x.SEQUENCE_IN_RATER_DEFINED = rlrd.SK_LAYER_SEQUENCE_NO  --Modified on 24 Sep 2025, as part od sf2-22693 layer index

WHERE  rlrd.BK_RATING_ID IS NULL;

	RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';