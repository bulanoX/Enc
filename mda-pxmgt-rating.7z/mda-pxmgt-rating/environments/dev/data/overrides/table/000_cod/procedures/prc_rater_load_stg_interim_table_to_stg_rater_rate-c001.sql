CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE()
Create Date:        10 May 2024
Author:             Andreea-Elena Radu
Description:        Fetch data from interim table to RATER_RATE table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author                  Comments
------------------- ------------------- ------------------------------------------------------------
18 July 2025        Andreea Macelaru        v1.1 - Add BK_RATE_CURRENCY into the deduplication key
10 May 2024         Andreea-Elena Radu      v1.0 - Initial script
***************************************************************************************************/
    
    INSERT INTO PXMGT_RATING_020_STG.RATER_RATE
                (
                    BK_RATE_CURRENCY 
    	           ,BK_RATER_NAME
    	           ,BK_VERSION
    	           ,BK_RATING_ID
    	           ,BK_CLIENT_SUPPLIED_ID 
    	           ,RATE
    	           ,EVENT_LOAD_TIMESTAMP
    	           ,RECORD_KAFKA_NPTS
    	           ,RECORD_KAFKA_OFFSET
    	           ,RECORD_KAFKA_PARTITION
    	           ,CREATED_AT
    	           ,CREATED_BY
    	           ,CREATED_FROM
    	           ,PROCESS_ID
    	           ,SOURCE_NAME                                  
                ) 
                
    SELECT          t.BK_RATE_CURRENCY 
    	           ,t.BK_RATER_NAME
    	           ,t.BK_VERSION
    	           ,t.BK_RATING_ID
    	           ,t.BK_CLIENT_SUPPLIED_ID 
    	           ,t.RATE
    	           ,t.EVENT_LOAD_TIMESTAMP
    	           ,t.RECORD_KAFKA_NPTS
    	           ,t.RECORD_KAFKA_OFFSET
    	           ,t.RECORD_KAFKA_PARTITION
    	           ,t.CREATED_AT
    	           ,t.CREATED_BY
    	           ,t.CREATED_FROM
    	           ,t.PROCESS_ID
    	           ,t.SOURCE_NAME  
                   
    FROM        (
                    SELECT       lf.VALUE:Code::STRING                                      AS BK_RATE_CURRENCY
                                ,i.BK_RATER_NAME                                            AS BK_RATER_NAME
                                ,i.BK_VERSION                                               AS BK_VERSION
                                ,i.BK_RATING_ID                                             AS BK_RATING_ID
                                ,i.BK_CLIENT_SUPPLIED_ID                                    AS BK_CLIENT_SUPPLIED_ID
                                ,lf.VALUE:Rate::NUMBER(29,5)                                AS RATE
                                ,i.EVENT_LOAD_TIMESTAMP                                     AS EVENT_LOAD_TIMESTAMP                 
                                ,i.RECORD_KAFKA_NPTS                                        AS RECORD_KAFKA_NPTS                               
                                ,i.RECORD_KAFKA_OFFSET                                      AS RECORD_KAFKA_OFFSET   
                                ,i.RECORD_KAFKA_PARTITION                                   AS RECORD_KAFKA_PARTITION
                                ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                           AS CREATED_AT                           
                                ,i.CREATED_BY                                               AS CREATED_BY         
                                ,i.CREATED_FROM                                             AS CREATED_FROM
                                ,i.PROCESS_ID                                               AS PROCESS_ID
                                ,i.SOURCE_NAME                                              AS SOURCE_NAME  
                                
                    FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM i 
                                ,LATERAL FLATTEN(i.RECORD_CONTENT:Result:Currencies:Rates) as lf
                ) t
                
    LEFT JOIN   PXMGT_RATING_020_STG.RATER_RATE r
    
            ON  t.BK_RATER_NAME         = r.BK_RATER_NAME
            AND t.BK_VERSION            = r.BK_VERSION
            AND t.BK_RATING_ID          = r.BK_RATING_ID
            AND t.BK_RATE_CURRENCY      = r.BK_RATE_CURRENCY
            AND t.BK_CLIENT_SUPPLIED_ID = r.BK_CLIENT_SUPPLIED_ID
            
    WHERE       r.BK_RATING_ID IS NULL     
            AND t.BK_RATE_CURRENCY IS NOT NULL;
            --AND t.RATE IS NOT NULL;

        
	RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));
 
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';