CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_TRANSFORM_ING_TABLE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_TRANSFORM_ING_TABLE()
Create Date:        10 May 2024
Author:             Catalin Dumitru
Description:        Deletes data from ingestion table by searching
                    keys in interim table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_TRANSFORM_ING_TABLE();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
07 Jul 2025         Naomi Vasu          v1.1 - Remove data from interim table instead of ING table
10 May 2024         Catalin Dumitru     v1.0 - Initial script
***************************************************************************************************/

        DELETE 
        FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING ing
        WHERE   EXISTS(
                        SELECT 1
                        FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM interim
                        WHERE   IFNULL(interim.RECORD_METADATA:key,0) = IFNULL(ing.RECORD_METADATA:key,0)
        );

        RETURN (''Number of rows deleted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
        WHEN EXPRESSION_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN STATEMENT_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN OTHER THEN
            ROLLBACK;
            RAISE;
    END';