CREATE OR ALTER TASK PXMGT_RATING_000_COD.TSK_RATER_DELETE_STG_RECORDS
    COMMENT = 'The task runs a stored procedure PRC_RATER_DELETE_STG_RECORDS() which deletes records from all staging records according to the RATER_GRS_DELETE table'
AS
    CALL PXMGT_RATING_000_COD.PRC_RATER_DELETE_STG_RECORDS()
;