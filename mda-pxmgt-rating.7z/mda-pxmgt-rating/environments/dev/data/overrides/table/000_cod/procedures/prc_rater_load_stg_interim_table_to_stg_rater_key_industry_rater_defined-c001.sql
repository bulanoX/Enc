CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_KEY_INDUSTRY_RATER_DEFINED()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_KEY_INDUSTRY_RATER_DEFINED()
Create Date:        31 July 2025
Author:             Andreea Macelaru
Description:        Fetch data from interim table to RATER_KEY_INDUSTRY_RATER_DEFINED  table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_KEY_INDUSTRY_RATER_DEFINED();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
31 July 2025         Andreea Macelaru    v1.0 - Initial script
***************************************************************************************************/

INSERT  INTO PXMGT_RATING_020_STG.RATER_KEY_INDUSTRY_RATER_DEFINED  (BK_RATER_NAME, BK_VERSION, BK_RATING_ID, 
BK_KEY_INDUSTRY_KEY, BK_CLIENT_SUPPLIED_ID, KEY_INDUSTRY_VALUE, EVENT_LOAD_TIMESTAMP, 
RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_FROM, PROCESS_ID, SOURCE_NAME
)

SELECT  inc.BK_RATER_NAME
       ,inc.BK_VERSION
       ,inc.BK_RATING_ID
       ,inc.BK_KEY_INDUSTRY_KEY
       ,inc.BK_CLIENT_SUPPLIED_ID
       ,inc.KEY_INDUSTRY_VALUE
       ,inc.EVENT_LOAD_TIMESTAMP
       ,inc.RECORD_KAFKA_NPTS
       ,inc.RECORD_KAFKA_OFFSET
       ,inc.RECORD_KAFKA_PARTITION    
       ,inc.CREATED_AT
       ,inc.CREATED_FROM
       ,inc.PROCESS_ID
       ,inc.SOURCE_NAME 
FROM
(SELECT  lf2.BK_RATER_NAME                                                               AS BK_RATER_NAME
        ,lf2.BK_VERSION                                                                  AS BK_VERSION
        ,lf2.BK_RATING_ID                                                                AS BK_RATING_ID
        ,lf2.KEY_INDUSTRY_KEY                                                            AS BK_KEY_INDUSTRY_KEY
        ,lf2.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
        ,lf2.KEY_INDUSTRY_VALUE                                                          AS KEY_INDUSTRY_VALUE
        ,lf2.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
        ,lf2.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
        ,lf2.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
        ,lf2.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
        ,lf2.CREATED_AT                                                                  AS CREATED_AT
        ,lf2.CREATED_FROM                                                                AS CREATED_FROM
        ,lf2.PROCESS_ID                                                                  AS PROCESS_ID
        ,lf2.SOURCE_NAME                                                                 AS SOURCE_NAME
 FROM
    (SELECT distinct 
            intr.BK_RATER_NAME                                                               AS BK_RATER_NAME
           ,intr.BK_VERSION                                                                  AS BK_VERSION
           ,intr.BK_RATING_ID                                                                AS BK_RATING_ID
           ,lf1.KEY::STRING                                                                  AS KEY_INDUSTRY_KEY
           ,intr.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
           ,lf1.VALUE::STRING                                                                AS KEY_INDUSTRY_VALUE
           ,intr.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
           ,intr.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
           ,intr.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
           ,intr.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
           ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                 AS CREATED_AT
           ,intr.CREATED_FROM                                                                AS CREATED_FROM
           ,intr.PROCESS_ID                                                                  AS PROCESS_ID
           ,intr.SOURCE_NAME                                                                 AS SOURCE_NAME
     FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM intr
    ,LATERAL FLATTEN(input => PARSE_JSON(RECORD_CONTENT:Result:Key_Industry.Rater_Defined)) lf1
     WHERE RECORD_CONTENT:Result:Key_Industry.Rater_Defined::STRING IS NOT NULL 
    ) lf2

 ) AS inc
LEFT JOIN  PXMGT_RATING_020_STG.RATER_KEY_INDUSTRY_RATER_DEFINED   rki
                ON  inc.BK_RATER_NAME = rki.BK_RATER_NAME
                AND inc.BK_VERSION = rki.BK_VERSION
                AND inc.BK_RATING_ID = rki.BK_RATING_ID
                AND inc.BK_CLIENT_SUPPLIED_ID = rki.BK_CLIENT_SUPPLIED_ID
                AND inc.BK_KEY_INDUSTRY_KEY = rki.BK_KEY_INDUSTRY_KEY
WHERE  rki.BK_RATING_ID IS NULL 
;

               
    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';