CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_COVERAGE
(
    interim_table VARCHAR
)
    RETURNS STRING
    LANGUAGE SQL
    EXECUTE AS OWNER
    AS
    $$
    
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_COVERAGE('GRS_USPE_INTERIM')
Create Date:        04 Jan 2024
Author:             Francisco Farto
Description:        
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_LOAD_STG_INTERIM_TABLE_TO_STG_COVERAGE('GRS_USPE_INTERIM');
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
11 Jan 2024         Francisco Farto     v1.0 - Initial script
07 Feb 2024         Francisco Farto     v1.1 - Remove DISTINCT, duplicates are taken care of in PRC_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE
***************************************************************************************************/

    DECLARE
        -- Schemas
        stg_schema VARCHAR DEFAULT 'PXMGT_RATING_020_STG.';
        
        -- Tables
        interim_table_name VARCHAR DEFAULT stg_schema || interim_table;
        staging_table_name VARCHAR DEFAULT stg_schema || 'COVERAGE';
        
    BEGIN
        LET rater_type VARCHAR := regexp_substr(interim_table, 'GRS_([^_]+)', 1, 1, 'e');
        LET process_id NUMBER := (SELECT ID FROM PXMGT_RATING_000_COD.LATEST_RUN_ID WHERE RATER_TYPE = :rater_type);

        LET staging_query VARCHAR := '
        INSERT INTO ' || staging_table_name || ' 
        SELECT
            t.RECORD_CONTENT:Metadata:Id                        AS BK_RATING_ID,
            t.RECORD_CONTENT:Metadata:Version                   AS BK_RATING_VERSION,
            t.RECORD_CONTENT:Metadata:RaterName                 AS BK_RATER_NAME,
            t.RECORD_CONTENT:Metadata:ClientSuppliedId          AS BK_CLIENT_SUPPLIED_ID,
            options.value:Id                                    AS BK_OPTION_ID,
            coverages.value:Name                                AS COVERAGE_NAME,
            
            t.RECORD_METADATA:CreateTime::VARCHAR               AS EVENT_LOAD_TIMESTAMP,
            t.RECORD_LDTS::DATETIME                             AS RECORD_KAFKA_NPTS,
            t.RECORD_METADATA:offset                            AS RECORD_KAFKA_OFFSET,
            t.RECORD_METADATA:partition                         AS RECORD_KAFKA_PARTITION,
            CURRENT_TIMESTAMP()                                 AS CREATED_AT,
            \'PRD_PXMGT_RATING_SYSADMIN\'                       AS CREATED_BY,
            \'ING\'                                             AS CREATED_FROM,
            ' || process_id || '                                AS PROCESS_ID,
            \'GRS\'                                             AS SOURCE_NAME
        FROM
            ' || interim_table_name || ' t,
            LATERAL FLATTEN(
                INPUT => PARSE_JSON(t.RECORD_CONTENT:Request:Options)
            ) options,
            LATERAL FLATTEN(
                INPUT => PARSE_JSON(options.value:Coverages)
            ) coverages
        WHERE
            t.IS_CORRECT_RECORD_CONTENT = TRUE
                AND
            t.IS_CORRECT_RATER_DEFINED = TRUE';
        
        EXECUTE IMMEDIATE :staging_query;

        EXCEPTION
            WHEN EXPRESSION_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN STATEMENT_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN OTHER THEN
                ROLLBACK;
                RAISE;
    END;
    $$;