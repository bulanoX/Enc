CREATE OR ALTER TASK PXMGT_RATING_000_COD.TSK_RATING_DO_000_ROOT
    COMMENT = 'It\'s a root task of DAG for the batch process of moving GRS DO data from Ingestion to Staging layer'
    SCHEDULE = 'USING CRON 0 * * * * Europe/London'
AS
    SELECT 'It\'s a root task of DAG for the batch process of moving GRS DO data from Ingestion to Staging layer'
;