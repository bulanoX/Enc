CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_TRANSFORM_COD_LATEST_RUN_ID
(
    rater_type VARCHAR
)
    RETURNS STRING
    LANGUAGE SQL
    EXECUTE AS CALLER
    AS
    $$

/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_TRANSFORM_COD_LATEST_RUN_ID
Create Date:        04 Jan 2024
Author:             Francisco Farto
Description:        Procedure to fetch the current RUN_ID of the Root task and inserts it in a table.
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_TRANSFORM_COD_LATEST_RUN_ID();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
04 Jan 2024         Francisco Farto     v0.1 - Initial script
***************************************************************************************************/

    BEGIN
        BEGIN TRANSACTION;
            LET clean_latest_run_id_table VARCHAR := 'DELETE FROM PXMGT_RATING_000_COD.LATEST_RUN_ID WHERE RATER_TYPE = \'' || :rater_type || '\'';
            EXECUTE IMMEDIATE :clean_latest_run_id_table;


            LET describe_task VARCHAR := 'DESCRIBE TASK PXMGT_RATING_000_COD.TSK_RATING_' || :rater_type || '_000_ROOT';
            EXECUTE IMMEDIATE :describe_task;

            LET id VARCHAR := (
                SELECT $3::varchar 
                FROM TABLE(result_scan(last_query_id())));
            
            LET run_id NUMBER := (
                SELECT max(RUN_ID)
                FROM TABLE(information_schema.task_history())
                WHERE root_task_id = :id 
                    AND name = ('TSK_RATING_' || :rater_type || '_000_ROOT')
                    AND schema_name = 'PXMGT_RATING_000_COD');
            
            INSERT INTO PXMGT_RATING_000_COD.LATEST_RUN_ID(id, rater_type) VALUES(:run_id, :rater_type);
        COMMIT;
        
        RETURN ('Updated LATEST_RUN_ID table with latest run ID.');

        EXCEPTION
            WHEN EXPRESSION_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN STATEMENT_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN OTHER THEN
                ROLLBACK;
                RAISE;
    END;
    $$;
