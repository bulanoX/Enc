CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE
(
    ingestion_table_name VARCHAR 
)
    RETURNS STRING
    LANGUAGE SQL
    EXECUTE AS OWNER
    AS
    $$
    
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE('GRS_USPE')
Create Date:        04 Jan 2024
Author:             Francisco Farto
Description:        Loads interim tables with data from the ingestion tables
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE('GRS_USPE');
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
06 Feb 2024         Francisco Farto     v1.1 - Fix edge cases when the query finds SQL NULLs
                                               and fix DISTINCT approach
04 Jan 2024         Francisco Farto     v1.0 - Initial script
***************************************************************************************************/

    DECLARE

        -- Schemas
        cod_schema VARCHAR DEFAULT 'PXMGT_RATING_000_COD.';
        ing_schema VARCHAR DEFAULT 'PXMGT_RATING_010_ING.';
        stg_schema VARCHAR DEFAULT 'PXMGT_RATING_020_STG.';
        
        -- Tables
        interim_table_name VARCHAR DEFAULT stg_schema || ingestion_table_name || '_INTERIM';

    BEGIN
        BEGIN TRANSACTION;

            LET truncate_interim_table VARCHAR := 'TRUNCATE TABLE ' || interim_table_name;
            EXECUTE IMMEDIATE :truncate_interim_table;

            LET ing_table VARCHAR := ing_schema || ingestion_table_name;
            LET temp_validation_table VARCHAR := cod_schema || ingestion_table_name || '_TEMP';


            LET create_temp_validation_table VARCHAR := '
            CREATE OR REPLACE TEMPORARY TABLE ' || temp_validation_table || ' AS
            SELECT DISTINCT
                ing_table.RECORD_METADATA:key                           AS RECORD_METADATA_KEY,

                -- Validate the RECORD_CONTENT JSON
                TRY_PARSE_JSON(ing_table.RECORD_CONTENT) IS NOT NULL    AS IS_CORRECT_RECORD_CONTENT,

                -- Validate RaterDefined fields present on various parts of RECORD_CONTENT
                TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Request:RaterDefined) IS NOT NULL OR ing_table.RECORD_CONTENT:Request:RaterDefined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Request:RaterDefined)
                                                                AS IS_CORRECT_REQUEST_RATER_DEFINED,
                TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Result.RaterDefined) IS NOT NULL OR ing_table.RECORD_CONTENT:Result.RaterDefined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Result.RaterDefined)
                                                                AS IS_CORRECT_RESULT_RATER_DEFINED,
                TRY_PARSE_JSON(requestOptions.value:RaterDefined) IS NOT NULL OR requestOptions.value:RaterDefined IS NULL OR IS_NULL_VALUE(requestOptions.value:RaterDefined)
                                                                AS IS_CORRECT_REQUEST_OPTIONS_RATER_DEFINED,
                TRY_PARSE_JSON(resultOptions.value:RaterDefined) IS NOT NULL OR resultOptions.value:RaterDefined IS NULL OR IS_NULL_VALUE(resultOptions.value:RaterDefined)
                                                                AS IS_CORRECT_RESULT_OPTIONS_RATER_DEFINED,
                TRY_PARSE_JSON(requestCoverages.value:Coverage:RaterDefined) IS NOT NULL OR requestCoverages.value:Coverage:RaterDefined IS NULL OR IS_NULL_VALUE(requestCoverages.value:Coverage:RaterDefined)
                                                                AS IS_CORRECT_REQUEST_OPTIONS_COVERAGES_RATER_DEFINED,
                TRY_PARSE_JSON(resultCoverages.value:CoverageResult:RaterDefined) IS NOT NULL OR resultCoverages.value:CoverageResult:RaterDefined IS NULL OR IS_NULL_VALUE(resultCoverages.value:CoverageResult:RaterDefined)
                                                                AS IS_CORRECT_RESULT_OPTIONS_COVERAGES_RATER_DEFINED
            FROM
                ' || ing_table || ' ing_table,
                LATERAL FLATTEN(
                    INPUT => PARSE_JSON(ing_table.RECORD_CONTENT:Request:Options)
                ) requestOptions,
                LATERAL FLATTEN(
                    INPUT => PARSE_JSON(requestOptions.value:Coverages),
                    OUTER => TRUE
                ) requestCoverages,
                LATERAL FLATTEN(
                    INPUT => PARSE_JSON(ing_table.RECORD_CONTENT:Result:Options)
                ) resultOptions,
                LATERAL FLATTEN(
                    INPUT => PARSE_JSON(resultOptions.value:Coverages),
                    OUTER => TRUE
                ) resultCoverages';
            EXECUTE IMMEDIATE :create_temp_validation_table;


            LET load_interim_table VARCHAR := '
                INSERT INTO ' || interim_table_name || ' 
                SELECT
                    ing_table.RECORD_METADATA       AS RECORD_METADATA,
                    ing_table.RECORD_CONTENT        AS RECORD_CONTENT,
                    ing_table.RECORD_LDTS           AS RECORD_LDTS,

                    -- Determine if RECORD_CONTENT field is valid
                    validation_table.IS_CORRECT_RECORD_CONTENT,

                    -- Determine if RaterDefined fields present on various parts of RECORD_CONTENT are all valid
                    validation_table.IS_CORRECT_REQUEST_RATER_DEFINED
                        AND
                    validation_table.IS_CORRECT_RESULT_RATER_DEFINED
                        AND
                    validation_table.IS_CORRECT_REQUEST_OPTIONS_RATER_DEFINED
                        AND
                    validation_table.IS_CORRECT_RESULT_OPTIONS_RATER_DEFINED
                        AND
                    validation_table.IS_CORRECT_REQUEST_OPTIONS_COVERAGES_RATER_DEFINED
                        AND
                    validation_table.IS_CORRECT_RESULT_OPTIONS_COVERAGES_RATER_DEFINED
                        AS IS_CORRECT_RATER_DEFINED,

                    -- Determine the RaterDefined field locations that are problematic
                    RTRIM( CONCAT(
                        IFF(validation_table.IS_CORRECT_REQUEST_RATER_DEFINED, \'\', \'Request:RaterDefined,\'),
                        IFF(validation_table.IS_CORRECT_RESULT_RATER_DEFINED, \'\', \'Result.RaterDefined,\'),
                        IFF(validation_table.IS_CORRECT_REQUEST_OPTIONS_RATER_DEFINED, \'\', \'Request.Options.RaterDefined,\'),
                        IFF(validation_table.IS_CORRECT_RESULT_OPTIONS_RATER_DEFINED, \'\', \'Result.Options.RaterDefined,\'),
                        IFF(validation_table.IS_CORRECT_REQUEST_OPTIONS_COVERAGES_RATER_DEFINED, \'\', \'Request.Options.Coverages.RaterDefined,\'),
                        IFF(validation_table.IS_CORRECT_RESULT_OPTIONS_COVERAGES_RATER_DEFINED, \'\', \'Result.Options.Coverages.RaterDefined,\')
                    ), \',\') AS RATER_DEFINED_ERROR_LOCATION

                FROM
                    ' || ing_table || ' ing_table
                LEFT JOIN
                    ' || temp_validation_table || ' validation_table
                ON
                    ing_table.RECORD_METADATA:key = validation_table.RECORD_METADATA_KEY';

            EXECUTE IMMEDIATE :load_interim_table;
        COMMIT;
        EXCEPTION
            WHEN EXPRESSION_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN STATEMENT_ERROR THEN
                ROLLBACK;
                RAISE;
            WHEN OTHER THEN
                ROLLBACK;
                RAISE;
    END;
    $$;
