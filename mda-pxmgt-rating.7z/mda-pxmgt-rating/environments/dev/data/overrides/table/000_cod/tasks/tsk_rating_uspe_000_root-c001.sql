CREATE OR ALTER TASK PXMGT_RATING_000_COD.TSK_RATING_USPE_000_ROOT
    COMMENT = 'It\'s a root task of DAG for the batch process of moving GRS USPE data from Ingestion to Staging layer'
    SCHEDULE = 'USING CRON 0 * * * * Europe/London'
AS
    SELECT 'It\'s a root task of DAG for the batch process of moving GRS USPE data from Ingestion to Staging layer'
;