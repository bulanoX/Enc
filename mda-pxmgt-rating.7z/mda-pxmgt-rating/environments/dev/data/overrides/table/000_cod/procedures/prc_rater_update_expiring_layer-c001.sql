CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_UPDATE_EXPIRING_LAYER()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS

$$
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_UPDATE_EXPIRING_LAYER()
Create Date:        13 Aug 2025
Author:             Andreea Macelaru
Description:        This procedure moves the data of the EXPIRING_LAYER column 
					from RATER_RATE_CHANGE_BUCKETS to the RATER_RATE_CHANGE_SELECTED_DETAILS staging tables
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_UPDATE_EXPIRING_LAYER();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
13 Aug 2025			Andreea Macelaru	v1.0 - Initial script
***************************************************************************************************/

BEGIN

MERGE INTO PXMGT_RATING_020_STG.RATER_RATE_CHANGE_SELECTED_DETAILS AS target
USING (
    SELECT
        rc.BK_RATING_ID,
        rc.BK_RATER_NAME,
        rc.BK_CLIENT_SUPPLIED_ID,
        rc.BK_VERSION,
        rc.SK_LAYER_SEQUENCE_NUMBER,
        MIN(rc.EXPIRING_LAYER) AS EXPIRING_LAYER
    FROM PXMGT_RATING_020_STG.RATER_RATE_CHANGE_BUCKETS rc
    WHERE (rc.EXPIRING_LAYER IS NOT NULL)
    GROUP BY
        rc.BK_RATING_ID,
        rc.BK_RATER_NAME,
        rc.BK_CLIENT_SUPPLIED_ID,
        rc.BK_VERSION,
        rc.SK_LAYER_SEQUENCE_NUMBER
) AS source
ON (target.BK_RATING_ID = source.BK_RATING_ID AND
    target.BK_RATER_NAME = source.BK_RATER_NAME AND
    target.BK_CLIENT_SUPPLIED_ID = source.BK_CLIENT_SUPPLIED_ID AND
    target.BK_VERSION = source.BK_VERSION AND
    target.SK_LAYER_SEQUENCE_NUMBER = source.SK_LAYER_SEQUENCE_NUMBER)
WHEN MATCHED THEN
    UPDATE SET
        target.EXPIRING_LAYER = source.EXPIRING_LAYER;

	RETURN ('Procedure executed.');
    EXCEPTION
        WHEN EXPRESSION_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN STATEMENT_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN OTHER THEN
            ROLLBACK;
            RAISE;

END;
$$;