CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_CLAIM_RATER_DEFINED()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_CLAIM_RATER_DEFINED ()
Create Date:        13 May 2024
Author:             Ionela Ciornei
Description:        Fetch data from interim table to RATER_CLAIM_RATER_DEFINED  table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_CLAIM_RATER_DEFINED ();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
18 July 2025        Andreea Macelaru   v1.1 - Add SK_CLAIM_SEQUENCE_NO into the deduplication key
13 May 2024         Ionela Ciornei     v1.0 - Initial script
***************************************************************************************************/

INSERT  INTO PXMGT_RATING_020_STG.RATER_CLAIM_RATER_DEFINED  (
BK_RATING_ID, BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID, BK_VERSION, SK_CLAIM_SEQUENCE_NO,BK_CLAIM_KEY, CLAIM_VALUE, EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME)

SELECT  inc.BK_RATING_ID
       ,inc.BK_RATER_NAME
       ,inc.BK_CLIENT_SUPPLIED_ID
       ,inc.BK_VERSION
       ,inc.SK_CLAIM_SEQUENCE_NO
       ,inc.BK_CLAIM_KEY
       ,inc.BK_CLAIM_VALUE
       ,inc.EVENT_LOAD_TIMESTAMP
       ,inc.RECORD_KAFKA_NPTS
       ,inc.RECORD_KAFKA_OFFSET
       ,inc.RECORD_KAFKA_PARTITION    
       ,inc.CREATED_AT
       ,inc.CREATED_BY
       ,inc.CREATED_FROM
       ,inc.PROCESS_ID
       ,inc.SOURCE_NAME 
FROM
(SELECT  lf1.BK_RATING_ID                                                                AS BK_RATING_ID
        ,lf1.BK_RATER_NAME                                                               AS BK_RATER_NAME
        ,lf1.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
        ,lf1.BK_VERSION                                                                  AS BK_VERSION
        ,lf1.SK_CLAIM_SEQUENCE_NO                                                        AS SK_CLAIM_SEQUENCE_NO
        ,lf2.KEY::STRING                                                                 AS BK_CLAIM_KEY
        ,lf2.VALUE::STRING                                                               AS BK_CLAIM_VALUE
        ,lf1.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
        ,lf1.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
        ,lf1.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
        ,lf1.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
        ,lf1.CREATED_AT                                                                  AS CREATED_AT
        ,lf1.CREATED_BY                                                                  AS CREATED_BY
        ,lf1.CREATED_FROM                                                                AS CREATED_FROM
        ,lf1.PROCESS_ID                                                                  AS PROCESS_ID
        ,lf1.SOURCE_NAME                                                                 AS SOURCE_NAME
 FROM
    (SELECT distinct intr.BK_RATING_ID                                                       AS BK_RATING_ID
           ,intr.BK_RATER_NAME                                                               AS BK_RATER_NAME
           ,intr.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
           ,intr.BK_VERSION                                                                  AS BK_VERSION
           ,c_seq.NEXTVAL                                                                    AS SK_CLAIM_SEQUENCE_NO
           ,intr.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
           ,intr.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
           ,intr.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
           ,intr.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
           ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                 AS CREATED_AT
           ,intr.CREATED_BY                                                                  AS CREATED_BY
           ,intr.CREATED_FROM                                                                AS CREATED_FROM
           ,intr.PROCESS_ID                                                                  AS PROCESS_ID
           ,intr.SOURCE_NAME                                                                 AS SOURCE_NAME
           ,lff1.VALUE                                                                       AS VALUE
     FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM intr
    ,LATERAL FLATTEN (intr.RECORD_CONTENT:Result.Experience_Rating.Claims) lff1
    ,TABLE(GETNEXTVAL(PXMGT_RATING_020_STG.RATER_CLAIM_RATER_DEFINED_SEQUENCE_NUMBER)) c_seq
     WHERE intr.RECORD_CONTENT:Result.Experience_Rating.Claims:: STRING IS NOT NULL AND lff1.VALUE:Rater_Defined:: STRING IS NOT NULL 
    ) lf1

,LATERAL FLATTEN (parse_json(lf1.VALUE:Rater_Defined)) lf2

) AS inc
LEFT JOIN  PXMGT_RATING_020_STG.RATER_CLAIM_RATER_DEFINED   rrr
                ON  inc.BK_RATER_NAME = rrr.BK_RATER_NAME
                AND inc.BK_VERSION = rrr.BK_VERSION
                AND inc.BK_RATING_ID = rrr.BK_RATING_ID
                AND inc.BK_CLIENT_SUPPLIED_ID = rrr.BK_CLIENT_SUPPLIED_ID
                AND inc.SK_CLAIM_SEQUENCE_NO = rrr.SK_CLAIM_SEQUENCE_NO
                AND inc.BK_CLAIM_KEY = rrr.BK_CLAIM_KEY
WHERE  rrr.BK_RATING_ID IS NULL 
;

               
    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';