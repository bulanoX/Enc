CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE
Create Date:        9 May 2024
Author:             Catalin Dumitru
Description:        Loads interim tables with data from the ingestion tables
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_EXTRACT_ING_TABLE_TO_STG_INTERIM_TABLE();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
07 Jul 2025         Naomi Vasu          v1.3 - Change in ING - STG data propagation, by using a stream in order to keep ING table persistent
19 Nov 2024         Andreea Macelaru    v1.2 - Change LEFT JOIN to INNER JOIN in the process of filling the interim table to process messages within the current run
22 Jul 2024         Catalin Dumitru     v1.1 - Add one more FLATTEN for Coverages to extract Rater_Defined; Jira: SF2-1770
09 May 2024         Catalin Dumitru     v1.0 - Initial script
***************************************************************************************************/

    BEGIN TRANSACTION;
        --Empty INTERIM table
        TRUNCATE TABLE PXMGT_RATING_020_STG.RATER_GRS_INTERIM;

        --Read new data from the RATER_STR_GRS stream and insert it into unprocessed interim table RATER_GRS_INTERIM_ING
        INSERT INTO PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING 
        SELECT RECORD_METADATA, RECORD_CONTENT, RECORD_LDTS 
        FROM PXMGT_RATING_010_ING.RATER_STR_GRS
        WHERE METADATA$ACTION = ''INSERT'';
        
        --Recreate TEMP table
        CREATE OR REPLACE TEMPORARY TABLE PXMGT_RATING_000_COD.RATER_GRS_TEMP AS
        SELECT DISTINCT
                    ing_table.RECORD_METADATA:key                           AS RECORD_METADATA_KEY,
                
                    -- Validate the RECORD_CONTENT JSON
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT) IS NOT NULL    AS IS_CORRECT_RECORD_CONTENT,
                
                    
                    -- Validate RaterDefined fields present on various parts of RECORD_CONTENT
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Request:Rater_Defined) IS NOT NULL OR ing_table.RECORD_CONTENT:Request:Rater_Defined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Request:Rater_Defined)
                                                                    AS IS_CORRECT_REQUEST_RATER_DEFINED,
                    
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Result.Rater_Defined) IS NOT NULL OR ing_table.RECORD_CONTENT:Result.Rater_Defined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Result.Rater_Defined)
                                                                    AS IS_CORRECT_RESULT_RATER_DEFINED,
    
                    TRY_PARSE_JSON(resultExperienceRatingClaims.Rater_Defined) IS NOT NULL OR resultExperienceRatingClaims.Rater_Defined IS NULL OR IS_NULL_VALUE(resultExperienceRatingClaims.Rater_Defined)
                                                                    AS IS_CORRECT_Result_Experience_Rating_Claims_Rater_Defined,
                                                                    
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Result:Experience_Rating:Rater_Defined) IS NOT NULL OR ing_table.RECORD_CONTENT:Result:Experience_Rating:Rater_Defined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Result:Experience_Rating:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Experience_Rating_Rater_Defined,
    
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Result:Exposure:Aggregate:Rater_Defined) IS NOT NULL OR ing_table.RECORD_CONTENT:Result:Exposure:Aggregate:Rater_Defined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Result:Exposure:Aggregate:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Exposure_Aggregate_Rater_Defined,
    
                    TRY_PARSE_JSON(ing_table.RECORD_CONTENT:Result:Exposure:Granular:Rater_Defined) IS NOT NULL OR ing_table.RECORD_CONTENT:Result:Exposure:Granular:Rater_Defined IS NULL OR IS_NULL_VALUE(ing_table.RECORD_CONTENT:Result:Exposure:Granular:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Exposure_Granular_Rater_Defined,
    
                    TRY_PARSE_JSON(resultLayers.VALUE:Value:Rater_Defined) IS NOT NULL OR resultLayers.VALUE:Value:Rater_Defined IS NULL OR IS_NULL_VALUE(resultLayers.VALUE:Value:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Layers_Coverages_Rater_Defined,
                    
                    TRY_PARSE_JSON(resultLayers.VALUE:Rate_Change:Rater_Defined) IS NOT NULL OR resultLayers.VALUE:Rate_Change:Rater_Defined IS NULL OR IS_NULL_VALUE(resultLayers.VALUE:Rate_Change:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Layers_Rate_Change_Rater_Defined,
                    
                    TRY_PARSE_JSON(resultLayers.VALUE:Rater_Defined) IS NOT NULL OR resultLayers.VALUE:Rater_Defined IS NULL OR IS_NULL_VALUE(resultLayers.VALUE:Rater_Defined)
                                                                    AS IS_CORRECT_Result_Layers_Rater_Defined
             
        FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING ing_table
        LEFT JOIN   (
                SELECT       a.RECORD_METADATA:key AS RECORD_METADATA_KEY, 
                             b.VALUE:Rater_Defined AS Rater_Defined
                FROM         PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING a,
                             LATERAL FLATTEN(RECORD_CONTENT:Result:Experience_Rating:Claims) b
        )resultExperienceRatingClaims
                    ON ing_table.RECORD_METADATA:key = resultExperienceRatingClaims.RECORD_METADATA_KEY
        LEFT JOIN   (
                SELECT       a.RECORD_METADATA:key AS RECORD_METADATA_KEY,
                             c.VALUE AS VALUE
                FROM         PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING a,
                             LATERAL FLATTEN(RECORD_CONTENT:Result:Layers) b, 
                             LATERAL FLATTEN(b.VALUE:Coverages) c
        ) resultLayers
                    ON ing_table.RECORD_METADATA:key = resultLayers.RECORD_METADATA_KEY
        ;

        --Fill in INTERIM table with data
        INSERT INTO PXMGT_RATING_020_STG.RATER_GRS_INTERIM(
                                                            BK_RATING_ID, BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID, BK_VERSION, RECORD_METADATA, RECORD_CONTENT, RECORD_LDTS, IS_CORRECT_RECORD_CONTENT, IS_CORRECT_RATER_DEFINED
                                                            , RATER_DEFINED_ERROR_LOCATION, EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME
                                                        )
        SELECT
            ing_table.RECORD_CONTENT:Metadata:Id::STRING                    AS BK_RATING_ID,
            ing_table.RECORD_CONTENT:Metadata:Rater_Name::STRING            AS BK_RATER_NAME,                  
            ing_table.RECORD_CONTENT:Metadata:Client_Supplied_Id::STRING    AS BK_CLIENT_SUPPLIED_ID,
            ing_table.RECORD_CONTENT:Metadata:Version::NUMBER               AS BK_VERSION,         
    
            ing_table.RECORD_METADATA       AS RECORD_METADATA,
            ing_table.RECORD_CONTENT        AS RECORD_CONTENT,
            ing_table.RECORD_LDTS           AS RECORD_LDTS,

            -- Determine if RECORD_CONTENT field is valid
            validation_table.IS_CORRECT_RECORD_CONTENT,

            -- Determine if RaterDefined fields present on various parts of RECORD_CONTENT are all valid
            validation_table.IS_CORRECT_REQUEST_RATER_DEFINED
            AND validation_table.IS_CORRECT_RESULT_RATER_DEFINED
            AND validation_table.IS_CORRECT_Result_Experience_Rating_Claims_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Experience_Rating_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Exposure_Aggregate_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Exposure_Granular_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Layers_Coverages_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Layers_Rate_Change_Rater_Defined
            AND validation_table.IS_CORRECT_Result_Layers_Rater_Defined
               AS IS_CORRECT_RATER_DEFINED,

            -- Determine the RaterDefined field locations that are problematic
            RTRIM( CONCAT(
                IFF(validation_table.IS_CORRECT_REQUEST_RATER_DEFINED, '''', ''Request:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_RESULT_RATER_DEFINED, '''', ''Result:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Experience_Rating_Claims_Rater_Defined, '''', ''Result:Experience_Rating:Claims:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Experience_Rating_Rater_Defined, '''', ''Result:Experience_Rating:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Exposure_Aggregate_Rater_Defined, '''', ''Result:Exposure:Aggregate:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Exposure_Granular_Rater_Defined, '''', ''Result:Exposure:Granular:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Layers_Coverages_Rater_Defined, '''', ''Result:Layers:Coverages:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Layers_Rate_Change_Rater_Defined, '''', ''Result:Layers:Rate:Coverages:Rater_Defined,''),
                IFF(validation_table.IS_CORRECT_Result_Layers_Rater_Defined, '''', ''Result:Layers:Rater_Defined,'')
            ), '''') AS RATER_DEFINED_ERROR_LOCATION,

            ing_table.RECORD_METADATA:CreateTime::VARCHAR                       AS EVENT_LOAD_TIMESTAMP,
            ing_table.RECORD_LDTS::DATETIME                                     AS RECORD_KAFKA_NPTS,
            ing_table.RECORD_METADATA:offset                                    AS RECORD_KAFKA_OFFSET,
            ing_table.RECORD_METADATA:partition                                 AS RECORD_KAFKA_PARTITION,
            --, CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                  AS CREATED_AT,
            ''PRD_PXMGT_RATING_SYSADMIN''                                         AS CREATED_BY,
            ''ING''                                                               AS CREATED_FROM,
            latest.ID                                                           AS PROCESS_ID,
            ''RATER_GRS''                                                         AS SOURCE_NAME
            
        FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM_ING ing_table
        INNER JOIN   PXMGT_RATING_000_COD.RATER_GRS_TEMP validation_table
                ON  ing_table.RECORD_METADATA:key = validation_table.RECORD_METADATA_KEY
        INNER JOIN   PXMGT_RATING_000_COD.RATER_LATEST_RUN_ID latest
                ON  UPPER(ing_table.RECORD_CONTENT:Metadata:Rater_Name::STRING) = latest.rater_type
            ;

    COMMIT;
    EXCEPTION
        WHEN EXPRESSION_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN STATEMENT_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN OTHER THEN
            ROLLBACK;
            RAISE;
END';