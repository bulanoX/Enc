CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE()
Create Date:        16 May 2024
Author:             Catalin Dumitru
Description:        Fetch data from interim table to RATER_RATE_CHANGE_BUCKETS table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
25 Aug 2025         Andreea Macelaru       v1.4 - Add BK_RATE_CHANGE_TYPE in deduplication key
18 July 2025        Andreea Macelaru       v1.3 - Delete BK_RATE_CHANGE_TYPE from deduplication key
30 Jun 2025         Naomi Vasu             v1.2 - Rename table from RATER_RATE_CHANGE to RATER_RATE_CHANGE_BUCKETS
23 Sept 2024        Ionela Ciornei         v1.1 - Add Expiring_Layer field
16 May 2024         Catalin Dumitru        v1.0 - Initial script
***************************************************************************************************/

    LET sqltemplate varchar := ''
    INSERT INTO PXMGT_RATING_020_STG.RATER_RATE_CHANGE_BUCKETS
                (
                 BK_RATER_NAME  
                ,BK_VERSION  
                ,BK_RATING_ID 
                ,SK_LAYER_SEQUENCE_NUMBER  
                ,BK_CLIENT_SUPPLIED_ID 
                ,BK_RATE_CHANGE_TYPE 
                ,MODEL_CALCULATED
                ,UW_SELECTED_CALCULATED
                ,UW_SELECTED_OVERRIDE
                ,UW_SELECTED_IS_DIRTY  
                ,UW_SELECTED_IS_OVERRIDDEN  
                ,UW_SELECTED_OVERRIDEN_CALCULATED
                ,UW_SELECTED_SELECTED 
                ,EXPIRING_LAYER
                ,COMMENT  
                ,EVENT_LOAD_TIMESTAMP
                ,RECORD_KAFKA_NPTS
                ,RECORD_KAFKA_OFFSET
                ,RECORD_KAFKA_PARTITION
                ,CREATED_AT
                ,CREATED_BY
                ,CREATED_FROM
                ,PROCESS_ID
                ,SOURCE_NAME
                
                )   
    SELECT       t.BK_RATER_NAME  
                ,t.BK_VERSION  
                ,t.BK_RATING_ID 
                ,l.SK_LAYER_SEQUENCE_NUMBER  
                ,t.BK_CLIENT_SUPPLIED_ID 
                ,t.BK_RATE_CHANGE_TYPE 
                ,t.MODEL_CALCULATED
                ,t.UW_SELECTED_CALCULATED
                ,t.UW_SELECTED_OVERRIDE
                ,t.UW_SELECTED_IS_DIRTY  
                ,t.UW_SELECTED_IS_OVERRIDDEN  
                ,t.UW_SELECTED_OVERRIDEN_CALCULATED
                ,t.UW_SELECTED_SELECTED 
                ,t.EXPIRING_LAYER
                ,t.COMMENT  
                ,t.EVENT_LOAD_TIMESTAMP
                ,t.RECORD_KAFKA_NPTS
                ,t.RECORD_KAFKA_OFFSET
                ,t.RECORD_KAFKA_PARTITION
                ,t.CREATED_AT
                ,t.CREATED_BY
                ,t.CREATED_FROM
                ,t.PROCESS_ID
                ,t.SOURCE_NAME   
                
    FROM            (
                            SELECT       i.BK_RATER_NAME                                                                                                        AS BK_RATER_NAME
                                        ,i.BK_VERSION                                                                                                           AS BK_VERSION
                                        ,i.BK_RATING_ID                                                                                                         AS BK_RATING_ID
                                        ,i.BK_CLIENT_SUPPLIED_ID                                                                                                AS BK_CLIENT_SUPPLIED_ID
                                        ,lf.INDEX + 1                                                                                                           AS IDX_RATE_CHANGE
                                        ,''''[PLACEHOLDER]''''                                                                                                  AS BK_RATE_CHANGE_TYPE
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Model_Calculated::NUMBER(29,5)                                                      AS MODEL_CALCULATED
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Calculated::NUMBER(29,5)                                                AS UW_SELECTED_CALCULATED
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Override::NUMBER(29,5)                                                  AS UW_SELECTED_OVERRIDE 
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Is_Dirty                                                                AS UW_SELECTED_IS_DIRTY
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Is_Overridden                                                           AS UW_SELECTED_IS_OVERRIDDEN 
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Overridden_Calculated::NUMBER(29,5)                                     AS UW_SELECTED_OVERRIDEN_CALCULATED
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Uw_Selected.Selected::NUMBER(29,5)                                                  AS UW_SELECTED_SELECTED
                                        ,lf.VALUE:Rate_Change.Expiring_Layer::NUMBER(38,0)                                                                      AS EXPIRING_LAYER
                                        ,lf.VALUE:Rate_Change:[PLACEHOLDER]:Comments::STRING                                                                    AS COMMENT
                                        ,i.EVENT_LOAD_TIMESTAMP                                                                                                 AS EVENT_LOAD_TIMESTAMP                 
                                        ,i.RECORD_KAFKA_NPTS                                                                                                    AS RECORD_KAFKA_NPTS                              
                                        ,i.RECORD_KAFKA_OFFSET                                                                                                  AS RECORD_KAFKA_OFFSET   
                                        ,i.RECORD_KAFKA_PARTITION                                                                                               AS RECORD_KAFKA_PARTITION
                                        ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                                                       AS CREATED_AT                           
                                        ,i.CREATED_BY                                                                                                           AS CREATED_BY         
                                        ,i.CREATED_FROM                                                                                                         AS CREATED_FROM
                                        ,i.PROCESS_ID                                                                                                           AS PROCESS_ID
                                        ,i.SOURCE_NAME                                                                                                          AS SOURCE_NAME  
                                        
                            FROM         PXMGT_RATING_020_STG.RATER_GRS_INTERIM i 
                                        ,LATERAL FLATTEN(RECORD_CONTENT:Result:Layers) lf               
                    ) t
                    
    INNER JOIN      (
                            SELECT       BK_RATER_NAME                                                    
                                        ,BK_VERSION                                              
                                        ,BK_RATING_ID                                             
                                        ,BK_CLIENT_SUPPLIED_ID 
                                        ,SK_LAYER_SEQUENCE_NUMBER
                                        ,ROW_NUMBER() OVER (PARTITION BY     BK_RATER_NAME                                                    
                                                                            ,BK_VERSION                                              
                                                                            ,BK_RATING_ID                                             
                                                                            ,BK_CLIENT_SUPPLIED_ID 
                                                                ORDER BY     SK_LAYER_SEQUENCE_NUMBER) AS IDX_LAYER
                                                        
                            FROM        PXMGT_RATING_020_STG.RATER_LAYER      
                    ) l
                    
                ON  t.BK_RATER_NAME						= l.BK_RATER_NAME           
                AND t.BK_VERSION						= l.BK_VERSION              
                AND t.BK_RATING_ID						= l.BK_RATING_ID            
                AND t.BK_CLIENT_SUPPLIED_ID				= l.BK_CLIENT_SUPPLIED_ID  
                AND t.IDX_RATE_CHANGE                   = l.IDX_LAYER
                
    LEFT JOIN   PXMGT_RATING_020_STG.RATER_RATE_CHANGE_BUCKETS rc

            ON  t.BK_RATER_NAME             = rc.BK_RATER_NAME
            AND t.BK_VERSION                = rc.BK_VERSION
            AND t.BK_RATING_ID              = rc.BK_RATING_ID
            AND t.BK_CLIENT_SUPPLIED_ID     = rc.BK_CLIENT_SUPPLIED_ID
            AND t.BK_RATE_CHANGE_TYPE       = rc.BK_RATE_CHANGE_TYPE
            AND l.SK_LAYER_SEQUENCE_NUMBER  = rc.SK_LAYER_SEQUENCE_NUMBER
        
        
    WHERE       rc.BK_RATING_ID IS NULL;
            -- AND (  t.MODEL_CALCULATED                 IS NOT NULL 
            --     OR t.UW_SELECTED_CALCULATED           IS NOT NULL 
            --     OR t.UW_SELECTED_OVERRIDE             IS NOT NULL 
            --     OR t.UW_SELECTED_IS_DIRTY             <> FALSE
            --     OR t.UW_SELECTED_IS_OVERRIDDEN        <> FALSE
            --     OR t.UW_SELECTED_OVERRIDEN_CALCULATED IS NOT NULL
            --     OR t.UW_SELECTED_SELECTED             IS NOT NULL
            --     OR t.COMMENT                          IS NOT NULL);
    '';

    --Brokerage_Change
    let sql_Brokerage_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Brokerage_Change'');
    execute immediate :sql_Brokerage_Change;
    let count_Brokerage_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Deductible_Change
    let sql_Deductible_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Deductible_Change'');
    execute immediate :sql_Deductible_Change;
    let count_Deductible_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Exposure_Change
    let sql_Exposure_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Exposure_Change'');
    execute immediate :sql_Exposure_Change;
    let count_Exposure_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Limit_Change
    let sql_Limit_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Limit_Change'');
    execute immediate :sql_Limit_Change;
    let count_Limit_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Other_Change
    let sql_Other_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Other_Change'');
    execute immediate :sql_Other_Change;
    let count_Other_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Risk_Characteristics_Change
    let sql_Risk_Characteristics_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Risk_Characteristics_Change'');
    execute immediate :sql_Risk_Characteristics_Change;
    let count_Risk_Characteristics_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

    --Terms_Conditions_Change
    let sql_Terms_Conditions_Change varchar := REPLACE(sqltemplate, ''[PLACEHOLDER]'', ''Terms_Conditions_Change'');
    execute immediate :sql_Terms_Conditions_Change;
    let count_Terms_Conditions_Change int := (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

 
    RETURN (''Number of rows inserted: '' || (count_Brokerage_Change + count_Deductible_Change + count_Exposure_Change + count_Limit_Change + count_Other_Change + count_Risk_Characteristics_Change + count_Terms_Conditions_Change));
 
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;

END';