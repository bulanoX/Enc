CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE_RATER_DEFINED()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE_RATER_DEFINED()
Create Date:        15 May 2024
Author:             Catalin Dumitru
Description:        Fetch data from interim table to RATER_COVERAGE_RATER_DEFINED table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE_RATER_DEFINED();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
25 Aug 2025         Andreea Macelaru       v1.3 - Add COVERAGE_ARRAY_NAME in deduplication key
31 Jul 2024         Catalin Dumitru        v1.2 - Add COVERAGE_ARRAY_NAME
22 Jul 2024         Catalin Dumitru        v1.1 - Change path for Rater_Defined; Jira ID SF2-1770
15 May 2024         Catalin Dumitru        v1.0 - Initial script
***************************************************************************************************/
    INSERT INTO PXMGT_RATING_020_STG.RATER_COVERAGE_RATER_DEFINED(
                        BK_RATER_NAME, BK_VERSION, BK_RATING_ID, SK_LAYER_SEQUENCE_NUMBER, BK_CLIENT_SUPPLIED_ID, COVERAGE_ARRAY_NAME, BK_COVERAGE_KEY, COVERAGE_VALUE, EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET,
                        RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME
    )
    SELECT      i.bk_rater_name
                ,i.bk_version
                ,i.bk_rating_id
                ,l.SK_Layer_sequence_number
                ,i.bk_client_supplied_id
                ,rd.COVERAGE_ARRAY_NAME
                ,rd.RD_KEY
                ,rd.RD_VALUE
                ,i.EVENT_LOAD_TIMESTAMP
                ,i.RECORD_KAFKA_NPTS
                ,i.RECORD_KAFKA_OFFSET
                ,i.RECORD_KAFKA_PARTITION
                ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ CREATED_AT
                ,i.CREATED_BY
                ,i.CREATED_FROM
                ,i.PROCESS_ID
                ,i.SOURCE_NAME
    FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM i
    INNER JOIN  (
                    SELECT  bk_client_supplied_id
                            , bk_rater_name
                            , bk_version
                            , bk_rating_id
                            , SK_Layer_sequence_number
                            , ROW_NUMBER() OVER(PARTITION BY bk_client_supplied_id, bk_rater_name, bk_rating_id, bk_version ORDER BY SK_Layer_sequence_number) AS IDX
                    FROM PXMGT_RATING_020_STG.RATER_LAYER 
    ) l      ON i.RECORD_CONTENT:Metadata:Id = l.bk_rating_id
            AND i.RECORD_CONTENT:Metadata:Version = l.bk_version
            AND i.RECORD_CONTENT:Metadata:Rater_Name = l.bk_rater_name
            AND i.RECORD_CONTENT:Metadata:Client_Supplied_Id = l.bk_client_supplied_id
            
    INNER JOIN (
            SELECT      i2.RECORD_CONTENT:Metadata:Id AS bk_rating_id
                        , i2.RECORD_CONTENT:Metadata:Version AS bk_version
                        , i2.RECORD_CONTENT:Metadata:Rater_Name AS bk_rater_name
                        , i2.RECORD_CONTENT:Metadata:Client_Supplied_Id AS bk_client_supplied_id
                        , f.SEQ
                        , f.INDEX + 1 AS SEQUENCE_IN_RATER_DEFINED
                        --, lf2.SEQ AS SEQUENCE_IN_RATER_DEFINED
                        , COV.VALUE:Name::STRING AS COVERAGE_ARRAY_NAME
                        , lf2.KEY AS RD_KEY
                        , lf2.VALUE AS RD_VALUE
            FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM i2,
            LATERAL     FLATTEN (i2.record_content:Result:Layers, outer => true) f
            , LATERAL     FLATTEN (f.VALUE:Coverages) COV
            , LATERAL     FLATTEN (parse_json(COV.VALUE:Value:Rater_Defined)) lf2
    ) rd    ON  rd.bk_rating_id = l.bk_rating_id
            AND rd.bk_version = l.bk_version
            AND rd.bk_rater_name = l.bk_rater_name
            AND rd.bk_client_supplied_id = l.bk_client_supplied_id
            AND rd.SEQUENCE_IN_RATER_DEFINED = l.IDX
    LEFT JOIN PXMGT_RATING_020_STG.RATER_COVERAGE_RATER_DEFINED x 
            ON  x.bk_rating_id = i.bk_rating_id
            AND x.bk_version = i.bk_version
            AND x.bk_rater_name = i.bk_rater_name
            AND x.bk_client_supplied_id = i.bk_client_supplied_id
            AND x.SK_Layer_sequence_number = l.SK_Layer_sequence_number
            and x.bk_coverage_key = rd.RD_KEY
            and x.COVERAGE_ARRAY_NAME = rd.COVERAGE_ARRAY_NAME

    WHERE   x.BK_CLIENT_SUPPLIED_ID IS NULL;

    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));
 
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';