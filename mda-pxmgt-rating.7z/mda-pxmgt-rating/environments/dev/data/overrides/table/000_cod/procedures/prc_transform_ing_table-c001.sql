CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_TRANSFORM_ING_TABLE
(
    ingestion_table_name VARCHAR
)
    RETURNS VARCHAR
    LANGUAGE SQL
    EXECUTE AS OWNER
    AS
    $$

/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_TRANSFORM_ING_TABLE('GRS_USPE')
Create Date:        03 Jan 2024
Author:             Francisco Farto
Description:        Deletes data from ingestion table by searching
                    keys in interim table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_TRANSFORM_ING_TABLE('GRS_USPE');
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
03 Jan 2024         Francisco Farto     v1.0 - Initial script
***************************************************************************************************/
    BEGIN
        LET delete_query VARCHAR := 'DELETE FROM PXMGT_RATING_010_ING.' || :ingestion_table_name || ' ing
                                        WHERE EXISTS(
                                                SELECT 1
                                                FROM PXMGT_RATING_020_STG.' || :ingestion_table_name || '_INTERIM interim
                                                WHERE
                                                    IFNULL(interim.RECORD_METADATA:key,0) = IFNULL(ing.RECORD_METADATA:key,0))';

        EXECUTE IMMEDIATE :delete_query;

        RETURN ('Number of rows deleted: ' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
        WHEN EXPRESSION_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN STATEMENT_ERROR THEN
            ROLLBACK;
            RAISE;
        WHEN OTHER THEN
            ROLLBACK;
            RAISE;
    END;
    $$;
