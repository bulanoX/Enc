CREATE OR ALTER TASK PXMGT_RATING_000_COD.TSK_REMOVE_CLEANUP_TABLES
    COMMENT = 'The task runs a stored procedure PXMGT_RATING_000_COD.PRC_REMOVE_CLEANUP_TABLES() which removes clean tables used to eliminate duplicates from STG tables '
AS
    CALL PXMGT_RATING_000_COD.PRC_REMOVE_CLEANUP_TABLES()
;