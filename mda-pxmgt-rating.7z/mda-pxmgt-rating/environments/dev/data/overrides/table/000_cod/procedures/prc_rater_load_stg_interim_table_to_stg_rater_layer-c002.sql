CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER()
Create Date:        13 May 2024
Author:             Razvan Bucur
Description:        Fetch data from interim table to RATER_LAYER table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_LAYER();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
24 Sep 2025         Khamarjaha          v1.4 - added layer_sequence_number logic in proc
28 Aug 2025         Andreea Macelaru    v1.3 - Add new columns 
30 Jul 2024         Catalin Dumitru     v1.2 - Fix Unity_Premium and Written_Line
19 Jul 2024         Catalin Dumitru     v1.1 - Remove Coverage_Name; Jira ID: SF2-1770
13 May 2024         Razvan Bucur        v1.0 - Initial script
***************************************************************************************************/
INSERT INTO PXMGT_RATING_020_STG.RATER_LAYER ( BK_RATER_NAME, BK_VERSION, BK_RATING_ID, SK_LAYER_SEQUENCE_NUMBER,BK_CLIENT_SUPPLIED_ID, is_primary_excess,
                                               trifocus, expected_loss_cost, expected_loss_cost_pre_uw_adj, limit, excess, deductible, 
                                               aggregate_limit, aggregate_excess, aggregate_deductible, currency, section_reference, brokerage,
                                               written_line, premium, status, benchmark_premium, bpi, bpi_pre_uw_adj, model_premium,
                                               unity_premium, quoted_premium, technical_premium, technical_premium_net, 
                                               technical_premium_pre_uw_adj, tpi, tpi_pre_uw_adj, pflr, pflr_att, pflr_cat, roc, uw_adj_impact,
                                               EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_AT,
                                               CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME, EXPECTED_LOSS_COST_100, QUOTED_PREMIUM_NET,
                                               QUOTED_PREMIUM_NET_100, QUOTED_PREMIUM_100, QUOTED_PREMIUM_ANNUAL, QUOTED_PREMIUM_ANNUAL_100,
                                               BENCHMARK_PREMIUM_NET, BENCHMARK_PREMIUM_NET_100, BENCHMARK_PREMIUM_100, BENCHMARK_PREMIUM_ANNUAL,
                                               BENCHMARK_PREMIUM_ANNUAL_100, BENCHMARK_PREMIUM_PRE_UW_ADJ, TECHNICAL_PREMIUM_100,
                                               TECHNICAL_PREMIUM_NET_100, PFLR_PRE_UW_ADJ )
SELECT   x.BK_RATER_NAME
        ,x.BK_VERSION
        ,x.BK_RATING_ID
		,x.SK_LAYER_SEQUENCE_NUMBER -- Added on 24 Sep 2025, as part od sf2-22693 layer index
        ,x.BK_CLIENT_SUPPLIED_ID  
        ,x.is_primary_excess
        ,x.trifocus
        ,x.expected_loss_cost
        ,x.expected_loss_cost_pre_uw_adj
        ,x.limit
        ,x.excess
        ,x.deductible
        ,x.aggregate_limit
        ,x.aggregate_excess
        ,x.aggregate_deductible
        ,x.currency
        ,x.section_reference
        ,x.brokerage
        ,x.Written_Line
        ,x.premium
        ,x.status
        ,x.benchmark_premium
        ,x.bpi
        ,x.bpi_pre_uw_adj
        ,x.model_premium
        ,x.unity_premium
        ,x.quoted_premium
        ,x.technical_premium
        ,x.technical_premium_net
        ,x.technical_premium_pre_uw_adj
        ,x.tpi
        ,x.tpi_pre_uw_adj
        ,x.pflr
        ,x.pflr_att
        ,x.pflr_cat
        ,x.roc
        ,x.uw_adj_impact
        ,x.EVENT_LOAD_TIMESTAMP
        ,x.RECORD_KAFKA_NPTS
        ,x.RECORD_KAFKA_OFFSET
        ,x.RECORD_KAFKA_PARTITION
        ,x.CREATED_AT
        ,x.CREATED_BY
        ,x.CREATED_FROM
        ,x.PROCESS_ID
        ,x.SOURCE_NAME
        ,x.EXPECTED_LOSS_COST_100
		,x.QUOTED_PREMIUM_NET
		,x.QUOTED_PREMIUM_NET_100
		,x.QUOTED_PREMIUM_100
		,x.QUOTED_PREMIUM_ANNUAL
		,x.QUOTED_PREMIUM_ANNUAL_100
		,x.BENCHMARK_PREMIUM_NET
		,x.BENCHMARK_PREMIUM_NET_100
		,x.BENCHMARK_PREMIUM_100
		,x.BENCHMARK_PREMIUM_ANNUAL
		,x.BENCHMARK_PREMIUM_ANNUAL_100
		,x.BENCHMARK_PREMIUM_PRE_UW_ADJ
		,x.TECHNICAL_PREMIUM_100
		,x.TECHNICAL_PREMIUM_NET_100
		,x.PFLR_PRE_UW_ADJ
FROM 
(
SELECT      g.BK_RATER_NAME
           ,g.BK_VERSION
           ,g.BK_RATING_ID
		   ,COALESCE(l.value:layer_index::Numeric(38,0), l.INDEX + 1)                     AS SK_LAYER_SEQUENCE_NUMBER -- Added on 24 Sep 2025, as part od sf2-22693 layer index
           ,g.BK_CLIENT_SUPPLIED_ID   
           ,l.VALUE:Is_Primary_Excess::STRING                     AS is_primary_excess  
           ,l.VALUE:Trifocus::STRING                              AS trifocus              
           ,l.VALUE:Expected_Loss_Cost::NUMERIC(29,5)             AS expected_loss_cost             
           ,l.VALUE:Expected_Loss_Cost_Pre_Uw_Adj::NUMERIC(29,5)  AS expected_loss_cost_pre_uw_adj    
           ,l.VALUE:Limit::NUMERIC(29,5)                          AS limit                         
           ,l.VALUE:Excess::NUMERIC(29,5)                         AS excess                         
           ,l.VALUE:Deductible::NUMERIC(29,5)                     AS deductible                     
           ,l.VALUE:Aggregate_Limit::NUMERIC(29,5)                AS aggregate_limit                
           ,l.VALUE:Aggregate_Excess::NUMERIC(29,5)               AS aggregate_excess              
           ,l.VALUE:Aggregate_Deductible::NUMERIC(29,5)           AS aggregate_deductible           
           ,l.VALUE:Currency::STRING                              AS currency      
           ,l.VALUE:Section_Reference::STRING                     AS section_reference              
           ,l.VALUE:Brokerage::NUMERIC(29,5)                      AS brokerage                      
           ,l.VALUE:Written_Line::NUMERIC(29,5)                   AS written_line                   
           ,l.VALUE:Premium::NUMERIC(29,5)                        AS premium                        
           ,l.VALUE:Status::STRING                                AS status    
           ,l.VALUE:Benchmark_Premium::NUMERIC(29,5)              AS benchmark_premium              
           ,l.VALUE:Bpi::NUMERIC(29,5)                            AS bpi                            
           ,l.VALUE:Bpi_Pre_Uw_Adj::NUMERIC(29,5)                 AS bpi_pre_uw_adj                 
           ,l.VALUE:Model_Premium::NUMERIC(29,5)                  AS model_premium                  
           ,l.VALUE:Unity_Premium::NUMERIC(29,5)                  AS unity_premium                  
           ,l.VALUE:Quoted_Premium::NUMERIC(29,5)                 AS quoted_premium                 
           ,l.VALUE:Technical_Premium::NUMERIC(29,5)              AS technical_premium              
           ,l.VALUE:Technical_Premium_Net::NUMERIC(29,5)          AS technical_premium_net        
           ,l.VALUE:Technical_Premium_Pre_Uw_Adj::NUMERIC(29,5)   AS technical_premium_pre_uw_adj    
           ,l.VALUE:Tpi::NUMERIC(29,5)                            AS tpi   
           ,l.VALUE:Tpi_Pre_Uw_Adj::NUMERIC(29,5)                 AS tpi_pre_uw_adj                 
           ,l.VALUE:Pflr::NUMERIC(29,5)                           AS pflr    
           ,l.VALUE:Pflr_Att::NUMERIC(29,5)                       AS pflr_att                       
           ,l.VALUE:Pflr_Cat::NUMERIC(29,5)                       AS pflr_cat                       
           ,l.VALUE:Roc::NUMERIC(29,5)                            AS roc                            
           ,l.VALUE:Uw_Adj_Impact::NUMERIC(29,5)                  AS uw_adj_impact                  
           ,g.EVENT_LOAD_TIMESTAMP                                AS EVENT_LOAD_TIMESTAMP                 
           ,g.RECORD_KAFKA_NPTS                                   AS RECORD_KAFKA_NPTS                               
           ,g.RECORD_KAFKA_OFFSET                                 AS RECORD_KAFKA_OFFSET   
           ,g.RECORD_KAFKA_PARTITION                              AS RECORD_KAFKA_PARTITION
           ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                      AS CREATED_AT                           
           ,g.CREATED_BY                                          AS CREATED_BY         
           ,g.CREATED_FROM                                        AS CREATED_FROM
           ,g.PROCESS_ID                                          AS PROCESS_ID
           ,g.SOURCE_NAME                                         AS SOURCE_NAME   
           ,l.VALUE:Expected_Loss_Cost_100::NUMERIC(29,5)         AS EXPECTED_LOSS_COST_100
		   ,l.VALUE:Quoted_Premium_Net::NUMERIC(29,5)             AS QUOTED_PREMIUM_NET
		   ,l.VALUE:Quoted_Premium_Net_100::NUMERIC(29,5)         AS QUOTED_PREMIUM_NET_100
		   ,l.VALUE:Quoted_Premium_100::NUMERIC(29,5)             AS QUOTED_PREMIUM_100
		   ,l.VALUE:Quoted_Premium_Annual::NUMERIC(29,5)          AS QUOTED_PREMIUM_ANNUAL
		   ,l.VALUE:Quoted_Premium_Annual_100::NUMERIC(29,5)      AS QUOTED_PREMIUM_ANNUAL_100
		   ,l.VALUE:Benchmark_Premium_Net::NUMERIC(29,5)          AS BENCHMARK_PREMIUM_NET
		   ,l.VALUE:Benchmark_Premium_Net_100::NUMERIC(29,5)      AS BENCHMARK_PREMIUM_NET_100
		   ,l.VALUE:Benchmark_Premium_100::NUMERIC(29,5)          AS BENCHMARK_PREMIUM_100
		   ,l.VALUE:Benchmark_Premium_Annual::NUMERIC(29,5)       AS BENCHMARK_PREMIUM_ANNUAL
		   ,l.VALUE:Benchmark_Premium_Annual_100::NUMERIC(29,5)   AS BENCHMARK_PREMIUM_ANNUAL_100
		   ,l.VALUE:Benchmark_Premium_Pre_Uw_Adj::NUMERIC(29,5)   AS BENCHMARK_PREMIUM_PRE_UW_ADJ
		   ,l.VALUE:Technical_Premium_100::NUMERIC(29,5)          AS TECHNICAL_PREMIUM_100
		   ,l.VALUE:Technical_Premium_Net_100::NUMERIC(29,5)      AS TECHNICAL_PREMIUM_NET_100
		   ,l.VALUE:Pflr_Pre_Uw_Adj::NUMERIC(29,5)                AS PFLR_PRE_UW_ADJ     
FROM PXMGT_RATING_020_STG.RATER_GRS_INTERIM g 
,LATERAL FLATTEN(RECORD_CONTENT:Result:Layers) l
)x
LEFT JOIN   PXMGT_RATING_020_STG.RATER_LAYER  rl
                ON  x.BK_RATER_NAME = rl.BK_RATER_NAME
                     AND x.BK_VERSION = rl.BK_VERSION
                     AND x.BK_RATING_ID = rl.BK_RATING_ID
                     AND x.BK_CLIENT_SUPPLIED_ID = rl.BK_CLIENT_SUPPLIED_ID
WHERE       rl.BK_RATING_ID IS NULL ;    
RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));
 
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';
