CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE ()
Create Date:        14 May 2024
Author:             Ionela Ciornei
Description:        Fetch data from interim table to RATER_COVERAGE  table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_COVERAGE ();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
28 Aug 2025         Andreea Macelaru    v1.4 - Add new columns 
18 Jul 2025         Andreea Macelaru    v1.3 - Rename COVERAGE_ARRAY_NAME to BK_COVERAGE_NAME
31 Jul 2024         Catalin Dumitru     v1.2 - Add COVERAGE_ARRAY_NAME
22 Jul 2024         Catalin Dumitru     v1.1 - Coverages becoms array from record, new flatten added; Jira ID SF2-1770
14 May 2024         Ionela Ciornei      v1.0 - Initial script
***************************************************************************************************/
INSERT  INTO PXMGT_RATING_020_STG.RATER_COVERAGE  ( BK_RATING_ID,BK_RATER_NAME,BK_CLIENT_SUPPLIED_ID,BK_VERSION,SK_LAYER_SEQUENCE_NUMBER, BK_COVERAGE_NAME, LIMIT ,EXCESS,DEDUCTIBLE
                                ,AGGREGATE_LIMIT,AGGREGATE_EXCESS ,AGGREGATE_DEDUCTIBLE,CURRENCY ,SECTION_REFERENCE,BROKERAGE,WRITTEN_LINE,PREMIUM,STATUS,BENCHMARK_PREMIUM
                                ,BPI,BPI_PRE_UW_ADJ,MODEL_PREMIUM ,UNITY_PREMIUM ,QUOTED_PREMIUM,TECHNICAL_PREMIUM,TECHNICAL_PREMIUM_PRE_UW_ADJ,TECHNICAL_PREMIUM_NET 
                                ,TPI,TPI_PRE_UW_ADJ,PFLR_ATT ,PFLR_CAT ,PFLR,ROC,UW_ADJ_IMPACT ,EVENT_LOAD_TIMESTAMP,RECORD_KAFKA_NPTS,RECORD_KAFKA_OFFSET
                                ,RECORD_KAFKA_PARTITION ,CREATED_AT,CREATED_BY,CREATED_FROM,PROCESS_ID,SOURCE_NAME,TRIFOCUS,EXPECTED_LOSS_COST,EXPECTED_LOSS_COST_PRE_UW_ADJ
                                ,EXPECTED_LOSS_COST_100,QUOTED_PREMIUM_NET,QUOTED_PREMIUM_NET_100,QUOTED_PREMIUM_100,QUOTED_PREMIUM_ANNUAL,QUOTED_PREMIUM_ANNUAL_100
                                ,BENCHMARK_PREMIUM_NET,BENCHMARK_PREMIUM_NET_100,BENCHMARK_PREMIUM_100,BENCHMARK_PREMIUM_ANNUAL,BENCHMARK_PREMIUM_ANNUAL_100
                                ,BENCHMARK_PREMIUM_PRE_UW_ADJ,TECHNICAL_PREMIUM_100,TECHNICAL_PREMIUM_NET_100,PFLR_PRE_UW_ADJ)
SELECT  inc.BK_RATING_ID
       ,inc.BK_RATER_NAME
       ,inc.BK_CLIENT_SUPPLIED_ID
       ,inc.BK_VERSION
       ,l.SK_LAYER_SEQUENCE_NUMBER
       ,inc.BK_COVERAGE_NAME
       ,inc.LIMIT                       
       ,inc.EXCESS                      
       ,inc.DEDUCTIBLE                  
       ,inc.AGGREGATE_LIMIT             
       ,inc.AGGREGATE_EXCESS            
       ,inc.AGGREGATE_DEDUCTIBLE        
       ,inc.CURRENCY                    
       ,inc.SECTION_REFERENCE           
       ,inc.BROKERAGE                   
       ,inc.WRITTEN_LINE                
       ,inc.PREMIUM                     
       ,inc.STATUS                      
       ,inc.BENCHMARK_PREMIUM           
       ,inc.BPI                         
       ,inc.BPI_PRE_UW_ADJ              
       ,inc.MODEL_PREMIUM               
       ,inc.UNITY_PREMIUM               
       ,inc.QUOTED_PREMIUM              
       ,inc.TECHNICAL_PREMIUM           
       ,inc.TECHNICAL_PREMIUM_PRE_UW_ADJ
       ,inc.TECHNICAL_PREMIUM_NET       
       ,inc.TPI                         
       ,inc.TPI_PRE_UW_ADJ              
       ,inc.PFLR_ATT                    
       ,inc.PFLR_CAT                    
       ,inc.PFLR                        
       ,inc.ROC                         
       ,inc.UW_ADJ_IMPACT 
       ,inc.EVENT_LOAD_TIMESTAMP
       ,inc.RECORD_KAFKA_NPTS
       ,inc.RECORD_KAFKA_OFFSET
       ,inc.RECORD_KAFKA_PARTITION    
       ,inc.CREATED_AT
       ,inc.CREATED_BY
       ,inc.CREATED_FROM
       ,inc.PROCESS_ID
       ,inc.SOURCE_NAME 
       ,inc.TRIFOCUS
	   ,inc.EXPECTED_LOSS_COST
       ,inc.EXPECTED_LOSS_COST_PRE_UW_ADJ
       ,inc.EXPECTED_LOSS_COST_100
       ,inc.QUOTED_PREMIUM_NET
       ,inc.QUOTED_PREMIUM_NET_100
       ,inc.QUOTED_PREMIUM_100
       ,inc.QUOTED_PREMIUM_ANNUAL
       ,inc.QUOTED_PREMIUM_ANNUAL_100
       ,inc.BENCHMARK_PREMIUM_NET
       ,inc.BENCHMARK_PREMIUM_NET_100
       ,inc.BENCHMARK_PREMIUM_100
       ,inc.BENCHMARK_PREMIUM_ANNUAL
       ,inc.BENCHMARK_PREMIUM_ANNUAL_100
       ,inc.BENCHMARK_PREMIUM_PRE_UW_ADJ
       ,inc.TECHNICAL_PREMIUM_100
       ,inc.TECHNICAL_PREMIUM_NET_100
       ,inc.PFLR_PRE_UW_ADJ 
FROM (
        SELECT intr.BK_RATING_ID                                                                 AS BK_RATING_ID
               ,intr.BK_RATER_NAME                                                               AS BK_RATER_NAME
               ,intr.BK_CLIENT_SUPPLIED_ID                                                       AS BK_CLIENT_SUPPLIED_ID
               ,intr.BK_VERSION                                                                  AS BK_VERSION
               ,lf1.INDEX+1                                                                      AS FAKE_SEQ
               ,lf2.VALUE:Name::STRING                                                           AS BK_COVERAGE_NAME
               ,lf2.VALUE:Value:Limit::NUMERIC(29,5)                                             AS LIMIT                       
               ,lf2.VALUE:Value:Excess::NUMERIC(29,5)                                            AS EXCESS                      
               ,lf2.VALUE:Value:Deductible::NUMERIC(29,5)                                        AS DEDUCTIBLE                  
               ,lf2.VALUE:Value:Aggregate_Limit::NUMERIC(29,5)                                   AS AGGREGATE_LIMIT             
               ,lf2.VALUE:Value:Aggregate_Excess::NUMERIC(29,5)                                  AS AGGREGATE_EXCESS            
               ,lf2.VALUE:Value:Aggregate_Deductible::NUMERIC(29,5)                              AS AGGREGATE_DEDUCTIBLE        
               ,lf2.VALUE:Value:Currency::STRING                                                 AS CURRENCY                    
               ,lf2.VALUE:Value:Section_Reference::STRING                                        AS SECTION_REFERENCE           
               ,lf2.VALUE:Value:Brokerage::NUMERIC(29,5)                                         AS BROKERAGE                   
               ,lf2.VALUE:Value:Written_Line::NUMERIC(29,5)                                      AS WRITTEN_LINE                
               ,lf2.VALUE:Value:Premium::NUMERIC(29,5)                                           AS PREMIUM                     
               ,lf2.VALUE:Value:Status::STRING                                                   AS STATUS                      
               ,lf2.VALUE:Value:Benchmark_Premium::NUMERIC(29,5)                                 AS BENCHMARK_PREMIUM           
               ,lf2.VALUE:Value:Bpi::NUMERIC(29,5)                                               AS BPI                         
               ,lf2.VALUE:Value:Bpi_Pre_Uw_Adj::NUMERIC(29,5)                                    AS BPI_PRE_UW_ADJ              
               ,lf2.VALUE:Value:Model_Premium::NUMERIC(29,5)                                     AS MODEL_PREMIUM               
               ,lf2.VALUE:Value:Unity_Premium::NUMERIC(29,5)                                     AS UNITY_PREMIUM               
               ,lf2.VALUE:Value:Quoted_Premium::NUMERIC(29,5)                                    AS QUOTED_PREMIUM              
               ,lf2.VALUE:Value:Technical_Premium::NUMERIC(29,5)                                 AS TECHNICAL_PREMIUM           
               ,lf2.VALUE:Value:Technical_Premium_Pre_Uw_Adj::NUMERIC(29,5)                      AS TECHNICAL_PREMIUM_PRE_UW_ADJ
               ,lf2.VALUE:Value:Technical_Premium_Net::NUMERIC(29,5)                             AS TECHNICAL_PREMIUM_NET       
               ,lf2.VALUE:Value:Tpi::NUMERIC(29,5)                                               AS TPI                         
               ,lf2.VALUE:Value:Tpi_Pre_Uw_Adj::NUMERIC(29,5)                                    AS TPI_PRE_UW_ADJ              
               ,lf2.VALUE:Value:Pflr_Att::NUMERIC(29,5)                                          AS PFLR_ATT                    
               ,lf2.VALUE:Value:Pflr_Cat::NUMERIC(29,5)                                          AS PFLR_CAT                    
               ,lf2.VALUE:Value:Pflr::NUMERIC(29,5)                                              AS PFLR                        
               ,lf2.VALUE:Value:Roc::NUMERIC(29,5)                                               AS ROC                         
               ,lf2.VALUE:Value:Uw_Adj_Impact::NUMERIC(29,5)                                     AS UW_ADJ_IMPACT 
               ,intr.EVENT_LOAD_TIMESTAMP                                                        AS EVENT_LOAD_TIMESTAMP
               ,intr.RECORD_KAFKA_NPTS                                                           AS RECORD_KAFKA_NPTS
               ,intr.RECORD_KAFKA_OFFSET                                                         AS RECORD_KAFKA_OFFSET
               ,intr.RECORD_KAFKA_PARTITION                                                      AS RECORD_KAFKA_PARTITION
               ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                 AS CREATED_AT
               ,intr.CREATED_BY                                                                  AS CREATED_BY
               ,intr.CREATED_FROM                                                                AS CREATED_FROM
               ,intr.PROCESS_ID                                                                  AS PROCESS_ID
               ,intr.SOURCE_NAME                                                                 AS SOURCE_NAME
               ,lf2.VALUE:Value:Trifocus::VARCHAR                                                AS TRIFOCUS
               ,lf2.VALUE:Value:Expected_Loss_Cost::NUMERIC(29,5)                                AS EXPECTED_LOSS_COST
               ,lf2.VALUE:Value:Expected_Loss_Cost_Pre_Uw_Adj::NUMERIC(29,5)                     AS EXPECTED_LOSS_COST_PRE_UW_ADJ
               ,lf2.VALUE:Value:Expected_Loss_Cost_100::NUMERIC(29,5)                            AS EXPECTED_LOSS_COST_100
               ,lf2.VALUE:Value:Quoted_Premium_Net::NUMERIC(29,5)                                AS QUOTED_PREMIUM_NET
               ,lf2.VALUE:Value:Quoted_Premium_Net_100::NUMERIC(29,5)                            AS QUOTED_PREMIUM_NET_100
               ,lf2.VALUE:Value:Quoted_Premium_100::NUMERIC(29,5)                                AS QUOTED_PREMIUM_100
               ,lf2.VALUE:Value:Quoted_Premium_Annual::NUMERIC(29,5)                             AS QUOTED_PREMIUM_ANNUAL
               ,lf2.VALUE:Value:Quoted_Premium_Annual_100::NUMERIC(29,5)                         AS QUOTED_PREMIUM_ANNUAL_100
               ,lf2.VALUE:Value:Benchmark_Premium_Net::NUMERIC(29,5)                             AS BENCHMARK_PREMIUM_NET
               ,lf2.VALUE:Value:Benchmark_Premium_Net_100::NUMERIC(29,5)                         AS BENCHMARK_PREMIUM_NET_100
               ,lf2.VALUE:Value:Benchmark_Premium_100::NUMERIC(29,5)                             AS BENCHMARK_PREMIUM_100
               ,lf2.VALUE:Value:Benchmark_Premium_Annual::NUMERIC(29,5)                          AS BENCHMARK_PREMIUM_ANNUAL
               ,lf2.VALUE:Value:Benchmark_Premium_Annual_100::NUMERIC(29,5)                      AS BENCHMARK_PREMIUM_ANNUAL_100
               ,lf2.VALUE:Value:Benchmark_Premium_Pre_Uw_Adj::NUMERIC(29,5)                      AS BENCHMARK_PREMIUM_PRE_UW_ADJ
               ,lf2.VALUE:Value:Technical_Premium_100::NUMERIC(29,5)                             AS TECHNICAL_PREMIUM_100
               ,lf2.VALUE:Value:Technical_Premium_Net_100::NUMERIC(29,5)                         AS TECHNICAL_PREMIUM_NET_100
               ,lf2.VALUE:Value:Pflr_Pre_Uw_Adj::NUMERIC(29,5)                                   AS PFLR_PRE_UW_ADJ 
        FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM intr
               ,LATERAL FLATTEN (intr.RECORD_CONTENT:Result.Layers) lf1
               ,LATERAL FLATTEN (lf1.VALUE:Coverages) lf2
        WHERE  lf2.VALUE::STRING IS NOT NULL
) AS inc
INNER JOIN  (SELECT BK_RATER_NAME,BK_VERSION,BK_RATING_ID,BK_CLIENT_SUPPLIED_ID,SK_LAYER_SEQUENCE_NUMBER
                    ,ROW_NUMBER() OVER (PARTITION BY BK_RATER_NAME,BK_VERSION,BK_RATING_ID,BK_CLIENT_SUPPLIED_ID ORDER BY SK_LAYER_SEQUENCE_NUMBER) AS RNK
              FROM PXMGT_RATING_020_STG.RATER_LAYER           
             )l 
                ON  l.BK_RATER_NAME = inc.BK_RATER_NAME
                AND l.BK_VERSION = inc.BK_VERSION
                AND l.BK_RATING_ID = inc.BK_RATING_ID
                AND l.BK_CLIENT_SUPPLIED_ID = inc.BK_CLIENT_SUPPLIED_ID
                AND l.RNK = inc.FAKE_SEQ
LEFT JOIN  PXMGT_RATING_020_STG.RATER_COVERAGE   rrr
                ON  inc.BK_RATER_NAME = rrr.BK_RATER_NAME
                AND inc.BK_VERSION = rrr.BK_VERSION
                AND inc.BK_RATING_ID = rrr.BK_RATING_ID
                AND inc.BK_CLIENT_SUPPLIED_ID = rrr.BK_CLIENT_SUPPLIED_ID
                AND l.SK_LAYER_SEQUENCE_NUMBER = rrr.SK_LAYER_SEQUENCE_NUMBER
                AND inc.BK_COVERAGE_NAME = rrr.BK_COVERAGE_NAME
WHERE  rrr.BK_RATING_ID IS NULL 
;
               
    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';
