CREATE OR REPLACE PROCEDURE  PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_SELECTED_DETAILS()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_SELECTED_DETAILS()
Create Date:        16 May 2024
Author:             Razvan Bucur
Description:        Fetch data from interim table to RATER_RATE_CHANGE_SELECTED_DETAILS table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATE_CHANGE_SELECTED_DETAILS();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
28 Aug 2025         Andreea Macelaru    v1.4 - Add new columns 
02 Jul 2025         Naomi Vasu          v1.3 - Move EXPIRING_LAYER to RATER_RATE_CHANGE_SELECTED_DETAILS
29 Jul 2024         Catalin Dumitru     v1.2 - Add BK_RATE_CHANGE_TYPE column
23 May 2024         Andreea-Elena Radu  v1.1 - Add inner join with Rater_Layer 
16 May 2024         Razvan Bucur        v1.0 - Initial script
***************************************************************************************************/
INSERT INTO PXMGT_RATING_020_STG.RATER_RATE_CHANGE_SELECTED_DETAILS 
( BK_RATER_NAME, BK_VERSION, BK_RATING_ID, SK_LAYER_SEQUENCE_NUMBER, BK_CLIENT_SUPPLIED_ID, BK_RATE_CHANGE_TYPE, MODEL_CALCULATED, UW_SELECTED, COMMENT,
  LLOYDS_LIMIT_ATTACHEMENT_POINT_CHANGE, Lloyds_Breadth_Of_Cover_Change_Change, OTHER_FACTORS_CHANGE, EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, 
  RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME, EXPIRING_LAYER, RISK_ADJUSTED_RATE_CHANGE, RISK_ADJUSTED_RATE_CHANGE_GROSS_FOR_REPORTING )
SELECT      x.BK_RATER_NAME
           ,x.BK_VERSION
           ,x.BK_RATING_ID
           ,l.SK_Layer_Sequence_Number
           ,x.BK_CLIENT_SUPPLIED_ID
           ,x.BK_RATE_CHANGE_TYPE
           ,x.MODEL_CALCULATED
           ,x.UW_SELECTED
           ,x.COMMENT
           ,x.LLOYDS_LIMIT_ATTACHEMENT_POINT_CHANGE
           ,x.Lloyds_Breadth_Of_Cover_Change_Change
           ,x.OTHER_FACTORS_CHANGE                                 
           ,x.EVENT_LOAD_TIMESTAMP                 
           ,x.RECORD_KAFKA_NPTS                        
           ,x.RECORD_KAFKA_OFFSET   
           ,x.RECORD_KAFKA_PARTITION
           ,x.CREATED_AT                           
           ,x.CREATED_BY         
           ,x.CREATED_FROM
           ,x.PROCESS_ID
           ,x.SOURCE_NAME
           ,x.EXPIRING_LAYER  
           ,x.RISK_ADJUSTED_RATE_CHANGE
           ,x.RISK_ADJUSTED_RATE_CHANGE_GROSS_FOR_REPORTING
           
FROM        (
                    SELECT       i.BK_RATER_NAME                                                                      AS BK_RATER_NAME
                                ,i.BK_VERSION                                                                         AS BK_VERSION
                                ,i.BK_RATING_ID                                                                       AS BK_RATING_ID
                                ,i.BK_CLIENT_SUPPLIED_ID                                                              AS BK_CLIENT_SUPPLIED_ID 
                                ,''Rate_Change''                                                                      AS BK_RATE_CHANGE_TYPE
                                ,lf.INDEX + 1                                                                         AS IDX  
                                ,lf.VALUE:Rate_Change:Rate_Change:Model_Calculated                                    AS MODEL_CALCULATED 
                                ,lf.VALUE:Rate_Change:Rate_Change:Uw_Selected                                         AS UW_SELECTED  
                                ,lf.VALUE:Rate_Change:Rate_Change:Comments                                            AS COMMENT     
                                ,lf.VALUE:Rate_Change:Rate_Change:Lloyds_Limit_Attachment_Point_Change                AS LLOYDS_LIMIT_ATTACHEMENT_POINT_CHANGE  
                                ,lf.VALUE:Rate_Change:Rate_Change:Lloyds_Breadth_Of_Cover_Change_Change               AS Lloyds_Breadth_Of_Cover_Change_Change
                                ,lf.VALUE:Rate_Change:Rate_Change:Other_Factors_Change                                AS OTHER_FACTORS_CHANGE                                             
                                ,i.EVENT_LOAD_TIMESTAMP                                                               AS EVENT_LOAD_TIMESTAMP                 
                                ,i.RECORD_KAFKA_NPTS                                                                  AS RECORD_KAFKA_NPTS                               
                                ,i.RECORD_KAFKA_OFFSET                                                                AS RECORD_KAFKA_OFFSET   
                                ,i.RECORD_KAFKA_PARTITION                                                             AS RECORD_KAFKA_PARTITION
                                ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                                     AS CREATED_AT                           
                                ,i.CREATED_BY                                                                         AS CREATED_BY         
                                ,i.CREATED_FROM                                                                       AS CREATED_FROM
                                ,i.PROCESS_ID                                                                         AS PROCESS_ID
                                ,i.SOURCE_NAME                                                                        AS SOURCE_NAME
                                ,lf.VALUE:Rate_Change.Expiring_Layer::NUMBER(38,0)                                    AS EXPIRING_LAYER 
                                ,lf.VALUE:Rate_Change.Risk_Adjusted_Rate_Change::NUMBER(29,5)                         AS RISK_ADJUSTED_RATE_CHANGE
                                ,lf.VALUE:Rate_Change.Risk_Adjusted_Rate_Change_Gross_For_Reporting::NUMBER(29,5)     AS RISK_ADJUSTED_RATE_CHANGE_GROSS_FOR_REPORTING
                    FROM        PXMGT_RATING_020_STG.RATER_GRS_INTERIM i 
                    ,LATERAL FLATTEN(i.RECORD_CONTENT:Result:Layers) AS lf
            ) x
            
INNER JOIN  (
                    SELECT       BK_RATER_NAME                                                    
                                ,BK_VERSION                                              
                                ,BK_RATING_ID                                             
                                ,BK_CLIENT_SUPPLIED_ID 
                                ,SK_LAYER_SEQUENCE_NUMBER
                                ,ROW_NUMBER() OVER (PARTITION BY     BK_RATER_NAME                                                    
                                                                    ,BK_VERSION                                              
                                                                    ,BK_RATING_ID                                             
                                                                    ,BK_CLIENT_SUPPLIED_ID 
                                                        ORDER BY     SK_LAYER_SEQUENCE_NUMBER) AS IDX_LAYER
                                                
                    FROM        PXMGT_RATING_020_STG.RATER_LAYER      
            ) l 
        ON  x.BK_RATER_NAME						= l.BK_RATER_NAME           
        AND x.BK_VERSION						= l.BK_VERSION              
        AND x.BK_RATING_ID						= l.BK_RATING_ID            
        AND x.BK_CLIENT_SUPPLIED_ID				= l.BK_CLIENT_SUPPLIED_ID  
        AND x.IDX                               = l.IDX_LAYER
            
LEFT JOIN   PXMGT_RATING_020_STG.RATER_RATE_CHANGE_SELECTED_DETAILS  rrcsd
        ON  x.BK_RATER_NAME                     = rrcsd.BK_RATER_NAME
        AND x.BK_VERSION                        = rrcsd.BK_VERSION
        AND x.BK_RATING_ID                      = rrcsd.BK_RATING_ID
        AND x.BK_CLIENT_SUPPLIED_ID             = rrcsd.BK_CLIENT_SUPPLIED_ID
        AND l.SK_LAYER_SEQUENCE_NUMBER          = rrcsd.SK_LAYER_SEQUENCE_NUMBER
        
WHERE  rrcsd.BK_RATING_ID IS NULL 
;
RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));
 
    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';