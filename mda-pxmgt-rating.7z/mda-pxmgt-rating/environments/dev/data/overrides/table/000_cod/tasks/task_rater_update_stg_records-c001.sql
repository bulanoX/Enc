CREATE OR ALTER TASK PXMGT_RATING_000_COD.TSK_RATER_UPDATE_STG_RECORDS
    COMMENT = 'The task runs a stored procedure PRC_RATER_UPDATE_STG_RECORDS() which updates the inception_date and expiry_date columns in the RATER_STANDARD_FIELDS according to the RATER_GRS_UPDATE table'
AS
    CALL PXMGT_RATING_000_COD.PRC_RATER_UPDATE_STG_RECORDS()
;