CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATED_RISK()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATED_RISK()
Create Date:        10 May 2024
Author:             Ionela Ciornei
Description:        Fetch data from interim table to RATER_RATED_RISK table
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_LOAD_STG_INTERIM_TABLE_TO_STG_RATER_RATED_RISK();
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
----------------------------------------------------------------------------------------------
3 Jul 2025          Naomi Vasu         v1.3 - Add IS_ARCHIVED, EXPIRING_POLICY_OPTION_ID, EXPIRING_POLICY_ID, POLICY_ID, RATING_ENGINE_NAME and MODEL_VERSION columns
12 May 2025         Andreea Macelaru   v1.2 - Change data type for Policy_option_id to String
5 May 2025          Andreea Macelaru   v1.1 - Add Policy_option_id column
10 May 2024         Ionela Ciornei     v1.0 - Initial script
***************************************************************************************************/

INSERT  INTO PXMGT_RATING_020_STG.RATER_RATED_RISK (
BK_RATING_ID, BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID, BK_VERSION, PRODUCT_ID, DATE_CREATED,LAST_UPDATED, STATUS, REQUEST_DATE, EVENT_LOAD_TIMESTAMP, RECORD_KAFKA_NPTS, RECORD_KAFKA_OFFSET, RECORD_KAFKA_PARTITION, CREATED_AT, CREATED_BY, CREATED_FROM, PROCESS_ID, SOURCE_NAME, POLICY_OPTION_ID, IS_ARCHIVED, EXPIRING_POLICY_OPTION_ID, EXPIRING_POLICY_ID, POLICY_ID, RATING_ENGINE_NAME, MODEL_VERSION)

SELECT  intr.BK_RATING_ID                                                   AS BK_RATING_ID
       ,intr.BK_RATER_NAME                                                  AS BK_RATER_NAME
       ,intr.BK_CLIENT_SUPPLIED_ID                                          AS BK_CLIENT_SUPPLIED_ID
       ,intr.BK_VERSION                                                     AS BK_VERSION
       ,RECORD_CONTENT:Request.Request_Info.Product_Id::STRING              AS PRODUCT_ID
       ,RECORD_CONTENT:Metadata.Created::DATETIME                           AS DATE_CREATED
       ,RECORD_CONTENT:Metadata.Last_Updated::DATETIME                      AS LAST_UPDATED
       ,RECORD_CONTENT:Metadata.Status::STRING                              AS STATUS
       ,RECORD_CONTENT:Request.Request_Info.Request_Date::DATETIME          AS REQUEST_DATE
       ,intr.EVENT_LOAD_TIMESTAMP                                           AS EVENT_LOAD_TIMESTAMP
       ,intr.RECORD_KAFKA_NPTS                                              AS RECORD_KAFKA_NPTS
       ,intr.RECORD_KAFKA_OFFSET                                            AS RECORD_KAFKA_OFFSET
       ,intr.RECORD_KAFKA_PARTITION                                         AS RECORD_KAFKA_PARTITION
       ,CURRENT_TIMESTAMP::TIMESTAMP_NTZ                                    AS CREATED_AT
       ,intr.CREATED_BY                                                     AS CREATED_BY
       ,intr.CREATED_FROM                                                   AS CREATED_FROM
       ,intr.PROCESS_ID                                                     AS PROCESS_ID
       ,intr.SOURCE_NAME                                                    AS SOURCE_NAME
       ,RECORD_CONTENT:Metadata.Rating_Engine_Quote_Id::VARCHAR             AS POLICY_OPTION_ID
       ,COALESCE(TO_BOOLEAN(RECORD_CONTENT:Metadata.Is_Archived), FALSE)    AS IS_ARCHIVED
       ,RECORD_CONTENT:Metadata.Rating_Engine_Expiring_Quote_Id::VARCHAR    AS EXPIRING_POLICY_OPTION_ID
       ,RECORD_CONTENT:Metadata.Rating_Engine_Expiring_Risk_Id::VARCHAR     AS EXPIRING_POLICY_ID
       ,RECORD_CONTENT:Metadata.Rating_Engine_Risk_Id::VARCHAR              AS POLICY_ID
       ,RECORD_CONTENT:Metadata.Rating_Engine_Name::VARCHAR                 AS RATING_ENGINE_NAME
       ,RECORD_CONTENT:Metadata.Model_Version::VARCHAR                      AS MODEL_VERSION
FROM    PXMGT_RATING_020_STG.RATER_GRS_INTERIM intr
LEFT JOIN   PXMGT_RATING_020_STG.RATER_RATED_RISK  rrr
                ON  intr.BK_RATER_NAME = rrr.BK_RATER_NAME
                AND intr.BK_VERSION = rrr.BK_VERSION
                AND intr.BK_RATING_ID = rrr.BK_RATING_ID
                AND intr.BK_CLIENT_SUPPLIED_ID = rrr.BK_CLIENT_SUPPLIED_ID
WHERE  rrr.BK_RATING_ID IS NULL     

;

       
        
    RETURN (''Number of rows inserted: '' || (SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))));

    EXCEPTION
    WHEN EXPRESSION_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN STATEMENT_ERROR THEN
        ROLLBACK;
        RAISE;
    WHEN OTHER THEN
        ROLLBACK;
        RAISE;
END';
