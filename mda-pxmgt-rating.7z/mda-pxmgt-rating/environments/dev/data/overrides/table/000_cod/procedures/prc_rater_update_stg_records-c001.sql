CREATE OR REPLACE PROCEDURE PXMGT_RATING_000_COD.PRC_RATER_UPDATE_STG_RECORDS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS 
$$
/***************************************************************************************************
Procedure:          PXMGT_RATING_000_COD.PRC_RATER_UPDATE_STG_RECORDS()
Create Date:        26 June 2025
Author:             Andreea Macelaru
Description:        Replace values from PXMGT table RATER_STANDARD_FIELDS using the following columns : BK_RATING_ID,
                    BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID from a stage loaded table : PXMGT_RATING_010_ING.RATER_GRS_UPDATE
Call by:            A task with requisite role and permissions provided.
Usage:              CALL PXMGT_RATING_000_COD.PRC_RATER_UPDATE_STG_RECORDS()
****************************************************************************************************
SUMMARY OF CHANGES
Date(dd Mmm yyyy)   Author              Comments
------------------- ------------------- ------------------------------------------------------------
26 June 2025         Andreea Macelaru     v1.0 - Initial script
***************************************************************************************************/
BEGIN

UPDATE PXMGT_RATING_020_STG.RATER_STANDARD_FIELDS rsf
SET rsf.INCEPTION_DATE = TO_TIMESTAMP(rgu.INCEPTION_DATE)
FROM PXMGT_RATING_010_ING.RATER_GRS_UPDATE AS rgu
WHERE rsf.BK_RATING_ID = rgu.BK_RATING_ID
      AND rsf.BK_RATER_NAME = rgu.BK_RATER_NAME
      AND rsf.BK_CLIENT_SUPPLIED_ID = rgu.BK_CLIENT_SUPPLIED_ID;

UPDATE PXMGT_RATING_020_STG.RATER_STANDARD_FIELDS rsf
SET rsf.EXPIRY_DATE = TO_TIMESTAMP(rgu.EXPIRY_DATE)
FROM PXMGT_RATING_010_ING.RATER_GRS_UPDATE AS rgu
WHERE rsf.BK_RATING_ID = rgu.BK_RATING_ID
      AND rsf.BK_RATER_NAME = rgu.BK_RATER_NAME
      AND rsf.BK_CLIENT_SUPPLIED_ID = rgu.BK_CLIENT_SUPPLIED_ID;

	RETURN 'Records updated successfully';
END;
$$;


