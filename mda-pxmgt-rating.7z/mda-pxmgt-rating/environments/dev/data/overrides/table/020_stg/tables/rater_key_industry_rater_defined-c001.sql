CREATE TABLE IF NOT EXISTS PXMGT_RATING_020_STG.RATER_KEY_INDUSTRY_RATER_DEFINED(
    BK_RATER_NAME VARCHAR(16777216) NOT NULL,
    BK_VERSION INT NOT NULL,
    BK_RATING_ID VARCHAR(16777216) NOT NULL,
    BK_KEY_INDUSTRY_KEY VARCHAR(16777216) NOT NULL,
    BK_CLIENT_SUPPLIED_ID VARCHAR(16777216) NOT NULL,
    KEY_INDUSTRY_VALUE VARCHAR(16777216),
    EVENT_LOAD_TIMESTAMP TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Provides the date and time when the record was stored in a topic within Kafka',
    RECORD_KAFKA_NPTS TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Provides the date and time when the record was ingested from Kafka topic',
    RECORD_KAFKA_OFFSET NUMBER(19,0) NOT NULL COMMENT 'Captures the unique offset for the same key from the Kafka topic',
    RECORD_KAFKA_PARTITION NUMBER(19,0) NOT NULL COMMENT 'Captures the unique parition for the same key from the Kafka topic',
    CREATED_AT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'This is timestamp of when the record was inserted into staging layer',
    CREATED_FROM VARCHAR(16777216) NOT NULL COMMENT 'This is name of immediate data source of the created record',
    PROCESS_ID NUMBER(38,0) NOT NULL COMMENT 'This is ID of the process which created or updated the data most recently',
    SOURCE_NAME VARCHAR(16777216) NOT NULL COMMENT 'This is name of the original data source',
    constraint PK_KEY_INDUSTRY_RATER_DEFINED_KEY PRIMARY KEY (BK_RATING_ID, BK_VERSION, BK_KEY_INDUSTRY_KEY, BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID)
);