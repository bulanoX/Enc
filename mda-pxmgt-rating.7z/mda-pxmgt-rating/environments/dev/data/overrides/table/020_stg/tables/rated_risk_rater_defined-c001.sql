CREATE TABLE IF NOT EXISTS PXMGT_RATING_020_STG.RATED_RISK_RATER_DEFINED (
    BK_RATING_ID VARCHAR(16777216) NOT NULL,
	BK_RATING_VERSION NUMBER(38,0) NOT NULL,
	BK_RATER_NAME VARCHAR(16777216) NOT NULL,
	BK_CLIENT_SUPPLIED_ID VARCHAR(16777216) NOT NULL,
    KEY VARCHAR(16777216),
    VALUE VARCHAR(16777216),
	EVENT_LOAD_TIMESTAMP TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Provides the date and time when the record was stored in a topic within Kafka',
	RECORD_KAFKA_NPTS TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Provides the date and time when the record was ingested from Kafka topic',
	RECORD_KAFKA_OFFSET NUMBER(19,0) NOT NULL COMMENT 'Captures the unique offset for the same key from the Kafka topic',
	RECORD_KAFKA_PARTITION NUMBER(19,0) NOT NULL COMMENT 'Captures the unique parition for the same key from the Kafka topic',
	CREATED_AT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'This is timestamp of when the record was inserted into staging layer',
	CREATED_BY VARCHAR(16777216) NOT NULL COMMENT 'This is name of the service account that created the record',
	CREATED_FROM VARCHAR(16777216) NOT NULL COMMENT 'This is name of immediate data source of the created record',
	PROCESS_ID NUMBER(38,0) NOT NULL COMMENT 'This is ID of the process which created or updated the data most recently',
	SOURCE_NAME VARCHAR(16777216) NOT NULL COMMENT 'This is name of the original data source',
	constraint PK_RATED_RISK_RATER_DEFINED primary key (BK_RATING_ID, BK_RATING_VERSION, BK_RATER_NAME, BK_CLIENT_SUPPLIED_ID)
)