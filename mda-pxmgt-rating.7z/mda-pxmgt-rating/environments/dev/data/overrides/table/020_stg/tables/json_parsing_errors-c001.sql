CREATE TABLE IF NOT EXISTS PXMGT_RATING_020_STG.JSON_PARSING_ERRORS (
	PROCESS_ID NUMBER(38,0) NOT NULL COMMENT 'Run_id from last executed Root task',
	RATER_TYPE VARCHAR(16777216) NOT NULL COMMENT 'Rater type',
	ERROR_TYPE VARCHAR(16777216) NOT NULL COMMENT 'Provides information which object failed while parsing to JSON',
	RATER_DEFINED_ERROR_LOCATION VARCHAR(16777216) COMMENT 'Provides location of failed RaterDefined object',
	RECORD_METADATA VARIANT COMMENT 'Records metadata such as kafka partition and offset',
	RECORD_CONTENT VARIANT COMMENT 'Records content',
	RECORD_LDTS TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Timestamp when the record was inserted into Ingestion table'
);