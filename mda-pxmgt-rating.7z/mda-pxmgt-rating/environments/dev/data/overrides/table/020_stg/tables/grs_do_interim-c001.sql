CREATE TABLE IF NOT EXISTS PXMGT_RATING_020_STG.GRS_DO_INTERIM (
	RECORD_METADATA VARIANT COMMENT 'records metadata such as kafka partition and offset',
	RECORD_CONTENT VARIANT COMMENT 'records content',
	RECORD_LDTS TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'timestamp when the record was inserted into the table',
	IS_CORRECT_RECORD_CONTENT BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'provides information if the JSON parsing of RECORD_CONTENT attribute succeeded',
	IS_CORRECT_RATER_DEFINED BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'provides information if the JSON parsing of RaterDefined attribute succeeded',
	RATER_DEFINED_ERROR_LOCATION VARCHAR(16777216) COMMENT 'provides information location of RaterDefined for which JSON parsing failed'
);