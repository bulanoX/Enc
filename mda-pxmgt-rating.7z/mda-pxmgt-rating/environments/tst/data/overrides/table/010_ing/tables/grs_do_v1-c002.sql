CREATE OR ALTER TABLE PXMGT_RATING_010_ING.GRS_DO (
	RECORD_METADATA VARIANT COMMENT 'records metadata such as kafka partition and offset',
	RECORD_CONTENT VARIANT COMMENT 'records content',
	RECORD_LDTS TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'timestamp when the record was inserted into the table'
);