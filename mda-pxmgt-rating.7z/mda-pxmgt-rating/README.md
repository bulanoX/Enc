# mda-domain-template

This repository has been created to provide MDA developers the path structure and basic configuration of a given domain.

## Structure per “domain-subdomain” (being domain-subdomain the repository name).
Separate the files for environments, with common.

Validations to introduce:

Validate that there two files, one for topic configs and other for schema (depends on answer to question).

Validate that topic name and filename for topic/schema match - otherwise it gets confusing.

Validate that files that are in the environment overrides are for artefacts (topics) that exist in the common.
```
├── README.md
├── resources
│   └── // AUTOMATION AND TOOLING FOR SPECIFIC SUBDOMAIN/DOMAIN*
└── environments
    ├── common
    │   ├── data
    │   │   ├── topic
    │   │   │   ├── raw
    │   │   │   ├── cleansed
    │   │   │   └── enriched
    │   │   ├── dataset
    │   │   │   ├── raw
    │   │   │   ├── cleansed
    │   │   │   └── enriched
    │   │   └── table
    │   │       ├── ingestion
    │   │       ├── staging
    │   │       ├── raw_vault
    │   │       ├── business_vault
    │   │       └── presentation_layer
    │   └── process
    │       ├── streaming
    │       │   ├── connector
    │       │   │   ├── source
    │       │   │   └── sink
    │       │   ├── simple
    │       │   ├── complex
    │       │   └── application
    │       │       ├── consumer
    │       │       └── producer
    │       └── batch
    │           ├── simple
    │           ├── complex
    │           └── orchestration
    ├── sandbox
    │   ├── data
    │   │   └── overrides
    │   │       ├── topic
    │   │       │   ├── raw
    │   │       │   ├── cleansed
    │   │       │   └── enriched
    │   │       ├── dataset
    │   │       │   ├── raw
    │   │       │   ├── cleansed
    │   │       │   └── enriched
    │   │       └── table
    │   │           ├── ingestion
    │   │           ├── staging
    │   │           ├── raw_vault
    │   │           ├── business_vault
    │   │           └── presentation_layer
    │   └── process
    │       └── overrides
    │           ├── streaming
    │           │   ├── connector
    │           │   │   ├── source
    │           │   │   └── sink
    │           │   ├── simple
    │           │   ├── complex
    │           │   └── application
    │           │       ├── consumer
    │           │       └── producer
    │           └── batch
    │               ├── simple
    │               ├── complex
    │               └── orchestration
    ├── dev
    │   └── ...   # Same structure as sandbox       
    ├── uat
    │   └── ...   # Same structure as sandbox  
    └── prod
        └── ...   # Same structure as sandbox
```

More detailed info in: [Git structure for data domains](https://beazley.atlassian.net/wiki/spaces/EAAS/pages/3830972913/Git+Structure+for+Data+Domains+WIP)
OWNERS: MDA-SRE team
