CREATE OR REPLACE VIEW CLAIMS_DEFAULT_020_STG.VW_MDA_LMMESSAGE_FULL AS
SELECT
    lmmsg.ActionParticipant AS ActionParticipant,
    ecf_part_type.NAME AS ActionParticipantType,
    -- lmmsg.AdditionalDetails AS AdditionalDetails,
    lmmsg.AgreementPartyContactEmail_Bzy AS AgreementPartyContactEmail,
    lmmsg.AgreementPartyContactName_Bzy AS AgreementPartyContactName,
    lmmsg.AgreementPartyContactTel_Bzy AS AgreementPartyContactTelephone,
    -- lmmsg.AllUnderwritersToSeeFileInd AS AllUnderwritersToSeeFileIndicator,
    -- lmmsg.AmendmentDetails AS AmendmentDetails,
    lmmsg.ApprovalIssue AS ApprovalIssue,
    lmmsg.AsOfDate::TIMESTAMP_NTZ AS AsOfDate,
    lmmsg.AssignedByUserID AS AssignedByUserID,
    lmmsg.AssignedGroupID AS AssignedGroupID,
    -- lmmsg.AssignedQueueID AS AssignedQueueID, 
    -- lmmsg.AssignedUserID AS AssignedUserID,
    lmmsg.AssignmentDate::TIMESTAMP_NTZ AS AssignmentDate,
    assign_status_type.NAME AS AssignmentStatus,
    lmmsg.BlockIndicator_Bzy AS BlockIndicator,
    lmmsg.BrokerContact AS BrokerContact,
    lmmsg.BrokerEmail AS BrokerEmail,
    lmmsg.BrokerId AS BrokerId,
    lmmsg.BrokerName AS BrokerName,
    lmmsg.BrokerPhone AS BrokerPhone,
    -- lmmsg.BrokerReference AS BrokerReference,
    -- lmmsg.BulkClaimHeaderTR AS BulkClaimHeaderTR,
    -- lmmsg.BulkClaimHeaderUCR AS BulkClaimHeaderUCR,
    -- lmmsg.BulkClaimNoOfItems AS BulkClaimNoOfItems,
    -- lmmsg.BureauLeadingInsurerComments AS BureauLeadingInsurerComments,
    lmmsg.BureauShare_Bzy AS BureauShare,
    lmmsg.BureauSigningRef_Bzy AS BureauSigningReference,
    ecf_bureau_type.NAME AS BureauType,
    lmmsg.CCv_5_CreateTime_Bzy::TIMESTAMP_NTZ AS CCv5CreateTime,
    lmmsg.CCv_5_CreateUser_Bzy AS CCv5CreateUser,
    lmmsg.CCv_5_UpdateTime_Bzy::TIMESTAMP_NTZ AS CCv5UpdateTime,
    lmmsg.CCv_5_UpdateUser_Bzy AS CCv5UpdateUser,
    -- ecf_claim_cat_code_type.DESCRIPTION AS CategoryCodeDesc,
    -- ecf_claim_cat_code_type.NAME AS CategoryCode,
    ecf_cause_of_loss_code_type1.DESCRIPTION AS CauseOfLossCodeDesc,
    ecf_cause_of_loss_code_type1.NAME AS CauseOfLossCode,
    -- lmmsg.CedantInLiquidationIndicator AS CedantInLiquidationIndicator,
    -- lmmsg.CedentPartyName AS CedentPartyName,
    -- lmmsg.ChaseUpIndicator AS ChaseUpIndicator,
    -- lmmsg.ChaseUpIndicatorInterval AS ChaseUpIndicatorInterval,
    lmmsg.Claim AS Claim,
    lmmsg.ClaimLineNumber AS ClaimLineNumber,
    lmmsg.ClaimResponseUUId AS ClaimResponseUUId,
    lmmsg.ClaimRetrieveReqReferredUUId AS ClaimRetrieveReqReferredUUId,
    ecf_msg_claim_status_type.NAME AS ClaimStatus,
    ecf_claim_typecode_type.NAME AS ClaimType,
    -- lmmsg.Claimant AS Claimant,
    ecf_scheme_type.NAME AS ClaimsScheme,
    ecf_class_of_bus_type.DESCRIPTION AS ClassOfBusiness,
    -- lmmsg.CloseDate AS CloseDate,
    -- lmmsg.CollectionUnlikelyIndicator AS CollectionUnlikelyIndicator,
    lmmsg.ConflictOfInterestInd AS ConflictOfInterestIndicator,
    lmmsg.ContactClassAccountId AS ContactClassAccountId,
    lmmsg.ContactClassUserId AS ContactClassUserId,
    lmmsg.ContactData AS ContactData,
    lmmsg.ContactEmail AS ContactEmail,
    -- lmmsg.ContactFax AS ContactFax,
    lmmsg.ContactName AS ContactName,
    lmmsg.ContactTelephone AS ContactTelephone,
    -- ecf_contr_type.NAME AS ContractConditionsApplyIndicator,
    -- lmmsg.ContractualConditionsIndicator AS ContractualConditionsIndicator,
    lmmsg.Country AS Country,
    lmmsg.CountryUSState AS CountryUSState,
    -- lmmsg.CoverType AS CoverType,
    lmmsg.CreateTime::TIMESTAMP_NTZ AS CreateTime,
    lmmsg.CreateUserID AS CreateUserId,
    c_c.displaynamemda AS CreateUserName,
    lmmsg.CreationDate::TIMESTAMP_NTZ AS CreationDate,
    curr_type1.NAME AS Currency1,
    curr_type2.NAME AS Currency2,
    curr_type3.NAME AS Currency3,
    add_os_claim_info_type.NAME AS CurrentNettOsQualifier,
    lmmsg.DownloadRequestUUId AS DownloadRequestUUId,
    lmmsg.DownloadResponseUUId AS DownloadResponseUUId,
    ecf_act_code_type.NAME AS ECFActionCode,
    lmmsg.ECFContactData AS ECFContactData,
    ecf_risk_code_type.DESCRIPTION AS ECFRiskCodeDesc,
    ecf_risk_code_type.NAME AS ECFRiskCode,
    lmmsg.ECFTransactionState AS ECFTransactionState,
    lmmsg.Excess_Bzy AS Excess,
    lmmsg.FILCode_Bzy AS FILCode,
    lmmsg.FailedMessageUUID AS FailedMessageUUID,
    -- ecf_file_format_type.NAME AS FileFormat,
    lmmsg.GroupReference_Bzy AS GroupReference,
    lmmsg.GroupedIndicator AS GroupedIndicator,
    lmmsg.ID AS ID,
    lmmsg.IMRDocumentId AS IMRDocumentId,
    lmmsg.IMRDocumentReference_Bzy AS IMRDocumentReference,
    lmmsg.IMRDocumentVersion_Bzy AS IMRDocumentVersion,
    -- lmmsg.ImmediatePartCollectionInd AS ImmediatePartCollectionIndicator,
    lmmsg.ImportedServicesAmount_1_Amt AS ImportedServicesAmount1,
    imp_serv_curr_type1.NAME AS ImportedServicesAmount1Currency,
    lmmsg.ImportedServicesAmount_2_Amt AS ImportedServicesAmount2,
    imp_serv_curr_type2.NAME AS ImportedServicesAmount2Currency,
    lmmsg.ImportedServicesAmount_3_Amt AS ImportedServicesAmount3,
    imp_serv_curr_type3.NAME AS ImportedServicesAmount3Currency,
    -- lmmsg.ImportedServicesNarrative1 AS ImportedServicesNarrative1,
    -- lmmsg.ImportedServicesNarrative2 AS ImportedServicesNarrative2,
    -- lmmsg.ImportedServicesNarrative3 AS ImportedServicesNarrative3,
    lmmsg.Insured AS Insured,
    -- lmmsg.InsuredId AS InsuredId,
    lmmsg.InsuredName AS InsuredName,
    lmmsg.InsurerOrReinsurerClaimRef_1 AS InsurerOrReinsurerClaimRef1,
    lmmsg.InsurerOrReinsurerClaimRef_2 AS InsurerOrReinsurerClaimRef2,
    -- lmmsg.InsurerReference AS InsurerReference,
    lmmsg.InsurerRiskReference AS InsurerRiskReference,
    lmmsg.InsurerTransactionReference AS InsurerTransactionReference,
    IFF(lmmsg.Retired = 0, 1, 0) AS IsActive,
    -- lmmsg.IsSimultaneousRIPIndicator AS IsSimultaneousRIPIndicator,
    lmmsg.LIRMALeadActions AS LIRMALeadActions,
    lmmsg.LcoCatastropheCode AS LcoCatastropheCode,
    lmmsg.LeadContactEmail AS LeadContactEmail,
    lmmsg.LeadContactName AS LeadContactName,
    lmmsg.LeadContactTelephone AS LeadContactTelephone,
    lmmsg.LeadName AS LeadName,
    lmmsg.LeadReserveAmount_1_Amt AS LeadReserveAmount1,
    lead_res_amt_curr_type1.NAME AS LeadReserveAmount1Currency,
    lmmsg.LeadReserveAmount_2_Amt AS LeadReserveAmount2,
    lead_res_amt_curr_type2.NAME AS LeadReserveAmount2Currency,
    lmmsg.LeadReserveAmount_3_Amt AS LeadReserveAmount3,
    lead_res_amt_curr_type3.NAME AS LeadReserveAmount3Currency,
    lmmsg.LeadReserveFees_1_Amt AS LeadReserveFees1Amount,
    lead_res_fees_curr_type1.NAME AS LeadReserveFees1Currency,
    lmmsg.LeadReserveFees_2_Amt AS LeadReserveFees2Amount,
    lead_res_fees_curr_type2.NAME AS LeadReserveFees2Currency,
    lmmsg.LeadReserveFees_3_Amt AS LeadReserveFees3Amount,
    lead_res_fees_curr_type3.NAME AS LeadReserveFees3Currency,
    -- lmmsg.LinkedOnly_Bzy AS LinkedOnly,
    ecf_cause_of_loss_code_type2.DESCRIPTION AS LossCauseDesc,
    ecf_cause_of_loss_code_type2.NAME AS LossCause,
    ecf_loss_date_qual_type.DESCRIPTION AS LossDateQualifierDesc,
    ecf_loss_date_qual_type.NAME AS LossDateQualifier,
    lmmsg.LossDescription AS LossDescription,
    lmmsg.LossDetails AS LossDetails,
    lmmsg.LossEndDate::TIMESTAMP_NTZ AS LossEndDate,
    lmmsg.LossFundsIndicator_Bzy AS LossFundsIndicator,
    lmmsg.LossLocation AS LossLocation,
    lmmsg.LossOrEventName AS LossOrEventName,
    lmmsg.LossStartDate::TIMESTAMP_NTZ AS LossStartDate,
    lmmsg.MarketCatCode_Bzy AS MarketCatCode,
    lmmsg_cat_type.NAME AS MessageCategory,
    ecfmsg_dir_type.NAME AS MessageDirection,
    lmmsg.MessageSequence AS MessageSequence,
    ecf_claim_msg_state_type.NAME AS MessageState,
    lmmsg_type.DESCRIPTION AS MessageTypeDesc,
    lmmsg_type.NAME AS MessageType,
    -- lmmsg.MinorPrecautionaryIndicator AS MinorPrecautionaryIndicator,
    lmmsg.MovementReferenceSequence AS MovementReferenceSequence,
    lmmsg.MovementStatus_Bzy AS MovementStatus,
    -- lmmsg.MultipleResponseIndicator AS MultipleResponseIndicator,
    lmmsg.NAICCode_Bzy AS NAICCode,
    lmmsg.Narrative AS Narrative,
    -- lmmsg.NoFurtherResponseIndicator AS NoFurtherResponseIndicator,
    lmmsg.NumberOfItemsInGroup_Bzy AS NumberOfItemsInGroup,
    lmmsg.OCR AS OCR,
    imr_doc_msg_status_type.NAME AS OperationStatus,
    lmmsg.OriginTimeStamp::TIMESTAMP_NTZ AS OriginTimeStamp,
    ori_curr_type.NAME AS OriginalCurrency,
    lmmsg.OriginalMovementSeq_Bzy AS OriginalMovementSequence,
    lmmsg.OriginalPolicySectionRef_Bzy AS OriginalPolicySectionReference,
    lmmsg.OriginalSplitReferenceCSV AS OriginalSplitReferenceCSV,
    ecf_out_qual_code_type2.NAME AS OutstandingAmountQualifier,
    lmmsg.OutstandingFees_Amt AS OutstandingFeesAmount,
    out_fees_curr_type.NAME AS OutstandingFeesCurrency,
    -- lmmsg.OutstandingFeesStatus_Bzy AS OutstandingFeesStatus,
    lmmsg.OutstandingIndemnity_Amt AS OutstandingIndemnityAmount,
    out_ind_curr_type.NAME AS OutstandingIndemnityCurrency,
    lmmsg.OutstandingIndemnityStatus_Bzy AS OutstandingIndemnityStatus,
    ecf_out_qual_code_type1.NAME AS OutstandingQualifierCode,
    lmmsg.PCSCode_Bzy AS PCSCode,
    lmmsg.PackageGroup_Bzy AS PackageGroup,
    lmmsg.PaidThisTimeFees_amt AS PaidThisTimeFeesAmount,
    paid_tt_fees_curr_type.NAME AS PaidThisTimeFeesCurrency,
    lmmsg.PaidThisTimeIndemnity_amt AS PaidThisTimeIndemnityAmount,
    paid_tt_ind_curr_type.NAME AS PaidThisTimeIndemnityCurrency,
    lmmsg.PaidToDateFees_amt AS PaidToDateFeesAmount,
    paid_td_fees_curr_type.NAME AS PaidToDateFeesCurrency,
    lmmsg.PaidToDateIndemnity_amt AS PaidToDateIndemnityAmount,
    paid_td_ind_curr_type.NAME AS PaidToDateIndemnityCurrency,
    ecf_part_func_type1.NAME AS ParticipantFunction,
    lmmsg.PcsCatastropheCode AS PcsCatastropheCode,
    lmmsg.PolicyPeriodEnd_Bzy AS PolicyPeriodEnd,
    lmmsg.PolicyPeriodStart_Bzy AS PolicyPeriodStart,
    -- lmmsg.PolicyType AS PolicyType,
    -- lmmsg.Policyholder AS Policyholder,
    lmmsg.PreviousGroupID AS PreviousGroupID,
    -- lmmsg.PreviousQueueID AS PreviousQueueID,
    -- lmmsg.PreviousUserID AS PreviousUserID,
    -- lmmsg.PrivateFootnote AS PrivateFootnote,
    lmmsg.ROE_Bzy AS ROE,
    lmmsg.RXS_Bzy AS RXS,
    lmmsg.ReceiverPartyAgency AS ReceiverPartyAgency,
    lmmsg.ReceiverPartyId AS ReceiverPartyId,
    lmmsg.ReceiverPartyName AS ReceiverPartyName,
    lmmsg.ReceiverPartyRoleCd AS ReceiverPartyRoleCode,
    lmmsg.ReceiverShare AS ReceiverShare,
    lmmsg.ReferredMessageUUId AS ReferredMessageUUId,
    lmmsg.ReferredUUID AS ReferredUUID,
    lmmsg.Reprocess AS Reprocess,
    -- lmmsg.RequestToBroker1 AS RequestToBroker1,
    -- lmmsg.RequestToBroker2 AS RequestToBroker2,
    lmmsg.ResponseAcknowledgement AS ResponseAcknowledgement,
    ecf_resp_code_type.NAME AS ResponseCode,
    lmmsg.RiskDescription AS RiskDescription,
    lmmsg.RiskLocation AS RiskLocation,
    -- lmmsg.RiskReference AS RiskReference,
    ecf_part_func_type2.NAME AS Role,
    lmmsg.SCMRiskCode AS SCMRiskCode,
    lmmsg.SICurrency_Bzy AS SICurrency,
    lmmsg.SILimits_Bzy AS SILimits,
    lmmsg.SIValueInterest_Bzy AS SIValueInterest,
    lmmsg.SearchRequestUUId AS SearchRequestUUId,
    lmmsg.SearchResponseUUId AS SearchResponseUUId,
    lmmsg.SenderPartyAgency AS SenderPartyAgency,
    lmmsg.SenderPartyId AS SenderPartyId,
    lmmsg.SenderPartyName AS SenderPartyName,
    lmmsg.SenderPartyRoleCd AS SenderPartyRoleCode,
    sett_curr_type.NAME AS SettlementCurrency,
    lmmsg.SimultaneousRIPIndicator AS SimultaneousRIPIndicator,
    -- lmmsg.SimultaneousReinstatementProcd AS SimultaneousReinstatementProcessed,
    lmmsg.SimultaneousReinstatementReq AS SimultaneousReinstatementReq,
    lmmsg.SlipOrder_1_Bzy AS SlipOrder1,
    lmmsg.SlipOrder_2_Bzy AS SlipOrder2,
    lmmsg.SlipOrder_1_Bzy AS SlipOrderPercentage,
    ecf_msg_status_type.DESCRIPTION AS StatusDesc,
    ecf_msg_status_type.NAME AS Status,
    -- ecf_claim_subcat_code_type.NAME AS SubCategoryCode,
    lmmsg_subtype_type.NAME AS Subtype,
    lmmsg.Subtype AS SubtypeID,
    lmmsg.Suspended AS Suspended,
    lmmsg.SyndicateLineNumber AS SyndicateLineNumber,
    lmmsg.TR AS TR,
    target_curr_type1.NAME AS TargetCurrency1,
    target_curr_type2.NAME AS TargetCurrency2,
    target_curr_type3.NAME AS TargetCurrency3,
    lmmsg.TransactionSequence AS TransactionSequence,
    ecf_trans_status_type.NAME AS TransactionStatus,
    ecf_claim_trans_type.NAME AS TransactionType,
    ecf_triage_code_type.NAME AS TriageCategory,
    lmmsg.TrustFundCode_Bzy AS TrustFundCode,
    lmmsg.UCR AS UCR,
    lmmsg.UMR AS UMR,
    lmmsg.UUID AS UUID,
    lmmsg.UnderwritingYear AS UnderwritingYear,
    lmmsg.UpdateTime::TIMESTAMP_NTZ AS UpdateTime,
    lmmsg.UpdateUserID AS UpdateUserID,
    u_c.displaynamemda AS UpdateUserName,
    lmmsg.UploadRequestUUId AS UploadRequestUUId,
    lmmsg.UploadResponseUUId AS UploadResponseUUId,
    lmmsg.VATAmount_1_amt AS VATAmount1,
    vat_curr_type1.NAME AS VATAmount1Currency,
    lmmsg.VATAmount_2_amt AS VATAmount2,
    vat_curr_type2.NAME AS VATAmount2Currency,
    lmmsg.VATAmount_3_amt AS VATAmount3,
    vat_curr_type3.NAME AS VATAmount3Currency,
    lmmsg.ValidationErrorCode AS ValidationErrorCode,
    lmmsg.ValidationFailureReason AS ValidationFailureReason,
    lmmsg.Vessel_Bzy AS Vessel,
    lmmsg.XCSEmail_Bzy AS XCSEmail,
    lmmsg.XCSName_Bzy AS XCSName,
    -- lmmsg.XCSPhone_Bzy AS XCSPhone,
    lmmsg.XcsToAgreeIndicator AS XcsToAgreeIndicator,
    'ClaimCenter' AS SourceSystem
FROM CLAIMS_DEFAULT_020_STG.CCX_LMMESSAGE_EXT lmmsg
LEFT JOIN CLAIMS_DEFAULT_020_STG.CC_USER c_u ON c_u.ID = lmmsg.CreateUserID
LEFT JOIN CLAIMS_DEFAULT_025_MOD.vw_mod_contact c_c ON c_c.ContactID = c_u.ContactID
LEFT JOIN CLAIMS_DEFAULT_020_STG.CC_USER u_u ON u_u.ID = lmmsg.UpdateUserID
LEFT JOIN CLAIMS_DEFAULT_025_MOD.vw_mod_contact u_c ON u_c.ContactID = u_u.ContactID
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY curr_type1 ON curr_type1.ID = lmmsg.Currency_1
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY curr_type2 ON curr_type2.ID = lmmsg.Currency_2
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY curr_type3 ON curr_type3.ID = lmmsg.Currency_3
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY vat_curr_type1 ON vat_curr_type1.ID = lmmsg.VATAmount_1_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY vat_curr_type2 ON vat_curr_type2.ID = lmmsg.VATAmount_2_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY vat_curr_type3 ON vat_curr_type3.ID = lmmsg.VATAmount_3_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY paid_td_fees_curr_type ON paid_td_fees_curr_type.ID = lmmsg.PaidToDateFees_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY sett_curr_type ON sett_curr_type.ID = lmmsg.SettlementCurrency
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY imp_serv_curr_type1 ON imp_serv_curr_type1.ID = lmmsg.ImportedServicesAmount_1_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY imp_serv_curr_type2 ON imp_serv_curr_type2.ID = lmmsg.ImportedServicesAmount_2_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY imp_serv_curr_type3 ON imp_serv_curr_type3.ID = lmmsg.ImportedServicesAmount_3_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_fees_curr_type1 ON lead_res_fees_curr_type1.ID = lmmsg.LeadReserveFees_1_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_fees_curr_type2 ON lead_res_fees_curr_type2.ID = lmmsg.LeadReserveFees_2_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_fees_curr_type3 ON lead_res_fees_curr_type3.ID = lmmsg.LeadReserveFees_3_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY ori_curr_type ON ori_curr_type.ID = lmmsg.OriginalCurrency
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY paid_tt_fees_curr_type ON paid_tt_fees_curr_type.ID = lmmsg.PaidThisTimeFees_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY paid_tt_ind_curr_type ON paid_tt_ind_curr_type.ID = lmmsg.PaidThisTimeIndemnity_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_amt_curr_type1 ON lead_res_amt_curr_type1.ID = lmmsg.LeadReserveAmount_1_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_amt_curr_type2 ON lead_res_amt_curr_type2.ID = lmmsg.LeadReserveAmount_2_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY lead_res_amt_curr_type3 ON lead_res_amt_curr_type3.ID = lmmsg.LeadReserveAmount_3_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY target_curr_type1 ON target_curr_type1.ID = lmmsg.TargetCurrency_1
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY target_curr_type2 ON target_curr_type2.ID = lmmsg.TargetCurrency_2
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY target_curr_type3 ON target_curr_type3.ID = lmmsg.TargetCurrency_3
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY out_ind_curr_type ON out_ind_curr_type.ID = lmmsg.OutstandingIndemnity_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY out_fees_curr_type ON out_fees_curr_type.ID = lmmsg.OutstandingFees_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_CURRENCY paid_td_ind_curr_type ON paid_td_ind_curr_type.ID = lmmsg.PaidToDateIndemnity_cur
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_LMMESSAGE_EXT lmmsg_subtype_type ON lmmsg_subtype_type.ID = lmmsg.Subtype
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_LMMESSAGECATEGORY_EXT  lmmsg_cat_type ON lmmsg_cat_type.ID = lmmsg.MessageCategory
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFPARTICIPANTFUNC_EXT ecf_part_func_type1 ON ecf_part_func_type1.ID = lmmsg.ParticipantFunction
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFPARTICIPANTFUNC_EXT ecf_part_func_type2 ON ecf_part_func_type2.ID = lmmsg.Role
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLASSOFBUSINESS_EXT ecf_class_of_bus_type ON ecf_class_of_bus_type.ID = lmmsg.ClassOfBusiness
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_IMRDOCUMENTMSGSTATUS_EXT imr_doc_msg_status_type ON imr_doc_msg_status_type.ID = lmmsg.OperationStatus
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFSCHEME_EXT ecf_scheme_type ON ecf_scheme_type.ID = lmmsg.ClaimsScheme
-- LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLAIMSUBCATCODE_EXT ecf_claim_subcat_code_type ON ecf_claim_subcat_code_type.ID = lmmsg.SubCategoryCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFOUTQUALCODE_EXT ecf_out_qual_code_type1 ON ecf_out_qual_code_type1.ID = lmmsg.OutstandingQualifierCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFOUTQUALCODE_EXT ecf_out_qual_code_type2 ON ecf_out_qual_code_type2.ID = lmmsg.OutstandingAmountQualifier
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFTRANSACTIONSTATUS_EXT ecf_trans_status_type ON ecf_trans_status_type.ID = lmmsg.TransactionStatus
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFTRIAGECODE_EXT ecf_triage_code_type ON ecf_triage_code_type.ID = lmmsg.TriageCategory
-- LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFFILEFORMAT_EXT ecf_file_format_type ON ecf_file_format_type.ID = lmmsg.FileFormat
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFLOSSDATEQUALIFIER_EXT ecf_loss_date_qual_type ON ecf_loss_date_qual_type.ID = lmmsg.LossDateQualifier
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFBUREAUTYPE_EXT ecf_bureau_type ON ecf_bureau_type.ID = lmmsg.BureauType
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLAIMMESSAGESTATE_EXT ecf_claim_msg_state_type ON ecf_claim_msg_state_type.ID = lmmsg.MessageState
-- LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCONTRACTCONDITIONS_EXT ecf_contr_type ON ecf_contr_type.ID = lmmsg.ContractConditionsApplyInd
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ASSIGNMENTSTATUS assign_status_type ON assign_status_type.ID = lmmsg.AssignmentStatus
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLAIMTRANSTYPE_EXT ecf_claim_trans_type ON ecf_claim_trans_type.ID = lmmsg.TransactionType
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFACTIONCODE_EXT ecf_act_code_type ON ecf_act_code_type.ID = lmmsg.ActionCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCAUSEOFLOSSCODE_EXT ecf_cause_of_loss_code_type1 ON ecf_cause_of_loss_code_type1.ID = lmmsg.CauseOfLossCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCAUSEOFLOSSCODE_EXT ecf_cause_of_loss_code_type2 ON ecf_cause_of_loss_code_type2.ID = lmmsg.LossCause
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFMESSAGECLAIMSTATUS_EXT ecf_msg_claim_status_type ON ecf_msg_claim_status_type.ID = lmmsg.ClaimStatus
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ADDITIONALOSCLAIMINFO_BZY add_os_claim_info_type ON add_os_claim_info_type.ID = lmmsg.CurrentNettOsQualifier_Bzy
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFRISKCODE_EXT ecf_risk_code_type ON ecf_risk_code_type.ID = lmmsg.RiskCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFMSGDIRTYPE_EXT ecfmsg_dir_type ON ecfmsg_dir_type.ID = lmmsg.MessageDirection
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLAIMTYPECODE_EXT ecf_claim_typecode_type ON ecf_claim_typecode_type.ID = lmmsg.ClaimType
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFRESPONSECODE_EXT ecf_resp_code_type ON ecf_resp_code_type.ID = lmmsg.ResponseCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_LMMESSAGETYPE_EXT lmmsg_type ON lmmsg_type.ID = lmmsg.MessageType
-- LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFCLAIMCATEGORYCODE_EXT ecf_claim_cat_code_type ON ecf_claim_cat_code_type.ID = lmmsg.CategoryCode
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFMESSAGESTATUS_EXT ecf_msg_status_type ON ecf_msg_status_type.ID = lmmsg.Status
LEFT JOIN CLAIMS_DEFAULT_020_STG.CCTL_ECFPARTICIPATIONTYPE_EXT ecf_part_type ON ecf_part_type.ID = lmmsg.ActionParticipantType;