﻿CREATE PROC [Red].[usp_PreProcessFactClaimExposure]
AS

IF (OBJECT_ID('tempdb..#ClaimEstimateMovementKey') IS NOT NULL) DROP TABLE #ClaimEstimateMovementKey

CREATE TABLE #ClaimEstimateMovementKey
(
    FK_ClaimEstimate            bigint          NOT NULL
    ,FK_ClaimMovement           bigint          NOT NULL
    ,UseMovementForIncurred     bit             NOT NULL
    PRIMARY KEY (FK_ClaimEstimate)
)

--"Real" movement links
INSERT INTO #ClaimEstimateMovementKey
(
    FK_ClaimEstimate
    ,FK_ClaimMovement
    ,UseMovementForIncurred
)
SELECT
FK_ClaimEstimate            = ce.PK_ClaimEstimate
,FK_ClaimMovement           = ce.FK_ClaimMovement
,UseMovementForIncurred     = 1
FROM
ODS.ClaimEstimate ce
WHERE
ce.FK_ClaimMovement IS NOT NULL


--"Fake" movement links
INSERT INTO #ClaimEstimateMovementKey
(
    FK_ClaimEstimate
    ,FK_ClaimMovement
    ,UseMovementForIncurred
)
SELECT
FK_ClaimEstimate            = ce.PK_ClaimEstimate
,FK_ClaimMovement           = cm.PK_ClaimMovement
,UseMovementForIncurred     = 0
FROM
ODS.ClaimEstimate ce
INNER JOIN 
(
    SELECT 
    FK_ClaimExposure    = cm.FK_ClaimExposure
    ,PK_ClaimMovement   = MAX(cm.PK_ClaimMovement)
    FROM
    ODS.ClaimMovement cm 
    WHERE
    cm.MovementGroupSequenceId = 1 --There are 56 claims with two "1"s. Take an arbitrary one.
    GROUP BY
    cm.FK_ClaimExposure
) cm
ON
ce.FK_ClaimExposure = cm.FK_ClaimExposure
WHERE
ce.FK_ClaimMovement IS NULL
 

IF (OBJECT_ID('tempdb..#ClaimEstimateLineShareType') IS NOT NULL) DROP TABLE #ClaimEstimateLineShareType

CREATE TABLE #ClaimEstimateLineShareType
(
    FK_ClaimExposure                bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Section                     bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
    ,FK_SlipLineNumber              bigint              NULL
    ,TotalLineMultiplier            numeric(19,12)      NOT NULL
)

TRUNCATE TABLE #ClaimEstimateLineShareType

--Total order & slip order lines
INSERT INTO #ClaimEstimateLineShareType
(
    FK_ClaimExposure
   ,FK_ShareType
   ,FK_Section
   ,TotalLineMultiplier
)

SELECT
FK_ClaimExposure            = ce.PK_ClaimExposure             
,FK_ShareType               = st.PK_ShareType                               
,FK_Section                 = cms.FK_Section                                  
,TotalLineMultiplier        = CASE WHEN cm.MovementType = 'SCM' OR c.claimType IN ('Special Processing Claim') THEN 
										CASE st.ShareTypeName 
											WHEN 'Total Order' THEN cms.WeightingMultiplier / isnull(cast(case when ce.ordernumber = 0 then 100 
											                                                                   else ce.OrderNumber /*cml.LineMultiplier  */ end / 100 as numeric(19,12)), ce.WrittenIfNotSignedOrderMultiplier)
											WHEN 'Slip Order'  THEN cms.WeightingMultiplier   
										END	
							 
						      ELSE CASE WHEN c.claimType IN ('General Claim') THEN  
							                  CASE WHEN st.ShareTypeName = 'Total Order' AND sl.Facility IS NOT NULL THEN cms.WeightingMultiplier/CAST(CASE WHEN cml.LineMultiplier = 0 THEN 1
											                                                                                                               ELSE cml.LineMultiplier END /1 AS numeric(19,12))
												   WHEN	st.ShareTypeName = 'Total Order' AND sl.Facility IS NULL	then cms.WeightingMultiplier/CAST(CASE WHEN sl.WrittenIfNotSignedLineMultiplier = 0 THEN 1
											                                                                                                 ELSE sl.WrittenIfNotSignedLineMultiplier END /1 AS numeric(19,12))
																											
							                       WHEN st.ShareTypeName = 'Slip Order'  THEN cms.WeightingMultiplier
											   END
                                      
									    WHEN c.claimType IN ('Embedded Claim') THEN 
										      
										      CASE st.ShareTypeName WHEN 'Total Order' THEN cms.WeightingMultiplier  --/CAST(CASE WHEN cml.LineMultiplier = 0 THEN 1 ELSE cml.LineMultiplier END /1 AS numeric(19,12))   

									                                 WHEN 'Slip Order' THEN  cms.WeightingMultiplier 
								               END 
							      
							         END 
						    END

    
FROM ODS.ClaimExposure ce

INNER JOIN
ODS.ClaimMovement cm ON
ce.FK_LastMovement = cm.PK_ClaimMovement

INNER JOIN
ODS.Claim c ON
ce.fk_CLaim = c.Pk_claim

INNER JOIN 
(SELECT fk_claimMovement , 
        SUM(LineMultiplier) as LineMultiplier
 FROM ODS.ClaimMovementLine
 GROUP BY fk_claimMovement
 ) cml ON 
cm.PK_ClaimMovement = cml.FK_ClaimMovement

INNER JOIN 
Red.ClaimMovementSection cms ON 
cm.PK_ClaimMovement = cms.FK_ClaimMovement

INNER JOIN 
(SELECT fk_section,
        s.Facility,
        SUM(sl.WrittenIfNotSignedLineMultiplier) as WrittenIfNotSignedLineMultiplier
FROM ODS.SectionLine sl 
INNER JOIN ODS.Section s on sl.FK_Section = s.PK_Section
GROUP BY fk_section, s.Facility
) sl ON
cms.FK_Section = sl.fk_section

CROSS JOIN 
Red.ShareType st

WHERE 
st.ShareTypeName IN ('Total Order','Slip Order')


--Beazley share lines
INSERT INTO #ClaimEstimateLineShareType
(
    FK_ClaimExposure
   ,FK_ShareType
   ,FK_Section
   ,FK_Syndicate
   ,FK_SlipLineNumber
   ,TotalLineMultiplier
)
SELECT
FK_ClaimExposure            = ce.PK_ClaimExposure                  
,FK_ShareType               = st.PK_ShareType                            
,FK_Section                 = cml.FK_Section                                 
,FK_Syndicate               = cml.FK_Syndicate                           
,FK_SlipLineNumber          = cml.FK_SlipLineNumber                 
,TotalLineMultiplier    = cast(cml.LineMultiplier as NUMERIC(19,12)) --ce.WrittenIfNotSignedOrderMultiplier * cml.LineMultiplier
--,TotalLineMultiplier    = ce.WrittenIfNotSignedOrderMultiplier * cml.LineMultiplier      
FROM 
ODS.ClaimExposure ce
INNER JOIN ODS.ClaimMovement cm ON 
ce.FK_LastMovement = cm.PK_ClaimMovement
INNER JOIN ODS.ClaimMovementLine cml ON
cm.PK_ClaimMovement = cml.FK_ClaimMovement
INNER JOIN 
Red.ClaimMovementSection cms ON 
cm.PK_ClaimMovement = cms.FK_ClaimMovement
INNER JOIN 
Red.ShareType st ON 
st.ShareTypeName = 'Beazley Share'

/*Join to the movement fact table to get all the keys and the paid/outstanding/incurred amounts*/

IF (OBJECT_ID('staging.ClaimEstimateFinancials') IS NOT NULL) DROP TABLE staging.ClaimEstimateFinancials

CREATE TABLE staging.ClaimEstimateFinancials
 (
    FK_ClaimExposure                        bigint              NOT NULL
   ,FK_EntityPerspective                    bigint              NOT NULL
   ,FK_Section                              bigint              NOT NULL
   ,FK_Syndicate                            bigint              NULL
   ,FK_SlipLineNumber                       bigint              NULL
   ,FK_ShareType                            bigint              NOT NULL
   ,FK_ReportingCurrencyOverride            bigint              NOT NULL
   ,FK_YOA                                  bigint              NOT NULL            
   ,FK_SettlementCurrency                   bigint              NOT NULL
   ,FK_OriginalCurrency                     bigint              NOT NULL
   ,FK_LocalCurrency						bigint              NOT NULL
   ,FK_GQDTransactionType                   bigint              NOT NULL
   ,FK_SpecialCategoryCatastrophe           bigint              NOT NULL
   ,FK_TriFocus                             bigint              NOT NULL
   ,FK_CRMBroker                            bigint              NOT NULL
   ,FK_Policy                               bigint              NOT NULL
   ,FK_QuoteFilter                          bigint              NOT NULL
   ,FK_HiddenStatusFilter                   bigint              NOT NULL
   ,FK_ClaimEstimate                        bigint              NOT NULL
   ,FK_ClaimMovement                        bigint              NOT NULL  
   ,FK_Date                                 datetime            NOT NULL
   ,FK_UnderwritingPlatform					bigint				NOT NULL
   ,FK_InternalWrittenBinderStatus			bigint				NOT NULL
   ,FK_ServiceCompany						bigint				NOT NULL
   ,ClaimMovementPartition                  int                 NULL

   ,TotalPaid                               numeric(19,4)       NOT NULL
   ,TotalOutstanding                        numeric(19,4)       NOT NULL
   ,TotalIncurred                           numeric(19,4)       NOT NULL
   
   ,MostLikely                              numeric(19,4)       NULL
   ,Pessimistic                             numeric(19,4)       NULL
   ,ExpectedRecoveries                      numeric(19,4)       NULL
   ,BlendWeightingMultiplier                numeric(19,12)      NULL
   
   ,PrePeerMostLikely                       numeric(19,4)       NULL
   ,PrePeerPessimistic                      numeric(19,4)       NULL
   ,PrePeerBlend                            numeric(19,4)       NULL
   ,PrePeerExpectedRecoveries               numeric(19,4)       NULL
   
   ,MovementPrePeerMostLikely               numeric(19,4)       NULL    
   ,MovementPrePeerPessimistic              numeric(19,4)       NULL 
   ,MovementPrePeerBlend                    numeric(19,4)       NULL
   ,MovementPrePeerExpectedRecoveries       numeric(19,4)       NULL
   ,MovementMostLikely                      numeric(19,4)       NULL       
   ,MovementPessimistic                     numeric(19,4)       NULL 
   ,MovementExpectedRecoveries              numeric(19,4)       NULL 
      
   ,SpecialPurposeSyndicateApplies          bit                 NULL
   ,ExposureStatusCode                      varchar(255)        NULL
   ,DataSetSource                           int                 NULL -- This column is only used for reconcilation and testing.
   
   ,BlendAmount								numeric(20,4)       NULL
   ,AuditModifyDateTime                     datetime2(7)        NULL
   ,AuditCreateDateTime                     datetime2(7)        DEFAULT (GETDATE()) NOT NULL
   ,AuditModifyDetails                      nvarchar(255)       NULL
)

CREATE NONCLUSTERED INDEX IX_#ClaimEstimateMovementKey ON [#ClaimEstimateMovementKey] 
(
    FK_ClaimMovement
)
INCLUDE 
(
    FK_ClaimEstimate
    ,UseMovementForIncurred
)

CREATE NONCLUSTERED INDEX IX_#ClaimEstimateLineShareType ON [#ClaimEstimateLineShareType] 
(
    FK_ClaimExposure
    ,FK_ShareType
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
)
INCLUDE 
(
    TotalLineMultiplier
)

INSERT INTO  staging.ClaimEstimateFinancials
(
    FK_ClaimExposure
   ,FK_EntityPerspective
   ,FK_Section
   ,FK_Syndicate
   ,FK_SlipLineNumber
   ,FK_ShareType
   ,FK_ReportingCurrencyOverride
   ,FK_YOA                              
   ,FK_SettlementCurrency
   ,FK_OriginalCurrency
   ,FK_LocalCurrency
   ,FK_GQDTransactionType
   ,FK_SpecialCategoryCatastrophe
   ,FK_TriFocus  
   ,FK_CRMBroker
   ,FK_Policy
   ,FK_QuoteFilter    
   ,FK_HiddenStatusFilter 
   ,FK_ClaimEstimate
   ,FK_ClaimMovement
   ,FK_Date
   ,FK_UnderwritingPlatform
   ,FK_InternalWrittenBinderStatus
   ,FK_ServiceCompany
   ,TotalPaid
   ,TotalOutstanding
   ,TotalIncurred  
   ,MostLikely         
   ,Pessimistic        
   ,ExpectedRecoveries 
   ,BlendWeightingMultiplier
   ,SpecialPurposeSyndicateApplies 
   ,ExposureStatusCode
   ,DataSetSource
   ,BlendAmount
)
SELECT
 FK_ClaimExposure               = claimes.FK_ClaimExposure
,FK_EntityPerspective           = fcm.FK_EntityPerspective                      
,FK_Section                     = fcm.FK_Section                             
,FK_Syndicate                   = fcm.FK_Syndicate                      
,FK_SlipLineNumber              = fcm.FK_SlipLineNumber            
,FK_ShareType                   = fcm.FK_ShareType                      
,FK_ReportingCurrencyOverride   = fcm.FK_ReportingCurrencyOverride    
,FK_YOA                         = fcm.FK_YOA                             
,FK_SettlementCurrency          = fcm.FK_SettlementCurrency             
,FK_OriginalCurrency            = fcm.FK_OriginalCurrency             
,FK_LocalCurrency				= ISNULL(fcm.FK_LocalCurrency,0)
,FK_GQDTransactionType          = fcm.FK_GQDTransactionType             
,FK_SpecialCategoryCatastrophe  = fcm.FK_SpecialCategoryCatastrophe     
,FK_TriFocus                    = fcm.FK_TriFocus                  
,FK_CRMBroker                   = fcm.FK_CRMBroker
,FK_Policy                      = fcm.FK_Policy                            
,FK_QuoteFilter                 = fcm.FK_QuoteFilter
,FK_HiddenStatusFilter          = fcm.FK_HiddenStatusFilter    
,FK_ClaimEstimate               = claimes.PK_ClaimEstimate
,FK_ClaimMovement               = fcm.FK_ClaimMovement
,FK_Date                        = claimes.FK_CreateDate
,FK_UnderwritingPlatform		= fcm.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= fcm.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= fcm.FK_ServiceCompany
,TotalPaid                      = CASE WHEN keys.UseMovementForIncurred = 1 THEN fcm.ToDateTotalPaid ELSE 0 END                    
,TotalOutstanding               = CASE WHEN keys.UseMovementForIncurred = 1 THEN fcm.ToDateTotalOutstanding ELSE 0 END       
,TotalIncurred                  = CASE WHEN keys.UseMovementForIncurred = 1 THEN fcm.ToDateTotalIncurred ELSE 0 END
,MostLikely                     = CASE 
                                    WHEN rco.ReportingCurrencyOverrideName = 'Original Currency' OR oc.CurrencyCode = sc.CurrencyCode 
                                    THEN claimes.MostLikelyOriginalCCY 
                                  END       
                                    * claimline.TotalLineMultiplier  * cep.PerspectiveMultiplier
,Pessimistic                    = CASE 
                                    WHEN rco.ReportingCurrencyOverrideName = 'Original Currency' OR oc.CurrencyCode = sc.CurrencyCode 
                                    THEN claimes.PessimisticOriginalCCY 
                                  END       
                                    * claimline.TotalLineMultiplier  * cep.PerspectiveMultiplier   
,ExpectedRecoveries             = CASE 
                                    WHEN rco.ReportingCurrencyOverrideName = 'Original Currency' OR oc.CurrencyCode = sc.CurrencyCode 
                                    THEN claimes.ExpectedRecoveriesOriginalCCY 
                                  END       
                                    * claimline.TotalLineMultiplier  * cep.PerspectiveMultiplier
,BlendWeightingMultiplier       = claimes.BlendWeightingMultiplier

,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,ExposureStatusCode             = claimes.ExposureStatusCode      
,DataSetSource                  = CASE WHEN keys.UseMovementForIncurred = 1 THEN 1 ELSE 2 END
,BlendAmount					= CASE 
                                    WHEN rco.ReportingCurrencyOverrideName = 'Original Currency' OR oc.CurrencyCode = sc.CurrencyCode 
                                    THEN claimes.BlendAmtOriginalCCY
                                  END       
                                    * claimline.TotalLineMultiplier  * cep.PerspectiveMultiplier
FROM
ODS.ClaimEstimate claimes

INNER JOIN	#ClaimEstimateLineShareType claimline 
		ON  claimes.FK_ClaimExposure  = claimline.FK_ClaimExposure

INNER JOIN	#ClaimEstimateMovementKey keys 
		ON  claimes.PK_ClaimEstimate = keys.FK_ClaimEstimate

INNER JOIN	Red.FactClaimMovement fcm 
		ON	keys.FK_ClaimMovement               = fcm.FK_ClaimMovement
			AND claimline.FK_Section            = fcm.FK_Section
			AND claimline.FK_ShareType          = fcm.FK_ShareType
			AND (claimline.FK_SlipLineNumber    = fcm.FK_SlipLineNumber OR (claimline.FK_SlipLineNumber IS NULL AND fcm.FK_SlipLineNumber IS NULL))
			AND (claimline.FK_Syndicate         = fcm.FK_Syndicate OR (claimline.FK_Syndicate IS NULL AND fcm.FK_Syndicate IS NULL))

INNER JOIN ODS.ClaimExposureEntityPerspective cep 
		ON	fcm.FK_ClaimExposure            = cep.FK_ClaimExposure
			AND fcm.FK_EntityPerspective    = cep.FK_EntityPerspective

INNER JOIN	ODS.Section s 
		ON fcm.FK_Section = s.PK_Section

INNER JOIN	Red.ReportingCurrencyOverride rco 
		ON	fcm.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride

INNER JOIN	ODS.SettlementCurrency sc 
		ON	fcm.FK_SettlementCurrency = sc.PK_SettlementCurrency

INNER JOIN	ODS.OriginalCurrency oc 
		ON	fcm.FK_OriginalCurrency = oc.PK_OriginalCurrency

CREATE NONCLUSTERED INDEX IX_#ClaimEstimateFinancials ON  staging.ClaimEstimateFinancials 
(
    FK_ClaimExposure
    ,FK_EntityPerspective
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_ClaimEstimate
)
INCLUDE 
(
    MostLikely
    ,Pessimistic
    ,ExpectedRecoveries
    ,BlendWeightingMultiplier
	,BlendAmount
)


TRUNCATE TABLE Red.FactClaimExposure
--**Disable Constratint --
ALTER TABLE Red.FactClaimExposure NOCHECK CONSTRAINT ALL;
--**

IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		   WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactClaimExposure' AND name = 'IK_FactClaimExposure')
BEGIN
	DROP INDEX IK_FactClaimExposure ON Red.FactClaimExposure
END

EXEC utility.usp_PartitionTableOnScheme 
 	 @SchemaName		= 'Red'  
	,@TableName			= 'FactClaimExposure' 
	,@PartitionScheme	= 'PS_FCE';

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'ClaimEstimateFinancials';

GO
