﻿CREATE PROCEDURE [Red].[usp_LoadFactRiskClass]
AS


/***************************************************************************************/
/*                           Load fact RiskClass                                           */
/***************************************************************************************/

ALTER TABLE Red.FactRiskClass NOCHECK CONSTRAINT ALL

TRUNCATE TABLE Red.FactRiskClass

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactRiskClass' AND CONSTRAINT_NAME = 'UQ_FactRiskClass_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactRiskClass
    DROP CONSTRAINT UQ_FactRiskClass_LogicalKey
END


INSERT INTO Red.FactRiskClass WITH (TABLOCK)
 (	FK_Section
	,FK_Syndicate
	,FK_ShareType
	,FK_ReportingCurrencyOverride
	,FK_Date
	,FK_YOA
	,FK_SettlementCurrency
	,FK_OriginalCurrency
	,FK_LocalCurrency
	,FK_TriFocus
	,FK_Policy
	,FK_HiddenStatusFilter
	,FK_QuoteFilter
	,FK_CRMBroker
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
	,FK_RiskClass
	,FK_EntityPerspective
	,FK_AcquisitionCostBasis
	,RiskClassWEP
	,RiskClassWEPExcLBS
	,RiskPercentage
	)
SELECT 
		 FK_Section
		,FK_Syndicate
		,FK_ShareType
		,FK_ReportingCurrencyOverride
		,FK_Date
		,FK_YOA
		,FK_SettlementCurrency
		,FK_OriginalCurrency
		,FK_LocalCurrency
		,FK_TriFocus
		,FK_Policy
		,FK_HiddenStatusFilter
		,FK_QuoteFilter
		,FK_CRMBroker
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,FK_ServiceCompany
		,FK_RiskClass
		,FK_EntityPerspective
		,FK_AcquisitionCostBasis
		,RiskClassWEP	           = RiskPercentage * SUM(WEPIncludingReinstatementPremium) OVER (PARTITION BY FK_Section
																											,FK_ShareType
																											,FK_ReportingCurrencyOverride
																											,FK_Date
																											,FK_YOA
																											,FK_SettlementCurrency
																											,FK_OriginalCurrency
																											,FK_LocalCurrency
																											,FK_TriFocus
																											,FK_Policy
																											,FK_HiddenStatusFilter
																											,FK_QuoteFilter
																											,FK_CRMBroker
																											,FK_UnderwritingPlatform
																											,FK_InternalWrittenBinderStatus
																											,FK_ServiceCompany
																											,FK_RiskClass
																											,FK_EntityPerspective
																											,FK_AcquisitionCostBasis) 
		,RiskClassWEPExcLBS		= RiskPercentage * SUM(WrittenOrEstimatedPremiumExcLBSfeeDeduction) OVER (PARTITION BY FK_Section
																											,FK_ShareType
																											,FK_ReportingCurrencyOverride
																											,FK_Date
																											,FK_YOA
																											,FK_SettlementCurrency
																											,FK_OriginalCurrency
																											,FK_LocalCurrency
																											,FK_TriFocus
																											,FK_Policy
																											,FK_HiddenStatusFilter
																											,FK_QuoteFilter
																											,FK_CRMBroker
																											,FK_UnderwritingPlatform
																											,FK_InternalWrittenBinderStatus
																											,FK_ServiceCompany
																											,FK_RiskClass
																											,FK_EntityPerspective
																											,FK_AcquisitionCostBasis) 
		,RiskPercentage
FROM (	
SELECT   FK_Section						= sr.FK_Section
		,FK_Syndicate					= fwep.FK_Syndicate
		,FK_ShareType					= fwep.FK_ShareType
		,FK_ReportingCurrencyOverride	= fwep.FK_ReportingCurrencyOverride
		,FK_Date						= fwep.FK_Date
		,FK_YOA							= fwep.FK_YOA
		,FK_SettlementCurrency			= fwep.FK_SettlementCurrency
		,FK_OriginalCurrency			= fwep.FK_OriginalCurrency
		,FK_LocalCurrency				= fwep.FK_LocalCurrency
		,FK_TriFocus					= fwep.FK_TriFocus
		,FK_Policy						= fwep.FK_Policy
		,FK_HiddenStatusFilter			= fwep.FK_HiddenStatusFilter
		,FK_QuoteFilter					= fwep.FK_QuoteFilter
		,FK_CRMBroker					= fwep.FK_CRMBroker
		,FK_UnderwritingPlatform		= fwep.FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus = fwep.FK_InternalWrittenBinderStatus
		,FK_ServiceCompany				= fwep.FK_ServiceCompany
		,FK_RiskClass					= sr.FK_RiskClass
		,FK_EntityPerspective			= fwep.FK_EntityPerspective
		,FK_AcquisitionCostBasis		= fwep.FK_AcquisitionCostBasis
		,WEPIncludingReinstatementPremium	= fwep.WEPIncludingReinstatementPremium
		,WrittenOrEstimatedPremiumExcLBSfeeDeduction = fwep.WrittenOrEstimatedPremiumExcLBSfeeDeduction										
		,RiskPercentage					= CASE WHEN fwep.FK_ShareType <> 1 THEN  sr.RiskPercentage 
											   ELSE (fwep.WEPIncludingReinstatementPremium * sr.RiskPercentage)/NULLIF(SUM(fwep.WEPIncludingReinstatementPremium) OVER (PARTITION BY fwep.FK_Section
																																											,fwep.FK_ShareType
																																											,fwep.FK_ReportingCurrencyOverride
																																											,fwep.FK_Date
																																											,fwep.FK_YOA
																																											,fwep.FK_SettlementCurrency
																																											,fwep.FK_OriginalCurrency
																																											,fwep.FK_LocalCurrency
																																											,fwep.FK_TriFocus
																																											,fwep.FK_Policy
																																											,fwep.FK_HiddenStatusFilter
																																											,fwep.FK_QuoteFilter
																																											,fwep.FK_CRMBroker
																																											,fwep.FK_UnderwritingPlatform
																																											,fwep.FK_InternalWrittenBinderStatus
																																											,fwep.FK_ServiceCompany
																																											,sr.FK_RiskClass
																																											,fwep.FK_EntityPerspective
																																											,fwep.FK_AcquisitionCostBasis)  ,0)
										END
FROM ODS.SectionRiskClass sr WITH(NOLOCK)	
INNER JOIN 	 Red.FactWrittenEstimatedPremium fwep WITH(NOLOCK)	
ON sr.FK_Section = fwep.FK_Section
				)x


IF NOT EXISTS
(
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactRiskClass' AND CONSTRAINT_NAME = 'UQ_FactRiskClass_LogicalKey'     
)
BEGIN
    ALTER TABLE Red.FactRiskClass
    ADD CONSTRAINT UQ_FactRiskClass_LogicalKey
    UNIQUE
        (
             FK_Section
			,FK_Syndicate
			,FK_ShareType
			,FK_ReportingCurrencyOverride
			,FK_Date
			,FK_YOA
			,FK_SettlementCurrency
			,FK_OriginalCurrency
			,FK_LocalCurrency
			,FK_TriFocus
			,FK_Policy
			,FK_HiddenStatusFilter
			,FK_QuoteFilter
			,FK_CRMBroker
			,FK_UnderwritingPlatform
			,FK_InternalWrittenBinderStatus
			,FK_ServiceCompany
			,FK_RiskClass
			,FK_EntityPerspective
			,FK_AcquisitionCostBasis
        )
END



ALTER TABLE Red.FactRiskClass CHECK CONSTRAINT ALL;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactRiskClass';