﻿CREATE PROC [Red].[usp_LoadFactClaimIncurredBand]
AS

SET NOCOUNT ON

DROP TABLE IF EXISTS #fcm
DROP TABLE IF EXISTS #fcm_grouped

SELECT
	FK_Section
	,FK_ClaimExposure
	,FK_YOA
	,MovementTotalIncurred
	,FK_EntityPerspective
	,FK_ReportingCurrencyOverride
	,FK_ShareType
	,FK_SettlementCurrency
	INTO #fcm
FROM Red.FactClaimMovement
WHERE FK_ReportingCurrencyOverride = 2 --SettlementCurrency
AND FK_ShareType = 1 --- BeazleyShare

SELECT TOP 100000000000
			 FK_Section							= cm.FK_Section
			,FK_ClaimExposure					= cm.FK_ClaimExposure
			,FK_ShareType                       = MAX(cm.FK_ShareType) -- BeazleyShare --st.PK_ShareType
			,FK_AcquisitionCostBasis            = acb.PK_AcquisitionCostBasis
			,FK_EntityPerspective               = cm.FK_EntityPerspective
	--		,FK_SettlementCurrency				= cm.FK_SettlementCurrency
			,FK_YOA								= cm.FK_YOA
			,FK_ReportingCurrency				= scr.FK_ReportingCurrency
			,FK_ReportingCurrencyOverride		= MAX(cm.FK_ReportingCurrencyOverride) --'Reporting Currency' --rco2.PK_ReportingCurrencyOverride
			,FK_RateType						= scr.FK_RateType
			,TotalIncurred						= ISNULL(SUM(cm.MovementTotalIncurred), 0)
			,TotalIncurredReporting				= ISNULL(SUM(cm.MovementTotalIncurred * scr.ExchangeRate), 0)
			INTO #fcm_grouped
		FROM #fcm cm			

			CROSS JOIN
				(
					SELECT 
						PK_AcquisitionCostBasis
					FROM Red.AcquisitionCostBasis
					WHERE AcquisitionCostBasisName IN ('Gross Of Acquisition Cost', 'Net Of External Acquisition Cost')
				) acb

			INNER JOIN Red.FactSettlementCurrencyRate scr 
			ON cm.FK_SettlementCurrency = scr.FK_SettlementCurrency
			AND cm.FK_YOA = scr.FK_YOA

			INNER JOIN
						(
							SELECT
								PK_SettlementCurrency
								,CurrencyCode
							FROM ODS.SettlementCurrency 
							WHERE CurrencyCode IN ('USD', 'GBP')
						) rc 
			ON 	scr.FK_ReportingCurrency = rc.PK_SettlementCurrency
		
		GROUP BY
 			cm.FK_Section
			,cm.FK_ClaimExposure
			,acb.PK_AcquisitionCostBasis
			,cm.FK_EntityPerspective
			,cm.FK_YOA
			,scr.FK_ReportingCurrency
			,scr.FK_RateType

---** DISABLE CONSTRAINTS
ALTER TABLE Red.FactClaimIncurredBand NOCHECK CONSTRAINT ALL;
--**

MERGE [Red].[FactClaimIncurredBand] AS TARGET
USING 
(SELECT 
	 FK_Section								= t.FK_Section
    ,FK_ClaimExposure						= t.FK_ClaimExposure
    ,FK_ShareType                           = t.FK_ShareType
    ,FK_AcquisitionCostBasis                = t.FK_AcquisitionCostBasis
    ,FK_EntityPerspective                   = t.FK_EntityPerspective
	,FK_YOA									= t.FK_YOA
	,FK_ReportingCurrency					= t.FK_ReportingCurrency
	,FK_ReportingCurrencyOverride			= t.FK_ReportingCurrencyOverride
	,FK_RateType							= t.FK_RateType
	,FK_TriFocus							= s.FK_TriFocus
	,FK_Policy								= s.FK_Policy
	,FK_HiddenStatusFilter					= s.FK_HiddenStatusFilter
	,FK_QuoteFilter							= s.FK_QuoteFilter
	,FK_ClaimIncurredBand					= c.PK_ClaimIncurredBand
	,FK_UnderwritingPlatform				= s.FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus			= s.FK_InternalWrittenBinderStatus
	,FK_ServiceCompany						= s.FK_ServiceCompany
	,TotalClaimIncurred						= t.TotalIncurredReporting
FROM #fcm_grouped AS t

	INNER JOIN	ODS.Section s 
	ON t.FK_Section = s.PK_Section

	INNER JOIN 	ODS.ClaimIncurredBand c 
	ON t.TotalIncurredReporting > c.BandMin
	AND t.TotalIncurredReporting <= c.BandMax
	) AS SOURCE
	ON  TARGET.FK_AcquisitionCostBasis			= SOURCE.FK_AcquisitionCostBasis
	AND TARGET.FK_ClaimExposure					= SOURCE.FK_ClaimExposure
	AND TARGET.FK_EntityPerspective				= SOURCE.FK_EntityPerspective
	AND TARGET.FK_RateType 						= SOURCE.FK_RateType
	AND TARGET.FK_ReportingCurrency 		    = SOURCE.FK_ReportingCurrency
	AND TARGET.FK_ReportingCurrencyOverride     = SOURCE.FK_ReportingCurrencyOverride
	AND TARGET.FK_ShareType 				    = SOURCE.FK_ShareType
	AND TARGET.FK_Section 				        = SOURCE.FK_Section
	AND TARGET.FK_YOA						    = SOURCE.FK_YOA
	AND TARGET.FK_ClaimIncurredBand 		    = SOURCE.FK_ClaimIncurredBand

	WHEN MATCHED THEN
UPDATE SET
	TARGET.FK_TriFocus						  = SOURCE.FK_TriFocus						
	,TARGET.FK_Policy						  = SOURCE.FK_Policy						
	,TARGET.FK_HiddenStatusFilter			  = SOURCE.FK_HiddenStatusFilter			
	,TARGET.FK_QuoteFilter					  = SOURCE.FK_QuoteFilter					
	,TARGET.FK_UnderwritingPlatform			  = SOURCE.FK_UnderwritingPlatform			
	,TARGET.FK_InternalWrittenBinderStatus	  = SOURCE.FK_InternalWrittenBinderStatus	
	,TARGET.FK_ServiceCompany				  = SOURCE.FK_ServiceCompany				
	,TARGET.TotalClaimIncurred				  = SOURCE.TotalClaimIncurred		
	,TARGET.AuditModifyDateTime		          = GETDATE()						
    ,TARGET.AuditModifyDetails		          = 'Merge in Red.usp_LoadFactClaimIncurredBand proc'
	WHEN NOT MATCHED BY TARGET THEN
INSERT
(
FK_Section						
,FK_ClaimExposure				
,FK_ShareType                   
,FK_AcquisitionCostBasis        
,FK_EntityPerspective           
,FK_YOA							
,FK_ReportingCurrency			
,FK_ReportingCurrencyOverride	
,FK_RateType					
,FK_TriFocus					
,FK_Policy						
,FK_HiddenStatusFilter			
,FK_QuoteFilter					
,FK_ClaimIncurredBand			
,FK_UnderwritingPlatform		
,FK_InternalWrittenBinderStatus	
,FK_ServiceCompany				
,TotalClaimIncurred		
,AuditCreateDateTime
,AuditModifyDetails
)
VALUES (
SOURCE.FK_Section						
,SOURCE.FK_ClaimExposure				
,SOURCE.FK_ShareType                   
,SOURCE.FK_AcquisitionCostBasis        
,SOURCE.FK_EntityPerspective           
,SOURCE.FK_YOA							
,SOURCE.FK_ReportingCurrency			
,SOURCE.FK_ReportingCurrencyOverride	
,SOURCE.FK_RateType					
,SOURCE.FK_TriFocus					
,SOURCE.FK_Policy						
,SOURCE.FK_HiddenStatusFilter			
,SOURCE.FK_QuoteFilter					
,SOURCE.FK_ClaimIncurredBand			
,SOURCE.FK_UnderwritingPlatform		
,SOURCE.FK_InternalWrittenBinderStatus	
,SOURCE.FK_ServiceCompany				
,SOURCE.TotalClaimIncurred	
,GETDATE()
,'New add in Red.usp_LoadFactClaimIncurredBand proc'	)		
WHEN NOT MATCHED BY SOURCE THEN DELETE;

---** ENABLE CONSTRAINTS
ALTER TABLE Red.FactClaimIncurredBand CHECK CONSTRAINT ALL;
--**

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactClaimIncurredBand';