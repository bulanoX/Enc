﻿

CREATE PROC [Red].[usp_LoadFactSettlementCurrencyRate]
AS

SET NOCOUNT ON

DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
FROM		Red.FactSettlementCurrencyRate

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


DELETE		fscr
FROM		Red.FactSettlementCurrencyRate fscr
LEFT JOIN	ODS.YOA y
		ON	fscr.FK_YOA = y.PK_YOA
WHERE		y.PK_YOA IS NULL

IF OBJECT_ID('tempdb..#FactSettlementCurrencyRate') IS NOT NULL
DROP TABLE #FactSettlementCurrencyRate

CREATE TABLE #FactSettlementCurrencyRate
		(
		 FK_YOA						BIGINT           NOT NULL
		,FK_RateType				BIGINT           NOT NULL
		,FK_SettlementCurrency		BIGINT           NOT NULL
		,FK_ReportingCurrency		BIGINT           NOT NULL
		,ExchangeRate				DECIMAL (38,12)	 NOT NULL
		)

/*Standard rates*/
INSERT INTO #FactSettlementCurrencyRate
 (
     FK_YOA
    ,FK_RateType
    ,FK_SettlementCurrency
    ,FK_ReportingCurrency
    ,ExchangeRate
 )
 
SELECT
     FK_YOA = y.PK_YOA                                             
    ,FK_RateType = rt.PK_RateType                                 
    ,FK_SettlementCurrency = sc_from.PK_SettlementCurrency        
    ,FK_ReportingCurrency = sc_to.PK_SettlementCurrency           
    ,ExchangeRate = ISNULL(ISNULL(cr_to.ExchangeRate, cry_to.ExchangeRate)
                    /ISNULL(cr_from.ExchangeRate, cry_from.ExchangeRate),0)                                                           
FROM ODS.YOA y

CROSS JOIN ODS.SettlementCurrency sc_from

CROSS JOIN ODS.SettlementCurrency sc_to

CROSS JOIN Red.RateType rt 

LEFT OUTER JOIN Utility.CurrencyRate cr_from 
ON  sc_from.CurrencyCode = cr_from.Currency
AND rt.RateType          = cr_from.RateType

LEFT OUTER JOIN Utility.CurrencyRateYOA cry_from 
ON  sc_from.CurrencyCode  = cry_from.Currency
AND rt.RateType           = cry_from.RateType
AND y.PK_YOA              = cry_from.YOA

LEFT OUTER JOIN Utility.CurrencyRate cr_to 
ON  sc_to.CurrencyCode = cr_to.Currency
AND rt.RateType        = cr_to.RateType

LEFT OUTER JOIN Utility.CurrencyRateYOA cry_to 
ON  sc_to.CurrencyCode = cry_to.Currency
AND rt.RateType        = cry_to.RateType
AND y.PK_YOA           = cry_to.YOA

WHERE
rt.PIMYear IS NULL
AND (y.AuditModifyDateTime > @LastAuditDate OR y.AuditCreateDateTime > @LastAuditDate)

/*PIM for all years @x year's PIM rate (last 2 years)*/
UPDATE Red.RateType SET
RateType    = 'All years ' + CAST(y.PIMYear AS varchar(4)) + ' PIM'
,PIMYear    = y.PIMYear
FROM
Red.RateType rt
INNER JOIN
(
    SELECT
    PIMYear         = x.YOA
    ,SequenceId     = ROW_NUMBER() OVER (ORDER BY x.YOA DESC)
    FROM
    (SELECT DISTINCT YOA FROM Utility.CurrencyRateYOA) x
) y ON
rt.PIMPlaceholder = y.SequenceId

INSERT INTO #FactSettlementCurrencyRate
(
 FK_YOA
,FK_RateType
,FK_SettlementCurrency
,FK_ReportingCurrency
,ExchangeRate
)
SELECT
FK_YOA                      = yoa.PK_YOA
,FK_RateType                = rt_pimyear.PK_RateType
,FK_SettlementCurrency      = fscr.FK_SettlementCurrency
,FK_ReportingCurrency       = fscr.FK_ReportingCurrency
,ExchangeRate               = fscr.ExchangeRate
FROM
#FactSettlementCurrencyRate fscr
INNER JOIN
Red.RateType rt_pim ON
fscr.FK_RateType = rt_pim.PK_RateType
AND rt_pim.RateType = 'PIM'
INNER JOIN
Red.RateType rt_pimyear ON
rt_pimyear.PIMYear = fscr.FK_YOA
CROSS JOIN
ODS.YOA yoa
WHERE (yoa.AuditModifyDateTime > @LastAuditDate OR yoa.AuditCreateDateTime > @LastAuditDate)

;MERGE	Red.FactSettlementCurrencyRate		AS TARGET
		    USING	#FactSettlementCurrencyRate	AS SOURCE
		    ON		TARGET.FK_SettlementCurrency	= SOURCE.FK_SettlementCurrency
                AND TARGET.FK_ReportingCurrency		= SOURCE.FK_ReportingCurrency
                AND TARGET.FK_RateType				= SOURCE.FK_RateType
                AND TARGET.FK_YOA					= SOURCE.FK_YOA

    WHEN	MATCHED THEN
		    UPDATE	
		    SET	 TARGET.ExchangeRate			    = SOURCE.ExchangeRate
			    ,TARGET.AuditModifyDateTime			= GETDATE()						
			    ,TARGET.AuditModifyDetails	        = 'Merge in Red.usp_LoadFactSettlementCurrencyRate' 

    WHEN	NOT MATCHED BY TARGET THEN
		    INSERT
		    (
		        FK_SettlementCurrency
               ,FK_ReportingCurrency
               ,FK_RateType
               ,FK_YOA
               ,ExchangeRate
               ,AuditCreateDateTime
               ,AuditModifyDetails
		    )
			    VALUES
		    (
			    SOURCE.FK_SettlementCurrency
		        ,SOURCE.FK_ReportingCurrency
                ,SOURCE.FK_RateType
                ,SOURCE.FK_YOA
                ,SOURCE.ExchangeRate
			    ,GETDATE()
			    ,'New add in Red.usp_LoadFactSettlementCurrencyRate'	
		    )
    ;


    EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactSettlementCurrencyRate';