﻿
CREATE PROC Red.usp_PreProcessFactWrittenPremium

AS

/***************************************************************************************/
/*                        Acquisition Cost (deductions)                                */
/***************************************************************************************/
IF (OBJECT_ID('staging.SectionAcquisitionCostBasis') IS NOT NULL) DROP TABLE staging.SectionAcquisitionCostBasis

CREATE TABLE staging.SectionAcquisitionCostBasis
 (
    FK_Section                                    bigint              NOT NULL
    ,FK_AcquisitionCostBasis                      bigint              NOT NULL
    ,FK_EntityPerspective                         bigint              NOT NULL    
    ,AcquisitionCostMultiplier                    numeric(19,12)      NOT NULL
    ,OriginalEPITotalAcquisitionCostMultiplier    numeric(19,12)      NOT NULL
    ,AuditModifyDateTime                          datetime2(7)        NULL
    ,AuditCreateDateTime                          datetime2(7)        DEFAULT (GETDATE()) NOT NULL
    ,AuditModifyDetails                           nvarchar(255)       NULL
 )

TRUNCATE TABLE staging.SectionAcquisitionCostBasis

INSERT INTO staging.SectionAcquisitionCostBasis WITH (TABLOCK)
(
    FK_Section
   ,FK_AcquisitionCostBasis
   ,FK_EntityPerspective
   ,AcquisitionCostMultiplier
   ,OriginalEPITotalAcquisitionCostMultiplier
)

SELECT
     FK_Section                                  = s.PK_Section                             
    ,FK_AcquisitionCostBasis                     = acb.PK_AcquisitionCostBasis
    ,FK_EntityPerspective                        = sep.FK_EntityPerspective     
    ,AcquisitionCostMultiplier                   = CASE acb.AcquisitionCostBasisName 
                                                   WHEN 'Gross Of Acquisition Cost' THEN 1
                                                   WHEN 'Net Of All Acquisition Cost'   THEN    (1 - s.ExternalAcquisitionCostMultiplier - sep.InternalAcquisitionCostMultiplier)
                                                   WHEN 'Net Of External Acquisition Cost' THEN  1 - s.ExternalAcquisitionCostMultiplier
                                                   END
    -- For Unirisx Marine Oslo the users manually update the OriginalNetEPI, the below logic allows us to display both gross and net OriginalEPI amounts as they are on the UI screen
    ,OriginalEPITotalAcquisitionCostMultiplier   = CASE acb.AcquisitionCostBasisName 
                                                   WHEN 'Gross Of Acquisition Cost' THEN 1
                                                   WHEN 'Net Of All Acquisition Cost'   THEN    (1 - s.OriginalEPITotalAcquisitionCostMultiplier - sep.InternalAcquisitionCostMultiplier)
                                                   WHEN 'Net Of External Acquisition Cost' THEN  1 - s.OriginalEPITotalAcquisitionCostMultiplier
                                                   END    
FROM 
ODS.Section s
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
CROSS JOIN
Red.AcquisitionCostBasis acb

CREATE INDEX A ON [Staging].[SectionAcquisitionCostBasis]	([FK_Section], [FK_AcquisitionCostBasis], [FK_EntityPerspective]) INCLUDE	([AcquisitionCostMultiplier], [OriginalEPITotalAcquisitionCostMultiplier])

/***************************************************************************************/
/*                        Share type                                                   */
/***************************************************************************************/
IF (OBJECT_ID('staging.SectionShareType') IS NOT NULL) DROP TABLE staging.SectionShareType

CREATE TABLE  staging.SectionShareType
(
    FK_Section                      bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
    ,TotalLineMultiplier            numeric(19,12)      NULL
    ,AuditModifyDateTime            datetime2(7)        NULL
    ,AuditCreateDateTime            datetime2(7)        DEFAULT (GETDATE()) NOT NULL
    ,AuditModifyDetails             nvarchar(255)       NULL
)

TRUNCATE TABLE  staging.SectionShareType

INSERT INTO  staging.SectionShareType
(
     FK_Section
    ,FK_ShareType
    ,FK_Syndicate
    ,TotalLineMultiplier
)

SELECT
FK_Section              = s.PK_Section     
,FK_ShareType           = st.PK_ShareType
,FK_Syndicate           = NULL                                      
,TotalLineMultiplier    = CASE st.ShareTypeName 
                            WHEN 'Total Order' THEN 1
                            WHEN 'Slip Order'  THEN s.WrittenIfNotSignedOrderMultiplier
                          END
FROM 
ODS.Section s
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName IN ('Total Order','Slip Order')
UNION ALL
SELECT
FK_Section             = sl.FK_Section                       
,FK_ShareType          = st.PK_ShareType                 
,FK_Syndicate          = sl.FK_Syndicate 
,TotalLineMultiplier   = sl.WrittenIfNotSignedLineMultiplier 
                        * s.WrittenIfNotSignedOrderMultiplier 
                        * CASE 
                            WHEN s.IsSigned = 0 
                            THEN s.EstimatedSigningMultiplier 
                            ELSE 1
                          END
FROM 
ODS.SectionLine sl
INNER JOIN
ODS.Section s ON
sl.FK_Section = s.PK_Section
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName = 'Beazley Share'


/***************************************************************************************/
/*                Section premium calculations in original currency                     */
/***************************************************************************************/
IF (OBJECT_ID('staging.SectionPremiumCalculations') IS NOT NULL) DROP TABLE staging.SectionPremiumCalculations

CREATE TABLE staging.SectionPremiumCalculations
 (
    FK_Section                          bigint              NOT NULL
    ,OriginalEPI                        numeric(38,4)       NULL
    ,MinimumPremium                     numeric(38,4)       NULL
    ,DepositPremium                     numeric(38,4)       NULL
    ,RateOnLinePremiumEntered           numeric(38,4)       NULL
    ,AdjustmentBaseAmount               numeric(38,4)       NULL
    ,AdjustmentPremium                  numeric(38,4)       NULL         
    ,WrittenOrEstimatedPremium          numeric(38,4)       NULL
	,LatestEPI					        numeric(38,4)       NULL
	,Premium					        numeric(38,4)       NULL
	,OriginalGrossPremium				numeric(38,4)       NULL
    ,DeclarationWEP                     numeric(38,4)       NULL
    ,ReinstatementPremium               numeric(38,4)       NULL
    ,PremiumIncomeLimit                 numeric(38,4)       NULL
    ,BenchmarkBaseWEP                   numeric(38,4)       NULL
    ,BenchmarkPremium                   numeric(38,4)       NULL
    ,ProfitCommissionNotionalWEP        numeric(38,4)       NULL
    ,ProfitCommissionBaseWEP            numeric(38,4)       NULL
    ,ExpectedLoss                       numeric(38,4)       NULL
	,RatingAdequacyWEP					numeric(38,4)       NULL
	,RatingAdequacyBaseWEP				numeric(38,4)       NULL
    ,RateChangeBaseWEP                  numeric(38,4)       NULL
    ,RateChangeWEP                      numeric(38,4)       NULL
	,RateChangeBaseDeclarationWEP       numeric(38,4)       NULL
    ,RateChangeDeclarationWEP           numeric(38,4)       NULL
    ,RateChangeQuestionnaireWEP         numeric(38,4)       NULL
    ,RateChangeOtherWEP                 numeric(38,4)       NULL
    ,RateChangeTermsAndConditionsWEP    numeric(38,4)       NULL
    ,RateChangeLimitWEP                 numeric(38,4)       NULL
    ,RateChangeDeductibleWEP            numeric(38,4)       NULL
    ,RateChangeRiskWEP                  numeric(38,4)       NULL
    ,RateChangeExposureWEP              numeric(19,4)       NULL
    ,BeazleyLedWEP                      numeric(38,4)       NULL
    ,RenewedWEP                         numeric(38,4)       NULL
    ,ExpectedPICCAmount                 numeric(38,4)       NULL
    ,USQuakeWEP                         numeric(38,4)       NULL
    ,USWindWEP                          numeric(38,4)       NULL
    ,USNonCatWEP                        numeric(38,4)       NULL
    ,NonUSCatWEP                        numeric(38,4)       NULL
    ,NonUSNonCatWEP                     numeric(38,4)       NULL
    ,AuditModifyDateTime                datetime2(7)        NULL
    ,AuditCreateDateTime                datetime2(7)        DEFAULT (GETDATE()) NOT NULL
    ,AuditModifyDetails                 nvarchar(255)       NULL
    UNIQUE(FK_Section)
 )

TRUNCATE TABLE staging.SectionPremiumCalculations

INSERT INTO staging.SectionPremiumCalculations
 (
    FK_Section
    ,OriginalEPI
    ,MinimumPremium
    ,DepositPremium
    ,RateOnLinePremiumEntered
    ,AdjustmentBaseAmount
    ,AdjustmentPremium
    ,WrittenOrEstimatedPremium
	,LatestEPI
	,Premium
	,OriginalGrossPremium 
    ,DeclarationWEP
    ,ReinstatementPremium
    ,PremiumIncomeLimit
    ,BenchmarkBaseWEP
    ,BenchmarkPremium
    ,ProfitCommissionNotionalWEP
    ,ProfitCommissionBaseWEP
    ,ExpectedLoss
	,RatingAdequacyWEP
	,RatingAdequacyBaseWEP
    ,RateChangeBaseWEP
    ,RateChangeWEP
	,RateChangeBaseDeclarationWEP
    ,RateChangeDeclarationWEP
    ,RateChangeQuestionnaireWEP
    ,RateChangeOtherWEP
    ,RateChangeTermsAndConditionsWEP
    ,RateChangeLimitWEP
    ,RateChangeDeductibleWEP
    ,RateChangeRiskWEP
    ,RateChangeExposureWEP
    ,BeazleyLedWEP
    ,RenewedWEP
    ,ExpectedPICCAmount
    ,USQuakeWEP
    ,USWindWEP
    ,USNonCatWEP
    ,NonUSCatWEP
    ,NonUSNonCatWEP	
 )
SELECT
FK_Section                          = s.PK_Section                                        
,OriginalEPI                        = s.OriginalEPIInOriginalCCY                            
,MinimumPremium                     = s.MinimumPremiumInOriginalCCY                       
,DepositPremium                     = s.DepositPremiumInOriginalCCY                       
,RateOnLinePremiumEntered           = s.RateOnLinePremiumEnteredInOriginalCCY                               
,AdjustmentBaseAmount               = s.AdjustmentBaseAmountInOriginalCCY
,AdjustmentPremium                  = s.AdjustmentPremiumInOriginalCCY                       
,WrittenOrEstimatedPremium          = s.WrittenOrEstimatedPremiumInOriginalCCY
,LatestEPI					        = vw.[EPI SL In CCY]    --Old value before change: s.LatestEPIInOriginalCCY
,Premium							= NULL --us.Premium
,OriginalGrossPremium				= s.OriginalGrossPremiumInOriginalCCY
,DeclarationWEP                     = s.DeclarationWEPInOriginalCCY
,ReinstatementPremium               = s.ReinstatementPremiumInOriginalCCY         
,PremiumIncomeLimit                 = s.PremiumIncomeLimitInOriginalCCY                     
--This should be set to NULL where there is no benchmark multiplier. Used for benchmark aggregations / calc measures.
--The idea is that if a Section has no benchmark multiplier, it should not affect the aggregate benchmark % at all
,BenchmarkBaseWEP                   = CASE 
                                        WHEN ISNULL(s.BenchmarkMultiplier, 0) <> 0 
                                        THEN s.WrittenOrEstimatedPremiumInOriginalCCY
                                        ELSE NULL
                                      END                                                 
,BenchmarkPremium                   = s.WrittenOrEstimatedPremiumInOriginalCCY * s.BenchmarkMultiplier    
,ProfitCommissionNotionalWEP        = s.WrittenOrEstimatedPremiumInOriginalCCY * s.ProfitCommissionMultiplier
--This should be set to NULL where there is no profit commission. Used for profit commission aggregations / calc measures.
--The idea is that if a Section has no profit commission, it should not affect the aggregate profit commission at all
,ProfitCommissionBaseWEP            = CASE 
                                        WHEN ISNULL(s.ProfitCommissionMultiplier,0 ) <> 0 
                                        THEN s.WrittenOrEstimatedPremiumInOriginalCCY 
                                        ELSE NULL 
                                      END
,ExpectedLoss                       = s.WrittenOrEstimatedPremiumInOriginalCCY * s.ExpectedLossRatioMultiplier
--This should be set to NULL where there is no rate change. Used for rate change aggregations / calc measures.
--The idea is that if a Section has no rate change, it should not affect the aggregate rate change at all
,RatingAdequacyWEP					= CASE 
										WHEN s.RatingAdequacyMultiplier <> 0 
										THEN (
                                                CASE
												    WHEN s.DQ_MethodOfPlacementCode = 'Z' THEN s.DeclarationWEPInOriginalCCY
												    ELSE s.WrittenOrEstimatedPremiumInOriginalCCY
												END 
                                                ) / s.RatingAdequacyMultiplier 
										ELSE NULL 
									  END
,RatingAdequacyBaseWEP				= CASE 
										WHEN s.BenchmarkMultiplier IS NOT NULL AND s.RatingAdequacyMultiplier IS NOT NULL 
										THEN (
                                                CASE
												    WHEN s.DQ_MethodOfPlacementCode = 'Z' THEN s.DeclarationWEPInOriginalCCY
												    ELSE s.WrittenOrEstimatedPremiumInOriginalCCY
												END 
                                                ) 
										ELSE NULL
									  END
,RateChangeBaseWEP                  = CASE 
                                        WHEN s.RateChangeMultiplier IS NOT NULL 
                                        THEN s.WrittenOrEstimatedPremiumInOriginalCCY
                                      END                                                 
,RateChangeWEP                      = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier                           
,RateChangeBaseDeclarationWEP       = CASE 
                                        WHEN s.RateChangeMultiplier IS NOT NULL 
                                        THEN s.DeclarationWEPInOriginalCCY
                                      END                                                 
,RateChangeDeclarationWEP           = s.DeclarationWEPInOriginalCCY * s.RateChangeMultiplier   
--This should be set to NULL where there is no rate change questionnaire. Used for rate change aggregations / calc measures. 
-- The idea is that if a Section has no rate change questionnaire, it should not affect the aggregate rate change at all
,RateChangeQuestionnaireWEP         = CASE WHEN COALESCE (
                                                            s.RateChangeDeductibleMultiplier
                                                           ,s.RateChangeExposureMultiplier
                                                           ,s.RateChangeLimitMultiplier
                                                           ,s.RateChangeOtherMultiplier
                                                           ,s.RateChangeRiskMultiplier
                                                           ,s.RateChangeTermsAndConditionsMultiplier
                                                         ) IS NOT NULL       
                                           THEN s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier
                                       END                                                 
--Rate change. Rate change weighted averages need to be compunded, in order going bottom to top in the rate change screen
,RateChangeOtherWEP                 = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier                       
,RateChangeTermsAndConditionsWEP    = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier * s.RateChangeTermsAndConditionsMultiplier          
,RateChangeLimitWEP                 = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier * s.RateChangeTermsAndConditionsMultiplier * s.RateChangeLimitMultiplier                       
,RateChangeDeductibleWEP            = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier * s.RateChangeTermsAndConditionsMultiplier * s.RateChangeLimitMultiplier * s.RateChangeDeductibleMultiplier        
,RateChangeRiskWEP                  = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier * s.RateChangeTermsAndConditionsMultiplier * s.RateChangeLimitMultiplier * s.RateChangeDeductibleMultiplier * s.RateChangeRiskMultiplier                        
,RateChangeExposureWEP              = s.WrittenOrEstimatedPremiumInOriginalCCY * s.RateChangeMultiplier * s.RateChangeOtherMultiplier * s.RateChangeTermsAndConditionsMultiplier * s.RateChangeLimitMultiplier * s.RateChangeDeductibleMultiplier * s.RateChangeRiskMultiplier * s.RateChangeExposureMultiplier                    
,BeazleyLedWEP                      = CASE WHEN s.IsBeazleyLead = 1 THEN s.WrittenOrEstimatedPremiumInOriginalCCY END
,RenewedWEP                         = CASE WHEN s.NumberOfRenewed = 1 THEN s.WrittenOrEstimatedPremiumInOriginalCCY END
,ExpectedPICCAmount                 = (s.WrittenOrEstimatedPremiumInOriginalCCY / s.DurationMonths) * s.ExpectedPICCTransactions
,USQuakeWEP                         = s.WrittenOrEstimatedPremiumInOriginalCCY * s.USQuakeMultiplier
,USWindWEP                          = s.WrittenOrEstimatedPremiumInOriginalCCY * s.USWindMultiplier
,USNonCatWEP                        = s.WrittenOrEstimatedPremiumInOriginalCCY * s.USNonCatMultiplier
,NonUSCatWEP                        = s.WrittenOrEstimatedPremiumInOriginalCCY * s.NonUSCatMultiplier
,NonUSNonCatWEP                     = s.WrittenOrEstimatedPremiumInOriginalCCY * s.NonUSNonCatMultiplier
FROM 
ODS.Section s

INNER JOIN ODS.TriFocus tf 
ON s.FK_TriFocus = tf.PK_TriFocus

--LEFT OUTER JOIN UC.Section us 
--ON us.PK_Section = s.PK_Section

LEFT JOIN [BEAZLEYINTELLIGENCE_DATAMART].[Datamart].[dbo].[vwSQLCube] vw 
on s.SectionReference = vw.Policyref COLLATE SQL_Latin1_General_CP1_CI_AS

TRUNCATE TABLE Red.FactWrittenEstimatedPremium

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactWrittenEstimatedPremium' AND CONSTRAINT_NAME = '}' 
 )

BEGIN
    ALTER TABLE Red.FactWrittenEstimatedPremium
    DROP CONSTRAINT UQ_FactWrittenEstimatedPremium_LogicalKey
END


---/// DROP INDEX ////




EXEC utility.usp_PartitionTableOnScheme 
 	 @SchemaName		= 'Red'  
	,@TableName			= 'FactWrittenEstimatedPremium' 
	,@PartitionScheme	= 'PS_FWEP';


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'SectionPremiumCalculations';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'SectionShareType';