﻿
CREATE PROC [RED].[usp_LoadFacilityDetails]
AS


	DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
	FROM		Red.FacilityDetails

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');


	DELETE		fd
	FROM		Red.FacilityDetails fd
	LEFT JOIN	ODS.Section s
	ON			fd.PK_Facility = s.PK_Section
	WHERE		s.PK_Section IS NULL


	DROP INDEX [NonClusteredColumnStoreIndex-20201127-111016] ON [Red].[FacilityDetails]


	;MERGE	Red.FacilityDetails	AS TARGET
			USING			
			(
				SELECT
						PK_Facility                             = s.PK_Section
						,SectionReference                       = s.SectionReference
						,MethodOfPlacementCode                  = p.MethodOfPlacementCode
						,InsuredParty                           = p.InsuredParty
						,CountryCode                            = s.CountryCode
						,Country                                = s.Country
						,RiskClassCode                          = s.RiskClassCode
						,RiskClass                              = s.RiskClass
						,FK_InceptionDate                       = s.FK_InceptionDate
						,FK_ExpiryDate                          = s.FK_ExpiryDate
						,IsRenewal                              = s.IsRenewal
						,IsRenewalName                          = s.IsRenewalName
						,SectionDisplayReference                = s.SectionDisplayReference
						,PolicyReferenceMOPCode                 = p.PolicyReferenceMOPCode
						,PolicyReferenceRiskNumber              = p.PolicyReferenceRiskNumber
						,PolicyReferenceYOA                     = p.PolicyReferenceYOA
						,SectionReferenceSectionIdentifier      = s.SectionReferenceSectionIdentifier
						,SectionReferenceReinsuranceIndicator   = s.SectionReferenceReinsuranceIndicator
						,SectionReferenceCOBCode                = s.SectionReferenceCOBCode
						,BinderType                             = s.BinderType
						,BinderTypeInternalExternal             = s.BinderTypeInternalExternal
						,HasMissingPICCTransactions				= s.HasMissingPICCTransactions
						,HasMissingPICCTransactionsName			= s.HasMissingPICCTransactionsName
						,IsBeazleyLead                          = s.IsBeazleyLead
						,IsBeazleyLeadName                      = s.IsBeazleyLeadName
						,PrimarySectionURL                      = s.PrimarySectionURL
						,PrimarySectionURLLabel                 = s.PrimarySectionURLLabel
						,HasDataContractSections                = s.HasDataContractSections
						,HasDataContractSectionsName            = s.HasDataContractSectionsName
						,FK_Underwriter							= s.FK_Underwriter
						,FK_TriFocus                            = s.FK_TriFocus
						,FK_Area                                = s.FK_Area
						,FK_YOA                                 = p.FK_YOA
						,FK_ClassOfBusiness                     = s.FK_ClassOfBusiness
						,Area									= a.Area
						,AreaCode								= a.AreaCode
						,ExpiryPK_Date							= dde.PK_Date
						,ExpiryDateName							= dde.DateName
						,ExpiryMonth							= dde.Month
						,ExpiryMonthName						= dde.MonthName
						,ExpiryQuarter							= dde.Quarter
						,ExpiryQuarterName						= dde.QuarterName
						,ExpiryYear								= dde.Year
						,ExpiryYearName							= dde.YearName
						,InceptionPK_Date						= ddi.PK_Date
						,InceptionDateName						= ddi.DateName
						,InceptionMonth							= ddi.Month
						,InceptionMonthName						= ddi.MonthName
						,InceptionQuarter						= ddi.Quarter
						,InceptionQuarterName					= ddi.QuarterName
						,InceptionYear							= ddi.Year
						,InceptionYearName						= ddi.YearName
						,YOAName								= y.YOAName
						,ClassOfBusiness						= cob.ClassOfBusiness
						,ClassOfBusinessCode					= cob.ClassOfBusinessCode
						,UnderwriterName						= u.UnderwriterName
						,DepartmentName							= t.DepartmentName
						,TriFocusName							= t.TrifocusName

				FROM	ODS.Section s

				INNER JOIN	ODS.Policy p 
						ON	s.FK_Policy = p.PK_Policy

				LEFT JOIN ODS.Area a
						ON s.FK_Area = a.PK_Area

				LEFT JOIN ODS.DimDate dde
						ON s.FK_ExpiryDate = dde.PK_Date

				LEFT JOIN ODS.DimDate ddi
						ON s.FK_InceptionDate = ddi.PK_Date

				LEFT JOIN ODS.YOA y
						ON s.FK_YOA = y.PK_YOA

				LEFT JOIN ODS.ClassOfBusiness cob
						ON s.FK_ClassOfBusiness = cob.PK_ClassOfBusiness

				LEFT JOIN ODS.Underwriter u
						ON s.FK_Underwriter = u.PK_Underwriter

				LEFT JOIN ODS.Trifocus t
						ON s.FK_TriFocus = t.PK_TriFocus 

				WHERE     
					(s.IsFacility = 1 OR s.PK_Section = 0)
				AND 
					(		(s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
						OR	(p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
						OR	(y.AuditModifyDateTime	 > @LastAuditDate OR y.AuditCreateDateTime	 > @LastAuditDate)
						OR	(cob.AuditModifyDateTime > @LastAuditDate OR cob.AuditCreateDateTime > @LastAuditDate)
						OR	(t.AuditModifyDateTime	 > @LastAuditDate OR t.AuditCreateDateTime	 > @LastAuditDate)
					)	
			)
			AS SOURCE

			ON	TARGET.PK_Facility = SOURCE.PK_Facility

	WHEN	MATCHED	THEN
			UPDATE	
			SET	TARGET.PK_Facility									= SOURCE.PK_Facility	
				,TARGET.SectionReference							= SOURCE.SectionReference					
				,TARGET.MethodOfPlacementCode              			= SOURCE.MethodOfPlacementCode              	
				,TARGET.InsuredParty                       			= SOURCE.InsuredParty                       	
				,TARGET.CountryCode                        			= SOURCE.CountryCode                        	
				,TARGET.Country                            			= SOURCE.Country                            	
				,TARGET.RiskClassCode                      			= SOURCE.RiskClassCode                      	
				,TARGET.RiskClass                          			= SOURCE.RiskClass                          	
				,TARGET.FK_InceptionDate                   			= SOURCE.FK_InceptionDate                   	
				,TARGET.FK_ExpiryDate                      			= SOURCE.FK_ExpiryDate                      	
				,TARGET.IsRenewal                          			= SOURCE.IsRenewal                          	
				,TARGET.IsRenewalName                      			= SOURCE.IsRenewalName                      	
				,TARGET.SectionDisplayReference            			= SOURCE.SectionDisplayReference            	
				,TARGET.PolicyReferenceMOPCode             			= SOURCE.PolicyReferenceMOPCode             	
				,TARGET.PolicyReferenceRiskNumber          			= SOURCE.PolicyReferenceRiskNumber          	
				,TARGET.PolicyReferenceYOA                 			= SOURCE.PolicyReferenceYOA                 	
				,TARGET.SectionReferenceSectionIdentifier  			= SOURCE.SectionReferenceSectionIdentifier  	
				,TARGET.SectionReferenceReinsuranceIndicator		= SOURCE.SectionReferenceReinsuranceIndicator	
				,TARGET.SectionReferenceCOBCode            			= SOURCE.SectionReferenceCOBCode            	
				,TARGET.BinderType                         			= SOURCE.BinderType                         	
				,TARGET.BinderTypeInternalExternal         			= SOURCE.BinderTypeInternalExternal         	
				,TARGET.HasMissingPICCTransactions					= SOURCE.HasMissingPICCTransactions			
				,TARGET.HasMissingPICCTransactionsName				= SOURCE.HasMissingPICCTransactionsName		
				,TARGET.IsBeazleyLead                      			= SOURCE.IsBeazleyLead                      	
				,TARGET.IsBeazleyLeadName                  			= SOURCE.IsBeazleyLeadName                  	
				,TARGET.PrimarySectionURL                  			= SOURCE.PrimarySectionURL                  	
				,TARGET.PrimarySectionURLLabel             			= SOURCE.PrimarySectionURLLabel             	
				,TARGET.HasDataContractSections            			= SOURCE.HasDataContractSections            	
				,TARGET.HasDataContractSectionsName        			= SOURCE.HasDataContractSectionsName        	
				,TARGET.FK_Underwriter								= SOURCE.FK_Underwriter						
				,TARGET.FK_TriFocus                        			= SOURCE.FK_TriFocus                        	
				,TARGET.FK_Area                            			= SOURCE.FK_Area                            	
				,TARGET.FK_YOA                             			= SOURCE.FK_YOA                             	
				,TARGET.FK_ClassOfBusiness                 			= SOURCE.FK_ClassOfBusiness                 	
				,TARGET.Area										= SOURCE.Area								
				,TARGET.AreaCode									= SOURCE.AreaCode							
				,TARGET.ExpiryPK_Date								= SOURCE.ExpiryPK_Date						
				,TARGET.ExpiryDateName								= SOURCE.ExpiryDateName						
				,TARGET.ExpiryMonth									= SOURCE.ExpiryMonth							
				,TARGET.ExpiryMonthName								= SOURCE.ExpiryMonthName						
				,TARGET.ExpiryQuarter								= SOURCE.ExpiryQuarter						
				,TARGET.ExpiryQuarterName							= SOURCE.ExpiryQuarterName					
				,TARGET.ExpiryYear									= SOURCE.ExpiryYear							
				,TARGET.ExpiryYearName								= SOURCE.ExpiryYearName						
				,TARGET.InceptionPK_Date							= SOURCE.InceptionPK_Date					
				,TARGET.InceptionDateName							= SOURCE.InceptionDateName					
				,TARGET.InceptionMonth								= SOURCE.InceptionMonth						
				,TARGET.InceptionMonthName							= SOURCE.InceptionMonthName					
				,TARGET.InceptionQuarter							= SOURCE.InceptionQuarter					
				,TARGET.InceptionQuarterName						= SOURCE.InceptionQuarterName				
				,TARGET.InceptionYear								= SOURCE.InceptionYear						
				,TARGET.InceptionYearName							= SOURCE.InceptionYearName					
				,TARGET.YOAName										= SOURCE.YOAName								
				,TARGET.ClassOfBusiness								= SOURCE.ClassOfBusiness						
				,TARGET.ClassOfBusinessCode							= SOURCE.ClassOfBusinessCode					
				,TARGET.UnderwriterName								= SOURCE.UnderwriterName						
				,TARGET.DepartmentName								= SOURCE.DepartmentName						
				,TARGET.TriFocusName								= SOURCE.TriFocusName
				,TARGET.AuditModifyDateTime							= GETDATE()						
				,TARGET.AuditModifyDetails							= 'Merge in Red.usp_LoadFacilityDetails' 

	WHEN	NOT MATCHED BY TARGET THEN
			INSERT
			(		
				PK_Facility                             
				,SectionReference                       
				,MethodOfPlacementCode                  
				,InsuredParty                           
				,CountryCode                            
				,Country                                
				,RiskClassCode                          
				,RiskClass                              
				,FK_InceptionDate                       
				,FK_ExpiryDate                          
				,IsRenewal                              
				,IsRenewalName                          
				,SectionDisplayReference                
				,PolicyReferenceMOPCode                 
				,PolicyReferenceRiskNumber              
				,PolicyReferenceYOA                     
				,SectionReferenceSectionIdentifier      
				,SectionReferenceReinsuranceIndicator   
				,SectionReferenceCOBCode                
				,BinderType                             
				,BinderTypeInternalExternal             
				,HasMissingPICCTransactions				
				,HasMissingPICCTransactionsName			
				,IsBeazleyLead                          
				,IsBeazleyLeadName                      
				,PrimarySectionURL                      
				,PrimarySectionURLLabel                 
				,HasDataContractSections                
				,HasDataContractSectionsName            
				,FK_Underwriter							
				,FK_TriFocus                            
				,FK_Area                                
				,FK_YOA                                 
				,FK_ClassOfBusiness                     
				,Area									
				,AreaCode								
				,ExpiryPK_Date							
				,ExpiryDateName							
				,ExpiryMonth							
				,ExpiryMonthName						
				,ExpiryQuarter							
				,ExpiryQuarterName						
				,ExpiryYear								
				,ExpiryYearName							
				,InceptionPK_Date						
				,InceptionDateName						
				,InceptionMonth							
				,InceptionMonthName						
				,InceptionQuarter						
				,InceptionQuarterName					
				,InceptionYear							
				,InceptionYearName						
				,YOAName								
				,ClassOfBusiness						
				,ClassOfBusinessCode					
				,UnderwriterName						
				,DepartmentName							
				,TriFocusName
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				SOURCE.PK_Facility	
				,SOURCE.SectionReference					
				,SOURCE.MethodOfPlacementCode             
				,SOURCE.InsuredParty                      
				,SOURCE.CountryCode                       
				,SOURCE.Country                           
				,SOURCE.RiskClassCode                     
				,SOURCE.RiskClass                         
				,SOURCE.FK_InceptionDate                  
				,SOURCE.FK_ExpiryDate                     
				,SOURCE.IsRenewal                         
				,SOURCE.IsRenewalName                     
				,SOURCE.SectionDisplayReference           
				,SOURCE.PolicyReferenceMOPCode            
				,SOURCE.PolicyReferenceRiskNumber         
				,SOURCE.PolicyReferenceYOA                
				,SOURCE.SectionReferenceSectionIdentifier 
				,SOURCE.SectionReferenceReinsuranceIndicator
				,SOURCE.SectionReferenceCOBCode           
				,SOURCE.BinderType                        
				,SOURCE.BinderTypeInternalExternal        
				,SOURCE.HasMissingPICCTransactions			
				,SOURCE.HasMissingPICCTransactionsName		
				,SOURCE.IsBeazleyLead                     
				,SOURCE.IsBeazleyLeadName                 
				,SOURCE.PrimarySectionURL                 
				,SOURCE.PrimarySectionURLLabel            
				,SOURCE.HasDataContractSections           
				,SOURCE.HasDataContractSectionsName       
				,SOURCE.FK_Underwriter						
				,SOURCE.FK_TriFocus                       
				,SOURCE.FK_Area                           
				,SOURCE.FK_YOA                            
				,SOURCE.FK_ClassOfBusiness                
				,SOURCE.Area								
				,SOURCE.AreaCode							
				,SOURCE.ExpiryPK_Date						
				,SOURCE.ExpiryDateName						
				,SOURCE.ExpiryMonth						
				,SOURCE.ExpiryMonthName					
				,SOURCE.ExpiryQuarter						
				,SOURCE.ExpiryQuarterName					
				,SOURCE.ExpiryYear							
				,SOURCE.ExpiryYearName						
				,SOURCE.InceptionPK_Date					
				,SOURCE.InceptionDateName					
				,SOURCE.InceptionMonth						
				,SOURCE.InceptionMonthName					
				,SOURCE.InceptionQuarter					
				,SOURCE.InceptionQuarterName				
				,SOURCE.InceptionYear						
				,SOURCE.InceptionYearName					
				,SOURCE.YOAName							
				,SOURCE.ClassOfBusiness					
				,SOURCE.ClassOfBusinessCode				
				,SOURCE.UnderwriterName					
				,SOURCE.DepartmentName						
				,SOURCE.TriFocusName
				,GETDATE()						
				,'New add in Red.usp_LoadFacilityDetails' 
			)
	;


	CREATE NONCLUSTERED COLUMNSTORE INDEX [NonClusteredColumnStoreIndex-20201127-111016] ON [Red].[FacilityDetails]
	(
		[PK_Facility],
		[SectionReference],
		[MethodOfPlacementCode],
		[InsuredParty],
		[CountryCode],
		[Country],
		[RiskClassCode],
		[RiskClass],
		[FK_InceptionDate],
		[FK_ExpiryDate],
		[IsRenewal],
		[IsRenewalName],
		[SectionDisplayReference],
		[PolicyReferenceMOPCode],
		[PolicyReferenceRiskNumber],
		[PolicyReferenceYOA],
		[SectionReferenceSectionIdentifier],
		[SectionReferenceReinsuranceIndicator],
		[SectionReferenceCOBCode],
		[BinderType],
		[BinderTypeInternalExternal],
		[HasMissingPICCTransactions],
		[HasMissingPICCTransactionsName],
		[IsBeazleyLead],
		[IsBeazleyLeadName],
		[PrimarySectionURL],
		[PrimarySectionURLLabel],
		[HasDataContractSections],
		[HasDataContractSectionsName],
		[FK_Underwriter],
		[FK_TriFocus],
		[FK_Area],
		[FK_YOA],
		[FK_ClassOfBusiness],
		[Area],
		[AreaCode],
		[ExpiryPK_Date],
		[ExpiryDateName],
		[ExpiryMonth],
		[ExpiryMonthName],
		[ExpiryQuarter],
		[ExpiryQuarterName],
		[ExpiryYear],
		[ExpiryYearName],
		[InceptionPK_Date],
		[InceptionDateName],
		[InceptionMonth],
		[InceptionMonthName],
		[InceptionQuarter],
		[InceptionQuarterName],
		[InceptionYear],
		[InceptionYearName],
		[YOAName],
		[ClassOfBusiness],
		[ClassOfBusinessCode],
		[UnderwriterName],
		[DepartmentName],
		[TriFocusName]
	)WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]