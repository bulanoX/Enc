﻿
CREATE PROCEDURE [Red].[usp_LoadFactExcess]
AS

DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime, AuditCreateDateTime))
FROM		Red.FactExcess

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');

/***************************************************************************************/
/*                        Share type                                                   */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType

CREATE TABLE #SectionShareType
(
     FK_Section                      bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
)

TRUNCATE TABLE #SectionShareType

INSERT INTO #SectionShareType
(
     FK_Section
    ,FK_ShareType
    ,FK_Syndicate
)

SELECT
 FK_Section              = s.PK_Section     
,FK_ShareType           = st.PK_ShareType
,FK_Syndicate           = NULL                                      

FROM ODS.Section s

CROSS JOIN Red.ShareType st

WHERE st.ShareTypeName IN ('Total Order','Slip Order')

UNION ALL

SELECT
 FK_Section            = sl.FK_Section                       
,FK_ShareType          = st.PK_ShareType                 
,FK_Syndicate          = sl.FK_Syndicate 

FROM ODS.SectionLine sl

CROSS JOIN Red.ShareType st

WHERE st.ShareTypeName = 'Beazley Share'


/***************************************************************************************/
/*          Section excess fact currency												   */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionExcessCurrency') IS NOT NULL) DROP TABLE #SectionExcessCurrency

CREATE TABLE #SectionExcessCurrency
(
     FK_Section							bigint              NOT NULL
	,FK_Syndicate						bigint              NULL
	,FK_ShareType						bigint              NOT NULL
	,FK_Date							datetime            NOT NULL
	,FK_YOA								bigint              NOT NULL
	,FK_SettlementCurrency				bigint              NOT NULL
	,FK_OriginalCurrency				bigint              NOT NULL
	,FK_ExcessCurrency					bigint              NOT NULL
	,FK_TriFocus						bigint              NOT NULL
	,FK_CRMBroker						bigint              NOT NULL
	,FK_Policy							bigint              NOT NULL
	,FK_QuoteFilter						bigint              NOT NULL
	,FK_HiddenStatusFilter				bigint              NOT NULL
	,FK_Excess							bigint				NOT NULL
	,FK_UnderwritingPlatform			bigint				NOT NULL
	,FK_InternalWrittenBinderStatus		bigint				NOT NULL 
	,FK_ServiceCompany					bigint				NOT NULL 
	,SpecialPurposeSyndicateApplies		bit                 NOT NULL
	,Excess								numeric(38,4)       NULL
)

	
TRUNCATE TABLE #SectionExcessCurrency

INSERT INTO #SectionExcessCurrency
 (
     FK_Section
	,FK_Syndicate
	,FK_ShareType
	,FK_Date
	,FK_YOA
	,FK_SettlementCurrency
	,FK_OriginalCurrency
	,FK_ExcessCurrency
	,FK_TriFocus
	,FK_CRMBroker
	,FK_Policy
	,FK_QuoteFilter
	,FK_HiddenStatusFilter
	,FK_Excess
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
	,SpecialPurposeSyndicateApplies
	,Excess
 )

-- Generic calcs
SELECT
 FK_Section						= s.PK_Section
,FK_Syndicate					= sst.FK_Syndicate
,FK_ShareType					= st.PK_ShareType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_ExcessCurrency				= se.FK_ExcessCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Excess						= se.FK_Excess		
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany	
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Excess							= CASE -- Excess is always at total order
									WHEN st.ShareTypeName = 'Beazley Share'
									THEN NULL
									ELSE se.ExcessAmountInExcessCCY
								  END

FROM ODS.Section s WITH(NOLOCK)

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionExcess se 
ON s.PK_Section = se.FK_Section

INNER JOIN #SectionShareType sst 
ON s.PK_Section = sst.FK_Section

INNER JOIN Red.ShareType st WITH(NOLOCK) 
ON sst.FK_ShareType = st.PK_ShareType

WHERE (s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
   OR (p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
   OR (se.AuditModifyDateTime	 > @LastAuditDate OR se.AuditCreateDateTime	 > @LastAuditDate)

UNION ALL

--Beazley share rows for Excess (use total order value & NULL syndicate key)
SELECT
 FK_Section						= s.PK_Section
,FK_Syndicate					= NULL
,FK_ShareType					= st.PK_ShareType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_ExcessCurrency				= se.FK_ExcessCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Excess						= se.FK_Excess	
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany	
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Excess							= se.ExcessAmountInExcessCCY --Excess is always at total order

FROM ODS.Section s WITH(NOLOCK)

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionExcess se 
ON s.PK_Section = se.FK_Section

INNER JOIN Red.ShareType st WITH(NOLOCK) 
ON st.ShareTypeName = 'Beazley Share'

WHERE (s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
   OR (p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
   OR (se.AuditModifyDateTime	 > @LastAuditDate OR se.AuditCreateDateTime	 > @LastAuditDate)
   

/***************************************************************************************/
/*                           Load fact limit                                           */
/***************************************************************************************/

ALTER TABLE Red.FactExcess NOCHECK CONSTRAINT ALL

--TRUNCATE TABLE Red.FactExcess

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExcess' AND CONSTRAINT_NAME = 'UQ_FactExcess_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactExcess
    DROP CONSTRAINT UQ_FactExcess_LogicalKey
END

DELETE FROM RED.FactExcess WHERE FK_Section not in (select PK_Section from ODS.Section)
DELETE FROM RED.FactExcess WHERE FK_Policy not in (select PK_Policy from ODS.Policy)
DELETE FROM RED.FactExcess WHERE FK_UnderwritingPlatform NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform)
DELETE FROM RED.FactExcess WHERE FK_CRMBroker NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker)
DELETE FROM RED.FactExcess WHERE FK_Excess NOT IN (SELECT PK_Excess FROM ODS.Excess)

MERGE Red.FactExcess AS TARGET

USING 
--Excess amounts in original currency
(

SELECT
FK_Section						= selc.FK_Section
,FK_Syndicate					= selc.FK_Syndicate
,FK_ShareType					= selc.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = selc.FK_Date
,FK_YOA                         = selc.FK_YOA
,FK_SettlementCurrency          = selc.FK_SettlementCurrency
,FK_OriginalCurrency            = selc.FK_OriginalCurrency
,FK_ExcessCurrency				= selc.FK_ExcessCurrency
,FK_TriFocus                    = selc.FK_TriFocus
,FK_CRMBroker                   = selc.FK_CRMBroker
,FK_Policy                      = selc.FK_Policy
,FK_QuoteFilter                 = selc.FK_QuoteFilter
,FK_HiddenStatusFilter          = selc.FK_HiddenStatusFilter
,FK_Excess						= selc.FK_Excess
,FK_UnderwritingPlatform		= selc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= selc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= selc.FK_ServiceCompany	
,SpecialPurposeSyndicateApplies = selc.SpecialPurposeSyndicateApplies
,Excess							= CASE 
									WHEN selc.FK_ExcessCurrency = selc.FK_OriginalCurrency
									THEN selc.Excess 
									ELSE TRY_CAST((selc.Excess / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(19,4))
								  END

FROM #SectionExcessCurrency selc

INNER JOIN ODS.OriginalCurrency lccy 
ON selc.FK_ExcessCurrency = lccy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crlim 
ON lccy.CurrencyCode = crlim.Currency AND crlim.RateType = 'Current'

INNER JOIN ODS.OriginalCurrency occy 
ON selc.FK_OriginalCurrency = occy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crsett 
ON occy.CurrencyCode = crsett.Currency AND crsett.RateType = 'Current'

CROSS JOIN Red.ReportingCurrencyOverride rco

WHERE rco.ReportingCurrencyOverrideName = 'Original Currency'

UNION ALL

--Limit amounts in settlement currency

SELECT
FK_Section						= selc.FK_Section
,FK_Syndicate					= selc.FK_Syndicate
,FK_ShareType					= selc.FK_ShareType
,FK_ReportingCurrencyOverride	= rco.PK_ReportingCurrencyOverride
,FK_Date                        = selc.FK_Date
,FK_YOA                         = selc.FK_YOA
,FK_SettlementCurrency          = selc.FK_SettlementCurrency
,FK_OriginalCurrency            = selc.FK_OriginalCurrency
,FK_ExcessCurrency				= selc.FK_ExcessCurrency
,FK_TriFocus                    = selc.FK_TriFocus
,FK_CRMBroker                   = selc.FK_CRMBroker
,FK_Policy                      = selc.FK_Policy
,FK_QuoteFilter                 = selc.FK_QuoteFilter
,FK_HiddenStatusFilter          = selc.FK_HiddenStatusFilter
,FK_Excess						= selc.FK_Excess
,FK_UnderwritingPlatform		= selc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= selc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= selc.FK_ServiceCompany	
,SpecialPurposeSyndicateApplies = selc.SpecialPurposeSyndicateApplies
,Excess							= CASE
									WHEN lccy.CurrencyCode = sccy.CurrencyCode
									THEN selc.Excess
									ELSE TRY_CAST((selc.Excess / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(19,4))
								  END

FROM #SectionExcessCurrency selc

INNER JOIN ODS.OriginalCurrency lccy 
ON selc.FK_ExcessCurrency = lccy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crlim 
ON lccy.CurrencyCode = crlim.Currency AND crlim.RateType = 'Current'

INNER JOIN ODS.SettlementCurrency sccy 
ON selc.FK_SettlementCurrency = sccy.PK_SettlementCurrency

LEFT OUTER JOIN Utility.CurrencyRate crsett 
ON sccy.CurrencyCode = crsett.Currency AND crsett.RateType = 'Current'

CROSS JOIN Red.ReportingCurrencyOverride rco

WHERE rco.ReportingCurrencyOverrideName = 'Settlement Currency'

) AS SOURCE

 ON TARGET.FK_Section                     = SOURCE.FK_Section
AND	ISNULL(TARGET.FK_Syndicate, 0)        = ISNULL(SOURCE.FK_Syndicate, 0)
AND TARGET.FK_ShareType                   = SOURCE.FK_ShareType
AND TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride
AND TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
AND TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
AND TARGET.FK_ExcessCurrency              = SOURCE.FK_ExcessCurrency
AND TARGET.FK_Excess                      = SOURCE.FK_Excess


WHEN MATCHED THEN

UPDATE SET 
  TARGET.FK_Section                     = SOURCE.FK_Section
 ,TARGET.FK_Syndicate                   = SOURCE.FK_Syndicate
 ,TARGET.FK_ShareType                   = SOURCE.FK_ShareType
 ,TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride
 ,TARGET.FK_Date                        = SOURCE.FK_Date
 ,TARGET.FK_YOA                         = SOURCE.FK_YOA
 ,TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
 ,TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
 ,TARGET.FK_ExcessCurrency              = SOURCE.FK_ExcessCurrency
 ,TARGET.FK_TriFocus                    = SOURCE.FK_TriFocus
 ,TARGET.FK_CRMBroker                   = SOURCE.FK_CRMBroker
 ,TARGET.FK_Policy                      = SOURCE.FK_Policy
 ,TARGET.FK_QuoteFilter                 = SOURCE.FK_QuoteFilter
 ,TARGET.FK_HiddenStatusFilter          = SOURCE.FK_HiddenStatusFilter
 ,TARGET.FK_Excess                      = SOURCE.FK_Excess
 ,TARGET.FK_UnderwritingPlatform        = SOURCE.FK_UnderwritingPlatform
 ,TARGET.FK_InternalWrittenBinderStatus = SOURCE.FK_InternalWrittenBinderStatus
 ,TARGET.FK_ServiceCompany              = SOURCE.FK_ServiceCompany
 ,TARGET.SpecialPurposeSyndicateApplies = SOURCE.SpecialPurposeSyndicateApplies
 ,TARGET.Excess                         = SOURCE.Excess
 ,TARGET.AuditModifyDateTime            = GETDATE()
 ,TARGET.AuditModifyDetails             = 'Merge in [RED].[FactExcess] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     FK_Section
    ,FK_Syndicate
    ,FK_ShareType
	,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_ExcessCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,FK_Excess
    ,FK_UnderwritingPlatform
    ,FK_InternalWrittenBinderStatus
    ,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,Excess
	,AuditModifyDetails

)
VALUES
(
     SOURCE.FK_Section
    ,SOURCE.FK_Syndicate
    ,SOURCE.FK_ShareType
	,SOURCE.FK_ReportingCurrencyOverride
    ,SOURCE.FK_Date
    ,SOURCE.FK_YOA
    ,SOURCE.FK_SettlementCurrency
    ,SOURCE.FK_OriginalCurrency
    ,SOURCE.FK_ExcessCurrency
    ,SOURCE.FK_TriFocus
    ,SOURCE.FK_CRMBroker
    ,SOURCE.FK_Policy
    ,SOURCE.FK_QuoteFilter
    ,SOURCE.FK_HiddenStatusFilter
    ,SOURCE.FK_Excess
    ,SOURCE.FK_UnderwritingPlatform
    ,SOURCE.FK_InternalWrittenBinderStatus
    ,SOURCE.FK_ServiceCompany
    ,SOURCE.SpecialPurposeSyndicateApplies
    ,SOURCE.Excess
	,'New in [RED].[FactExcess] table' 
);

/* Initialize ExcLBS columns with existing values */
UPDATE slc
SET  ExcessExcLBS = Excess
FROM Red.FactExcess slc


IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS

CREATE TABLE #ExcLBS
(
     FK_Section                     bigint              NOT NULL
	,FK_SectionExcLBS				bigint              NOT NULL
	,Excess                         NUMERIC (38, 4) NULL
	,ExcessExcLBS                   NUMERIC (38, 4) NULL
)

TRUNCATE TABLE #ExcLBS

INSERT INTO  #ExcLBS
	(
	 FK_Section
	,FK_SectionExcLBS
	,Excess 
	,ExcessExcLBS
	)
SELECT
	 ss.PK_Section
	,sl.PK_Section
	,Excess = SUM(slcs.Excess) 
	,ExcessExcLBS =  SUM(slcl.Excess) 
FROM 
		Red.FactExcess slcs
		INNER JOIN ODS.Section ss ON slcs.FK_Section = ss.PK_Section
		INNER JOIN Red.FactExcess slcl 
		ON slcs.FK_Policy 		= slcl.FK_Policy
		--AND isnull(slcs.Excess,0) = isnull(slcl.Excess,0)
		INNER JOIN ODS.Section sl ON slcl.FK_Section = sl.PK_Section
		AND ss.FK_ClassOfBusiness = sl.FK_ClassOfBusiness
		INNER JOIN ODS.UnderwritingPlatform ups
		ON ups.PK_UnderwritingPlatform = slcs.FK_UnderwritingPlatform
		INNER JOIN ODS.UnderwritingPlatform upl
		ON upl.PK_UnderwritingPlatform = slcl.FK_UnderwritingPlatform
		WHERE ups.UnderwritingPlatformCode IN ('SYND','LBSM','LBSF')
		AND upl.UnderwritingPlatformCode = 'LBS'
GROUP BY 
	 ss.PK_Section
	,sl.PK_Section



/* Set ExcLBS columns to 0 for LBS sections */

UPDATE seocl
SET	 ExcessExcLBS 		= CASE WHEN seocs.Excess IS NULL THEN NULL ELSE 0 END

FROM 
#ExcLBS exc
INNER JOIN Red.FactExcess seocl 
ON exc.FK_SectionExcLBS 		= seocl.FK_Section
INNER JOIN Red.FactExcess seocs 
ON exc.FK_Section 	= seocs.FK_Section
WHERE 
	ISNULL(exc.Excess,0) 	 = ISNULL(exc.ExcessExcLBS,0)



IF NOT EXISTS
(
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExcess' AND CONSTRAINT_NAME = 'UQ_FactExcess_LogicalKey'     
)
BEGIN
    ALTER TABLE Red.FactExcess
    ADD CONSTRAINT UQ_FactExcess_LogicalKey
    UNIQUE
        (
             FK_Section
			 ,FK_Syndicate
			 ,FK_ShareType
			 ,FK_ReportingCurrencyOverride
			 ,FK_SettlementCurrency
			 ,FK_OriginalCurrency
			 ,FK_ExcessCurrency
			 ,FK_Excess
        )
END

ALTER TABLE Red.FactExcess CHECK CONSTRAINT ALL

IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType
IF (OBJECT_ID('tempdb..#SectionExcessCurrency') IS NOT NULL) DROP TABLE #SectionExcessCurrency
IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactExcess';