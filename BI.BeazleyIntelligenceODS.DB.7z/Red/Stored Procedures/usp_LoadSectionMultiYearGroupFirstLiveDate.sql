﻿

CREATE PROCEDURE [Red].[usp_LoadSectionMultiYearGroupFirstLiveDate]
AS

SET NOCOUNT ON

--TRUNCATE TABLE Red.SectionMultiYearGroupFirstLiveDate

MERGE Red.SectionMultiYearGroupFirstLiveDate AS TARGET

USING 
(
SELECT
FK_Section              = s.PK_Section
,FK_FirstLiveDate       = sm.FK_FirstLiveDate
FROM
ODS.Section s
INNER JOIN
ODS.Section sm ON
s.MultiYearGroupReference = sm.MultiYearGroupReference
UNION
SELECT
FK_Section              = s.PK_Section
,FK_FirstLiveDate       = s.FK_FirstLiveDate
FROM
ODS.Section s
WHERE
s.MultiYearGroupReference IS NULL) AS SOURCE

 ON TARGET.FK_Section       = SOURCE.FK_Section
AND TARGET.FK_FirstLiveDate = SOURCE.FK_FirstLiveDate

WHEN MATCHED THEN

UPDATE SET 
  TARGET.FK_Section             = SOURCE.FK_Section
 ,TARGET.FK_FirstLiveDate       = SOURCE.FK_FirstLiveDate
 ,TARGET.AuditModifyDateTime    = GETDATE()
 ,TARGET.AuditModifyDetails     = 'Merge in [RED].[SectionMultiYearGroupFirstLiveDate] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     FK_Section
    ,FK_FirstLiveDate
	,AuditModifyDetails

)
VALUES
(
     SOURCE.FK_Section
    ,SOURCE.FK_FirstLiveDate
	,'New in [RED].[SectionMultiYearGroupFirstLiveDate] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'SectionMultiYearGroupFirstLiveDate';