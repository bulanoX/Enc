﻿
CREATE PROC [Red].[usp_LoadFactPICCTransaction]

AS

DECLARE @LastAuditDate DATETIME2(7)

SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM Red.FactPICCTransaction
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

/**************************************************************************************/
/*                          PICC Transaction fact in original currency                */
/**************************************************************************************/
IF (OBJECT_ID('tempdb..#PICCTransactionOriginalCurrency') IS NOT NULL) DROP TABLE #PICCTransactionOriginalCurrency

CREATE TABLE #PICCTransactionOriginalCurrency
 (
    FK_PICCTransaction              bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_AcquisitionCostBasis        bigint              NOT NULL
    ,FK_Date                        datetime            NOT NULL
    ,FK_YOA                         bigint              NOT NULL
    ,FK_SettlementCurrency          bigint              NOT NULL
    ,FK_OriginalCurrency            bigint              NOT NULL
    ,FK_LocalCurrency				bigint              NOT NULL
    ,FK_TriFocus                    bigint              NOT NULL
    ,FK_CRMBroker                   bigint              NOT NULL
    ,FK_Section                     bigint              NOT NULL
    ,FK_Policy                      bigint              NOT NULL
    ,FK_QuoteFilter                 bigint              NOT NULL
    ,FK_HiddenStatusFilter          bigint              NOT NULL
	,FK_UnderwritingPlatform		bigint				NOT NULL
	,FK_InternalWrittenBinderStatus	bigint				NOT NULL
	,FK_ServiceCompany				bigint				NOT NULL
    ,SpecialPurposeSyndicateApplies bit                 NOT NULL
    ,PICCAmount                     numeric(19,4)       NULL
 )

--TRUNCATE TABLE #PICCTransactionOriginalCurrency

INSERT INTO #PICCTransactionOriginalCurrency
 (
     FK_PICCTransaction
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_AcquisitionCostBasis
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_LocalCurrency	
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Section
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,PICCAmount
 )

SELECT
 FK_PICCTransaction                 = picc.PK_PICCTransaction             
,FK_Syndicate                       = sst.FK_Syndicate                      
,FK_ShareType                       = sst.FK_ShareType                        
,FK_AcquisitionCostBasis            = sacb.FK_AcquisitionCostBasis  
,FK_Date                            = picc.FK_Date
,FK_YOA                             = picc.FK_YOA
,FK_SettlementCurrency              = picc.FK_SettlementCurrency
,FK_OriginalCurrency                = picc.FK_OriginalCurrency
,FK_LocalCurrency					= ISNULL(picc.FK_LocalCurrency,0)
,FK_TriFocus                        = picc.FK_TriFocus
,FK_CRMBroker                       = picc.FK_CRMBroker
,FK_Section                         = picc.FK_Section
,FK_Policy                          = picc.FK_Policy
,FK_QuoteFilter                     = picc.FK_QuoteFilter
,FK_HiddenStatusFilter              = picc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform			= picc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= picc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= picc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies     = picc.SpecialPurposeSyndicateApplies  
,PICCAmount                         = picc.PICCAmountInOriginalCCY * sacb.AcquisitionCostMultiplier * sst.TotalLineMultiplier                     
FROM 
ODS.PICCTransaction picc
INNER JOIN 
staging.SectionAcquisitionCostBasis sacb ON 
picc.FK_Section = sacb.FK_Section
INNER JOIN staging.SectionShareType sst ON 
picc.FK_Section = sst.FK_Section
INNER JOIN 
ODS.EntityPerspective ep ON
sacb.FK_EntityPerspective = ep.PK_EntityPerspective
WHERE
ep.EntityPerspective = 'Eurobase View'

AND (
       (picc.AuditCreateDateTime > @LastAuditDate OR picc.AuditModifyDateTime > @LastAuditDate)	
	   OR (sacb.AuditCreateDateTime > @LastAuditDate OR sacb.AuditModifyDateTime > @LastAuditDate)
	   OR (sst.AuditCreateDateTime > @LastAuditDate OR sst.AuditModifyDateTime > @LastAuditDate)
    )

--Load fact PICC transaction*/
ALTER TABLE Red.FactPICCTransaction NOCHECK CONSTRAINT ALL

--TRUNCATE TABLE Red.FactPICCTransaction

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactPICCTransaction' AND CONSTRAINT_NAME = 'UQ_FactPICCTransaction_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactPICCTransaction
    DROP CONSTRAINT UQ_FactPICCTransaction_LogicalKey
END
  

DELETE picc FROM  RED.[FactPICCTransaction] picc 
WHERE FK_Policy NOT IN (SELECT PK_Policy FROM ODS.Policy)
OR FK_Section NOT IN (SELECT  PK_Section FROM ODS.Section )
OR FK_TriFocus NOT IN (SELECT pk_trifocus FROM ODS.TriFocus)
OR FK_UnderwritingPlatform  NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform )
OR FK_CRMBroker  NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker )
OR FK_Syndicate NOT IN (SELECT pk_Syndicate from ODS.Syndicate)


MERGE [RED].[FactPICCTransaction] target
USING
( 
SELECT
FK_PICCTransaction              = piccoc.FK_PICCTransaction                  
,FK_Syndicate                   = piccoc.FK_Syndicate                        
,FK_ShareType                   = piccoc.FK_ShareType                        
,FK_AcquisitionCostBasis        = piccoc.FK_AcquisitionCostBasis             
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride            
,FK_Date                        = piccoc.FK_Date
,FK_YOA                         = piccoc.FK_YOA
,FK_SettlementCurrency          = piccoc.FK_SettlementCurrency
,FK_OriginalCurrency            = piccoc.FK_OriginalCurrency
,FK_LocalCurrency				= piccoc.FK_LocalCurrency	
,FK_TriFocus                    = piccoc.FK_TriFocus
,FK_CRMBroker                   = piccoc.FK_CRMBroker
,FK_Section                     = piccoc.FK_Section
,FK_Policy                      = piccoc.FK_Policy
,FK_QuoteFilter                 = piccoc.FK_QuoteFilter
,FK_HiddenStatusFilter          = piccoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= piccoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= piccoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= piccoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = piccoc.SpecialPurposeSyndicateApplies                     
,PICCAmount                     = piccoc.PICCAmount                          

FROM 
#PICCTransactionOriginalCurrency piccoc
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Original Currency'

--Premium amounts in settlement currency
UNION ALL
SELECT
 FK_PICCTransaction             = piccoc.FK_PICCTransaction                             
,FK_Syndicate                   = piccoc.FK_Syndicate                                    
,FK_ShareType                   = piccoc.FK_ShareType                                    
,FK_AcquisitionCostBasis        = piccoc.FK_AcquisitionCostBasis              
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride        
,FK_Date                        = piccoc.FK_Date
,FK_YOA                         = piccoc.FK_YOA
,FK_SettlementCurrency          = piccoc.FK_SettlementCurrency
,FK_OriginalCurrency            = piccoc.FK_OriginalCurrency
,FK_LocalCurrency				= piccoc.FK_LocalCurrency	
,FK_TriFocus                    = piccoc.FK_TriFocus
,FK_CRMBroker                   = piccoc.FK_CRMBroker
,FK_Section                     = piccoc.FK_Section
,FK_Policy                      = piccoc.FK_Policy
,FK_QuoteFilter                 = piccoc.FK_QuoteFilter
,FK_HiddenStatusFilter          = piccoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= piccoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= piccoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= piccoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = piccoc.SpecialPurposeSyndicateApplies                                          
,PICCAmount                     = piccoc.PICCAmount / s.OriginalCCYToSettlementCCYRate     
FROM 
#PICCTransactionOriginalCurrency piccoc
INNER JOIN 
ODS.Section s ON 
piccoc.FK_Section = s.PK_Section
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Settlement Currency'


--Premium amounts in LOCAL currency
UNION ALL
SELECT
 FK_PICCTransaction             = piccoc.FK_PICCTransaction                             
,FK_Syndicate                   = piccoc.FK_Syndicate                                    
,FK_ShareType                   = piccoc.FK_ShareType                                    
,FK_AcquisitionCostBasis        = piccoc.FK_AcquisitionCostBasis              
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride        
,FK_Date                        = piccoc.FK_Date
,FK_YOA                         = piccoc.FK_YOA
,FK_SettlementCurrency          = piccoc.FK_SettlementCurrency
,FK_OriginalCurrency            = piccoc.FK_OriginalCurrency
,FK_LocalCurrency				= piccoc.FK_LocalCurrency	
,FK_TriFocus                    = piccoc.FK_TriFocus
,FK_CRMBroker                   = piccoc.FK_CRMBroker
,FK_Section                     = piccoc.FK_Section
,FK_Policy                      = piccoc.FK_Policy
,FK_QuoteFilter                 = piccoc.FK_QuoteFilter
,FK_HiddenStatusFilter          = piccoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= piccoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= piccoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= piccoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = piccoc.SpecialPurposeSyndicateApplies                                          
,PICCAmount                     = piccoc.PICCAmount / s.OriginalCCYToSettlementCCYRate     
FROM 
#PICCTransactionOriginalCurrency piccoc
INNER JOIN 
ODS.Section s ON 
piccoc.FK_Section = s.PK_Section
INNER JOIN 
ODS.Policy p   ON
s.FK_Policy = p.PK_Policy
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Local Currency'
AND p.sourcesystem = 'Unirisx'
and s.BeazleyOfficeLocation = 'Singapore'
) AS  Source
ON  target.FK_PICCTransaction = source.FK_PICCTransaction
AND target.FK_Policy          = source.FK_Policy
AND target.fk_Section         = source.Fk_Section
AND target.FK_Trifocus        = source.Fk_Trifocus
AND target.FK_YOA             = source.FK_YOA
AND ISNULL(target.FK_Syndicate, '') = ISNULL(source.FK_Syndicate, '')
AND target.FK_ShareType       = source. FK_ShareType
AND target.FK_AcquisitionCostBasis = source.FK_AcquisitionCostBasis
AND target.FK_ReportingCurrencyOverride = source.FK_ReportingCurrencyOverride
AND target.FK_Date             = source.FK_Date
AND target.FK_SettlementCurrency =source.FK_SettlementCurrency
AND target.FK_OriginalCurrency = source.FK_OriginalCurrency 
AND target.FK_UnderwritingPlatform = source.FK_UnderwritingPlatform

WHEN MATCHED THEN 
UPDATE 
SET 
 target.FK_LocalCurrency		        = source.FK_LocalCurrency	
,target.FK_CRMBroker                    = source.FK_CRMBroker
,target.FK_QuoteFilter                  = source.FK_QuoteFilter
,target.FK_HiddenStatusFilter           = source.FK_HiddenStatusFilter
,target.FK_InternalWrittenBinderStatus	= source.FK_InternalWrittenBinderStatus
,target.FK_ServiceCompany				= source.FK_ServiceCompany
,target.SpecialPurposeSyndicateApplies  = source.SpecialPurposeSyndicateApplies                     
,target.PICCAmount                      = source.PICCAmount   
,target.AuditModifyDateTime             = GETDATE()
,target.AuditModifyDetails              = 'Merge in [RED].[usp_LoadFactPICCTransaction] proc' 


WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
     FK_PICCTransaction          
    ,FK_Syndicate                  
    ,FK_ShareType                   
    ,FK_AcquisitionCostBasis     
	,FK_ReportingCurrencyOverride
    ,FK_Date                      
    ,FK_YOA                         
    ,FK_SettlementCurrency          
    ,FK_OriginalCurrency            
    ,FK_LocalCurrency			
    ,FK_TriFocus                    
    ,FK_CRMBroker                   
    ,FK_Section                     
    ,FK_Policy                     
    ,FK_QuoteFilter                 
    ,FK_HiddenStatusFilter          
	,FK_UnderwritingPlatform		
	,FK_InternalWrittenBinderStatus	
	,FK_ServiceCompany				
    ,SpecialPurposeSyndicateApplies 
    ,PICCAmount    
	,AuditCreateDateTime   
    ,AuditModifyDetails 
)
VALUES
(
source.FK_PICCTransaction          
,source.FK_Syndicate                  
,source.FK_ShareType                   
,source.FK_AcquisitionCostBasis     
,source.FK_ReportingCurrencyOverride
,source.FK_Date                      
,source.FK_YOA                         
,source.FK_SettlementCurrency          
,source.FK_OriginalCurrency            
,source.FK_LocalCurrency			
,source.FK_TriFocus                    
,source.FK_CRMBroker                   
,source.FK_Section                     
,source.FK_Policy                     
,source.FK_QuoteFilter                 
,source.FK_HiddenStatusFilter          
,source.FK_UnderwritingPlatform		
,source.FK_InternalWrittenBinderStatus	
,source.FK_ServiceCompany				
,source.SpecialPurposeSyndicateApplies 
,source.PICCAmount    		
,GETDATE()
,'New add in [RED].[usp_LoadFactPICCTransaction] proc'
);

     
IF NOT EXISTS
(
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactPICCTransaction' AND CONSTRAINT_NAME = 'UQ_FactPICCTransaction_LogicalKey' 
)
BEGIN
    ALTER TABLE Red.FactPICCTransaction
    ADD CONSTRAINT UQ_FactPICCTransaction_LogicalKey
    UNIQUE
        (
             FK_PICCTransaction
            ,FK_Syndicate
            ,FK_ShareType
            ,FK_AcquisitionCostBasis
            ,FK_ReportingCurrencyOverride
        )
END

ALTER TABLE Red.FactPICCTransaction CHECK CONSTRAINT ALL

IF (OBJECT_ID('tempdb..#PICCTransactionOriginalCurrency') IS NOT NULL) DROP TABLE #PICCTransactionOriginalCurrency;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactPICCTransaction';