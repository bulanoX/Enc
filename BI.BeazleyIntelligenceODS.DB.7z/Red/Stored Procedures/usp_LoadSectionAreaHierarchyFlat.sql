﻿

CREATE PROCEDURE [Red].[usp_LoadSectionAreaHierarchyFlat]
AS

SET NOCOUNT ON


    DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
	FROM		Red.SectionAreaHierarchyFlat

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   Red.AreaHierarchyFlat ahf
            ON  sahf.FK_AreaHierarchyFlat = ahf.PK_AreaHierarchyFlat
    WHERE       ahf.PK_AreaHierarchyFlat IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.CRMBroker crm
            ON  sahf.FK_CRMBroker = crm.PK_CRMBroker
    WHERE       crm.PK_CRMBroker IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.OriginalCurrency oc
            ON  sahf.FK_OriginalCurrency = oc.PK_OriginalCurrency
    WHERE       oc.PK_OriginalCurrency IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.Policy p
            ON  sahf.FK_Policy = p.PK_Policy
    WHERE       p.PK_Policy IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.Section s
            ON  sahf.FK_Section = s.PK_Section
    WHERE       s.PK_Section IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.ServiceCompany sc
            ON  sahf.FK_ServiceCompany = sc.PK_ServiceCompany
    WHERE       sc.PK_ServiceCompany IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.Trifocus t
            ON  sahf.FK_TriFocus = t.PK_TriFocus
    WHERE       t.PK_TriFocus IS NULL

    DELETE      sahf
    FROM        Red.SectionAreaHierarchyFlat sahf --
    LEFT JOIN   ODS.UnderwritingPlatform up
            ON  sahf.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform
    WHERE       up.PK_UnderwritingPlatform IS NULL



    ;MERGE	Red.SectionAreaHierarchyFlat	AS TARGET
		    USING	
		    (
			    SELECT   
                        FK_Section                          =  t.FK_Section          
                        ,FK_AreaHierarchyFlat               =  COALESCE(ah1.PK_AreaHierarchyFlat
                                                                        ,ah2.PK_AreaHierarchyFlat
                                                                        ,ah3.PK_AreaHierarchyFlat)
                        ,FK_Date                            = s.FK_InceptionDate   
                        ,FK_YOA                             = s.FK_YOA
                        ,FK_SettlementCurrency              = s.FK_SettlementCurrency
                        ,FK_OriginalCurrency                = s.FK_OriginalCurrency
                        ,FK_LocalCurrency				    = s.FK_LocalCurrency
                        ,FK_TriFocus                        = s.FK_TriFocus
                        ,FK_Policy                          = s.FK_Policy
                        ,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
                        ,FK_QuoteFilter                     = s.FK_QuoteFilter
                        ,FK_CRMBroker                       = s.FK_CRMBroker
                        ,FK_UnderwritingPlatform		    = s.FK_UnderwritingPlatform
                        ,FK_InternalWrittenBinderStatus	    = s.FK_InternalWrittenBinderStatus
                        ,FK_ServiceCompany				    = s.FK_ServiceCompany
                        ,SpecialPurposeSyndicateApplies     = s.SpecialPurposeSyndicateApplies
                        ,AreaMultiplier                     = t.AreaMultiplier 

                FROM    ODS.SectionTerritory t

                INNER JOIN ODS.Section s 
                        ON t.FK_Section = s.PK_Section

                INNER JOIN ODS.Area a 
                        ON t.FK_Area = a.PK_Area

                LEFT OUTER JOIN Red.AreaHierarchyFlat ah3 
                        ON a.AreaCode = ah3.Level3Code

                LEFT OUTER JOIN Red.AreaHierarchyFlat ah2 
                        ON  a.AreaCode = ah2.Level2Code 
                        AND ah2.Level3Key IS NULL

                LEFT OUTER JOIN Red.AreaHierarchyFlat ah1 
                        ON  a.AreaCode = ah1.Level1Code
                        AND ah1.Level2Key IS NULL
                        AND ah1.Level3Key IS NULL
        
                WHERE   ((t.AuditModifyDateTime > @LastAuditDate     OR      t.AuditCreateDateTime > @LastAuditDate)
                    OR  (s.AuditModifyDateTime > @LastAuditDate     OR      s.AuditCreateDateTime > @LastAuditDate)
                    OR  (a.AuditModifyDateTime > @LastAuditDate     OR      a.AuditCreateDateTime > @LastAuditDate)
                    OR  (s.AuditModifyDateTime > @LastAuditDate     OR      s.AuditCreateDateTime > @LastAuditDate)
                    OR  (ah3.AuditModifyDateTime > @LastAuditDate   OR    ah3.AuditCreateDateTime > @LastAuditDate))
                    AND (ah1. pK_AreaHierarchyFlat IS NOT NULL OR ah2. pK_AreaHierarchyFlat IS NOT NULL OR ah3. pK_AreaHierarchyFlat IS NOT NULL)
                )
                AS SOURCE

                 ON		TARGET.FK_Section             = SOURCE.FK_Section
                    AND TARGET.FK_AreaHierarchyFlat   = SOURCE.FK_AreaHierarchyFlat

    WHEN	MATCHED THEN
		    UPDATE	
		    SET	 TARGET.FK_Section                          = SOURCE.FK_Section            
                ,TARGET.FK_AreaHierarchyFlat                = SOURCE.FK_AreaHierarchyFlat 
                ,TARGET.FK_Date                             = SOURCE.FK_Date    
                ,TARGET.FK_YOA                              = SOURCE.FK_YOA
                ,TARGET.FK_SettlementCurrency               = SOURCE.FK_SettlementCurrency
                ,TARGET.FK_OriginalCurrency                 = SOURCE.FK_OriginalCurrency
                ,TARGET.FK_LocalCurrency				    = SOURCE.FK_LocalCurrency
                ,TARGET.FK_TriFocus                         = SOURCE.FK_TriFocus
                ,TARGET.FK_Policy                           = SOURCE.FK_Policy
                ,TARGET.FK_HiddenStatusFilter               = SOURCE.FK_HiddenStatusFilter
                ,TARGET.FK_QuoteFilter                      = SOURCE.FK_QuoteFilter
                ,TARGET.FK_CRMBroker                        = SOURCE.FK_CRMBroker
                ,TARGET.FK_UnderwritingPlatform		        = SOURCE.FK_UnderwritingPlatform
                ,TARGET.FK_InternalWrittenBinderStatus	    = SOURCE.FK_InternalWrittenBinderStatus
                ,TARGET.FK_ServiceCompany				    = SOURCE.FK_ServiceCompany
                ,TARGET.SpecialPurposeSyndicateApplies      = SOURCE.SpecialPurposeSyndicateApplies
                ,TARGET.AreaMultiplier                      = SOURCE.AreaMultiplier 
                ,TARGET.AuditModifyDateTime                 = GETDATE()
                ,TARGET.AuditModifyDetails                  = 'Merge in Red.usp_LoadSectionAreaHierarchyFlat' 

    WHEN    NOT MATCHED BY TARGET THEN
            INSERT
            (
                FK_Section                               
                ,FK_AreaHierarchyFlat               
                ,FK_Date                            
                ,FK_YOA                             
                ,FK_SettlementCurrency              
                ,FK_OriginalCurrency                
                ,FK_LocalCurrency				    
                ,FK_TriFocus                        
                ,FK_Policy                          
                ,FK_HiddenStatusFilter              
                ,FK_QuoteFilter                     
                ,FK_CRMBroker                       
                ,FK_UnderwritingPlatform		   
                ,FK_InternalWrittenBinderStatus	   
                ,FK_ServiceCompany				    
                ,SpecialPurposeSyndicateApplies     
                ,AreaMultiplier   
                ,AuditCreateDateTime
                ,AuditModifyDetails
            )
            VALUES
            (
                 SOURCE.FK_Section                               
                ,SOURCE.FK_AreaHierarchyFlat               
                ,SOURCE.FK_Date                            
                ,SOURCE.FK_YOA                             
                ,SOURCE.FK_SettlementCurrency              
                ,SOURCE.FK_OriginalCurrency                
                ,SOURCE.FK_LocalCurrency				    
                ,SOURCE.FK_TriFocus                        
                ,SOURCE.FK_Policy                          
                ,SOURCE.FK_HiddenStatusFilter              
                ,SOURCE.FK_QuoteFilter                     
                ,SOURCE.FK_CRMBroker                       
                ,SOURCE.FK_UnderwritingPlatform		   
                ,SOURCE.FK_InternalWrittenBinderStatus	   
                ,SOURCE.FK_ServiceCompany				    
                ,SOURCE.SpecialPurposeSyndicateApplies     
                ,SOURCE.AreaMultiplier  
                ,GETDATE()
                ,'New add in Red.usp_LoadSectionAreaHierarchyFlat' 
            )
    ;



    DELETE 
    FROM    Red.AreaHierarchyFlat 
    WHERE   PK_AreaHierarchyFlat NOT IN (SELECT FK_AreaHierarchyFlat FROM Red.SectionAreaHierarchyFlat);


    EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'SectionAreaHierarchyFlat'; 