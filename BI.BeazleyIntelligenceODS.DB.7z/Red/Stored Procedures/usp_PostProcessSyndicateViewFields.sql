﻿CREATE PROC [Red].[usp_PostProcessSyndicateViewFields]
AS

SET NOCOUNT ON
 
DROP TABLE IF EXISTS #Section
CREATE TABLE #Section
(
	PK_Section BIGINT NULL
	,SyndicateViewMultiplier NUMERIC(19,12)
)

INSERT INTO #Section
(
	PK_Section
	,SyndicateViewMultiplier
)
SELECT 
	PK_Section					= s.PK_Section
	,SyndicateViewMultiplier	= s.SyndicateViewMultiplier
	
FROM ODS.Section s


DROP TABLE IF EXISTS #FactClaimMovement
CREATE TABLE #FactClaimMovement
(
	 ToDateTotalPaid_SyndicateView			NUMERIC (21, 4)  NULL
	,ToDateTotalOutstanding_SyndicateView	NUMERIC (21, 4)  NULL
	,ToDateTotalIncurred_SyndicateView		NUMERIC (24, 4)  NULL
	,MovementTotalPaid_SyndicateView		 NUMERIC (21, 4)  NULL
	,MovementTotalOutstanding_SyndicateView	 NUMERIC (21, 4)  NULL
	,MovementTotalIncurred_SyndicateView	 NUMERIC (24, 4)  NULL
	,SyndicateViewMultiplier			      NUMERIC (19, 12) NULL
	,FK_ClaimMovement                         BIGINT NULL
	,FK_EntityPerspective					  BIGINT NULL
	,FK_Section								  BIGINT NULL
	,FK_Syndicate							  BIGINT NULL
	,FK_SlipLineNumber						  BIGINT NULL
	,FK_ShareType							  BIGINT NULL
	,FK_ReportingCurrencyOverride			  BIGINT NULL

)

INSERT INTO #FactClaimMovement
(
	 ToDateTotalPaid_SyndicateView			
	,ToDateTotalOutstanding_SyndicateView	
	,ToDateTotalIncurred_SyndicateView		
	,MovementTotalPaid_SyndicateView		
	,MovementTotalOutstanding_SyndicateView	
	,MovementTotalIncurred_SyndicateView	
	,SyndicateViewMultiplier			    
	,FK_ClaimMovement                       
	,FK_EntityPerspective					
	,FK_Section								
	,FK_Syndicate							
	,FK_SlipLineNumber						
	,FK_ShareType							
	,FK_ReportingCurrencyOverride			
)

SELECT
	ToDateTotalPaid_SyndicateView				= fcm.ToDateTotalPaid			* ISNULL(s.SyndicateViewMultiplier, 1)
	,ToDateTotalOutstanding_SyndicateView		= fcm.ToDateTotalOutstanding	* ISNULL(s.SyndicateViewMultiplier, 1)
	,ToDateTotalIncurred_SyndicateView			= fcm.ToDateTotalIncurred		* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementTotalPaid_SyndicateView			= fcm.MovementTotalPaid			* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementTotalOutstanding_SyndicateView		= fcm.MovementTotalOutstanding	* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementTotalIncurred_SyndicateView		= fcm.MovementTotalIncurred		* ISNULL(s.SyndicateViewMultiplier, 1)
	,SyndicateViewMultiplier					= s.SyndicateViewMultiplier
	,FK_ClaimMovement
	,FK_EntityPerspective
	,FK_Section
	,FK_Syndicate
	,FK_SlipLineNumber
	,FK_ShareType
	,FK_ReportingCurrencyOverride
	
FROM 
	(
		SELECT
			 FK_Section
			,ToDateTotalPaid
			,ToDateTotalOutstanding
			,ToDateTotalIncurred	
			,MovementTotalOutstanding_SyndicateView		
			,MovementTotalPaid			
			,MovementTotalOutstanding	
			,MovementTotalIncurred		
			
			,SyndicateViewMultiplier
			,FK_ClaimMovement
			,FK_EntityPerspective
			,FK_Syndicate
			,FK_SlipLineNumber
			,FK_ShareType
			,FK_ReportingCurrencyOverride
		FROM red.FactClaimMovement 
		WHERE FK_EntityPerspective = 3
	) fcm

INNER JOIN #Section s 
ON s.PK_Section = fcm.FK_Section

CREATE NONCLUSTERED INDEX [IDX_FactClaimMovement] ON #FactClaimMovement ([FK_EntityPerspective] ASC) INCLUDE ([FK_ClaimMovement] ,  [FK_Section] , [FK_Syndicate] , [FK_SlipLineNumber] , [FK_ShareType] , [FK_ReportingCurrencyOverride] ) WITH (FILLFACTOR = 90)



UPDATE  TARGET SET 
  TARGET.ToDateTotalPaid_SyndicateView			  = SOURCE.ToDateTotalPaid_SyndicateView
 ,TARGET.ToDateTotalOutstanding_SyndicateView	  = SOURCE.ToDateTotalOutstanding_SyndicateView
 ,TARGET.ToDateTotalIncurred_SyndicateView        = SOURCE.ToDateTotalIncurred_SyndicateView
 ,TARGET.MovementTotalPaid_SyndicateView		  = SOURCE.MovementTotalPaid_SyndicateView
 ,TARGET.MovementTotalOutstanding_SyndicateView   = SOURCE.MovementTotalOutstanding_SyndicateView
 ,TARGET.MovementTotalIncurred_SyndicateView      = SOURCE.MovementTotalIncurred_SyndicateView
 ,TARGET.SyndicateViewMultiplier				  = SOURCE.SyndicateViewMultiplier
  FROM RED.FactClaimMovement TARGET
INNER JOIN  #FactClaimMovement source
ON target.FK_Section = source.FK_Section
AND target.FK_ClaimMovement = source.FK_ClaimMovement
AND target.FK_EntityPerspective = source.FK_EntityPerspective
AND target.FK_Syndicate = source.FK_Syndicate
AND target.FK_SlipLineNumber = source.FK_SlipLineNumber
AND target.FK_ShareType = source.FK_ShareType
AND target.FK_ReportingCurrencyOverride = source.FK_ReportingCurrencyOverride
AND target.FK_EntityPerspective = source.FK_EntityPerspective
 ;


DROP TABLE IF EXISTS #FactClaimExposure
CREATE TABLE #FactClaimExposure
(
	 MovementMostLikely_SyndicateView		     NUMERIC (38, 4)  NULL
	,MovementPessimistic_SyndicateView			 NUMERIC (38, 4)  NULL
	,MovementExpectedRecoveries_SyndicateView	 NUMERIC (38, 4)  NULL
	,MovementPrePeerBlend_SyndicateView			 NUMERIC (38, 4)  NULL
	,SyndicateViewMultiplier					 NUMERIC (19, 12) NULL
	,FK_EntityPerspective                        BIGINT NULL
	,FK_ReportingCurrencyOverride                BIGINT NULL
	,FK_ShareType                                BIGINT NULL
	,FK_ClaimExposure							 BIGINT NULL
	,FK_Section									 BIGINT NULL
	,FK_Syndicate								 BIGINT NULL
	,FK_SlipLineNumber							 BIGINT NULL
	,ClaimMovementPartition						 INT NULL
	

)

INSERT INTO #FactClaimExposure
(
	 MovementMostLikely_SyndicateView		
	,MovementPessimistic_SyndicateView		
	,MovementExpectedRecoveries_SyndicateView
	,MovementPrePeerBlend_SyndicateView		
	,SyndicateViewMultiplier				
	,FK_EntityPerspective
	,FK_ReportingCurrencyOverride
	,FK_ShareType
	,FK_ClaimExposure
	,FK_Section
	,FK_Syndicate
	,FK_SlipLineNumber
	,ClaimMovementPartition
	
)

SELECT
     MovementMostLikely_SyndicateView			= fce.MovementMostLikely			* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementPessimistic_SyndicateView			= fce.MovementPessimistic			* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementExpectedRecoveries_SyndicateView	= fce.MovementExpectedRecoveries	* ISNULL(s.SyndicateViewMultiplier, 1)
	,MovementPrePeerBlend_SyndicateView			= fce.MovementPrePeerBlend			* ISNULL(s.SyndicateViewMultiplier, 1)
	,SyndicateViewMultiplier					= s.SyndicateViewMultiplier
	,FK_EntityPerspective
	,FK_ReportingCurrencyOverride
	,FK_ShareType
	,FK_ClaimExposure
	,FK_Section
	,FK_Syndicate
	,FK_SlipLineNumber
	,ClaimMovementPartition
FROM 
	(
		SELECT
			FK_Section
			,MovementMostLikely			
			,MovementPessimistic			
			,MovementExpectedRecoveries	
			,MovementPrePeerBlend			
			,SyndicateViewMultiplier
			,FK_EntityPerspective
			,FK_ReportingCurrencyOverride
			,FK_ShareType
			,FK_ClaimExposure
			,FK_Syndicate
			,FK_SlipLineNumber
			,ClaimMovementPartition
		FROM red.FactClaimExposure 
		WHERE FK_EntityPerspective = 3
	) fce

INNER JOIN #Section s 
ON s.PK_Section = fce.FK_Section

CREATE NONCLUSTERED INDEX [IDX_#FactClaimExposure] ON #FactClaimExposure ([FK_EntityPerspective] ASC, [FK_Section] ASC ) INCLUDE ( [FK_ReportingCurrencyOverride] , [FK_ShareType] , [FK_ClaimExposure] , [FK_Syndicate] , [FK_SlipLineNumber] , [ClaimMovementPartition] ) WITH (FILLFACTOR = 90)


UPDATE TARGET SET 
  TARGET.MovementMostLikely_SyndicateView			     = SOURCE.MovementMostLikely_SyndicateView
 ,TARGET.MovementPessimistic_SyndicateView				 = SOURCE.MovementPessimistic_SyndicateView
 ,TARGET.MovementExpectedRecoveries_SyndicateView        = SOURCE.MovementExpectedRecoveries_SyndicateView
 ,TARGET.MovementPrePeerBlend_SyndicateView				 = SOURCE.MovementPrePeerBlend_SyndicateView
,TARGET.SyndicateViewMultiplier							 = SOURCE.SyndicateViewMultiplier
FROM RED.FactClaimExposure target
INNER JOIN  #FactClaimExposure source
ON target.FK_EntityPerspective = source.FK_EntityPerspective
AND target.FK_ReportingCurrencyOverride = source.FK_ReportingCurrencyOverride
AND target.FK_ShareType = source.FK_ShareType
AND target.FK_ClaimExposure = source.FK_ClaimExposure
AND target.FK_Section = source.FK_Section
AND target.FK_Syndicate = source.FK_Syndicate
AND target.FK_SlipLineNumber = source.FK_SlipLineNumber
AND target.ClaimMovementPartition = source.ClaimMovementPartition

 ;
