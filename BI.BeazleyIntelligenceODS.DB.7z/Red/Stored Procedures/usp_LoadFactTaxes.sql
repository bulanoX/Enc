﻿CREATE PROCEDURE [Red].[usp_LoadFactTaxes]
AS

DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
FROM		Red.FactTaxes

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');


/***************************************************************************************/
/*                        Share type                                                   */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType

CREATE TABLE #SectionShareType
(
    FK_Section                       bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
    ,TotalLineMultiplier            numeric(19,12)      NULL
)



INSERT INTO #SectionShareType
(
     FK_Section
    ,FK_ShareType
    ,FK_Syndicate
    ,TotalLineMultiplier
)

SELECT
FK_Section              = s.PK_Section     
,FK_ShareType           = st.PK_ShareType
,FK_Syndicate           = NULL                                      
,TotalLineMultiplier    = CASE st.ShareTypeName 
                            WHEN 'Total Order' THEN 1
                            WHEN 'Slip Order'  THEN s.WrittenIfNotSignedOrderMultiplier
                          END
FROM 
ODS.Section s
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName IN ('Total Order','Slip Order')

UNION ALL

SELECT
FK_Section             = sl.FK_Section                       
,FK_ShareType          = st.PK_ShareType                 
,FK_Syndicate          = sl.FK_Syndicate 
,TotalLineMultiplier   = sl.WrittenIfNotSignedLineMultiplier 
                        * s.WrittenIfNotSignedOrderMultiplier 
                        * CASE 
                            WHEN s.IsSigned = 0 
                            THEN s.EstimatedSigningMultiplier 
                            ELSE 1
                          END
FROM 
ODS.SectionLine sl
INNER JOIN
ODS.Section s ON
sl.FK_Section = s.PK_Section
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName = 'Beazley Share'

IF (OBJECT_ID('tempdb..#TaxesCurrency') IS NOT NULL) DROP TABLE #TaxesCurrency

CREATE TABLE #TaxesCurrency
(   
    PK_Taxes                        bigint              NOT NULL 
   ,FK_Section                      bigint              NOT NULL
   ,FK_Syndicate                    bigint              NULL
   ,FK_ShareType                    bigint              NOT NULL
   ,FK_Date                         datetime            NOT NULL
   ,FK_YOA                          bigint              NOT NULL
   ,FK_SettlementCurrency           bigint              NULL
   ,FK_OriginalCurrency             bigint              NULL
   ,FK_TriFocus                     bigint              NOT NULL
   ,FK_CRMBroker                    bigint              NOT NULL
   ,FK_Policy                       bigint              NOT NULL
   ,FK_QuoteFilter                  bigint              NOT NULL
   ,FK_HiddenStatusFilter           bigint              NOT NULL
   ,FK_UnderwritingPlatform			bigint				NOT NULL
   ,FK_InternalWrittenBinderStatus	bigint				NOT NULL
   ,FK_ServiceCompany				bigint				NOT NULL
   ,FK_LocalCurrency				bigint              NOT NULL
   ,TaxableAmount                   DECIMAL (38, 12)     NULL
   ,Tax                             NUMERIC (38 ,12)     NULL
   ,TaxRate                         NUMERIC (38 ,12)     NULL
   ,OriginalCCYToSettlementCCYRate	NUMERIC (38, 4) 	 NULL
   )
   INSERT INTO #TaxesCurrency
   (
   PK_Taxes
  ,FK_Section                    
  ,FK_Syndicate                  
  ,FK_ShareType                  
  ,FK_Date                       
  ,FK_YOA                        
  ,FK_SettlementCurrency         
  ,FK_OriginalCurrency           
  ,FK_TriFocus                   
  ,FK_CRMBroker                  
  ,FK_Policy                     
  ,FK_QuoteFilter                
  ,FK_HiddenStatusFilter         
  ,FK_UnderwritingPlatform			
  ,FK_InternalWrittenBinderStatus
  ,FK_ServiceCompany				
  ,FK_LocalCurrency				
  ,TaxableAmount
  ,Tax     
  ,TaxRate 
  ,OriginalCCYToSettlementCCYRate  

  )
  SELECT 
   t.PK_Taxes
  ,t.FK_Section              
  ,FK_Syndicate                     = sst.FK_Syndicate                     
  ,FK_ShareType                     = sst.FK_ShareType                   
  ,FK_Date                          = s.FK_InceptionDate
  ,FK_YOA                           = s.FK_YOA
  ,FK_SettlementCurrency            = CASE WHEN s.SourceSystem <> 'Eurobase' 
                                         THEN s.FK_SettlementCurrency
                                         ELSE sce.PK_SettlementCurrency--ISNULL(sce.PK_SettlementCurrency,0)
									  END									  
  ,FK_OriginalCurrency              = CASE WHEN s.SourceSystem <> 'Eurobase' 
                                         THEN s.FK_LimitCurrency
                                         ELSE oce.PK_OriginalCurrency --ISNULL(oce.PK_OriginalCurrency,0)
									  END									
  ,FK_TriFocus                      = s.FK_TriFocus
  ,FK_CRMBroker                     = s.FK_CRMBroker
  ,FK_Policy                        = s.FK_Policy
  ,FK_QuoteFilter                   = s.FK_QuoteFilter
  ,FK_HiddenStatusFilter            = s.FK_HiddenStatusFilter
  ,FK_UnderwritingPlatform		    = s.FK_UnderwritingPlatform
  ,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
  ,FK_ServiceCompany			 	= s.FK_ServiceCompany
  ,FK_LocalCurrency				    = ISNULL(s.FK_LocalCurrency,0)
  ,TaxableAmount                    = t.TaxableAmount               * sst.TotalLineMultiplier    
  ,Tax                              = t.Tax                         * sst.TotalLineMultiplier
  ,TaxRate                          = t.TaxRate              --       * sst.TotalLineMultiplier
  ,OriginalCCYToSettlementCCYRate   = t.OriginalCCYToSettlementCCYRate
  FROM
  ODS.Taxes t
   INNER JOIN ODS.Section s  
  ON s.PK_Section =  t.FK_Section
  INNER JOIN ODS.OriginalCurrency oc 
  ON s.FK_OriginalCurrency = oc.PK_OriginalCurrency
  INNER JOIN 
  #SectionShareType sst ON 
  t.FK_Section = sst.FK_Section
  LEFT JOIN ODS.OriginalCurrency oce
  ON t.OriginalCurrency	= oce.CurrencyCode
  LEFT JOIN ODS.SettlementCurrency sce
  ON t.SettlementCurrency	= sce.CurrencyCode
  WHERE (t.AuditModifyDateTime	 > @LastAuditDate OR t.AuditCreateDateTime	 > @LastAuditDate)
     OR (s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
	 
  DELETE FROM #TaxesCurrency WHERE FK_SettlementCurrency IS NULL OR FK_OriginalCurrency  IS NULL
  
  DELETE FROM Red.FactTaxes WHERE FK_Section not in (select PK_Section from ODS.Section)
  DELETE FROM Red.FactTaxes WHERE FK_Policy not in (select PK_Policy from ODS.Policy)
  DELETE FROM Red.FactTaxes WHERE FK_UnderwritingPlatform NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform)
  DELETE FROM Red.FactTaxes WHERE FK_CRMBroker NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker)

  DELETE FROM Red.FactTaxes WHERE FK_Taxes not in (select PK_Taxes from ODS.Taxes)
 
---** Disabling Constraints
 ALTER TABLE Red.FactTaxes NOCHECK CONSTRAINT ALL;
--**** 


  MERGE Red.FactTaxes AS TARGET

  USING ( 
	--Taxes amounts in original currency
	SELECT
	 FK_taxes                       = tc.PK_taxes
	,FK_Section					    = tc.FK_Section	               
	,FK_Syndicate                   = tc.FK_Syndicate
	,FK_ShareType                   = tc.FK_ShareType
	,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride                 
	,FK_Date                        = tc.FK_Date
	,FK_YOA                         = tc.FK_YOA
	,FK_SettlementCurrency          = tc.FK_SettlementCurrency
	,FK_OriginalCurrency            = tc.FK_OriginalCurrency
	,FK_TriFocus                    = tc.FK_TriFocus
	,FK_CRMBroker                   = tc.FK_CRMBroker
	,FK_Policy                      = tc.FK_Policy
	,FK_QuoteFilter                 = tc.FK_QuoteFilter
	,FK_HiddenStatusFilter          = tc.FK_HiddenStatusFilter
	,FK_UnderwritingPlatform		= tc.FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus = tc.FK_InternalWrittenBinderStatus
	,FK_ServiceCompany			    = tc.FK_ServiceCompany
	,FK_LocalCurrency				= tc.FK_LocalCurrency
	,TaxableAmount                  = tc.TaxableAmount
	,Tax                            = tc.Tax
	,TaxRate                        = tc.TaxRate
	FROM 
	#TaxesCurrency tc
	CROSS JOIN 
	Red.ReportingCurrencyOverride rco 
	WHERE 
	rco.ReportingCurrencyOverrideName = 'Original Currency'
	

	UNION 

	--Taxes amounts in settlement currency
	SELECT
	FK_taxes                        = tc.PK_taxes
	,FK_Section					    = tc.FK_Section	               
	,FK_Syndicate                   = tc.FK_Syndicate
	,FK_ShareType                   = tc.FK_ShareType
	,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride                 
	,FK_Date                        = tc.FK_Date
	,FK_YOA                         = tc.FK_YOA
	,FK_SettlementCurrency          = tc.FK_SettlementCurrency
	,FK_OriginalCurrency            = tc.FK_OriginalCurrency
	,FK_TriFocus                    = tc.FK_TriFocus
	,FK_CRMBroker                   = tc.FK_CRMBroker
	,FK_Policy                      = tc.FK_Policy
	,FK_QuoteFilter                 = tc.FK_QuoteFilter
	,FK_HiddenStatusFilter          = tc.FK_HiddenStatusFilter
	,FK_UnderwritingPlatform		= tc.FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus = tc.FK_InternalWrittenBinderStatus
	,FK_ServiceCompany			    = tc.FK_ServiceCompany
	,FK_LocalCurrency				= tc.FK_LocalCurrency
	,TaxableAmount                  = CASE WHEN s.SourceSystem <> 'Eurobase' 
											THEN tc.TaxableAmount/ NULLIF(s.LimitCCYToSettlementCCYRate, 0) 
											ELSE tc.TaxableAmount/ NULLIF(tc.OriginalCCYToSettlementCCYRate, 0) 
										END
	,Tax                            = tc.Tax/ NULLIF(s.LimitCCYToSettlementCCYRate, 0) 
	,TaxRate                        = tc.TaxRate
	FROM 
	#TaxesCurrency tc
	INNER JOIN 
	ODS.Section s   ON
	tc.FK_Section = s.PK_Section
	CROSS JOIN 
	Red.ReportingCurrencyOverride rco 
	WHERE 
	rco.ReportingCurrencyOverrideName = 'Settlement Currency'

	/*** SGP Enabled - Start ***/
	--Taxes amounts in LOCAL currency 
	UNION 
  
	SELECT
	FK_taxes = tc.PK_taxes
	,FK_Section					    = tc.FK_Section	               
	,FK_Syndicate                   = tc.FK_Syndicate
	,FK_ShareType                   = tc.FK_ShareType
	,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride                 
	,FK_Date                        = tc.FK_Date
	,FK_YOA                         = tc.FK_YOA
	,FK_SettlementCurrency          = tc.FK_SettlementCurrency
	,FK_OriginalCurrency            = tc.FK_OriginalCurrency
	,FK_TriFocus                    = tc.FK_TriFocus
	,FK_CRMBroker                   = tc.FK_CRMBroker
	,FK_Policy                      = tc.FK_Policy
	,FK_QuoteFilter                 = tc.FK_QuoteFilter
    ,FK_HiddenStatusFilter          = tc.FK_HiddenStatusFilter
    ,FK_UnderwritingPlatform		= tc.FK_UnderwritingPlatform
    ,FK_InternalWrittenBinderStatus = tc.FK_InternalWrittenBinderStatus
    ,FK_ServiceCompany			    = tc.FK_ServiceCompany
    ,FK_LocalCurrency				= tc.FK_LocalCurrency
    ,TaxableAmount                  = tc.TaxableAmount/ NULLIF(s.OriginalCCYToLocalCCYRate, 0)   
    ,Tax                            = tc.Tax / NULLIF(s.OriginalCCYToLocalCCYRate, 0) 
    ,TaxRate                        = tc.TaxRate


FROM 
#TaxesCurrency tc
INNER JOIN 
ODS.Section s   ON
tc.FK_Section = s.PK_Section
INNER JOIN 
ODS.Policy p   ON
s.FK_Policy = p.PK_Policy
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Local Currency'
) AS SOURCE

  ON TARGET.FK_taxes                       = SOURCE.FK_taxes
 AND TARGET.FK_Section			           = SOURCE.FK_Section	               
 AND ISNULL(TARGET.FK_Syndicate, 0)        = ISNULL(SOURCE.FK_Syndicate, 0)
 AND TARGET.FK_ShareType                   = SOURCE.FK_ShareType
 AND TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride    
 

WHEN MATCHED THEN

UPDATE SET 
   TARGET.FK_taxes                       = SOURCE.FK_taxes
  ,TARGET.FK_Section			         = SOURCE.FK_Section	               
  ,TARGET.FK_Syndicate                   = SOURCE.FK_Syndicate
  ,TARGET.FK_ShareType                   = SOURCE.FK_ShareType
  ,TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride                 
  ,TARGET.FK_Date                        = SOURCE.FK_Date
  ,TARGET.FK_YOA                         = SOURCE.FK_YOA
  ,TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
  ,TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
  ,TARGET.FK_TriFocus                    = SOURCE.FK_TriFocus
  ,TARGET.FK_CRMBroker                   = SOURCE.FK_CRMBroker
  ,TARGET.FK_Policy                      = SOURCE.FK_Policy
  ,TARGET.FK_QuoteFilter                 = SOURCE.FK_QuoteFilter
  ,TARGET.FK_HiddenStatusFilter          = SOURCE.FK_HiddenStatusFilter
  ,TARGET.FK_UnderwritingPlatform        = SOURCE.FK_UnderwritingPlatform
  ,TARGET.FK_InternalWrittenBinderStatus = SOURCE.FK_InternalWrittenBinderStatus
  ,TARGET.FK_ServiceCompany		         = SOURCE.FK_ServiceCompany
  ,TARGET.FK_LocalCurrency		         = SOURCE.FK_LocalCurrency
  ,TARGET.TaxableAmount                  = SOURCE.TaxableAmount
  ,TARGET.Tax                            = SOURCE.Tax
  ,TARGET.TaxRate                        = SOURCE.TaxRate
  ,TARGET.AuditModifyDateTime            = GETDATE()
  ,TARGET.AuditModifyDetails             = 'Merge in [RED].[FactTaxes] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
      FK_taxes                     
     ,FK_Section			  
     ,FK_Syndicate                 
     ,FK_ShareType                 
     ,FK_ReportingCurrencyOverride 
     ,FK_Date                      
     ,FK_YOA                       
     ,FK_SettlementCurrency        
     ,FK_OriginalCurrency          
     ,FK_TriFocus                  
     ,FK_CRMBroker                 
     ,FK_Policy                    
     ,FK_QuoteFilter               
     ,FK_HiddenStatusFilter        
     ,FK_UnderwritingPlatform      
     ,FK_InternalWrittenBinderStatus
     ,FK_ServiceCompany		  
     ,FK_LocalCurrency		  
     ,TaxableAmount                
     ,Tax                          
     ,TaxRate                      
     ,AuditModifyDetails

)
VALUES
(
     SOURCE.FK_taxes                     
	,SOURCE.FK_Section			  
	,SOURCE.FK_Syndicate                 
	,SOURCE.FK_ShareType                 
	,SOURCE.FK_ReportingCurrencyOverride 
	,SOURCE.FK_Date                      
	,SOURCE.FK_YOA                       
	,SOURCE.FK_SettlementCurrency        
	,SOURCE.FK_OriginalCurrency          
	,SOURCE.FK_TriFocus                  
	,SOURCE.FK_CRMBroker                 
	,SOURCE.FK_Policy                    
	,SOURCE.FK_QuoteFilter               
	,SOURCE.FK_HiddenStatusFilter        
	,SOURCE.FK_UnderwritingPlatform      
	,SOURCE.FK_InternalWrittenBinderStatus
	,SOURCE.FK_ServiceCompany		  
	,SOURCE.FK_LocalCurrency		  
	,SOURCE.TaxableAmount                
	,SOURCE.Tax                          
	,SOURCE.TaxRate                      
	,'New in [RED].[FactTaxes] table' 
)
--WHEN NOT MATCHED BY SOURCE THEN DELETE
;


---** Enabling Constraints
 ALTER TABLE Red.FactTaxes CHECK CONSTRAINT ALL;
--****

IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType
IF (OBJECT_ID('tempdb..#TaxesCurrency') IS NOT NULL) DROP TABLE #TaxesCurrency;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactTaxes';
