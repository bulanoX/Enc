﻿CREATE PROC [Red].[usp_LoadFactClaimDeductibleTracking]
AS

SET NOCOUNT ON

/*
    To convert from deductible currency to exposure original currency:
    If ded ccy = orig ccy, do nothing
    If ded ccy = sett ccy, use incurred rate
    If neither, use current rate
    
    Then use the incurred rate to convert from orig ccy to sett ccy
*/

/*Attach deductibles to first exposure*/

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM RED.FactClaimDeductibleTracking
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF (OBJECT_ID('tempdb..#ClaimExposureMapping') IS NOT NULL)
DROP TABLE #ClaimExposureMapping

CREATE TABLE #ClaimExposureMapping
(
    FK_Claim            bigint          NOT NULL
    ,FK_ClaimExposure   bigint          NOT NULL
    PRIMARY KEY (FK_Claim)
)

INSERT INTO #ClaimExposureMapping
(
    FK_Claim
    ,FK_ClaimExposure
)
SELECT 
FK_Claim            = c.PK_Claim
,FK_ClaimExposure   = ce.PK_ClaimExposure
FROM
ODS.Claim c
INNER JOIN
(
    SELECT
    FK_Claim            = ce.FK_Claim
    ,ExposureSequenceId = MIN(ce.ExposureSequenceId)
    FROM
    ODS.ClaimExposure ce
    GROUP BY
    ce.FK_Claim
) x ON
c.PK_Claim = x.FK_Claim
INNER JOIN
ODS.ClaimExposure ce ON
c.PK_Claim = ce.FK_Claim
AND ce.ExposureSequenceId = x.ExposureSequenceId --Take the first exposure
WHERE ISNULL(c.AuditModifyDateTime,c.AuditCreateDateTime) > @LastAuditDate
OR ISNULL(ce.AuditModifyDateTime,ce.AuditCreateDateTime) > @LastAuditDate

IF (OBJECT_ID('tempdb..#DeductibleRates') IS NOT NULL)
DROP TABLE #DeductibleRates

CREATE TABLE #DeductibleRates
(   
    FK_ClaimExposure                    bigint              NOT NULL
    ,OriginalCCY                        varchar(255)        NOT NULL
    ,SettlementCCY                      varchar(255)        NOT NULL
    ,DeductibleCCY                      varchar(255)        NOT NULL
    ,TotalIncurredInOriginalCCY         numeric(19,4)       NOT NULL
    ,TotalIncurredInSettlementCCY       numeric(19,4)       NULL
    ,OriginalCCYToSettlementCCYRate     numeric(38,12)      NULL
    ,OriginalCCYToDeductibleCCYRate     numeric(38,12)      NULL
)

INSERT INTO #DeductibleRates
(
    FK_ClaimExposure
    ,OriginalCCY
    ,SettlementCCY
    ,DeductibleCCY
    ,TotalIncurredInOriginalCCY
    ,TotalIncurredInSettlementCCY
)
SELECT
FK_ClaimExposure                    = ce.PK_ClaimExposure
,OriginalCCY                        = oc.CurrencyCode
,SettlementCCY                      = sc.CurrencyCode
,DeductibleCCY                      = c.DeductibleCCY
,TotalIncurredInOriginalCCY         = y.TotalIncurredInOriginalCCY
,TotalIncurredInSettlementCCY       = z.TotalIncurredInSettlementCCY
FROM
ODS.Claim c
INNER JOIN
#ClaimExposureMapping map ON
c.PK_Claim = map.FK_Claim
INNER JOIN
ODS.ClaimExposure ce ON
map.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN
ODS.SettlementCurrency sc ON
ce.FK_LastMovementSettlementCurrency = sc.PK_SettlementCurrency
INNER JOIN
ODS.OriginalCurrency oc ON
ce.FK_LastMovementOriginalCurrency= oc.PK_OriginalCurrency
INNER JOIN
(
    SELECT
    FK_ClaimExposure                    = fce.FK_ClaimExposure
    ,TotalIncurredInOriginalCCY         = SUM(fce.TotalIncurred)
    FROM
    Red.FactClaimExposure fce
    INNER JOIN
    Red.ShareType st ON
    fce.FK_ShareType = st.PK_ShareType
    AND st.ShareTypeName = 'Total Order'
    INNER JOIN
    Red.ReportingCurrencyOverride rco ON
    fce.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride
    AND rco.ReportingCurrencyOverrideName = 'Original Currency'
    GROUP BY
    fce.FK_ClaimExposure
) y ON
ce.PK_ClaimExposure = y.FK_ClaimExposure
INNER JOIN
(
    SELECT
    FK_ClaimExposure                    = fce.FK_ClaimExposure
    ,TotalIncurredInSettlementCCY       = SUM(fce.TotalIncurred)
    FROM
    Red.FactClaimExposure fce
    INNER JOIN
    Red.ShareType st ON
    fce.FK_ShareType = st.PK_ShareType
    AND st.ShareTypeName = 'Total Order'
    INNER JOIN
    Red.ReportingCurrencyOverride rco ON
    fce.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride
    AND rco.ReportingCurrencyOverrideName = 'Settlement Currency'
    GROUP BY
    fce.FK_ClaimExposure
) z ON
ce.PK_ClaimExposure = z.FK_ClaimExposure
WHERE
EXISTS (SELECT 1 FROM ODS.ClaimDeductibleTracking cd WHERE cd.FK_Claim = c.PK_Claim)
AND c.DeductibleCCY IS NOT NULL
AND( ISNULL(c.AuditModifyDateTime,c.AuditCreateDateTime) > @LastAuditDate OR ISNULL(ce.AuditModifyDateTime,ce.AuditCreateDateTime) > @LastAuditDate)

UPDATE dr SET
OriginalCCYToSettlementCCYRate = CASE
                                    WHEN dr.OriginalCCY = dr.SettlementCCY THEN 1
                                    WHEN dr.TotalIncurredInSettlementCCY <> 0
                                        AND dr.TotalIncurredInOriginalCCY <> 0 
                                        THEN dr.TotalIncurredInOriginalCCY / dr.TotalIncurredInSettlementCCY
                                    ELSE cr_orig.ExchangeRate / cr_sett.ExchangeRate
                                  END
FROM
#DeductibleRates dr
INNER JOIN
Utility.CurrencyRate cr_orig ON
dr.OriginalCCY = cr_orig.Currency
AND cr_orig.RateType = 'Current'
INNER JOIN
Utility.CurrencyRate cr_sett ON
dr.SettlementCCY = cr_sett.Currency
AND cr_sett.RateType = 'Current'

UPDATE dr SET
OriginalCCYToDeductibleCCYRate  = CASE
                                    WHEN dr.DeductibleCCY = dr.OriginalCCY THEN 1
                                    WHEN dr.DeductibleCCY = dr.SettlementCCY THEN dr.OriginalCCYToSettlementCCYRate
                                    ELSE cr_orig.ExchangeRate / cr_ded.ExchangeRate
                                  END
FROM
#DeductibleRates dr
INNER JOIN
Utility.CurrencyRate cr_orig ON
dr.OriginalCCY = cr_orig.Currency
AND cr_orig.RateType = 'Current'
INNER JOIN
Utility.CurrencyRate cr_ded ON
dr.DeductibleCCY = cr_ded.Currency
AND cr_ded.RateType = 'Current'


IF (OBJECT_ID('tempdb..#DeductibleTracking') IS NOT NULL)
DROP TABLE #DeductibleTracking

CREATE TABLE #DeductibleTracking
(
    FK_Claim                                            bigint              NOT NULL
    ,FK_ClaimCostCategory                               bigint              NOT NULL
    ,DeductibleAggregatePaidBeazleyInDeductibleCCY      numeric(19,4)       NOT NULL
    ,DeductibleAggregatePaidInsuredInDeductibleCCY      numeric(19,4)       NOT NULL
    ,DeductibleAggregateRecoveredInDeductibleCCY        numeric(19,4)       NOT NULL
    ,DeductibleEachClaimPaidBeazleyInDeductibleCCY      numeric(19,4)       NOT NULL
    ,DeductibleEachClaimPaidInsuredInDeductibleCCY      numeric(19,4)       NOT NULL
    ,DeductibleEachClaimRecoveredInDeductibleCCY        numeric(19,4)       NOT NULL

)

INSERT INTO #DeductibleTracking
(
    FK_Claim
    ,FK_ClaimCostCategory
    ,DeductibleAggregatePaidBeazleyInDeductibleCCY
    ,DeductibleAggregatePaidInsuredInDeductibleCCY
    ,DeductibleAggregateRecoveredInDeductibleCCY
    ,DeductibleEachClaimPaidBeazleyInDeductibleCCY
    ,DeductibleEachClaimPaidInsuredInDeductibleCCY
    ,DeductibleEachClaimRecoveredInDeductibleCCY
)
SELECT
FK_Claim                                                = dt.FK_Claim
,FK_ClaimCostCategory                                   = dt.FK_ClaimCostCategory
,DeductibleAggregatePaidBeazleyInDeductibleCCY          = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType IN ('Excess', 'Aggregate Deductible')
                                                                AND dt.BeazleyPaid = 1
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
,DeductibleAggregatePaidInsuredInDeductibleCCY          = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType IN ('Excess', 'Aggregate Deductible')
                                                                AND dt.BeazleyPaid = 0 
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
,DeductibleAggregateRecoveredInDeductibleCCY            = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType IN ('Excess', 'Aggregate Deductible')
                                                                AND dt.BeazleyPaid = 1 
                                                                AND dt.Recoverable = 1 
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
,DeductibleEachClaimPaidBeazleyInDeductibleCCY          = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType = 'Each Claim Deductible'
                                                                AND dt.BeazleyPaid = 1 
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
,DeductibleEachClaimPaidInsuredInDeductibleCCY          = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType = 'Each Claim Deductible'
                                                                AND dt.BeazleyPaid = 0 
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
,DeductibleEachClaimRecoveredInDeductibleCCY            = SUM(CASE 
                                                              WHEN 
                                                                dt.DeductiblePaymentType = 'Each Claim Deductible'
                                                                AND dt.BeazleyPaid = 1 
                                                                AND dt.Recoverable = 1
                                                              THEN dt.DeductibleAmount 
                                                              ELSE 0 
                                                          END)
FROM
ODS.ClaimDeductibleTracking dt
GROUP BY
dt.FK_Claim
,dt.FK_ClaimCostCategory

IF (OBJECT_ID('tempdb..#FactClaimDeductibleTracking') IS NOT NULL)
DROP TABLE #FactClaimDeductibleTracking

CREATE TABLE #FactClaimDeductibleTracking
(
	[FK_ClaimExposure]               BIGINT          NOT NULL,
    [FK_ShareType]                   BIGINT          NOT NULL,
    [FK_ReportingCurrencyOverride]   BIGINT          NOT NULL,
    [FK_ClaimCostCategory]           BIGINT          NOT NULL,
    [FK_YOA]                         BIGINT          NOT NULL,
    [FK_SettlementCurrency]          BIGINT          NOT NULL,
    [FK_OriginalCurrency]            BIGINT          NOT NULL,
    [FK_GQDTransactionType]          BIGINT          NOT NULL,
    [FK_SpecialCategoryCatastrophe]  BIGINT          NOT NULL,
    [DeductibleAggregatePaidBeazley] NUMERIC (38, 4) NOT NULL,
    [DeductibleAggregatePaidInsured] NUMERIC (38, 4) NOT NULL,
    [DeductibleAggregateRecovered]   NUMERIC (38, 4) NOT NULL,
    [DeductibleEachClaimPaidBeazley] NUMERIC (38, 4) NOT NULL,
    [DeductibleEachClaimPaidInsured] NUMERIC (38, 4) NOT NULL,
    [DeductibleEachClaimRecovered]   NUMERIC (38, 4) NOT NULL,
)


    
INSERT INTO #FactClaimDeductibleTracking
(
    FK_ClaimExposure
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_ClaimCostCategory
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_SpecialCategoryCatastrophe
    ,DeductibleAggregatePaidBeazley
    ,DeductibleAggregatePaidInsured
    ,DeductibleAggregateRecovered
    ,DeductibleEachClaimPaidBeazley
    ,DeductibleEachClaimPaidInsured
    ,DeductibleEachClaimRecovered      
)
SELECT
FK_ClaimExposure                        = ce.PK_ClaimExposure
,FK_ShareType                           = st.PK_ShareType
,FK_ReportingCurrencyOverride           = rco.PK_ReportingCurrencyOverride
,FK_ClaimCostCategory                   = dt.FK_ClaimCostCategory
,FK_YOA                                 = ce.FK_YOA
,FK_SettlementCurrency                  = ce.FK_LastMovementSettlementCurrency
,FK_OriginalCurrency                    = ce.FK_LastMovementOriginalCurrency
,FK_GQDTransactionType                  = ce.FK_GQDTransactionType
,FK_SpecialCategoryCatastrophe          = ce.FK_SpecialCategoryCatastrophe
,DeductibleAggregatePaidBeazley         = ISNULL(dt.DeductibleAggregatePaidBeazleyInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate,0)
,DeductibleAggregatePaidInsured         = ISNULL(dt.DeductibleAggregatePaidInsuredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate,0)
,DeductibleAggregateRecovered           = ISNULL(dt.DeductibleAggregateRecoveredInDeductibleCCY * dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleEachClaimPaidBeazley         = ISNULL(dt.DeductibleEachClaimPaidBeazleyInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate,0)
,DeductibleEachClaimPaidInsured         = ISNULL(dt.DeductibleEachClaimPaidInsuredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate,0)
,DeductibleEachClaimRecovered           = ISNULL(dt.DeductibleEachClaimRecoveredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate,0)
FROM
#DeductibleTracking dt
INNER JOIN
ODS.Claim c ON
dt.FK_Claim = c.PK_Claim
INNER JOIN
#ClaimExposureMapping map ON
c.PK_Claim = map.FK_Claim
INNER JOIN
ODS.ClaimExposure ce ON
map.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN
#DeductibleRates dr ON
ce.PK_ClaimExposure = dr.FK_ClaimExposure
INNER JOIN
Red.ShareType st ON
st.ShareTypeName IN ('Total Order', 'Slip Order')
INNER JOIN
Red.ReportingCurrencyOverride rco ON
rco.ReportingCurrencyOverrideName = 'Original Currency'
WHERE ( ISNULL(c.AuditModifyDateTime,c.AuditCreateDateTime) > @LastAuditDate OR ISNULL(ce.AuditModifyDateTime,ce.AuditCreateDateTime) > @LastAuditDate)
UNION ALL
SELECT
FK_Claim                                = ce.PK_ClaimExposure
,FK_ShareType                           = st.PK_ShareType
,FK_ReportingCurrencyOverride           = rco.PK_ReportingCurrencyOverride
,FK_ClaimCostCategory                   = dt.FK_ClaimCostCategory
,FK_YOA                                 = ce.FK_YOA
,FK_SettlementCurrency                  = ce.FK_LastMovementSettlementCurrency
,FL_OriginalCurrency                    = ce.FK_LastMovementOriginalCurrency
,FK_GQDTransactionType                  = ce.FK_GQDTransactionType
,FK_SpecialCategoryCatastrophe          = ce.FK_SpecialCategoryCatastrophe
,DeductibleAggregatePaidBeazley         = ISNULL((dt.DeductibleAggregatePaidBeazleyInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleAggregatePaidInsured         = ISNULL((dt.DeductibleAggregatePaidInsuredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleAggregateRecovered           = ISNULL((dt.DeductibleAggregateRecoveredInDeductibleCCY * dr.OriginalCCYToSettlementCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleEachClaimPaidBeazley         = ISNULL((dt.DeductibleEachClaimPaidBeazleyInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleEachClaimPaidInsured         = ISNULL((dt.DeductibleEachClaimPaidInsuredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
,DeductibleEachClaimRecovered           = ISNULL((dt.DeductibleEachClaimRecoveredInDeductibleCCY * dr.OriginalCCYToDeductibleCCYRate) / dr.OriginalCCYToSettlementCCYRate,0)
FROM
#DeductibleTracking dt
INNER JOIN
ODS.Claim c ON
dt.FK_Claim = c.PK_Claim
INNER JOIN
#ClaimExposureMapping map ON
c.PK_Claim = map.FK_Claim
INNER JOIN
ODS.ClaimExposure ce ON
ce.PK_ClaimExposure = map.FK_ClaimExposure
INNER JOIN
#DeductibleRates dr ON
ce.PK_ClaimExposure = dr.FK_ClaimExposure
INNER JOIN
Red.ShareType st ON
st.ShareTypeName IN ('Total Order', 'Slip Order')
INNER JOIN
Red.ReportingCurrencyOverride rco ON
rco.ReportingCurrencyOverrideName = 'Settlement Currency'
WHERE ( ISNULL(c.AuditModifyDateTime,c.AuditCreateDateTime) > @LastAuditDate OR ISNULL(ce.AuditModifyDateTime,ce.AuditCreateDateTime) > @LastAuditDate)

/*Beazley share - only relevant for Beazley paid, recovered, and unrecovered amounts*/
INSERT INTO #FactClaimDeductibleTracking
(
    FK_ClaimExposure
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_ClaimCostCategory
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_SpecialCategoryCatastrophe
    ,DeductibleAggregatePaidBeazley
    ,DeductibleAggregatePaidInsured
    ,DeductibleAggregateRecovered
    ,DeductibleEachClaimPaidBeazley
    ,DeductibleEachClaimPaidInsured
    ,DeductibleEachClaimRecovered      
)
SELECT
FK_ClaimExposure                            = fcd.FK_ClaimExposure
,FK_ShareType                               = st_beaz.PK_ShareType
,FK_ReportingCurrencyOverride               = fcd.FK_ReportingCurrencyOverride
,FK_ClaimCostCategory                       = fcd.FK_ClaimCostCategory
,FK_YOA                                     = fcd.FK_YOA
,FK_SettlementCurrency                      = fcd.FK_SettlementCurrency
,FK_OriginalCurrency                        = fcd.FK_OriginalCurrency
,FK_GQDTransactionType                      = fcd.FK_GQDTransactionType
,FK_SpecialCategory                         = fcd.FK_SpecialCategoryCatastrophe
,DeductibleAggregatePaidBeazley             = fcd.DeductibleAggregatePaidBeazley * ce.WrittenIfNotSignedOrderMultiplier * ce.LastMovementLineMultiplier
,DeductibleAggregatePaidInsured             = 0 --Not relevant at Beazley Share
,DeductibleAggregateRecovered               = fcd.DeductibleAggregateRecovered * ce.WrittenIfNotSignedOrderMultiplier * ce.LastMovementLineMultiplier
,DeductibleEachClaimPaidBeazley             = fcd.DeductibleEachClaimPaidBeazley * ce.WrittenIfNotSignedOrderMultiplier * ce.LastMovementLineMultiplier
,DeductibleEachClaimPaidInsured             = 0 --Not relevant at Beazley Share
,DeductibleEachClaimRecovered               = fcd.DeductibleEachClaimRecovered * ce.WrittenIfNotSignedOrderMultiplier * ce.LastMovementLineMultiplier
FROM
#FactClaimDeductibleTracking fcd
INNER JOIN
Red.ShareType st ON
fcd.FK_ShareType = st.PK_ShareType
AND st.ShareTypeName = 'Total Order'
INNER JOIN 
Red.ShareType st_beaz ON
st_beaz.ShareTypeName = 'Beazley Share'
INNER JOIN
ODS.ClaimExposure ce ON
fcd.FK_ClaimExposure = ce.PK_ClaimExposure
WHERE (ISNULL(ce.AuditModifyDateTime,ce.AuditCreateDateTime) > @LastAuditDate)


ALTER TABLE Red.FactClaimDeductibleTracking NOCHECK CONSTRAINT ALL

IF EXISTS
 ( 
   SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactClaimDeductibleTracking' AND CONSTRAINT_NAME = 'UQ_FactClaimDeductibleTracking_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactClaimDeductibleTracking
    DROP CONSTRAINT UQ_FactClaimDeductibleTracking_LogicalKey       
END

DELETE FROM Red.FactClaimDeductibleTracking
WHERE FK_ClaimExposure NOT IN (SELECT PK_ClaimExposure FROM ODS.ClaimExposure)
OR FK_ShareType NOT IN (SELECT PK_ShareType FROM Red.ShareType)
OR FK_ReportingCurrencyOverride NOT IN (SELECT PK_ReportingCurrencyOverride FROM Red.ReportingCurrencyOverride)
OR FK_ClaimCostCategory NOT IN (SELECT PK_ClaimCostCategory FROM ODS.ClaimCostCategory)
OR FK_GQDTransactionType NOT IN (SELECT PK_GQDTransactionType FROM ODS.GQDTransactionType)
OR FK_OriginalCurrency NOT IN (SELECT PK_OriginalCurrency FROM ODS.OriginalCurrency)
OR FK_SettlementCurrency NOT IN (SELECT PK_SettlementCurrency FROM ODS.SettlementCurrency)
OR FK_SpecialCategoryCatastrophe NOT IN (SELECT PK_SpecialCategoryCatastrophe FROM ODS.SpecialCategoryCatastrophe)
OR FK_YOA NOT IN (SELECT PK_YOA FROM ODS.YOA)

MERGE Red.FactClaimDeductibleTracking TARGET
USING #FactClaimDeductibleTracking SOURCE
ON  TARGET.FK_ClaimExposure = SOURCE.FK_ClaimExposure
AND TARGET.FK_ShareType = SOURCE.FK_ShareType
AND TARGET.FK_ReportingCurrencyOverride = SOURCE.FK_ReportingCurrencyOverride
AND TARGET.FK_ClaimCostCategory = SOURCE.FK_ClaimCostCategory

WHEN MATCHED THEN 
UPDATE 
SET 
  TARGET.FK_YOA                         = SOURCE.FK_YOA                        
 ,TARGET.FK_SettlementCurrency			= SOURCE.FK_SettlementCurrency			
 ,TARGET.FK_OriginalCurrency			= SOURCE.FK_OriginalCurrency				
 ,TARGET.FK_GQDTransactionType			= SOURCE.FK_GQDTransactionType			
 ,TARGET.FK_SpecialCategoryCatastrophe	= SOURCE.FK_SpecialCategoryCatastrophe
 ,TARGET.DeductibleAggregatePaidBeazley	= SOURCE.DeductibleAggregatePaidBeazley
 ,TARGET.DeductibleAggregatePaidInsured	= SOURCE.DeductibleAggregatePaidInsured
 ,TARGET.DeductibleAggregateRecovered	= SOURCE.DeductibleAggregateRecovered	
 ,TARGET.DeductibleEachClaimPaidBeazley	= SOURCE.DeductibleEachClaimPaidBeazley
 ,TARGET.DeductibleEachClaimPaidInsured	= SOURCE.DeductibleEachClaimPaidInsured
 ,TARGET.DeductibleEachClaimRecovered   = SOURCE.DeductibleEachClaimRecovered    
 ,TARGET.AuditModifyDateTime	        = GETDATE()						
 ,TARGET.AuditModifyDetails	            = 'Merge in [Red].[usp_LoadFactClaimDeductibleTracking] proc' 

 WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
 FK_ClaimExposure
,FK_ShareType
,FK_ReportingCurrencyOverride
,FK_ClaimCostCategory
,FK_YOA
,FK_SettlementCurrency
,FK_OriginalCurrency
,FK_GQDTransactionType
,FK_SpecialCategoryCatastrophe
,DeductibleAggregatePaidBeazley
,DeductibleAggregatePaidInsured
,DeductibleAggregateRecovered
,DeductibleEachClaimPaidBeazley
,DeductibleEachClaimPaidInsured
,DeductibleEachClaimRecovered   
,AuditCreateDateTime
,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_ClaimExposure
,SOURCE.FK_ShareType
,SOURCE.FK_ReportingCurrencyOverride
,SOURCE.FK_ClaimCostCategory
,SOURCE.FK_YOA
,SOURCE.FK_SettlementCurrency
,SOURCE.FK_OriginalCurrency
,SOURCE.FK_GQDTransactionType
,SOURCE.FK_SpecialCategoryCatastrophe
,SOURCE.DeductibleAggregatePaidBeazley
,SOURCE.DeductibleAggregatePaidInsured
,SOURCE.DeductibleAggregateRecovered
,SOURCE.DeductibleEachClaimPaidBeazley
,SOURCE.DeductibleEachClaimPaidInsured
,SOURCE.DeductibleEachClaimRecovered   
,GETDATE()
,'New add in [Red].[usp_LoadFactClaimDeductibleTracking] proc'	
);

ALTER TABLE Red.FactClaimDeductibleTracking CHECK CONSTRAINT ALL


IF NOT EXISTS
 ( 
   SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactClaimDeductibleTracking' AND CONSTRAINT_NAME = 'UQ_FactClaimDeductibleTracking_LogicalKey' 
 )
BEGIN

ALTER TABLE Red.FactClaimDeductibleTracking
    ADD CONSTRAINT UQ_FactClaimDeductibleTracking_LogicalKey
    UNIQUE
    (
         FK_ClaimExposure
         ,FK_ShareType
         ,FK_ReportingCurrencyOverride
         ,FK_ClaimCostCategory
    )
END


IF (OBJECT_ID('tempdb..#ClaimExposureMapping') IS NOT NULL)        DROP TABLE #ClaimExposureMapping
IF (OBJECT_ID('tempdb..#DeductibleRates') IS NOT NULL)             DROP TABLE #DeductibleRates
IF (OBJECT_ID('tempdb..#FactClaimDeductibleTracking') IS NOT NULL) DROP TABLE #FactClaimDeductibleTracking
IF (OBJECT_ID('tempdb..#DeductibleTracking') IS NOT NULL)          DROP TABLE #DeductibleTracking;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactClaimDeductibleTracking';