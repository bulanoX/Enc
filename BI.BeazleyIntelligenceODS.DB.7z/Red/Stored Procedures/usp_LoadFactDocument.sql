﻿CREATE PROC [Red].[usp_LoadFactDocument]
AS
    
SET NOCOUNT ON


DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM		Red.FactDocument

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');


DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.DocumentType dt
       ON     f.FK_DocumentType = dt.PK_DocumentType
WHERE         PK_DocumentType IS NULL AND f.FK_DocumentType IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.Section s
       ON     f.FK_Section = s.PK_Section
WHERE         PK_Section IS NULL AND f.FK_Section IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.YOA y
       ON     f.FK_YOA = y.PK_YOA
WHERE         PK_YOA IS NULL AND f.FK_YOA IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.CRMBroker c
       ON     f.FK_CRMBroker = c.PK_CRMBroker
WHERE         PK_CRMBroker IS NULL AND f.FK_CRMBroker IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.Policy p
       ON     f.FK_Policy = p.PK_Policy
WHERE         PK_Policy IS NULL AND f.FK_Policy IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.OriginalCurrency oc
       ON     f.FK_OriginalCurrency = oc.PK_OriginalCurrency
WHERE         PK_OriginalCurrency IS NULL AND f.FK_OriginalCurrency IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.ServiceCompany sp
       ON     f.FK_ServiceCompany = sp.PK_ServiceCompany
WHERE         PK_ServiceCompany IS NULL AND f.FK_ServiceCompany IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.TriFocus tf
       ON     f.FK_TriFocus = tf.PK_TriFocus
WHERE         PK_TriFocus IS NULL AND f.FK_TriFocus IS NOT NULL

DELETE		  f
FROM          Red.FactDocument f
LEFT JOIN     Ods.UnderwritingPlatform up
       ON     f.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform
WHERE         PK_UnderwritingPlatform IS NULL AND f.FK_UnderwritingPlatform IS NOT NULL


ALTER TABLE Red.FactDocument NOCHECK CONSTRAINT ALL

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactDocument' AND CONSTRAINT_NAME = 'UQ_FactDocument_LogicalKey' 
 )

BEGIN
    ALTER TABLE Red.FactDocument
    DROP CONSTRAINT UQ_FactDocument_LogicalKey
END
 
 
;MERGE	Red.FactDocument	AS TARGET
		USING	
		(
			SELECT
					 FK_DocumentType                    = x.FK_DocumentType                   
					,FK_Section                         = s.PK_Section                           
					,FK_YOA                             = p.FK_YOA
					,FK_SettlementCurrency              = s.FK_SettlementCurrency
					,FK_OriginalCurrency                = s.FK_OriginalCurrency
					,FK_LocalCurrency					= s.FK_LocalCurrency
					,FK_TriFocus                        = s.FK_TriFocus
					,FK_Policy                          = p.PK_Policy
					,FK_QuoteFilter                     = s.FK_QuoteFilter
					,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
					,FK_CRMBroker                       = s.FK_CRMBroker
					,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
					,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
					,FK_ServiceCompany					= s.FK_ServiceCompany
					,SpecialPurposeSyndicateApplies     = s.SpecialPurposeSyndicateApplies            
					,DocumentCreateDate                 = y.EarliestCreateDate
					,EarliestPolicyDocumentDate         = x.EarliestPolicyDocumentDate
					,DaysBetweenQBAndEPDDate            = DATEDIFF(DAY, s.QuoteOrBindDate, x.EarliestPolicyDocumentDate)
					,NumberOfDocuments                  = ISNULL(y.NumberOfDocuments, 0)

			FROM			ODS.Section s 

			INNER JOIN		ODS.Policy p 
					ON		s.FK_Policy = p.PK_Policy

			INNER JOIN		(
								SELECT
								FK_Policy                       = s.FK_Policy
								,FK_DocumentType                = d.FK_DocumentType
								,EarliestPolicyDocumentDate     = MIN(d.DocumentCreateDate)
								,LastAuditDate					= MAX(ISNULL(d.AuditModifyDateTime,d.AuditCreateDateTime) )
								FROM
								ODS.Section s
								INNER JOIN
								ODS.Policy p ON
								s.FK_Policy = p.PK_Policy
								INNER JOIN
								ODS.Document d ON
								s.PK_Section = d.FK_Section
								WHERE
								s.FK_Policy <> 0
								GROUP BY
								s.FK_Policy
								,d.FK_DocumentType
							) x 
					ON		p.PK_Policy = x.FK_Policy

		LEFT OUTER JOIN		(
								SELECT
								FK_Section              = d.FK_Section
								,FK_DocumentType        = d.FK_DocumentType
								,EarliestCreateDate     = MIN(d.DocumentCreateDate)
								,NumberOfDocuments      = COUNT(1)
								FROM
								ODS.Document d 
								GROUP BY
								d.FK_Section
								,d.FK_DocumentType
							) y 
					ON		s.PK_Section = y.FK_Section
					AND		x.FK_DocumentType = y.FK_DocumentType

			WHERE
						(s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
					OR  (p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
					OR   x.LastAuditDate> @LastAuditDate
			)		
			AS SOURCE

			ON		TARGET.FK_Section                       = SOURCE.FK_Section                   
				AND	TARGET.FK_DocumentType					= SOURCE.FK_DocumentType         
	

	WHEN	MATCHED	THEN
			UPDATE	
			SET	TARGET.FK_YOA								= SOURCE.FK_YOA
				,TARGET.FK_SettlementCurrency				= SOURCE.FK_SettlementCurrency
				,TARGET.FK_OriginalCurrency					= SOURCE.FK_OriginalCurrency
				,TARGET.FK_LocalCurrency					= SOURCE.FK_LocalCurrency
				,TARGET.FK_TriFocus							= SOURCE.FK_TriFocus
				,TARGET.FK_Policy							= SOURCE.FK_Policy
				,TARGET.FK_QuoteFilter						= SOURCE.FK_QuoteFilter
				,TARGET.FK_HiddenStatusFilter				= SOURCE.FK_HiddenStatusFilter
				,TARGET.FK_CRMBroker						= SOURCE.FK_CRMBroker
				,TARGET.FK_UnderwritingPlatform				= SOURCE.FK_UnderwritingPlatform
				,TARGET.FK_InternalWrittenBinderStatus		= SOURCE.FK_InternalWrittenBinderStatus
				,TARGET.FK_ServiceCompany					= SOURCE.FK_ServiceCompany
				,TARGET.SpecialPurposeSyndicateApplies		= SOURCE.SpecialPurposeSyndicateApplies            
				,TARGET.DocumentCreateDate					= SOURCE.DocumentCreateDate
				,TARGET.EarliestPolicyDocumentDate			= SOURCE.EarliestPolicyDocumentDate
				,TARGET.DaysBetweenQBAndEPDDate				= SOURCE.DaysBetweenQBAndEPDDate
				,TARGET.NumberOfDocuments					= SOURCE.NumberOfDocuments
				,TARGET.AuditModifyDateTime					= GETDATE()						
				,TARGET.AuditModifyDetails					= 'Merge in Red.usp_LoadFactDocument' 


	WHEN    NOT MATCHED BY TARGET THEN
			INSERT
			(       
				 FK_DocumentType
				,FK_Section
				,FK_YOA
				,FK_SettlementCurrency
				,FK_OriginalCurrency
				,FK_LocalCurrency
				,FK_TriFocus
				,FK_Policy
				,FK_QuoteFilter
				,FK_HiddenStatusFilter
				,FK_CRMBroker
				,FK_UnderwritingPlatform
				,FK_InternalWrittenBinderStatus
				,FK_ServiceCompany
				,SpecialPurposeSyndicateApplies
				,DocumentCreateDate
				,EarliestPolicyDocumentDate
				,DaysBetweenQBAndEPDDate
				,NumberOfDocuments
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				 SOURCE.FK_DocumentType
				,SOURCE.FK_Section
				,SOURCE.FK_YOA
				,SOURCE.FK_SettlementCurrency
				,SOURCE.FK_OriginalCurrency
				,SOURCE.FK_LocalCurrency
				,SOURCE.FK_TriFocus
				,SOURCE.FK_Policy
				,SOURCE.FK_QuoteFilter
				,SOURCE.FK_HiddenStatusFilter
				,SOURCE.FK_CRMBroker
				,SOURCE.FK_UnderwritingPlatform
				,SOURCE.FK_InternalWrittenBinderStatus
				,SOURCE.FK_ServiceCompany
				,SOURCE.SpecialPurposeSyndicateApplies
				,SOURCE.DocumentCreateDate
				,SOURCE.EarliestPolicyDocumentDate
				,SOURCE.DaysBetweenQBAndEPDDate
				,SOURCE.NumberOfDocuments
				,GETDATE()						
				,'New add in Red.usp_LoadFactDocument' 
		   )
	;


IF NOT EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactDocument' AND CONSTRAINT_NAME = 'UQ_FactDocument_LogicalKey' 
 )

BEGIN
    ALTER TABLE Red.FactDocument
        ADD CONSTRAINT UQ_FactDocument_LogicalKey
        UNIQUE
        (
             FK_Section
            ,FK_DocumentType
        )
        
END
    
ALTER TABLE Red.FactDocument CHECK CONSTRAINT ALL;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactDocument';