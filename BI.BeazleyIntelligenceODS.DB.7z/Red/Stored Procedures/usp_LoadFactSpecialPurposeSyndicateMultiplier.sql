﻿

CREATE PROCEDURE [Red].[usp_LoadFactSpecialPurposeSyndicateMultiplier]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM Red.FactSpecialPurposeSyndicateMultiplier

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF (OBJECT_ID('tempdb..#SpecialPurposeSyndicateYOA') IS NOT NULL) DROP TABLE #SpecialPurposeSyndicateYOA

CREATE TABLE #SpecialPurposeSyndicateYOA
 (
    FK_YOA                              int             NULL
   ,SpecialPurposeSyndicateMultiplier   numeric(19,12)  NULL
 )

TRUNCATE TABLE #SpecialPurposeSyndicateYOA

INSERT INTO #SpecialPurposeSyndicateYOA
 (
    FK_YOA
   ,SpecialPurposeSyndicateMultiplier
 )

SELECT
FK_YOA = yoa.PK_YOA 
,SpecialPurposeSyndicateMultiplier = ISNULL(sm.SpecialPurposeSyndicateMultiplier, 0)
FROM 
ODS.YOA yoa
LEFT OUTER JOIN
Utility.SpecialPurposeSyndicateMultiplier sm ON
yoa.PK_YOA = sm.YOA
WHERE 
ISNULL(yoa.[AuditModifyDateTime], yoa.[AuditCreateDateTime]) > @LastAuditDate 
OR ISNULL(sm.[AuditModifyDateTime], sm.[AuditCreateDateTime]) > @LastAuditDate 

DELETE FROM Red.FactSpecialPurposeSyndicateMultiplier
WHERE Fk_YOA  NOT IN (SELECT PK_YOA FROM ODS.YOA)
OR FK_SpecialPurposeSyndicateBasis NOT IN (SELECT PK_SpecialPurposeSyndicateBasis FROM Red.SpecialPurposeSyndicateBasis)
MERGE Red.FactSpecialPurposeSyndicateMultiplier TARGET
USING
(
SELECT
 FK_YOA                                 = spsyoa.FK_YOA                  
,FK_SpecialPurposeSyndicateBasis        = spsbasis.PK_SpecialPurposeSyndicateBasis      
,SpecialPurposeSyndicateApplies         = applies.SpecialPurposeSyndicateApplies         
,SpecialPurposeSyndicateMultiplier      = CASE applies.SpecialPurposeSyndicateApplies
                                                 WHEN 0 THEN CASE spsbasis.SpecialPurposeSyndicateBasis WHEN 'Gross Of SPS' THEN 1
                                                                                             WHEN 'Net Of SPS'   THEN 1
                                                                                             WHEN 'SPS Only'     THEN 0
                                                             END --end when 0
                                                 WHEN 1 THEN CASE spsbasis.SpecialPurposeSyndicateBasis WHEN 'Gross Of SPS' THEN 1
                                                                                             WHEN 'Net Of SPS'   THEN 1 - spsyoa.SpecialPurposeSyndicateMultiplier
                                                                                             WHEN 'SPS Only'     THEN spsyoa.SpecialPurposeSyndicateMultiplier
                                                             END --end when 1
                                                 END --end SpecialPurposeSyndicateapplies
FROM #SpecialPurposeSyndicateYOA spsyoa

CROSS JOIN Red.SpecialPurposeSyndicateBasis spsbasis

CROSS JOIN( 
           SELECT SpecialPurposeSyndicateApplies = CAST(0 AS bit) 
           UNION ALL
           SELECT SpecialPurposeSyndicateApplies = CAST(1 AS bit) 
           ) applies

WHERE NOT (applies.SpecialPurposeSyndicateApplies = 0 AND spsbasis.SpecialPurposeSyndicateBasis = 'SPS Only')
) SOURCE
ON  TARGET.SpecialPurposeSyndicateApplies   = SOURCE.SpecialPurposeSyndicateApplies
AND TARGET.FK_YOA							= SOURCE.FK_YOA
AND TARGET.FK_SpecialPurposeSyndicateBasis  = SOURCE.FK_SpecialPurposeSyndicateBasis

WHEN MATCHED THEN 
UPDATE 
SET 
TARGET.SpecialPurposeSyndicateMultiplier = SOURCE.SpecialPurposeSyndicateMultiplier
,TARGET.AuditModifyDateTime                  = GETDATE()
,TARGET.AuditModifyDetails                   = 'Merge in [Red].[usp_LoadFactSpecialPurposeSyndicateMultiplier] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
SpecialPurposeSyndicateApplies
,FK_YOA                         
,FK_SpecialPurposeSyndicateBasis
,SpecialPurposeSyndicateMultiplier
,AuditCreateDateTime   
,AuditModifyDetails 
 )
 VALUES
 (
 SOURCE.SpecialPurposeSyndicateApplies
,SOURCE.FK_YOA                         
,SOURCE.FK_SpecialPurposeSyndicateBasis
,SOURCE.SpecialPurposeSyndicateMultiplier
,GETDATE()
,'New add in [Red].[usp_LoadFactSpecialPurposeSyndicateMultiplier] proc'
);

IF (OBJECT_ID('tempdb..#SpecialPurposeSyndicateYOA') IS NOT NULL) DROP TABLE #SpecialPurposeSyndicateYOA;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactSpecialPurposeSyndicateMultiplier';

