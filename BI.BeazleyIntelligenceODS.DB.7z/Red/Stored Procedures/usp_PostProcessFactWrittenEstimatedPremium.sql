﻿/*
Post-Deployment Script Template								
--------------------------------------------------------------------------------------
*/
--
CREATE PROCEDURE [Red].[usp_PostProcessFactWrittenEstimatedPremium]
AS BEGIN
	
--Index creation & constraint enabling 

IF NOT EXISTS (SELECT 1 FROM BeazleyIntelligenceODS.sys.indexes  
		    WHERE name = 'FactWrittenEstimatedPremium_Combined'
			)
		BEGIN   
			CREATE NONCLUSTERED INDEX FactWrittenEstimatedPremium_Combined
			ON BeazleyIntelligenceODS.Red.FactWrittenEstimatedPremium(FK_sharetype, FK_acquisitionCostBasis,FK_ReportingCurrencyOverride,FK_QuoteFilter)
			INCLUDE (FK_section,FK_YOA,FK_settlementcurrency,FK_EntityPerspective,DeclarationWEP,PremiumIncomeLimit,BenchmarkPremium,WEPIncludingReinstatementPremium)
END

ALTER TABLE BeazleyIntelligenceODS.Red.FactWrittenEstimatedPremium CHECK CONSTRAINT ALL ;        


END
GO