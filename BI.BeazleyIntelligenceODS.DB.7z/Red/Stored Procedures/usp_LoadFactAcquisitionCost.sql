﻿CREATE PROC [Red].[usp_LoadFactAcquisitionCost]

AS
/**************************************************************************************/
/*                          Load fact acquisition cost                                */
/**************************************************************************************/

	TRUNCATE TABLE Red.FactAcquisitionCost
	IF EXISTS
				(
				SELECT	1 
				FROM	INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
				WHERE	TABLE_SCHEMA = 'Red' 
					AND TABLE_NAME = 'FactAcquisitionCost' 
					AND CONSTRAINT_NAME = 'UQ_FactAcquisitionCost_LogicalKey' 
				)
		BEGIN
				ALTER TABLE Red.FactAcquisitionCost
				DROP CONSTRAINT UQ_FactAcquisitionCost_LogicalKey
		END



---/// DROP  INDEX & DISABLE CONSTRAINTS
ALTER TABLE Red.FactAcquisitionCost NOCHECK CONSTRAINT ALL;

IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		    WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactAcquisitionCost' AND name = 'FactAcquisitionCost_Combined')
	BEGIN
		DROP INDEX FactAcquisitionCost_Combined ON  Red.FactAcquisitionCost
	END
---/////////

    

	INSERT INTO Red.FactAcquisitionCost WITH (TABLOCK)
 (
	 FK_Section
	,FK_EntityPerspective                  
	,FK_AcquisitionCostType                
	,FK_Syndicate                          
	,FK_ShareType                          
	,FK_ReportingCurrencyOverride          
	,FK_Date                               
	,FK_YOA                                
	,FK_SettlementCurrency                 
	,FK_OriginalCurrency                   
	,FK_LocalCurrency					   
	,FK_TriFocus                           
	,FK_CRMBroker                          
	,FK_Policy                             
	,FK_QuoteFilter                        
	,FK_HiddenStatusFilter                 
	,FK_UnderwritingPlatform			   
	,FK_InternalWrittenBinderStatus		   
	,FK_ServiceCompany					   
	,SpecialPurposeSyndicateApplies        
	,ExternalAcquisitionCostAmount 		
	,InternalAcquisitionCostAmount  		
	,ExternalAcquisitionCostAmountExcLBSFee
	,TaxDescription
 )
			
				SELECT      
						FK_Section                                  = fwep.FK_Section
						,FK_EntityPerspective                       = sac.FK_EntityPerspective                           
						,FK_AcquisitionCostType                     = sac.FK_AcquisitionCostType        
						,FK_Syndicate                               = fwep.FK_Syndicate                             
						,FK_ShareType                               = fwep.FK_ShareType                             
						,FK_ReportingCurrencyOverride               = fwep.FK_ReportingCurrencyOverride
						,FK_Date                                    = fwep.FK_Date
						,FK_YOA                                     = fwep.FK_YOA
						,FK_SettlementCurrency                      = fwep.FK_SettlementCurrency
						,FK_OriginalCurrency                        = fwep.FK_OriginalCurrency
						,FK_LocalCurrency					        = fwep.FK_LocalCurrency
						,FK_TriFocus                                = fwep.FK_TriFocus
						,FK_CRMBroker                               = fwep.FK_CRMBroker
						,FK_Policy                                  = fwep.FK_Policy
						,FK_QuoteFilter                             = fwep.FK_QuoteFilter
						,FK_HiddenStatusFilter                      = fwep.FK_HiddenStatusFilter
						,FK_UnderwritingPlatform			        = fwep.FK_UnderwritingPlatform
						,FK_InternalWrittenBinderStatus		        = fwep.FK_InternalWrittenBinderStatus
						,FK_ServiceCompany					        = fwep.FK_ServiceCompany
						,SpecialPurposeSyndicateApplies             = fwep.SpecialPurposeSyndicateApplies                             
						,ExternalAcquisitionCostAmount              = CASE 
																			WHEN	act.AcquisitionCostTypeInternalExternal = 'External' 
																			THEN	fwep.WrittenOrEstimatedPremium * sac.AcquisitionCostMultiplier 
																	END
						,InternalAcquisitionCostAmount              = CASE 
																			WHEN	act.AcquisitionCostTypeInternalExternal = 'Internal' 
																			THEN	fwep.WrittenOrEstimatedPremium * sac.AcquisitionCostMultiplier
																	END
						,ExternalAcquisitionCostAmountExcLBSFee     = CASE 
																			WHEN	act.AcquisitionCostTypeInternalExternal = 'External' 
																				AND act.AcquisitionCostTypeCode<>'X' 
																			THEN	fwep.WrittenOrEstimatedPremium * sac.AcquisitionCostMultiplier 
																		END
						,sac.TaxDescription
				FROM     Red.FactWrittenEstimatedPremium fwep

				INNER JOIN Red.AcquisitionCostBasis acb 
						ON fwep.FK_AcquisitionCostBasis = acb.PK_AcquisitionCostBasis
						AND acb.AcquisitionCostBasisName = 'Gross Of Acquisition Cost'

				INNER JOIN ODS.SectionAcquisitionCost sac 
						ON fwep.FK_Section = sac.FK_Section

				INNER JOIN ODS.AcquisitionCostType act 
						ON sac.FK_AcquisitionCostType = act.PK_AcquisitionCostType
						AND sac.FK_EntityPerspective = fwep.FK_EntityPerspective
	
	IF NOT EXISTS
				(
				SELECT	 1 
				FROM	INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
				WHERE	TABLE_SCHEMA = 'Red' 
					AND TABLE_NAME = 'FactAcquisitionCost' 
					AND CONSTRAINT_NAME = 'UQ_FactAcquisitionCost_LogicalKey'    
				)
		BEGIN
				ALTER TABLE Red.FactAcquisitionCost
				ADD CONSTRAINT UQ_FactAcquisitionCost_LogicalKey
				UNIQUE
					(
						FK_Section
						,FK_EntityPerspective
						,FK_AcquisitionCostType
						,FK_Syndicate
						,FK_ShareType
						,FK_ReportingCurrencyOverride
						,TaxDescription
					)
		END

---///CREATE INDEX & ENABLE CONSTRAINTS
	IF NOT EXISTS (
		       select 1 from sys.indexes where name='FactAcquisitionCost_Combined'
				   )
	BEGIN   
		CREATE NONCLUSTERED INDEX FactAcquisitionCost_Combined ON Red.FactAcquisitionCost (FK_ShareType,FK_ReportingCurrencyOverride,FK_QuoteFilter)
		INCLUDE (FK_Section,FK_YOA, FK_SettlementCurrency, FK_EntityPerspective,ExternalAcquisitionCostAmountExcLBSFee);
	END 

	ALTER TABLE Red.FactAcquisitionCost CHECK CONSTRAINT ALL;
---/////////


	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactAcquisitionCost';
GO




