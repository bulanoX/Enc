﻿CREATE PROCEDURE  [Red].[usp_LoadFactExposure]
AS



/*******************************************************************************/
/*                        Share type                                           */
/*******************************************************************************/
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType

CREATE TABLE #SectionShareType
(
    FK_Section                      bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
    ,TotalLineMultiplier            numeric(19,12)      NULL
	,SyndicateSplitMultiplier		numeric(19,12)      NULL
)

TRUNCATE TABLE #SectionShareType

INSERT INTO #SectionShareType
(
     FK_Section
    ,FK_ShareType
    ,FK_Syndicate
    ,TotalLineMultiplier
	,SyndicateSplitMultiplier
)

SELECT
FK_Section              = s.PK_Section     
,FK_ShareType           = st.PK_ShareType
,FK_Syndicate           = NULL                                      
,TotalLineMultiplier    = CASE st.ShareTypeName 
                            WHEN 'Total Order' THEN 1
                            WHEN 'Slip Order'  THEN s.WrittenIfNotSignedOrderMultiplier
                          END
,SyndicateSplitMultiplier = CASE st.ShareTypeName 
                            WHEN 'Total Order' THEN 1
                            WHEN 'Slip Order'  THEN s.WrittenIfNotSignedOrderMultiplier
                          END						  
FROM 
ODS.Section s
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName IN ('Total Order','Slip Order')
UNION ALL
SELECT
FK_Section             = sl.FK_Section                       
,FK_ShareType          = st.PK_ShareType                 
,FK_Syndicate          = sl.FK_Syndicate 
,TotalLineMultiplier   = sl.WrittenIfNotSignedLineMultiplier 
                        * s.WrittenIfNotSignedOrderMultiplier 
                        * CASE 
                            WHEN s.IsSigned = 0 
                            THEN s.EstimatedSigningMultiplier 
                            ELSE 1
                          END
,SyndicateSplitMultiplier = ISNULL(ss.SyndicateMultiplier, 1) 						  
FROM 
ODS.SectionLine sl
INNER JOIN
ODS.Section s ON
sl.FK_Section = s.PK_Section
LEFT JOIN 
ODS.SyndicateSplit ss ON
ss.FK_YOA = s.FK_YOA
AND ss.FK_Syndicate = sl.FK_Syndicate
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName = 'Beazley Share'


/***************************************************************************************/
/*                       Unirisx Section Limit                                                */
/***************************************************************************************/

CREATE TABLE #SectionLimit
(
    FK_Section                      bigint              NOT NULL
    ,SublimitName                   varchar(255)		NULL
    ,LimitAmountInLimitCCY          numeric(19,4)       NULL
)

TRUNCATE TABLE #SectionLimit

INSERT INTO #SectionLimit
	   (
	   FK_Section
	   ,SublimitName
	   ,LimitAmountInLimitCCY 
	   )
SELECT	
		PK_Section
		,SublimitName
		,LimitAmountInLimitCCY 
FROM (
		SELECT  s.PK_Section 
			   ,s.SectionReference
			   ,t.DepartmentName
			   ,sub.SublimitName
			   ,sl.LimitAmountInLimitCCY
			   ,dl.LimitPriority
			   ,rn = ROW_NUMBER() OVER(PARTITION BY s.SectionReference  ORDER BY dl.LimitPriority ASC, sl.LimitAmountInLimitCCY DESC) 
		FROM  ODS.Policy p
			 INNER JOIN 
			 ODS.Section s ON 
				p.pk_policy = s.fk_policy
			 INNER JOIN 
			 ODS.SectionLimit sl ON 
				s.PK_Section = sl.FK_Section
			 INNER JOIN 
			 ODS.Sublimit sub ON 
				sub.pk_sublimit = sl.fk_sublimit
			 INNER JOIN 
			 ODS.Trifocus t ON 
				t.pk_trifocus = s.fk_trifocus
			 INNER JOIN 
			 Staging_MDS.MDS_Staging.DepartmentLimit dl ON 
				dl.DepartmentName = t.DepartmentName 
				AND dl.LimitName = sub.SublimitName
				AND p.SourceSystem = dl.SourceSystem
		WHERE p.SourceSystem = 'Unirisx' 
	) sl
WHERE rn = 1

/***************************************************************************************/
/*          Section exposure fact in original currency                                 */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionExposureOriginalCurrency') IS NOT NULL) DROP TABLE #SectionExposureOriginalCurrency

CREATE TABLE #SectionExposureOriginalCurrency
(
    FK_Section                      bigint              NOT NULL
   ,FK_Syndicate                    bigint              NULL
   ,FK_ShareType                    bigint              NOT NULL
   ,FK_Date                         datetime            NOT NULL
   ,FK_YOA                          bigint              NOT NULL
   ,FK_SettlementCurrency           bigint              NOT NULL
   ,FK_OriginalCurrency             bigint              NOT NULL
   ,FK_TriFocus                     bigint              NOT NULL
   ,FK_CRMBroker                    bigint              NOT NULL
   ,FK_Policy                       bigint              NOT NULL
   ,FK_QuoteFilter                  bigint              NOT NULL
   ,FK_HiddenStatusFilter           bigint              NOT NULL
   ,FK_UnderwritingPlatform			bigint				NOT NULL
   ,FK_InternalWrittenBinderStatus	bigint				NOT NULL
   ,FK_ServiceCompany				bigint				NOT NULL
   ,SpecialPurposeSyndicateApplies  bit                 NOT NULL
   ,Limit                           numeric(38, 4)       NULL
   ,Exposure                        numeric(38, 4)       NULL
   ,OriginalLimit					numeric(38, 4)       NULL	
   ,OriginalExposure				numeric(38, 4)       NULL
   ,Excess                          numeric(38, 4)       NULL
   ,Deductible                      numeric(38, 4)       NULL
   ,EventLimit                      numeric(38, 4)       NULL
   ,AggregateAmount                 numeric(38, 4)       NULL
   ,AnnualRevenues                  numeric(38, 4)       NULL
   ,TreatyCAT                       numeric(38, 4)       NULL
   ,TreatyAggXL	                    numeric(38, 4)       NULL
   ,TreatyCatBackUp                 numeric(38, 4)       NULL
   ,TreatyRiskXS                    numeric(38, 4)       NULL
   ,TreatyCasClass                  numeric(38, 4)       NULL
   ,TreatyProRata                   numeric(38, 4)       NULL
   ,EngineeringSumInsuredTO         numeric(38, 4)       NULL
   ,EngineeringSumInsuredBS         numeric(38, 4)       NULL   
   ,FK_LocalCurrency				bigint              NOT NULL
   ,ReinsuranceLimit 				numeric(38, 4)       NULL   
   ,ReinsuranceExposure				numeric(38, 4)       NULL   
)

TRUNCATE TABLE #SectionExposureOriginalCurrency

INSERT INTO #SectionExposureOriginalCurrency
 (
    FK_Section
   ,FK_Syndicate
   ,FK_ShareType
   ,FK_Date
   ,FK_YOA
   ,FK_SettlementCurrency
   ,FK_OriginalCurrency
   ,FK_TriFocus
   ,FK_CRMBroker
   ,FK_Policy
   ,FK_QuoteFilter
   ,FK_HiddenStatusFilter
   ,FK_UnderwritingPlatform
   ,FK_InternalWrittenBinderStatus
   ,FK_ServiceCompany
   ,SpecialPurposeSyndicateApplies
   ,Limit
   ,Exposure
   ,OriginalLimit	
   ,OriginalExposure
   ,Excess
   ,Deductible
   ,EventLimit
   ,AggregateAmount
   ,AnnualRevenues
   ,EngineeringSumInsuredTO
   ,EngineeringSumInsuredBS
   ,FK_LocalCurrency
   ,ReinsuranceLimit
   ,ReinsuranceExposure
 )
--Generic calcs
SELECT
 FK_Section                     = s.PK_Section 
,FK_Syndicate                   = sst.FK_Syndicate                     
,FK_ShareType                   = sst.FK_ShareType                      
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_LimitCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Limit                          = CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.LimitAmountInLimitCCY * sst.SyndicateSplitMultiplier END 
,Exposure                       = CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.LimitAmountInLimitCCY * sst.TotalLineMultiplier END --Exposure is always at Beazley share
,OriginalLimit					= CASE WHEN st.ShareTypeName = 'Beazley Share' THEN NULL ELSE s.OriginalLimitInOriginalCCY END --Limit is always at total order
,OriginalExposure				= CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.OriginalLimitInOriginalCCY * sst.TotalLineMultiplier END --Exposure is always at Beazley share
,Excess                         = CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.ExcessAmountInLimitCCY * sst.SyndicateSplitMultiplier END --Excess is always at total order
,Deductible                     = CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.DeductibleAmountInLimitCCY * sst.SyndicateSplitMultiplier END --Deductible is always at total order
,EventLimit                     = s.EventLimitAmountInLimitCCY   * sst.TotalLineMultiplier
,AggregateAmount                = s.AggregateAmount              * sst.TotalLineMultiplier
,AnnualRevenues                 = p.AnnualRevenues               * sst.TotalLineMultiplier
,EngineeringSumInsuredTO        = CASE WHEN st.ShareTypeName = 'Beazley Share' THEN NULL ELSE s.EngineeringSumInsuredInLimitCCY END
,EngineeringSumInsuredBS        = CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE s.EngineeringSumInsuredInLimitCCY * sst.TotalLineMultiplier END --Exposure is always at Beazley share
,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
,ReinsuranceLimit				= CASE WHEN st.ShareTypeName = 'Beazley Share' THEN NULL ELSE
										CASE WHEN p.SourceSystem = 'Unirisx' THEN COALESCE(sl.LimitAmountInLimitCCY,s.LimitAmountInLimitCCY) ELSE s.LimitAmountInLimitCCY END
								  END		
,ReinsuranceExposure			= CASE WHEN st.ShareTypeName <> 'Beazley Share' THEN NULL ELSE
										CASE WHEN p.SourceSystem = 'Unirisx' THEN COALESCE(sl.LimitAmountInLimitCCY,s.LimitAmountInLimitCCY) * sst.TotalLineMultiplier ELSE s.LimitAmountInLimitCCY * sst.TotalLineMultiplier END
								  END		
FROM 
ODS.Section s WITH(NOLOCK)
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN 
#SectionShareType sst ON 
s.PK_Section = sst.FK_Section
INNER JOIN
Red.ShareType st WITH(NOLOCK) ON
sst.FK_ShareType = st.PK_ShareType
LEFT JOIN
#SectionLimit sl ON
sl.FK_Section = s.PK_Section

UNION ALL

--Beazley share rows for excess, deductible, limit & engineering sum insured TO (use total order value & NULL syndicate key)
SELECT
FK_Section                      = s.PK_Section                                 
,FK_Syndicate                   = NULL                     
,FK_ShareType                   = st.PK_ShareType                     
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_LimitCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Limit                          = NULL --Limit is always at total order
,Exposure                       = NULL
,OriginalLimit				    = s.OriginalLimitInOriginalCCY
,OriginalExposure				= NULL
,Excess                         = NULL--s.ExcessAmountInLimitCCY --Excess is always at total order
,Deductible                     = NULL--s.DeductibleAmountInLimitCCY  --Deductible is always at total order
,EventLimit                     = NULL
,AggregateAmount                = NULL
,AnnualRevenues                 = NULL
,EngineeringSumInsuredTO        = s.EngineeringSumInsuredInLimitCCY
,EngineeringSumInsuredBS        = NULL
,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
,ReinsuranceLimit				= CASE WHEN p.SourceSystem = 'Unirisx' THEN COALESCE(sl.LimitAmountInLimitCCY,s.LimitAmountInLimitCCY) ELSE s.LimitAmountInLimitCCY END								  
,ReinsuranceExposure			= NULL
FROM 
ODS.Section s WITH(NOLOCK)
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
Red.ShareType st WITH(NOLOCK) ON
st.ShareTypeName = 'Beazley Share'
LEFT JOIN
#SectionLimit sl ON
sl.FK_Section = s.PK_Section

UNION ALL
--Total order & slip order rows for exposure & engineering sum insured BS (use Beazley share value)
SELECT
FK_Section                      = s.PK_Section                                 
,FK_Syndicate                   = sst.FK_Syndicate                     
,FK_ShareType                   = st.PK_ShareType                     
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_LimitCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Limit                          = s.LimitAmountInLimitCCY * sst.SyndicateSplitMultiplier
,Exposure                       = s.LimitAmountInLimitCCY * sst.TotalLineMultiplier
,OriginalLimit				    = NULL
,OriginalExposure				= s.OriginalLimitInOriginalCCY * sst.TotalLineMultiplier
,Excess                         = s.ExcessAmountInLimitCCY * sst.SyndicateSplitMultiplier-- NULL
,Deductible                     = s.DeductibleAmountInLimitCCY * sst.SyndicateSplitMultiplier--NULL
,EventLimit                     = NULL
,AggregateAmount                = NULL
,AnnualRevenues                 = NULL
,EngineeringSumInsuredTO        = NULL
,EngineeringSumInsuredBS        = s.EngineeringSumInsuredInLimitCCY * sst.TotalLineMultiplier
,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
,ReinsuranceLimit				= NULL							  
,ReinsuranceExposure			= CASE WHEN p.SourceSystem = 'Unirisx' THEN COALESCE(sl.LimitAmountInLimitCCY,s.LimitAmountInLimitCCY) * sst.TotalLineMultiplier ELSE s.LimitAmountInLimitCCY * sst.TotalLineMultiplier END	
FROM 
ODS.Section s WITH(NOLOCK)
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
#SectionShareType sst ON
s.PK_Section = sst.FK_Section
INNER JOIN
Red.ShareType st_beaz WITH(NOLOCK) ON
sst.FK_ShareType = st_beaz.PK_ShareType
AND st_beaz.ShareTypeName = 'Beazley Share'
INNER JOIN
Red.ShareType st WITH(NOLOCK) ON
st.ShareTypeName IN ('Slip Order', 'Total Order')
LEFT JOIN
#SectionLimit sl ON
sl.FK_Section = s.PK_Section



/***************************************************************************************/
/*                                Set treaty aggs fields                               */
/***************************************************************************************/
/*For Beazley share, we use the "Exposure" field*/
UPDATE seoc SET
 TreatyCAT            = CASE WHEN cob.ClassOfBusinessCode IN ('CC','CS','CW','CZ') THEN seoc.Exposure END    
,TreatyAggXL	      = CASE WHEN cob.ClassOfBusinessCode IN ('CA', 'XL') THEN seoc.Exposure END
,TreatyCatBackUp      = CASE WHEN cob.ClassOfBusinessCode IN ('CB') THEN seoc.Exposure END
,TreatyRiskXS         = CASE WHEN cob.ClassOfBusinessCode IN ('CR') THEN
                          CASE
                          WHEN ISNULL(s.EventLimitAmountInLimitCCY, 0) <> 0 THEN seoc.EventLimit
                          ELSE
                              CASE
                                  WHEN ISNULL(s.NumberOfReinstatements, 0) <= 2 THEN seoc.Exposure * (ISNULL(s.NumberOfReinstatements, 0) + 1)
                                  ELSE seoc.Exposure * 3
                              END
                              
                          END
                        END
,TreatyCasClass       = CASE WHEN cob.ClassOfBusinessCode IN ('AW', 'AC') THEN seoc.Exposure END
,TreatyProRata        = CASE WHEN cob.ClassOfBusinessCode IN ('CT') THEN seoc.Exposure END

FROM 
#SectionExposureOriginalCurrency seoc
INNER JOIN ODS.Section s ON
seoc.FK_Section = s.PK_Section
INNER JOIN ODS.ClassOfBusiness cob ON
s.FK_ClassOfBusiness = cob.PK_ClassOfBusiness
INNER JOIN
Red.ShareType st ON
seoc.FK_ShareType = st.PK_ShareType
WHERE
st.ShareTypeName = 'Beazley Share'

/*For total order, we use the "Limit" field*/
UPDATE seoc SET
 TreatyCAT            = CASE WHEN cob.ClassOfBusinessCode IN ('CC','CS','CW','CZ') THEN seoc.Limit END    
,TreatyAggXL	      = CASE WHEN cob.ClassOfBusinessCode IN ('CA', 'XL') THEN seoc.Limit END
,TreatyCatBackUp      = CASE WHEN cob.ClassOfBusinessCode IN ('CB') THEN seoc.Limit END
,TreatyRiskXS         = CASE WHEN cob.ClassOfBusinessCode IN ('CR') THEN
                          CASE
                          WHEN ISNULL(s.EventLimitAmountInLimitCCY, 0) <> 0 THEN seoc.EventLimit
                          ELSE
                              CASE
                                  WHEN ISNULL(s.NumberOfReinstatements, 0) <= 2 THEN seoc.Limit * (ISNULL(s.NumberOfReinstatements, 0) + 1)
                                  ELSE seoc.Limit * 3
                              END
                              
                          END
                        END
,TreatyCasClass       = CASE WHEN cob.ClassOfBusinessCode IN ('AW', 'AC') THEN seoc.Limit END
,TreatyProRata        = CASE WHEN cob.ClassOfBusinessCode IN ('CT') THEN seoc.Limit END

FROM 
#SectionExposureOriginalCurrency seoc
INNER JOIN ODS.Section s  ON
seoc.FK_Section = s.PK_Section
INNER JOIN ODS.ClassOfBusiness cob ON
s.FK_ClassOfBusiness = cob.PK_ClassOfBusiness
INNER JOIN
Red.ShareType st ON
seoc.FK_ShareType = st.PK_ShareType
WHERE
st.ShareTypeName = 'Total Order'


/***************************************************************************************/
/*                           Load fact exposure                                        */
/***************************************************************************************/


TRUNCATE TABLE Red.FactExposure

---///DROP INDEXES & DISABLE CONSTRAINTS
ALTER TABLE Red.FactExposure NOCHECK CONSTRAINT ALL


IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExposure' AND CONSTRAINT_NAME = 'UQ_FactExposure_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactExposure
    DROP CONSTRAINT UQ_FactExposure_LogicalKey
END


IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		    WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactExposure' AND name = 'FactExposure_combined')
BEGIN
	DROP INDEX FactExposure_combined ON Red.FactExposure
END
---////////// 



--Does a minimally logged insert if this hint is provided, there is no clustered index,
--and the recovery model is not full
INSERT INTO Red.FactExposure WITH (TABLOCK)
 (
     FK_Section
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,Limit
    ,Exposure
    ,OriginalLimit	
    ,OriginalExposure
    ,Excess
    ,Deductible
    ,EventLimit
    ,AggregateAmount
	,AnnualRevenues
    ,TreatyCAT   
    ,TreatyAggXL
    ,TreatyCatBackUp
    ,TreatyRiskXS
    ,TreatyCasClass
    ,TreatyProRata
    ,EngineeringSumInsuredTO
    ,EngineeringSumInsuredBS	
	,FK_LocalCurrency
	,ReinsuranceLimit
	,ReinsuranceExposure
 )
--Exposure amounts in original currency
SELECT
 FK_Section                     = seoc.FK_Section
,FK_Syndicate                   = seoc.FK_Syndicate
,FK_ShareType                   = seoc.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = seoc.FK_Date
,FK_YOA                         = seoc.FK_YOA
,FK_SettlementCurrency          = seoc.FK_SettlementCurrency
,FK_OriginalCurrency            = seoc.FK_OriginalCurrency
,FK_TriFocus                    = seoc.FK_TriFocus
,FK_CRMBroker                   = seoc.FK_CRMBroker
,FK_Policy                      = seoc.FK_Policy
,FK_QuoteFilter                 = seoc.FK_QuoteFilter
,FK_HiddenStatusFilter          = seoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= seoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= seoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= seoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = seoc.SpecialPurposeSyndicateApplies
,Limit                          = seoc.Limit
,Exposure                       = seoc.Exposure
,OriginalLimit					= seoc.OriginalLimit	
,OriginalExposure				= seoc.OriginalExposure
,Excess                         = seoc.Excess
,Deductible                     = seoc.Deductible
,EventLimit                     = seoc.EventLimit
,AggregateAmount                = seoc.AggregateAmount
,AnnualRevenues                 = seoc.AnnualRevenues
,TreatyCAT                      = seoc.TreatyCAT
,TreatyAggXL                    = seoc.TreatyAggXL
,TreatyCatBackUp                = seoc.TreatyCatBackUp
,TreatyRiskXS                   = seoc.TreatyRiskXS
,TreatyCasClass                 = seoc.TreatyCasClass
,TreatyProRata                  = seoc.TreatyProRata
,EngineeringSumInsuredTO        = seoc.EngineeringSumInsuredTO
,EngineeringSumInsuredBS        = seoc.EngineeringSumInsuredBS
,FK_LocalCurrency				= seoc.FK_LocalCurrency
,ReinsuranceLimit				= seoc.ReinsuranceLimit
,ReinsuranceExposure			= seoc.ReinsuranceExposure
FROM 
#SectionExposureOriginalCurrency seoc
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Original Currency'

UNION ALL

--Exposure amounts in settlement currency
SELECT
FK_Section                              = seoc.FK_Section
,FK_Syndicate                           = seoc.FK_Syndicate
,FK_ShareType                           = seoc.FK_ShareType
,FK_ReportingCurrencyOverride           = rco.PK_ReportingCurrencyOverride
,FK_Date                                = seoc.FK_Date
,FK_YOA                                 = seoc.FK_YOA
,FK_SettlementCurrency                  = seoc.FK_SettlementCurrency
,FK_OriginalCurrency                    = seoc.FK_OriginalCurrency
,FK_TriFocus                            = seoc.FK_TriFocus
,FK_CRMBroker                           = seoc.FK_CRMBroker
,FK_Policy                              = seoc.FK_Policy
,FK_QuoteFilter                         = seoc.FK_QuoteFilter
,FK_HiddenStatusFilter                  = seoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform				= seoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus			= seoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany						= seoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies         = seoc.SpecialPurposeSyndicateApplies                                               
,Limit                                  = seoc.Limit                    / s.LimitCCYToSettlementCCYRate
,Exposure                               = seoc.Exposure                 / s.LimitCCYToSettlementCCYRate
,OriginalLimit							= seoc.OriginalLimit			/ s.LimitCCYToSettlementCCYRate
,OriginalExposure						= seoc.OriginalExposure			/ s.LimitCCYToSettlementCCYRate
,Excess                                 = seoc.Excess                   / s.LimitCCYToSettlementCCYRate
,Deductible                             = seoc.Deductible               / s.LimitCCYToSettlementCCYRate
,EventLimit                             = seoc.EventLimit               / s.LimitCCYToSettlementCCYRate
,AggregateAmount                        = seoc.AggregateAmount          / s.LimitCCYToSettlementCCYRate             
,AnnualRevenues                         = seoc.AnnualRevenues           / s.LimitCCYToSettlementCCYRate             
,TreatyCAT                              = seoc.TreatyCAT                / s.LimitCCYToSettlementCCYRate
,TreatyAggXL                            = seoc.TreatyAggXL              / s.LimitCCYToSettlementCCYRate
,TreatyCatBackUp                        = seoc.TreatyCatBackUp          / s.LimitCCYToSettlementCCYRate
,TreatyRiskXS                           = seoc.TreatyRiskXS             / s.LimitCCYToSettlementCCYRate
,TreatyCasClass                         = seoc.TreatyCasClass           / s.LimitCCYToSettlementCCYRate
,TreatyProRata                          = seoc.TreatyProRata            / s.LimitCCYToSettlementCCYRate
,EngineeringSumInsuredTO                = seoc.EngineeringSumInsuredTO  / s.LimitCCYToSettlementCCYRate
,EngineeringSumInsuredBS                = seoc.EngineeringSumInsuredBS  / s.LimitCCYToSettlementCCYRate
,FK_LocalCurrency						= seoc.FK_LocalCurrency
,ReinsuranceLimit						= seoc.ReinsuranceLimit			/ s.LimitCCYToSettlementCCYRate
,ReinsuranceExposure					= seoc.ReinsuranceExposure		/ s.LimitCCYToSettlementCCYRate

FROM 
#SectionExposureOriginalCurrency seoc
INNER JOIN 
ODS.Section s   ON
seoc.FK_Section = s.PK_Section
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Settlement Currency'

/*** SGP Enabled - Start ***/
--Exposure amounts in LOCAL currency 
UNION ALL
  
SELECT
FK_Section                              = seoc.FK_Section
,FK_Syndicate                           = seoc.FK_Syndicate
,FK_ShareType                           = seoc.FK_ShareType
,FK_ReportingCurrencyOverride           = rco.PK_ReportingCurrencyOverride
,FK_Date                                = seoc.FK_Date
,FK_YOA                                 = seoc.FK_YOA
,FK_SettlementCurrency                  = seoc.FK_SettlementCurrency
,FK_OriginalCurrency                    = seoc.FK_OriginalCurrency
,FK_TriFocus                            = seoc.FK_TriFocus
,FK_CRMBroker                           = seoc.FK_CRMBroker
,FK_Policy                              = seoc.FK_Policy
,FK_QuoteFilter                         = seoc.FK_QuoteFilter
,FK_HiddenStatusFilter                  = seoc.FK_HiddenStatusFilter
,FK_UnderwritingPlatform				= seoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus			= seoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany						= seoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies         = seoc.SpecialPurposeSyndicateApplies                                               
,Limit                                  = seoc.Limit                    * s.OriginalCCYToLocalCCYRate
,Exposure                               = seoc.Exposure                 * s.OriginalCCYToLocalCCYRate
,OriginalLimit							= seoc.OriginalLimit			* s.OriginalCCYToLocalCCYRate
,OriginalExposure						= seoc.OriginalExposure			* s.OriginalCCYToLocalCCYRate
,Excess                                 = seoc.Excess                   * s.OriginalCCYToLocalCCYRate
,Deductible                             = seoc.Deductible               * s.OriginalCCYToLocalCCYRate
,EventLimit                             = seoc.EventLimit               * s.OriginalCCYToLocalCCYRate
,AggregateAmount                        = seoc.AggregateAmount          * s.OriginalCCYToLocalCCYRate             
,AnnualRevenues                         = seoc.AnnualRevenues           * s.OriginalCCYToLocalCCYRate             
,TreatyCAT                              = seoc.TreatyCAT                * s.OriginalCCYToLocalCCYRate
,TreatyAggXL                            = seoc.TreatyAggXL              * s.OriginalCCYToLocalCCYRate
,TreatyCatBackUp                        = seoc.TreatyCatBackUp          * s.OriginalCCYToLocalCCYRate
,TreatyRiskXS                           = seoc.TreatyRiskXS             * s.OriginalCCYToLocalCCYRate
,TreatyCasClass                         = seoc.TreatyCasClass           * s.OriginalCCYToLocalCCYRate
,TreatyProRata                          = seoc.TreatyProRata            * s.OriginalCCYToLocalCCYRate
,EngineeringSumInsuredTO                = seoc.EngineeringSumInsuredTO  * s.OriginalCCYToLocalCCYRate
,EngineeringSumInsuredBS                = seoc.EngineeringSumInsuredBS  * s.OriginalCCYToLocalCCYRate
,FK_LocalCurrency						= seoc.FK_LocalCurrency
,ReinsuranceLimit						= seoc.ReinsuranceLimit			* s.OriginalCCYToLocalCCYRate
,ReinsuranceExposure					= seoc.ReinsuranceExposure		* s.OriginalCCYToLocalCCYRate

FROM 
#SectionExposureOriginalCurrency seoc
INNER JOIN 
ODS.Section s   ON
seoc.FK_Section = s.PK_Section
INNER JOIN 
ODS.Policy p   ON
s.FK_Policy = p.PK_Policy
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Local Currency'
AND p.sourcesystem = 'Unirisx'
AND s.beazleyOfficeLocation = 'Singapore'
/*** SGP Enabled - End ***/

/* Initialize ExcLBS columns with existing values */

UPDATE seoc
SET	LimitExcLBS 		= Limit
	,ExposureExcLBS 	= Exposure
	,ExcessExcLBS 		= Excess
	,DeductibleExcLBS 	= Deductible
FROM 
Red.FactExposure seoc

IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS

CREATE TABLE #ExcLBS
(
     FK_Section                     bigint              NOT NULL
	,FK_SectionExcLBS				bigint              NOT NULL
    ,Limit                          NUMERIC (38, 4) NULL
	,LimitExcLBS                    NUMERIC (38, 4) NULL
	,Excess                         NUMERIC (38, 4) NULL
	,ExcessExcLBS                   NUMERIC (38, 4) NULL
	,Deductible                     NUMERIC (38, 4) NULL
	,DeductibleExcLBS               NUMERIC (38, 4) NULL
)

TRUNCATE TABLE #ExcLBS

INSERT INTO  #ExcLBS
	(
	 FK_Section
	,FK_SectionExcLBS
    ,Limit
	,LimitExcLBS
	,Excess 
	,ExcessExcLBS
	,Deductible
	,DeductibleExcLBS
	)
SELECT
	 ss.PK_Section
	,sl.PK_Section
	,Limit = SUM(seocs.Limit)
	,LimitExcLBS = SUM(seocl.Limit)
	,Excess = SUM(seocs.Excess) 
	,ExcessExcLBS =  SUM(seocl.Excess) 
	,Deductible = SUM(seocs.Deductible)
	,DeductibleExcLBS = SUM(seocl.Deductible)
FROM 
	Red.FactExposure seocs
	INNER JOIN ODS.Section ss ON seocs.FK_Section = ss.PK_Section
	INNER JOIN Red.FactExposure seocl 
	ON seocs.FK_Policy 		= seocl.FK_Policy
	INNER JOIN ODS.Section sl ON seocl.FK_Section = sl.PK_Section
	AND ss.FK_ClassOfBusiness = sl.FK_ClassOfBusiness
	INNER JOIN ODS.UnderwritingPlatform ups
	ON ups.PK_UnderwritingPlatform = seocs.FK_UnderwritingPlatform
	INNER JOIN ODS.UnderwritingPlatform upl
	ON upl.PK_UnderwritingPlatform = seocl.FK_UnderwritingPlatform
WHERE ups.UnderwritingPlatformCode IN ('SYND','LBSM','LBSF')
	AND upl.UnderwritingPlatformCode = 'LBS'
GROUP BY 
	 ss.PK_Section
	,sl.PK_Section

/* Set ExcLBS columns to 0 for LBS sections */

UPDATE seocl
SET	LimitExcLBS 		= CASE WHEN seocs.Limit IS NULL THEN NULL ELSE 0 END
	,ExposureExcLBS 	= CASE WHEN seocs.Exposure IS NULL THEN NULL ELSE 0 END
	,ExcessExcLBS 		= CASE WHEN seocs.Excess IS NULL THEN NULL ELSE 0 END
	,DeductibleExcLBS 	= CASE WHEN seocs.Deductible IS NULL THEN NULL ELSE 0 END
FROM 
#ExcLBS exc
INNER JOIN Red.FactExposure seocl 
ON exc.FK_SectionExcLBS 		= seocl.FK_Section
INNER JOIN Red.FactExposure seocs 
ON exc.FK_Section 	= seocs.FK_Section
WHERE 
	ISNULL(exc.Limit,0) 		 = ISNULL(exc.LimitExcLBS,0)
	AND ISNULL(exc.Excess,0) 	 = ISNULL(exc.ExcessExcLBS,0)
	AND ISNULL(exc.Deductible,0) = ISNULL(exc.DeductibleExcLBS,0)


IF NOT EXISTS
(
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExposure' AND CONSTRAINT_NAME = 'UQ_FactExposure_LogicalKey'     
)
BEGIN
    ALTER TABLE Red.FactExposure
    ADD CONSTRAINT UQ_FactExposure_LogicalKey
    UNIQUE
        (
             FK_Section
            ,FK_Syndicate
            ,FK_ShareType
            ,FK_ReportingCurrencyOverride
        )
END
    

---/// CREATE INDEX & ENABLE CONSTRAINTS///
IF NOT EXISTS (
           select 1 from sys.indexes where name='FactExposure_combined'
           )
BEGIN
	CREATE NONCLUSTERED INDEX  FactExposure_combined ON Red.FactExposure (FK_ShareType,FK_QuoteFilter,FK_ReportingCurrencyOverride)
	INCLUDE (FK_SECTION, FK_YOA, FK_SettlementCurrency, Limit, LimitExcLBS, Exposure, ExposureExcLBS,Excess,ExcessExcLBS, Deductible,DeductibleExcLBS, ReinsuranceLimit,ReinsuranceExposure,EventLimit) 
END

ALTER TABLE Red.FactExposure CHECK CONSTRAINT ALL;
--//////////


IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType
IF (OBJECT_ID('tempdb..#SectionLimit') IS NOT NULL) DROP TABLE #SectionLimit
IF (OBJECT_ID('tempdb..#SectionExposureOriginalCurrency') IS NOT NULL) DROP TABLE #SectionExposureOriginalCurrency
IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactExposure';