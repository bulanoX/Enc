﻿

CREATE PROC [Red].[usp_PreProcessFactExposureProfileBand]

AS

SET NOCOUNT ON

IF (OBJECT_ID('staging.ValuesInReportingCurrency') IS NOT NULL)
DROP TABLE staging.ValuesInReportingCurrency

CREATE TABLE Staging.ValuesInReportingCurrency
(
    FK_Section                          bigint              NOT NULL
    ,FK_RateType                        bigint              NOT NULL
    ,FK_ReportingCurrency               bigint              NOT NULL
    ,FK_ReportingCurrencyOverride       bigint              NOT NULL
    ,FK_ShareType                       bigint              NOT NULL
    ,FK_AcquisitionCostBasis            bigint              NOT NULL
    ,FK_EntityPerspective               bigint              NOT NULL
    ,Department                         varchar(255)        NOT NULL
    ,Limit                              numeric(38,4)       NOT NULL
    ,Excess                             numeric(38,4)       NOT NULL
    ,Deductible                         numeric(38,4)       NOT NULL
    ,Exposure                           numeric(38,4)       NOT NULL
    ,WEPIncludingReinstatementPremuium  numeric(38,4)       NULL
    ,AuditModifyDateTime                datetime2(7)        NULL
    ,AuditCreateDateTime                datetime2(7)        DEFAULT (GETDATE()) NOT NULL
    ,AuditModifyDetails                 nvarchar(255)       NULL
)

/*
Amounts in reporting CCY
 To save on load time, this measure group is only available on the following bases:
    - Entity perspective - all
    - Share type = Beazley share
    - Acquisition cost basis - Gross, Net of external
    - Reporting currency - GBP, USD
*/

    SELECT 
    FK_Section                              = fe.FK_Section
    ,FK_ShareType                           = st.PK_ShareType
    ,FK_AcquisitionCostBasis                = acb.PK_AcquisitionCostBasis
    ,FK_EntityPerspective                   = sep.FK_EntityPerspective
    ,LimitInSettlementCCY                   = ISNULL(SUM(fe.Limit), 0)
    ,ExcessInSettlementCCY                  = ISNULL(SUM(fe.Excess), 0)
    ,DeductibleInSettlementCCY              = ISNULL(SUM(fe.Deductible), 0)
    ,ExposureInSettlementCCY                = ISNULL(SUM(fe.Exposure), 0)
	INTO #x
    FROM
    Red.FactExposure fe
    INNER JOIN
    Red.ReportingCurrencyOverride rc ON
    fe.FK_ReportingCurrencyOverride = rc.PK_ReportingCurrencyOverride
    INNER JOIN
    Red.ShareType st ON
    fe.FK_ShareType = st.PK_ShareType
    CROSS JOIN
    Red.AcquisitionCostBasis acb
    INNER JOIN
    ODS.SectionEntityPerspective sep ON
    fe.FK_Section = sep.FK_Section
    INNER JOIN
    ODS.EntityPerspective ep ON
    sep.FK_EntityPerspective = ep.PK_EntityPerspective
    WHERE
    rc.ReportingCurrencyOverrideName = 'Settlement Currency'
    AND st.ShareTypeName = 'Beazley Share'
    --AND ep.EntityPerspective IN ('Combined View', 'Syndicate View')
    AND acb.AcquisitionCostBasisName IN ('Gross Of Acquisition Cost', 'Net Of External Acquisition Cost')
    GROUP BY
    fe.FK_Section
    ,st.PK_ShareType
    ,acb.PK_AcquisitionCostBasis
    ,sep.FK_EntityPerspective
	-- 15 secs
	 
   SELECT
    FK_Section                                          = fp.FK_Section
    ,FK_ShareType                                       = st.PK_ShareType
    ,FK_AcquisitionCostBasis                            = acb.PK_AcquisitionCostBasis
    ,FK_EntityPerspective                               = fp.FK_EntityPerspective
    ,WEPIncludingReinstatementPremiumInSettlementCCY    = SUM(fp.WEPIncludingReinstatementPremium)
    into #y  
	FROM
    Red.FactWrittenEstimatedPremium fp
    INNER JOIN
    Red.ReportingCurrencyOverride rc ON
    fp.FK_ReportingCurrencyOverride = rc.PK_ReportingCurrencyOverride
    INNER JOIN
    Red.ShareType st ON
    fp.FK_ShareType = st.PK_ShareType
    INNER JOIN
    Red.AcquisitionCostBasis acb ON
    fp.FK_AcquisitionCostBasis = acb.PK_AcquisitionCostBasis
    INNER JOIN
    ODS.EntityPerspective ep ON
    fp.FK_EntityPerspective = ep.PK_EntityPerspective
    WHERE
    rc.ReportingCurrencyOverrideName = 'Settlement Currency'
    AND st.ShareTypeName = 'Beazley Share'
    --AND ep.EntityPerspective IN ('Syndicate View', 'Combined View')
    AND acb.AcquisitionCostBasisName IN ('Gross Of Acquisition Cost', 'Net Of External Acquisition Cost')
    GROUP BY
    fp.FK_Section
    ,st.PK_ShareType
    ,acb.PK_AcquisitionCostBasis
    ,fp.FK_EntityPerspective
	--   12 secs
 

TRUNCATE TABLE Staging.ValuesInReportingCurrency
INSERT INTO Staging.ValuesInReportingCurrency WITH(TABLOCK)
(
    FK_Section
    ,FK_RateType
    ,FK_ReportingCurrency
    ,FK_ReportingCurrencyOverride
    ,FK_ShareType
    ,FK_AcquisitionCostBasis
    ,FK_EntityPerspective
    ,Department
    ,Limit
    ,Excess
    ,Deductible
    ,Exposure
    ,WEPIncludingReinstatementPremuium
)
SELECT
FK_Section                          = x.FK_Section
,FK_RateType                        = scr.FK_RateType
,FK_ReportingCurrency               = scr.FK_ReportingCurrency
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride
,FK_ShareType                       = x.FK_ShareType
,FK_AcquisitionCostBasis            = x.FK_AcquisitionCostBasis
,FK_EntityPerspective               = x.FK_EntityPerspective
,Department                         = tf.DepartmentName
,Limit                              = x.LimitInSettlementCCY                            * scr.ExchangeRate
,Excess                             = x.ExcessInSettlementCCY                           * scr.ExchangeRate
,Deductible                         = x.DeductibleInSettlementCCY                       * scr.ExchangeRate
,Exposure                           = x.ExposureInSettlementCCY                         * scr.ExchangeRate
,WEPIncludingReinstatementPremuium  = y.WEPIncludingReinstatementPremiumInSettlementCCY * scr.ExchangeRate
FROM
 #x x
INNER JOIN
#y y ON
x.FK_Section = y.FK_Section
AND x.FK_ShareType = y.FK_ShareType
AND x.FK_AcquisitionCostBasis = y.FK_AcquisitionCostBasis
AND x.FK_EntityPerspective = y.FK_EntityPerspective
INNER JOIN
ODS.Section s ON
x.FK_Section = s.PK_Section
INNER JOIN
ODS.TriFocus tf ON
s.FK_TriFocus = tf.PK_TriFocus
INNER JOIN
Red.FactSettlementCurrencyRate scr ON
s.FK_SettlementCurrency = scr.FK_SettlementCurrency
AND s.FK_YOA = scr.FK_YOA
INNER JOIN
ODS.SettlementCurrency rc ON
scr.FK_ReportingCurrency = rc.PK_SettlementCurrency
INNER JOIN
Red.ReportingCurrencyOverride rco ON
rco.ReportingCurrencyOverrideName = 'Reporting Currency'
WHERE
EXISTS (SELECT 1 FROM ODS.ExposureProfileBand ef WHERE ef.Department = tf.DepartmentName)
AND rc.CurrencyCode IN ('USD', 'GBP')
AND s.IsQuote = 0
-- insert without index... 1m18s
-- insert with index...  1m07s (index creation 7 secs)


CREATE INDEX a ON [Staging].[ValuesInReportingCurrency]	( [FK_RateType], [FK_AcquisitionCostBasis], [FK_EntityPerspective])  INCLUDE ([FK_Section], [FK_ReportingCurrency], [FK_ReportingCurrencyOverride], [FK_ShareType], [Department], [Limit], [Excess], [Deductible], [Exposure], [WEPIncludingReinstatementPremuium])


TRUNCATE TABLE red.FactExposureProfileBand

--** Disable Constraints
ALTER TABLE red.FactExposureProfileBand NOCHECK CONSTRAINT ALL;
-- 

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExposureProfileBand' AND CONSTRAINT_NAME = 'UQ_FactExposureProfileBand_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactExposureProfileBand
    DROP CONSTRAINT UQ_FactExposureProfileBand_LogicalKey
END
 
EXEC utility.usp_PartitionTableOnScheme 
 	 @SchemaName		= 'Red'  
	,@TableName			= 'FactExposureProfileBand' 
	,@PartitionScheme	= 'PS_FEPB'

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'ValuesInReportingCurrency';