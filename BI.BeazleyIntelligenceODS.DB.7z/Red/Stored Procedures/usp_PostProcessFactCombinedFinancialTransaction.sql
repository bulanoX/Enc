﻿

CREATE PROCEDURE [Red].[usp_PostProcessFactCombinedFinancialTransaction]
AS BEGIN
		IF (OBJECT_ID('staging.FactCombinedFinancialTransaction_275') IS NOT NULL) BEGIN DROP TABLE staging.FactCombinedFinancialTransaction_275 END

		CREATE TABLE staging.FactCombinedFinancialTransaction_275(
			[FK_AcquisitionCostBasis]				[bigint] NOT NULL,
			[FK_EntityPerspective]					[bigint] NOT NULL,
			[FK_ShareType]							[bigint] NOT NULL,
			[FK_Syndicate]							[bigint] NOT NULL,
			[FK_ReportingCurrencyOverride]			[bigint] NOT NULL,
			[FK_Date]								[datetime] NOT NULL,
			[FK_YOA]								[bigint] NOT NULL,
			[FK_SettlementCurrency]					[bigint] NOT NULL,
			[FK_OriginalCurrency]					[bigint] NOT NULL,
			[FK_LocalCurrency]						[bigint] NOT NULL,
			[FK_Section]							[bigint] NOT NULL,
			[FK_DevelopmentPeriod]					[bigint] NOT NULL,
			[FK_TriFocus]							[bigint] NOT NULL,
			[FK_ClaimExposure]						[bigint] NULL,
			[FK_LPSOTransaction]					[bigint] NULL,
			[FK_NonLLoydsPremiumTransaction]		[bigint] NULL,
			[FK_GQDTransactionType]					[bigint] NOT NULL,
			[FK_SpecialCategoryCatastropheMatrix]   [bigint] NOT NULL,
			[FK_Policy]								[bigint] NOT NULL,
			[FK_HiddenStatusFilter]					[bigint] NOT NULL,
			[FK_QuoteFilter]						[bigint] NOT NULL,
			[FK_CRMBroker]							[bigint] NOT NULL,
			[FK_UnderwritingPlatform]				[bigint] NOT NULL,
			[FK_InternalWrittenBinderStatus]		[bigint] NOT NULL,
			--[AllCategories]							[numeric](19, 4) NULL,
			[AccountedPremium]						[numeric](19, 4) NULL,
			[AccountedExternalAcquisitionCost]		[numeric](19, 4) NULL,
			[AccountedInternalAcquisitionCost]		[numeric](19, 4) NULL,
			--[DelinkedPremium]						[numeric](19, 4) NULL,
			--[ClaimPaid]								[numeric](19, 4) NULL,
			--[ClaimOutstanding]						[numeric](19, 4) NULL,
			--[LPSOVATAmount]							[numeric](19, 4) NULL,
			--[IPTOverseasTax]                        [numeric](38, 12) NULL,
			--[IPTUKTax]                              [numeric](38, 12) NULL,
			--[SpecialPurposeSyndicateApplies]		[bit] NOT NULL,
			--[ClaimIncurred]							AS (case when [ClaimPaid] IS NULL AND [ClaimOutstanding] IS NULL then NULL else isnull([ClaimPaid],(0))+isnull([ClaimOutstanding],(0)) end),
			--[ReinsurancePremiumFac]					[numeric](19, 4) NULL,
			--[ReinsuranceRecoveryFac]				[numeric](19, 4) NULL,
			--PartitionID								[int] NULL,
			--ClaimTeamExaminer						[varchar](255) NULL,
			FK_ClaimTeamExaminer					[bigint] NULL,
			[FK_ServiceCompany]						[bigint] NOT NULL,
		) ON [PRIMARY]


		DECLARE		@PKGrossOfAcquisitionCost	BIGINT,
					@PKUnderwritingPlatform		BIGINT

		SELECT		@PKGrossOfAcquisitionCost = PK_AcquisitionCostBasis 
		FROM		red.AcquisitionCostBasis
		WHERE		AcquisitionCostBasisName = 'Gross Of Acquisition Cost'

		SELECT		@PKUnderwritingPlatform	= PK_UnderwritingPlatform 
		FROM		Ods.UnderwritingPlatform 
		WHERE		UnderwritingPlatformCode = 'SLBS'

		/***********************************************************************************/
		/*                Combined Load                                                 */
		/***********************************************************************************/


		TRUNCATE TABLE staging.FactCombinedFinancialTransaction_275

		--Does a minimally logged insert if this TABLOCK hint is provided, there is no clustered index,
		----and the recovery model is not full*/
		INSERT INTO staging.FactCombinedFinancialTransaction_275 WITH (TABLOCK)
		 (
			FK_LPSOTransaction
			,FK_NonLloydsPremiumTransaction
			,FK_EntityPerspective
			,FK_AcquisitionCostBasis
			,FK_Syndicate
			,FK_ShareType
			,FK_ReportingCurrencyOverride
			,FK_Date
			,FK_YOA
			,FK_SettlementCurrency
			,FK_OriginalCurrency
			,FK_LocalCurrency
			,FK_GQDTransactionType
			,FK_Section
			,FK_TriFocus
			,FK_CRMBroker
			--,SpecialPurposeSyndicateApplies
			,FK_DevelopmentPeriod
			,FK_ClaimExposure
			,FK_SpecialCategoryCatastropheMatrix
			,FK_Policy
			,FK_QuoteFilter
			,FK_HiddenStatusFilter
			,FK_UnderwritingPlatform
			,FK_InternalWrittenBinderStatus
			,FK_ServiceCompany
			--,AllCategories
			,AccountedPremium
			,AccountedExternalAcquisitionCost
			,AccountedInternalAcquisitionCost
		 --   ,ClaimPaid
		 --   ,ClaimOutstanding
		 --   ,DelinkedPremium
		 --   ,LPSOVATAmount
			--,IPTOverseasTax                  
		 --   ,IPTUKTax                      
		 --   ,ReinsurancePremiumFac
		 --   ,ReinsuranceRecoveryFac
		 --   ,PartitionID
		 )
		 SELECT		fact.FK_LPSOTransaction
					,fact.FK_NonLloydsPremiumTransaction
					,fact.FK_EntityPerspective
					,fact.FK_AcquisitionCostBasis
					,fact.FK_Syndicate
					,fact.FK_ShareType
					,fact.FK_ReportingCurrencyOverride
					,fact.FK_Date
					,fact.FK_YOA
					,fact.FK_SettlementCurrency
					,fact.FK_OriginalCurrency
					,fact.FK_LocalCurrency
					,fact.FK_GQDTransactionType
					,fact.FK_Section
					,fact.FK_TriFocus
					,fact.FK_CRMBroker
					--,SpecialPurposeSyndicateApplies
					,fact.FK_DevelopmentPeriod
					,fact.FK_ClaimExposure
					,fact.FK_SpecialCategoryCatastropheMatrix
					,fact.FK_Policy
					,fact.FK_QuoteFilter
					,fact.FK_HiddenStatusFilter
					,fact.FK_UnderwritingPlatform
					,fact.FK_InternalWrittenBinderStatus
					,fact.FK_ServiceCompany
					--,AllCategories
					,fact.AccountedPremium
					,fact.AccountedExternalAcquisitionCost
					,fact.AccountedInternalAcquisitionCost
		FROM		Red.FactCombinedFinancialTransaction fact
		
		INNER JOIN	Ods.Policy p
				ON	fact.FK_Policy = p.PK_Policy

		WHERE		fact.FK_AcquisitionCostBasis = @PKGrossOfAcquisitionCost
				AND fact.FK_UnderwritingPlatform = @PKUnderwritingPlatform
				AND p.SourceSystem = 'Unirisx'


		UPDATE		fact 
			SET		fact.AccountedPremium = fact.AccountedPremium - (gross.AccountedPremium * sac.AcquisitionCostMultiplier)
		FROM		red.FactCombinedFinancialTransaction  fact
		INNER JOIN	staging.FactCombinedFinancialTransaction_275 gross 
				on	gross.FK_AcquisitionCostBasis			= @PKGrossOfAcquisitionCost
				and (fact.FK_Section						= gross.FK_Section)
				and (
						fact.FK_LPSOTransaction				= gross.FK_LPSOTransaction 
						OR (fact.FK_LPSOTransaction IS NULL AND  gross.FK_LPSOTransaction IS NULL)
					)      
				and (
						fact.FK_NonLloydsPremiumTransaction	= gross.FK_NonLloydsPremiumTransaction	
						OR (fact.FK_NonLloydsPremiumTransaction IS NULL AND gross.FK_NonLloydsPremiumTransaction IS NULL)
					)
				and (fact.FK_EntityPerspective				= gross.FK_EntityPerspective)
				and (fact.FK_Syndicate						= gross.FK_Syndicate)
				and (fact.FK_ShareType						= gross.FK_ShareType)
				and (fact.FK_ReportingCurrencyOverride		= gross.FK_ReportingCurrencyOverride)
				and (fact.FK_Date							= gross.FK_Date)
				and (fact.FK_YOA							= gross.FK_YOA)
				and (fact.FK_SettlementCurrency				= gross.FK_SettlementCurrency)
				and (fact.FK_OriginalCurrency				= gross.FK_OriginalCurrency)
				and (fact.FK_LocalCurrency					= gross.FK_LocalCurrency)
				and (fact.FK_GQDTransactionType				= gross.FK_GQDTransactionType)
				and (fact.FK_TriFocus						= gross.FK_TriFocus)
				and (fact.FK_CRMBroker						= gross.FK_CRMBroker)
				and (fact.FK_DevelopmentPeriod				= gross.FK_DevelopmentPeriod)
				and (
						fact.FK_ClaimExposure					= gross.FK_ClaimExposure 
						OR (fact.FK_ClaimExposure IS NULL AND gross.FK_ClaimExposure IS NULL)
					)                   
				and (fact.FK_SpecialCategoryCatastropheMatrix = gross.FK_SpecialCategoryCatastropheMatrix)
				and (fact.FK_Policy							= gross.FK_Policy)
				and (fact.FK_QuoteFilter					= gross.FK_QuoteFilter)
				and (fact.FK_HiddenStatusFilter				= gross.FK_HiddenStatusFilter)
				and (fact.FK_UnderwritingPlatform			= gross.FK_UnderwritingPlatform)			
				and (
						fact.FK_InternalWrittenBinderStatus	= gross.FK_InternalWrittenBinderStatus 
						OR (fact.FK_InternalWrittenBinderStatus IS NULL AND gross.FK_InternalWrittenBinderStatus IS NULL)
					)
				and (
						fact.FK_ServiceCompany					= gross.FK_ServiceCompany 
						OR (fact.FK_ServiceCompany IS NULL AND gross.FK_ServiceCompany IS NULL)
					)

		INNER JOIN ODS.SectionAcquisitionCost sac
		ON fact.FK_Section = sac.FK_Section
		AND fact.FK_EntityPerspective = sac.FK_EntityPerspective

		INNER JOIN ods.AcquisitionCostType act
		ON act.PK_AcquisitionCostType = sac.FK_AcquisitionCostType

		WHERE	fact.FK_AcquisitionCostBasis <> @PKGrossOfAcquisitionCost
		AND act.AcquisitionCostTypeCode = 'X'
		-- DROP STAGING TABLE
		--DROP TABLE staging.FactCombinedFinancialTransaction_275

--Index creation & constraint enabling 

IF NOT EXISTS (	SELECT 1 FROM BeazleyIntelligenceODS.sys.indexes  
		    WHERE name = 'FactCombinedFinancialTransaction_Combined'
			  )
		BEGIN   
			CREATE NONCLUSTERED INDEX FactCombinedFinancialTransaction_Combined 
			ON  BeazleyIntelligenceODS.Red.FactCombinedFinancialTransaction(FK_AcquisitionCostBasis,FK_ShareType, FK_ReportingCurrencyOverride,FK_QuoteFilter)
			INCLUDE(FK_EntityPerspective, FK_YOA,FK_SettlementCurrency, FK_Section,AccountedPremium,AccountedPremiumExcIPTOverseasTax,IPTOverseasTax,IPTUKTax);
		END

ALTER TABLE BeazleyIntelligenceODS.Red.FactCombinedFinancialTransaction CHECK CONSTRAINT ALL;


END
GO