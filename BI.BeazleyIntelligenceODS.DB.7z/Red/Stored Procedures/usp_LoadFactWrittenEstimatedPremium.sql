﻿CREATE PROCEDURE [Red].[usp_LoadFactWrittenEstimatedPremium]
AS

SET NOCOUNT ON

DECLARE @GUID UNIQUEIDENTIFIER 
SET		@GUID = (SELECT MAX(PartitionGUID) FROM staging.PartitionMap WHERE PartitionID=1 and storedProcedureId = 3)


/***************************************************************************************/
/*       Section premium fact in original currency (Section + Section Line level)      */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionPremiumOriginalCurrency') IS NOT NULL) DROP TABLE #SectionPremiumOriginalCurrency

CREATE TABLE #SectionPremiumOriginalCurrency
 (
     FK_Section                         bigint              NOT NULL
    ,FK_EntityPerspective               bigint              NOT NULL
    ,FK_Syndicate                       bigint              NULL
    ,FK_ShareType                       bigint              NOT NULL
    ,FK_AcquisitionCostBasis            bigint              NOT NULL
    ,FK_Date                            datetime            NOT NULL
    ,FK_YOA                             bigint              NOT NULL
    ,FK_SettlementCurrency              bigint              NOT NULL
    ,FK_OriginalCurrency                bigint              NOT NULL
	,FK_LocalCurrency                   bigint              NOT NULL
    ,FK_TriFocus                        bigint              NOT NULL
    ,FK_CRMBroker                       bigint              NOT NULL
    ,FK_Policy                          bigint              NOT NULL
    ,FK_QuoteFilter                     bigint              NOT NULL
    ,FK_HiddenStatusFilter              bigint              NOT NULL
    ,FK_RenewalDueDate                  datetime            NOT NULL
	,FK_UnderwritingPlatform			bigint				NOT NULL
	,FK_InternalWrittenBinderStatus		bigint				NOT NULL
	,FK_ServiceCompany					bigint				NOT NULL
    ,SpecialPurposeSyndicateApplies     bit                 NOT NULL
    ,OriginalEPI                        numeric(38,4)       NULL
    ,MinimumPremium                     numeric(38,4)       NULL
    ,DepositPremium                     numeric(38,4)       NULL
    ,RateOnLinePremiumEntered           numeric(38,4)       NULL
    ,AdjustmentBaseAmount               numeric(38,4)       NULL
    ,AdjustmentPremium                  numeric(38,4)       NULL  
    ,CashPosition                       numeric(38,4)       NULL
    ,WrittenOrEstimatedPremium          numeric(38,4)       NULL
	,WrittenOrEstimatedPremiumExcLBS	numeric(38,4)       NULL
	,LatestEPI					        numeric(38,4)       NULL
	,Premium					        numeric(38,4)       NULL
	,OriginalGrossPremium				numeric(38,4)       NULL
    ,DeclarationWEP                     numeric(38,4)       NULL
    ,ReinstatementPremium               numeric(38,4)       NULL
    ,PremiumIncomeLimit                 numeric(38,4)       NULL
    ,BenchmarkBaseWEP                   numeric(38,4)       NULL
    ,BenchmarkPremium                   numeric(38,4)       NULL
    ,ProfitCommissionNotionalWEP        numeric(38,4)       NULL
    ,ProfitCommissionBaseWEP            numeric(38,4)       NULL
    ,ExpectedLoss                       numeric(38,4)       NULL
	,RatingAdequacyWEP					numeric(38,4)       NULL
	,RatingAdequacyBaseWEP				numeric(38,4)       NULL
    ,RateChangeBaseWEP                  numeric(38,4)       NULL
    ,RateChangeWEP                      numeric(38,4)       NULL
    ,RateChangeBaseDeclarationWEP       numeric(38,4)       NULL
    ,RateChangeDeclarationWEP           numeric(38,4)       NULL
    ,RateChangeQuestionnaireWEP         numeric(38,4)       NULL
    ,RateChangeOtherWEP                 numeric(38,4)       NULL
    ,RateChangeTermsAndConditionsWEP    numeric(38,4)       NULL
    ,RateChangeLimitWEP                 numeric(38,4)       NULL
    ,RateChangeDeductibleWEP            numeric(38,4)       NULL
    ,RateChangeRiskWEP                  numeric(38,4)       NULL
    ,RateChangeExposureWEP              numeric(38,4)       NULL
    ,BeazleyLedWEP                      numeric(38,4)       NULL
    ,RenewedWEP                         numeric(38,4)       NULL
    ,ExpectedPICCAmount                 numeric(38,4)       NULL
    ,USQuakeWEP                         numeric(38,4)       NULL
    ,USWindWEP                          numeric(38,4)       NULL
    ,USNonCatWEP                        numeric(38,4)       NULL
    ,NonUSCatWEP                        numeric(38,4)       NULL
    ,NonUSNonCatWEP                     numeric(38,4)       NULL
 )


TRUNCATE TABLE #SectionPremiumOriginalCurrency

INSERT INTO #SectionPremiumOriginalCurrency
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_AcquisitionCostBasis
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_LocalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,FK_RenewalDueDate
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,OriginalEPI
    ,MinimumPremium
    ,DepositPremium
    ,RateOnLinePremiumEntered
    ,AdjustmentBaseAmount
    ,AdjustmentPremium
    ,CashPosition
    ,WrittenOrEstimatedPremium
	,WrittenOrEstimatedPremiumExcLBS 
	,LatestEPI
	,Premium
	,OriginalGrossPremium	
    ,DeclarationWEP
    ,ReinstatementPremium
    ,PremiumIncomeLimit
    ,BenchmarkBaseWEP
    ,BenchmarkPremium
    ,ProfitCommissionNotionalWEP
    ,ProfitCommissionBaseWEP
    ,ExpectedLoss
	,RatingAdequacyWEP
	,RatingAdequacyBaseWEP
    ,RateChangeBaseWEP
    ,RateChangeWEP
	,RateChangeBaseDeclarationWEP
	,RateChangeDeclarationWEP
    ,RateChangeQuestionnaireWEP
    ,RateChangeOtherWEP
    ,RateChangeTermsAndConditionsWEP
    ,RateChangeLimitWEP
    ,RateChangeDeductibleWEP
    ,RateChangeRiskWEP
    ,RateChangeExposureWEP
    ,BeazleyLedWEP
    ,RenewedWEP
    ,ExpectedPICCAmount
    ,USQuakeWEP
    ,USWindWEP
    ,USNonCatWEP
    ,NonUSCatWEP
    ,NonUSNonCatWEP
)

SELECT
FK_Section                          = spc.FK_Section 
,FK_EntityPerspective               = sep.FK_EntityPerspective                             
,FK_Syndicate                       = sst.FK_Syndicate                      
,FK_ShareType                       = sst.FK_ShareType                     
,FK_AcquisitionCostBasis            = sacb.FK_AcquisitionCostBasis 
,FK_Date                            = s.FK_InceptionDate
,FK_YOA                             = s.FK_YOA
,FK_SettlementCurrency              = s.FK_SettlementCurrency
,FK_OriginalCurrency                = s.FK_OriginalCurrency
,FK_LocalCurrency					= ISNULL(s.FK_LocalCurrency,0)
,FK_TriFocus                        = s.FK_TriFocus
,FK_CRMBroker                       = s.FK_CRMBroker
,FK_Policy                          = p.PK_Policy
,FK_QuoteFilter                     = s.FK_QuoteFilter
,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
,FK_RenewalDueDate                  = s.FK_RenewalDueDate
,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies     = s.SpecialPurposeSyndicateApplies

,OriginalEPI                        = spc.OriginalEPI                       * sep.PerspectiveMultiplier     * sacb.OriginalEPITotalAcquisitionCostMultiplier  * sst.TotalLineMultiplier
,MinimumPremium                     = spc.MinimumPremium                    * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,DepositPremium                     = spc.DepositPremium                    * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateOnLinePremiumEntered           = spc.RateOnLinePremiumEntered          * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,AdjustmentBaseAmount               = spc.AdjustmentBaseAmount              * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,AdjustmentPremium                  = spc.AdjustmentPremium                 * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,CashPosition                       = s.AgressoPayedRate *
                                        CASE WHEN s.SourceSystem = 'Eurobase' AND uw.UnderwritingPlatformName = 'Beazley Insurance dac' 
                                             -- use Orginal EPI
                                             THEN spc.OriginalEPI * sep.PerspectiveMultiplier * sacb.OriginalEPITotalAcquisitionCostMultiplier  * sst.TotalLineMultiplier
                                             WHEN s.WEPBasis = 'Booked Premium' AND s.SourceSystem NOT IN ('Eurobase','CIPS')
                                             --use WrittenOrEstimatedPremium
                                             THEN spc.WrittenOrEstimatedPremium         * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier 
                                             WHEN s.WEPBasis = 'Estimated Premium' AND s.SourceSystem NOT IN ('Eurobase','CIPS')
                                             --use LatestEPIInOriginalCCY
                                             THEN s.LatestEPIInOriginalCCY			* sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier 
                                       END
,WrittenOrEstimatedPremium          = spc.WrittenOrEstimatedPremium         * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,WrittenOrEstimatedPremiumExcLBS	= spc.WrittenOrEstimatedPremium			* sep.PerspectiveMultiplier		* (
																												CASE 
																													WHEN acb.AcquisitionCostBasisName <> 'Gross Of Acquisition Cost' 
																													THEN sacb.AcquisitionCostMultiplier + lbs.LBSAcquisitionCostMultiplier 
																													ELSE sacb.AcquisitionCostMultiplier 
																												END
																											) 

																																							  * sst.TotalLineMultiplier
,LatestEPI					        = spc.LatestEPI					        * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,Premium					        = spc.Premium					        * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,OriginalGrossPremium				= spc.OriginalGrossPremium				* sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,DeclarationWEP                     = spc.DeclarationWEP                    * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,ReinstatementPremium               = spc.ReinstatementPremium              * sep.PerspectiveMultiplier                                                       * sst.TotalLineMultiplier --Acquisition costs don't apply to reinstatement premium
,PremiumIncomeLimit                 = spc.PremiumIncomeLimit                * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,BenchmarkBaseWEP                   = spc.BenchmarkBaseWEP                  * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,BenchmarkPremium                   = spc.BenchmarkPremium                  * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,ProfitCommissionNotionalWEP        = spc.ProfitCommissionNotionalWEP       * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,ProfitCommissionBaseWEP            = spc.ProfitCommissionBaseWEP           * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,ExpectedLoss                       = spc.ExpectedLoss                      * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RatingAdequacyWEP                  = spc.RatingAdequacyWEP                 * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RatingAdequacyBaseWEP              = spc.RatingAdequacyBaseWEP             * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeBaseWEP                  = spc.RateChangeBaseWEP                 * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeWEP                      = spc.RateChangeWEP                     * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeBaseDeclarationWEP       = spc.RateChangeBaseDeclarationWEP      * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeDeclarationWEP           = spc.RateChangeDeclarationWEP          * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeQuestionnaireWEP         = spc.RateChangeQuestionnaireWEP        * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeOtherWEP                 = spc.RateChangeOtherWEP                * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeTermsAndConditionsWEP    = spc.RateChangeTermsAndConditionsWEP   * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeLimitWEP                 = spc.RateChangeLimitWEP                * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeDeductibleWEP            = spc.RateChangeDeductibleWEP           * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeRiskWEP                  = spc.RateChangeRiskWEP                 * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RateChangeExposureWEP              = spc.RateChangeExposureWEP             * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,BeazleyLedWEP                      = spc.BeazleyLedWEP                     * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,RenewedWEP                         = spc.RenewedWEP                        * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,ExpectedPICCAmount                 = spc.ExpectedPICCAmount                * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,USQuakeWEP                         = spc.USQuakeWEP                        * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,USWindWEP                          = spc.USWindWEP                         * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,USNonCatWEP                        = spc.USNonCatWEP                       * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,NonUSCatWEP                        = spc.NonUSCatWEP                       * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier
,NonUSNonCatWEP                     = spc.NonUSNonCatWEP                    * sep.PerspectiveMultiplier     * sacb.AcquisitionCostMultiplier                  * sst.TotalLineMultiplier

FROM 
staging.SectionPremiumCalculations spc

INNER JOIN  ODS.Section s 
ON spc.FK_Section = s.PK_Section

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionEntityPerspective sep 
ON s.PK_Section = sep.FK_Section

INNER JOIN ODS.UnderwritingPlatform uw
ON s.FK_UnderwritingPlatform = uw.PK_UnderwritingPlatform

INNER JOIN  staging.SectionAcquisitionCostBasis sacb 
ON spc.FK_Section = sacb.FK_Section
AND sep.FK_EntityPerspective = sacb.FK_EntityPerspective

INNER JOIN Red.AcquisitionCostBasis acb
ON sacb.FK_AcquisitionCostBasis = acb.PK_AcquisitionCostBasis

INNER JOIN 
staging.SectionShareType sst ON 
spc.FK_Section = sst.FK_Section

INNER JOIN staging.PartitionMap PM 
		ON PM.FK_ShareType = sst.FK_ShareType  
			AND PM.FK_AcquisitionCostBasis = sacb.FK_AcquisitionCostBasis  
			AND PM.FK_EntityPerspective = sacb.FK_EntityPerspective   
/* for brexit */
LEFT JOIN (
                SELECT		sac.FK_Section, 
							sac.FK_EntityPerspective,
                            CAST(SUM(CASE WHEN act.AcquisitionCostTypeCode='X' THEN sac.AcquisitionCostMultiplier ELSE 0 END) AS NUMERIC(38,12)) as LBSAcquisitionCostMultiplier
                FROM		[ODS].[SectionAcquisitionCost] sac
                INNER JOIN	[ODS].[AcquisitionCostType] act
						ON	sac.FK_AcquisitionCostType=PK_AcquisitionCostType
                GROUP BY	sac.FK_Section, sac.FK_EntityPerspective
) lbs		ON	lbs.FK_Section=sep.FK_Section
			AND lbs.FK_EntityPerspective=sep.FK_EntityPerspective
/* end for brexit */ 

WHERE PM.StoredProcedureId = 3
AND PM.PartitionGUID = @GUID


CREATE INDEX [IX_SectionPremiumOriginalCurrency]
ON [#SectionPremiumOriginalCurrency] ([FK_Section])
INCLUDE ([FK_EntityPerspective],[FK_Syndicate],[FK_ShareType],[FK_AcquisitionCostBasis],[WrittenOrEstimatedPremium],WrittenOrEstimatedPremiumExcLBS,[LatestEPI],[Premium],[ReinstatementPremium])





/***************************************************************************************/
/*                                Load staging fact premium                                    */
/***************************************************************************************/
IF (OBJECT_ID('staging.FactWrittenEstimatedPremium') IS NOT NULL) DROP TABLE staging.FactWrittenEstimatedPremium

CREATE TABLE Staging.FactWrittenEstimatedPremium
(
	[FK_Section] [bigint] NOT NULL,
	[FK_Syndicate] [bigint] NULL,
	[FK_ShareType] [bigint] NOT NULL,
	[FK_AcquisitionCostBasis] [bigint] NOT NULL,
	[FK_ReportingCurrencyOverride] [bigint] NOT NULL,
	[FK_Date] [datetime] NOT NULL,
	[FK_YOA] [bigint] NOT NULL,
	[FK_SettlementCurrency] [bigint] NOT NULL,
	[FK_LocalCurrency] [bigint] NOT NULL,
	[FK_TriFocus] [bigint] NOT NULL,
	[FK_EntityPerspective] [bigint] NOT NULL,
	[FK_OriginalCurrency] [bigint] NOT NULL,
	[FK_Policy] [bigint] NOT NULL,
	[FK_HiddenStatusFilter] [bigint] NOT NULL,
	[FK_QuoteFilter] [bigint] NOT NULL,
	[FK_RenewalDueDate] [datetime] NOT NULL,
	[FK_CRMBroker] [bigint] NOT NULL,
	[FK_UnderwritingPlatform] [bigint] NOT NULL,
	[FK_InternalWrittenBinderStatus] [bigint] NOT NULL,
	[SpecialPurposeSyndicateApplies] [bit] NOT NULL,
	[OriginalEPI] [numeric](38, 4) NULL,
	[MinimumPremium] [numeric](38, 4) NULL,
	[DepositPremium] [numeric](38, 4) NULL,
	[RateOnLinePremiumEntered] [numeric](38, 4) NULL,
	[AdjustmentBaseAmount] [numeric](38, 4) NULL,
	[AdjustmentPremium] [numeric](38, 4) NULL,
    [CashPosition] [numeric](38, 4) NULL,
	[WrittenOrEstimatedPremium] [numeric](38, 4) NULL,
	[LatestEPI] [numeric](38, 4) NULL,
	[Premium] [numeric](38, 4) NULL,
	[OriginalGrossPremium] [numeric](38, 4) NULL,
	[DeclarationWEP] [numeric](38, 4) NULL,
	[ReinstatementPremium] [numeric](38, 4) NULL,
	[PremiumIncomeLimit] [numeric](38, 4) NULL,
	[BenchmarkBaseWEP] [numeric](38, 4) NULL,
	[BenchmarkPremium] [numeric](38, 4) NULL,
	[ProfitCommissionNotionalWEP] [numeric](38, 4) NULL,
	[ProfitCommissionBaseWEP] [numeric](38, 4) NULL,
	[ExpectedLoss] [numeric](38, 4) NULL,
	[RatingAdequacyWEP] [numeric](38,4) NULL,
	[RatingAdequacyBaseWEP] [numeric](38,4) NULL,
	[RateChangeBaseWEP] [numeric](38, 4) NULL,
	[RateChangeWEP] [numeric](38, 4) NULL,
	[RateChangeBaseDeclarationWEP] [numeric](38, 4) NULL,
	[RateChangeDeclarationWEP] [numeric](38, 4) NULL,
	[RateChangeQuestionnaireWEP] [numeric](38, 4) NULL,
	[RateChangeOtherWEP] [numeric](38, 4) NULL,
	[RateChangeTermsAndConditionsWEP] [numeric](38, 4) NULL,
	[RateChangeLimitWEP] [numeric](38, 4) NULL,
	[RateChangeDeductibleWEP] [numeric](38, 4) NULL,
	[RateChangeRiskWEP] [numeric](38, 4) NULL,
	[RateChangeExposureWEP] [numeric](38, 4) NULL,
	[BeazleyLedWEP] [numeric](38, 4) NULL,
	[RenewedWEP] [numeric](38, 4) NULL,
	[ExpectedPICCAmount] [numeric](38, 4) NULL,
	[USQuakeWEP] [numeric](38, 4) NULL,
	[USWindWEP] [numeric](38, 4) NULL,
	[USNonCatWEP] [numeric](38, 4) NULL,
	[NonUSCatWEP] [numeric](38, 4) NULL,
	[NonUSNonCatWEP] [numeric](38, 4) NULL,
	[WEPIncludingReinstatementPremium]  AS (isnull([WrittenOrEstimatedPremium],(0))+isnull([ReinstatementPremium],(0))),
	PartitionID INT NULL,
	[FK_ServiceCompany] [bigint] NOT NULL,
	[WrittenOrEstimatedPremiumExcLBS] [numeric](38, 4) NULL,
	[WrittenOrEstimatedPremiumExcLBSfeeDeduction] AS (CONVERT([numeric](38,4),isnull([WrittenOrEstimatedPremiumExcLBS],(0)) + isnull([ReinstatementPremium],(0)))), 
	--[WEPExcludingReinstatementPremiumAndLBSFee] AS (CONVERT([numeric](20,4),isnull([WrittenOrEstimatedPremiumExcLBS],(0)) - isnull([ReinstatementPremium],(0))))
	[WEPExcludingReinstatementPremiumAndLBSFee] AS (CONVERT([numeric](38,4),isnull([WrittenOrEstimatedPremiumExcLBS],(0))))

)


  
INSERT INTO staging.FactWrittenEstimatedPremium WITH(TABLOCK)

 (
    FK_Section
    ,FK_EntityPerspective
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_AcquisitionCostBasis
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
	,FK_LocalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,FK_RenewalDueDate
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,OriginalEPI
    ,MinimumPremium
    ,DepositPremium
    ,RateOnLinePremiumEntered
    ,AdjustmentBaseAmount
    ,AdjustmentPremium
    ,CashPosition
    ,WrittenOrEstimatedPremium
	,WrittenOrEstimatedPremiumExcLBS 
	,LatestEPI
	,Premium
	,OriginalGrossPremium
    ,DeclarationWEP
    ,ReinstatementPremium
    ,PremiumIncomeLimit
    ,BenchmarkBaseWEP
    ,BenchmarkPremium
    ,ProfitCommissionNotionalWEP
    ,ProfitCommissionBaseWEP
    ,ExpectedLoss
	,RatingAdequacyWEP
	,RatingAdequacyBaseWEP
    ,RateChangeBaseWEP
    ,RateChangeWEP
    ,RateChangeBaseDeclarationWEP
    ,RateChangeDeclarationWEP
    ,RateChangeQuestionnaireWEP
    ,RateChangeOtherWEP
    ,RateChangeTermsAndConditionsWEP
    ,RateChangeLimitWEP
    ,RateChangeDeductibleWEP
    ,RateChangeRiskWEP
    ,RateChangeExposureWEP
    ,BeazleyLedWEP
    ,RenewedWEP
    ,ExpectedPICCAmount
    ,USQuakeWEP
    ,USWindWEP
    ,USNonCatWEP
    ,NonUSCatWEP
    ,NonUSNonCatWEP   
	,PartitionID
)

--Premium amounts in original currency
SELECT
 FK_Section                                     = spoc.FK_Section
,FK_EntityPerspective                           = spoc.FK_EntityPerspective
,FK_Syndicate                                   = spoc.FK_Syndicate
,FK_ShareType                                   = spoc.FK_ShareType
,FK_AcquisitionCostBasis                        = spoc.FK_AcquisitionCostBasis
,FK_ReportingCurrencyOverride                   = rco.PK_ReportingCurrencyOverride
,FK_Date                                        = spoc.FK_Date
,FK_YOA                                         = spoc.FK_YOA
,FK_SettlementCurrency                          = spoc.FK_SettlementCurrency
,FK_OriginalCurrency                            = spoc.FK_OriginalCurrency
,FK_LocalCurrency								= spoc.FK_LocalCurrency
,FK_TriFocus                                    = spoc.FK_TriFocus
,FK_CRMBroker                                   = spoc.FK_CRMBroker
,FK_Policy                                      = spoc.FK_Policy
,FK_QuoteFilter                                 = spoc.FK_QuoteFilter
,FK_HiddenStatusFilter                          = spoc.FK_HiddenStatusFilter
,FK_RenewalDueDate                              = spoc.FK_RenewalDueDate
,FK_UnderwritingPlatform						= spoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus					= spoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany								= spoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies                 = spoc.SpecialPurposeSyndicateApplies
,OriginalEPI                                    = spoc.OriginalEPI
,MinimumPremium                                 = spoc.MinimumPremium
,DepositPremium                                 = spoc.DepositPremium
,RateOnLinePremiumEntered                       = spoc.RateOnLinePremiumEntered
,AdjustmentBaseAmount                           = spoc.AdjustmentBaseAmount
,AdjustmentPremium                              = spoc.AdjustmentPremium
,CashPosition                                   = spoc.CashPosition
,WrittenOrEstimatedPremium                      = spoc.WrittenOrEstimatedPremium
,WrittenOrEstimatedPremiumExcLBS				= spoc.WrittenOrEstimatedPremiumExcLBS 
,LatestEPI					                    = spoc.LatestEPI
,Premium										= spoc.Premium
,OriginalGrossPremium							= spoc.OriginalGrossPremium
,DeclarationWEP                                 = spoc.DeclarationWEP
,ReinstatementPremium                           = spoc.ReinstatementPremium
,PremiumIncomeLimit                             = spoc.PremiumIncomeLimit
,BenchmarkBaseWEP                               = spoc.BenchmarkBaseWEP
,BenchmarkPremium                               = spoc.BenchmarkPremium
,ProfitCommissionNotionalWEP                    = spoc.ProfitCommissionNotionalWEP
,ProfitCommissionBaseWEP                        = spoc.ProfitCommissionBaseWEP
,ExpectedLoss                                   = spoc.ExpectedLoss
,RatingAdequacyWEP								= spoc.RatingAdequacyWEP
,RatingAdequacyBaseWEP							= spoc.RatingAdequacyBaseWEP
,RateChangeBaseWEP                              = spoc.RateChangeBaseWEP
,RateChangeWEP                                  = spoc.RateChangeWEP
,RateChangeBaseDeclarationWEP                   = spoc.RateChangeBaseDeclarationWEP
,RateChangeDeclarationWEP                       = spoc.RateChangeDeclarationWEP
,RateChangeQuestionnaireWEP                     = spoc.RateChangeQuestionnaireWEP
,RateChangeOtherWEP                             = spoc.RateChangeOtherWEP
,RateChangeTermsAndConditionsWEP                = spoc.RateChangeTermsAndConditionsWEP
,RateChangeLimitWEP                             = spoc.RateChangeLimitWEP
,RateChangeDeductibleWEP                        = spoc.RateChangeDeductibleWEP
,RateChangeRiskWEP                              = spoc.RateChangeRiskWEP
,RateChangeExposureWEP                          = spoc.RateChangeExposureWEP
,BeazleyLedWEP                                  = spoc.BeazleyLedWEP
,RenewedWEP                                     = spoc.RenewedWEP
,ExpectedPICCAmount                             = spoc.ExpectedPICCAmount
,USQuakeWEP                                     = spoc.USQuakeWEP
,USWindWEP                                      = spoc.USWindWEP
,USNonCatWEP                                    = spoc.USNonCatWEP
,NonUSCatWEP                                    = spoc.NonUSCatWEP
,NonUSNonCatWEP                                 = spoc.NonUSNonCatWEP
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
FROM 
#SectionPremiumOriginalCurrency spoc
CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Original Currency'

--Premium amounts in settlement currency
UNION ALL

SELECT
 FK_Section                         = spoc.FK_Section    
,FK_EntityPerspective               = spoc.FK_EntityPerspective                                                                  
,FK_Syndicate                       = spoc.FK_Syndicate                                                            
,FK_ShareType                       = spoc.FK_ShareType                                                            
,FK_AcquisitionCostBasis            = spoc.FK_AcquisitionCostBasis                                                 
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride                                            
,FK_Date                            = spoc.FK_Date
,FK_YOA                             = spoc.FK_YOA
,FK_SettlementCurrency              = spoc.FK_SettlementCurrency
,FK_OriginalCurrency                = spoc.FK_OriginalCurrency
,FK_LocalCurrency					= spoc.FK_LocalCurrency
,FK_TriFocus                        = spoc.FK_TriFocus
,FK_CRMBroker                       = spoc.FK_CRMBroker
,FK_Policy                          = spoc.FK_Policy
,FK_QuoteFilter                     = spoc.FK_QuoteFilter
,FK_HiddenStatusFilter              = spoc.FK_HiddenStatusFilter
,FK_RenewalDueDate                  = spoc.FK_RenewalDueDate
,FK_UnderwritingPlatform			= spoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= spoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= spoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies     = spoc.SpecialPurposeSyndicateApplies
,OriginalEPI                        = spoc.OriginalEPI							/ s.OriginalCCYToSettlementCCYRate
,MinimumPremium                     = spoc.MinimumPremium						/ s.OriginalCCYToSettlementCCYRate
,DepositPremium                     = spoc.DepositPremium						/ s.OriginalCCYToSettlementCCYRate
,RateOnLinePremiumEntered           = spoc.RateOnLinePremiumEntered				/ s.OriginalCCYToSettlementCCYRate
,AdjustmentBaseAmount               = spoc.AdjustmentBaseAmount					/ s.OriginalCCYToSettlementCCYRate
,AdjustmentPremium                  = spoc.AdjustmentPremium					/ s.OriginalCCYToSettlementCCYRate
,CashPosition                       = spoc.CashPosition                         / s.OriginalCCYToSettlementCCYRate
,WrittenOrEstimatedPremium          = spoc.WrittenOrEstimatedPremium			/ s.OriginalCCYToSettlementCCYRate
,WrittenOrEstimatedPremiumExcLBS	= spoc.WrittenOrEstimatedPremiumExcLBS		/ s.OriginalCCYToSettlementCCYRate
,LatestEPI					        = spoc.LatestEPI							/ s.OriginalCCYToSettlementCCYRate
,Premium					        = spoc.Premium   							/ s.OriginalCCYToSettlementCCYRate
,OriginalGrossPremium				= spoc.OriginalGrossPremium					/ s.OriginalCCYToSettlementCCYRate
,DeclarationWEP                     = spoc.DeclarationWEP						/ s.OriginalCCYToSettlementCCYRate
,ReinstatementPremium               = spoc.ReinstatementPremium					/ s.OriginalCCYToSettlementCCYRate
,PremiumIncomeLimit                 = spoc.PremiumIncomeLimit					/ s.OriginalCCYToSettlementCCYRate
,BenchmarkBaseWEP                   = spoc.BenchmarkBaseWEP						/ s.OriginalCCYToSettlementCCYRate
,BenchmarkPremium                   = spoc.BenchmarkPremium						/ s.OriginalCCYToSettlementCCYRate
,ProfitCommissionNotionalWEP        = spoc.ProfitCommissionNotionalWEP			/ s.OriginalCCYToSettlementCCYRate
,ProfitCommissionBaseWEP            = spoc.ProfitCommissionBaseWEP				/ s.OriginalCCYToSettlementCCYRate
,ExpectedLoss                       = spoc.ExpectedLoss							/ s.OriginalCCYToSettlementCCYRate
,RatingAdequacyWEP					= spoc.RatingAdequacyWEP					/ s.OriginalCCYToSettlementCCYRate
,RatingAdequacyBaseWEP				= spoc.RatingAdequacyBaseWEP				/ s.OriginalCCYToSettlementCCYRate
,RateChangeBaseWEP                  = spoc.RateChangeBaseWEP					/ s.OriginalCCYToSettlementCCYRate
,RateChangeWEP                      = spoc.RateChangeWEP						/ s.OriginalCCYToSettlementCCYRate
,RateChangeBaseDeclarationWEP       = spoc.RateChangeBaseDeclarationWEP			/ s.OriginalCCYToSettlementCCYRate
,RateChangeDeclarationWEP           = spoc.RateChangeDeclarationWEP				/ s.OriginalCCYToSettlementCCYRate
,RateChangeQuestionnaireWEP         = spoc.RateChangeQuestionnaireWEP			/ s.OriginalCCYToSettlementCCYRate
,RateChangeOtherWEP                 = spoc.RateChangeOtherWEP					/ s.OriginalCCYToSettlementCCYRate
,RateChangeTermsAndConditionsWEP    = spoc.RateChangeTermsAndConditionsWEP		/ s.OriginalCCYToSettlementCCYRate
,RateChangeLimitWEP                 = spoc.RateChangeLimitWEP					/ s.OriginalCCYToSettlementCCYRate
,RateChangeDeductibleWEP            = spoc.RateChangeDeductibleWEP				/ s.OriginalCCYToSettlementCCYRate
,RateChangeRiskWEP                  = spoc.RateChangeRiskWEP					/ s.OriginalCCYToSettlementCCYRate
,RateChangeExposureWEP              = spoc.RateChangeExposureWEP				/ s.OriginalCCYToSettlementCCYRate
,BeazleyLedWEP                      = spoc.BeazleyLedWEP						/ s.OriginalCCYToSettlementCCYRate
,RenewedWEP                         = spoc.RenewedWEP							/ s.OriginalCCYToSettlementCCYRate
,ExpectedPICCAmount                 = spoc.ExpectedPICCAmount					/ s.OriginalCCYToSettlementCCYRate
,USQuakeWEP                         = spoc.USQuakeWEP							/ s.OriginalCCYToSettlementCCYRate
,USWindWEP                          = spoc.USWindWEP							/ s.OriginalCCYToSettlementCCYRate
,USNonCatWEP                        = spoc.USNonCatWEP							/ s.OriginalCCYToSettlementCCYRate
,NonUSCatWEP                        = spoc.NonUSCatWEP							/ s.OriginalCCYToSettlementCCYRate
,NonUSNonCatWEP                     = spoc.NonUSNonCatWEP						/ s.OriginalCCYToSettlementCCYRate
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
FROM #SectionPremiumOriginalCurrency spoc

INNER JOIN ODS.Section s 
ON spoc.FK_Section = s.PK_Section

CROSS JOIN Red.ReportingCurrencyOverride rco 

WHERE rco.ReportingCurrencyOverrideName = 'Settlement Currency'

/*** SGP Enabled - Start ***/
UNION ALL
-- LOCAL CURRENCY
SELECT
 FK_Section                         = spoc.FK_Section    
,FK_EntityPerspective               = spoc.FK_EntityPerspective                                                                  
,FK_Syndicate                       = spoc.FK_Syndicate                                                            
,FK_ShareType                       = spoc.FK_ShareType                                                            
,FK_AcquisitionCostBasis            = spoc.FK_AcquisitionCostBasis                                                 
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride                                            
,FK_Date                            = spoc.FK_Date
,FK_YOA                             = spoc.FK_YOA
,FK_SettlementCurrency              = spoc.FK_SettlementCurrency
,FK_OriginalCurrency                = spoc.FK_OriginalCurrency
,FK_LocalCurrency					= spoc.FK_LocalCurrency
,FK_TriFocus                        = spoc.FK_TriFocus
,FK_CRMBroker                       = spoc.FK_CRMBroker
,FK_Policy                          = spoc.FK_Policy
,FK_QuoteFilter                     = spoc.FK_QuoteFilter
,FK_HiddenStatusFilter              = spoc.FK_HiddenStatusFilter
,FK_RenewalDueDate                  = spoc.FK_RenewalDueDate
,FK_UnderwritingPlatform			= spoc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= spoc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= spoc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies     = spoc.SpecialPurposeSyndicateApplies
,OriginalEPI                        = spoc.OriginalEPI							* s.OriginalCCYToLocalCCYRate
,MinimumPremium                     = spoc.MinimumPremium						* s.OriginalCCYToLocalCCYRate
,DepositPremium                     = spoc.DepositPremium						* s.OriginalCCYToLocalCCYRate
,RateOnLinePremiumEntered           = spoc.RateOnLinePremiumEntered				* s.OriginalCCYToLocalCCYRate
,AdjustmentBaseAmount               = spoc.AdjustmentBaseAmount					* s.OriginalCCYToLocalCCYRate
,AdjustmentPremium                  = spoc.AdjustmentPremium					* s.OriginalCCYToLocalCCYRate
,CashPosition                       = spoc.CashPosition                         * s.OriginalCCYToLocalCCYRate
,WrittenOrEstimatedPremium          = spoc.WrittenOrEstimatedPremium			* s.OriginalCCYToLocalCCYRate
,WrittenOrEstimatedPremiumExcLBS	= spoc.WrittenOrEstimatedPremiumExcLBS		* s.OriginalCCYToLocalCCYRate
,LatestEPI					        = spoc.LatestEPI							* s.OriginalCCYToLocalCCYRate
,Premium					        = spoc.Premium   							* s.OriginalCCYToLocalCCYRate
,OriginalGrossPremium				= spoc.OriginalGrossPremium					* s.OriginalCCYToLocalCCYRate
,DeclarationWEP                     = spoc.DeclarationWEP						* s.OriginalCCYToLocalCCYRate
,ReinstatementPremium               = spoc.ReinstatementPremium					* s.OriginalCCYToLocalCCYRate
,PremiumIncomeLimit                 = spoc.PremiumIncomeLimit					* s.OriginalCCYToLocalCCYRate
,BenchmarkBaseWEP                   = spoc.BenchmarkBaseWEP						* s.OriginalCCYToLocalCCYRate
,BenchmarkPremium                   = spoc.BenchmarkPremium						* s.OriginalCCYToLocalCCYRate
,ProfitCommissionNotionalWEP        = spoc.ProfitCommissionNotionalWEP			* s.OriginalCCYToLocalCCYRate
,ProfitCommissionBaseWEP            = spoc.ProfitCommissionBaseWEP				* s.OriginalCCYToLocalCCYRate
,ExpectedLoss                       = spoc.ExpectedLoss							* s.OriginalCCYToLocalCCYRate
,RatingAdequacyWEP					= spoc.RatingAdequacyWEP					* s.OriginalCCYToLocalCCYRate
,RatingAdequacyBaseWEP				= spoc.RatingAdequacyBaseWEP				* s.OriginalCCYToLocalCCYRate
,RateChangeBaseWEP                  = spoc.RateChangeBaseWEP					* s.OriginalCCYToLocalCCYRate
,RateChangeWEP                      = spoc.RateChangeWEP						* s.OriginalCCYToLocalCCYRate
,RateChangeBaseDeclarationWEP       = spoc.RateChangeBaseDeclarationWEP			* s.OriginalCCYToLocalCCYRate
,RateChangeDeclarationWEP           = spoc.RateChangeDeclarationWEP				* s.OriginalCCYToLocalCCYRate
,RateChangeQuestionnaireWEP         = spoc.RateChangeQuestionnaireWEP			* s.OriginalCCYToLocalCCYRate
,RateChangeOtherWEP                 = spoc.RateChangeOtherWEP					* s.OriginalCCYToLocalCCYRate
,RateChangeTermsAndConditionsWEP    = spoc.RateChangeTermsAndConditionsWEP		* s.OriginalCCYToLocalCCYRate
,RateChangeLimitWEP                 = spoc.RateChangeLimitWEP					* s.OriginalCCYToLocalCCYRate
,RateChangeDeductibleWEP            = spoc.RateChangeDeductibleWEP				* s.OriginalCCYToLocalCCYRate
,RateChangeRiskWEP                  = spoc.RateChangeRiskWEP					* s.OriginalCCYToLocalCCYRate
,RateChangeExposureWEP              = spoc.RateChangeExposureWEP				* s.OriginalCCYToLocalCCYRate
,BeazleyLedWEP                      = spoc.BeazleyLedWEP						* s.OriginalCCYToLocalCCYRate
,RenewedWEP                         = spoc.RenewedWEP							* s.OriginalCCYToLocalCCYRate
,ExpectedPICCAmount                 = spoc.ExpectedPICCAmount					* s.OriginalCCYToLocalCCYRate
,USQuakeWEP                         = spoc.USQuakeWEP							* s.OriginalCCYToLocalCCYRate
,USWindWEP                          = spoc.USWindWEP							* s.OriginalCCYToLocalCCYRate
,USNonCatWEP                        = spoc.USNonCatWEP							* s.OriginalCCYToLocalCCYRate
,NonUSCatWEP                        = spoc.NonUSCatWEP							* s.OriginalCCYToLocalCCYRate
,NonUSNonCatWEP                     = spoc.NonUSNonCatWEP						* s.OriginalCCYToLocalCCYRate
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
FROM 
#SectionPremiumOriginalCurrency spoc

INNER JOIN ODS.Section s
 ON spoc.FK_Section = s.PK_Section

INNER JOIN ODS.Policy p  
ON s.FK_Policy = p.PK_Policy

CROSS JOIN 
Red.ReportingCurrencyOverride rco 
WHERE 
rco.ReportingCurrencyOverrideName = 'Local Currency'
AND p.sourcesystem = 'Unirisx'
AND s.BeazleyOfficeLocation = 'Singapore'
/*** SGP Enabled - End ***/

IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		   WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactWrittenEstimatedPremium' AND name = 'IK_FactWrittenEstimatedPremium')
BEGIN
	DROP INDEX IK_FactWrittenEstimatedPremium ON Red.FactWrittenEstimatedPremium
END


---/// DROP INDEX & DISABLE CONSTRAINTS
ALTER TABLE Red.FactWrittenEstimatedPremium NOCHECK CONSTRAINT ALL;

IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		    WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactWrittenEstimatedPremium' AND name = 'FactWrittenEstimatedPremium_Combined')
BEGIN
	DROP INDEX FactWrittenEstimatedPremium_Combined ON Red.FactWrittenEstimatedPremium
END
---/////////

-- ADD CHECK CONSTRAINT TO PARTITIONID.
ALTER TABLE staging.FactWrittenEstimatedPremium ADD CONSTRAINT CHK_Staging_FactWrittenEstimatedPremium_p CHECK (PartitionId=1 AND PartitionId IS NOT NULL)
   
-- SWITCH PARTITION
ALTER TABLE staging.FactWrittenEstimatedPremium SWITCH TO Red.FactWrittenEstimatedPremium Partition 1
		
-- DROP STAGING TABLE
DROP TABLE staging.FactWrittenEstimatedPremium 

---/// CREATE INDEX  & ENABLE CONSTRAINTS 
--IF NOT EXISTS
-- (
--    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
--    WHERE 
--    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactWrittenEstimatedPremium' AND CONSTRAINT_NAME = 'UQ_FactWrittenEstimatedPremium_LogicalKey' 
-- )
--BEGIN 
--  ALTER TABLE Red.FactWrittenEstimatedPremium
--  ADD CONSTRAINT UQ_FactWrittenEstimatedPremium_LogicalKey
--  UNIQUE
--        (
--            FK_Section
--            ,FK_Syndicate
--            ,FK_ShareType
--            ,FK_AcquisitionCostBasis
--            ,FK_ReportingCurrencyOverride
--            ,FK_EntityPerspective
--        )
--END
    
---/////////

-- Drop tmp tables
IF (OBJECT_ID('tempdb..#SectionAcquisitionCostBasis') IS NOT NULL) DROP TABLE #SectionAcquisitionCostBasis
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType
IF (OBJECT_ID('tempdb..#SectionPremiumCalculations') IS NOT NULL) DROP TABLE #SectionPremiumCalculations
IF (OBJECT_ID('tempdb..#SectionPremiumOriginalCurrency') IS NOT NULL) DROP TABLE #SectionPremiumOriginalCurrency
IF (OBJECT_ID('tempdb..#SectionExposureOriginalCurrency') IS NOT NULL) DROP TABLE #SectionExposureOriginalCurrency
IF (OBJECT_ID('tempdb..#SectionCurrencyRate') IS NOT NULL) DROP TABLE #SectionCurrencyRate
IF (OBJECT_ID('tempdb..#PICCTransactionOriginalCurrency') IS NOT NULL) DROP TABLE #PICCTransactionOriginalCurrency;
