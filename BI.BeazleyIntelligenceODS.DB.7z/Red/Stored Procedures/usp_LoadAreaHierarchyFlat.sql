﻿

CREATE PROCEDURE [Red].[usp_LoadAreaHierarchyFlat]
AS

SET NOCOUNT ON
 

	DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
	FROM		Red.AreaHierarchyFlat

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


/*
    DELETE      ahf
    FROM        Red.AreaHierarchyFlat ahf
    LEFT JOIN   ODS.Area a
            ON  ahf.Level1Key = a.PK_Area
    WHERE       a.PK_Area IS NULL

    DELETE      ahf
    FROM        Red.AreaHierarchyFlat ahf
    LEFT JOIN   ODS.Area a
            ON  ahf.Level2Key = a.PK_Area
    WHERE       a.PK_Area IS NULL

    DELETE      ahf
    FROM        Red.AreaHierarchyFlat ahf
    LEFT JOIN   ODS.Area a
            ON  ahf.Level3Key = a.PK_Area
    WHERE       a.PK_Area IS NULL
    */

    IF OBJECT_ID('tempdb..#AreaHierarchyFlat') IS NOT NULL
    DROP TABLE #AreaHierarchyFlat

    CREATE TABLE #AreaHierarchyFlat
			    (
			    [Level1Key]         BIGINT           NOT NULL,
                [Level1Code]        VARCHAR (255)    NOT NULL,
                [Level1Name]        VARCHAR (255)    NOT NULL,
                [Level2Key]         BIGINT           NOT NULL,
                [Level2Code]        VARCHAR (255)    NOT NULL,
                [Level2Name]        VARCHAR (255)    NOT NULL,
                [Level3Key]         BIGINT           NOT NULL,
                [Level3Code]        VARCHAR (255)    NOT NULL,
                [Level3Name]        VARCHAR (255)    NOT NULL
			    )


    INSERT INTO #AreaHierarchyFlat
             (
                Level1Key
               ,Level1Code
               ,Level1Name
               ,Level2Key
               ,Level2Code
               ,Level2Name
               ,Level3Key
               ,Level3Code
               ,Level3Name
             )

    SELECT
                 Level1Key          = a.PK_Area
                ,Level1Code         = a.AreaCode  
                ,Level1Name         = a.Area     
    
                ,Level2Key          = a.PK_Area
                ,Level2Code         = a.AreaCode  
                ,Level2Name         = a.Area  
    
                ,Level3Key          = a.PK_Area
                ,Level3Code         = a.AreaCode  
                ,Level3Name         = a.Area                   

    FROM        ODS.Area a 

    WHERE       a.FK_ParentArea = a.PK_Area
          --  AND (a.AuditModifyDateTime > @LastAuditDate OR a.AuditCreateDateTime > @LastAuditDate)
    


    INSERT INTO #AreaHierarchyFlat
             (
                Level1Key
               ,Level1Code
               ,Level1Name
               ,Level2Key
               ,Level2Code
               ,Level2Name
               ,Level3Key
               ,Level3Code
               ,Level3Name
             )

    SELECT
                 Level1Key          = ahf.Level1Key              
                ,Level1Code         = ahf.Level1Code            
                ,Level1Name         = ahf.Level1Name
    
                ,Level2Key          = a.PK_Area           
                ,Level2Code         = a.AreaCode           
                ,Level2Name         = a.Area
    
                ,Level3Key          = a.PK_Area           
                ,Level3Code         = a.AreaCode           
                ,Level3Name         = a.Area
       
    FROM        ODS.Area a

    INNER JOIN  #AreaHierarchyFlat ahf
            ON  a.FK_ParentArea = ahf.Level1Key
            AND a.FK_ParentArea <> a.PK_Area
			--AND ahf.Level1Key <> 0

    --WHERE       a.AuditModifyDateTime > @LastAuditDate OR a.AuditCreateDateTime > @LastAuditDate   
    


    INSERT INTO #AreaHierarchyFlat
             (
                Level1Key
               ,Level1Code
               ,Level1Name
               ,Level2Key
               ,Level2Code
               ,Level2Name
               ,Level3Key
               ,Level3Code
               ,Level3Name
             )

    SELECT
                 Level1Key          = ahf.Level1Key         
                ,Level1Code         = ahf.Level1Code       
                ,Level1Name         = ahf.Level1Name 
         
                ,Level2Key          = ahf.Level2Key         
                ,Level2Code         = ahf.Level2Code       
                ,Level2Name         = ahf.Level2Name  
          
                ,Level3Key          = a.PK_Area                 
                ,Level3Code         = a.AreaCode               
                ,Level3Name         = a.Area                     

    FROM        ODS.Area a

    INNER JOIN  #AreaHierarchyFlat ahf
            ON  a.FK_ParentArea = ahf.Level2Key
            AND ahf.Level2Key <> ahf.Level1Key
			--AND ahf.Level2Key <> 0

    --WHERE       a.AuditModifyDateTime > @LastAuditDate OR a.AuditCreateDateTime > @LastAuditDate   


    ;MERGE	Red.AreaHierarchyFlat		AS TARGET
		    USING	#AreaHierarchyFlat	AS SOURCE
		    ON		TARGET.Level1Code   = SOURCE.Level1Code
                AND TARGET.Level2Code   = SOURCE.Level2Code
                AND TARGET.Level3Code   = SOURCE.Level3Code

    WHEN	MATCHED THEN
		    UPDATE	
		    SET	TARGET.Level1Key			        = SOURCE.Level1Key
                ,TARGET.Level1Name			        = SOURCE.Level1Name
                ,TARGET.Level2Key			        = SOURCE.Level2Key
                ,TARGET.Level2Name			        = SOURCE.Level2Name
                ,TARGET.Level3Key			        = SOURCE.Level3Key
                ,TARGET.Level3Name			        = SOURCE.Level3Name
			    ,TARGET.AuditModifyDateTime	        = GETDATE()						
			    ,TARGET.AuditModifyDetails	        = 'Merge in Red.AreaHierarchyFlat' 

    WHEN	NOT MATCHED BY TARGET THEN
		    INSERT
		    (
		        Level1Key
               ,Level1Code
               ,Level1Name
               ,Level2Key
               ,Level2Code
               ,Level2Name
               ,Level3Key
               ,Level3Code
               ,Level3Name
               ,AuditCreateDateTime
               ,AuditModifyDetails
		    )
			    VALUES
		    (
			    SOURCE.Level1Key
		        ,SOURCE.Level1Code
                ,SOURCE.Level1Name
                ,SOURCE.Level2Key
                ,SOURCE.Level2Code
                ,SOURCE.Level2Name
                ,SOURCE.Level3Key
                ,SOURCE.Level3Code
               ,SOURCE.Level3Name
			    ,GETDATE()
			    ,'New add in Red.AreaHierarchyFlat'	
		    )
	WHEN	NOT MATCHED BY SOURCE THEN DELETE
    ;

    EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'AreaHierarchyFlat';


