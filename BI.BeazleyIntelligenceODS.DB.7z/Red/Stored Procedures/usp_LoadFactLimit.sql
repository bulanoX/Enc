﻿CREATE PROCEDURE [Red].[usp_LoadFactLimit]
AS

DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
FROM		Red.FactLimit

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');

/***************************************************************************************/
/*                        Share type                                                   */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType

CREATE TABLE #SectionShareType
(
     FK_Section                      bigint              NOT NULL
    ,FK_ShareType                   bigint              NOT NULL
    ,FK_Syndicate                   bigint              NULL
)

TRUNCATE TABLE #SectionShareType

INSERT INTO #SectionShareType
(
     FK_Section
    ,FK_ShareType
    ,FK_Syndicate
)

SELECT
 FK_Section             = s.PK_Section     
,FK_ShareType           = st.PK_ShareType
,FK_Syndicate           = NULL                                      

FROM ODS.Section s

CROSS JOIN Red.ShareType st

WHERE st.ShareTypeName IN ('Total Order','Slip Order')

UNION ALL

SELECT
 FK_Section             = sl.FK_Section                       
,FK_ShareType          = st.PK_ShareType                 
,FK_Syndicate          = sl.FK_Syndicate 

FROM ODS.SectionLine sl

CROSS JOIN Red.ShareType st

WHERE st.ShareTypeName = 'Beazley Share'


/***************************************************************************************/
/*          Section limit fact currency												   */
/***************************************************************************************/
IF (OBJECT_ID('tempdb..#SectionLimitCurrency') IS NOT NULL) DROP TABLE #SectionLimitCurrency

CREATE TABLE #SectionLimitCurrency
(
     FK_Section							bigint              NOT NULL
	,FK_Syndicate						bigint              NULL
	,FK_ShareType						bigint              NOT NULL
	,FK_Date							datetime            NOT NULL
	,FK_YOA								bigint              NOT NULL
	,FK_SettlementCurrency				bigint              NOT NULL
	,FK_OriginalCurrency				bigint              NOT NULL
	,FK_LimitCurrency					bigint              NOT NULL
	,FK_TriFocus						bigint              NOT NULL
	,FK_CRMBroker						bigint              NOT NULL
	,FK_Policy							bigint              NOT NULL
	,FK_QuoteFilter						bigint              NOT NULL
	,FK_HiddenStatusFilter				bigint              NOT NULL
	,FK_Sublimit						bigint				NOT NULL
	,FK_SublimitType					bigint				NOT NULL
	,FK_UnderwritingPlatform			bigint				NOT NULL
	,FK_InternalWrittenBinderStatus		bigint				NOT NULL
	,FK_ServiceCompany					bigint				NOT NULL
	,SpecialPurposeSyndicateApplies		bit                 NOT NULL
	,Limit								numeric(38,4)       NULL
	,Subexposure						numeric(38,4)       NULL
)

TRUNCATE TABLE #SectionLimitCurrency

INSERT INTO #SectionLimitCurrency
 (
     FK_Section
	,FK_Syndicate
	,FK_ShareType
	,FK_Date
	,FK_YOA
	,FK_SettlementCurrency
	,FK_OriginalCurrency
	,FK_LimitCurrency
	,FK_TriFocus
	,FK_CRMBroker
	,FK_Policy
	,FK_QuoteFilter
	,FK_HiddenStatusFilter
	,FK_Sublimit
	,FK_SublimitType
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
	,SpecialPurposeSyndicateApplies
	,Limit
	,Subexposure
 )

-- Generic calcs
SELECT
 FK_Section						= s.PK_Section
,FK_Syndicate					= sst.FK_Syndicate
,FK_ShareType					= st.PK_ShareType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_LimitCurrency				= sl.FK_LimitCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Sublimit					= sl.FK_Sublimit
,FK_SublimitType				= sl.FK_SublimitType
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Limit							= CASE -- Limit is always at total order
									WHEN st.ShareTypeName = 'Beazley Share'
									THEN NULL
									ELSE sl.LimitAmountInLimitCCY
								  END
,Subexposure					= CASE -- Limit is always at total order
									WHEN st.ShareTypeName = 'Beazley Share'
									THEN NULL
									ELSE subex.Subexposure
								  END

FROM ODS.Section s WITH(NOLOCK)

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionLimit sl 
ON s.PK_Section = sl.FK_Section

INNER JOIN #SectionShareType sst 
ON s.PK_Section = sst.FK_Section

INNER JOIN Red.ShareType st WITH(NOLOCK) 
ON sst.FK_ShareType = st.PK_ShareType

LEFT OUTER JOIN (
SELECT  
	sl.fk_section
   ,sl.fk_sublimit
   ,sl.FK_LimitCurrency 
   ,sl.FK_SublimitType
   ,Subexposure = SUM (sl.LimitAmountinlimitccy *
                      (sll.WrittenIfNotSignedLineMultiplier 
                        * sec.WrittenIfNotSignedOrderMultiplier 
                        * CASE 
                            WHEN sec.IsSigned = 0 
                            THEN sec.EstimatedSigningMultiplier 
                            ELSE 1
                          END
                                           )
                                           )
FROM ods.sectionlimit sl

INNER JOIN ods.sectionline sll 
ON sl.fk_section=sll.fk_section

INNER JOIN ods.section sec
ON sl.FK_Section=sec.pk_section

group by sl.fk_section, sl.fk_sublimit, sl.FK_LimitCurrency, sl.FK_SublimitType
) subex

ON  subex.FK_Section=s.PK_Section
AND subex.FK_Sublimit=sl.FK_Sublimit
AND subex.FK_LimitCurrency=sl.FK_LimitCurrency
AND subex.FK_SublimitType=sl.FK_SublimitType
 WHERE (p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
     OR (s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
	 OR (sl.AuditModifyDateTime	 > @LastAuditDate OR sl.AuditCreateDateTime	 > @LastAuditDate)

UNION ALL

--Beazley share rows for limit (use total order value & NULL syndicate key)
SELECT
 FK_Section						= s.PK_Section
,FK_Syndicate					= NULL
,FK_ShareType					= st.PK_ShareType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_LimitCurrency				= sl.FK_LimitCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_Policy                      = s.FK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Sublimit					= sl.FK_Sublimit
,FK_SublimitType				= sl.FK_SublimitType
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,Limit							= sl.LimitAmountInLimitCCY --Limit is always at total order
,Subexposure					= subex.Subexposure

FROM ODS.Section s WITH(NOLOCK)

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionLimit sl 
ON s.PK_Section = sl.FK_Section

INNER JOIN Red.ShareType st WITH(NOLOCK) 
ON st.ShareTypeName = 'Beazley Share'

LEFT OUTER JOIN (
SELECT  
	sl.fk_section
   ,sl.fk_sublimit
   ,sl.FK_LimitCurrency 
   ,sl.FK_SublimitType
   ,Subexposure = SUM (sl.LimitAmountinlimitccy *
                      (sll.WrittenIfNotSignedLineMultiplier 
                        * sec.WrittenIfNotSignedOrderMultiplier 
                        * CASE 
                            WHEN sec.IsSigned = 0 
                            THEN sec.EstimatedSigningMultiplier 
                            ELSE 1
                          END
                                           )
                                           )
FROM ods.sectionlimit sl

INNER JOIN ods.sectionline sll 
ON sl.fk_section=sll.fk_section

INNER JOIN ods.section sec
ON sl.FK_Section=sec.pk_section

group by sl.fk_section, sl.fk_sublimit, sl.FK_LimitCurrency, sl.FK_SublimitType
) subex

ON  subex.FK_Section=s.PK_Section
AND subex.FK_Sublimit=sl.FK_Sublimit
AND subex.FK_LimitCurrency=sl.FK_LimitCurrency
AND subex.FK_SublimitType=sl.FK_SublimitType
WHERE (p.AuditModifyDateTime	 > @LastAuditDate OR p.AuditCreateDateTime	 > @LastAuditDate)
     OR (s.AuditModifyDateTime	 > @LastAuditDate OR s.AuditCreateDateTime	 > @LastAuditDate)
	 OR (sl.AuditModifyDateTime	 > @LastAuditDate OR sl.AuditCreateDateTime	 > @LastAuditDate)

/***************************************************************************************/
/*                           Load fact limit                                           */
/***************************************************************************************/

ALTER TABLE Red.FactLimit NOCHECK CONSTRAINT ALL


--TRUNCATE TABLE Red.FactLimit

IF EXISTS
 (
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE 
    TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactLimit' AND CONSTRAINT_NAME = 'UQ_FactLimit_LogicalKey' 
 )
BEGIN
    ALTER TABLE Red.FactLimit
    DROP CONSTRAINT UQ_FactLimit_LogicalKey
END

DELETE FROM RED.FactLimit WHERE FK_Section not in (select PK_Section from ODS.Section)
DELETE FROM RED.FactLimit WHERE FK_Policy not in (select PK_Policy from ODS.Policy)
DELETE FROM RED.FactLimit WHERE FK_UnderwritingPlatform NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform)
DELETE FROM RED.FactLimit WHERE FK_CRMBroker NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker)
DELETE FROM RED.FactLimit WHERE FK_Sublimit NOT IN (SELECT PK_Sublimit FROM ODS.Sublimit)
DELETE FROM RED.FactLimit WHERE FK_SublimitType NOT IN (SELECT PK_SublimitType FROM ODS.SublimitType)

MERGE Red.FactLimit as TARGET 

USING

(
SELECT
 FK_Section						= selc.FK_Section
,FK_Syndicate					= selc.FK_Syndicate
,FK_ShareType					= selc.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = selc.FK_Date
,FK_YOA                         = selc.FK_YOA
,FK_SettlementCurrency          = selc.FK_SettlementCurrency
,FK_OriginalCurrency            = selc.FK_OriginalCurrency
,FK_LimitCurrency				= selc.FK_LimitCurrency
,FK_TriFocus                    = selc.FK_TriFocus
,FK_CRMBroker                   = selc.FK_CRMBroker
,FK_Policy                      = selc.FK_Policy
,FK_QuoteFilter                 = selc.FK_QuoteFilter
,FK_HiddenStatusFilter          = selc.FK_HiddenStatusFilter
,FK_Sublimit					= selc.FK_Sublimit
,FK_SublimitType				= selc.FK_SublimitType
,FK_UnderwritingPlatform		= selc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= selc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= selc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = selc.SpecialPurposeSyndicateApplies
,Limit							= CASE 
									WHEN selc.FK_LimitCurrency = selc.FK_OriginalCurrency
									THEN selc.Limit 
									ELSE TRY_CAST((selc.Limit / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(38,4))
								  END
,Subexposure					= CASE 
									WHEN selc.FK_LimitCurrency = selc.FK_OriginalCurrency
									THEN selc.Subexposure 
									ELSE TRY_CAST((selc.Subexposure / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(38,4))
								  END

FROM #SectionLimitCurrency selc

INNER JOIN ODS.OriginalCurrency lccy 
ON selc.FK_LimitCurrency = lccy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crlim 
ON lccy.CurrencyCode = crlim.Currency AND crlim.RateType = 'Current'

INNER JOIN ODS.OriginalCurrency occy 
ON selc.FK_OriginalCurrency = occy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crsett 
ON occy.CurrencyCode = crsett.Currency AND crsett.RateType = 'Current'

CROSS JOIN Red.ReportingCurrencyOverride rco

WHERE rco.ReportingCurrencyOverrideName = 'Original Currency'

UNION ALL

--Limit amounts in settlement currency

SELECT
 FK_Section						= selc.FK_Section
,FK_Syndicate					= selc.FK_Syndicate
,FK_ShareType					= selc.FK_ShareType
,FK_ReportingCurrencyOverride	= rco.PK_ReportingCurrencyOverride
,FK_Date                        = selc.FK_Date
,FK_YOA                         = selc.FK_YOA
,FK_SettlementCurrency          = selc.FK_SettlementCurrency
,FK_OriginalCurrency            = selc.FK_OriginalCurrency
,FK_LimitCurrency				= selc.FK_LimitCurrency
,FK_TriFocus                    = selc.FK_TriFocus
,FK_CRMBroker                   = selc.FK_CRMBroker
,FK_Policy                      = selc.FK_Policy
,FK_QuoteFilter                 = selc.FK_QuoteFilter
,FK_HiddenStatusFilter          = selc.FK_HiddenStatusFilter
,FK_Sublimit					= selc.FK_Sublimit
,FK_SublimitType				= selc.FK_SublimitType
,FK_UnderwritingPlatform		= selc.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= selc.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= selc.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = selc.SpecialPurposeSyndicateApplies
,Limit							= CASE
									WHEN lccy.CurrencyCode = sccy.CurrencyCode
									THEN selc.Limit
									ELSE TRY_CAST((selc.Limit / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(38,4))
								  END
,Subexposure					= CASE
									WHEN lccy.CurrencyCode = sccy.CurrencyCode
									THEN selc.Subexposure
									ELSE TRY_CAST((selc.Subexposure / (crlim.ExchangeRate / crsett.ExchangeRate)) AS NUMERIC(38,4))
								  END

FROM #SectionLimitCurrency selc

INNER JOIN ODS.OriginalCurrency lccy 
ON selc.FK_LimitCurrency = lccy.PK_OriginalCurrency

LEFT OUTER JOIN Utility.CurrencyRate crlim 
ON lccy.CurrencyCode = crlim.Currency AND crlim.RateType = 'Current'

INNER JOIN ODS.SettlementCurrency sccy 
ON selc.FK_SettlementCurrency = sccy.PK_SettlementCurrency

LEFT OUTER JOIN Utility.CurrencyRate crsett 
ON sccy.CurrencyCode = crsett.Currency AND crsett.RateType = 'Current'

CROSS JOIN Red.ReportingCurrencyOverride rco

WHERE rco.ReportingCurrencyOverrideName = 'Settlement Currency'
) AS SOURCE

ON  TARGET.FK_Section                     = SOURCE.FK_Section
AND	ISNULL(TARGET.FK_Syndicate, 0)        = ISNULL(SOURCE.FK_Syndicate, 0)
AND TARGET.FK_ShareType                   = SOURCE.FK_ShareType
AND TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride
AND TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
AND TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
AND TARGET.FK_LimitCurrency               = SOURCE.FK_LimitCurrency
AND TARGET.FK_Sublimit                    = SOURCE.FK_Sublimit
AND TARGET.FK_SublimitType				  = SOURCE.FK_SublimitType


WHEN MATCHED THEN

UPDATE SET 
 TARGET.FK_Section                     = SOURCE.FK_Section
,TARGET.FK_Syndicate                   = SOURCE.FK_Syndicate
,TARGET.FK_ShareType                   = SOURCE.FK_ShareType
,TARGET.FK_ReportingCurrencyOverride   = SOURCE.FK_ReportingCurrencyOverride
,TARGET.FK_Date                        = SOURCE.FK_Date
,TARGET.FK_YOA                         = SOURCE.FK_YOA
,TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
,TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
,TARGET.FK_LimitCurrency               = SOURCE.FK_LimitCurrency
,TARGET.FK_TriFocus                    = SOURCE.FK_TriFocus
,TARGET.FK_CRMBroker                   = SOURCE.FK_CRMBroker
,TARGET.FK_Policy                      = SOURCE.FK_Policy
,TARGET.FK_QuoteFilter                 = SOURCE.FK_QuoteFilter
,TARGET.FK_HiddenStatusFilter          = SOURCE.FK_HiddenStatusFilter
,TARGET.FK_Sublimit                    = SOURCE.FK_Sublimit
,TARGET.FK_SublimitType                = SOURCE.FK_SublimitType
,TARGET.FK_UnderwritingPlatform        = SOURCE.FK_UnderwritingPlatform
,TARGET.FK_InternalWrittenBinderStatus = SOURCE.FK_InternalWrittenBinderStatus
,TARGET.FK_ServiceCompany              = SOURCE.FK_ServiceCompany
,TARGET.SpecialPurposeSyndicateApplies = SOURCE.SpecialPurposeSyndicateApplies
,TARGET.Limit                          = SOURCE.Limit
,TARGET.Subexposure	                   = SOURCE.Subexposure	 
,TARGET.AuditModifyDateTime            = GETDATE()
,TARGET.AuditModifyDetails             = 'Merge in [RED].[FactLimit] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
      FK_Section
	 ,FK_Syndicate
	 ,FK_ShareType
	 ,FK_ReportingCurrencyOverride
	 ,FK_Date
	 ,FK_YOA
	 ,FK_SettlementCurrency
	 ,FK_OriginalCurrency
	 ,FK_LimitCurrency
	 ,FK_TriFocus
	 ,FK_CRMBroker
	 ,FK_Policy
	 ,FK_QuoteFilter
	 ,FK_HiddenStatusFilter
	 ,FK_Sublimit
	 ,FK_SublimitType
	 ,FK_UnderwritingPlatform
	 ,FK_InternalWrittenBinderStatus
	 ,FK_ServiceCompany
	 ,SpecialPurposeSyndicateApplies
	 ,Limit
	 ,Subexposure                      
     ,AuditModifyDetails

)
VALUES
(
     FK_Section
	 ,FK_Syndicate
	 ,FK_ShareType
	 ,FK_ReportingCurrencyOverride
	 ,FK_Date
	 ,FK_YOA
	 ,FK_SettlementCurrency
	 ,FK_OriginalCurrency
	 ,FK_LimitCurrency
	 ,FK_TriFocus
	 ,FK_CRMBroker
	 ,FK_Policy
	 ,FK_QuoteFilter
	 ,FK_HiddenStatusFilter
	 ,FK_Sublimit
	 ,FK_SublimitType
	 ,FK_UnderwritingPlatform
	 ,FK_InternalWrittenBinderStatus
	 ,FK_ServiceCompany
	 ,SpecialPurposeSyndicateApplies
	 ,Limit
	 ,Subexposure                      
     ,'New in [RED].[FactLimit] table' 
);


/* Initialize ExcLBS columns with existing values */
UPDATE slc
SET  LimitExcLBS = Limit
	,SubexposureExcLBS = Subexposure
FROM Red.FactLimit slc

IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS

CREATE TABLE #ExcLBS
(
     FK_Section                     bigint              NOT NULL
	,FK_SectionExcLBS				bigint              NOT NULL
    ,Limit                          NUMERIC (38, 4) NULL
	,LimitExcLBS                    NUMERIC (38, 4) NULL
	,Subexposure                    NUMERIC (38, 4) NULL
	,SubexposureExcLBS              NUMERIC (38, 4) NULL
)

TRUNCATE TABLE #ExcLBS

INSERT INTO  #ExcLBS
	(
	 FK_Section
	,FK_SectionExcLBS
    ,Limit
	,LimitExcLBS
	,Subexposure 
	,SubexposureExcLBS
	)
SELECT
	 ss.PK_Section
	,sl.PK_Section
	,Limit = SUM(slcs.Limit)
	,LimitExcLBS = SUM(slcl.Limit)
	,Subexposure = SUM(slcs.Subexposure) 
	,SubexposureExcLBS =  SUM(slcl.Subexposure) 

FROM 
	Red.FactLimit slcs
	INNER JOIN ODS.Section ss ON slcs.FK_Section = ss.PK_Section
	INNER JOIN Red.FactLimit slcl 
	ON slcs.FK_Policy 		= slcl.FK_Policy
	INNER JOIN ODS.Section sl ON slcl.FK_Section = sl.PK_Section
	AND ss.FK_ClassOfBusiness = sl.FK_ClassOfBusiness
	INNER JOIN ODS.UnderwritingPlatform ups
	ON ups.PK_UnderwritingPlatform = slcs.FK_UnderwritingPlatform
	INNER JOIN ODS.UnderwritingPlatform upl
	ON upl.PK_UnderwritingPlatform = slcl.FK_UnderwritingPlatform
	WHERE ups.UnderwritingPlatformCode IN ('SYND','LBSM','LBSF')
	AND upl.UnderwritingPlatformCode = 'LBS'
GROUP BY 
	 ss.PK_Section
	,sl.PK_Section

/* Set ExcLBS columns to 0 for LBS sections */
UPDATE seocl
SET	LimitExcLBS 		=  CASE WHEN seocs.Limit IS NULL THEN NULL ELSE 0 END
	,SubexposureExcLBS 	=  CASE WHEN seocs.Subexposure IS NULL THEN NULL ELSE 0 END
FROM 
#ExcLBS exc
INNER JOIN Red.FactLimit seocl 
ON exc.FK_SectionExcLBS 		= seocl.FK_Section
INNER JOIN Red.FactLimit seocs 
ON exc.FK_Section 	= seocs.FK_Section
WHERE 
	ISNULL(exc.Limit,0) = ISNULL(exc.LimitExcLBS,0)


IF NOT EXISTS
(
    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactLimit' AND CONSTRAINT_NAME = 'UQ_FactLimit_LogicalKey'     
)
BEGIN
    ALTER TABLE Red.FactLimit
    ADD CONSTRAINT UQ_FactLimit_LogicalKey
    UNIQUE
        (
             FK_Section
			 ,FK_Syndicate
			 ,FK_ShareType
			 ,FK_ReportingCurrencyOverride
			 ,FK_SettlementCurrency
			 ,FK_OriginalCurrency
			 ,FK_LimitCurrency
			 ,FK_Sublimit
			 ,FK_SublimitType
        )
END

ALTER TABLE Red.FactLimit CHECK CONSTRAINT ALL
    
IF (OBJECT_ID('tempdb..#SectionShareType') IS NOT NULL) DROP TABLE #SectionShareType
IF (OBJECT_ID('tempdb..#SectionLimitCurrency') IS NOT NULL) DROP TABLE #SectionLimitCurrency
IF (OBJECT_ID('tempdb..#ExcLBS') IS NOT NULL) DROP TABLE #ExcLBS;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactLimit';