﻿

CREATE PROC [Red].[usp_PostProcessFactClaimExposure]
AS

SET NOCOUNT ON
 

/****************************************************************************************/
-- CREATE INDEX 
IF NOT EXISTS (SELECT 1 FROM sys.indexes where object_name(object_id) = 'FactClaimExposure' and name = 'IK_FactClaimExposure')
BEGIN
	CREATE CLUSTERED INDEX [IK_FactClaimExposure] ON [Red].[FactClaimExposure]
	(
		[FK_EntityPerspective] ASC,
		[FK_ReportingCurrencyOverride] ASC,
		[FK_ShareType] ASC,
		[FK_ClaimExposure] ASC,
		[FK_Section] ASC,
		[FK_Syndicate] ASC,
		[FK_SlipLineNumber] ASC,
		[ClaimMovementPartition] ASC
	)  ON [PRIMARY]
END 

--** Enable  constraints --
ALTER TABLE Red.FactClaimExposure CHECK CONSTRAINT ALL;
ALTER TABLE Red.FactExposureProfileBand CHECK CONSTRAINT ALL;
--**


/****************************************************************************************/
-- Pessimistic/Most Likely null check and ExposureStatus check fields update. Needed for the Red cube.'       
-- The purpose of this logic is to be able to detect null values in the pessimitic or most likely estimates 
-- and identify the status of a claim at any point on time 
-- when we roll up claims transactions in the cube.
-- THIS RELIES ON THE CLUSTERED INDEX TO WORK!!!
/****************************************************************************************/
 

-- Pessimistic / Most Likely NullCheck and ExposureStatus check  
DECLARE @Prev_FK_ClaimExposure              BIGINT
DECLARE @Prev_FK_Section                    BIGINT
DECLARE @Prev_FK_Syndicate                  BIGINT
DECLARE @Prev_FK_SlipLineNumber             BIGINT
DECLARE @Prev_FK_ShareType                  BIGINT
DECLARE @Prev_FK_ReportingCurrencyOverride  BIGINT
DECLARE @Prev_FK_EntityPerspective          BIGINT


DECLARE @MostLikelyNullCheck        INT
DECLARE @MostLikelyNullCheckAgg     INT

DECLARE @PessimisticNullCheck       INT
DECLARE @PessimisticNullCheckAgg    INT

DECLARE @ExposureStatusCheck        INT
DECLARE @ExposureStatusCheckAgg     INT


SET     @PessimisticNullCheckAgg    = 0
SET     @MostLikelyNullCheckAgg     = 0
SET     @ExposureStatusCheckAgg     = 0

UPDATE fc

SET  
@MostLikelyNullCheck = fc.MostLikelyNullCheck       = CASE WHEN 
                                                       (
                                                        fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                  
                                                        AND fc.FK_Section                               = @Prev_FK_Section                    
                                                        AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                        AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                        AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                        AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                        AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                        )
                                                       THEN    ( 
                                                               CASE WHEN fc.MostLikely IS NOT NULL THEN 1
                                                               ELSE -(@MostLikelyNullCheckAgg) 
                                                               END
                                                                )
                                                       ELSE 
                                                                ( 
                                                               CASE WHEN fc.MostLikely IS NOT NULL THEN 1
                                                               ELSE 0 
                                                               END
                                                                ) 
                                                       
                                                       END  
                                                             
                                                       
,@PessimisticNullCheck = fc.PessimisticNullCheck    = CASE WHEN 
                                                               (
                                                                fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                   
                                                                AND fc.FK_Section                               = @Prev_FK_Section                    
                                                                AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                                AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                                AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                                AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                                AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                                )
                                                            THEN    ( 
                                                                       CASE WHEN fc.Pessimistic IS NOT NULL THEN 1
                                                                       ELSE -(@PessimisticNullCheckAgg) 
                                                                       END
                                                                     )
                                                            ELSE 
                                                                     ( 
                                                                       CASE WHEN fc.Pessimistic IS NOT NULL THEN 1
                                                                       ELSE 0 
                                                                       END
                                                                     ) 
                                                               
                                                            END 

,@ExposureStatusCheck = fc.ExposureStatusCheck      = CASE WHEN 
                                                       (
                                                        fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                    
                                                        AND fc.FK_Section                               = @Prev_FK_Section                    
                                                        AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                        AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                        AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                        AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                        AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                        )
                                                       THEN    ( 
                                                               CASE WHEN fc.ExposureStatusCode = 'O' THEN 1
                                                               ELSE -(@ExposureStatusCheckAgg) 
                                                               END
                                                                )
                                                       ELSE 
                                                                ( 
                                                               CASE WHEN fc.ExposureStatusCode = 'O' THEN 1
                                                               ELSE 0 
                                                               END
                                                                ) 
                                                       
                                                       END  


,@MostLikelyNullCheckAgg                        = CASE WHEN 
                                                               (
                                                                fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                    
                                                                AND fc.FK_Section                               = @Prev_FK_Section                    
                                                                AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                                AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                                AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                                AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                                AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                                )
                                               THEN  @MostLikelyNullCheckAgg  + @MostLikelyNullCheck 
                                               ELSE  ( 
                                                                       CASE WHEN fc.MostLikely IS NOT NULL THEN 1
                                                                       ELSE 0 
                                                                       END
                                                                     ) 
                                               END
    
    
    
,@PessimisticNullCheckAgg                       = CASE WHEN 
                                                               (
                                                                fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                     
                                                                AND fc.FK_Section                               = @Prev_FK_Section
                                                                AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                                AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                                AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                                AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                                AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                                )
                                               THEN  @PessimisticNullCheckAgg + @PessimisticNullCheck
                                               ELSE  ( 
                                                                       CASE WHEN fc.Pessimistic IS NOT NULL THEN 1
                                                                       ELSE 0 
                                                                       END
                                                                     )  
                                               END

,@ExposureStatusCheckAgg                    = CASE WHEN 
                                                               (
                                                                fc.FK_ClaimExposure                             = @Prev_FK_ClaimExposure                     
                                                                AND fc.FK_Section                               = @Prev_FK_Section                    
                                                                AND COALESCE(fc.FK_Syndicate,-999999999)        = COALESCE(@Prev_FK_Syndicate,-999999999)                 
                                                                AND COALESCE(fc.FK_SlipLineNumber,-999999999)   = COALESCE(@Prev_FK_SlipLineNumber,-999999999)            
                                                                AND fc.FK_ShareType                             = @Prev_FK_ShareType                 
                                                                AND fc.FK_ReportingCurrencyOverride             = @Prev_FK_ReportingCurrencyOverride 
                                                                AND fc.FK_EntityPerspective                     = @Prev_FK_EntityPerspective 
                                                                )
                                               THEN  @ExposureStatusCheckAgg  + @ExposureStatusCheck 
                                               ELSE  ( 
                                                                       CASE WHEN fc.ExposureStatusCode = 'O' THEN 1
                                                                       ELSE 0 
                                                                       END
                                                                     ) 
                                               END


,@Prev_FK_ClaimExposure                     = fc.FK_ClaimExposure          
,@Prev_FK_Section                           = fc.FK_Section
,@Prev_FK_Syndicate                         = fc.FK_Syndicate                
,@Prev_FK_SlipLineNumber                    = fc.FK_SlipLineNumber           
,@Prev_FK_ShareType                         = fc.FK_ShareType                
,@Prev_FK_ReportingCurrencyOverride         = fc.FK_ReportingCurrencyOverride
,@Prev_FK_EntityPerspective                 = fc.FK_EntityPerspective    

FROM 
Red.FactClaimExposure  fc WITH (TABLOCKX)
OPTION (MAXDOP 1)