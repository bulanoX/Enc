﻿CREATE PROC [Red].[usp_LoadFactClaimMovement]
AS

SET NOCOUNT ON

/*****************************************************************************************/
/*    Work out each section's relative contribution to the total line for each movement */
/*****************************************************************************************/
TRUNCATE TABLE Red.ClaimMovementSection

INSERT INTO Red.ClaimMovementSection
 (
    FK_ClaimMovement
   ,FK_Section
   ,WeightingMultiplier
 )

SELECT
    FK_ClaimMovement        = cml.FK_ClaimMovement           
   ,FK_Section              = cml.FK_Section                          
   ,WeightingMultiplier     = SUM(
                                  CASE WHEN tl.TotalLine = 0 THEN 1 / tl.NumberOfRows
                                  ELSE cml.LineMultiplier / tl.TotalLine
                                  END
                                  )                                 
FROM ODS.ClaimMovementLine cml
INNER JOIN
(
    SELECT
    PK_ClaimMovement    = cml.FK_ClaimMovement                            
    ,TotalLine          = SUM(cml.LineMultiplier)                       
    ,NumberOfRows       = CAST(COUNT(1) as float)                       
    FROM  
    ODS.ClaimMovementLine cml
    GROUP BY 
    cml.FK_ClaimMovement
) tl ON 
cml.FK_ClaimMovement = tl.PK_ClaimMovement
GROUP BY 
cml.FK_ClaimMovement
,cml.FK_Section

--For movements which do not have any lines, add distribute the sections evenly*/
INSERT INTO Red.ClaimMovementSection
 (
    FK_ClaimMovement
   ,FK_Section
   ,WeightingMultiplier
 )
 
SELECT
FK_ClaimMovement        = cm.PK_ClaimMovement                            
,FK_Section             = ces.FK_Section                                   
,WeightingMultiplier     = CAST(1 as float) / x.NumberOfSections
FROM 
ODS.ClaimExposureSection ces
INNER JOIN
ODS.ClaimMovement cm ON 
ces.FK_ClaimExposure = cm.FK_ClaimExposure
INNER JOIN  
(
    SELECT
    FK_ClaimExposure    = ces.FK_ClaimExposure             
    ,NumberOfSections   = CAST(COUNT(1) as float)    
    FROM 
    ODS.ClaimExposureSection ces
    GROUP BY 
    ces.FK_ClaimExposure
) x 
ON cm.FK_ClaimExposure = x.FK_ClaimExposure
WHERE 
NOT EXISTS 
(
      SELECT 
      1 
      FROM 
      Red.ClaimMovementSection cms
      WHERE cms.FK_ClaimMovement = cm.PK_ClaimMovement
) 

/*****************************************************************************************/
/*                        Share type (Claim Movement Line level)                         */              
/*****************************************************************************************/
IF (OBJECT_ID('tempdb..#ClaimMovementLineShareType') IS NOT NULL) DROP TABLE #ClaimMovementLineShareType

CREATE TABLE #ClaimMovementLineShareType
 (
     FK_ClaimMovement               bigint                 NOT NULL
    ,FK_ShareType                   bigint                 NOT NULL
    ,FK_Section                     bigint                 NOT NULL
    ,FK_Syndicate                   bigint                 NULL
    ,FK_SlipLineNumber              bigint                 NULL
    ,TotalLineMultiplier            numeric(19,12)         NOT NULL
 )

TRUNCATE TABLE #ClaimMovementLineShareType

--For movements attaching to more than one Section, we create one record per Section and apportion
--the Total Order and Slip Order amounts based on each Section's contribution to the total at Beazley level

--Total/Slip order
INSERT INTO #ClaimMovementLineShareType
(
    FK_ClaimMovement
    ,FK_ShareType
    ,FK_Section
    ,TotalLineMultiplier
)

SELECT DISTINCT 
FK_ClaimMovement        = cm.PK_ClaimMovement                         
,FK_ShareType           = st.PK_ShareType                               
,FK_Section             = cms.FK_Section   
,TotalLineMultiplier    = CASE WHEN cm.MovementType = 'SCM' OR c.claimType IN ('Special Processing Claim') THEN 
										CASE st.ShareTypeName 
											WHEN 'Total Order' THEN cms.WeightingMultiplier / isnull(cast(case when ce.ordernumber = 0 then 100 
											                                                                   else ce.OrderNumber /*cml.LineMultiplier  */ end / 100 as numeric(19,12)), ce.WrittenIfNotSignedOrderMultiplier)
											WHEN 'Slip Order'  THEN cms.WeightingMultiplier   
										END	
							 
						      ELSE CASE WHEN c.claimType IN ('General Claim') THEN  
							                  CASE WHEN st.ShareTypeName = 'Total Order' AND sl.Facility IS NOT NULL THEN cms.WeightingMultiplier/CAST(CASE WHEN cml.LineMultiplier = 0 THEN 1
											                                                                                                               ELSE cml.LineMultiplier END /1 AS numeric(19,12))
												   WHEN	st.ShareTypeName = 'Total Order' AND sl.Facility IS NULL	then cms.WeightingMultiplier/CAST(CASE WHEN sl.WrittenIfNotSignedLineMultiplier = 0 THEN 1
											                                                                                                 ELSE sl.WrittenIfNotSignedLineMultiplier END /1 AS numeric(19,12))
																											
							                       WHEN st.ShareTypeName = 'Slip Order'  THEN cms.WeightingMultiplier
											   END
                                      
									    WHEN c.claimType IN ('Embedded Claim') THEN 
										      
										      CASE st.ShareTypeName WHEN 'Total Order' THEN cms.WeightingMultiplier  --/CAST(CASE WHEN cml.LineMultiplier = 0 THEN 1 ELSE cml.LineMultiplier END /1 AS numeric(19,12))   

									                                 WHEN 'Slip Order' THEN  cms.WeightingMultiplier 
								               END 
							      
							         END 
						    END
FROM ODS.ClaimMovement cm

INNER JOIN 
(SELECT fk_claimMovement , 
        SUM(LineMultiplier) as LineMultiplier
 FROM ODS.ClaimMovementLine
 GROUP BY fk_claimMovement
 ) cml ON 
cm.PK_ClaimMovement = cml.FK_ClaimMovement

INNER JOIN 
ODS.ClaimExposure ce ON 
cm.FK_ClaimExposure = ce.PK_ClaimExposure

INNER JOIN
ODS.Claim c ON
ce.fk_CLaim = c.Pk_claim

INNER JOIN 
Red.ClaimMovementSection cms ON 
cm.PK_ClaimMovement = cms.FK_ClaimMovement

INNER JOIN 
(SELECT fk_section,
        s.Facility,
        SUM(sl.WrittenIfNotSignedLineMultiplier) as WrittenIfNotSignedLineMultiplier
FROM ODS.SectionLine sl 
INNER JOIN ODS.Section s on sl.FK_Section = s.PK_Section
GROUP BY fk_section, s.Facility
) sl ON
cms.FK_Section = sl.fk_section

CROSS JOIN 
Red.ShareType st

WHERE 
st.ShareTypeName IN ('Total Order','Slip Order')


--Beazley Share
INSERT INTO #ClaimMovementLineShareType
(
    FK_ClaimMovement
    ,FK_ShareType
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,TotalLineMultiplier
)
SELECT
FK_ClaimMovement        = cm.PK_ClaimMovement                    
,FK_ShareType           = st.PK_ShareType                            
,FK_Section             = cml.FK_Section                                 
,FK_Syndicate           = cml.FK_Syndicate                           
,FK_SlipLineNumber      = cml.FK_SlipLineNumber                 
,TotalLineMultiplier    = cast(cml.LineMultiplier as NUMERIC(19,12)) --ce.WrittenIfNotSignedOrderMultiplier * cml.LineMultiplier    
--,TotalLineMultiplier    = ce.WrittenIfNotSignedOrderMultiplier * cml.LineMultiplier                             
FROM 
ODS.ClaimMovement cm
INNER JOIN 
ODS.ClaimExposure ce ON 
cm.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN 
ODS.ClaimMovementLine cml ON 
cm.PK_ClaimMovement = cml.FK_ClaimMovement
INNER JOIN 
Red.ShareType st ON 
st.ShareTypeName = 'Beazley Share'

--Paid Amounts
IF (OBJECT_ID('tempdb..#ClaimMovement') IS NOT NULL) DROP TABLE #ClaimMovement

CREATE TABLE #ClaimMovement
(
    FK_ClaimMovement                                bigint              NOT NULL
    ,FK_Section                                     bigint              NULL
    ,FK_Syndicate                                   bigint              NULL
    ,FK_SlipLineNumber                              bigint              NULL
    ,FK_ShareType                                   bigint              NULL default 0
    ,FK_Date                                        datetime            NOT NULL default 0
  	,FK_MovementCreationDate                        datetime            NULL
    ,FK_YOA                                         bigint              NULL default 0
    ,FK_SettlementCurrency                          bigint              NULL default 0
    ,FK_OriginalCurrency                            bigint              NULL default 0
	  ,FK_LocalCurrency		                        bigint              NULL default 0
    ,FK_GQDTransactionType                          bigint              NULL default 0
    ,FK_ClaimCostCategory                           bigint              NULL default 0
    ,FK_ClaimExposure                               bigint              NULL default 0
    ,FK_DevelopmentPeriod                           bigint              NULL default 0
    ,FK_SpecialCategoryCatastrophe                  bigint              NULL default 0
    ,FK_TriFocus                                    bigint              NULL default 0
    ,FK_CRMBroker                                   bigint              NULL default 0
    ,FK_Policy                                      bigint              NULL default 0
    ,FK_QuoteFilter                                 bigint              NULL default 0
    ,FK_HiddenStatusFilter                          bigint              NULL default 0
	,FK_UnderwritingPlatform						bigint				NULL default 0
	,FK_InternalWrittenBinderStatus					bigint				NULL default 0
	,FK_ServiceCompany								bigint				NULL default 0
    ,MovementGroupId                                int                 NULL default 0
    ,MovementGroupSequenceId                        int                 NULL default 0
    /*Paid*/
    ,MovementNetPaymentAmountInOriginalCCY          numeric(20,4)       NULL default 0
	,MovementPaidIndemnityInOriginalCCY             numeric(19,4)       NULL default 0
    ,MovementPaidFeesInOriginalCCY                  numeric(19,4)       NULL default 0
    ,MovementPaidDefenceInOriginalCCY               numeric(19,4)       NULL default 0
	,MovementTaxAmountInOriginalCCY                 numeric(20,4)       NULL default 0
	,MovementNetPaymentAmountInSettlementCCY        numeric(20,4)       NULL default 0
    ,MovementPaidIndemnityInSettlementCCY           numeric(19,4)       NULL default 0
    ,MovementPaidFeesInSettlementCCY                numeric(19,4)       NULL default 0
    ,MovementPaidDefenceInSettlementCCY             numeric(19,4)       NULL default 0
	,MovementTaxAmountInSettlementCCY               numeric(20,4)       NULL default 0
    ,ToDateNetPaymentAmountInOriginalCCY            numeric(20,4)       NULL
	,ToDatePaidIndemnityInOriginalCCY               numeric(19,4)       NULL
    ,ToDatePaidFeesInOriginalCCY                    numeric(19,4)       NULL
    ,ToDatePaidDefenceInOriginalCCY                 numeric(19,4)       NULL
	,ToDateTaxAmountInOriginalCCY                   numeric(20,4)       NULL
	,ToDateNetPaymentAmountInSettlementCCY          numeric(20,4)       NULL
    ,ToDatePaidIndemnityInSettlementCCY             numeric(19,4)       NULL
    ,ToDatePaidFeesInSettlementCCY                  numeric(19,4)       NULL
    ,ToDatePaidDefenceInSettlementCCY               numeric(19,4)       NULL
	,ToDateTaxAmountInSettlementCCY                 numeric(20,4)       NULL
    ,MovementOutstandingIndemnityInOriginalCCY      numeric(19,4)       NULL
    ,MovementOutstandingFeesInOriginalCCY           numeric(19,4)       NULL
    ,MovementOutstandingDefenceInOriginalCCY        numeric(19,4)       NULL
    ,MovementOutstandingIndemnityInSettlementCCY    numeric(19,4)       NULL
    ,MovementOutstandingFeesInSettlementCCY         numeric(19,4)       NULL
    ,MovementOutstandingDefenceInSettlementCCY      numeric(19,4)       NULL
    ,ToDateOutstandingIndemnityInOriginalCCY        numeric(19,4)       NULL default 0
    ,ToDateOutstandingFeesInOriginalCCY             numeric(19,4)       NULL default 0
    ,ToDateOutstandingDefenceInOriginalCCY          numeric(19,4)       NULL default 0
    ,ToDateOutstandingIndemnityInSettlementCCY      numeric(19,4)       NULL default 0
    ,ToDateOutstandingFeesInSettlementCCY           numeric(19,4)       NULL default 0
    ,ToDateOutstandingDefenceInSettlementCCY        numeric(19,4)       NULL  default 0
    /*Non-reinsurance recoveries (negative paid amounts)*/
    ,MovementReceivedIndemnityNRRInOriginalCCY      numeric(19,4)       NULL default 0
    ,MovementReceivedFeesNRRInOriginalCCY           numeric(19,4)       NULL default 0
    ,MovementReceivedDefenceNRRInOriginalCCY        numeric(19,4)       NULL default 0
    ,ToDateReceivedIndemnityNRRInOriginalCCY        numeric(19,4)       NULL
    ,ToDateReceivedFeesNRRInOriginalCCY             numeric(19,4)       NULL
    ,ToDateReceivedDefenceNRRInOriginalCCY          numeric(19,4)       NULL
    ,MovementReceivedIndemnityNRRInSettlementCCY    numeric(19,4)       NULL default 0
    ,MovementReceivedFeesNRRInSettlementCCY         numeric(19,4)       NULL default 0
    ,MovementReceivedDefenceNRRInSettlementCCY      numeric(19,4)       NULL     default 0
    ,ToDateReceivedIndemnityNRRInSettlementCCY      numeric(19,4)       NULL
    ,ToDateReceivedFeesNRRInSettlementCCY           numeric(19,4)       NULL
    ,ToDateReceivedDefenceNRRInSettlementCCY        numeric(19,4)       NULL
    ,PaidOriginalCCYToSettlementCCYRate             numeric(19,12)      NULL default 0
    ,OutstandingOriginalCCYToSettlementCCYRate      numeric(19,12)      NULL default 0
    ,OriginalCCY                                    varchar(255)        NULL default 0
    ,SettlementCCY                                  varchar(255)        NULL default 0
    ,SpecialPurposeSyndicateApplies                 bit                 NULL default 0
	,OriginalCCYToLocalCCYRate						numeric(19,12)      NULL
	,ClaimTeamExaminer								varchar(255)        NULL
	,FK_ClaimTeamExaminer							bigint				NULL	
	,ActualOriginalCurrency 						VARCHAR(3)			NULL		   --MultiCCY change --
	,ActualOriginalAmount 							NUMERIC(19,4)		NULL		   --MultiCCY change --
	,EstimatedSettlementAmount 						NUMERIC(19,4)		NULL		   --MultiCCY change --
	,ActualToSettlementExchangeRate					NUMERIC(19,4)		NULL		   --MultiCCY change --
	,ActualOriginalAmountType						varchar(255)		NULL		   --MultiCCY change --
	,SignedLine										NUMERIC(20, 4)		NULL

)

CREATE CLUSTERED INDEX IDX_ClaimMovementPaid ON #ClaimMovement 
(
    MovementGroupId
    ,FK_ShareType
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,MovementGroupsequenceId
)

CREATE NONCLUSTERED INDEX IDX_ClaimMovementLineShareType
ON #ClaimMovementLineShareType (FK_ClaimMovement)
INCLUDE 
(
    FK_ShareType
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,TotalLineMultiplier
)

INSERT INTO #ClaimMovement
 (
    FK_ClaimMovement
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,FK_ShareType
    ,FK_Date
	,FK_MovementCreationDate               
    ,FK_YOA                
    ,FK_SettlementCurrency 
    ,FK_OriginalCurrency
	,FK_LocalCurrency
    ,FK_GQDTransactionType 
    ,FK_ClaimCostCategory
    ,FK_ClaimExposure
    ,FK_DevelopmentPeriod
    ,FK_SpecialCategoryCatastrophe
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany	
    ,MovementGroupId
    ,MovementGroupSequenceId
    ,MovementNetPaymentAmountInOriginalCCY
	,MovementPaidIndemnityInOriginalCCY
    ,MovementPaidFeesInOriginalCCY
    ,MovementPaidDefenceInOriginalCCY
	,MovementTaxAmountInOriginalCCY
    ,MovementNetPaymentAmountInSettlementCCY
	,MovementPaidIndemnityInSettlementCCY
    ,MovementPaidFeesInSettlementCCY
    ,MovementPaidDefenceInSettlementCCY
	,MovementTaxAmountInSettlementCCY
    ,ToDateOutstandingIndemnityInOriginalCCY
    ,ToDateOutstandingFeesInOriginalCCY
    ,ToDateOutstandingDefenceInOriginalCCY
    ,ToDateOutstandingIndemnityInSettlementCCY
    ,ToDateOutstandingFeesInSettlementCCY
    ,ToDateOutstandingDefenceInSettlementCCY
    ,MovementReceivedIndemnityNRRInOriginalCCY
    ,MovementReceivedFeesNRRInOriginalCCY
    ,MovementReceivedDefenceNRRInOriginalCCY
    ,MovementReceivedIndemnityNRRInSettlementCCY
    ,MovementReceivedFeesNRRInSettlementCCY
    ,MovementReceivedDefenceNRRInSettlementCCY
    ,PaidOriginalCCYToSettlementCCYRate
    ,OutstandingOriginalCCYToSettlementCCYRate
    ,OriginalCCY
    ,SettlementCCY
    ,SpecialPurposeSyndicateApplies
	,OriginalCCYToLocalCCYRate  
	,ClaimTeamExaminer				
	,FK_ClaimTeamExaminer
	,ActualOriginalCurrency 		   --MultiCCY change --
	,ActualOriginalAmount 			   --MultiCCY change --
	,EstimatedSettlementAmount 		   --MultiCCY change --
	,ActualToSettlementExchangeRate	   --MultiCCY change --			
	,ActualOriginalAmountType		   --MultiCCY change --
	,SignedLine

 ) 
SELECT
FK_ClaimMovement                                = cml.FK_ClaimMovement                       
,FK_Section                                     = cml.FK_Section                               
,FK_Syndicate                                   = cml.FK_Syndicate                         
,FK_SlipLineNumber                              = cml.FK_SlipLineNumber               
,FK_ShareType                                   = cml.FK_ShareType                         
,FK_Date                                        = cm.FK_MovementPeriod
,FK_MovementCreationDate                        = cm.FK_MovementCreationDate
,FK_YOA                                         = ce.FK_YOA
,FK_SettlementCurrency                          = cm.FK_SettlementCurrency
,FK_OriginalCurrency                            = cm.FK_OriginalCurrency
,FK_LocalCurrency								= cm.FK_LocalCurrency
,FK_GQDTransactionType                          = ce.FK_GQDTransactionType
,FK_ClaimCostCategory                           = cm.FK_ClaimCostCategory
,FK_ClaimExposure                               = cm.FK_ClaimExposure
,FK_DevelopmentPeriod                           = cm.FK_DevelopmentPeriod
,FK_SpecialCategoryCatastrophe                  = ce.FK_SpecialCategoryCatastrophe
,FK_TriFocus                                    = s.FK_TriFocus
,FK_CRMBroker                                   = s.FK_CRMBroker
,FK_Policy                                      = s.FK_Policy
,FK_QuoteFilter                                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter                          = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform						= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus					= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany								= s.FK_ServiceCompany	
,MovementGroupId                                = cm.MovementGroupId                          
,MovementGroupSequenceId                        = cm.MovementGroupSequenceId          
,MovementNetPaymentAmountInOriginalCCY          = cm.MovementNetPaymentAmountInOriginalCCY * cml.TotalLineMultiplier
,MovementPaidIndemnityInOriginalCCY             = cm.MovementPaidIndemnityInOriginalCCY * cml.TotalLineMultiplier
,MovementPaidFeesInOriginalCCY                  = cm.MovementPaidFeesInOriginalCCY * cml.TotalLineMultiplier
,MovementPaidDefenceInOriginalCCY               = cm.MovementPaidDefenceInOriginalCCY * cml.TotalLineMultiplier
,MovementTaxAmountInOriginalCCY                 = cm.MovementTaxAmountInOriginalCCY * cml.TotalLineMultiplier
/**!!!!!!!!!!!!!!START - Take Settlement for Agresso user  !!!!!!!!!!*/
,MovementNetPaymentAmountInSettlementCCY        = cm.MovementNetPaymentAmountInSettlementCCY * cml.TotalLineMultiplier
,MovementPaidIndemnityInSettlementCCY           = cm.MovementPaidIndemnityInSettlementCCY * cml.TotalLineMultiplier
,MovementPaidFeesInSettlementCCY                = cm.MovementPaidFeesInSettlementCCY * cml.TotalLineMultiplier
,MovementPaidDefenceInSettlementCCY             = cm.MovementPaidDefenceInSettlementCCY * cml.TotalLineMultiplier
,MovementTaxAmountInSettlementCCY               = cm.MovementTaxAmountInSettlementCCY * cml.TotalLineMultiplier
/**!!!!!!!!!!!!!!FINISH - Take Settlement for Agresso user  !!!!!!!!!!*/
,ToDateOutstandingIndemnityInOriginalCCY        = cm.ToDateOutstandingIndemnityInOriginalCCY * cml.TotalLineMultiplier
,ToDateOutstandingFeesInOriginalCCY             = cm.ToDateOutstandingFeesInOriginalCCY * cml.TotalLineMultiplier
,ToDateOutstandingDefenceInOriginalCCY          = cm.ToDateOutstandingDefenceInOriginalCCY * cml.TotalLineMultiplier
/*!!!!!!!!!!!!!!!START - ToDate.. for Agresso user !!!!!!!!!!!!*/
,ToDateOutstandingIndemnityInSettlementCCY      = cm.ToDateOutstandingIndemnityInSettlementCCY * cml.TotalLineMultiplier
,ToDateOutstandingFeesInSettlementCCY           = cm.ToDateOutstandingFeesInSettlementCCY * cml.TotalLineMultiplier
,ToDateOutstandingDefenceInSettlementCCY        = cm.ToDateOutstandingDefenceInSettlementCCY * cml.TotalLineMultiplier
/*!!!!!!!!!!!!!!!FINISH - ToDate.. for Agresso user !!!!!!!!!!!!*/
/*Non-reinsurance recoveries*/
,MovementReceivedIndemnityNRRInOriginalCCY      = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidIndemnityInOriginalCCY < 0) THEN cm.MovementPaidIndemnityInOriginalCCY * cml.TotalLineMultiplier ELSE 0 END
,MovementReceivedFeesNRRInOriginalCCY           = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidFeesInOriginalCCY < 0) THEN cm.MovementPaidFeesInOriginalCCY * cml.TotalLineMultiplier ELSE 0 END
,MovementReceivedDefenceNRRInOriginalCCY        = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidDefenceInOriginalCCY < 0) THEN cm.MovementPaidDefenceInOriginalCCY * cml.TotalLineMultiplier ELSE 0 END
/*!!!!!!!!!!!!!!!START - NNR for Agresso user !!!!!!!!!!!!*/
,MovementReceivedIndemnityNRRInSettlementCCY    = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidIndemnityInOriginalCCY < 0) THEN cm.MovementPaidIndemnityInSettlementCCY * cml.TotalLineMultiplier ELSE 0 END
,MovementReceivedFeesNRRInSettlementCCY         = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidFeesInOriginalCCY < 0) THEN cm.MovementPaidFeesInSettlementCCY * cml.TotalLineMultiplier ELSE 0 END
,MovementReceivedDefenceNRRInSettlementCCY      = -1 * CASE WHEN cm.MovementType = 'Recovery' OR (cm.MovementType = 'SCM' AND cm.MovementPaidDefenceInOriginalCCY < 0) THEN cm.MovementPaidDefenceInSettlementCCY * cml.TotalLineMultiplier ELSE 0 END
/*!!!!!!!!!!!!!!!FINISH - NNR for Agresso user !!!!!!!!!!!!*/
,PaidOriginalCCYToSettlementCCYRate             = cm.PaidOriginalCCYToSettlementCCYRate 
,OutstandingOriginalCCYToSettlementCCYRate      = cm.OutstandingOriginalCCYToSettlementCCYRate
,OriginalCCY                                    = oc.CurrencyCode                                 
,SettlementCCY                                  = sc.CurrencyCode                             
,SpecialPurposeSyndicateApplies                 = s.SpecialPurposeSyndicateApplies
,OriginalCCYToLocalCCYRate					    = CASE WHEN cm.OriginalCCYToLocalCCYRate IS NULL THEN 1 ELSE cm.OriginalCCYToLocalCCYRate END
,ClaimTeamExaminer								= ce.ClaimTeamExaminer				
,FK_ClaimTeamExaminer							= ce.FK_ClaimTeamExaminer	            
,ActualOriginalCurrency 						= cm.ActualOriginalCurrency 			   --MultiCCY change --
,ActualOriginalAmount 							= cm.ActualOriginalAmount				   --MultiCCY change --
,EstimatedSettlementAmount 						= cm.EstimatedSettlementAmount 			   --MultiCCY change --
,ActualToSettlementExchangeRate					= cm.ActualToSettlementExchangeRate		   --MultiCCY change --			
,ActualOriginalAmountType 						= cm.ActualOriginalAmountType			   --MultiCCY change --
,SignedLine										= cml.TotalLineMultiplier  

FROM 
#ClaimMovementLineShareType cml
INNER JOIN 
ODS.ClaimMovement cm with (nolock) ON 
cml.FK_ClaimMovement = cm.PK_ClaimMovement
INNER JOIN 
ODS.ClaimExposure ce with (nolock) ON 
cm.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN 
ODS.SettlementCurrency sc with (nolock) ON 
cm.FK_SettlementCurrency = sc.PK_SettlementCurrency
INNER JOIN 
ODS.OriginalCurrency oc with (nolock) ON 
cm.FK_OriginalCurrency = oc.PK_OriginalCurrency
INNER JOIN 
ODS.Section s with (nolock) 
ON cml.FK_Section = s.PK_Section 

/*
Now we need to work out:

  -Paid-to-date amounts for "paid" fields
  -Deltas for outstanding fields
  
Below is a method which allows us to do this in a highly performant manner. It is documented very well here:
http://www.sqlservercentral.com/articles/T-SQL/68467/

The gist of the article is that we can access values from the previous row in a recursive manner but in linear time 
by assigning the previous row value to a variable inside the "UPDATE" statement. It relies on the query being processed
in the order of the clustered index, which has been shown to be the case in this and related articles. It's not pretty, but it
is by far the fastest way of calculating running totals in SQL. Perhaps there will be a native function to do this in a future version
and this code can be re-written. A verification function will run after the load has completed to ensure the totals are correct.

Using the "triangular join" method (join to every preceding row in the group then GROUP BY and sum) this proc was taking over an hour, 
and paid-to-date values and outstanding deltas had to be worked out separately. This proc now takes <20 minutes using the method below,
and I suspect the running time is close to O(n) (upper bound for the running time of the triangular join method is probably ((n^2 + n) / 2), 
but the actual running time depends on the characteristics of the data, specifically how big the "triangles" get).

The only other quirk is that for movement groups that have movements in multiple original currencies, we have to convert the 
previous movement value to settlement currency, then back out to the new original currency. Multiple settlement currencies aren't an issue
because MovementGroupId is generated based on settlement currency (as well as other fields), so there will never be multiple settlement currencies in one group.
*/


DECLARE @Anchor bigint

DECLARE @PrevMovementGroupId int
DECLARE @PrevMovementGroupSequenceId int
DECLARE @PrevFK_Section bigint
DECLARE @PrevFK_Syndicate bigint
DECLARE @PrevFK_SlipLineNumber bigint
DECLARE @PrevFK_ShareType bigint

DECLARE @ToDateNetPaymentAmountInOriginalCCY numeric(20,4)
DECLARE @ToDatePaidFeesInOriginalCCY numeric(19,4)
DECLARE @ToDatePaidIndemnityInOriginalCCY numeric(19,4)
DECLARE @ToDatePaidDefenceInOriginalCCY numeric(19,4)
DECLARE @ToDateTaxAmountInOriginalCCY numeric(20,4)

DECLARE @ToDateReceivedFeesNRRInOriginalCCY numeric(19,4)
DECLARE @ToDateReceivedIndemnityNRRInOriginalCCY numeric(19,4)
DECLARE @ToDateReceivedDefenceNRRInOriginalCCY numeric(19,4)

DECLARE @ToDateNetPaymentAmountInSettlementCCY numeric(20,4)
DECLARE @ToDatePaidFeesInSettlementCCY numeric(19,4)
DECLARE @ToDatePaidIndemnityInSettlementCCY numeric(19,4)
DECLARE @ToDatePaidDefenceInSettlementCCY numeric(19,4)
DECLARE @ToDateTaxAmountInSettlementCCY numeric(20,4)

DECLARE @ToDateReceivedFeesNRRInSettlementCCY numeric(19,4)
DECLARE @ToDateReceivedIndemnityNRRInSettlementCCY numeric(19,4)
DECLARE @ToDateReceivedDefenceNRRInSettlementCCY numeric(19,4)

DECLARE @PrevToDateOutstandingFeesInOriginalCCY numeric(19,4)
DECLARE @PrevToDateOutstandingIndemnityInOriginalCCY numeric(19,4)
DECLARE @PrevToDateOutstandingDefenceInOriginalCCY numeric(19,4)

DECLARE @PrevToDateOutstandingFeesInSettlementCCY numeric(19,4)
DECLARE @PrevToDateOutstandingIndemnityInSettlementCCY numeric(19,4)
DECLARE @PrevToDateOutstandingDefenceInSettlementCCY numeric(19,4)

DECLARE @t1 numeric(19,4)
DECLARE @t2 numeric(19,4)
DECLARE @t3 numeric(19,4)
DECLARE @t4 numeric(19,4)
DECLARE @t5 numeric(19,4)
DECLARE @t6 numeric(19,4)

DECLARE @PrevOriginalCCY varchar(255)

DECLARE @NewGroup bit

UPDATE cm SET
@Anchor                                             = cm.FK_ClaimMovement
,@NewGroup                                          = CASE 
                                                        WHEN
                                                            cm.MovementGroupId = @PrevMovementGroupId
                                                            AND cm.FK_ShareType = @PrevFK_ShareType
                                                            AND cm.FK_Section = @PrevFK_Section
                                                            AND (cm.FK_Syndicate = @PrevFK_Syndicate OR (cm.FK_Syndicate IS NULL AND @PrevFK_Syndicate IS NULL))
                                                            AND (cm.FK_SlipLineNumber = @PrevFK_SlipLineNumber OR (cm.FK_SlipLineNumber IS NULL AND @PrevFK_SlipLineNumber IS NULL))
                                                        THEN 0
                                                        ELSE 1
                                                      END

,@ToDateNetPaymentAmountInOriginalCCY        
    = ToDateNetPaymentAmountInOriginalCCY           = cm.MovementNetPaymentAmountInOriginalCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDateNetPaymentAmountInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDateNetPaymentAmountInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END

,@ToDatePaidFeesInOriginalCCY        
    = ToDatePaidFeesInOriginalCCY                   = cm.MovementPaidFeesInOriginalCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDatePaidFeesInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDatePaidFeesInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@ToDatePaidIndemnityInOriginalCCY        
    = ToDatePaidIndemnityInOriginalCCY              = cm.MovementPaidIndemnityInOriginalCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDatePaidIndemnityInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDatePaidIndemnityInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@ToDatePaidDefenceInOriginalCCY                
    = ToDatePaidDefenceInOriginalCCY                = cm.MovementPaidDefenceInOriginalCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDatePaidDefenceInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDatePaidDefenceInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END

,@ToDateTaxAmountInOriginalCCY        
    = ToDateTaxAmountInOriginalCCY                 = cm.MovementTaxAmountInOriginalCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDateTaxAmountInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDateTaxAmountInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END


,@ToDateNetPaymentAmountInSettlementCCY                   
    = ToDateNetPaymentAmountInSettlementCCY        = cm.MovementNetPaymentAmountInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDateNetPaymentAmountInSettlementCCY, 0) 
                                                      END

,@ToDatePaidFeesInSettlementCCY                   
    = ToDatePaidFeesInSettlementCCY                 = cm.MovementPaidFeesInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDatePaidFeesInSettlementCCY, 0) 
                                                      END
,@ToDatePaidIndemnityInSettlementCCY              
    = ToDatePaidIndemnityInSettlementCCY            = cm.MovementPaidIndemnityInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDatePaidIndemnityInSettlementCCY, 0)
                                                      END
,@ToDatePaidDefenceInSettlementCCY                
    = ToDatePaidDefenceInSettlementCCY              = cm.MovementPaidDefenceInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDatePaidDefenceInSettlementCCY, 0) 
                                                      END

,@ToDateTaxAmountInSettlementCCY                   
    = ToDateTaxAmountInSettlementCCY                = cm.MovementTaxAmountInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDateTaxAmountInSettlementCCY, 0) 
                                                      END

/*Non-reinsurance recoveries*/
,@ToDateReceivedFeesNRRInOriginalCCY        
    = ToDateReceivedFeesNRRInOriginalCCY            = cm.MovementReceivedFeesNRRInOriginalCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDateReceivedFeesNRRInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDateReceivedFeesNRRInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@ToDateReceivedIndemnityNRRInOriginalCCY        
    = ToDateReceivedIndemnityNRRInOriginalCCY       = cm.MovementReceivedIndemnityNRRInOriginalCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDateReceivedIndemnityNRRInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDateReceivedIndemnityNRRInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@ToDateReceivedDefenceNRRInOriginalCCY                
    = ToDateReceivedDefenceNRRInOriginalCCY         = cm.MovementReceivedDefenceNRRInOriginalCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@ToDateReceivedDefenceNRRInOriginalCCY, 0) 
                                                        ELSE ISNULL(@ToDateReceivedDefenceNRRInSettlementCCY * cm.PaidOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@ToDateReceivedFeesNRRInSettlementCCY                   
    = ToDateReceivedFeesNRRInSettlementCCY          = cm.MovementReceivedFeesNRRInSettlementCCY +
                                                    CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDateReceivedFeesNRRInSettlementCCY, 0) 
                                                      END
,@ToDateReceivedIndemnityNRRInSettlementCCY              
    = ToDateReceivedIndemnityNRRInSettlementCCY     = cm.MovementReceivedIndemnityNRRInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDateReceivedIndemnityNRRInSettlementCCY, 0)
                                                      END
,@ToDateReceivedDefenceNRRInSettlementCCY                
    = ToDateReceivedDefenceNRRInSettlementCCY       = cm.MovementReceivedDefenceNRRInSettlementCCY +
                                                      CASE 
                                                        WHEN @NewGroup = 1 
                                                        THEN 0
                                                        ELSE ISNULL(@ToDateReceivedDefenceNRRInSettlementCCY, 0) 
                                                      END


/*Although we don't use @t1 etc. anywhere, we still need to assign to it to keep the 3-part UPDATE syntax. 
If we just try to use 2-part syntax of field = value, for some reason the value of @PrevToDateOutstandingFeesInOriginalCCY etc. gets
re-evaluated to the current row value, and we need it to evaluate to the value of the previous row. It's like the 3-part syntax stops the
processor re-evaluating the variable. Perhaps with the regular syntax the statement gets evaluated at the same time as the other assignments,
but with the 3-part syntax it gets evaluated before the 2-part assignments.*/
,@t1 =
    MovementOutstandingFeesInOriginalCCY            = cm.ToDateOutstandingFeesInOriginalCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@PrevToDateOutstandingFeesInOriginalCCY, 0)
                                                        ELSE ISNULL(@PrevToDateOutstandingFeesInSettlementCCY * cm.OutstandingOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@t2
    = MovementOutstandingIndemnityInOriginalCCY     = cm.ToDateOutstandingIndemnityInOriginalCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@PrevToDateOutstandingIndemnityInOriginalCCY, 0)
                                                        ELSE ISNULL(@PrevToDateOutstandingIndemnityInSettlementCCY * cm.OutstandingOriginalCCYToSettlementCCYRate, 0)
                                                      END
,@t3
    = MovementOutstandingDefenceInOriginalCCY       = cm.ToDateOutstandingDefenceInOriginalCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        WHEN cm.OriginalCCY = @PrevOriginalCCY
                                                        THEN ISNULL(@PrevToDateOutstandingDefenceInOriginalCCY, 0)
                                                        ELSE ISNULL(@PrevToDateOutstandingDefenceInSettlementCCY * cm.OutstandingOriginalCCYToSettlementCCYRate, 0)
                                                      END

,@t4
    = MovementOutstandingFeesInSettlementCCY        = cm.ToDateOutstandingFeesInSettlementCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        ELSE ISNULL(@PrevToDateOutstandingFeesInSettlementCCY, 0)
                                                      END
,@t5
    = MovementOutstandingIndemnityInSettlementCCY   = cm.ToDateOutstandingIndemnityInSettlementCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        ELSE ISNULL(@PrevToDateOutstandingIndemnityInSettlementCCY, 0)
                                                      END
,@t6
    = MovementOutstandingDefenceInSettlementCCY     = cm.ToDateOutstandingDefenceInSettlementCCY -
                                                      CASE 
                                                        WHEN @NewGroup = 1
                                                        THEN 0
                                                        ELSE ISNULL(@PrevToDateOutstandingDefenceInSettlementCCY, 0)
                                                      END
,@PrevMovementGroupId                               = cm.MovementGroupId
,@PrevMovementGroupSequenceId                       = cm.MovementGroupSequenceId
,@PrevFK_Section                                    = cm.FK_Section
,@PrevFK_ShareType                                  = cm.FK_ShareType
,@PrevFK_Syndicate                                  = cm.FK_Syndicate
,@PrevFK_SlipLineNumber                             = cm.FK_SlipLineNumber
,@PrevOriginalCCY                                   = cm.OriginalCCY
,@PrevToDateOutstandingFeesInOriginalCCY            = cm.ToDateOutstandingFeesInOriginalCCY
,@PrevToDateOutstandingIndemnityInOriginalCCY       = cm.ToDateOutstandingIndemnityInOriginalCCY
,@PrevToDateOutstandingDefenceInOriginalCCY         = cm.ToDateOutstandingDefenceInOriginalCCY
,@PrevToDateOutstandingFeesInSettlementCCY          = cm.ToDateOutstandingFeesInSettlementCCY
,@PrevToDateOutstandingIndemnityInSettlementCCY     = cm.ToDateOutstandingIndemnityInSettlementCCY
,@PrevToDateOutstandingDefenceInSettlementCCY       = cm.ToDateOutstandingDefenceInSettlementCCY
FROM
#ClaimMovement cm --Don't do any joins here, it might cause the query to process the rows in a different order which will break the functionality
OPTION (MAXDOP 1) --DOn't remove this hint: a parallel execution plan will break the functionality

--ticket 324 -- put lines which do not have correspondent for FK_ClaimTeamExaminer into dictionary to Unknown member from dictionary
UPDATE cm
SET 
	cm.FK_ClaimTeamExaminer = 0,
	cm.ClaimTeamExaminer = 'N/A'
FROM #ClaimMovement cm

LEFT JOIN ODS.ClaimTeamExaminer cte 
ON cte.PK_ClaimTeamExaminer = cm.FK_ClaimTeamExaminer

WHERE cte.PK_ClaimTeamExaminer IS NULL


TRUNCATE TABLE Red.FactClaimMovement

---///DROP INDEXES & DISABLE CONSTRATINTS

ALTER TABLE Red.FactClaimMovement NOCHECK CONSTRAINT ALL;
 
IF EXISTS (
           SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
           WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactClaimMovement' AND CONSTRAINT_NAME = 'UQ_FactClaimMovement_LogicalKey' 
           ) 
    BEGIN
        ALTER TABLE Red.FactClaimMovement
        DROP CONSTRAINT UQ_FactClaimMovement_LogicalKey

END
 
 
IF EXISTS (
           select 1 from sys.indexes where name='FactClaimMovement_EntityPerspective'
           )
BEGIN
	DROP INDEX [FactClaimMovement_EntityPerspective] ON [Red].[FactClaimMovement]
END
 
IF EXISTS (
           select 1 from sys.indexes where name='FactClaimMovement_Combined'
           )
BEGIN
	DROP INDEX [FactClaimMovement_Combined] ON [Red].[FactClaimMovement]
END



CREATE NONCLUSTERED INDEX idx_tmp1
ON #ClaimMovement ([FK_ClaimExposure])
INCLUDE ([FK_ClaimMovement],[FK_Section],[FK_Syndicate],[FK_SlipLineNumber],[FK_ShareType],[FK_Date],[FK_YOA],[FK_SettlementCurrency],[FK_OriginalCurrency],[FK_GQDTransactionType],[FK_ClaimCostCategory],[FK_DevelopmentPeriod],[FK_SpecialCategoryCatastrophe],[FK_TriFocus],[FK_CRMBroker],[FK_Policy],[FK_QuoteFilter],[FK_HiddenStatusFilter],[FK_UnderwritingPlatform],
[FK_InternalWrittenBinderStatus],[FK_ServiceCompany],[MovementPaidIndemnityInSettlementCCY],[MovementPaidFeesInSettlementCCY],[MovementPaidDefenceInSettlementCCY],[ToDatePaidIndemnityInSettlementCCY],[ToDatePaidFeesInSettlementCCY],[ToDatePaidDefenceInSettlementCCY],[MovementOutstandingIndemnityInSettlementCCY],[MovementOutstandingFeesInSettlementCCY],[MovementOutstandingDefenceInSettlementCCY],[ToDateOutstandingIndemnityInSettlementCCY],[ToDateOutstandingFeesInSettlementCCY],[ToDateOutstandingDefenceInSettlementCCY],[MovementReceivedIndemnityNRRInSettlementCCY],[MovementReceivedFeesNRRInSettlementCCY],[MovementReceivedDefenceNRRInSettlementCCY],[ToDateReceivedIndemnityNRRInSettlementCCY],[ToDateReceivedFeesNRRInSettlementCCY],[ToDateReceivedDefenceNRRInSettlementCCY],[SpecialPurposeSyndicateApplies])
  
    /*Null out movements for multi-original ccy claims.. This way they won't pollute the totals when
    disaggregating by original ccy. Keep positions as they are pre-calculated to be in the correct ccy
    at movement level, and thus still available for reporting*/
    SELECT
    PK_ClaimExposure                    = ce.PK_ClaimExposure
    ,OriginalCCYMovementMultiplier      = 1 -- changed to 1 because in V9 Movements have different currencies for the same Exposure, generating thsi multiplier as NULL
											-- -> so many nulls were generated in Red.FactClaimMovement and Red.FactCOmbinedFinancialtransaction
											--CASE WHEN ce.MultipleOriginalCCYIndicator = 1 THEN NULL ELSE 1 END
	INTO #x
    FROM
    ODS.ClaimExposure ce
	CREATE INDEX a on #x(PK_ClaimExposure)
 
--Does a minimally logged insert if this TABLOCK hint is provided, there is no clustered index,
--and the recovery model is not full*/
INSERT INTO Red.FactClaimMovement WITH(TABLOCK)
 (
    FK_ClaimMovement
    ,FK_EntityPerspective
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
	,FK_MovementCreationDate               
    ,FK_YOA                
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_ClaimCostCategory 
    ,FK_ClaimExposure
    ,FK_DevelopmentPeriod
    ,FK_SpecialCategoryCatastrophe
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany	
    ,SpecialPurposeSyndicateApplies
    ,MovementNetPaymentAmount
	,MovementPaidIndemnity
    ,MovementPaidFees
    ,MovementPaidDefence
	,MovementTaxAmount
	,ToDateNetPaymentAmount
    ,ToDatePaidIndemnity
	,ToDatePaidFees
    ,ToDatePaidDefence
	,ToDateTaxAmount
    ,MovementOutstandingIndemnity 
    ,MovementOutstandingFees
    ,MovementOutstandingDefence
    ,ToDateOutstandingIndemnity
    ,ToDateOutstandingFees
    ,ToDateOutstandingDefence
    ,MovementReceivedIndemnityNRR
    ,MovementReceivedFeesNRR
    ,MovementReceivedDefenceNRR
    ,ToDateReceivedIndemnityNRR
    ,ToDateReceivedFeesNRR
    ,ToDateReceivedDefenceNRR
	,ClaimTeamExaminer					
	,FK_ClaimTeamExaminer              
	,ActualOriginalCurrency 								  --MultiCCY change --
	,ActualOriginalAmount 									  --MultiCCY change --
	,EstimatedSettlementAmount 								  --MultiCCY change --
	,ActualToSettlementExchangeRate							  --MultiCCY change --				
	,ActualOriginalAmountType								  --MultiCCY change --
	,SignedLine

 )
SELECT
FK_ClaimMovement                = cm.FK_ClaimMovement
,FK_EntityPerspective           = cep.FK_EntityPerspective
,FK_Section                     = cm.FK_Section
,FK_Syndicate                   = cm.FK_Syndicate
,FK_SlipLineNumber              = cm.FK_SlipLineNumber
,FK_ShareType                   = cm.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = cm.FK_Date
,FK_MovementCreationDate        = cm.FK_MovementCreationDate                 
,FK_YOA                         = cm.FK_YOA
,FK_SettlementCurrency          = cm.FK_SettlementCurrency
,FK_OriginalCurrency            = cm.FK_OriginalCurrency
,FK_GQDTransactionType          = cm.FK_GQDTransactionType
,FK_ClaimCostCategory           = cm.FK_ClaimCostCategory
,FK_ClaimExposure               = cm.FK_ClaimExposure
,FK_DevelopmentPeriod           = cm.FK_DevelopmentPeriod
,FK_SpecialCategoryCatastrophe  = cm.FK_SpecialCategoryCatastrophe
,FK_TriFocus                    = cm.FK_TriFocus
,FK_CRMBroker                   = cm.FK_CRMBroker
,FK_Policy                      = cm.FK_Policy
,FK_QuoteFilter                 = cm.FK_QuoteFilter
,FK_HiddenStatusFilter          = cm.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= cm.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= cm.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= cm.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = cm.SpecialPurposeSyndicateApplies
,MovementNetPaymentAmount       = cm.MovementNetPaymentAmountInOriginalCCY              * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementPaidIndemnity          = cm.MovementPaidIndemnityInOriginalCCY                 * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementPaidFees               = cm.MovementPaidFeesInOriginalCCY                      * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementPaidDefence            = cm.MovementPaidDefenceInOriginalCCY                   * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementTaxAmount              = cm.MovementTaxAmountInOriginalCCY                     * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,ToDateNetPaymentAmount         = cm.ToDateNetPaymentAmountInOriginalCCY                * cep.PerspectiveMultiplier
,ToDatePaidIndemnity            = cm.ToDatePaidIndemnityInOriginalCCY                   * cep.PerspectiveMultiplier
,ToDatePaidFees                 = cm.ToDatePaidFeesInOriginalCCY                        * cep.PerspectiveMultiplier
,ToDatePaidDefence              = cm.ToDatePaidDefenceInOriginalCCY                     * cep.PerspectiveMultiplier
,ToDateTaxAmount                = cm.ToDateTaxAmountInOriginalCCY                       * cep.PerspectiveMultiplier
,MovementOutstandingIndemnity   = cm.MovementOutstandingIndemnityInOriginalCCY          * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementOutstandingFees        = cm.MovementOutstandingFeesInOriginalCCY               * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementOutstandingDefence     = cm.MovementOutstandingDefenceInOriginalCCY            * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,ToDateOutstandingIndemnity     = cm.ToDateOutstandingIndemnityInOriginalCCY            * cep.PerspectiveMultiplier
,ToDateOutstandingFees          = cm.ToDateOutstandingFeesInOriginalCCY                 * cep.PerspectiveMultiplier
,ToDateOutstandingDefence       = cm.ToDateOutstandingDefenceInOriginalCCY              * cep.PerspectiveMultiplier
,MovementReceivedIndemnityNRR   = cm.MovementReceivedIndemnityNRRInOriginalCCY          * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementReceivedFeesNRR        = cm.MovementReceivedFeesNRRInOriginalCCY               * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,MovementReceivedDefenceNRR     = cm.MovementReceivedDefenceNRRInOriginalCCY            * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier
,ToDateReceivedIndemnityNRR     = cm.ToDateReceivedIndemnityNRRInOriginalCCY            * cep.PerspectiveMultiplier
,ToDateReceivedFeesNRR          = cm.ToDateReceivedFeesNRRInOriginalCCY                 * cep.PerspectiveMultiplier
,ToDateReceivedDefenceNRR       = cm.ToDateReceivedDefenceNRRInOriginalCCY              * cep.PerspectiveMultiplier
,ClaimTeamExaminer				= cm.ClaimTeamExaminer					
,FK_ClaimTeamExaminer			= cm.FK_ClaimTeamExaminer			            
,ActualOriginalCurrency 		= cm.ActualOriginalCurrency 														   --MultiCCY change --
,ActualOriginalAmount 			= cm.ActualOriginalAmount								* cep.PerspectiveMultiplier	   --MultiCCY change --
,EstimatedSettlementAmount 		= cm.EstimatedSettlementAmount 							* cep.PerspectiveMultiplier	   --MultiCCY change --
,ActualToSettlementExchangeRate	= cm.ActualToSettlementExchangeRate													   --MultiCCY change --				
,ActualOriginalAmountType		= cm.ActualOriginalAmountType															--MultiCCY change --				
,SignedLine						= cm.SignedLine

FROM 
#ClaimMovement cm
INNER JOIN
ODS.ClaimExposureEntityPerspective cep with (nolock) ON
cm.FK_ClaimExposure = cep.FK_ClaimExposure
INNER JOIN #x x 
		ON cep.FK_ClaimExposure = x.PK_ClaimExposure
CROSS JOIN
Red.ReportingCurrencyOverride rco with (nolock) 
WHERE
rco.ReportingCurrencyOverrideName = 'Original Currency'

UPDATE cm SET
	 FK_ClaimTeamExaminer				= 0			
	,ClaimTeamExaminer					= 'N/A'		
FROM
#ClaimMovement cm
WHERE ClaimTeamExaminer IS NULL

INSERT INTO Red.FactClaimMovement WITH(TABLOCK)
 (
    FK_ClaimMovement
    ,FK_EntityPerspective
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date     
	,FK_MovementCreationDate                                  
    ,FK_YOA                
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_ClaimCostCategory 
    ,FK_ClaimExposure
    ,FK_DevelopmentPeriod
    ,FK_SpecialCategoryCatastrophe
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,MovementNetPaymentAmount
	,MovementPaidIndemnity
    ,MovementPaidFees
    ,MovementPaidDefence
	,MovementTaxAmount
    ,ToDateNetPaymentAmount
	,ToDatePaidIndemnity
    ,ToDatePaidFees
    ,ToDatePaidDefence
	,ToDateTaxAmount
    ,MovementOutstandingIndemnity 
    ,MovementOutstandingFees
    ,MovementOutstandingDefence
    ,ToDateOutstandingIndemnity
    ,ToDateOutstandingFees
    ,ToDateOutstandingDefence
    ,MovementReceivedIndemnityNRR
    ,MovementReceivedFeesNRR
    ,MovementReceivedDefenceNRR
    ,ToDateReceivedIndemnityNRR
    ,ToDateReceivedFeesNRR
    ,ToDateReceivedDefenceNRR
	,ClaimTeamExaminer							
	,FK_ClaimTeamExaminer              
	,ActualOriginalCurrency 								  --MultiCCY change --
	,ActualOriginalAmount 									  --MultiCCY change --
	,EstimatedSettlementAmount 								  --MultiCCY change --
	,ActualToSettlementExchangeRate							  --MultiCCY change --							
	,ActualOriginalAmountType								  --MultiCCY change --
	,SignedLine

 )
SELECT
FK_ClaimMovement                = cm.FK_ClaimMovement
,FK_EntityPerspective           = cep.FK_EntityPerspective
,FK_Section                      = cm.FK_Section
,FK_Syndicate                   = cm.FK_Syndicate
,FK_SlipLineNumber              = cm.FK_SlipLineNumber
,FK_ShareType                   = cm.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = cm.FK_Date
,FK_MovementCreationDate		= cm.FK_MovementCreationDate
,FK_YOA                         = cm.FK_YOA
,FK_SettlementCurrency          = cm.FK_SettlementCurrency
,FK_OriginalCurrency            = cm.FK_OriginalCurrency
,FK_GQDTransactionType          = cm.FK_GQDTransactionType
,FK_ClaimCostCategory           = cm.FK_ClaimCostCategory
,FK_ClaimExposure               = cm.FK_ClaimExposure
,FK_DevelopmentPeriod           = cm.FK_DevelopmentPeriod
,FK_SpecialCategoryCatastrophe  = cm.FK_SpecialCategoryCatastrophe
,FK_TriFocus                    = cm.FK_TriFocus
,FK_CRMBroker                   = cm.FK_CRMBroker
,FK_Policy                      = cm.FK_Policy
,FK_QuoteFilter                 = cm.FK_QuoteFilter
,FK_HiddenStatusFilter          = cm.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= cm.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= cm.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= cm.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = cm.SpecialPurposeSyndicateApplies
,MovementNetPaymentAmount       = cm.MovementNetPaymentAmountInSettlementCCY            * cep.PerspectiveMultiplier
,MovementPaidIndemnity          = cm.MovementPaidIndemnityInSettlementCCY               * cep.PerspectiveMultiplier
,MovementPaidFees               = cm.MovementPaidFeesInSettlementCCY                    * cep.PerspectiveMultiplier
,MovementPaidDefence            = cm.MovementPaidDefenceInSettlementCCY                 * cep.PerspectiveMultiplier
,MovementTaxAmount              = cm.MovementTaxAmountInSettlementCCY                   * cep.PerspectiveMultiplier
,ToDateNetPaymentAmount         = cm.ToDateNetPaymentAmountInSettlementCCY              * cep.PerspectiveMultiplier
,ToDatePaidIndemnity            = cm.ToDatePaidIndemnityInSettlementCCY                 * cep.PerspectiveMultiplier
,ToDatePaidFees                 = cm.ToDatePaidFeesInSettlementCCY                      * cep.PerspectiveMultiplier
,ToDatePaidDefence              = cm.ToDatePaidDefenceInSettlementCCY                   * cep.PerspectiveMultiplier
,ToDateTaxAmount                = cm.ToDateTaxAmountInSettlementCCY                     * cep.PerspectiveMultiplier
,MovementOutstandingIndemnity   = cm.MovementOutstandingIndemnityInSettlementCCY        * cep.PerspectiveMultiplier
,MovementOutstandingFees        = cm.MovementOutstandingFeesInSettlementCCY             * cep.PerspectiveMultiplier
,MovementOutstandingDefence     = cm.MovementOutstandingDefenceInSettlementCCY          * cep.PerspectiveMultiplier
,ToDateOutstandingIndemnity     = cm.ToDateOutstandingIndemnityInSettlementCCY          * cep.PerspectiveMultiplier
,ToDateOutstandingFees          = cm.ToDateOutstandingFeesInSettlementCCY               * cep.PerspectiveMultiplier
,ToDateOutstandingDefence       = cm.ToDateOutstandingDefenceInSettlementCCY            * cep.PerspectiveMultiplier
,MovementReceivedIndemnityNRR   = cm.MovementReceivedIndemnityNRRInSettlementCCY        * cep.PerspectiveMultiplier
,MovementReceivedFeesNRR        = cm.MovementReceivedFeesNRRInSettlementCCY             * cep.PerspectiveMultiplier
,MovementReceivedDefenceNRR     = cm.MovementReceivedDefenceNRRInSettlementCCY          * cep.PerspectiveMultiplier
,ToDateReceivedIndemnityNRR     = cm.ToDateReceivedIndemnityNRRInSettlementCCY          * cep.PerspectiveMultiplier
,ToDateReceivedFeesNRR          = cm.ToDateReceivedFeesNRRInSettlementCCY               * cep.PerspectiveMultiplier
,ToDateReceivedDefenceNRR       = cm.ToDateReceivedDefenceNRRInSettlementCCY            * cep.PerspectiveMultiplier
,ClaimTeamExaminer				= cm.ClaimTeamExaminer					
,FK_ClaimTeamExaminer			= cm.FK_ClaimTeamExaminer		            
,ActualOriginalCurrency 		= cm.ActualOriginalCurrency 														   --MultiCCY change --
,ActualOriginalAmount 			= cm.ActualOriginalAmount								* cep.PerspectiveMultiplier	   --MultiCCY change --
,EstimatedSettlementAmount 		= cm.EstimatedSettlementAmount 							* cep.PerspectiveMultiplier	   --MultiCCY change --
,ActualToSettlementExchangeRate	= cm.ActualToSettlementExchangeRate													   --MultiCCY change --			
,ActualOriginalAmountType		= cm.ActualOriginalAmountType															--MultiCCY change --			
,SignedLine						= cm.SignedLine

FROM 
#ClaimMovement cm
INNER JOIN
ODS.ClaimExposureEntityPerspective cep with (nolock) ON
cm.FK_ClaimExposure = cep.FK_ClaimExposure
CROSS JOIN
Red.ReportingCurrencyOverride rco with (nolock) 
WHERE
rco.ReportingCurrencyOverrideName = 'Settlement Currency'



/*** SGP Enabled - Start ***/
-- Local Curency Rows
INSERT INTO Red.FactClaimMovement WITH(TABLOCK)
 (
    FK_ClaimMovement
    ,FK_EntityPerspective
    ,FK_Section
    ,FK_Syndicate
    ,FK_SlipLineNumber
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
	,FK_MovementCreationDate                                       
    ,FK_YOA                
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
	,FK_LocalCurrency
    ,FK_GQDTransactionType
    ,FK_ClaimCostCategory 
    ,FK_ClaimExposure
    ,FK_DevelopmentPeriod
    ,FK_SpecialCategoryCatastrophe
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,SpecialPurposeSyndicateApplies
    ,MovementNetPaymentAmount
	,MovementPaidIndemnity
    ,MovementPaidFees
    ,MovementPaidDefence
	,MovementTaxAmount
	,ToDateNetPaymentAmount
    ,ToDatePaidIndemnity
    ,ToDatePaidFees
    ,ToDatePaidDefence
	,ToDateTaxAmount
    ,MovementOutstandingIndemnity 
    ,MovementOutstandingFees
    ,MovementOutstandingDefence
    ,ToDateOutstandingIndemnity
    ,ToDateOutstandingFees
    ,ToDateOutstandingDefence
    ,MovementReceivedIndemnityNRR
    ,MovementReceivedFeesNRR
    ,MovementReceivedDefenceNRR
    ,ToDateReceivedIndemnityNRR
    ,ToDateReceivedFeesNRR
    ,ToDateReceivedDefenceNRR              
	,ActualOriginalCurrency 								  --MultiCCY change --
	,ActualOriginalAmount 									  --MultiCCY change --
	,EstimatedSettlementAmount 								  --MultiCCY change --
	,ActualToSettlementExchangeRate							  --MultiCCY change --	
	,ActualOriginalAmountType 								--MultiCCY change --
	,SignedLine

 )
SELECT
FK_ClaimMovement                = cm.FK_ClaimMovement
,FK_EntityPerspective           = cep.FK_EntityPerspective
,FK_Section                     = cm.FK_Section
,FK_Syndicate                   = cm.FK_Syndicate
,FK_SlipLineNumber              = cm.FK_SlipLineNumber
,FK_ShareType                   = cm.FK_ShareType
,FK_ReportingCurrencyOverride   = rco.PK_ReportingCurrencyOverride
,FK_Date                        = cm.FK_Date
,FK_MovementCreationDate		= cm.FK_MovementCreationDate
,FK_YOA                         = cm.FK_YOA
,FK_SettlementCurrency          = cm.FK_SettlementCurrency
,FK_OriginalCurrency            = cm.FK_OriginalCurrency
,FK_LocalCurrency				= cm.FK_LocalCurrency
,FK_GQDTransactionType          = cm.FK_GQDTransactionType
,FK_ClaimCostCategory           = cm.FK_ClaimCostCategory
,FK_ClaimExposure               = cm.FK_ClaimExposure
,FK_DevelopmentPeriod           = cm.FK_DevelopmentPeriod
,FK_SpecialCategoryCatastrophe  = cm.FK_SpecialCategoryCatastrophe
,FK_TriFocus                    = cm.FK_TriFocus
,FK_CRMBroker                   = cm.FK_CRMBroker
,FK_Policy                      = cm.FK_Policy
,FK_QuoteFilter                 = cm.FK_QuoteFilter
,FK_HiddenStatusFilter          = cm.FK_HiddenStatusFilter
,FK_UnderwritingPlatform		= cm.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= cm.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= cm.FK_ServiceCompany
,SpecialPurposeSyndicateApplies = cm.SpecialPurposeSyndicateApplies
,MovementNetPaymentAmount       = cm.MovementNetPaymentAmountInOriginalCCY              * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementPaidIndemnity          = cm.MovementPaidIndemnityInOriginalCCY                 * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementPaidFees               = cm.MovementPaidFeesInOriginalCCY                      * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementPaidDefence            = cm.MovementPaidDefenceInOriginalCCY                   * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementTaxAmount              = cm.MovementTaxamountInOriginalCCY                     * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,ToDateNetPaymentAmount         = cm.ToDateNetPaymentAmountInOriginalCCY                * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDatePaidIndemnity            = cm.ToDatePaidIndemnityInOriginalCCY                   * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDatePaidFees                 = cm.ToDatePaidFeesInOriginalCCY                        * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDatePaidDefence              = cm.ToDatePaidDefenceInOriginalCCY                     * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDateTaxAmount                = cm.ToDateTaxAmountInOriginalCCY                       * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,MovementOutstandingIndemnity   = cm.MovementOutstandingIndemnityInOriginalCCY          * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementOutstandingFees        = cm.MovementOutstandingFeesInOriginalCCY               * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementOutstandingDefence     = cm.MovementOutstandingDefenceInOriginalCCY            * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,ToDateOutstandingIndemnity     = cm.ToDateOutstandingIndemnityInOriginalCCY            * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDateOutstandingFees          = cm.ToDateOutstandingFeesInOriginalCCY                 * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDateOutstandingDefence       = cm.ToDateOutstandingDefenceInOriginalCCY              * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,MovementReceivedIndemnityNRR   = cm.MovementReceivedIndemnityNRRInOriginalCCY          * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementReceivedFeesNRR        = cm.MovementReceivedFeesNRRInOriginalCCY               * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,MovementReceivedDefenceNRR     = cm.MovementReceivedDefenceNRRInOriginalCCY            * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate
,ToDateReceivedIndemnityNRR     = cm.ToDateReceivedIndemnityNRRInOriginalCCY            * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDateReceivedFeesNRR          = cm.ToDateReceivedFeesNRRInOriginalCCY                 * cep.PerspectiveMultiplier										 / cm.OriginalCCYtoLocalCCYRate
,ToDateReceivedDefenceNRR       = cm.ToDateReceivedDefenceNRRInOriginalCCY              * cep.PerspectiveMultiplier			            
,ActualOriginalCurrency 		= cm.ActualOriginalCurrency 														   --MultiCCY change --
,ActualOriginalAmount 			= cm.ActualOriginalAmount								* cep.PerspectiveMultiplier	   --MultiCCY change --
,EstimatedSettlementAmount 		= cm.EstimatedSettlementAmount 							* cep.PerspectiveMultiplier	   --MultiCCY change --
,ActualToSettlementExchangeRate	= cm.ActualToSettlementExchangeRate													   --MultiCCY change --										
,ActualOriginalAmountType		= cm.ActualOriginalAmountType															--MultiCCY change --										
,SignedLine						= cm.SignedLine

FROM 
#ClaimMovement cm
INNER JOIN
ODS.ClaimExposureEntityPerspective cep with (nolock) ON
cm.FK_ClaimExposure = cep.FK_ClaimExposure
INNER JOIN #x x 
		ON cep.FK_ClaimExposure = x.PK_ClaimExposure
CROSS JOIN
Red.ReportingCurrencyOverride rco with (nolock) 
WHERE
rco.ReportingCurrencyOverrideName = 'Local Currency'
AND cm.FK_LocalCurrency <>0
/*** SGP Enabled - End ***/

---//// CREATE INDEX & ENABLE CONSTRAINTS
IF NOT EXISTS (
               SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
               WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactClaimMovement' AND CONSTRAINT_NAME = 'UQ_FactClaimMovement_LogicalKey' 
              )
BEGIN
    ALTER TABLE Red.FactClaimMovement
    ADD CONSTRAINT UQ_FactClaimMovement_LogicalKey
    UNIQUE
        (
            FK_ClaimMovement
            ,FK_EntityPerspective
            ,FK_Section
            ,FK_Syndicate
            ,FK_SlipLineNumber
            ,FK_ShareType
            ,FK_ReportingCurrencyOverride
        )
END


IF NOT EXISTS (
           select 1 from sys.indexes where name='FactClaimMovement_EntityPerspective'
           )
BEGIN
	CREATE NONCLUSTERED INDEX [FactClaimMovement_EntityPerspective] ON [Red].[FactClaimMovement]
	(
	[FK_EntityPerspective] ASC
	)
END


IF NOT EXISTS (
           select 1 from sys.indexes where name='FactClaimMovement_Combined'
           )
BEGIN
	CREATE NONCLUSTERED INDEX [FactClaimMovement_Combined] ON [Red].[FactClaimMovement]
	(
		[FK_ShareType] ASC,
		[FK_ReportingCurrencyOverride] ASC,
		[FK_YOA] ASC,
		[FK_SettlementCurrency] ASC,
		[FK_QuoteFilter] ASC
	)
	INCLUDE([FK_Section],[FK_EntityPerspective],[MovementTotalPaid],[MovementTotalOutstanding],[MovementTotalIncurred]) 
END


ALTER TABLE Red.FactClaimMovement CHECK CONSTRAINT ALL
 

IF (OBJECT_ID('tempdb..#ClaimMovementLineShareType') IS NOT NULL)                   DROP TABLE #ClaimMovementLineShareType
IF (OBJECT_ID('tempdb..#ClaimMovement') IS NOT NULL)                                DROP TABLE #ClaimMovement;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'ClaimMovementSection';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactClaimMovement';
