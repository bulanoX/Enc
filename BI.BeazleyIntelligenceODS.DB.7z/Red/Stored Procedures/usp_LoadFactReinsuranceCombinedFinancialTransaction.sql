﻿

CREATE PROCEDURE [Red].[usp_LoadFactReinsuranceCombinedFinancialTransaction]
AS

/*
 - The Combined financials contain:
 - LPSO premiums
 - LPSO claim paid amounts
 - LPSO RI transactions
 - Manual claim paid & outstanding
 - SCM claim outstanding only (paid is accounted for in LPSO claim paid)
 
 This is the measure group used to caclulate loss ratios and create triangles.
*/

SET NOCOUNT ON


/***********************************************************************************/
/*                Combined Load                                                    */
/***********************************************************************************/
TRUNCATE TABLE Red.FactReinsuranceCombinedFinancialTransaction;

--Does a minimally logged insert if this TABLOCK hint is provided, there is no clustered index,
----and the recovery model is not full*/
INSERT INTO Red.FactReinsuranceCombinedFinancialTransaction WITH (TABLOCK)
 (
     FK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction
    ,FK_EntityPerspective
    ,FK_AcquisitionCostBasis
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_ReinsuranceContract
    ,FK_TriFocus
    ,FK_CRMBroker
--    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,AllCategories
    --,AccountedPremium
    --,AccountedExternalAcquisitionCost
    --,AccountedInternalAcquisitionCost
    --,ClaimPaid
    --,ClaimOutstanding
    --,DelinkedPremium
    --,LPSOVATAmount
    ,ReinsurancePremiumNonFac
    ,ReinsuranceRecoveryNonFac
--    ,PartitionID
 )
/*LPSO values where there is no valid claim link - these use the SectionEntityPerspective for EntityPerspective key*/
SELECT
    FK_LPSOTransaction                  = l.PK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction     = NULL
    ,FK_EntityPerspective               = 0 --sep.FK_EntityPerspective
    ,FK_AcquisitionCostBasis            = 0 --lacb.FK_AcquisitionCostBasis    
    ,FK_Syndicate                       = ltlst.FK_Syndicate                          
    ,FK_ShareType                       = ltlst.FK_ShareType                            
    ,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride  
    ,FK_Date                            = l.FK_ProcessingPeriodDate
    ,FK_YOA                             = l.FK_YOA
    ,FK_SettlementCurrency              = l.FK_SettlementCurrency
    ,FK_OriginalCurrency                = l.FK_OriginalCurrency
    ,FK_GQDTransactionType              = l.FK_GQDTransactionType
    ,FK_ReinsuranceContract             = l.FK_ReinsuranceContract
    ,FK_TriFocus                        = 0 --s.FK_TriFocus
    ,FK_CRMBroker                       = 0 --s.FK_CRMBroker
    --,SpecialPurposeSyndicateApplies     = l.SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod               = l.FK_DevelopmentPeriod   
    ,FK_ClaimExposure                   = l.FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix= 0 --sccm.PK_SpecialCategoryCatastropheMatrix
    ,FK_Policy                          = 0 --s.FK_Policy
    ,FK_QuoteFilter                     = 0 --s.FK_QuoteFilter
    ,FK_HiddenStatusFilter              = 0 --s.FK_HiddenStatusFilter
    ,AllCategories                      = ((l.PositiveAmountInOriginalCCY --* ltlst.TotalPositiveLineMultiplier
								  + l.NegativeAmountInOriginalCCY ) --* ltlst.TotalNegativeLineMultiplier)
								  * CASE WHEN l.CategoryCode IN (1, 2, 3) THEN 1 --lacb.AcquisitionCostMultiplier
								    ELSE 1
								    END
								    )/
								    CASE rco.ReportingCurrencyOverrideName
									   WHEN 'Original Currency' THEN 1 
									   WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
								    END 
								    *
								    CASE WHEN l.CategoryCode IN (4,5) THEN - 1 ELSE 1 END --Reverse sign for claims amounts

    ,ReinsurancePremiumNonFac		    =  CASE WHEN l.CategoryCode IN (6,7) 
								    THEN
									   ((l.PositiveAmountInOriginalCCY --* ltlst.TotalPositiveLineMultiplier
									 + l.NegativeAmountInOriginalCCY ) --* ltlst.TotalNegativeLineMultiplier)
									   )/
									   CASE rco.ReportingCurrencyOverrideName
										  WHEN 'Original Currency' THEN 1 
										  WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
									   END                                       
								    END

    ,ReinsuranceRecoveryNonFac                 =  CASE WHEN l.CategoryCode IN (8,9) 
								    THEN
									   ((l.PositiveAmountInOriginalCCY -- * ltlst.TotalPositiveLineMultiplier
									 + l.NegativeAmountInOriginalCCY ) --* ltlst.TotalNegativeLineMultiplier)
									   )/
									   CASE rco.ReportingCurrencyOverrideName
										  WHEN 'Original Currency' THEN 1 
										  WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
									   END                                       
								    END
 
FROM ODS.ReinsuranceLPSOTransaction l
INNER JOIN ODS.ReinsuranceContractNonFac s 
    ON l.FK_ReinsuranceContract = s.PK_ReinsuranceContract
INNER JOIN staging.ReinsuranceLPSOTransactionLineShareType ltlst 
    ON l.PK_LPSOTransaction = ltlst.FK_LPSOTransaction
INNER JOIN Red.ReportingCurrencyOverride rco
    ON rco.ReportingCurrencyOverrideName IN ('Original Currency', 'Settlement Currency')
WHERE
    l.FK_ClaimExposure IS NULL;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactReinsuranceCombinedFinancialTransaction';