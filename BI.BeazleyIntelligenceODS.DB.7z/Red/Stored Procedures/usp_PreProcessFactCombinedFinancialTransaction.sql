﻿

CREATE PROCEDURE [Red].[usp_PreProcessFactCombinedFinancialTransaction]
AS

/*
 - The Combined financials contain:
 - LPSO premiums
 - LPSO claim paid amounts
 - LPSO RI transactions
 - Manual claim paid & outstanding
 - SCM claim outstanding only (paid is accounted for in LPSO claim paid)
 
 This is the measure group used to caclulate loss ratios and create triangles.
*/

SET NOCOUNT ON

/*Need to truncate these tables up front as they will be populated at various points during execution of the proc*/


--TRUNCATE TABLE Red.FactSpecialCategoryCatastropheMatrix
--DELETE FROM Red.SpecialCategoryCatastropheMatrix

/*Specials matrix
LPSO - cat special is a many-many, but in practice only a handful of transactions map to more than one special
If we model this as a regular many-many, then the intermediate measure group will have 100m+ rows. This is very 
ineffiecient. To avoid this, we are using a technique called many-to-many matrix compression, described in detail 
here: http://www.microsoft.com/en-us/download/details.aspx?id=137.

The gist of this is that we create a table containing a row for each unique combination of "groupings" of values (we
contcatenate the values to achieve this). This will become a new hidden dimension in the cube. Then we create a new
"fact" table which maps each row in the new dimension to the relevant values, essentially "decompressing" the matrix.
The original fact table then contains a reference to the new dimension, which in turn expands out into the facts.

This technique allows us to compress what would otherwise have been 100m+ rows into fewer than 20 rows in this particular
instance.
*/
IF OBJECT_ID('staging.LPSOSpecialCategoryCatastropheMatrix') IS NOT NULL
DROP TABLE staging.LPSOSpecialCategoryCatastropheMatrix

CREATE TABLE staging.LPSOSpecialCategoryCatastropheMatrix
(
    FK_LPSOTransaction                      bigint          NOT NULL
    ,GroupId                                varchar(255)    NOT NULL
    ,[AuditModifyDateTime]                  datetime2(7)    NULL
    ,[AuditCreateDateTime]                  datetime2(7)    DEFAULT (GETDATE()) NOT NULL
    ,[AuditModifyDetails]                   nvarchar(255)   NULL

)

/*Create a unique key for each "group" of specials. We'll join back through this
table later to get the correct surrogate key for each matrix record*/
INSERT INTO staging.LPSOSpecialCategoryCatastropheMatrix
(
    FK_LPSOTransaction
    ,GroupId
)
SELECT DISTINCT
FK_LPSOTransaction          =  s.FK_LPSOTransaction
,GroupId                    = (
                                SELECT 
                                CAST([FK_SpecialCategoryCatastrophe] as varchar(60)) AS [data()] 
                                FROM ODS.LPSOTransactionSpecialCategoryCatastrophe f
                                WHERE f.[FK_LPSOTransaction] = s.[FK_LPSOTransaction]
                                ORDER BY FK_SpecialCategoryCatastrophe
                                FOR XML PATH ('')
                               ) 
FROM ODS.LPSOTransactionSpecialCategoryCatastrophe s 
WHERE s.FK_SpecialCategoryCatastrophe <> 0
UNION ALL
SELECT
FK_LPSOTransaction          = s.FK_LPSOTransaction
,GroupId                    = CAST(s.FK_SpecialCategoryCatastrophe AS varchar(60))
FROM ODS.LPSOTransactionSpecialCategoryCatastrophe s 
WHERE s.FK_SpecialCategoryCatastrophe = 0
 
CREATE NONCLUSTERED INDEX IX_LPSOSpecialCategoryCatastropheMatrix   ON Staging.LPSOSpecialCategoryCatastropheMatrix (FK_LPSOTransaction)


/*Insert the dimension rows*/
MERGE Red.SpecialCategoryCatastropheMatrix AS TARGET

USING 
(
SELECT DISTINCT
GroupId                         = lm.GroupId
FROM
staging.LPSOSpecialCategoryCatastropheMatrix lm) AS SOURCE

ON TARGET.GroupId = SOURCE.GROUPId

WHEN MATCHED THEN

UPDATE SET 
  TARGET.AuditModifyDateTime    = GETDATE()
 ,TARGET.AuditModifyDetails     = 'Merge in [RED].[SpecialCategoryCatastropheMatrix] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     GroupId
	,AuditModifyDetails

)
VALUES
(
     SOURCE.GroupId
	,'New in [RED].[SpecialCategoryCatastropheMatrix] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

/*Create the fact rows*/

MERGE Red.FactSpecialCategoryCatastropheMatrix AS TARGET

USING (
SELECT DISTINCT
 FK_SpecialCategoryCatastropheMatrix    = sccm.PK_SpecialCategoryCatastropheMatrix
,FK_SpecialCategoryCatastrophe          = lscc.FK_SpecialCategoryCatastrophe
FROM
Red.SpecialCategoryCatastropheMatrix sccm
INNER JOIN
staging.LPSOSpecialCategoryCatastropheMatrix lsccm ON
sccm.GroupId = lsccm.GroupId
INNER JOIN
ODS.LPSOTransactionSpecialCategoryCatastrophe lscc ON
lsccm.FK_LPSOTransaction = lscc.FK_LPSOTransaction) AS SOURCE

 ON TARGET.FK_SpecialCategoryCatastropheMatrix = SOURCE.FK_SpecialCategoryCatastropheMatrix
AND TARGET.FK_SpecialCategoryCatastrophe       = SOURCE.FK_SpecialCategoryCatastrophe
WHEN MATCHED THEN

UPDATE SET 
  TARGET.FK_SpecialCategoryCatastropheMatrix = SOURCE.FK_SpecialCategoryCatastropheMatrix
 ,TARGET.FK_SpecialCategoryCatastrophe       = SOURCE.FK_SpecialCategoryCatastrophe
 ,TARGET.AuditModifyDateTime                 = GETDATE()
 ,TARGET.AuditModifyDetails                  = 'Merge in [RED].[FactSpecialCategoryCatastropheMatrix] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     FK_SpecialCategoryCatastropheMatrix
	,FK_SpecialCategoryCatastrophe
	,AuditModifyDetails

)
VALUES
(
     SOURCE.FK_SpecialCategoryCatastropheMatrix
	,SOURCE.FK_SpecialCategoryCatastrophe
	,'New in [RED].[FactSpecialCategoryCatastropheMatrix] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

/*Per discussion with Ellen Lombard on 10/10/2012, for the first phase
we will be showing US premium by accounting period. In a subsequent release we
will also be showing earned premium, but at this time unclear how and whether the calculation
below is correct*/

/*
/*Earnings
First we create a temp table to hold earned premium by month*/
IF OBJECT_ID('tempdb..#EarnedPremium') IS NOT NULL
DROP TABLE #EarnedPremium

CREATE TABLE #EarnedPremium
(
    FK_NonLloydsPremiumTransaction      bigint          NOT NULL
    ,FK_Date                            datetime        NOT NULL
    ,EarnedGrossPremium                 numeric(19,4)   NOT NULL
    ,EarnedNetExternalPremium           numeric(19,4)   NOT NULL
)

/*Hash table of all months, keyed on FirstDay*/
IF OBJECT_ID('tempdb..#Months') IS NOT NULL
DROP TABLE #Months

CREATE TABLE #Months
(
    FirstDay                datetime        NOT NULL
    ,LastDay                datetime        NOT NULL
    ,NumberOfDays           int             NOT NULL
    ,PRIMARY KEY (FirstDay)
)

INSERT INTO #Months
(
    FirstDay
    ,LastDay
    ,NumberOfDays
)
SELECT
FirstDay            = [Month]
,LastDay            = MAX([Date])
,NumberOfDays       = COUNT(1)
FROM
ODS.DimDate
WHERE
YEAR([Date]) <> 1753
GROUP BY
[Month]
ORDER BY
[Month]

/*Work out the earned premium by month*/
INSERT INTO #EarnedPremium
(
    FK_NonLloydsPremiumTransaction
    ,FK_Date
    ,EarnedGrossPremium
    ,EarnedNetExternalPremium
)
SELECT
FK_NonLloydsPremiumTransaction      = x.PK_NonLloydsPremiumTransaction
,FK_Date                            = Utility.udf_EarlierDate(x.FK_EffectiveToDate, m.LastDay)
,EarnedGrossPremium                 = (x.GrossPremium / x.DurationDays) --Premium per day
                                       *
                                      (
                                        x.DurationDays --Total duration
                                       - Utility.udf_GreaterOf(DATEDIFF(DAY, x.FK_EffectiveFromDate, m.FirstDay), 0) --Days from inception to first day, zero if negative
                                       - Utility.udf_GreaterOf(DATEDIFF(DAY, m.LastDay, x.FK_EffectiveToDate), 0) --Days from last day to expiry, zero if negative
                                      )
,EarnedNetExternalPremium           = (x.NetExternalPremium / x.DurationDays) --Premium per day
                                       *
                                      (
                                        x.DurationDays --Total duration
                                       - Utility.udf_GreaterOf(DATEDIFF(DAY, x.FK_EffectiveFromDate, m.FirstDay), 0) --Days from inception to first day, zero if negative
                                       - Utility.udf_GreaterOf(DATEDIFF(DAY, m.LastDay, x.FK_EffectiveToDate), 0) --Days from last day to expiry, zero if negative
                                      )

FROM
(
    SELECT
    PK_NonLloydsPremiumTransaction          = nlpt.PK_NonLloydsPremiumTransaction
    ,FK_EffectiveFromDate                   = nlpt.FK_EffectiveFromDate
    ,FK_EffectiveToDate                     = nlpt.FK_EffectiveToDate
    ,GrossPremium                           = ISNULL(nlpt.GrossPremiumInOriginalCCY, 0)
    ,NetExternalPremium                     = ISNULL(nlpt.GrossPremiumInOriginalCCY, 0) - ISNULL(nlpt.ExternalAcquisitionCostInOriginalCCY, 0)
    ,DurationDays                           = CAST(DATEDIFF(DAY, nlpt.FK_EffectiveFromDate, nlpt.FK_EffectiveToDate) + 1 AS float)
    FROM
    ODS.NonLloydsPremiumTransaction nlpt
    WHERE
    YEAR(nlpt.FK_EffectiveFromDate) <> 1753
    AND YEAR(nlpt.FK_EffectiveToDate) <> 1753
    AND nlpt.FK_EffectiveFromDate <= nlpt.FK_EffectiveToDate
) x
INNER JOIN
#Months m ON
m.FirstDay BETWEEN x.FK_EffectiveFromDate AND x.FK_EffectiveToDate --Month beginning falls between inception and expiry
OR m.LastDay BETWEEN x.FK_EffectiveFromDate AND x.FK_EffectiveToDate --Month ending falls between inception and expiry
OR x.FK_EffectiveFromDate BETWEEN m.FirstDay AND m.LastDay --In case of inception/expiry in the same month
*/

/*LPSO - share types and acquisition cost bases*/
IF (OBJECT_ID('staging.LPSOAcquisitionCostBasis') IS NOT NULL) DROP TABLE staging.LPSOAcquisitionCostBasis

CREATE TABLE staging.LPSOAcquisitionCostBasis
 (
     FK_LPSOTransaction             bigint              NOT NULL
    ,FK_AcquisitionCostBasis        bigint              NOT NULL
    ,AcquisitionCostMultiplier      numeric(19,12)      NOT NULL
    ,AuditModifyDateTime            datetime2(7)        NULL
    ,AuditCreateDateTime            datetime2(7)        DEFAULT (GETDATE()) NOT NULL
    ,AuditModifyDetails             nvarchar(255)       NULL

 )

TRUNCATE TABLE staging.LPSOAcquisitionCostBasis

INSERT INTO staging.LPSOAcquisitionCostBasis
(
     FK_LPSOTransaction
    ,FK_AcquisitionCostBasis
    ,AcquisitionCostMultiplier
)

SELECT
FK_LPSOTransaction          = l.PK_LPSOTransaction     
,FK_AcquisitionCostBasis     = acb.PK_AcquisitionCostBasis
,AcquisitionCostMultiplier   = CASE acb.AcquisitionCostBasisName
                                  WHEN 'Gross Of Acquisition Cost' THEN 1
                                  WHEN 'Net Of All Acquisition Cost' THEN 1 - l.ExternalAcquisitionCostMultiplier - l.InternalAcquisitionCostMultiplier
                                  WHEN 'Net Of External Acquisition Cost' THEN 1 - l.ExternalAcquisitionCostMultiplier
                              END                                     
FROM ODS.LPSOTransaction l
INNER JOIN 
ODS.Section s ON 
l.FK_Section = s.PK_Section
CROSS JOIN 
Red.AcquisitionCostBasis acb

CREATE INDEX IDX_Stg_LPSOAcquisitionCostBasis ON staging.LPSOAcquisitionCostBasis (FK_LPSOTransaction) INCLUDE (FK_AcquisitionCostBasis)

/***********************************************************************************/
/*                Share Type (LPSO Transaction Line Level)                         */
/***********************************************************************************/
IF (OBJECT_ID('Staging.LPSOTransactionLineShareType') IS NOT NULL) DROP TABLE Staging.LPSOTransactionLineShareType

CREATE TABLE Staging.LPSOTransactionLineShareType
 (
    FK_LPSOTransaction							bigint              NOT NULL
   ,FK_Syndicate								bigint              NULL
   ,FK_ShareType								bigint              NOT NULL
   ,TotalPositiveLineMultiplier					numeric(19,12)      NOT NULL
   ,TotalNegativeLineMultiplier					numeric(19,12)      NOT NULL
   ,TotalPositiveVATLineMultiplier				numeric(19,12)      NOT NULL
   ,TotalNegativeVATLineMultiplier				numeric(19,12)      NOT NULL
   ,TotalPositiveDelinkedLineMultiplier			numeric(19,12)      NOT NULL
   ,TotalNegativeDelinkedLineMultiplier			numeric(19,12)      NOT NULL
   ,TotalPositiveIPTOverseasTaxLineMultiplier	numeric(19,12)      NOT NULL
   ,TotalNegativeIPTOverseasTaxLineMultiplier	numeric(19,12)      NOT NULL
   ,TotalPositiveIPTUKTaxLineMultiplier			numeric(19,12)      NOT NULL
   ,TotalNegativeIPTUKTaxLineMultiplier			numeric(19,12)      NOT NULL
   ,TotalPositiveExcIPTOverseasTaxLineMultiplier	numeric(19,12)      NOT NULL
   ,TotalNegativeExcIPTOverseasTaxLineMultiplier	numeric(19,12)      NOT NULL
   ,[AuditModifyDateTime]                       datetime2(7)  NULL
   ,[AuditCreateDateTime]                       datetime2(7)  DEFAULT (GETDATE()) NOT NULL
   ,[AuditModifyDetails]                        nvarchar(255) NULL

 )

TRUNCATE TABLE Staging.LPSOTransactionLineShareType

/*We're not going to have total order / slip order amounts in the combined financial transaction
measure group, as this would greatly inflate row counts*/

--INSERT INTO #LPSOTransactionLineShareType
-- (
--    FK_LPSOTransaction
--   ,FK_ShareType
--   ,TotalPositiveLineMultiplier
--   ,TotalNegativeLineMultiplier
--   ,TotalPositiveVATLineMultiplier
--   ,TotalNegativeVATLineMultiplier
--   ,TotalPositiveDelinkedLineMultiplier
--   ,TotalNegativeDelinkedLineMultiplier
-- )

--SELECT
--    FK_LPSOTransaction                      = lpsot.PK_LPSOTransaction                   
--   ,FK_ShareType                            = sharet.PK_ShareType                 
--   ,TotalPositiveLineMultiplier             = 1                                     
--   ,TotalNegativeLineMultiplier             = 1                                     
--   ,TotalPositiveVATLineMultiplier          = 1                                    
--   ,TotalNegativeVATLineMultiplier          = 1                                     
--  ,TotalPositiveDelinkedLineMultiplier      = 1                                   
--  ,TotalNegativeDelinkedLineMultiplier      = 1                                   
--FROM ODS.LPSOTransaction lpsot

--INNER JOIN ODS.Section pol 
--ON lpsot.FK_Section = pol.PK_Section

--CROSS JOIN Red.ShareType sharet

--WHERE sharet.ShareTypeName = 'Total Order'

INSERT INTO Staging.LPSOTransactionLineShareType
 (
    FK_LPSOTransaction
   ,FK_Syndicate
   ,FK_ShareType
   ,TotalPositiveLineMultiplier
   ,TotalNegativeLineMultiplier
   ,TotalPositiveVATLineMultiplier
   ,TotalNegativeVATLineMultiplier
   ,TotalPositiveDelinkedLineMultiplier
   ,TotalNegativeDelinkedLineMultiplier
   ,TotalPositiveIPTOverseasTaxLineMultiplier	
   ,TotalNegativeIPTOverseasTaxLineMultiplier	
   ,TotalPositiveIPTUKTaxLineMultiplier		
   ,TotalNegativeIPTUKTaxLineMultiplier	
   ,TotalPositiveExcIPTOverseasTaxLineMultiplier
   ,TotalNegativeExcIPTOverseasTaxLineMultiplier   
 )
 
SELECT
FK_LPSOTransaction							= l.PK_LPSOTransaction               
,FK_Syndicate								= ltl.FK_Syndicate                    
,FK_ShareType								= st.PK_ShareType                       
,TotalPositiveLineMultiplier				= s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveLineMultiplier           
,TotalNegativeLineMultiplier				= s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeLineMultiplier            
,TotalPositiveVATLineMultiplier				= s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveVATLineMultiplier        
,TotalNegativeVATLineMultiplier				= s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeVATLineMultiplier        
,TotalPositiveDelinkedLineMultiplier		= s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveDelinkedLineMultiplier   
,TotalNegativeDelinkedLineMultiplier		= s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeDelinkedLineMultiplier  
,TotalPositiveIPTOverseasTaxLineMultiplier	= s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveIPTOverseasTaxLineMultiplier   
,TotalNegativeIPTOverseasTaxLineMultiplier	= s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeIPTOverseasTaxLineMultiplier 
,TotalPositiveIPTUKTaxLineMultiplier		= s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveIPTUKTaxLineMultiplier   
,TotalNegativeIPTUKTaxLineMultiplier		= s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeIPTUKTaxLineMultiplier  
,TotalPositiveExcIPTOverseasTaxLineMultiplier = s.WrittenIfNotSignedOrderMultiplier * ltl.PositiveExcIPTOverseasTaxLineMultiplier  
,TotalNegativeExcIPTOverseasTaxLineMultiplier = s.WrittenIfNotSignedOrderMultiplier * ltl.NegativeExcIPTOverseasTaxLineMultiplier  
FROM 
ODS.LPSOTransaction l
INNER JOIN ODS.Section s ON 
l.FK_Section = s.PK_Section
INNER JOIN ODS.LPSOTransactionLine ltl ON 
l.PK_LPSOTransaction = ltl.FK_LPSOTransaction
CROSS JOIN 
Red.ShareType st
WHERE 
st.ShareTypeName = 'Beazley Share'

CREATE NONCLUSTERED INDEX IX_LPSOTransactionLineShareType ON Staging.LPSOTransactionLineShareType (FK_LPSOTransaction)

TRUNCATE TABLE Red.FactCombinedFinancialTransaction
 
EXEC utility.usp_PartitionTableOnScheme 
 	 @SchemaName		= 'Red'  
	,@TableName			= 'FactCombinedFinancialTransaction' 
	,@PartitionScheme	= 'PS_FCFT';


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactSpecialCategoryCatastropheMatrix';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'SpecialCategoryCatastropheMatrix';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'LPSOAcquisitionCostBasis';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'LPSOTransactionLineShareType';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Staging', @TableName = 'LPSOSpecialCategoryCatastropheMatrix';

