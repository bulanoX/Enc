﻿

CREATE PROCEDURE [Red].[usp_LoadFactUltimateLossRatio]
AS

SET NOCOUNT ON


DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
FROM		Red.FactUltimateLossRatio

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');


IF OBJECT_ID('tempdb..#UltimateLossRatioMovement') IS NOT NULL
DROP TABLE #UltimateLossRatioMovement

CREATE TABLE #UltimateLossRatioMovement
(
     GroupId                                bigint          NOT NULL
    ,DevelopmentMonth                       int             NOT NULL
    ,FK_YOA                                 bigint          NOT NULL
    ,FK_Syndicate                           bigint          NOT NULL
    ,FK_TriFocus                            bigint          NOT NULL
    ,FK_SettlementCurrency                  bigint          NOT NULL
    ,FK_SpecialCategoryCatastrophe          bigint          NOT NULL
    ,FK_SpecialCategorySection              bigint          NOT NULL
    ,UltimatePremiumPosition                numeric(19,4)   NULL
    ,UltimateIncurredPosition               numeric(19,4)   NULL
    ,UltimateIncurredMovement               numeric(19,4)   NULL
    ,UltimatePremiumMovement                numeric(19,4)   NULL
    PRIMARY KEY (GroupId, DevelopmentMonth)
)

/*The group IDs have already been generated based on the compound key (excluding development period)
,so we don't need to worry about joining on all the fields, we can just use group id*/

INSERT INTO #UltimateLossRatioMovement
(
             GroupId
            ,DevelopmentMonth
            ,FK_YOA
            ,FK_Syndicate
            ,FK_TriFocus
            ,FK_SettlementCurrency
            ,FK_SpecialCategoryCatastrophe
            ,FK_SpecialCategorySection
            ,UltimatePremiumPosition
            ,UltimateIncurredPosition
)
SELECT
             GroupId                            = ulr.GroupId
            ,DevelopmentMonth                   = dp.DevelopmentMonth
            ,FK_YOA                             = ulr.FK_YOA
            ,FK_Syndicate                       = ulr.FK_Syndicate
            ,FK_TriFocus                        = ulr.FK_TriFocus
            ,FK_SettlementCurrency              = ulr.FK_SettlementCurrency
            ,FK_SpecialCategoryCatastrophe      = ulr.FK_SpecialCategoryCatastrophe
            ,FK_SpecialCategorySection          = ulr.FK_SpecialCategorySection
            ,UltimatePremiumPosition            = ulr.GrossUltimatePremiumPosition
            ,UltimateIncurredPosition           = ulr.GrossUltimateIncurredPosition
FROM        ODS.UltimateLossRatio ulr
INNER JOIN  ODS.DevelopmentPeriod dp 
        ON  ulr.FK_DevelopmentPeriod = dp.PK_DevelopmentPeriod

/*

Now the rules are as follows:
    If a value has been entered for a given period, that value is considered to be in effect 
    for that month and the next two months, unless an intervening value has been entered
    After the value stops being in effect, we need to work out the movement. This may involve creating
    a new (reversal) record if there is no future value for that group
*/

/*First we insert records for all the periods we want, if they don't already exist*/
INSERT INTO #UltimateLossRatioMovement
(
             GroupId
            ,DevelopmentMonth
            ,FK_YOA
            ,FK_Syndicate
            ,FK_TriFocus
            ,FK_SettlementCurrency
            ,FK_SpecialCategoryCatastrophe
            ,FK_SpecialCategorySection
            ,UltimatePremiumPosition
            ,UltimateIncurredPosition
)
SELECT DISTINCT
             GroupId                            = ulrm.GroupId
            ,DevelopmentMonth                   = dm_future.DevelopmentMonth
            ,FK_YOA                             = ulrm.FK_YOA
            ,FK_Syndicate                       = ulrm.FK_Syndicate
            ,FK_TriFocus                        = ulrm.FK_TriFocus
            ,FK_SettlementCurrency              = ulrm.FK_SettlementCurrency
            ,FK_SpecialCategoryCatastrophe      = ulrm.FK_SpecialCategoryCatastrophe
            ,FK_SpecialCategorySection          = ulrm.FK_SpecialCategorySection
            ,UltimatePremiumPosition            = NULL
            ,UltimateIncurredPosition           = NULL
FROM        #UltimateLossRatioMovement ulrm
INNER JOIN  ODS.DevelopmentPeriod dm_future 
        ON  dm_future.DevelopmentMonth > ulrm.DevelopmentMonth
       AND  dm_future.DevelopmentMonth <= ulrm.DevelopmentMonth + 2
WHERE 
        NOT EXISTS
        (
            SELECT  1 
            FROM    #UltimateLossRatioMovement ulrm_future
            WHERE   ulrm_future.GroupId = ulrm.GroupId
            AND     ulrm_future.DevelopmentMonth = dm_future.DevelopmentMonth
        )


/*Now populate the nulls recursively*/
;WITH CTEValuesInEffect AS
(
    SELECT
             GroupId                        = ulrm.GroupId
            ,DevelopmentMonth               = ulrm.DevelopmentMonth
            ,UltimatePremiumPosition        = ulrm.UltimatePremiumPosition
            ,UltimateIncurredPosition       = ulrm.UltimateIncurredPosition
    FROM    #UltimateLossRatioMovement ulrm
    WHERE   ulrm.UltimatePremiumPosition IS NOT NULL
    UNION ALL
    SELECT
                 GroupId                        = ulrm.GroupId
                ,DevelopmentMonth               = ulrm.DevelopmentMonth
                ,UltimatePremiumPosition        = cte.UltimatePremiumPosition
                ,UltimateIncurredPosition       = cte.UltimateIncurredPosition
    FROM        CTEValuesInEffect cte
    INNER JOIN  #UltimateLossRatioMovement ulrm 
    ON          cte.GroupId = ulrm.GroupId 
    AND         cte.DevelopmentMonth + 1 = ulrm.DevelopmentMonth
    AND         ulrm.UltimatePremiumPosition IS NULL
)
UPDATE ulrm 
SET
             UltimatePremiumPosition        = cte.UltimatePremiumPosition
            ,UltimateIncurredPosition       = cte.UltimateIncurredPosition
FROM        #UltimateLossRatioMovement ulrm
INNER JOIN  CTEValuesInEffect cte 
ON          ulrm.GroupId = cte.GroupId
AND         ulrm.DevelopmentMonth = cte.DevelopmentMonth
OPTION      (MAXRECURSION 0)

/*Now create reversal records*/
INSERT INTO #UltimateLossRatioMovement
(
         GroupId
        ,DevelopmentMonth
        ,FK_YOA
        ,FK_Syndicate
        ,FK_TriFocus
        ,FK_SettlementCurrency
        ,FK_SpecialCategoryCatastrophe
        ,FK_SpecialCategorySection
        ,UltimatePremiumPosition
        ,UltimateIncurredPosition
)
SELECT
         GroupId                            = ulrm.GroupId
        ,DevelopmentMonth                   = ulrm.DevelopmentMonth + 1
        ,FK_YOA                             = ulrm.FK_YOA
        ,FK_Syndicate                       = ulrm.FK_Syndicate
        ,FK_TriFocus                        = ulrm.FK_TriFocus
        ,FK_SettlementCurrency              = ulrm.FK_SettlementCurrency
        ,FK_SpecialCategoryCatastrophe      = ulrm.FK_SpecialCategoryCatastrophe
        ,FK_SpecialCategorySection          = ulrm.FK_SpecialCategorySection
        ,UltimatePremiumPosition            = 0
        ,UltimateIncurredPosition           = 0
FROM    #UltimateLossRatioMovement ulrm
WHERE 
/*There are no future ULRs for this group*/
    NOT EXISTS
    (
        SELECT  1
        FROM    #UltimateLossRatioMovement ulrm_future 
        WHERE   ulrm_future.GroupId = ulrm.GroupId
        AND     ulrm_future.DevelopmentMonth = ulrm.DevelopmentMonth + 1
    )
/*But there are some ULR's in future for this YOA*/
    AND EXISTS
    (
        SELECT  1
        FROM    #UltimateLossRatioMovement ulrm_future
        WHERE   ulrm_future.FK_YOA = ulrm.FK_YOA
        AND     ulrm_future.DevelopmentMonth > ulrm.DevelopmentMonth
    )


/*Work out the movements*/
UPDATE ulrm 
SET
 UltimatePremiumMovement    = ulrm.UltimatePremiumPosition - ISNULL(ulrm_previous.UltimatePremiumPosition, 0)
,UltimateIncurredMovement   = ulrm.UltimateIncurredPosition - ISNULL(ulrm_previous.UltimateIncurredPosition, 0)
FROM            #UltimateLossRatioMovement ulrm
LEFT OUTER JOIN #UltimateLossRatioMovement ulrm_previous 
ON              ulrm.GroupId = ulrm_previous.GroupId
AND             ulrm.DevelopmentMonth = ulrm_previous.DevelopmentMonth + 1


DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.DevelopmentPeriod x
ON            f.FK_DevelopmentPeriod = x.PK_DevelopmentPeriod
WHERE         PK_DevelopmentPeriod IS NULL AND f.FK_DevelopmentPeriod IS NOT NULL

 
DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.SpecialCategoryCatastrophe x
ON            f.FK_SpecialCategoryCatastrophe = x.PK_SpecialCategoryCatastrophe
WHERE         PK_SpecialCategoryCatastrophe IS NULL AND f.FK_SpecialCategoryCatastrophe IS NOT NULL


DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.SpecialCategorySection x
ON            f.FK_SpecialCategorySection = x.PK_SpecialCategorySection
WHERE         PK_SpecialCategorySection IS NULL AND f.FK_SpecialCategorySection IS NOT NULL


DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.Syndicate x
ON            f.FK_Syndicate = x.PK_Syndicate
WHERE         PK_Syndicate IS NULL AND f.FK_Syndicate IS NOT NULL


DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.TriFocus x
ON            f.FK_TriFocus = x.PK_TriFocus
WHERE         PK_TriFocus IS NULL AND f.FK_TriFocus IS NOT NULL


DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.YOA x
ON            f.FK_YOA = x.PK_YOA
WHERE         PK_YOA IS NULL AND f.FK_YOA IS NOT NULL

DELETE        f
FROM          Red.FactUltimateLossRatio f
LEFT JOIN     Ods.UltimateLossRatio x
ON            f.GroupId = x.GroupId
				and  f.FK_DevelopmentPeriod = x.FK_DevelopmentPeriod
				and f.FK_TriFocus = x.FK_TriFocus
				and f.FK_Syndicate = x.FK_Syndicate
				and f.FK_SettlementCurrency = x.FK_SettlementCurrency
WHERE       x.GroupID is null AND f.GroupId is not null

;MERGE	Red.FactUltimateLossRatio	AS TARGET
		USING	
		(
            SELECT
                    GroupId                             = ulr.GroupId
                    ,FK_AcquisitionCostBasis            = acb.PK_AcquisitionCostBasis
                    ,FK_Date                            = dt.PK_Date
                    ,FK_DevelopmentPeriod               = dp.PK_DevelopmentPeriod
                    ,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride
                    ,FK_EntityPerspective               = ep.PK_EntityPerspective
                    ,FK_SettlementCurrency              = ulr.FK_SettlementCurrency
                    ,FK_ShareType                       = st.PK_ShareType
                    ,FK_SpecialCategoryCatastrophe      = ulr.FK_SpecialCategoryCatastrophe
                    ,FK_SpecialCategorySection          = ulr.FK_SpecialCategorySection
                    ,FK_Syndicate                       = ulr.FK_Syndicate
                    ,FK_TriFocus                        = ulr.FK_TriFocus
                    ,FK_YOA                             = ulr.FK_YOA
                    ,FK_QuoteFilter                     = qf.PK_QuoteFilter
                    ,FK_HiddenStatusFilter              = hsf.PK_HiddenStatusFilter
                    ,UltimatePremiumMovement            = ulr.UltimatePremiumMovement
                    ,UltimateIncurredMovement           = ulr.UltimateIncurredMovement
            
            FROM    #UltimateLossRatioMovement ulr
            
            INNER JOIN ODS.DevelopmentPeriod dp 
                    ON ulr.DevelopmentMonth = dp.DevelopmentMonth

            INNER JOIN Red.ReportingCurrencyOverride rco 
                    ON rco.ReportingCurrencyOverrideName = 'Settlement Currency'

            INNER JOIN Red.ShareType st 
                    ON st.ShareTypeName = 'Beazley Share'

            INNER JOIN Red.AcquisitionCostBasis acb 
                    ON acb.AcquisitionCostBasisName = 'Net Of All Acquisition Cost'

            INNER JOIN ODS.YOA yoa 
                    ON ulr.FK_YOA = yoa.PK_YOA

            INNER JOIN ODS.DimDate dt 
                    ON dt.PK_Date = DATEADD(MONTH, ulr.DevelopmentMonth - 1, yoa.FirstDate)

            INNER JOIN ODS.QuoteFilter qf 
                    ON qf.QuoteFilter = 'Policy'

            INNER JOIN ODS.HiddenStatusFilter hsf 
                    ON hsf.HiddenStatusFilter = 'Show Regular Statuses'

            INNER JOIN ODS.EntityPerspective ep 
                    ON --ep.EntityPerspective IN ('Eurobase View', 'Syndicate View') --Don't show ULRs in combined view, as BICI ULRs are at 75%
                       ep.EntityPerspective = 'Eurobase View'

            WHERE
                    (ulr.UltimateIncurredMovement <> 0 OR ulr.UltimatePremiumMovement <> 0)
            AND 
                    (yoa.AuditModifyDateTime > @LastAuditDate OR yoa.AuditCreateDateTime > @LastAuditDate)
					
        )
		AS SOURCE

        ON		    TARGET.GroupId                          = SOURCE.GroupId                   
				AND	TARGET.FK_DevelopmentPeriod             = SOURCE.FK_DevelopmentPeriod         
				AND	TARGET.FK_ShareType                     = SOURCE.FK_ShareType       
				AND	TARGET.FK_ReportingCurrencyOverride     = SOURCE.FK_ReportingCurrencyOverride                 
				AND	TARGET.FK_AcquisitionCostBasis          = SOURCE.FK_AcquisitionCostBasis                 
				AND	TARGET.FK_EntityPerspective             = SOURCE.FK_EntityPerspective 

WHEN	MATCHED	THEN
	    UPDATE	
	    SET  TARGET.GroupId                                 = SOURCE.GroupId
            ,TARGET.FK_AcquisitionCostBasis                 = SOURCE.FK_AcquisitionCostBasis
            ,TARGET.FK_Date                                 = SOURCE.FK_Date
            ,TARGET.FK_DevelopmentPeriod                    = SOURCE.FK_DevelopmentPeriod
            ,TARGET.FK_ReportingCurrencyOverride            = SOURCE.FK_ReportingCurrencyOverride
            ,TARGET.FK_EntityPerspective                    = SOURCE.FK_EntityPerspective
            ,TARGET.FK_SettlementCurrency                   = SOURCE.FK_SettlementCurrency
            ,TARGET.FK_ShareType                            = SOURCE.FK_ShareType
            ,TARGET.FK_SpecialCategoryCatastrophe           = SOURCE.FK_SpecialCategoryCatastrophe
            ,TARGET.FK_SpecialCategorySection               = SOURCE.FK_SpecialCategorySection
            ,TARGET.FK_Syndicate                            = SOURCE.FK_Syndicate
            ,TARGET.FK_TriFocus                             = SOURCE.FK_TriFocus
            ,TARGET.FK_YOA                                  = SOURCE.FK_YOA
            ,TARGET.FK_QuoteFilter                          = SOURCE.FK_QuoteFilter
            ,TARGET.FK_HiddenStatusFilter                   = SOURCE.FK_HiddenStatusFilter
            ,TARGET.UltimatePremiumMovement                 = SOURCE.UltimatePremiumMovement
            ,TARGET.UltimateIncurredMovement                = SOURCE.UltimateIncurredMovement
		    ,TARGET.AuditModifyDateTime						= GETDATE()						
		    ,TARGET.AuditModifyDetails						= 'Merge in Red.usp_LoadFactUltimateLossRatio' 

WHEN    NOT MATCHED BY TARGET THEN
		INSERT
		(       
			 GroupId
            ,FK_AcquisitionCostBasis
            ,FK_Date
            ,FK_DevelopmentPeriod
            ,FK_ReportingCurrencyOverride
            ,FK_EntityPerspective
            ,FK_SettlementCurrency
            ,FK_ShareType
            ,FK_SpecialCategoryCatastrophe
            ,FK_SpecialCategorySection
            ,FK_Syndicate
            ,FK_TriFocus
            ,FK_YOA
            ,FK_QuoteFilter
            ,FK_HiddenStatusFilter
            ,UltimatePremiumMovement
            ,UltimateIncurredMovement
			,AuditCreateDateTime
			,AuditModifyDetails
		)
		VALUES
		(
			 SOURCE.GroupId
            ,SOURCE.FK_AcquisitionCostBasis
            ,SOURCE.FK_Date
            ,SOURCE.FK_DevelopmentPeriod
            ,SOURCE.FK_ReportingCurrencyOverride
            ,SOURCE.FK_EntityPerspective
            ,SOURCE.FK_SettlementCurrency
            ,SOURCE.FK_ShareType
            ,SOURCE.FK_SpecialCategoryCatastrophe
            ,SOURCE.FK_SpecialCategorySection
            ,SOURCE.FK_Syndicate
            ,SOURCE.FK_TriFocus
            ,SOURCE.FK_YOA
            ,SOURCE.FK_QuoteFilter
            ,SOURCE.FK_HiddenStatusFilter
            ,SOURCE.UltimatePremiumMovement
            ,SOURCE.UltimateIncurredMovement
			,GETDATE()						
			,'New add in Red.usp_LoadFactUltimateLossRatio' 
	   )
;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'FactUltimateLossRatio';

