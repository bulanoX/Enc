﻿
CREATE PROCEDURE [Red].[usp_LoadFactCombinedFinancialTransaction]
AS


DECLARE @GUID UNIQUEIDENTIFIER 
SET		@GUID = (SELECT MAX(PartitionGUID) FROM staging.PartitionMap WHERE PartitionID=1 and storedProcedureId = 2)

/*
 - The Combined financials contain:
 - LPSO premiums
 - LPSO claim paid amounts
 - LPSO RI transactions
 - Manual claim paid & outstanding
 - SCM claim outstanding only (paid is accounted for in LPSO claim paid)
 
 This is the measure group used to caclulate loss ratios and create triangles.
*/

SET NOCOUNT ON

/*Need to truncate these tables up front as they will be populated at various points during execution of the proc*/

--TRUNCATE TABLE Red.FactCombinedFinancialTransaction
--TRUNCATE TABLE Red.FactSpecialCategoryCatastropheMatrix
--DELETE FROM Red.SpecialCategoryCatastropheMatrix
 
IF (OBJECT_ID('staging.FactCombinedFinancialTransaction') IS NOT NULL) BEGIN DROP TABLE staging.FactCombinedFinancialTransaction END

CREATE TABLE staging.FactCombinedFinancialTransaction(
	[FK_AcquisitionCostBasis]				[bigint] NOT NULL,
	[FK_EntityPerspective]					[bigint] NOT NULL,
	[FK_ShareType]							[bigint] NOT NULL,
	[FK_Syndicate]							[bigint] NOT NULL,
	[FK_ReportingCurrencyOverride]			[bigint] NOT NULL,
	[FK_Date]								[datetime] NOT NULL,
	[FK_YOA]								[bigint] NOT NULL,
	[FK_SettlementCurrency]					[bigint] NOT NULL,
	[FK_OriginalCurrency]					[bigint] NOT NULL,
	[FK_LocalCurrency]						[bigint] NOT NULL DEFAULT 0,
	[FK_Section]							[bigint] NOT NULL,
	[FK_DevelopmentPeriod]					[bigint] NOT NULL,
	[FK_TriFocus]							[bigint] NOT NULL,
	[FK_ClaimExposure]						[bigint] NULL,
	[FK_LPSOTransaction]					[bigint] NULL,
	[FK_NonLLoydsPremiumTransaction]		[bigint] NULL,
	[FK_GQDTransactionType]					[bigint] NOT NULL,
	[FK_SpecialCategoryCatastropheMatrix]   [bigint] NOT NULL,
	[FK_Policy]								[bigint] NOT NULL,
	[FK_HiddenStatusFilter]					[bigint] NOT NULL,
	[FK_QuoteFilter]						[bigint] NOT NULL,
	[FK_CRMBroker]							[bigint] NOT NULL,
	[FK_UnderwritingPlatform]				[bigint] NOT NULL,
	[FK_InternalWrittenBinderStatus]		[bigint] NOT NULL,
	[AllCategories]							[numeric](19, 4) NULL,
	[AccountedPremium]						[numeric](19, 4) NULL,
	[AccountedPremiumExcIPTOverseasTax]		[numeric](19, 4) NULL,
	[AccountedExternalAcquisitionCost]		[numeric](19, 4) NULL,
	[AccountedInternalAcquisitionCost]		[numeric](19, 4) NULL,
	[DelinkedPremium]						[numeric](19, 4) NULL,
	[ClaimPaid]								[numeric](19, 4) NULL,
	[ClaimOutstanding]						[numeric](19, 4) NULL,
	[LPSOVATAmount]							[numeric](19, 4) NULL,
	[IPTOverseasTax]                        [numeric](38, 12) NULL,
	[IPTUKTax]                              [numeric](38, 12) NULL,
	[SpecialPurposeSyndicateApplies]		[bit] NOT NULL,
	[ClaimIncurred]							AS (case when [ClaimPaid] IS NULL AND [ClaimOutstanding] IS NULL then NULL else isnull([ClaimPaid],(0))+isnull([ClaimOutstanding],(0)) end),
    [ReinsurancePremiumFac]					[numeric](19, 4) NULL,
    [ReinsuranceRecoveryFac]				[numeric](19, 4) NULL,
	PartitionID								[int] NULL,
	ClaimTeamExaminer						[varchar](255) NULL,
	FK_ClaimTeamExaminer					[bigint] NULL,
	[FK_ServiceCompany]						[bigint] NOT NULL,
	[SigningsPosition]                      [numeric](19,4) NULL,
    [CashDue]                               [numeric] (19, 4) NULL,
    [CashPosition]                          [numeric] (19, 4) NULL
) ON [PRIMARY]



/***********************************************************************************/
/*                Combined Load                                                 */
/***********************************************************************************/


TRUNCATE TABLE staging.FactCombinedFinancialTransaction

--Does a minimally logged insert if this TABLOCK hint is provided, there is no clustered index,
----and the recovery model is not full*/
INSERT INTO staging.FactCombinedFinancialTransaction WITH (TABLOCK)
 (
    FK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction
    ,FK_EntityPerspective
    ,FK_AcquisitionCostBasis
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_Section
    ,FK_TriFocus
    ,FK_CRMBroker
    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,AllCategories
    ,AccountedPremium
	,AccountedPremiumExcIPTOverseasTax
    ,AccountedExternalAcquisitionCost
    ,AccountedInternalAcquisitionCost
    ,ClaimPaid
    ,ClaimOutstanding
    ,DelinkedPremium
    ,LPSOVATAmount
	,IPTOverseasTax                  
    ,IPTUKTax                      
    ,ReinsurancePremiumFac
    ,ReinsuranceRecoveryFac
    ,SigningsPosition
    ,CashDue
    ,CashPosition
    ,PartitionID
 )
/*LPSO values where there is no valid claim link - these use the SectionEntityPerspective for EntityPerspective key*/
SELECT
FK_LPSOTransaction                  = l.PK_LPSOTransaction
,FK_NonLloydsPremiumTransaction     = NULL
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostBasis            = lacb.FK_AcquisitionCostBasis    
,FK_Syndicate                       = ltlst.FK_Syndicate                          
,FK_ShareType                       = ltlst.FK_ShareType                            
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride  
,FK_Date                            = l.FK_ProcessingPeriodDate
,FK_YOA                             = l.FK_YOA
,FK_SettlementCurrency              = l.FK_SettlementCurrency
,FK_OriginalCurrency                = l.FK_OriginalCurrency
,FK_GQDTransactionType              = l.FK_GQDTransactionType
,FK_Section                         = l.FK_Section
,FK_TriFocus                        = s.FK_TriFocus
,FK_CRMBroker                       = s.FK_CRMBroker
,SpecialPurposeSyndicateApplies     = l.SpecialPurposeSyndicateApplies
,FK_DevelopmentPeriod               = l.FK_DevelopmentPeriod   
,FK_ClaimExposure                   = l.FK_ClaimExposure
,FK_SpecialCategoryCatastropheMatrix= sccm.PK_SpecialCategoryCatastropheMatrix
,FK_Policy                          = s.FK_Policy
,FK_QuoteFilter                     = s.FK_QuoteFilter
,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= s.FK_ServiceCompany
,AllCategories                      = ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                      + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                      * CASE WHEN l.CategoryCode IN (1, 2, 3) THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                        )/
                                        CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1 
                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                        END 
                                        *
                                        CASE WHEN l.CategoryCode IN (4,5) THEN - 1 ELSE 1 END --Reverse sign for claims amounts
,AccountedPremium                   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * lacb.AcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,AccountedPremiumExcIPTOverseasTax	=  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountExcIPTOverseasTaxInOriginalCCY * ltlst.TotalPositiveExcIPTOverseasTaxLineMultiplier
                                          + l.NegativeAmountExcIPTOverseasTaxInOriginalCCY * ltlst.TotalNegativeExcIPTOverseasTaxLineMultiplier)
                                          * lacb.AcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END									
,AccountedExternalAcquisitionCost   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * l.ExternalAcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,AccountedInternalAcquisitionCost   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * l.InternalAcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,ClaimPaid                          =  CASE WHEN l.CategoryCode IN (4,5) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,ClaimOutstanding                   = NULL
,DelinkedPremium                    = ((l.PositiveDelinkedAmountInOriginalCCY * ltlst.TotalPositiveDelinkedLineMultiplier
                                        + l.NegativeDelinkedAmountInOriginalCCY * ltlst.TotalNegativeDelinkedLineMultiplier) *
                                        CASE WHEN l.CategoryCode IN ('1', '2', '3') THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                        )/ 
                                        CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1 
                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                        END
,LPSOVATAmount                      = ((l.PositiveVATAmountInOriginalCCY * ltlst.TotalPositiveVATLineMultiplier
                                    + l.NegativeVATAmountInOriginalCCY * ltlst.TotalNegativeVATLineMultiplier) *
                                        CASE WHEN l.CategoryCode IN ('1', '2', '3') THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                       )/ 
                                       CASE rco.ReportingCurrencyOverrideName
                                           WHEN 'Original Currency' THEN 1 
                                           WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                       END

,IPTOverseasTax		               	= CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveIPTOverseasTaxAmountInOriginalCCY * ltlst.TotalPositiveIPTOverseasTaxLineMultiplier
                                          + l.NegativeIPTOverseasTaxAmountInOriginalCCY * ltlst.TotalNegativeIPTOverseasTaxLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END  
										END

,IPTUKTax			               	= CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveIPTUKTaxAmountInOriginalCCY * ltlst.TotalPositiveIPTUKTaxLineMultiplier
                                          + l.NegativeIPTUKTaxAmountInOriginalCCY * ltlst.TotalNegativeIPTUKTaxLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END  
										END

,ReinsurancePremiumFac			=  CASE WHEN l.CategoryCode IN (6,7) AND fac.PolicyReference IS NOT NULL

                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END

,ReinsuranceRecoveryFac              =  CASE WHEN l.CategoryCode IN (8,9) AND fac.PolicyReference IS NOT NULL
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,SigningsPosition                   =  CASE WHEN up.UnderwritingPlatformCode IN ('BICI', 'BAIC', 'BIDAC') THEN NULL
										  ELSE
												CASE WHEN l.CategoryCode IN (1,2,3) 
												THEN
													((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
												  + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
												  * lacb.AcquisitionCostMultiplier
													)/
													CASE rco.ReportingCurrencyOverrideName
														WHEN 'Original Currency' THEN 1 
														WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
													END                                       
												END
										 END
,CashDue                         =    CASE WHEN l.FK_SettlementDate <= GETDATE()
                                            THEN 
                                                CASE WHEN l.CategoryCode IN (1,2,3) 
                                                    THEN
                                                        ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                                        + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                                        * lacb.AcquisitionCostMultiplier
                                                        )/
                                                        CASE rco.ReportingCurrencyOverrideName
                                                            WHEN 'Original Currency' THEN 1 
                                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                                        END                                       
                                                    END
                                       END
,CashPosition                     =  CASE WHEN     s.SourceSystem = 'CIPS' 
                                                OR s.SourceSystem = 'Eurobase' AND up.UnderwritingPlatformName <> 'Beazley Insurance dac'
                                          THEN 1 
                                          ELSE NULL 
                                     END                                        
                                             *
                                                    --AccountedPremium
                                                    CASE WHEN l.CategoryCode IN (1,2,3) 
                                                        THEN
                                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                                            + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                                            * lacb.AcquisitionCostMultiplier
                                                            )/
                                                            CASE rco.ReportingCurrencyOverrideName
                                                                WHEN 'Original Currency' THEN 1 
                                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                                            END                                       
                                                        END
										

/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
 
FROM ODS.LPSOTransaction l
INNER JOIN ODS.Section s 
		ON l.FK_Section = s.PK_Section
INNER JOIN staging.LPSOAcquisitionCostBasis lacb 
		ON l.PK_LPSOTransaction = lacb.FK_LPSOTransaction
INNER JOIN staging.LPSOTransactionLineShareType ltlst 
		ON l.PK_LPSOTransaction = ltlst.FK_LPSOTransaction
INNER JOIN Red.ReportingCurrencyOverride rco
		ON rco.ReportingCurrencyOverrideName IN ('Original Currency', 'Settlement Currency')
INNER JOIN ODS.SectionEntityPerspective sep 
		ON s.PK_Section = sep.FK_Section
INNER JOIN staging.LPSOSpecialCategoryCatastropheMatrix lsccm 
		ON l.PK_LPSOTransaction = lsccm.FK_LPSOTransaction
INNER JOIN Red.SpecialCategoryCatastropheMatrix sccm 
		ON lsccm.GroupId = sccm.GroupId
LEFT JOIN
    (SELECT DISTINCT  [PolicyReference]
     FROM [Staging_MDS].[dbo].[vw_policy_fac_link] ) AS fac
	ON s.SectionReference = fac.PolicyReference
INNER JOIN ODS.UnderwritingPlatform up 
        ON s.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform
INNER JOIN staging.PartitionMap PM 
		ON PM.FK_AcquisitionCostBasis = lacb.FK_AcquisitionCostBasis
			AND PM.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride  
			AND PM.FK_EntityPerspective = sep.FK_EntityPerspective   
WHERE
    l.FK_ClaimExposure IS NULL
    AND PM.PartitionGUID = @GUID
    AND PM.StoredProcedureId = 2

INSERT INTO Staging.FactCombinedFinancialTransaction  
 (
    FK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction
    ,FK_EntityPerspective
    ,FK_AcquisitionCostBasis
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_Section
    ,FK_TriFocus
    ,FK_CRMBroker
    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,AllCategories
    ,AccountedPremium
	,AccountedPremiumExcIPTOverseasTax	
    ,AccountedExternalAcquisitionCost
    ,AccountedInternalAcquisitionCost
    ,ClaimPaid
    ,ClaimOutstanding
    ,DelinkedPremium
    ,LPSOVATAmount
	,IPTOverseasTax                
    ,IPTUKTax                      
    ,ReinsurancePremiumFac
    ,ReinsuranceRecoveryFac
	,SigningsPosition
    ,CashDue
    ,CashPosition
    ,PartitionID
 )

/*LPSO values where there is a valid claim link - these use ClaimEntityPerspective for the EntityPerspective key*/
SELECT
FK_LPSOTransaction                  = l.PK_LPSOTransaction
,FK_NonLloydsPremiumTransaction     = NULL
,FK_EntityPerspective               = cep.FK_EntityPerspective
,FK_AcquisitionCostBasis            = lacb.FK_AcquisitionCostBasis    
,FK_Syndicate                       = ltlst.FK_Syndicate                          
,FK_ShareType                       = ltlst.FK_ShareType                            
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride  
,FK_Date                            = l.FK_ProcessingPeriodDate
,FK_YOA                             = l.FK_YOA
,FK_SettlementCurrency              = l.FK_SettlementCurrency
,FK_OriginalCurrency                = l.FK_OriginalCurrency
,FK_GQDTransactionType              = l.FK_GQDTransactionType
,FK_Section                         = l.FK_Section
,FK_TriFocus                        = s.FK_TriFocus
,FK_CRMBroker                       = s.FK_CRMBroker
,SpecialPurposeSyndicateApplies     = l.SpecialPurposeSyndicateApplies
,FK_DevelopmentPeriod               = l.FK_DevelopmentPeriod   
,FK_ClaimExposure                   = l.FK_ClaimExposure
,FK_SpecialCategoryCatastropheMatrix= sccm.PK_SpecialCategoryCatastropheMatrix
,FK_Policy                          = s.FK_Policy
,FK_QuoteFilter                     = s.FK_QuoteFilter
,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= s.FK_ServiceCompany
,AllCategories                      = ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                      + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                      * CASE WHEN l.CategoryCode IN (1, 2, 3) THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                        )/
                                        CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1 
                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                        END
                                        *
                                        CASE WHEN l.CategoryCode IN (4,5) THEN - 1 ELSE 1 END --Reverse sign for claims amounts
,AccountedPremium                   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * lacb.AcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,AccountedPremiumExcIPTOverseasTax	=  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountExcIPTOverseasTaxInOriginalCCY * ltlst.TotalPositiveExcIPTOverseasTaxLineMultiplier
                                          + l.NegativeAmountExcIPTOverseasTaxInOriginalCCY * ltlst.TotalNegativeExcIPTOverseasTaxLineMultiplier)
                                          * lacb.AcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END												
,AccountedExternalAcquisitionCost   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * l.ExternalAcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,AccountedInternalAcquisitionCost   =  CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                          * l.InternalAcquisitionCostMultiplier
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,ClaimPaid                          =  CASE WHEN l.CategoryCode IN (4,5) 
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,ClaimOutstanding                   = NULL
,DelinkedPremium                    = ((l.PositiveDelinkedAmountInOriginalCCY * ltlst.TotalPositiveDelinkedLineMultiplier
                                        + l.NegativeDelinkedAmountInOriginalCCY * ltlst.TotalNegativeDelinkedLineMultiplier) *
                                        CASE WHEN l.CategoryCode IN ('1', '2', '3') THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                        )/ 
                                        CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1 
                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                        END
,LPSOVATAmount                      = ((l.PositiveVATAmountInOriginalCCY * ltlst.TotalPositiveVATLineMultiplier
                                    + l.NegativeVATAmountInOriginalCCY * ltlst.TotalNegativeVATLineMultiplier) *
                                        CASE WHEN l.CategoryCode IN ('1', '2', '3') THEN lacb.AcquisitionCostMultiplier
                                        ELSE 1
                                        END
                                       )/ 
                                       CASE rco.ReportingCurrencyOverrideName
                                           WHEN 'Original Currency' THEN 1 
                                           WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                       END

,IPTOverseasTax		               	= CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveIPTOverseasTaxAmountInOriginalCCY * ltlst.TotalPositiveIPTOverseasTaxLineMultiplier
                                          + l.NegativeIPTOverseasTaxAmountInOriginalCCY * ltlst.TotalNegativeIPTOverseasTaxLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END  
										END

,IPTUKTax			               	= CASE WHEN l.CategoryCode IN (1,2,3) 
                                        THEN
                                            ((l.PositiveIPTUKTaxAmountInOriginalCCY * ltlst.TotalPositiveIPTUKTaxLineMultiplier
                                          + l.NegativeIPTUKTaxAmountInOriginalCCY * ltlst.TotalNegativeIPTUKTaxLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END  
										END
,ReinsurancePremiumFac				=  CASE WHEN l.CategoryCode IN (6,7) AND fac.PolicyReference IS NOT NULL
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END

,ReinsuranceRecoveryFac			 =  CASE WHEN l.CategoryCode IN (8,9) AND fac.PolicyReference IS NOT NULL
                                        THEN
                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                          + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                            )/
                                            CASE rco.ReportingCurrencyOverrideName
                                                WHEN 'Original Currency' THEN 1 
                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                            END                                       
                                        END
,SigningsPosition                   = CASE WHEN up.UnderwritingPlatformCode IN ('BICI', 'BAIC', 'BIDAC') THEN NULL
									      ELSE 		
												CASE WHEN l.CategoryCode IN (1,2,3) 
												THEN
													((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
												  + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
												  * lacb.AcquisitionCostMultiplier
													)/
													CASE rco.ReportingCurrencyOverrideName
														WHEN 'Original Currency' THEN 1 
														WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
													END                                       
												END
										END
,CashDue                         =   CASE WHEN l.FK_SettlementDate <= GETDATE()
                                            THEN 
                                                CASE WHEN l.CategoryCode IN (1,2,3) 
                                                    THEN
                                                        ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                                        + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                                        * lacb.AcquisitionCostMultiplier
                                                        )/
                                                        CASE rco.ReportingCurrencyOverrideName
                                                            WHEN 'Original Currency' THEN 1 
                                                            WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                                        END                                       
                                                    END                                                
                                       END
,CashPosition                     = CASE WHEN     s.SourceSystem = 'CIPS' 
                                                OR s.SourceSystem = 'Eurobase' AND up.UnderwritingPlatformName <> 'Beazley Insurance dac'
                                          THEN 1 
                                          ELSE NULL 
                                     END                                        
                                             *
                                                     --AccountedPremium
                                                    CASE WHEN l.CategoryCode IN (1,2,3) 
                                                        THEN
                                                            ((l.PositiveAmountInOriginalCCY * ltlst.TotalPositiveLineMultiplier
                                                            + l.NegativeAmountInOriginalCCY * ltlst.TotalNegativeLineMultiplier)
                                                            * lacb.AcquisitionCostMultiplier
                                                            )/
                                                            CASE rco.ReportingCurrencyOverrideName
                                                                WHEN 'Original Currency' THEN 1 
                                                                WHEN 'Settlement Currency' THEN l.OriginalCCYToSettlementCCYRate
                                                            END                                       
                                                        END
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
 
FROM 
    ODS.LPSOTransaction l
INNER JOIN
    ODS.Section s ON
    l.FK_Section = s.PK_Section
INNER JOIN 
    staging.LPSOAcquisitionCostBasis lacb ON
    l.PK_LPSOTransaction = lacb.FK_LPSOTransaction
INNER JOIN 
    staging.LPSOTransactionLineShareType ltlst ON
    l.PK_LPSOTransaction = ltlst.FK_LPSOTransaction
INNER JOIN 
    Red.ReportingCurrencyOverride rco ON
    rco.ReportingCurrencyOverrideName IN ('Original Currency', 'Settlement Currency')
INNER JOIN 
    ODS.ClaimExposureEntityPerspective cep ON
    l.FK_ClaimExposure = cep.FK_ClaimExposure
INNER JOIN 
    staging.LPSOSpecialCategoryCatastropheMatrix lsccm ON
    l.PK_LPSOTransaction = lsccm.FK_LPSOTransaction
INNER JOIN
    Red.SpecialCategoryCatastropheMatrix sccm ON
    lsccm.GroupId = sccm.GroupId
LEFT JOIN
    (SELECT DISTINCT [PolicyReference] 
     FROM [Staging_MDS].[dbo].[vw_policy_fac_link] ) AS fac
	ON s.SectionReference = fac.PolicyReference

INNER JOIN ODS.UnderwritingPlatform up 
     ON s.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform 

INNER JOIN staging.PartitionMap PM 
    ON PM.FK_AcquisitionCostBasis = lacb.FK_AcquisitionCostBasis  
    AND PM.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride  
    AND PM.FK_EntityPerspective = cep.FK_EntityPerspective  
WHERE
    l.FK_ClaimExposure IS NOT NULL
    AND PM.PartitionGUID = @GUID
    AND PM.StoredProcedureId = 2

 
INSERT INTO Staging.FactCombinedFinancialTransaction  
 (
    FK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction
    ,FK_EntityPerspective
    ,FK_AcquisitionCostBasis
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_GQDTransactionType
    ,FK_Section
    ,FK_TriFocus
    ,FK_CRMBroker
    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,AllCategories
    ,AccountedPremium
	,AccountedPremiumExcIPTOverseasTax
    ,AccountedExternalAcquisitionCost
    ,AccountedInternalAcquisitionCost
    ,ClaimPaid
    ,ClaimOutstanding
    ,DelinkedPremium
    ,LPSOVATAmount
    ,PartitionID
	,ClaimTeamExaminer					
	,FK_ClaimTeamExaminer		
	,SigningsPosition
    ,CashDue
    ,CashPosition
 )

/*Claims movements - paid & outstanding for manual claims, outstanding only for SCM (paid is accounted for in LPSO)*/
SELECT
FK_LPSOTransaction                  = NULL
,FK_NonLloydsPremiumTransaction     = NULL
,FK_EntityPerspective               = fcm.FK_EntityPerspective
,FK_AcquisitionCostBasis            = acb.PK_AcquisitionCostBasis
,FK_Syndicate                       = fcm.FK_Syndicate
,FK_ShareType                       = fcm.FK_ShareType
,FK_ReportingCurrencyOverride       = fcm.FK_ReportingCurrencyOverride
,FK_Date                            = fcm.FK_Date
,FK_YOA                             = fcm.FK_YOA
,FK_SettlementCurrency              = fcm.FK_SettlementCurrency
,FK_OriginalCurrency                = fcm.FK_OriginalCurrency
,FK_GQDTransactionType              = fcm.FK_GQDTransactionType
,FK_Section                         = fcm.FK_Section
,FK_TriFocus                        = fcm.FK_TriFocus
,FK_CRMBroker                       = fcm.FK_CRMBroker
,SpecialPurposeSyndicateApplies     = fcm.SpecialPurposeSyndicateApplies
,FK_DevelopmentPeriod               = fcm.FK_DevelopmentPeriod
,FK_ClaimExposure                   = fcm.FK_ClaimExposure
,FK_SpecialCategoryCatastropheMatrix=sccm.PK_SpecialCategoryCatastropheMatrix
,FK_Policy                          = fcm.FK_Policy
,FK_QuoteFilter                     = fcm.FK_QuoteFilter
,FK_HiddenStatusFilter              = fcm.FK_HiddenStatusFilter
,FK_UnderwritingPlatform			= fcm.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= fcm.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= fcm.FK_ServiceCompany
,AllCategories                      = NULL
,AccountedPremium                   = NULL
,AccountedPremiumExcIPTOverseasTax  = NULL
,AccountedExternalAcquisitionCost   = NULL
,AccountedInternalAcquisitionCost   = NULL
,ClaimPaid                          = CASE WHEN c.HasSCMData = 0 THEN fcm.MovementTotalPaid ELSE NULL END --Claim paids for Eurobase come from USM data
,ClaimOutstanding                   = fcm.MovementTotalOutstanding
,DelinkedPremium                    = NULL
,LPSOVATAmount                      = NULL
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
,ClaimTeamExaminer					= ce.ClaimTeamExaminer					
,FK_ClaimTeamExaminer				= ce.FK_ClaimTeamExaminer				
,SigningsPosition                   = NULL
,CashDue                            = NULL
,CashPosition                       = NULL

FROM
    Red.FactClaimMovement fcm
INNER JOIN
    ODS.ClaimExposure ce ON
    fcm.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN
    ODS.Claim c ON
    ce.FK_Claim = c.PK_Claim
CROSS JOIN
    Red.AcquisitionCostBasis acb
INNER JOIN
    Red.ShareType st ON
    fcm.FK_ShareType = st.PK_ShareType
    AND st.ShareTypeName = 'Beazley Share'
INNER JOIN
Red.SpecialCategoryCatastropheMatrix sccm ON
    CAST(ce.FK_SpecialCategoryCatastrophe AS varchar(60)) = sccm.GroupId
INNER JOIN staging.PartitionMap PM 
    ON PM.FK_AcquisitionCostBasis = acb.PK_AcquisitionCostBasis  
    AND PM.FK_ReportingCurrencyOverride = fcm.FK_ReportingCurrencyOverride  
    AND PM.FK_EntityPerspective = fcm.FK_EntityPerspective  
WHERE
	(
	 c.HasSCMData = 0
	  OR
	(c.HasSCMData = 1 AND fcm.MovementTotalOutstanding <> 0)
	)
    AND PM.PartitionGUID = @GUID
    AND PM.StoredProcedureId = 2



INSERT INTO Staging.FactCombinedFinancialTransaction  
 (
    FK_LPSOTransaction
    ,FK_NonLloydsPremiumTransaction
    ,FK_EntityPerspective
    ,FK_AcquisitionCostBasis
    ,FK_Syndicate
    ,FK_ShareType
    ,FK_ReportingCurrencyOverride
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_LocalCurrency
    ,FK_GQDTransactionType
    ,FK_Section
    ,FK_TriFocus
    ,FK_CRMBroker
    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
    ,FK_SpecialCategoryCatastropheMatrix
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
    ,AllCategories
    ,AccountedPremium
	,AccountedPremiumExcIPTOverseasTax
    ,AccountedExternalAcquisitionCost
    ,AccountedInternalAcquisitionCost
    ,ClaimPaid
    ,ClaimOutstanding
    ,DelinkedPremium
    ,LPSOVATAmount
	,SigningsPosition
    ,CashDue
    ,CashPosition
    ,PartitionID
 )

/*Non-lloyds premiums*/
SELECT
FK_LPSOTransaction                  = NULL
,FK_NonLloydsPremiumTransaction     = nlp.PK_NonLloydsPremiumTransaction
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostBasis            = acb.PK_AcquisitionCostBasis
,FK_Syndicate                       = CASE WHEN st.ShareTypeName = 'Beazley Share' THEN sl.FK_Syndicate END
,FK_ShareType                       = st.PK_ShareType
,FK_ReportingCurrencyOverride       = rco.PK_ReportingCurrencyOverride
,FK_Date                            = nlp.FK_AccountingPeriod
,FK_YOA                             = yoa.PK_YOA
,FK_SettlementCurrency              = nlp.FK_SettlementCurrency
,FK_OriginalCurrency                = nlp.FK_OriginalCurrency
,FK_LocalCurrency					= nlp.FK_LocalCurrency
,FK_GQDTransactionType              = 0
,FK_Section                          = nlp.FK_Section
,FK_TriFocus                        = s.FK_TriFocus
,FK_CRMBroker                       = s.FK_CRMBroker
,SpecialPurposeSyndicateApplies     = s.SpecialPurposeSyndicateApplies
,FK_DevelopmentPeriod               = ISNULL(dp.PK_DevelopmentPeriod, 0)
,FK_ClaimExposure                   = NULL
,FK_SpecialCategoryCatastropheMatrix= sccm.PK_SpecialCategoryCatastropheMatrix
,FK_Policy                          = s.FK_Policy
,FK_QuoteFilter                     = s.FK_QuoteFilter
,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= s.FK_ServiceCompany
,AllCategories                      = NULL
,AccountedPremium                   =( 
                                         CASE acb.AcquisitionCostBasisName
                                            WHEN 'Gross Of Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY
                                            WHEN 'Net Of All Acquisition Cost' THEN (nlp.GrossPremiumInOriginalCCY  * (1 - sep.InternalAcquisitionCostMultiplier)) - nlp.ExternalAcquisitionCostInOriginalCCY
                                            WHEN 'Net Of External Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY - nlp.ExternalAcquisitionCostInOriginalCCY
                                          END
                                          /
                                          CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1
                                            WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                            WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                          END
                                      )
                                      *
                                      CASE st.ShareTypeName
                                        WHEN 'Total Order' THEN 1
                                        WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                      END
                                      *
                                      sep.PerspectiveMultiplier

								  /*  
									  CASE  
										WHEN p.SourceSystem = 'Unirisx' AND UP.UnderwritingPlatformCode = 'SLBS' THEN 0.9725 --BI to deduct the 2.75% LBS fee from the Accounted Premium. BI - 3995
										ELSE 1
									  END */
,AccountedPremiumExcIPTOverseasTax  =( 
                                         CASE acb.AcquisitionCostBasisName
                                            WHEN 'Gross Of Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY
                                            WHEN 'Net Of All Acquisition Cost' THEN (nlp.GrossPremiumInOriginalCCY  * (1 - sep.InternalAcquisitionCostMultiplier)) - nlp.ExternalAcquisitionCostInOriginalCCY
                                            WHEN 'Net Of External Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY - nlp.ExternalAcquisitionCostInOriginalCCY
                                          END
                                          /
                                          CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1
                                            WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                            WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                          END
                                      )
                                      *
                                      CASE st.ShareTypeName
                                        WHEN 'Total Order' THEN 1
                                        WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                      END
                                      *
                                      sep.PerspectiveMultiplier
,AccountedExternalAcquisitionCost   =(
                                          nlp.ExternalAcquisitionCostInOriginalCCY
                                          /
                                          CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1
                                            WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                            WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                          END
                                      )
                                      *
                                      CASE st.ShareTypeName
                                        WHEN 'Total Order' THEN 1
                                        WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                      END
                                      *
                                      sep.PerspectiveMultiplier
,AccountedInternalAcquisitionCost   =( 
                                        (nlp.GrossPremiumInOriginalCCY  * sep.InternalAcquisitionCostMultiplier)
                                          /
                                          CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1
                                            WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                            WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                          END
                                      )
                                      *
                                      CASE st.ShareTypeName
                                        WHEN 'Total Order' THEN 1
                                        WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                      END
                                      *
                                      sep.PerspectiveMultiplier
,ClaimPaid                          = NULL
,ClaimOutstanding                   = NULL
,DelinkedPremium                    = NULL
,LPSOVATAmount                      = NULL
,SigningsPosition                   = CASE WHEN up.UnderwritingPlatformCode IN ('BICI', 'BAIC', 'BIDAC') THEN NULL
                                        ELSE 
										  ( 
                                         CASE acb.AcquisitionCostBasisName
                                            WHEN 'Gross Of Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY
                                            WHEN 'Net Of All Acquisition Cost' THEN (nlp.GrossPremiumInOriginalCCY  * (1 - sep.InternalAcquisitionCostMultiplier)) - nlp.ExternalAcquisitionCostInOriginalCCY
                                            WHEN 'Net Of External Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY - nlp.ExternalAcquisitionCostInOriginalCCY
                                          END
                                          /
                                          CASE rco.ReportingCurrencyOverrideName
                                            WHEN 'Original Currency' THEN 1
                                            WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                            WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                          END
                                      )
                                      *
                                      CASE st.ShareTypeName
                                        WHEN 'Total Order' THEN 1
                                        WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                      END
                                      *
                                      sep.PerspectiveMultiplier
									  END
,CashDue                         =   CASE WHEN nlp.FK_SettlementDate <= GETDATE()
                                            THEN 
                                                    ( 
                                                        CASE acb.AcquisitionCostBasisName
                                                        WHEN 'Gross Of Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY
                                                        WHEN 'Net Of All Acquisition Cost' THEN (nlp.GrossPremiumInOriginalCCY  * (1 - sep.InternalAcquisitionCostMultiplier)) - nlp.ExternalAcquisitionCostInOriginalCCY
                                                        WHEN 'Net Of External Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY - nlp.ExternalAcquisitionCostInOriginalCCY
                                                        END
                                                        /
                                                        CASE rco.ReportingCurrencyOverrideName
                                                        WHEN 'Original Currency' THEN 1
                                                        WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                                        WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                                        END
                                                    )
                                                    *
                                                    CASE st.ShareTypeName
                                                    WHEN 'Total Order' THEN 1
                                                    WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                                    END
                                                    *
                                                    sep.PerspectiveMultiplier                                                
                                       END
,CashPosition                     =  CASE WHEN     s.SourceSystem = 'CIPS' 
                                                OR s.SourceSystem = 'Eurobase' AND up.UnderwritingPlatformName <> 'Beazley Insurance dac'
                                          THEN 1 
                                          ELSE NULL 
                                     END                                        
                                             *
                                                    --AccountedPremium
                                                    ( 
                                                        CASE acb.AcquisitionCostBasisName
                                                        WHEN 'Gross Of Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY
                                                        WHEN 'Net Of All Acquisition Cost' THEN (nlp.GrossPremiumInOriginalCCY  * (1 - sep.InternalAcquisitionCostMultiplier)) - nlp.ExternalAcquisitionCostInOriginalCCY
                                                        WHEN 'Net Of External Acquisition Cost' THEN nlp.GrossPremiumInOriginalCCY - nlp.ExternalAcquisitionCostInOriginalCCY
                                                        END
                                                        /
                                                        CASE rco.ReportingCurrencyOverrideName
                                                        WHEN 'Original Currency' THEN 1
                                                        WHEN 'Settlement Currency' THEN nlp.OriginalCCYToSettlementCCYRate
                                                        WHEN 'Local Currency' THEN nlp.OriginalCCYToLocalCCYRate
                                                        END
                                                    )
                                                    *
                                                    CASE st.ShareTypeName
                                                    WHEN 'Total Order' THEN 1
                                                    WHEN 'Beazley Share' THEN s.WrittenIfNotSignedOrderMultiplier * sl.WrittenIfNotSignedLineMultiplier
                                                    END
                                                    *
                                                    sep.PerspectiveMultiplier
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/

FROM
    ODS.Section s 
INNER JOIN
    ODS.NonLloydsPremiumTransaction nlp ON
    s.PK_Section = nlp.FK_Section
INNER JOIN
    ODS.SectionEntityPerspective sep ON
    s.PK_Section = sep.FK_Section
CROSS JOIN
    Red.AcquisitionCostBasis acb
INNER JOIN
    Red.ShareType st ON
    st.ShareTypeName = 'Beazley Share'
INNER JOIN
    Red.ReportingCurrencyOverride rco ON
    rco.ReportingCurrencyOverrideName IN ('Original Currency', 'Settlement Currency','Local Currency')
INNER JOIN
    ODS.Policy p ON
    s.FK_Policy = p.PK_Policy
INNER JOIN
    ODS.SectionLine sl ON
    s.PK_Section = sl.FK_Section
INNER JOIN
    ODS.YOA yoa ON
    p.FK_YOA = yoa.PK_YOA
INNER JOIN
    Red.SpecialCategoryCatastropheMatrix sccm ON
    sccm.GroupId = '0'
LEFT OUTER JOIN
    ODS.DevelopmentPeriod dp ON
    dp.DevelopmentMonth = DATEDIFF(MONTH, yoa.FirstDate, nlp.FK_AccountingPeriod) + 1
INNER JOIN ODS.UnderwritingPlatform up 
    ON s.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform

INNER JOIN staging.PartitionMap PM 
    ON PM.FK_AcquisitionCostBasis = acb.PK_AcquisitionCostBasis  
    AND PM.FK_ReportingCurrencyOverride = rco.PK_ReportingCurrencyOverride  
    AND PM.FK_EntityPerspective = sep.FK_EntityPerspective  
/*
INNER JOIN ODS.UnderwritingPlatform UP     -- BI - 3995
	ON s.FK_UnderwritingPlatform = UP.PK_UnderwritingPlatform
*/			 
WHERE 
    PM.PartitionGUID = @GUID
    AND PM.StoredProcedureId = 2

/*
IF OBJECT_ID('staging.LPSOAcquisitionCostBasis')               IS NOT NULL DROP TABLE staging.LPSOAcquisitionCostBasis
IF OBJECT_ID('staging.LPSOTransactionLineShareType')           IS NOT NULL DROP TABLE staging.LPSOTransactionLineShareType
IF OBJECT_ID('staging.LPSOSpecialCategoryCatastropheMatrix')   IS NOT NULL DROP TABLE staging.LPSOSpecialCategoryCatastropheMatrix
IF OBJECT_ID('tempdb..#Months')                                 IS NOT NULL DROP TABLE #Months
IF OBJECT_ID('tempdb..#EarnedPremium')                          IS NOT NULL DROP TABLE #EarnedPremium
IF OBJECT_ID('tempdb..#FacilityPremium')                        IS NOT NULL DROP TABLE #FacilityPremium
*/

--ticket 324 -- put lines which do not have correspondent for FK_ClaimTeamExaminer into dictionary to Unknown member from dictionary
UPDATE ft
SET 
	ft.FK_ClaimTeamExaminer = 0,
	ft.ClaimTeamExaminer = 'N/A'
FROM staging.FactCombinedFinancialTransaction ft

LEFT JOIN ODS.ClaimTeamExaminer cte 
ON cte.PK_ClaimTeamExaminer = ft.FK_ClaimTeamExaminer

WHERE cte.PK_ClaimTeamExaminer IS NULL


--/// DROP INDEX & DISABLE CONSTRAINTS
ALTER TABLE Red.FactCombinedFinancialTransaction NOCHECK CONSTRAINT ALL;


IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		    WHERE object_schema_name(object_id) = 'Red' AND object_name(object_id) = 'FactCombinedFinancialTransaction' AND name = 'FactCombinedFinancialTransaction_Combined')
BEGIN
	DROP INDEX FactCombinedFinancialTransaction_Combined ON Red.FactCombinedFinancialTransaction
END
---/////////


-- ADD CHECK CONSTRAINT TO PARTITIONID.
ALTER TABLE staging.FactCombinedFinancialTransaction ADD CONSTRAINT CHK_Staging_FactCombinedFinancialTransaction_p CHECK (PartitionId=1 AND PartitionId IS NOT NULL)

-- SWITCH PARTITION  
ALTER TABLE staging.FactCombinedFinancialTransaction SWITCH TO Red.FactCombinedFinancialTransaction Partition 1

-- DROP STAGING TABLE
DROP TABLE staging.FactCombinedFinancialTransaction;

