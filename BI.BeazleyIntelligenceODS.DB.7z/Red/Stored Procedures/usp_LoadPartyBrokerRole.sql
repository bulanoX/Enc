﻿

CREATE PROCEDURE [Red].[usp_LoadPartyBrokerRole]
AS

SET NOCOUNT ON

--TRUNCATE TABLE Red.PartyBrokerRole

MERGE Red.PartyBrokerRole AS TARGET

USING 
(SELECT
    FK_Party = pol.FK_PartyBrokerPlacing      
   ,RoleName = 'Placing Broker'           

FROM ODS.Policy pol

UNION

SELECT
    FK_Party = pol.FK_PartyBrokerProducing   
   ,RoleName = 'Producing Broker'       
FROM ODS.Policy pol

UNION

SELECT
    FK_Party = pol.FK_PartyBrokerServiceOfSuit     
   ,RoleName ='Service of Suit'         

FROM ODS.Policy pol

UNION

SELECT
    FK_Party= pol.FK_PartyBrokerNoticeOfClaim     
   ,RoleName = 'Notice of Claim'      
FROM ODS.Policy pol) AS SOURCE

 ON TARGET.FK_PartyBroker       = SOURCE.FK_Party
AND TARGET.RoleName             = SOURCE.RoleName

WHEN MATCHED THEN

UPDATE SET 
  TARGET.FK_PartyBroker         = SOURCE.FK_Party
 ,TARGET.RoleName               = SOURCE.RoleName
 ,TARGET.AuditModifyDateTime    = GETDATE()
 ,TARGET.AuditModifyDetails     = 'Merge in [RED].[PartyBrokerRole] table'
 
WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     FK_PartyBroker 
    ,RoleName
	,AuditModifyDetails

)
VALUES
(
     SOURCE.FK_Party
    ,SOURCE.RoleName
	,'New in [RED].[PartyBrokerRole] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'PartyBrokerRole';