﻿

CREATE PROC [Red].[usp_LoadFactExposureProfileBand]

AS

SET NOCOUNT ON

DECLARE @GUID UNIQUEIDENTIFIER 
SET		@GUID = (SELECT MAX(PartitionGUID) FROM staging.PartitionMap WHERE PartitionID=1 and storedProcedureId = 4)



/*Insert fact table values*/
--ALTER TABLE Red.FactExposureProfileBand NOCHECK CONSTRAINT ALL



IF (OBJECT_ID('staging.FactExposureProfileBand') IS NOT NULL) DROP TABLE staging.FactExposureProfileBand

CREATE TABLE Staging.FactExposureProfileBand
(
	[FK_Section] [bigint] NOT NULL,
	[FK_RateType] [bigint] NOT NULL,
	[FK_ReportingCurrency] [bigint] NOT NULL,
	[FK_ReportingCurrencyOverride] [bigint] NOT NULL,
	[FK_ShareType] [bigint] NOT NULL,
	[FK_AcquisitionCostBasis] [bigint] NOT NULL,
	[FK_EntityPerspective] [bigint] NOT NULL,
	[FK_Date] [datetime] NOT NULL,
	[FK_YOA] [bigint] NOT NULL,
	[FK_SettlementCurrency] [bigint] NOT NULL,
	[FK_OriginalCurrency] [bigint] NOT NULL,
	[FK_LocalCurrency] [bigint] NOT NULL,
	[FK_TriFocus] [bigint] NOT NULL,
	[FK_Policy] [bigint] NOT NULL,
	[FK_HiddenStatusFilter] [bigint] NOT NULL,
	[FK_QuoteFilter] [bigint] NOT NULL,
	[FK_CRMBroker] [bigint] NOT NULL,
	[SpecialPurposeSyndicateApplies] [bit] NOT NULL,
	[Limit] [numeric](38, 4) NOT NULL,
	[Excess] [numeric](38, 4) NOT NULL,
	[Deductible] [numeric](38, 4) NOT NULL,
	[Exposure] [numeric](38, 4) NOT NULL,
	[WEPIncludingReinstatementPremium] [numeric](38, 4) NULL,
	[FK_LimitProfileBand] [bigint] NOT NULL,
	[FK_ExcessProfileBand] [bigint] NOT NULL,
	[FK_DeductibleProfileBand] [bigint] NOT NULL,
	[FK_ExposureProfileBand] [bigint] NOT NULL,
	[FK_PremiumProfileBand] [bigint] NOT NULL,
	[FK_UnderwritingPlatform] [bigint] NOT NULL,
	[FK_InternalWrittenBinderStatus] [bigint] NOT NULL,
	[PartitionID] INT NULL,
	[FK_ServiceCompany] [bigint] NOT NULL
)

INSERT INTO Staging.FactExposureProfileBand WITH (TABLOCK) 
(
    FK_Section
    ,FK_RateType
    ,FK_ReportingCurrency
    ,FK_ReportingCurrencyOverride
    ,FK_ShareType
    ,FK_AcquisitionCostBasis
    ,FK_EntityPerspective
    ,FK_Date
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
	,FK_LocalCurrency
    ,FK_TriFocus
    ,FK_Policy
    ,FK_HiddenStatusFilter
    ,FK_QuoteFilter
    ,FK_CRMBroker
    ,SpecialPurposeSyndicateApplies
    ,Limit
    ,Excess
    ,Deductible
    ,Exposure
    ,WEPIncludingReinstatementPremium
    ,FK_LimitProfileBand
    ,FK_ExcessProfileBand
    ,FK_DeductibleProfileBand
    ,FK_ExposureProfileBand
	,FK_PremiumProfileBand
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
	,PartitionID
)
SELECT
FK_Section                          = rc.FK_Section
,FK_RateType                        = rc.FK_RateType
,FK_ReportingCurrency               = rc.FK_ReportingCurrency
,FK_ReportingCurrencyOverride       = rc.FK_ReportingCurrencyOverride
,FK_ShareType                       = rc.FK_ShareType
,FK_AcquisitionCostBasis            = rc.FK_AcquisitionCostBasis
,FK_EntityPerspective               = rc.FK_EntityPerspective
,FK_Date                            = s.FK_InceptionDate
,FK_YOA                             = s.FK_YOA
,FK_SettlementCurrency              = s.FK_SettlementCurrency
,FK_OriginalCurrency                = s.FK_OriginalCurrency
,FK_LocalCurrency					= s.FK_LocalCurrency
,FK_TriFocus                        = s.FK_TriFocus
,FK_Policy                          = s.FK_Policy
,FK_HiddenStatusFilter              = s.FK_HiddenStatusFilter
,FK_QuoteFilter                     = s.FK_QuoteFilter
,FK_CRMBroker                       = s.FK_CRMBroker
,SpecialPurposeSyndicateApplies     = s.SpecialPurposeSyndicateApplies
,Limit                              = rc.Limit
,Excess                             = rc.Excess
,Deductible                         = rc.Deductible
,Exposure                           = rc.Exposure
,WEPIncludingReinstatementPremium   = rc.WEPIncludingReinstatementPremuium
,FK_LimitProfileBand                = p_lim.PK_ExposureProfileBand
,FK_ExcessProfileBand               = p_exc.PK_ExposureProfileBand
,FK_DeductibleProfileBand           = p_ded.PK_ExposureProfileBand
,FK_ExposureProfileBand             = p_exp.PK_ExposureProfileBand
,FK_PremiumProfileBand				= p_prm.PK_ExposureProfileBand
,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany					= s.FK_ServiceCompany
/*DO NOT AMEND FORMATTING*/
,PartitionID=1
/*DO NOT AMEND FORMATTING*/
FROM
staging.ValuesInReportingCurrency rc

INNER JOIN	ODS.Section s					ON	rc.FK_Section = s.PK_Section
INNER JOIN	ODS.ExposureProfileBand p_lim	ON	p_lim.BandType = 'Limit'
												AND rc.Department = p_lim.Department
												AND rc.Limit > p_lim.BandMin
												AND rc.Limit <= p_lim.BandMax
INNER JOIN	ODS.ExposureProfileBand p_exc	ON	p_exc.BandType = 'Excess'
												AND rc.Department = p_exc.Department
												AND rc.Excess > p_exc.BandMin
												AND rc.Excess <= p_exc.BandMax
INNER JOIN	ODS.ExposureProfileBand p_ded	ON	p_ded.BandType = 'Deductible'
												AND rc.Department = p_ded.Department
												AND rc.Deductible > p_ded.BandMin
												AND rc.Deductible <= p_ded.BandMax	
INNER JOIN	ODS.ExposureProfileBand p_exp	ON	p_exp.BandType = 'Exposure'
												AND rc.Department = p_exp.Department
												AND rc.Exposure > p_exp.BandMin
												AND rc.Exposure <= p_exp.BandMax
INNER JOIN	ODS.ExposureProfileBand p_prm	ON	p_prm.BandType = 'Premium'
												--AND rc.Department = p_exp.Department
												AND rc.WEPIncludingReinstatementPremuium > p_prm.BandMin
												AND rc.WEPIncludingReinstatementPremuium <= p_prm.BandMax

INNER JOIN staging.PartitionMap PM 
		ON      PM.FK_EntityPerspective = rc.FK_EntityPerspective   
			AND PM.FK_AcquisitionCostBasis = rc.FK_AcquisitionCostBasis  
			AND PM.FK_RateType = rc.FK_RateType
WHERE PM.PartitionGUID = @GUID
AND PM.StoredProcedureId = 4


/*

DROP INDEX #ValuesInReportingCurrency.a

Target table load time WITH		index = 10.0
Target table load time WITHOUT	index = 9.47

-- index creation time.... 10s

CREATE NONCLUSTERED INDEX a
ON [dbo].[#ValuesInReportingCurrency] ([FK_Section])
INCLUDE ([FK_RateType],[FK_ReportingCurrency],[FK_ReportingCurrencyOverride],[FK_ShareType],[FK_AcquisitionCostBasis],[FK_EntityPerspective],[Department],[Limit],[Excess],[Deductible],[Exposure],[WEPIncludingReinstatementPremuium])
 
  

*/


--IF NOT EXISTS
--(
--    SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE 
--    WHERE TABLE_SCHEMA = 'Red' AND TABLE_NAME = 'FactExposureProfileBand' AND CONSTRAINT_NAME = 'UQ_FactExposureProfileBand_LogicalKey'     
--)
--BEGIN
--    ALTER TABLE Red.FactExposureProfileBand
--    ADD CONSTRAINT UQ_FactExposureProfileBand_LogicalKey
--    UNIQUE
--        (
--            FK_Section
--            ,FK_RateType
--            ,FK_ReportingCurrency
--            ,FK_ReportingCurrencyOverride
--            ,FK_ShareType
--            ,FK_AcquisitionCostBasis
--            ,FK_EntityPerspective
--        )
--END

--ALTER TABLE Red.FactExposureProfileBand CHECK CONSTRAINT ALL


-- ADD CHECK CONSTRAINT TO PARTITIONID.
ALTER TABLE staging.FactExposureProfileBand ADD CONSTRAINT CHK_Staging_FactExposureProfileBand_p CHECK (PartitionId=1 AND PartitionId IS NOT NULL)
 
-- SWITCH PARTITION
ALTER TABLE staging.FactExposureProfileBand SWITCH TO Red.FactExposureProfileBand Partition 1

-- DROP STAGING TABLE
DROP TABLE  staging.FactExposureProfileBand;

