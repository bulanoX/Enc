﻿
CREATE PROCEDURE [Red].[usp_LoadOperationalMetric]
AS

SET NOCOUNT ON

--DELETE FROM Red.OperationalMetric

IF (OBJECT_ID('tempdb..#OperationalMetric') IS NOT NULL)
DROP TABLE #OperationalMetric

CREATE TABLE #OperationalMetric
(
    [OperationalMetricParentID] [bigint] NULL,
	[EntityName] [nvarchar](255) NOT NULL,
	[MetricCalculation] [nvarchar](max) NULL,
	[MetricFormat] [nvarchar](255) NULL,
	[MetricDisplayOrder] [int] NULL,
	[MDSEntityID] [int] NULL,
	[MDSParentEntityID] [int] NULL,
)
----- Load Operational Metric Table
INSERT INTO #OperationalMetric
 (
  EntityName         
 ,MetricCalculation  
 ,MetricFormat
 ,MetricDisplayOrder
 ,MDSEntityID           
 ,MDSParentEntityID
 )


-- entities dataset
SELECT 

 EntityName                 = enty.[Name]
,MetricCalculation          = NULL
,MetricFormat               = NULL
,MetricDisplayOrder         = NULL
,MDSEntityID                = enty.Code        
,MDSParentEntityID          = CASE WHEN enty.ParentEntityID_Code = enty.Code 
                               THEN NULL 
                               ELSE enty.ParentEntityID_Code 
                              END
FROM Staging_MDS.MDS_Staging.BeazleyIntelligenceMetricEntity enty

UNION ALL

-- metric dataset
SELECT 
 EntityName               = defi.[Name] 
,MetricCalculation        = defi.MetricCalculation
,MetricFormat             = frmt.[Name]
,MetricDisplayOrder       = defi.MetricDisplayOrder
,MDSEntityID              = NULL
,MDSParentEntityID        = defi.EntityId_Code


FROM  Staging_MDS.MDS_Staging.BeazleyIntelligenceMetricDefinition defi

LEFT OUTER JOIN Staging_MDS.MDS_Staging.BeazleyIntelligenceMetricFormat frmt
ON defi.MetricFormatID_Code = frmt.Code

MERGE Red.OperationalMetric AS TARGET

USING #OperationalMetric AS SOURCE

 ON TARGET.EntityName              = SOURCE.EntityName
AND TARGET.MetricCalculation       = SOURCE.MetricCalculation
AND TARGET.MetricFormat            = SOURCE.MetricFormat
AND TARGET.MetricDisplayOrder      = SOURCE.MetricDisplayOrder
AND TARGET.MDSEntityID             = SOURCE.MDSEntityID
AND TARGET.MDSParentEntityID       = SOURCE.MDSParentEntityID

WHEN MATCHED THEN

UPDATE SET 
   TARGET.EntityName             = SOURCE.EntityName
  ,TARGET.MetricCalculation      = SOURCE.MetricCalculation
  ,TARGET.MetricFormat           = SOURCE.MetricFormat
  ,TARGET.MetricDisplayOrder     = SOURCE.MetricDisplayOrder
  ,TARGET.MDSEntityID            = SOURCE.MDSEntityID
  ,TARGET.MDSParentEntityID      = SOURCE.MDSParentEntityID
  ,TARGET.AuditModifyDateTime    = GETDATE()
  ,TARGET.AuditModifyDetails     = 'Merge in [RED].[OperationalMetric] table'
 
WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     EntityName         
    ,MetricCalculation  
    ,MetricFormat
    ,MetricDisplayOrder
    ,MDSEntityID           
    ,MDSParentEntityID
	,AuditModifyDetails

)
VALUES
(
   SOURCE.EntityName
  ,SOURCE.MetricCalculation
  ,SOURCE.MetricFormat
  ,SOURCE.MetricDisplayOrder
  ,SOURCE.MDSEntityID
  ,SOURCE.MDSParentEntityID	
  ,'New in [RED].[OperationalMetric] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

-- Redefine hierarchy ids before data is read by the Red cube
UPDATE metric

SET metric.OperationalMetricParentID = pmetric.PK_OperationalMetricID

FROM Red.OperationalMetric metric

LEFT OUTER JOIN Red.OperationalMetric pmetric
ON metric.MDSParentEntityId = pmetric.MDSEntityId


-- Clean up hierarchy when there is not a metric defined.
;
WITH OperationalMetricHierarchy 
(
  PK_OperationalMetricID 
 ,OperationalMetricParentID 
 ,EntityName
 ,HasVisibleLeaves 
)
AS
(
-- Anchor Member
SELECT
      PK_OperationalMetricID         = metric.PK_OperationalMetricID
     ,OperationalMetricParentID      = metric.OperationalMetricParentID
     ,EntityName                     = metric.EntityName
     ,HasVisibleLeaves               = 1

FROM  Red.OperationalMetric metric
WHERE metric.MetricCalculation IS NOT NULL

UNION ALL

-- Recursive member
SELECT
      PK_OperationalMetricID         = metric.PK_OperationalMetricID
     ,OperationalMetricParentID      = metric.OperationalMetricParentID
     ,EntityName                     = metric.EntityName
     ,HasVisibleLeaves               = 1

FROM  Red.OperationalMetric metric     
    
INNER JOIN OperationalMetricHierarchy cte    
ON metric.PK_OperationalMetricID = cte.OperationalMetricParentID
)

DELETE metric FROM Red.OperationalMetric metric
WHERE metric.PK_OperationalMetricID NOT IN (SELECT metric.PK_OperationalMetricID FROM OperationalMetricHierarchy metric)


IF (OBJECT_ID('tempdb..#OperationalMetric') IS NOT NULL)
DROP TABLE #OperationalMetric;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Red', @TableName = 'OperationalMetric';