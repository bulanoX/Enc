﻿

CREATE PROCEDURE [Red].[usp_PreProcessFactReinsuranceCombinedFinancialTransaction]
AS

/*
 - The Combined financials contain:
 - LPSO premiums
 - LPSO claim paid amounts
 - LPSO RI transactions
 - Manual claim paid & outstanding
 - SCM claim outstanding only (paid is accounted for in LPSO claim paid)
 
 This is the measure group used to caclulate loss ratios and create triangles.
*/

SET NOCOUNT ON


/***********************************************************************************/
/*                Share Type (LPSO Transaction Line Level)                         */
/***********************************************************************************/
IF (OBJECT_ID('Staging.ReinsuranceLPSOTransactionLineShareType') IS NOT NULL) DROP TABLE Staging.ReinsuranceLPSOTransactionLineShareType

CREATE TABLE Staging.ReinsuranceLPSOTransactionLineShareType
 (
    FK_LPSOTransaction                     bigint              NOT NULL
   ,FK_Syndicate                           bigint              NULL
   ,FK_ShareType                           bigint              NOT NULL
   ,TotalPositiveLineMultiplier            numeric(19,12)      NOT NULL
   ,TotalNegativeLineMultiplier            numeric(19,12)      NOT NULL
   ,TotalPositiveVATLineMultiplier         numeric(19,12)      NOT NULL
   ,TotalNegativeVATLineMultiplier         numeric(19,12)      NOT NULL
   ,TotalPositiveDelinkedLineMultiplier    numeric(19,12)      NOT NULL
   ,TotalNegativeDelinkedLineMultiplier    numeric(19,12)      NOT NULL
   ,AuditModifyDateTime                    datetime2(7)         NULL
   ,AuditCreateDateTime                    datetime2(7)  DEFAULT (GETDATE()) NOT NULL
   ,AuditModifyDetails                     nvarchar(255)        NULL

 )

TRUNCATE TABLE Staging.ReinsuranceLPSOTransactionLineShareType

INSERT INTO Staging.ReinsuranceLPSOTransactionLineShareType
 (
    FK_LPSOTransaction
   ,FK_Syndicate
   ,FK_ShareType
   ,TotalPositiveLineMultiplier
   ,TotalNegativeLineMultiplier
   ,TotalPositiveVATLineMultiplier
   ,TotalNegativeVATLineMultiplier
   ,TotalPositiveDelinkedLineMultiplier
   ,TotalNegativeDelinkedLineMultiplier
 )
 
SELECT
    FK_LPSOTransaction                  = l.PK_LPSOTransaction               
    ,FK_Syndicate                        = ltl.FK_Syndicate                    
    ,FK_ShareType                        = st.PK_ShareType                       
    ,TotalPositiveLineMultiplier         = s.SignedOrderMultiplier * ltl.PositiveLineMultiplier           
    ,TotalNegativeLineMultiplier         = s.SignedOrderMultiplier * ltl.NegativeLineMultiplier            
    ,TotalPositiveVATLineMultiplier      = s.SignedOrderMultiplier * ltl.PositiveVATLineMultiplier        
    ,TotalNegativeVATLineMultiplier      = s.SignedOrderMultiplier * ltl.NegativeVATLineMultiplier        
    ,TotalPositiveDelinkedLineMultiplier = s.SignedOrderMultiplier * ltl.PositiveDelinkedLineMultiplier   
    ,TotalNegativeDelinkedLineMultiplier = s.SignedOrderMultiplier * ltl.NegativeDelinkedLineMultiplier   
FROM 
    ODS.ReinsuranceLPSOTransaction l
INNER JOIN 
    ODS.ReinsuranceContractNonFac s 
    ON l.FK_ReinsuranceContract = s.PK_ReinsuranceContract
INNER JOIN 
    ODS.ReinsuranceLPSOTransactionLine ltl 
    ON l.PK_LPSOTransaction = ltl.FK_LPSOTransaction
CROSS JOIN 
    Red.ShareType st
WHERE 
    st.ShareTypeName = 'Beazley Share'

CREATE NONCLUSTERED INDEX IX_ReinsuranceLPSOTransactionLineShareType ON Staging.ReinsuranceLPSOTransactionLineShareType (FK_LPSOTransaction)

TRUNCATE TABLE Red.FactReinsuranceCombinedFinancialTransaction