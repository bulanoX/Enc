﻿CREATE TABLE [Red].[ClaimMovementSection] (
    [FK_ClaimMovement]    BIGINT           NOT NULL,
    [FK_Section]          BIGINT           NOT NULL,
    [WeightingMultiplier] NUMERIC (38, 37) NOT NULL,
    CONSTRAINT [PK_ClaimMovementSection] PRIMARY KEY CLUSTERED ([FK_ClaimMovement] ASC, [FK_Section] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimMovementSection_ClaimMovement] FOREIGN KEY ([FK_ClaimMovement]) REFERENCES [ODS].[ClaimMovement] ([PK_ClaimMovement]),
    CONSTRAINT [FK_ClaimMovementSection_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

