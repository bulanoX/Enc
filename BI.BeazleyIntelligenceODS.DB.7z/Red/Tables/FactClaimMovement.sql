﻿CREATE TABLE [Red].[FactClaimMovement] (
    [FK_ClaimMovement]                       BIGINT           NOT NULL,
    [FK_Section]                             BIGINT           NOT NULL,
    [FK_Syndicate]                           BIGINT           NULL,
    [FK_SlipLineNumber]                      BIGINT           NULL,
    [FK_ShareType]                           BIGINT           NOT NULL,
    [FK_ReportingCurrencyOverride]           BIGINT           NOT NULL,
    [FK_Date]                                DATETIME         NOT NULL,
    [FK_MovementCreationDate]                DATETIME         NULL,
    [FK_YOA]                                 BIGINT           NOT NULL,
    [FK_SettlementCurrency]                  BIGINT           NOT NULL,
    [FK_OriginalCurrency]                    BIGINT           NOT NULL,
    [FK_LocalCurrency]                       BIGINT           CONSTRAINT [DF__FactClaim__FK_Lo__73E5190C] DEFAULT ((0)) NOT NULL,
    [FK_GQDTransactionType]                  BIGINT           NOT NULL,
    [FK_ClaimCostCategory]                   BIGINT           NOT NULL,
    [FK_ClaimExposure]                       BIGINT           NOT NULL,
    [FK_DevelopmentPeriod]                   BIGINT           NOT NULL,
    [FK_SpecialCategoryCatastrophe]          BIGINT           NOT NULL,
    [FK_TriFocus]                            BIGINT           NOT NULL,
    [FK_EntityPerspective]                   BIGINT           NOT NULL,
    [FK_Policy]                              BIGINT           NOT NULL,
    [FK_HiddenStatusFilter]                  BIGINT           NOT NULL,
    [FK_QuoteFilter]                         BIGINT           NOT NULL,
    [FK_CRMBroker]                           BIGINT           NOT NULL,
    [FK_UnderwritingPlatform]                BIGINT           NOT NULL,
    [FK_InternalWrittenBinderStatus]         BIGINT           NOT NULL,
    [SpecialPurposeSyndicateApplies]         BIT              NOT NULL,
    [MovementPaidIndemnity]                  NUMERIC (19, 4)  NULL,
    [MovementPaidFees]                       NUMERIC (19, 4)  NULL,
    [MovementPaidDefence]                    NUMERIC (19, 4)  NULL,
    [ToDatePaidIndemnity]                    NUMERIC (19, 4)  NOT NULL,
    [ToDatePaidFees]                         NUMERIC (19, 4)  NOT NULL,
    [ToDatePaidDefence]                      NUMERIC (19, 4)  NOT NULL,
    [MovementReceivedIndemnityNRR]           NUMERIC (19, 4)  NULL,
    [MovementReceivedFeesNRR]                NUMERIC (19, 4)  NULL,
    [MovementReceivedDefenceNRR]             NUMERIC (19, 4)  NULL,
    [ToDateReceivedIndemnityNRR]             NUMERIC (19, 4)  NOT NULL,
    [ToDateReceivedFeesNRR]                  NUMERIC (19, 4)  NOT NULL,
    [ToDateReceivedDefenceNRR]               NUMERIC (19, 4)  NOT NULL,
    [MovementOutstandingIndemnity]           NUMERIC (19, 4)  NULL,
    [MovementOutstandingFees]                NUMERIC (19, 4)  NULL,
    [MovementOutstandingDefence]             NUMERIC (19, 4)  NULL,
    [ToDateOutstandingIndemnity]             NUMERIC (19, 4)  NOT NULL,
    [ToDateOutstandingFees]                  NUMERIC (19, 4)  NOT NULL,
    [ToDateOutstandingDefence]               NUMERIC (19, 4)  NOT NULL,
    [MovementIncurredIndemnity]              AS               ([MovementPaidIndemnity]+[MovementOutstandingIndemnity]),
    [MovementIncurredFees]                   AS               ([MovementPaidFees]+[MovementOutstandingFees]),
    [MovementIncurredDefence]                AS               ([MovementPaidDefence]+[MovementOutstandingDefence]),
    [MovementTotalPaid]                      AS               (([MovementPaidFees]+[MovementPaidIndemnity])+[MovementPaidDefence]),
    [MovementTotalOutstanding]               AS               (([MovementOutstandingFees]+[MovementOutstandingIndemnity])+[MovementOutstandingDefence]),
    [MovementTotalIncurred]                  AS               ((((([MovementPaidFees]+[MovementPaidIndemnity])+[MovementPaidDefence])+[MovementOutstandingFees])+[MovementOutstandingIndemnity])+[MovementOutstandingDefence]),
    [ToDateIncurredFees]                     AS               ([ToDatePaidFees]+[ToDateOutstandingFees]),
    [ToDateIncurredIndemnity]                AS               ([ToDatePaidIndemnity]+[ToDateOutstandingIndemnity]),
    [ToDateIncurredDefence]                  AS               ([ToDatePaidDefence]+[ToDateOutstandingDefence]),
    [ToDateTotalPaid]                        AS               (([ToDatePaidFees]+[ToDatePaidIndemnity])+[ToDatePaidDefence]),
    [ToDateTotalOutstanding]                 AS               (([ToDateOutstandingFees]+[ToDateOutstandingIndemnity])+[ToDateOutstandingDefence]),
    [ToDateTotalIncurred]                    AS               ((((([ToDatePaidFees]+[ToDatePaidIndemnity])+[ToDatePaidDefence])+[ToDateOutstandingFees])+[ToDateOutstandingIndemnity])+[ToDateOutstandingDefence]),
    [MovementTotalReceivedNRR]               AS               (([MovementReceivedIndemnityNRR]+[MovementReceivedFeesNRR])+[MovementReceivedDefenceNRR]),
    [ToDateTotalReceivedNRR]                 AS               (([ToDateReceivedIndemnityNRR]+[ToDateReceivedFeesNRR])+[ToDateReceivedDefenceNRR]),
    [MovementPaidIndemnityExcludingNRR]      AS               ([MovementPaidIndemnity]+[MovementReceivedIndemnityNRR]),
    [MovementPaidFeesExcludingNRR]           AS               ([MovementPaidFees]+[MovementReceivedFeesNRR]),
    [MovementPaidDefenceExcludingNRR]        AS               ([MovementPaidDefence]+[MovementReceivedDefenceNRR]),
    [MovementTotalPaidExcludingNRR]          AS               ((((([MovementPaidIndemnity]+[MovementPaidFees])+[MovementPaidDefence])+[MovementReceivedIndemnityNRR])+[MovementReceivedFeesNRR])+[MovementReceivedDefenceNRR]),
    [ToDatePaidIndemnityExcludingNRR]        AS               ([ToDatePaidIndemnity]+[ToDateReceivedIndemnityNRR]),
    [ToDatePaidFeesExcludingNRR]             AS               ([ToDatePaidFees]+[ToDateReceivedFeesNRR]),
    [ToDatePaidDefenceExcludingNRR]          AS               ([ToDatePaidDefence]+[ToDateReceivedDefenceNRR]),
    [ToDateTotalPaidExcludingNRR]            AS               ((((([ToDatePaidIndemnity]+[ToDatePaidFees])+[ToDatePaidDefence])+[ToDateReceivedIndemnityNRR])+[ToDateReceivedFeesNRR])+[ToDateReceivedDefenceNRR]),
    [MovementIncurredIndemnityExcludingNRR]  AS               (([MovementOutstandingIndemnity]+[MovementPaidIndemnity])+[MovementReceivedIndemnityNRR]),
    [MovementIncurredFeesExcludingNRR]       AS               (([MovementOutstandingFees]+[MovementPaidFees])+[MovementReceivedFeesNRR]),
    [MovementIncurredDefenceExcludingNRR]    AS               (([MovementOutstandingDefence]+[MovementPaidDefence])+[MovementReceivedDefenceNRR]),
    [MovementTotalIncurredExcludingNRR]      AS               (((((((([MovementOutstandingIndemnity]+[MovementOutstandingFees])+[MovementOutstandingDefence])+[MovementPaidIndemnity])+[MovementPaidFees])+[MovementPaidDefence])+[MovementReceivedIndemnityNRR])+[MovementReceivedFeesNRR])+[MovementReceivedDefenceNRR]),
    [ToDateIncurredIndemnityExcludingNRR]    AS               (([ToDateOutstandingIndemnity]+[ToDatePaidIndemnity])+[ToDateReceivedIndemnityNRR]),
    [ToDateIncurredFeesExcludingNRR]         AS               (([ToDateOutstandingFees]+[ToDatePaidFees])+[ToDateReceivedFeesNRR]),
    [ToDateIncurredDefenceExcludingNRR]      AS               (([ToDateOutstandingDefence]+[ToDatePaidDefence])+[ToDateReceivedDefenceNRR]),
    [ToDateTotalIncurredExcludingNRR]        AS               (((((((([ToDateOutstandingIndemnity]+[ToDateOutstandingFees])+[ToDateOutstandingDefence])+[ToDatePaidIndemnity])+[ToDatePaidFees])+[ToDatePaidDefence])+[ToDateReceivedIndemnityNRR])+[ToDateReceivedFeesNRR])+[ToDateReceivedDefenceNRR]),
    [MovementPaidIndemnityAndDefence]        AS               ([MovementPaidIndemnity]+[MovementPaidDefence]),
    [MovementOutstandingIndemnityAndDefence] AS               ([MovementOutstandingIndemnity]+[MovementOutstandingDefence]),
    [MovementIncurredIndemnityAndDefence]    AS               ((([MovementPaidIndemnity]+[MovementPaidDefence])+[MovementOutstandingIndemnity])+[MovementOutstandingDefence]),
    [ToDatePaidIndemnityAndDefence]          AS               ([ToDatePaidIndemnity]+[ToDatePaidDefence]),
    [ToDateOutstandingIndemnityAndDefence]   AS               ([ToDateOutstandingIndemnity]+[ToDateOutstandingDefence]),
    [ToDateIncurredIndemnityAndDefence]      AS               ((([ToDatePaidIndemnity]+[ToDatePaidDefence])+[ToDateOutstandingIndemnity])+[ToDateOutstandingDefence]),
    [ClaimTeamExaminer]                      VARCHAR (255)    CONSTRAINT [DEF_FactClaimMovement_ClaimTeamExaminer] DEFAULT ('N/A') NULL,
    [FK_ClaimTeamExaminer]                   BIGINT           CONSTRAINT [DEF_FactClaimMovement_FK_ClaimTeamExaminer] DEFAULT ((0)) NULL,
    [ActualOriginalCurrency]                 VARCHAR (3)      NULL,
    [ActualOriginalAmount]                   NUMERIC (19, 4)  NULL,
    [EstimatedSettlementAmount]              NUMERIC (19, 4)  NULL,
    [ActualToSettlementExchangeRate]         NUMERIC (19, 4)  NULL,
    [FK_ServiceCompany]                      BIGINT           NOT NULL,
    [ActualOriginalAmountType]               VARCHAR (255)    NULL,
    [SignedLine]                             NUMERIC (20, 4)  NULL,
    [NetPaymentAmount]                       NUMERIC (20, 4)  NULL,
    [TaxAmount]                              NUMERIC (20, 4)  NULL,
    [ToDateTotalPaid_SyndicateView]          NUMERIC (21, 4)  NULL,
    [ToDateTotalOutstanding_SyndicateView]   NUMERIC (21, 4)  NULL,
    [ToDateTotalIncurred_SyndicateView]      NUMERIC (24, 4)  NULL,
    [MovementTotalPaid_SyndicateView]        NUMERIC (21, 4)  NULL,
    [MovementTotalOutstanding_SyndicateView] NUMERIC (21, 4)  NULL,
    [MovementTotalIncurred_SyndicateView]    NUMERIC (24, 4)  NULL,
    [SyndicateViewMultiplier]                NUMERIC (19, 12) NULL,
    [MovementNetPaymentAmount]               NUMERIC (20, 4)  NULL,
    [ToDateNetPaymentAmount]                 NUMERIC (20, 4)  NULL,
    [MovementTaxAmount]                      NUMERIC (20, 4)  NULL,
    [ToDateTaxAmount]                        NUMERIC (20, 4)  NULL,
    CONSTRAINT [FK_FactClaimMovement_ClaimCostCategory] FOREIGN KEY ([FK_ClaimCostCategory]) REFERENCES [ODS].[ClaimCostCategory] ([PK_ClaimCostCategory]),
    CONSTRAINT [FK_FactClaimMovement_ClaimExposureEntityPerspective] FOREIGN KEY ([FK_ClaimExposure], [FK_EntityPerspective]) REFERENCES [ODS].[ClaimExposureEntityPerspective] ([FK_ClaimExposure], [FK_EntityPerspective]),
    CONSTRAINT [FK_FactClaimMovement_ClaimMovement] FOREIGN KEY ([FK_ClaimMovement]) REFERENCES [ODS].[ClaimMovement] ([PK_ClaimMovement]),
    CONSTRAINT [FK_FactClaimMovement_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_FactClaimMovement_Date] FOREIGN KEY ([FK_Date]) REFERENCES [ODS].[DimDate] ([PK_Date]),
    CONSTRAINT [FK_FactClaimMovement_DevelopmentPeriod] FOREIGN KEY ([FK_DevelopmentPeriod]) REFERENCES [ODS].[DevelopmentPeriod] ([PK_DevelopmentPeriod]),
    CONSTRAINT [FK_FactClaimMovement_GQDTransactionType] FOREIGN KEY ([FK_GQDTransactionType]) REFERENCES [ODS].[GQDTransactionType] ([PK_GQDTransactionType]),
    CONSTRAINT [FK_FactClaimMovement_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_FactClaimMovement_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_FactClaimMovement_LocalCurrency] FOREIGN KEY ([FK_LocalCurrency]) REFERENCES [ODS].[LocalCurrency] ([PK_LocalCurrency]),
    CONSTRAINT [FK_FactClaimMovement_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_FactClaimMovement_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_FactClaimMovement_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_FactClaimMovement_ReportingCurrencyOverride] FOREIGN KEY ([FK_ReportingCurrencyOverride]) REFERENCES [Red].[ReportingCurrencyOverride] ([PK_ReportingCurrencyOverride]),
    CONSTRAINT [FK_FactClaimMovement_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_FactClaimMovement_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_FactClaimMovement_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_FactClaimMovement_ShareType] FOREIGN KEY ([FK_ShareType]) REFERENCES [Red].[ShareType] ([PK_ShareType]),
    CONSTRAINT [FK_FactClaimMovement_SlipLineNumber] FOREIGN KEY ([FK_SlipLineNumber]) REFERENCES [ODS].[SlipLineNumber] ([PK_SlipLineNumber]),
    CONSTRAINT [FK_FactClaimMovement_SpecialCategoryCatastrophe] FOREIGN KEY ([FK_SpecialCategoryCatastrophe]) REFERENCES [ODS].[SpecialCategoryCatastrophe] ([PK_SpecialCategoryCatastrophe]),
    CONSTRAINT [FK_FactClaimMovement_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate]),
    CONSTRAINT [FK_FactClaimMovement_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_FactClaimMovement_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform]),
    CONSTRAINT [FK_FactClaimMovement_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_FactClaimMovement_LogicalKey] UNIQUE NONCLUSTERED ([FK_ClaimMovement] ASC, [FK_EntityPerspective] ASC, [FK_Section] ASC, [FK_Syndicate] ASC, [FK_SlipLineNumber] ASC, [FK_ShareType] ASC, [FK_ReportingCurrencyOverride] ASC) WITH (FILLFACTOR = 90)
);
GO

CREATE NONCLUSTERED INDEX [FactClaimMovement_EntityPerspective] ON Red.FactClaimMovement ([FK_EntityPerspective] ASC) WITH (FILLFACTOR = 90);
GO


































