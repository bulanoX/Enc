﻿CREATE TABLE [Red].[AreaHierarchyFlat] (
    [PK_AreaHierarchyFlat] AS               ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(((([Level1Code]+'|~|')+[Level2Code])+'|~|')+[Level3Code]))),(0)) PERSISTED NOT NULL,
    [Level1Key]            BIGINT           NOT NULL,
    [Level1Code]           VARCHAR (255)    NOT NULL,
    [Level1Name]           VARCHAR (255)    NOT NULL,
    [Level2Key]            BIGINT           NOT NULL,
    [Level2Code]           VARCHAR (255)    NOT NULL,
    [Level2Name]           VARCHAR (255)    NOT NULL,
    [Level3Key]            BIGINT           NOT NULL,
    [Level3Code]           VARCHAR (255)    NOT NULL,
    [Level3Name]           VARCHAR (255)    NOT NULL,
    [AuditModifyDateTime]  DATETIME2 (7)    NULL,
    [AuditCreateDateTime]  DATETIME2 (7)    DEFAULT (GETDATE()) NULL,
    [AuditModifyDetails]   NVARCHAR (255)   NULL,
    CONSTRAINT [PK_AreaHierarchyFlat] PRIMARY KEY CLUSTERED ([PK_AreaHierarchyFlat] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_AreaHierarchyFlat_LogicalKey] UNIQUE NONCLUSTERED ([Level1Code] ASC, [Level2Code] ASC, [Level3Code] ASC) WITH (FILLFACTOR = 90)
);

