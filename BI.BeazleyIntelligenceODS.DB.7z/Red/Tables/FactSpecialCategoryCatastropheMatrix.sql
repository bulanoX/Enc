﻿CREATE TABLE [Red].[FactSpecialCategoryCatastropheMatrix] (
    [FK_SpecialCategoryCatastropheMatrix] BIGINT         NOT NULL,
    [FK_SpecialCategoryCatastrophe]       BIGINT         NOT NULL,
    [AuditModifyDateTime]                 DATETIME2 (7)  NULL,
    [AuditCreateDateTime]                 DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                  NVARCHAR (512) NULL,
    CONSTRAINT [FK_FactSpecialCategoryCatastropheMatrix_SpecialCategoryCatastrophe] FOREIGN KEY ([FK_SpecialCategoryCatastrophe]) REFERENCES [ODS].[SpecialCategoryCatastrophe] ([PK_SpecialCategoryCatastrophe]),
    CONSTRAINT [FK_FactSpecialCategoryCatastropheMatrix_SpecialCategoryCatastropheMatrix] FOREIGN KEY ([FK_SpecialCategoryCatastropheMatrix]) REFERENCES [Red].[SpecialCategoryCatastropheMatrix] ([PK_SpecialCategoryCatastropheMatrix]),
    CONSTRAINT [UQ_FactSpecialCategoryCatastropheMatrix_LogicalKey] UNIQUE NONCLUSTERED ([FK_SpecialCategoryCatastropheMatrix] ASC, [FK_SpecialCategoryCatastrophe] ASC) WITH (FILLFACTOR = 90)
);



