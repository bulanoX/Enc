﻿CREATE TABLE [Red].[FactAcquisitionCost] (
    [FK_Section]                             BIGINT          NOT NULL,
    [FK_AcquisitionCostType]                 BIGINT          NOT NULL,
    [FK_Syndicate]                           BIGINT          NULL,
    [FK_ShareType]                           BIGINT          NOT NULL,
    [FK_ReportingCurrencyOverride]           BIGINT          NOT NULL,
    [FK_Policy]                              BIGINT          NOT NULL,
    [FK_Date]                                DATETIME        NOT NULL,
    [FK_YOA]                                 BIGINT          NOT NULL,
    [FK_SettlementCurrency]                  BIGINT          NOT NULL,
    [FK_OriginalCurrency]                    BIGINT          NOT NULL,
    [FK_LocalCurrency]                       BIGINT          NOT NULL,
    [FK_TriFocus]                            BIGINT          NOT NULL,
    [FK_EntityPerspective]                   BIGINT          NOT NULL,
    [FK_HiddenStatusFilter]                  BIGINT          NOT NULL,
    [FK_QuoteFilter]                         BIGINT          NOT NULL,
    [FK_CRMBroker]                           BIGINT          NOT NULL,
    [FK_UnderwritingPlatform]                BIGINT          NOT NULL,
    [FK_InternalWrittenBinderStatus]         BIGINT          NOT NULL,
    [SpecialPurposeSyndicateApplies]         BIT             NOT NULL,
    [InternalAcquisitionCostAmount]          NUMERIC (38, 4) NULL,
    [ExternalAcquisitionCostAmount]          NUMERIC (38, 4) NULL,
    [TotalAcquisitionCostAmount]             AS              (case when isnull([InternalAcquisitionCostAmount],[ExternalAcquisitionCostAmount]) IS NULL then NULL else isnull([InternalAcquisitionCostAmount],(0))+isnull([ExternalAcquisitionCostAmount],(0)) end),
    [FK_ServiceCompany]                      BIGINT          NOT NULL,
    [ExternalAcquisitionCostAmountExcLBSFee] NUMERIC (38, 4) NULL,
    [TaxDescription]                         NVARCHAR (255)  DEFAULT ('N/A') NOT NULL,
    [AuditModifyDateTime]                    DATETIME2 (7)   NULL,
    [AuditCreateDateTime]                    DATETIME2 (7)   DEFAULT (GETDATE()) NULL,
    [AuditModifyDetails]                     NVARCHAR (255)  NULL,
    CONSTRAINT [FK_FactAcquisitionCost_AcquisitionCostType] FOREIGN KEY ([FK_AcquisitionCostType]) REFERENCES [ODS].[AcquisitionCostType] ([PK_AcquisitionCostType]),
    CONSTRAINT [FK_FactAcquisitionCost_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_FactAcquisitionCost_Date] FOREIGN KEY ([FK_Date]) REFERENCES [ODS].[DimDate] ([PK_Date]),
    CONSTRAINT [FK_FactAcquisitionCost_EntityPerspective] FOREIGN KEY ([FK_EntityPerspective]) REFERENCES [ODS].[EntityPerspective] ([PK_EntityPerspective]),
    CONSTRAINT [FK_FactAcquisitionCost_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_FactAcquisitionCost_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_FactAcquisitionCost_LocalCurrency] FOREIGN KEY ([FK_LocalCurrency]) REFERENCES [ODS].[LocalCurrency] ([PK_LocalCurrency]),
    CONSTRAINT [FK_FactAcquisitionCost_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_FactAcquisitionCost_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_FactAcquisitionCost_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_FactAcquisitionCost_ReportingCurrencyOverride] FOREIGN KEY ([FK_ReportingCurrencyOverride]) REFERENCES [Red].[ReportingCurrencyOverride] ([PK_ReportingCurrencyOverride]),
    CONSTRAINT [FK_FactAcquisitionCost_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_FactAcquisitionCost_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_FactAcquisitionCost_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_FactAcquisitionCost_ShareType] FOREIGN KEY ([FK_ShareType]) REFERENCES [Red].[ShareType] ([PK_ShareType]),
    CONSTRAINT [FK_FactAcquisitionCost_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate]),
    CONSTRAINT [FK_FactAcquisitionCost_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_FactAcquisitionCost_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform]),
    CONSTRAINT [FK_FactAcquisitionCost_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_FactAcquisitionCost_LogicalKey] UNIQUE NONCLUSTERED ([FK_Section] ASC, [FK_EntityPerspective] ASC, [FK_AcquisitionCostType] ASC, [FK_Syndicate] ASC, [FK_ShareType] ASC, [FK_ReportingCurrencyOverride] ASC, [TaxDescription] ASC) WITH (FILLFACTOR = 90)
);





































