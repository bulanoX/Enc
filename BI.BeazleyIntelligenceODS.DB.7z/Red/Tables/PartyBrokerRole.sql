﻿CREATE TABLE [Red].[PartyBrokerRole] (
    [FK_PartyBroker]      BIGINT         NOT NULL,
    [RoleName]            VARCHAR (255)  NOT NULL,
    [AuditModifyDateTime] DATETIME2 (7)  NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]  NVARCHAR (512) NULL,
    CONSTRAINT [PK_PartyBrokerRole] PRIMARY KEY CLUSTERED ([FK_PartyBroker] ASC, [RoleName] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_PartyBrokerRole_PartyBroker] FOREIGN KEY ([FK_PartyBroker]) REFERENCES [ODS].[PartyBroker] ([PK_PartyBroker])
);



