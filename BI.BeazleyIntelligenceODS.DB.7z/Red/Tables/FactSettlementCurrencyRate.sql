﻿CREATE TABLE [Red].[FactSettlementCurrencyRate] (
    [FK_SettlementCurrency] BIGINT           NOT NULL,
    [FK_ReportingCurrency]  BIGINT           NOT NULL,
    [FK_RateType]           BIGINT           NOT NULL,
    [FK_YOA]                BIGINT           NOT NULL,
    [ExchangeRate]          DECIMAL (38, 12) NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]    NVARCHAR (255)   NULL,
    CONSTRAINT [FK_SettlementCurrencyRate_RateType] FOREIGN KEY ([FK_RateType]) REFERENCES [Red].[RateType] ([PK_RateType]),
    CONSTRAINT [FK_SettlementCurrencyRate_ReportingCurrency] FOREIGN KEY ([FK_ReportingCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_SettlementCurrencyRate_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_SettlementCurrencyRate_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_SettlementCurrencyRate_LogicalKey] UNIQUE NONCLUSTERED ([FK_SettlementCurrency] ASC, [FK_ReportingCurrency] ASC, [FK_RateType] ASC, [FK_YOA] ASC) WITH (FILLFACTOR = 90)
);

