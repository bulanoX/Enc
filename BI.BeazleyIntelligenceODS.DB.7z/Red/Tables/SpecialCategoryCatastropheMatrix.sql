﻿CREATE TABLE [Red].[SpecialCategoryCatastropheMatrix] (
    [PK_SpecialCategoryCatastropheMatrix] AS            ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([GroupId]))),(0)) PERSISTED NOT NULL,
    [GroupId]                             VARCHAR (255)  NOT NULL,
    [AuditModifyDateTime]                 DATETIME2 (7)  NULL,
    [AuditCreateDateTime]                 DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                  NVARCHAR (512) NULL,
    CONSTRAINT [PK_SpecialCategoryCatastropheMatrix] PRIMARY KEY NONCLUSTERED ([PK_SpecialCategoryCatastropheMatrix] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_SpecialCategoryCatastropheMatrix_LogicalKey] UNIQUE NONCLUSTERED ([GroupId] ASC) WITH (FILLFACTOR = 90)
);



