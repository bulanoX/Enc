﻿CREATE TABLE [Red].[FactOperationalMetric] (
    [FK_OperationalMetricID] BIGINT NOT NULL,
    [MetricValue]            INT    NULL,
    CONSTRAINT [FK_FactOperationalMetric_OperationalMetric] FOREIGN KEY ([FK_OperationalMetricID]) REFERENCES [Red].[OperationalMetric] ([PK_OperationalMetricID]),
    CONSTRAINT [UQ_FactOperationalMetric_LogicalKey] UNIQUE NONCLUSTERED ([FK_OperationalMetricID] ASC) WITH (FILLFACTOR = 90)
);

