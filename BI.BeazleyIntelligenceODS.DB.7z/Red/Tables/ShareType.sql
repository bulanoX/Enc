﻿CREATE TABLE [Red].[ShareType] (
    [PK_ShareType]  BIGINT        NOT NULL,
    [ShareTypeName] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_ShareType] PRIMARY KEY CLUSTERED ([PK_ShareType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ShareType_LogicalKey] UNIQUE NONCLUSTERED ([ShareTypeName] ASC) WITH (FILLFACTOR = 90)
);

