﻿CREATE TABLE [Red].[SpecialPurposeSyndicateBasis] (
    [PK_SpecialPurposeSyndicateBasis] BIGINT        NOT NULL,
    [SpecialPurposeSyndicateBasis]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_SpecialPurposeSyndicateBasis] PRIMARY KEY CLUSTERED ([PK_SpecialPurposeSyndicateBasis] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_SpecialPurposeSyndicateBasis_LogicalKey] UNIQUE NONCLUSTERED ([SpecialPurposeSyndicateBasis] ASC) WITH (FILLFACTOR = 90)
);

