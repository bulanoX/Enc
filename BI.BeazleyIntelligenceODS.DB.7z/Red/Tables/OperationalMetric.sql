﻿CREATE TABLE [Red].[OperationalMetric] (
    [PK_OperationalMetricID]    AS             ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((isnull(CONVERT([nvarchar](255),[MDSEntityID]),'')+isnull([EntityName],''))+isnull(CONVERT([nvarchar](255),[MDSParentEntityID]),'')))),(0)) PERSISTED NOT NULL,
    [OperationalMetricParentID] BIGINT         NULL,
    [EntityName]                NVARCHAR (255) NOT NULL,
    [MetricCalculation]         NVARCHAR (MAX) NULL,
    [MetricFormat]              NVARCHAR (255) NULL,
    [MetricDisplayOrder]        INT            NULL,
    [MDSEntityID]               INT            NULL,
    [MDSParentEntityID]         INT            NULL,
    [AuditModifyDateTime]       DATETIME2 (7)  NULL,
    [AuditCreateDateTime]       DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]        NVARCHAR (512) NULL,
    CONSTRAINT [PK_OperationalMetricID] PRIMARY KEY NONCLUSTERED ([PK_OperationalMetricID] ASC) WITH (FILLFACTOR = 90)
);



