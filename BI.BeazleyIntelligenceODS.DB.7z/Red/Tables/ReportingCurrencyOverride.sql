﻿CREATE TABLE [Red].[ReportingCurrencyOverride] (
    [PK_ReportingCurrencyOverride]  BIGINT        NOT NULL,
    [ReportingCurrencyOverrideName] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_ReportingCurrencyOverride] PRIMARY KEY CLUSTERED ([PK_ReportingCurrencyOverride] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ReportingCurrencyOverride_LogicalKey] UNIQUE NONCLUSTERED ([ReportingCurrencyOverrideName] ASC) WITH (FILLFACTOR = 90)
);

