﻿CREATE TABLE [Red].[FactSpecialPurposeSyndicateMultiplier] (
    [SpecialPurposeSyndicateApplies]    BIT              NOT NULL,
    [FK_YOA]                            BIGINT           NOT NULL,
    [FK_SpecialPurposeSyndicateBasis]   BIGINT           NOT NULL,
    [SpecialPurposeSyndicateMultiplier] NUMERIC (19, 12) NOT NULL,
    [FK_Syndicate]                      BIGINT           NULL,
    [AuditModifyDateTime]               DATETIME2 (7)    NULL,
	[AuditCreateDateTime]               DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                NVARCHAR (512)   NULL,
    CONSTRAINT [FK_SpecialPurposeSyndicateMultiplier_SpecialPurposeSyndicateBasis] FOREIGN KEY ([FK_SpecialPurposeSyndicateBasis]) REFERENCES [Red].[SpecialPurposeSyndicateBasis] ([PK_SpecialPurposeSyndicateBasis]),
    CONSTRAINT [FK_SpecialPurposeSyndicateMultiplier_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate]),
    CONSTRAINT [FK_SpecialPurposeSyndicateMultiplier_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_SpecialPurposeSyndicateMultiplier_LogicalKey] UNIQUE NONCLUSTERED ([SpecialPurposeSyndicateApplies] ASC, [FK_YOA] ASC, [FK_SpecialPurposeSyndicateBasis] ASC) WITH (FILLFACTOR = 90)
);

