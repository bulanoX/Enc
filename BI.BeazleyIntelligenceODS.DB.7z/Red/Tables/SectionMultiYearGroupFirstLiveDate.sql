﻿CREATE TABLE [Red].[SectionMultiYearGroupFirstLiveDate] (
    [FK_Section]          BIGINT         NOT NULL,
    [FK_FirstLiveDate]    DATETIME       NOT NULL,
    [AuditModifyDateTime] DATETIME2 (7)  NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]  NVARCHAR (512) NULL,
    CONSTRAINT [UQ_SectionMultiYearGroupFirstLiveDate_LogicalKey] PRIMARY KEY CLUSTERED ([FK_Section] ASC, [FK_FirstLiveDate] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionMultiYearGroupFirstLiveDate_Date] FOREIGN KEY ([FK_FirstLiveDate]) REFERENCES [ODS].[DimDate] ([PK_Date]),
    CONSTRAINT [FK_SectionMultiYearGroupFirstLiveDate_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);



