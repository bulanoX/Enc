﻿CREATE TABLE [Red].[RateType] (
    [PK_RateType]    BIGINT        NOT NULL,
    [RateType]       VARCHAR (255) NOT NULL,
    [PIMPlaceholder] INT           NULL,
    [PIMYear]        INT           NULL,
    CONSTRAINT [PK_RateType] PRIMARY KEY CLUSTERED ([PK_RateType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_RateType_RateType] UNIQUE NONCLUSTERED ([RateType] ASC) WITH (FILLFACTOR = 90)
);

