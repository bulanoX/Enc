﻿CREATE TABLE [Red].[AcquisitionCostBasis] (
    [PK_AcquisitionCostBasis]  BIGINT        NOT NULL,
    [AcquisitionCostBasisName] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_AcquisitionCostBasis] PRIMARY KEY CLUSTERED ([PK_AcquisitionCostBasis] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_AcquisitionCostBasis_LogicalKey] UNIQUE NONCLUSTERED ([AcquisitionCostBasisName] ASC) WITH (FILLFACTOR = 90)
);

