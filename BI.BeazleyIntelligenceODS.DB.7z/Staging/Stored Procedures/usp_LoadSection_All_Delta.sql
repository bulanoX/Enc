﻿CREATE PROCEDURE   [Staging].[usp_LoadSection_All_Delta]
AS
BEGIN

	DECLARE @LastAuditDate_Policy DATETIME2(7), @LastAuditDate_Section DATETIME2(7), @LastAuditDate DATETIME2(7)

	SELECT 
		@LastAuditDate_Policy = ISNULL(MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) ), '1900-01-01')
	FROM Staging.Policy

	SELECT 
		@LastAuditDate_Section = ISNULL(MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) ), '1900-01-01')
	FROM Staging.Section

	SET @LastAuditDate = CASE				
							WHEN @LastAuditDate_Policy <= @LastAuditDate_Section THEN @LastAuditDate_Policy
							ELSE @LastAuditDate_Section
						END


	drop table if exists #policy_deltas
	drop table if exists #section_deltas

	CREATE TABLE #section_deltas
	(		
		SectionSourceId VARCHAR(255) NOT NULL,
		PolicySourceId VARCHAR(255) NOT NULL,
		SourceSystem VARCHAR(255) NOT NULL,
	)

	CREATE TABLE #policy_deltas
	(		
		PolicySourceId VARCHAR(255) NOT NULL,
		SourceSystem VARCHAR(255) NOT NULL,
	)

	INSERT INTO #section_deltas
	(
		SectionSourceId, 
		PolicySourceId, 
		SourceSystem
	)

	SELECT
		SectionSourceId, PolicySourceId, SourceSystem
	FROM
		(
			SELECT
				SectionSourceId, PolicySourceId, SourceSystem
		
			FROM BeazleyIntelligenceDataContract.Outbound.vw_Section s with (nolock) 
			WHERE ISNULL(s.AuditModifyDatetime, s.AuditCreateDateTime) >= @LastAuditDate
			      OR NOT EXISTS (SELECT 1 FROM Staging.Section t where t.SectionReference = s.SectionReference )
				   

			UNION

			SELECT
				SectionSourceId, PolicySourceId, SourceSystem
			FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension s with (nolock) 
			WHERE ISNULL(s.AuditModifyDatetime, s.AuditCreateDateTime) >= @LastAuditDate
		) as t
	GROUP BY SectionSourceId, PolicySourceId, SourceSystem

	
	INSERT INTO #policy_deltas
	(
		PolicySourceId, 
		SourceSystem 
	)
	SELECT
		PolicySourceId, SourceSystem 
	FROM
		(
			select 
				PolicySourceId, SourceSystem 
			from #section_deltas
			group by PolicySourceId, SourceSystem

			UNION

			SELECT
				PolicySourceId, SourceSystem
		
			FROM BeazleyIntelligenceDataContract.Outbound.vw_Policy s with (nolock) 
			WHERE ISNULL(s.AuditModifyDatetime, s.AuditCreateDateTime) >= @LastAuditDate


			UNION

			SELECT
				PolicySourceId, SourceSystem
			FROM BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension s with (nolock) 
			WHERE ISNULL(s.AuditModifyDatetime, s.AuditCreateDateTime) >= @LastAuditDate
		) as t
		group by PolicySourceId, SourceSystem 
		

	DROP TABLE IF EXISTS #sqa

	SELECT 
		SectionSourceID				= sa.SectionSourceID
		,SourceSystem				= sa.SourceSystem
		,CreatedAt					= MIN(sa.CreatedAt)	
		into #sqa
	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionQuestionAnswer sa
	inner join #section_deltas sd	
    on sd.SectionSourceId =  sa.SectionSourceId	
    and sd.SourceSYstem = sa.SourceSystem
	GROUP BY sa.SectionSourceID, sa.SourceSystem 

	drop table if exists #temp_s
	drop table if exists #temp_se
	
	drop table if exists #temp_p
	drop table if exists #temp_pe

-- section

	SELECT 
		 s.SectionSourceId
		,PolicySourceId										= s.PolicySourceId
		,SectionReference									= s.SectionReference
		,CoverageName										= s.CoverageName
		,SectionSequenceId									= s.SectionSequenceId
		,PolicyReference									= s.PolicyReference
		,SourceSystem										= s.SourceSystem 
		,BeazleyIsAgreementParty							=  s.BeazleyIsAgreementParty
		,OfficeLocation										=  s.OfficeLocation
		,BenchmarkPremiumAmountInOriginalCCY 				=  s.BenchmarkPremiumAmountInOriginalCCY 
		,BenchmarkPremiumMultiplier							=  s.BenchmarkPremiumMultiplier
		,ClassOfBusiness									=  s.ClassOfBusiness
		,CoreAccountType									=  s.CoreAccountType
		,CoreAccountTypeCode								=  s.CoreAccountTypeCode
		,DateModified										=  s.DateModified
		,DeductibleAmountInLimitCCY							=  s.DeductibleAmountInLimitCCY
		,DeductibleQualifier								=  s.DeductibleQualifier
		,EstimatedSigningMultiplier							=  s.EstimatedSigningMultiplier
		,EventLimitAmountInLimitCCY							=  s.EventLimitAmountInLimitCCY
		,EventLimitDescription								=  s.EventLimitDescription
		,EventLimitQualifier								=  s.EventLimitQualifier
		,ExcessQualifier									=  s.ExcessQualifier
		,ExpiringSectionReference							=  s.ExpiringSectionReference
		,ExpiryDate											=  s.ExpiryDate
		,ExternalAcquisitionCostMultiplier					=  s.ExternalAcquisitionCostMultiplier
		,FacilityReference									=  s.FacilityReference
		,FirstLiveDate										=  s.FirstLiveDate
		,WrittenOrEstimatedPremiumAmountInOriginalCCY		=  s.WrittenOrEstimatedPremiumAmountInOriginalCCY 
		,WEPBasis											=  IIF(s.SourceSystem in ('Unirisx','Eurobase','BeazleyPro'), s.WEPBasis, 'Booked Premium')
		,SectionStatusCode 									=  s.SectionStatusCode 
		,InceptionDate										=  s.InceptionDate
		,TriFocus											=  s.TriFocus 
		,Interest											=  s.Interest
		,InterestCode										=  s.InterestCode
		,IsBeazleyLead										=  s.IsBeazleyLead
		,IsQuote											=  s.IsQuote
		,IsRenewal											=  s.IsRenewal
		,IsSigned											=  s.IsSigned
		,LatestEPIInOriginalCCY								=  s.LatestEPIInOriginalCCY
		,LeaderName											=  s.LeaderName
		,LeaderPseudonym									=  s.LeaderPseudonym
		,LimitAmountInLimitCCY								=  s.LimitAmountInLimitCCY
		,LimitAmountInOriginalCCY							=  s.LimitAmountInOriginalCCY
		,LimitCurrency										=  s.LimitCurrency
		,LimitQualifier										=  s.LimitQualifier
		,LimitTypeCode										=  s.LimitTypeCode
		,LimitTypeDescription								=  s.LimitTypeDescription
		,Occupation											=  s.Occupation
		,OccupationCode										=  s.OccupationCode
		,OriginalCurrency									=  s.OriginalCurrency
		,OriginalCCYToSettlementCCYRate						=  s.OriginalCCYToSettlementCCYRate
		,Peril												=  s.Peril
		,PerilCode											=  s.PerilCode
		,ExcessAmountInLimitCCY								=  s.ExcessAmountInLimitCCY 
		,ProductName										=  s.ProductName
		,QuoteOrBindDate									=  s.QuoteOrBindDate
		,RateChangeMultiplier								= s.RateChangeMultiplier
		,SectionStatus										= s.SectionStatus
		,SettlementCurrency									= s.SettlementCurrency
		,SignedLineMultiplier								= s.SignedLineMultiplier
		,SignedOrderMultiplier								= s.SignedOrderMultiplier
		,StatsCode	 										= s.StatsCode
		,StatsDescription									= s.StatsDescription
		,TechnicalPremium									= s.TechnicalPremiumMultiplier
		,TermsOfTradeDate									= s.TermsOfTradeDate
		,TotalSIExposureOurShare							= s.TotalSIExposureOurShare
		,UnderwritingPlatformCode							= s.UnderwritingPlatformCode
		,WrittenIfNotSignedLineMultiplier					= s.WrittenIfNotSignedLineMultiplier
		,WrittenLineMultiplier								= s.WrittenLineMultiplier
		,WrittenOrderMultiplier								= s.WrittenOrderMultiplier
		,InsuredCity										= s.InsuredCity
		,InsuredState										= s.InsuredState
		,InsuredCountry										= s.InsuredCountry
		,InsuredParty										= s.InsuredParty
		,UnderwriterName									= s.UnderwriterName
		,s.Trifocuscode
		,s.HashbytesId
		into #temp_s

	FROM BeazleyIntelligenceDataContract.Outbound.vw_Section s with (nolock)  
	
	    INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension  se with (nolock) 
		ON s.SourceSystem = se.SourceSystem
		AND s.SectionSourceId = se.SectionSourceId
		 
		INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Policy p with (nolock)
		ON p.SourceSystem = se.SourceSystem
		AND p.PolicySourceId = se.PolicySourceId

		INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension  pe with (nolock) 
		ON p.SourceSystem = pe.SourceSystem 
		AND p.PolicySourceId = pe.PolicySourceId 
	
		INNER JOIN #section_deltas sd
		ON sd.SectionSourceId = s.SectionSourceId
		AND sd.SourceSystem = s.SourceSystem
		

--section extension
	SELECT 
		se.SectionSourceId
		,se.SourceSystem
		,se.AreaCode
		,SectionReference									=  se.SectionReference
		,FullQuoteReference									= se.FullQuoteReference
		,SectionDescription									= se.SectionDescription
		,AccountHandler										= se.AccountHandler	
		,ATIAClassOfBusiness								= se.ATIAClassOfBusiness
		,AdditionalExposures								= se.AdditionalExposures
		,AdjustmentBaseAmountInOriginalCCY					= se.AdjustmentBaseAmountInOriginalCCY
		,AdjustmentMultiplier								= se.AdjustmentMultiplier
		,AdjustmentPremiumAmountInOriginalCCY				= se.AdjustmentPremiumAmountInOriginalCCY
		,AdminPurposesFlag									= se.AdminPurposesFlag
		,AggregateAmountInOriginalCCY						= se.AggregateAmountInOriginalCCY
		,AggregateQualifier									= se.AggregateQualifier
		,AggregatesRequired									= se.AggregatesRequired
		,AgressoReference									= se.AgressoReference
		,Area												= se.Area
		,BenchmarkDate										= se.BenchmarkDate
		,BIDeductible										= se.BIDeductible
		,Billings											= se.Billings
		,BinderType											= se.BinderType
		,BreachResponseMultiplier							= se.BreachResponseMultiplier
		,BreachResponseParentSection						= se.BreachResponseParentSection
		,CancelledDate										= se.CancelledDate
		,CancelledReason									= se.CancelledReason
		,CapitaEntryTimeHours								= se.CapitaEntryTimeHours
		,CapitaQCTimeHours									= se.CapitaQCTimeHours		
		,CarrierIndicator									= se.CarrierIndicator
		,CheckStatusCode									= se.CheckStatusCode
		,CIPsRiskCode                                       = se.CIPsRiskCode
		,ClaimBasis											= se.ClaimBasis
		,ClaimBasisCode										= se.ClaimBasisCode
		,ClaimDelegatedTo									= se.ClaimDelegatedTo
		,ClientClassificationCode							= se.ClientClassificationCode
		,Comments											= se.Comments
		,Conditions											= se.Conditions
		,ConditionsCode										= se.ConditionsCode
		,ConstructionPeriodFrom								= se.ConstructionPeriodFrom
		,ConstructionPeriodTo								= se.ConstructionPeriodTo
		,ConstructionTitle									= se.ConstructionTitle
		,ConstructionDays									= se.ConstructionDays
		,ConstructionMonths									= se.ConstructionMonths
		,ContractCertaintyControlsCompliantDate				= se.ContractCertaintyControlsCompliantDate
		,ContractCertaintyEnteredDate						= se.ContractCertaintyEnteredDate
		,ContractCertaintyFullyCompliantDate				= se.ContractCertaintyFullyCompliantDate
		,ContractCertaintyModifiedDate						= se.ContractCertaintyModifiedDate
		,ContractCertaintyPostBindComplete					= se.ContractCertaintyPostBindComplete
		,ContractCertaintyPreBindComplete					= se.ContractCertaintyPreBindComplete
		,ContractCertaintyPreBindSignatureDate 				= se.ContractCertaintyPreBindSignatureDate 
		,ContractCertaintyPrimaryCompleteDate				= se.ContractCertaintyPrimaryCompleteDate
		,ContractCertaintyQuestionNote						= se.ContractCertaintyQuestionNote
		,IsPrimarySection									= se.IsPrimarySection
		,se.InsuredItemNarrative
		,ContractCertaintyStatus							= se.ContractCertaintyStatus
		,ContractCertaintyStatusSortOrder					= se.ContractCertaintyStatusSortOrder
		,Country											= se.Country
		,CountryCode										= se.CountryCode
		,CoverageForm										= se.CoverageForm
		,CoverageSolution									= se.CoverageSolution
		,CoverType											= se.CoverType
		,CrossSelling										= se.CrossSelling
		,CrossSellingInitiator								= se.CrossSellingInitiator
		,DaysBetweenConstructionPhaseToandFrom				= se.DaysBetweenConstructionPhaseToandFrom
		,DaysBetweenMaintenanceFromAndTo					= se.DaysBetweenMaintenanceFromAndTo
		,DaysBetweenTestingFromAndTo						= se.DaysBetweenTestingFromAndTo
		,DeclarationWEPAmountInOriginalCCY					= se.DeclarationWEPAmountInOriginalCCY
		,DelegatedClaimsAuthority							= se.DelegatedClaimsAuthority
		,DepositPremiumAmountInOriginalCCY					= se.DepositPremiumAmountInOriginalCCY
		,EngineeringProjectName								= se.EngineeringProjectName
		,EngineeringSumInsuredInLimitCCY					= se.EngineeringSumInsuredInLimitCCY
		,EquipmentBreakdownContactName						= se.EquipmentBreakdownContactName
		,EquipmentBreakdownContactNumber					= se.EquipmentBreakdownContactNumber
		,EquipmentBreakdownReferral							= se.EquipmentBreakdownReferral
		,ESGPolicyFlag		    							= se.ESGPolicyFlag
		,ExpensesMultiplier                                 = se.ExpensesMultiplier
		,FACRIIndicator										= se.FACRIIndicator
		,Fees												= se.Fees
		,FullTimeEquivalents								= se.FullTimeEquivalents
		,GulfOfMexicoRiskPremiumMultiplier					= se.GulfOfMexicoRiskPremiumMultiplier
		,GulfOfMexicoWindstormMultiplier					= se.GulfOfMexicoWindstormMultiplier
		,HasConsortiumLink									= se.HasConsortiumLink 
		,HasMultiYearLink									= se.HasMultiYearLink
		,HasParentLink                                      = se.HasParentLink
		,HazardClass										= se.HazardClass
		,se.OriginatingSourceSystem 
		,se.HiddenStatusFilter
		,ITVPerSQFT											= se.ITVPerSQFT
		,IncludeInMunichStacking							= se.IncludeInMunichStacking
		,IncludePML											= se.IncludePML
		,Industry											= se.Industry
		,IndustryCode										= se.IndustryCode
		,IndustryCodeQualifier								= se.IndustryCodeQualifier
		,InnovationCampaign									= se.InnovationCampaign
		,InnovationPremiumMultiplier						= se.InnovationPremiumMultiplier													
		,InwardQuotaShareMultiplier							= se.InwardQuotaShareMultiplier
		,IsBreachResponseDummy								= se.IsBreachResponseDummy
		,IsPolicyholderAPrivateIndividual					= se.IsPolicyholderAPrivateIndividual
		,IsRapidRenewal										= se.IsRapidRenewal
		,IsSynergySection									= se.IsSynergySection
		,KeyLocationAddress1								= se.KeyLocationAddress1
		,KeyLocationAddress2								= se.KeyLocationAddress2
		,KeyLocationCity									= se.KeyLocationCity
		,KeyLocationCountry									= se.KeyLocationCountry
		,KeyLocationState									= se.KeyLocationState
		,KeyLocationStreetNumber							= se.KeyLocationStreetNumber
		,KeyLocationZipCode									= se.KeyLocationZipCode
		,UnderwriterLargeRiskReviewer						= se.UnderwriterLargeRiskReviewer
		,LimitCCYToSettlementCCYRateCurrent					= se.LimitCCYToSettlementCCYRateCurrent
		,LimitCCYToSettlementCCYRateMelded					= se.LimitCCYToSettlementCCYRateMelded
		,LimitDescription									= se.LimitDescription
		,LimitMeldedRate									= se.LimitMeldedRate
		,LinkedConsortiumReference							= se.LinkedConsortiumReference
		,LinkedESGBinderReference							= se.LinkedESGBinderReference
		,LinkedESGSectionReference							= se.LinkedESGSectionReference
		,LinkedNonSynergySectionReference					= se.LinkedNonSynergySectionReference
		,LinkedParentReference                              = se.LinkedParentReference
		,LinkedSynergySectionReference						= se.LinkedSynergySectionReference
		,LloydsClassOfBusiness								= se.LloydsClassOfBusiness				
		,LloydsClassOfBusinessCode							= se.LloydsClassOfBusinessCode
		,LocalCurrency										= se.LocalCurrency
		,MailingAddress1									= se.MailingAddress1
		,MailingAddress2									= se.MailingAddress2
		,MailingCity										= se.MailingCity
		,MailingState										= se.MailingState
		,MailingZipCode										= se.MailingZipCode
		,MaintenancePeriodFrom								= se.MaintenancePeriodFrom
		,MaintenancePeriodTo								= se.MaintenancePeriodTo
		,MaintenanceMonths									= se.MaintenanceMonths
		,MASTerritory										= se.MASTerritory
		,MarketCapitalisation								= se.MarketCapitalisation
		,MigratedPolicy										= se.MigratedPolicy
		,MinimumPremiumAmountInOriginalCCY					= se.MinimumPremiumAmountInOriginalCCY
		,MultiYearGroupReference							= se.MultiYearGroupReference
		,MultiYearIndicator									= se.MultiYearIndicator
		,NewConditionsExpiryDate							= se.NewConditionsExpiryDate
		,NotifiedIndividuals								= se.NotifiedIndividuals
		,NotifiedIndividualsName							= se.NotifiedIndividualsName
		,NumberOfEmployees									= se.NumberOfEmployees
		,NumberOfLawyers									= se.NumberOfLawyers
		,NumberOfLives										= se.NumberOfLives
		,NumberOfLocations									= se.NumberOfLocations
		,NumberOfReinstatements								= se.NumberOfReinstatements
		,Obligor											= se.Obligor
		,ObligorOccupation									= se.ObligorOccupation
		,ObligorOccupationCode 								= se.ObligorOccupationCode 
		,OriginalCCYToLocalCCYRate							= se.OriginalCCYToLocalCCYRate
		,OriginalCoverageName								= se.OriginalCoverageName
		,OriginalEPIAmountInOriginalCCY						= se.OriginalEPIAmountInOriginalCCY
		,OriginalEPITotalAcquisitionCostMultiplier			= se.OriginalEPITotalAcquisitionCostMultiplier
		,OriginalGrossPremiumAmountInOriginalCCY			= se.OriginalGrossPremiumAmountInOriginalCCY
		,OriginalInsured									= se.OriginalInsured
		,OriginalInsuredArea								= se.OriginalInsuredArea
		,OriginalInsuredAreaCode							= se.OriginalInsuredAreaCode
		,OriginalLimitAmountInOriginalCCY					= se.OriginalLimitAmountInOriginalCCY
		,PDDeductible										= se.PDDeductible
		,PDSI												= se.PDSI 
		,PMLExposure										= se.PMLExposure
		,PMLExposureOurShareUSD								= se.PMLExposureOurShareUSD
		,PMLExposure100PerctShareUSD						= se.PMLExposure100PerctShareUSD
		,PMLExposure100PerctShareOrigCcy					= se.PMLExposure100PerctShareOrigCcy
		,PMLPercentage                                      = se.PMLPercentage
		,TSI100PercForPMLOrigCcy							= se.TSI100PercForPMLOrigCcy
        ,PolicyRate                                         = se.PolicyRate
		,PremiumIncomeLimitAmountInOriginalCCY				= se.PremiumIncomeLimitAmountInOriginalCCY
		,PremiumRates										= se.PremiumRates
		,PrimaryLegacyReference								= se.PrimaryLegacyReference
		,PrimaryOrExcess									= se.PrimaryOrExcess
		,PrimarySectionURL									= se.PrimarySectionURL
		,PrimarySectionURLLabel								= se.PrimarySectionURLLabel	
		,ProductIsMultiTransactional						= se.ProductIsMultiTransactional
		,ProfitCommissionMultiplier							= se.ProfitCommissionMultiplier
		,ProgramName  										= se.ProgramName  
		,ProgramNumber										= se.ProgramNumber
		,ProgramPeriod										= se.ProgramPeriod
		,ProgramType										= se.ProgramType
		,ProgramYear										= se.ProgramYear
		,QuoteBoundSectionReference							= se.QuoteBoundSectionReference
		,QuoteDaysValid										= se.QuoteDaysValid
		,QuoteLapsedDate									= se.QuoteLapsedDate
		,RateChangeControlComplete							= se.RateChangeControlComplete
		,RateChangeDate										= se.RateChangeDate
		,RateChangeDeductibleMultiplier						= se.RateChangeDeductibleMultiplier
		,RateChangeExposureMultiplier						= se.RateChangeExposureMultiplier
		,RateChangeLimitMultiplier							= se.RateChangeLimitMultiplier
		,RateChangeMethod									= se.RateChangeMethod
		,RateChangeOtherMultiplier							= se.RateChangeOtherMultiplier
		,RateChangeRiskMultiplier							= se.RateChangeRiskMultiplier
		,RateChangeTermsAndConditionsMultiplier				= se.RateChangeTermsAndConditionsMultiplier
		,RateOnLineEnteredMultiplier						= se.RateOnLineEnteredMultiplier
		,RateOnLinePremiumEnteredInOriginalCCY				= se.RateOnLinePremiumEnteredInOriginalCCY
		,RationaleQuestionnaireComplete						= se.RationaleQuestionnaireComplete
		,RationaleQuestionnaireDate							= se.RationaleQuestionnaireDate
		,ReSigningIndicator									= se.ReSigningIndicator
		,ReactivationReason									= se.ReactivationReason
		,ReactivationReasonCode								= se.ReactivationReasonCode
		,ReinstatementMultiplier							= se.ReinstatementMultiplier
		,ReinstatementPremiumAmountInOriginalCCY			= se.ReinstatementPremiumAmountInOriginalCCY
		,ReinsuranceIndicator								= se.ReinsuranceIndicator
		,RetroInceptionDate									= se.RetroInceptionDate
		,Revenues											= se.Revenues
		,RiskClassDescription								= se.RiskClassDescription
		,RiskClassCode										= se.RiskClassCode
		,SICCode											= se.SICCode
		,SigningNumberDate                                  = se.SigningNumberDate 
		,SLSpecificCoverage									= se.SLSpecificCoverage
		,ReKeyReference										= se.ReKeyReference 
		,ReKeySource										= se.ReKeySource
		,SecondarySectionURL								= se.SecondarySectionURL
		,SecondarySectionURLLabel							= se.SecondarySectionURLLabel
		,SectionReferenceCOBCode							= se.SectionReferenceCOBCode
		,SectionReferenceReinsuranceIndicator				= se.SectionReferenceReinsuranceIndicator
		,SectionReferenceSectionIdentifier					= se.SectionReferenceSectionIdentifier
		,ServiceCompanyCode									= se.ServiceCompanyCode	
		,SpecialPurposeSyndicateApplies						= se.SpecialPurposeSyndicateApplies						
		,SubmissionDate										= se.SubmissionDate
		,SwordTreatyCoverage								= se.SwordTreatyCoverage
		,TerritorialFocusGroup								= se.TerritorialFocusGroup
		,TerrorismReference									= se.TerrorismReference
		,TestingPeriodFrom									= se.TestingPeriodFrom
		,TestingPeriodTo									= se.TestingPeriodTo
		,TestingMonths										= se.TestingMonths
		,TimeExcess											= se.TimeExcess
		,TimeExcessAmount									= se.TimeExcessAmount
		,TopLocationTSI										= se.TopLocationTSI
		,TotalSumInsured									= se.TotalSumInsured
		,TransactionLiabilityProject						= se.TransactionLiabilityProject
		,TransactionTypeCode								= se.TransactionTypeCode			 
	    ,TransactionTypeDescription							= se.TransactionTypeDescription
		,TransactionValue									= se.TransactionValue				
		,UltimateLossRatioMultiplier						= se.UltimateLossRatioMultiplier
		,UnderwriterAssistant								= se.UnderwriterAssistant
		,UnderwriterAssistantContractCertainty				= se.UnderwriterAssistantContractCertainty
		,UnderwriterContractCertainty						= se.UnderwriterContractCertainty
		,UnderwriterUserInitials							= se.UnderwriterUserInitials
		,USUnderwritingCoverageCode							= se.USUnderwritingCoverageCode
		,VATNumber                                          = se.VATNumber
		,WEPLastUpdatedDate									= se.WEPLastUpdatedDate
		,AdditionalInsuredParty								= se.AdditionalInsuredParty
		,BrokerNoticeOfClaim								= se.BrokerNoticeOfClaim
		,PlacingBrokerContact								= se.PlacingBrokerContact
		,PlacingBrokerNumber								= se.PlacingBrokerNumber
		,ProducingBrokerContact								= se.ProducingBrokerContact
		,ProducingBrokerNumber								= se.ProducingBrokerNumber
		,ReinsuredParty										= se.ReinsuredParty
		,BrokerServiceOfSuit								= se.BrokerServiceOfSuit
		,UniqueMarketReference								= se.UniqueMarketReference
		,YearOfAccount										= se.YearOfAccount
		,UnderwriterRiskEnteredBy							= UnderwriterRiskEnteredBy
		,BenchmarkApplies									= BenchmarkApplies
		,NoticeDate											= se.NoticeDate
		,NotificationThreshold								= se.NotificationThreshold
		,TacitRenewal										= se.TacitRenewal
		,RatingAdequacyMultiplier							= se.RatingAdequacyMultiplier
		into #temp_se		

	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension se with (nolock)
	Inner join #section_deltas sd
		on sd.SectionSourceId = se.SectionSourceId
		and sd.SourceSystem = se.SourceSystem
		
	

-- policy extension

	SELECT 
		 PolicySourceId									= pe.PolicySourceId
		,pe.SourceSystem
		,MethodOfPlacementCode								= pe.MethodOfPlacementCode
		,InsuranceType										= pe.InsuranceType 
		,pe.OriginatingSourceSystem
		into #temp_pe

	FROM BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension pe with (nolock)
		
		INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Policy p with (nolock)
		ON p.SourceSystem = pe.SourceSystem 
		AND p.PolicySourceId = pe.PolicySourceId 
	
		INNER JOIN #policy_deltas sd
		ON sd.PolicySourceId = pe.PolicySourceId
		AND sd.SourceSystem = pe.SourceSystem

    
-- policy 	
	SELECT 
		 p.PolicySourceId
		,p.SourceSystem
		,p.PolicyReference
		,p.IsQuote
		,p.YearofAccount
		,p.InsuredName
		into #temp_p

	FROM BeazleyIntelligenceDataContract.Outbound.vw_Policy p with (nolock)
	
	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension pe with (nolock)
	ON p.SourceSystem = pe.SourceSystem 
	AND p.PolicySourceId = pe.PolicySourceId 
		
	INNER JOIN #policy_deltas sd
	ON sd.PolicySourceId = p.PolicySourceId
	AND sd.SourceSystem = p.SourceSystem



		CREATE INDEX IX_tmpPolicy_PolicySourceId ON #temp_p (PolicySourceId, SourceSystem)

        CREATE INDEX IX_tmpPolicyExtension_PolicySourceId ON #temp_pe (PolicySourceId, SourceSystem)
	
        CREATE INDEX IX_tmpSection_SectionSourceId ON #temp_s (SectionSourceId, SourceSystem)

        CREATE INDEX IX_tmpSectionExtension_SectionSourceId ON #temp_se (SectionSourceId, SourceSystem)
	
        CREATE INDEX IX_tmpSection_PolicySourceId ON #temp_s (PolicySourceId, SourceSystem)


	
	TRUNCATE TABLE Staging.Section_All	

	INSERT INTO Staging.Section_All	
	(
		 SectionReference								
		,FullQuoteReference								
		,SectionDescription								
		,CoverageName									
		,SectionSequenceId								
		,PolicyReference	
		,AccountHandler
		,ATIAClassOfBusiness							
		,AdditionalExposures							
		,AdjustmentBaseAmountInOriginalCCY				
		,AdjustmentMultiplier							
		,AdjustmentPremiumAmountInOriginalCCY			
		,AdminPurposesFlag								
		,AggregateAmountInOriginalCCY					
		,AggregateQualifier								
		,AggregatesRequired								
		,AgressoReference								
		,Area											
		,BeazleyIsAgreementParty						
		,OfficeLocation									
		,BenchmarkDate									
		,SourceSystem									
		,WrittenOrEstimatedPremiumAmountInOriginalCCY	
		,WEPBasis
		,BenchmarkMultiplier							
		,BenchmarkPremiumAmountInOriginalCCY 			
		,BenchmarkPremiumMultiplier						
		,BIDeductible									
		,Billings										
		,BinderType										
		,BreachResponseMultiplier						
		,BreachResponseParentSection	
		,CancelledDate
		,CancelledReason		
		,CapitaEntryTimeHours							
		,CapitaQCTimeHours		
		,CarrierIndicator
		,CheckStatusCode
		,CIPsRiskCode								
		,ClaimBasis										
		,ClaimBasisCode		
		,ClaimDelegatedTo
		,ClassOfBusiness								
		,ClientClassificationCode
		,Comments
		,Conditions										
		,ConditionsCode	
		,ConstructionPeriodFrom
		,ConstructionPeriodTo							
		,ConstructionTitle				
		,ConstructionDays	
		,ConstructionMonths
		,ContractCertaintyControlsCompliantDate			
		,ContractCertaintyEnteredDate					
		,ContractCertaintyFullyCompliantDate			
		,ContractCertaintyModifiedDate					
		,ContractCertaintyPostBindComplete				
		,ContractCertaintyPreBindComplete				
		,ContractCertaintyPreBindSignatureDate 			
		,ContractCertaintyPrimaryCompleteDate			
		,ContractCertaintyQuestionNote					
		,IsPrimarySection								
		,InsuredItem									
		,ContractCertaintyStatus						
		,ContractCertaintyStatusSortOrder				
		,CoreAccountType								
		,CoreAccountTypeCode							
		,Country										
		,CountryCode									
		,CoverageForm	
		,CoverageSolution
		,CoverType										
		,CrossSelling									
		,CrossSellingInitiator							
		,DateModified									
		,DaysBetweenConstructionPhaseToandFrom			
		,DaysBetweenMaintenanceFromAndTo				
		,DaysBetweenTestingFromAndTo					
		,DeclarationWEPAmountInOriginalCCY		
		,DelegatedClaimsAuthority
		,DeductibleAmountInLimitCCY						
		,DeductibleQualifier							
		,DepositPremiumAmountInOriginalCCY				
		,EngineeringProjectName							
		,EngineeringSumInsuredInLimitCCY				
		,EquipmentBreakdownContactName					
		,EquipmentBreakdownContactNumber				
		,EquipmentBreakdownReferral	
		,ESGPolicyFlag
		,EstimatedSigningMultiplier						
		,EventLimitAmountInLimitCCY						
		,EventLimitDescription							
		,EventLimitQualifier							
		,ExcessAmountInLimitCCY							
		,ExcessQualifier	
		,ExpensesMultiplier
		,ExpiringSectionReference						
		,ExpiryDate										
		,ExternalAcquisitionCostMultiplier				
		,FACRIIndicator									
		,FacilityReference								
		,Fees											
		,FirstLiveDate									
		,FullTimeEquivalents							
		,GulfOfMexicoRiskPremiumMultiplier				
		,GulfOfMexicoWindstormMultiplier	
		,HasConsortiumLink 
		,HasMultiYearLink	
		,HasParentLink
		,HazardClass									
		,HiddenStatusFilter								
		,SectionStatusCode 								
		,ITVPerSQFT										
		,InceptionDate									
		,IncludeInMunichStacking
		,IncludePML
		,Industry										
		,IndustryCode									
		,IndustryCodeQualifier							
		,InnovationCampaign								
		,InnovationPremiumMultiplier					
		,Interest										
		,InterestCode									
		,InwardQuotaShareMultiplier						
		,IsBeazleyLead									
		,IsBreachResponseDummy	
		,IsPolicyholderAPrivateIndividual						
		,IsQuote										
		,IsRenewal										
		,IsRapidRenewal									
		,IsSigned										
		,IsSynergySection								
		,KeyLocationAddress1							
		,KeyLocationAddress2							
		,KeyLocationCity								
		,KeyLocationCountry								
		,KeyLocationState								
		,KeyLocationStreetNumber						
		,KeyLocationZipCode								
		,UnderwriterLargeRiskReviewer					
		,LatestEPIInOriginalCCY							
		,LeaderName										
		,LeaderPseudonym								
		,LimitAmountInLimitCCY							
		,LimitAmountInOriginalCCY						
		,LimitCurrency									
		,LimitCCYToSettlementCCYRateCurrent				
		,LimitCCYToSettlementCCYRateMelded				
		,LimitDescription								
		,LimitMeldedRate								
		,LimitQualifier
		,LimitTypeCode
		,LimitTypeDescription
		,LinkedConsortiumReference
		,LinkedESGBinderReference
		,LinkedESGSectionReference
		,LinkedNonSynergySectionReference	
		,LinkedParentReference
		,LinkedSynergySectionReference					
		,LloydsClassOfBusiness							
		,LloydsClassOfBusinessCode						
		,LocalCurrency									
		,MailingAddress1								
		,MailingAddress2								
		,MailingCity									
		,MailingState									
		,MailingZipCode									
		,MaintenancePeriodFrom							
		,MaintenancePeriodTo		
		,MaintenanceMonths
		,MASTerritory									
		,MarketCapitalisation							
		,MigratedPolicy									
		,MinimumPremiumAmountInOriginalCCY				
		,MultiYearGroupReference						
		,MultiYearIndicator		
		,NewConditionsExpiryDate
		,NotifiedIndividuals							
		,NotifiedIndividualsName						
		,NumberOfEmployees								
		,NumberOfLawyers								
		,NumberOfLives										
		,NumberOfLocations									
		,NumberOfReinstatements							
		,Obligor										
		,ObligorOccupation								
		,ObligorOccupationCode 							
		,Occupation										
		,OccupationCode									
		,OriginalCurrency								
		,OriginalCCYToLocalCCYRate						
		,OriginalCCYToSettlementCCYRate					
		,OriginalCoverageName							
		,OriginalEPIAmountInOriginalCCY					
		,OriginalEPITotalAcquisitionCostMultiplier		
		,OriginalGrossPremiumAmountInOriginalCCY		
		,OriginalInsured								
		,OriginalInsuredArea							
		,OriginalInsuredAreaCode						
		,OriginalLimitAmountInOriginalCCY				
		,OriginatingSourceSystem						
		,PDDeductible				
		,PDSI
		,PMLExposure	
		,PMLExposureOurShareUSD		
		,PMLExposure100PerctShareUSD	
		,PMLExposure100PerctShareOrigCcy
		,PMLPercentage  
		,TSI100PercForPMLOrigCcy
        ,PolicyRate                                          
		,Peril											
		,PerilCode										
		,PremiumIncomeLimitAmountInOriginalCCY			
		,PremiumRates	
		,PrimaryLegacyReference
		,PrimaryOrExcess								
		,PrimarySectionURL								
		,PrimarySectionURLLabel							
		,ProductName									
		,ProductIsMultiTransactional					
		,ProfitCommissionMultiplier						
		,ProgramName  									
		,ProgramNumber									
		,ProgramPeriod									
		,ProgramType
		,ProgramYear
		,QuoteBoundSectionReference						
		,QuoteDaysValid									
		,QuoteLapsedDate								
		,QuoteOrBindDate		
		,RatingAdequacyMultiplier
		,RateChangeControlComplete						
		,RateChangeDate									
		,RateChangeDeductibleMultiplier					
		,RateChangeExposureMultiplier					
		,RateChangeLimitMultiplier						
		,RateChangeMethod								
		,RateChangeMultiplier							
		,RateChangeOtherMultiplier						
		,RateChangeRiskMultiplier						
		,RateChangeTermsAndConditionsMultiplier			
		,RateOnLineEnteredMultiplier					
		,RateOnLinePremiumEnteredInOriginalCCY			
		,RationaleQuestionnaireComplete					
		,RationaleQuestionnaireDate						
		,ReSigningIndicator								
		,ReactivationReason								
		,ReactivationReasonCode							
		,ReinstatementMultiplier						
		,ReinstatementPremiumAmountInOriginalCCY		
		,ReinsuranceIndicator							
		,RetroInceptionDate								
		,Revenues										
		,RiskClassDescription							
		,RiskClassCode									
		,SICCode
		,SigningNumberDate
		,SLSpecificCoverage		
		,ReKeyReference 
		,ReKeySource
		,SecondarySectionURL							
		,SecondarySectionURLLabel						
		,SectionReferenceCOBCode						
		,SectionReferenceReinsuranceIndicator			
		,SectionReferenceSectionIdentifier				
		,SectionStatus									
		,ServiceCompanyCode								
		,SettlementCurrency								
		,SignedLineMultiplier							
		,SignedOrderMultiplier							
		,SpecialPurposeSyndicateApplies					
		,StatsCode										
		,StatsDescription								
		,SubmissionDate									
		,SwordTreatyCoverage	
		,TechnicalPremium
		,TermsOfTradeDate	
		,TotalSIExposureOurShare
		,TerritorialFocusGroup
		,TerrorismReference								
		,TestingPeriodFrom								
		,TestingPeriodTo	
		,TestingMonths
		,TimeExcess		
		,TimeExcessAmount
		,TopLocationTSI									
		,TotalSumInsured								
		,TransactionLiabilityProject	
		,TransactionTypeCode	 
	    ,TransactionTypeDescription
		,TransactionValue								
		,Trifocus										
		,UltimateLossRatioMultiplier					
		,UnderwriterAssistantContractCertainty			
		,UnderwriterContractCertainty					
		,UnderwriterUserInitials						
		,UnderwritingPlatformCode						
		,USUnderwritingCoverageCode
		,VATNumber						
		,WEPLastUpdatedDate								
		,WrittenIfNotSignedLineMultiplier				
		,WrittenLineMultiplier							
		,MethodOfPlacementCode							
		,InsuranceType									
		,WrittenOrderMultiplier							
		,AdditionalInsuredParty							
		,InsuredCity									
		,InsuredState									
		,InsuredCountry									
		,InsuredParty									
		,BrokerNoticeOfClaim							
		,PlacingBrokerContact							
		,PlacingBrokerNumber							
		,ProducingBrokerContact							
		,ProducingBrokerNumber							
		,ReinsuredParty									
		,BrokerServiceOfSuit							
		,UniqueMarketReference							
		,YearOfAccount	
		,UnderwriterAssistant
		,UnderwriterName								
		,UnderwriterRiskEnteredBy						
		,BenchmarkApplies								
		,DocumentSignedDate								
		,CreatedAt										
		,TrifocusName									
		,Division										
		,StatusName
		,StatusCode
		,HashbytesId
		,TechnologyCoverageName							
		,ClassifiedAsTechnology							
		,CapitaTotalTimeHours							
		,LiveStatus										
		,TermsOfTradeExpired							
		,TotalWrittenMultiplier		
		,TotalSignedMultiplier							
		,WrittenIfNotSignedOrderMultiplier				
		,TotalWrittenIfNotSignedMultiplier				
		,DurationMonths									
		--,DaysSinceQuoteOrBindDate						
		--,DaysBetweenQBAndRateChangeDate					
		--,DaysBetweenQBAndBenchmarkDate					
		,MonthsSinceInception							
		,MonthsSinceTOT									
		,DaysBetweenQBAndCCCCDateOrToday				
		,DaysBetweenQBAndCCFCDateOrToday				
		,DaysBetweenQBAndCCPCDateOrToday				
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday			
		,NoticeDate										
		,NotificationThreshold							
		,TacitRenewal									
		,PriorityDelete									
	)
	SELECT 
		 SectionReference									=  s.SectionReference
		,FullQuoteReference									= se.FullQuoteReference
		,SectionDescription									= se.SectionDescription
		,CoverageName										= s.CoverageName
		,SectionSequenceId									= s.SectionSequenceId
		,PolicyReference									= s.PolicyReference
		,AccountHandler										= se.AccountHandler
		,ATIAClassOfBusiness								= se.ATIAClassOfBusiness
		,AdditionalExposures								= se.AdditionalExposures
		,AdjustmentBaseAmountInOriginalCCY					= se.AdjustmentBaseAmountInOriginalCCY
		,AdjustmentMultiplier								= se.AdjustmentMultiplier
		,AdjustmentPremiumAmountInOriginalCCY				= se.AdjustmentPremiumAmountInOriginalCCY
		,AdminPurposesFlag									= se.AdminPurposesFlag
		,AggregateAmountInOriginalCCY						= se.AggregateAmountInOriginalCCY
		,AggregateQualifier									= se.AggregateQualifier
		,AggregatesRequired									= se.AggregatesRequired
		,AgressoReference									= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN
																	CASE WHEN p.IsQuote = 0 THEN p.PolicyReference 
																	ELSE NULL
																	END
																	ELSE  se.AgressoReference
																END
		,Area												= CASE 
																	WHEN s.SourceSystem in ('BeazleyPro', 'StagingDataContract') THEN se.AreaCode
																	ELSE se.Area
																END
		,BeazleyIsAgreementParty							=  CASE
																	WHEN s.SourceSystem = 'BeazleyPro' THEN 'Yes'
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
																	ELSE s.BeazleyIsAgreementParty
																END
		,OfficeLocation										=  s.OfficeLocation
		,BenchmarkDate										=  se.BenchmarkDate
		,SourceSystem										=  s.SourceSystem
		,WrittenOrEstimatedPremiumAmountInOriginalCCY		=  s.WrittenOrEstimatedPremiumAmountInOriginalCCY
		,WEPBasis											=  s.WEPBasis
		,BenchmarkMultiplier								= CASE 
																	WHEN s.SourceSystem = 'BeazleyPro' THEN s.BenchmarkPremiumMultiplier
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 1 / Utility.udf_ProcessPercentage(s.BenchmarkPremiumMultiplier, 0, 0, 1)
																	ELSE NULL
																END
		,BenchmarkPremiumAmountInOriginalCCY 				=  s.BenchmarkPremiumAmountInOriginalCCY 
		,BenchmarkPremiumMultiplier							=  s.BenchmarkPremiumMultiplier
		,BIDeductible										= se.BIDeductible
		,Billings											= se.Billings
		,BinderType											= se.BinderType
		,BreachResponseMultiplier							= se.BreachResponseMultiplier
		,BreachResponseParentSection						= se.BreachResponseParentSection
		,CancelledDate										= se.CancelledDate
		,CancelledReason									= se.CancelledReason
		,CapitaEntryTimeHours								= se.CapitaEntryTimeHours
		,CapitaQCTimeHours									= se.CapitaQCTimeHours		
		,CarrierIndicator									= se.CarrierIndicator
		,CheckStatusCode									= se.CheckStatusCode
		,CIPsRiskCode                                       = se.CIPsRiskCode
		,ClaimBasis											= se.ClaimBasis
		,ClaimBasisCode										= se.ClaimBasisCode
		,ClaimDelegatedTo									= se.ClaimDelegatedTo
		,ClassOfBusiness									=  s.ClassOfBusiness
		,ClientClassificationCode							= se.ClientClassificationCode
		,Comments											= se.Comments
		,Conditions											= se.Conditions
		,ConditionsCode										= se.ConditionsCode
		,ConstructionPeriodFrom								= se.ConstructionPeriodFrom
		,ConstructionPeriodTo								= se.ConstructionPeriodTo
		,ConstructionTitle									= se.ConstructionTitle
		,ConstructionDays									= se.ConstructionDays
		,ConstructionMonths									= se.ConstructionMonths	
		,ContractCertaintyControlsCompliantDate				= se.ContractCertaintyControlsCompliantDate
		,ContractCertaintyEnteredDate						= se.ContractCertaintyEnteredDate
		,ContractCertaintyFullyCompliantDate				= se.ContractCertaintyFullyCompliantDate
		,ContractCertaintyModifiedDate						= se.ContractCertaintyModifiedDate
		,ContractCertaintyPostBindComplete					= se.ContractCertaintyPostBindComplete
		,ContractCertaintyPreBindComplete					= se.ContractCertaintyPreBindComplete
		,ContractCertaintyPreBindSignatureDate 				= se.ContractCertaintyPreBindSignatureDate 
		,ContractCertaintyPrimaryCompleteDate				= se.ContractCertaintyPrimaryCompleteDate
		,ContractCertaintyQuestionNote						= se.ContractCertaintyQuestionNote
		,IsPrimarySection									= se.IsPrimarySection
		,InsuredItem										= CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN se.InsuredItemNarrative
																END
		,ContractCertaintyStatus							= CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 'No Status'
																	 ELSE se.ContractCertaintyStatus
																END
		,ContractCertaintyStatusSortOrder					= CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 6
																	 ELSE se.ContractCertaintyStatusSortOrder
																END
		,CoreAccountType									=  s.CoreAccountType
		,CoreAccountTypeCode								=  s.CoreAccountTypeCode
		,Country											= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
																	 ELSE ISNULL(x.Country, se.Country)
																END
		,CountryCode										= se.CountryCode
		,CoverageForm										= se.CoverageForm
		,CoverageSolution									= se.CoverageSolution
		,CoverType											= se.CoverType
		,CrossSelling										= se.CrossSelling
		,CrossSellingInitiator								= se.CrossSellingInitiator
		,DateModified										=  s.DateModified
		,DaysBetweenConstructionPhaseToandFrom				= se.DaysBetweenConstructionPhaseToandFrom
		,DaysBetweenMaintenanceFromAndTo					= se.DaysBetweenMaintenanceFromAndTo
		,DaysBetweenTestingFromAndTo						= se.DaysBetweenTestingFromAndTo
		,DeclarationWEPAmountInOriginalCCY					= se.DeclarationWEPAmountInOriginalCCY
		,DelegatedClaimsAuthority							= se.DelegatedClaimsAuthority
		,DeductibleAmountInLimitCCY							=  s.DeductibleAmountInLimitCCY
		,DeductibleQualifier								=  s.DeductibleQualifier
		,DepositPremiumAmountInOriginalCCY					= se.DepositPremiumAmountInOriginalCCY
		,EngineeringProjectName								= se.EngineeringProjectName
		,EngineeringSumInsuredInLimitCCY					= se.EngineeringSumInsuredInLimitCCY
		,EquipmentBreakdownContactName						= se.EquipmentBreakdownContactName
		,EquipmentBreakdownContactNumber					= se.EquipmentBreakdownContactNumber
		,EquipmentBreakdownReferral							= se.EquipmentBreakdownReferral
		,ESGPolicyFlag										= se.ESGPolicyFlag
		,EstimatedSigningMultiplier							=  CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN ISNULL(s.EstimatedSigningMultiplier, 1)
																	ELSE s.EstimatedSigningMultiplier
																END
		,EventLimitAmountInLimitCCY							=  s.EventLimitAmountInLimitCCY
		,EventLimitDescription								=  s.EventLimitDescription
		,EventLimitQualifier								=  s.EventLimitQualifier
		,ExcessAmountInLimitCCY								=  s.ExcessAmountInLimitCCY
		,ExcessQualifier									=  s.ExcessQualifier
		,ExpensesMultiplier                                 = se.ExpensesMultiplier
		,ExpiringSectionReference							=  s.ExpiringSectionReference
		,ExpiryDate											=  s.ExpiryDate
		,ExternalAcquisitionCostMultiplier					=  CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN ISNULL(s.ExternalAcquisitionCostMultiplier, 0)
																	ELSE  s.ExternalAcquisitionCostMultiplier
																END
		,FACRIIndicator										= se.FACRIIndicator
		,FacilityReference									=  s.FacilityReference
		,Fees												= se.Fees
		,FirstLiveDate										=  s.FirstLiveDate
		,FullTimeEquivalents								= se.FullTimeEquivalents
		,GulfOfMexicoRiskPremiumMultiplier					= se.GulfOfMexicoRiskPremiumMultiplier
		,GulfOfMexicoWindstormMultiplier					= se.GulfOfMexicoWindstormMultiplier
		,HasConsortiumLink									= se.HasConsortiumLink 
		,HasMultiYearLink									= se.HasMultiYearLink
		,HasParentLink                                      = se.HasParentLink
		,HazardClass										= se.HazardClass
		,HiddenStatusFilter									= CASE
																	WHEN s.SourceSystem = 'StagingDataContract'  THEN
																	CASE --Cancelled 0-valued policies from BeazleyAccess should be hidden
																	WHEN se.OriginatingSourceSystem = 'BeazleyAccess' 
																	AND s.SectionStatus = 'Cancelled' 
																	AND s.WrittenOrEstimatedPremiumAmountInOriginalCCY = 0
																	THEN 'Show Hidden Statuses'
																	ELSE 'Show Regular Statuses'
																	END
																	WHEN s.SourceSystem = 'BeazleyPro' THEN se.HiddenStatusFilter
																	ELSE NULL
																END
		,SectionStatusCode 									=  CASE 
																	WHEN s.SourceSystem = 'FDR' THEN COALESCE(map.StatusCode, s.SectionStatusCode)
																	ELSE s.SectionStatusCode 
																END
		,ITVPerSQFT											= se.ITVPerSQFT
		,InceptionDate										=  s.InceptionDate
		,IncludeInMunichStacking							= 
																CASE
																	WHEN p.SourceSystem = 'BeazleyPro' THEN
																			CASE			
																				WHEN p.YearofAccount /* pol.YOA*/ > 2005
																						AND s.TriFocus NOT LIKE '%Environmental%'
																						AND NOT (s.TriFocus LIKE '%Lawyers%MM%' AND  p.YearofAccount /* pol.YOA*/ IN (2010, 2011, 2012))
																						AND s.SectionReference NOT LIKE 'V15FA606PNDM%'
																						AND isnull(tf2.DepartmentName, tf.DepartmentName) = 'Specialty Lines'
																						AND s.IsQuote = 0
																						THEN 1
																				ELSE 0
																			END
																	ELSE se.IncludeInMunichStacking
																END
		,IncludePML											= se.IncludePML
		,Industry											= se.Industry
		,IndustryCode										= se.IndustryCode
		,IndustryCodeQualifier								= se.IndustryCodeQualifier
		,InnovationCampaign									= se.InnovationCampaign
		,InnovationPremiumMultiplier						= se.InnovationPremiumMultiplier													
		,Interest											=  s.Interest
		,InterestCode										=  s.InterestCode
		,InwardQuotaShareMultiplier							= se.InwardQuotaShareMultiplier
		,IsBeazleyLead										=  s.IsBeazleyLead
		,IsBreachResponseDummy								= se.IsBreachResponseDummy
		,IsPolicyholderAPrivateIndividual					= CASE WHEN s.SourceSystem IN ('BeazleyPro','StagingDataContract','FDR') THEN NULL
																	ELSE 
																		CASE WHEN se.IsPolicyholderAPrivateIndividual = 1 THEN 'Yes' 
																			 WHEN se.IsPolicyholderAPrivateIndividual = 0 THEN 'No'
																			 ELSE NULL
																		END
																END
		,IsQuote											=  s.IsQuote
		,IsRenewal											=  CASE 
																	WHEN s.SourceSystem = 'BeazleyPro' THEN 0
																	WHEN s.SourceSystem= 'StagingDataContract' THEN ISNULL(s.IsRenewal, 0)
																	ELSE  s.IsRenewal
																END
		,IsRapidRenewal										=  CASE 
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 0
																	ELSE ISNULL(se.IsRapidRenewal,0)
																END
		,IsSigned											=  s.IsSigned
		,IsSynergySection									= se.IsSynergySection
		,KeyLocationAddress1								= se.KeyLocationAddress1
		,KeyLocationAddress2								= se.KeyLocationAddress2
		,KeyLocationCity									= se.KeyLocationCity
		,KeyLocationCountry									= se.KeyLocationCountry
		,KeyLocationState									= se.KeyLocationState
		,KeyLocationStreetNumber							= se.KeyLocationStreetNumber
		,KeyLocationZipCode									= se.KeyLocationZipCode
		,UnderwriterLargeRiskReviewer						= se.UnderwriterLargeRiskReviewer
		,LatestEPIInOriginalCCY								=  s.LatestEPIInOriginalCCY
		,LeaderName											= 
																CASE 
																	WHEN s.SourceSystem = 'StagingDataCOntract' THEN bp.BptName
																	ELSE s.LeaderName
																END
		,LeaderPseudonym									=  s.LeaderPseudonym
		,LimitAmountInLimitCCY								=  s.LimitAmountInLimitCCY
		,LimitAmountInOriginalCCY							=  s.LimitAmountInOriginalCCY
		,LimitCurrency										=  s.LimitCurrency
		,LimitCCYToSettlementCCYRateCurrent					= se.LimitCCYToSettlementCCYRateCurrent
																
		,LimitCCYToSettlementCCYRateMelded					= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULLIF(se.LimitCCYToSettlementCCYRateMelded, 0)
																	WHEN s.SourceSystem = 'BeazleyPro' THEN NULL
																	ELSE se.LimitCCYToSettlementCCYRateMelded
																END
		,LimitDescription									= se.LimitDescription
		,LimitMeldedRate									= se.LimitMeldedRate
		,LimitQualifier										= s.LimitQualifier
		,LimitTypeCode										= s.LimitTypeCode
		,LimitTypeDescription								= s.LimitTypeDescription
		,LinkedConsortiumReference							= se.LinkedConsortiumReference
		,LinkedESGBinderReference							= se.LinkedESGBinderReference
		,LinkedESGSectionReference							= se.LinkedESGSectionReference
		,LinkedNonSynergySectionReference					= se.LinkedNonSynergySectionReference
		,LinkedParentReference                              = se.LinkedParentReference
		,LinkedSynergySectionReference						= se.LinkedSynergySectionReference
		,LloydsClassOfBusiness								= se.LloydsClassOfBusiness				
		,LloydsClassOfBusinessCode							= se.LloydsClassOfBusinessCode
		,LocalCurrency										= se.LocalCurrency
		,MailingAddress1									= se.MailingAddress1
		,MailingAddress2									= se.MailingAddress2
		,MailingCity										= se.MailingCity
		,MailingState										= se.MailingState
		,MailingZipCode										= se.MailingZipCode
		,MaintenancePeriodFrom								= se.MaintenancePeriodFrom
		,MaintenancePeriodTo								= se.MaintenancePeriodTo
		,MaintenanceMonths									= se.MaintenanceMonths
		,MASTerritory										= se.MASTerritory
		,MarketCapitalisation								= se.MarketCapitalisation
		,MigratedPolicy										= se.MigratedPolicy
		,MinimumPremiumAmountInOriginalCCY					= se.MinimumPremiumAmountInOriginalCCY
		,MultiYearGroupReference							= se.MultiYearGroupReference
		,MultiYearIndicator									= se.MultiYearIndicator
		,NewConditionsExpiryDate							= se.NewConditionsExpiryDate
		,NotifiedIndividuals								= se.NotifiedIndividuals
		,NotifiedIndividualsName							= se.NotifiedIndividualsName
		,NumberOfEmployees									= se.NumberOfEmployees
		,NumberOfLawyers									= se.NumberOfLawyers
		,NumberOfLives										= se.NumberOfLives
		,NumberOfLocations									= se.NumberOfLocations
		,NumberOfReinstatements								= se.NumberOfReinstatements
		,Obligor											= se.Obligor
		,ObligorOccupation									= se.ObligorOccupation
		,ObligorOccupationCode 								= se.ObligorOccupationCode 
		,Occupation											=  s.Occupation
		,OccupationCode										=  s.OccupationCode
		,OriginalCurrency									=  s.OriginalCurrency
		,OriginalCCYToLocalCCYRate							= se.OriginalCCYToLocalCCYRate
		,OriginalCCYToSettlementCCYRate						=  CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULLIF(s.OriginalCCYToSettlementCCYRate, 0)
																	 ELSE s.OriginalCCYToSettlementCCYRate
																END
		,OriginalCoverageName								= se.OriginalCoverageName
		,OriginalEPIAmountInOriginalCCY						= se.OriginalEPIAmountInOriginalCCY
		,OriginalEPITotalAcquisitionCostMultiplier			= se.OriginalEPITotalAcquisitionCostMultiplier
		,OriginalGrossPremiumAmountInOriginalCCY			= se.OriginalGrossPremiumAmountInOriginalCCY
		,OriginalInsured									= se.OriginalInsured
		,OriginalInsuredArea								= se.OriginalInsuredArea
		,OriginalInsuredAreaCode							= se.OriginalInsuredAreaCode
		,OriginalLimitAmountInOriginalCCY					= se.OriginalLimitAmountInOriginalCCY
		,OriginatingSourceSystem							= se.OriginatingSourceSystem
		,PDDeductible										= se.PDDeductible
		,PDSI												= se.PDSI
		,PMLExposure										= se.PMLExposure
		,PMLExposureOurShareUSD								= se.PMLExposureOurShareUSD
		,PMLExposure100PerctShareUSD						= se.PMLExposure100PerctShareUSD
		,PMLExposure100PerctShareOrigCcy					= se.PMLExposure100PerctShareOrigCcy
		,PMLPercentage                                      = se.PMLPercentage
		,TSI100PercForPMLOrigCcy							= se.TSI100PercForPMLOrigCcy
        ,PolicyRate                                         = se.PolicyRate
		,Peril												=  s.Peril
		,PerilCode											=  s.PerilCode
		,PremiumIncomeLimitAmountInOriginalCCY				= se.PremiumIncomeLimitAmountInOriginalCCY
		,PremiumRates										= se.PremiumRates
		,PrimaryLegacyReference								= se.PrimaryLegacyReference
		,PrimaryOrExcess									= CASE
																	WHEN s.SourceSystem = 'BeazleyPro' THEN 
																	    CASE WHEN CAST(s.ExcessAmountInLimitCCY AS NUMERIC(19,4)) > 0 THEN 'Excess' ELSE 'Primary' END -- se.PrimaryOrExcess
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 
																	    CASE WHEN s.ExcessAmountInLimitCCY > 0 THEN 'Excess' ELSE 'Primary' END
																	ELSE se.PrimaryOrExcess
																END
		,PrimarySectionURL									= se.PrimarySectionURL
		,PrimarySectionURLLabel								= se.PrimarySectionURLLabel	
		,ProductName										=  s.ProductName
		,ProductIsMultiTransactional						= CASE
																	WHEN s.SourceSystem = 'BeazleyPro'  THEN se.ProductIsMultiTransactional
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 0
																	ELSE NULL
																END
		,ProfitCommissionMultiplier							= se.ProfitCommissionMultiplier
		,ProgramName  										= se.ProgramName  
		,ProgramNumber										= se.ProgramNumber
		,ProgramPeriod										= se.ProgramPeriod
		,ProgramType										= se.ProgramType
		,ProgramYear										= se.ProgramYear
		,QuoteBoundSectionReference							= se.QuoteBoundSectionReference
		,QuoteDaysValid										= se.QuoteDaysValid
		,QuoteLapsedDate									= se.QuoteLapsedDate
		,QuoteOrBindDate									=  s.QuoteOrBindDate
		,RatingAdequacyMultiplier							= se.RatingAdequacyMultiplier
		,RateChangeControlComplete							= se.RateChangeControlComplete
		,RateChangeDate										= se.RateChangeDate
		,RateChangeDeductibleMultiplier						= se.RateChangeDeductibleMultiplier
		,RateChangeExposureMultiplier						= se.RateChangeExposureMultiplier
		,RateChangeLimitMultiplier							= se.RateChangeLimitMultiplier
		,RateChangeMethod									= se.RateChangeMethod
		,RateChangeMultiplier								= s.RateChangeMultiplier
		,RateChangeOtherMultiplier							= se.RateChangeOtherMultiplier
		,RateChangeRiskMultiplier							= se.RateChangeRiskMultiplier
		,RateChangeTermsAndConditionsMultiplier				= se.RateChangeTermsAndConditionsMultiplier
		,RateOnLineEnteredMultiplier						= se.RateOnLineEnteredMultiplier
		,RateOnLinePremiumEnteredInOriginalCCY				= se.RateOnLinePremiumEnteredInOriginalCCY
		,RationaleQuestionnaireComplete						= se.RationaleQuestionnaireComplete
		,RationaleQuestionnaireDate							= se.RationaleQuestionnaireDate
		,ReSigningIndicator									= se.ReSigningIndicator
		,ReactivationReason									= se.ReactivationReason
		,ReactivationReasonCode								= se.ReactivationReasonCode
		,ReinstatementMultiplier							= se.ReinstatementMultiplier
		,ReinstatementPremiumAmountInOriginalCCY			= se.ReinstatementPremiumAmountInOriginalCCY
		,ReinsuranceIndicator								= se.ReinsuranceIndicator
		,RetroInceptionDate									= se.RetroInceptionDate
		,Revenues											= se.Revenues
		,RiskClassDescription								= se.RiskClassDescription
		,RiskClassCode										= se.RiskClassCode
		,SICCode											= se.SICCode
		,SigningNumberDate                                  = se.SigningNumberDate
		,SLSpecificCoverage									= se.SLSpecificCoverage
		,ReKeyReference 									= se.ReKeyReference
		,ReKeySource										= se.ReKeySource
		,SecondarySectionURL								= se.SecondarySectionURL
		,SecondarySectionURLLabel							= se.SecondarySectionURLLabel
		,SectionReferenceCOBCode							= se.SectionReferenceCOBCode
		,SectionReferenceReinsuranceIndicator				= se.SectionReferenceReinsuranceIndicator
		,SectionReferenceSectionIdentifier					= se.SectionReferenceSectionIdentifier
		,SectionStatus										= s.SectionStatus
		,ServiceCompanyCode									= se.ServiceCompanyCode	
		,SettlementCurrency									= s.SettlementCurrency
		,SignedLineMultiplier								= s.SignedLineMultiplier
		,SignedOrderMultiplier								= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 
																	CASE 
																	WHEN CAST(s.IsSigned AS bit) = 0 THEN NULL
																	ELSE ISNULL(Utility.udf_ProcessPercentage(s.SignedOrderMultiplier, 0, 0, 0), 1)
																	END
																	ELSE s.SignedOrderMultiplier
																END
		,SpecialPurposeSyndicateApplies						= se.SpecialPurposeSyndicateApplies						
		,StatsCode											= s.StatsCode
		,StatsDescription									= s.StatsDescription
		,SubmissionDate										= se.SubmissionDate
		,SwordTreatyCoverage								= se.SwordTreatyCoverage
		,TechnicalPremium									= s.TechnicalPremium
		,TermsOfTradeDate									= s.TermsOfTradeDate
		,TotalSIExposureOurShare							= s.TotalSIExposureOurShare
		,TerritorialFocusGroup								= se.TerritorialFocusGroup
		,TerrorismReference									= se.TerrorismReference
		,TestingPeriodFrom									= se.TestingPeriodFrom
		,TestingPeriodTo									= se.TestingPeriodTo
		,TestingMonths										= se.TestingMonths
		,TimeExcess											= se.TimeExcess
		,TimeExcessAmount									= se.TimeExcessAmount
		,TopLocationTSI										= se.TopLocationTSI
		,TotalSumInsured									= se.TotalSumInsured
		,TransactionLiabilityProject						= se.TransactionLiabilityProject
		,TransactionTypeCode								= se.TransactionTypeCode			 
	    ,TransactionTypeDescription							= se.TransactionTypeDescription
		,TransactionValue									= se.TransactionValue				
		,Trifocus											= coalesce(tf.TriFocusName, tf2.TriFocusName, s.trifocus)
		,UltimateLossRatioMultiplier						= se.UltimateLossRatioMultiplier
		,UnderwriterAssistantContractCertainty				= se.UnderwriterAssistantContractCertainty
		,UnderwriterContractCertainty						= se.UnderwriterContractCertainty
		,UnderwriterUserInitials							= se.UnderwriterUserInitials
		,UnderwritingPlatformCode							= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN 'SYND'
																	ELSE s.UnderwritingPlatformCode
																END
		,USUnderwritingCoverageCode							= se.USUnderwritingCoverageCode
		,VATNumber                                          = se.VATNumber
		,WEPLastUpdatedDate									= se.WEPLastUpdatedDate
		,WrittenIfNotSignedLineMultiplier					= s.WrittenIfNotSignedLineMultiplier
		,WrittenLineMultiplier								= s.WrittenLineMultiplier
		,MethodOfPlacementCode								= pe.MethodOfPlacementCode
		,InsuranceType										= pe.InsuranceType 
		,WrittenOrderMultiplier								= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN ISNULL(s.WrittenOrderMultiplier, 1)
																	ELSE s.WrittenOrderMultiplier
																END
		,AdditionalInsuredParty								= se.AdditionalInsuredParty
		,InsuredCity										= s.InsuredCity
		,InsuredState										= s.InsuredState
		,InsuredCountry										= s.InsuredCountry
		,InsuredParty										= CASE
																	WHEN p.SourceSystem in ('StagingDataContract', 'ClaimCenter', 'FDR', 'myBeazley', 'USHVH') THEN p.InsuredName
																	ELSE s.InsuredParty
																END
		,BrokerNoticeOfClaim								= se.BrokerNoticeOfClaim
		,PlacingBrokerContact								= se.PlacingBrokerContact
		,PlacingBrokerNumber								= se.PlacingBrokerNumber
		,ProducingBrokerContact								= se.ProducingBrokerContact
		,ProducingBrokerNumber								= se.ProducingBrokerNumber
		,ReinsuredParty										= se.ReinsuredParty
		,BrokerServiceOfSuit								= se.BrokerServiceOfSuit
		,UniqueMarketReference								= se.UniqueMarketReference
		,YearOfAccount										= se.YearOfAccount
		,UnderwriterAssistant								= se.UnderwriterAssistant
		,UnderwriterName									= s.UnderwriterName
		,UnderwriterRiskEnteredBy							= UnderwriterRiskEnteredBy
		,BenchmarkApplies									= BenchmarkApplies
		,DocumentSignedDate									= doc.DocumentSignedDate 
		,CreatedAt											= sqa.CreatedAt 
		,TrifocusName										= CASE 
																	WHEN s.SourceSystem = 'BeazleyPro' THEN s.Trifocus
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
																	ELSE coalesce(tf.TriFocusName, tf2.TriFocusName, s.trifocus)--tf.Name
																END
		,Division											= CASE
																	WHEN s.SourceSystem IN ('BeazleyPro','StagingDataContract') THEN NULL
																	ELSE isnull(tf.Division, tf2.Division)
																END
		,StatusName											= map.StatusName
		,StatusCode											= map.StatusCode
		,s.HashbytesId
		,TechnologyCoverageName								= tm.TechnologyCoverageName
		,ClassifiedAsTechnology								= CASE 
																	WHEN tm.TechnologyCoverageName IS NULL OR tm.TechnologyCoverageName = 'N/A' THEN 'NA' 
																	ELSE 'Technology' 
																END
		,CapitaTotalTimeHours								= CASE
																	WHEN s.SourceSystem IN ('BeazleyPro','StagingDataContract') THEN NULL
																	ELSE NULLIF(ISNULL(se.CapitaEntryTimeHours, 0) + ISNULL(se.CapitaQCTimeHours, 0),0)
																END
		,LiveStatus											= CASE 
																	WHEN s.InceptionDate <= GETDATE() AND s.ExpiryDate > GETDATE()  THEN 'Live' 
																	WHEN (s.InceptionDate > GETDATE()) THEN 'To Inception' 
																	WHEN s.InceptionDate IS NULL OR s.ExpiryDate IS NULL THEN 'N/A'
																	ELSE 'Expired' 
															   END
		,TermsOfTradeExpired								= CASE
																	WHEN DATEDIFF(DAY, TermsOfTradeDate, GETDATE()) > 0 THEN 1
																	ELSE 0
															   END
		,TotalWrittenMultiplier								= NULL
		,TotalSignedMultiplier								= CASE
																	WHEN s.SourceSystem IN ('BeazleyPro','StagingDataContract') THEN NULL
																	ELSE s.SignedLineMultiplier * s.SignedOrderMultiplier
																END
		,WrittenIfNotSignedOrderMultiplier					= NULL
		,TotalWrittenIfNotSignedMultiplier					= NULL
																		/*  case 
																				when s.SourceSystem = 'USHVH' then 1000
																				when s.sourcesystem = 'FDR' then 100 
																				else 1 
																			end */
		,DurationMonths										 = CASE
																	WHEN s.InceptionDate > s.ExpiryDate THEN NULL 
																	WHEN DATEDIFF(DAY, s.InceptionDate, s.ExpiryDate) < 16 THEN 1
																	ELSE ROUND(DATEDIFF(DAY, s.InceptionDate, s.ExpiryDate) / 30.5, 0)
															  END
		--,DaysSinceQuoteOrBindDate							= DATEDIFF(DAY, s.QuoteOrBindDate, GETDATE())
		--,DaysBetweenQBAndRateChangeDate						= CASE
		--															WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
		--															ELSE DATEDIFF(DAY, s.QuoteOrBindDate, se.RateChangeDate)
		--														END
		--,DaysBetweenQBAndBenchmarkDate						= CASE
		--															WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
		--															 ELSE DATEDIFF(DAY, s.QuoteOrBindDate, se.BenchmarkDate)
		--														END
		,MonthsSinceInception								= DATEDIFF(MONTH, s.InceptionDate,GETDATE()) 
		,MonthsSinceTOT										= DATEDIFF(MONTH, s.TermsOfTradeDate, GETDATE()) 

		,DaysBetweenQBAndCCCCDateOrToday					= CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, s.QuoteOrBindDate, GETDATE())
																	ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(se.ContractCertaintyControlsCompliantDate, GETDATE()))   END
																END

		,DaysBetweenQBAndCCFCDateOrToday					= CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, s.QuoteOrBindDate, GETDATE())
																	ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(se.ContractCertaintyFullyCompliantDate, GETDATE())) END
																END

		,DaysBetweenQBAndCCPCDateOrToday					= CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, s.QuoteOrBindDate, GETDATE())
																		ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(se.ContractCertaintyPrimaryCompleteDate, GETDATE())) END
																END

		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday				= CASE
																	WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
																	ELSE CASE 
																			WHEN IsBreachResponseDummy = 0 
																			THEN DATEDIFF(DAY, s.QuoteOrBindDate,
																			ISNULL(Utility.udf_EarlierDate(se.ContractCertaintyPrimaryCompleteDate,se.ContractCertaintyPreBindSignatureDate),GETDATE())) 
																		END
																END
		,NoticeDate											= se.NoticeDate
		,NotificationThreshold								= se.NotificationThreshold
		,TacitRenewal										= se.TacitRenewal
		,PriorityDelete									= CASE 
																WHEN s.SourceSystem IN ('Eurobase', 'Unirisx', 'Gamechanger', 'CIPS', 'myBeazley', 'US High Value Homeowners', 'USHVH','BeazleyPro') THEN 1
																WHEN s.SourceSystem = 'FDR' THEN 2
																ELSE 3
															END

		

	FROM #temp_S s

	INNER JOIN #temp_se se 
	ON s.SourceSystem = se.SourceSystem
	AND s.SectionSourceId = se.SectionSourceId
	
	INNER JOIN #temp_p p 
	ON	p.SourceSystem = s.SourceSystem
	AND p.PolicySourceId = s.PolicySourceId

	INNER JOIN #temp_pe pe 
	ON	p.SourceSystem = pe.SourceSystem 
	AND p.PolicySourceId = pe.PolicySourceId
	
	LEFT OUTER JOIN #sqa sqa 
		/*( 
			SELECT 
				 SectionSourceId			= sa.SectionSourceId
				,SourceSystem				= sa.SourceSystem
				,CreatedAt					= MIN(sa.CreatedAt)	
			FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionQuestionAnswer sa
			inner join #section_deltas sd 
			on sd.SectionSourceId =  sa.SectionSourceId
				and sd.SourceSYstem = sa.SourceSystem
			GROUP BY sa.SectionSourceId, sa.SourceSystem 
		) sqa*/
	ON s.SourceSystem = sqa.SourceSystem
	AND s.SectionSourceId = sqa.SectionSourceId

	--ContractCertaintyPreBindSignatureDate logic - BI 676
	LEFT OUTER JOIN 
		( 
			SELECT  
				 PolicySourceId			= d.PolicySourceId
				,DocumentSignedDate		= MIN(d.DocumentSignedDate)
			FROM BeazleyIntelligenceDataContract.Outbound.vw_Document d
			WHERE DocumentType ='Contract Certainty'
			GROUP BY PolicySourceId 
		) doc
	ON doc.PolicySourceId = s.PolicySourceId
	AND sqa.CreatedAt IS NULL

	
	LEFT JOIN ODS.Trifocus tf
	ON s.Trifocus = tf.TriFocusName

	
	LEFT JOIN ODS.Trifocus tf2
	ON s.Trifocuscode = tf2.TriFocusCode

	LEFT JOIN 
		( select Code		
				,StatusCode	
				,Name
				,SourceSystem
				,StatusName
			 from 
			(SELECT 
				Code			= sta.Code
				,StatusCode		= sta.StatusCode
				,Name			= map1.Name
				,SourceSystem	= src.Name
				,StatusName		= sta.Name  
				,RowNo = ROW_NUMBER() over (partition by  map1.Name,sta.Name, src.Name order by sta.extract_Datetime)
			FROM Staging_MDS.MDS_Staging.SectionStatusMapping map1
				
			INNER JOIN Staging_MDS.MDS_Staging.SourceSystem src 
			ON map1.SourceSystemID_Code = src.Code 
			AND map1.SourceSystemID_Name = src.Name			
			
			INNER JOIN Staging_MDS.MDS_Staging.SectionStatus  sta
			ON map1.SectionStatusID_Code = sta.Code

			WHERE src.Name IN('Gamechanger','myBeazley','CIPS','FDR','RulebookUS','Acturis')) mapt
			where mapt.RowNo = 1
		) map 
	ON map.Name = s.SectionStatus 
	and map.SourceSystem = s.SourceSystem

	
	LEFT JOIN
			(
			SELECT
					 AreaCode                = ac.AreaCode 
					,CountryCode             = ac.CountryCode
					,Country                 = MIN(Utility.udf_ProcessString(ac.Country, 1))
			FROM Staging_MDS.dbo.vw_area_country_code ac
			WHERE ac.CountryCode IS NOT NULL
			GROUP BY ac.CountryCode, ac.AreaCode  
			) x
			ON se.CountryCode = x.CountryCode
			AND x.AreaCode = CASE 
								WHEN se.SourceSystem in ('BeazleyPro', 'StagingDataContract') THEN se.AreaCode 
								ELSE se.Area 
							END

	--LEFT OUTER JOIN Staging_MDS.MDS_Staging.TechnologyMapping tm
	LEFT OUTER JOIN (
	select 
	 tmt.Trifocus_Name ,
	 tmt.ClassOfBusinessCode ,
	 tmt.ProductName,
	 tmt.CoverageName,
	 tmt.SourceSystem_Name 
	 ,tmt.TechnologyCoverageName
	 from
	(select 
	 tmm.Trifocus_Name ,
	 tmm.ClassOfBusinessCode ,
	 tmm.ProductName,
	 tmm.CoverageName,
	 tmm.SourceSystem_Name 
	 ,tmm.TechnologyCoverageName
	 ,RowNo = row_number() over (partition by  tmm.Trifocus_Name,tmm.ClassOfBusinessCode, tmm.ProductName, tmm.CoverageName, tmm.SourceSystem_Name, tmm.TechnologyCoverageName order by tmm.extract_datetime)
	from Staging_MDS.MDS_Staging.TechnologyMapping tmm	
	) tmt
	where tmt.RowNo = 1  ) tm
	ON  tm.Trifocus_Name = s.Trifocus
	AND tm.ClassOfBusinessCode = s.ClassOfBusiness
	AND ISNULL(tm.ProductName,'') = ISNULL(s.ProductName,'') 
	AND tm.CoverageName = s.CoverageName
	AND tm.SourceSystem_Name = p.SourceSystem

	--LEFT OUTER JOIN Staging_MDS.dbo.vw_business_partners bp
	LEFT OUTER JOIN	
	(select bpt.BptName
		   ,bpt.BptPseudo
	from 
	(select bp.BptName
				,bp.BptPseudo
				,row_number() over (Partition by bp.BptName,bp.BptPseudo order by bp.BptPseudo) as RowNo
				from Staging_MDS.dbo.vw_business_partners bp) bpt
	where bpt.RowNo = 1) bp
	ON s.LeaderPseudonym = bp.BptPseudo


	WHERE ISNULL(pe.OriginatingSourceSystem, 'N\A') NOT IN ('FDR','USHVH', 'US High Value Homeowners') 
	
	DELETE
	FROM Staging.Section_All
	WHERE OriginatingSourceSystem = 'EazyPro' 
	AND YearOfAccount >= 2017

	IF (SELECT MAX(AuditCreateDateTime) FROM Staging.Section) IS NULL
		DELETE t
		FROM
		(
			SELECT 
				SectionReference, 
				SourceSystem, 
				PriorityDelete,
				ROW_NUMBER() OVER (PARTITION BY SectionReference ORDER BY PriorityDelete) AS RowNo
			FROM Staging.Section_All WITH(NOLOCK)
		
		) AS t
		WHERE RowNo > 1
	

	DELETE sa
	FROM Staging.Section_All sa
	INNER JOIN Staging.Section s
	ON s.PolicyReference = sa.PolicyReference

	WHERE 
		(sa.SourceSystem = 'FDR' and s.SourceSystem = 'BeazleyPro')
		OR
		(sa.SourceSystem = 'StagingDataContract' and s.SourceSystem = 'Unirisx')

END