﻿create procedure [Staging].[usp_LoadStaging_MeldedRate]
as
begin
	TRUNCATE TABLE Staging.Staging_MeldedRate

	INSERT INTO Staging.Staging_MeldedRate
	(
		 SectionReference					 
		,LimitCCYToSettlementCCYRateCurrent	 
		,LimitCCYToSettlementCCYRateMelded	 
	)
	SELECT
		 SectionReference					   = SectionReference
		,LimitCCYToSettlementCCYRateCurrent	   = LimitCCYToSettlementCCYRateCurrent
		,LimitCCYToSettlementCCYRateMelded	   = LimitCCYToSettlementCCYRateMelded
	FROM Staging.Section_All 

end