﻿
CREATE procedure [Staging].[usp_LoadPolicy_Claims_Delta]					
AS
Begin
	
	
	DECLARE @LastAuditDate DATETIME2(7)

	SELECT 
		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM Staging.Policy

	SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

	TRUNCATE TABLE Staging.Policy_Claims

	INSERT INTO Staging.Policy_Claims
	(
		PolicyNumber	
		,TrifocusCode	
		,YOA			
	)

	SELECT			
		PolicyNumber						= c.PolicyNumber
		,TrifocusCode						= ce.TrifocusCode
		,YOA								= ISNULL(TRY_CONVERT(INT, c.YOA), 0) -- ISNULL(YOA_ext, 0)

	FROM BeazleyIntelligenceDataContract.outbound.vw_Claim c  WITH(NOLOCK)
	INNER JOIN 
		(
			SELECT 
				ClaimSourceId			= ClaimSourceId
				,TriFocusCode			= TriFocusCode 
				,AuditCreateDateTime
				,AuditModifyDatetime
				,RowId					= ROW_NUMBER()OVER (PARTITION BY ClaimSourceId ORDER BY TriFocusCode, AuditCreateDateTime)
			FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure  WITH(NOLOCK)
			WHERE SourceSystem ='ClaimCenter'
		) ce
	ON ce.ClaimSourceId = c.ClaimSourceId
		
	WHERE c.SourceSystem ='ClaimCenter'
		AND 
			(
				ISNULL(c.AuditModifyDatetime, c.AuditCreateDateTime) >= @LastAuditDate
				OR
				ISNULL(ce.AuditModifyDatetime, ce.AuditCreateDateTime) >= @LastAuditDate
			)
			AND ce.RowId = 1
		AND ISNULL(c.IsRetired, 0) = 0
END