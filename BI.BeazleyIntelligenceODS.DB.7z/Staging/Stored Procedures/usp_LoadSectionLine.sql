﻿


CREATE PROCEDURE [Staging].[usp_LoadSectionLine]
AS
BEGIN


	------------------------------------------------------------------------------------------------------------------------------------------
	-- prepare Staging.SectionLine
	-----------------------------------------------------------------------------------------------------------------------------------------
	TRUNCATE TABLE  Staging.SectionLineBase

	INSERT INTO Staging.SectionLineBase
	(
		 SectionReference	
		,PolicyReference	
		,Facility			
		,FK_YOA				
		,SourceSystem		
		,Trifocus			
		,CarrierIndicator
		
	)
	select
		 SectionReference		= s.SectionReference
		,PolicyReference		= p.PolicyReference
		,Facility				= s.Facility
		,FK_YOA					= p.FK_YOA
		,SourceSystem			= p.SourceSystem
		,Trifocus				= tf.TriFocusName
		,CarrierIndicator		= s.CarrierIndicator

	FROM Staging.Section s with (nolock) 
 
	INNER JOIN Staging.Policy p WITH (nolock)
	ON s.policyreference = p.policyreference

	LEFT JOIN ODS.Trifocus tf on tf.PK_TriFocus = s.FK_TriFocus
	

	/*Lines*/


	IF OBJECT_ID('tempdb..#SectionLineTemp') IS NOT NULL
	DROP TABLE #SectionLineTemp

	CREATE TABLE #SectionLineTemp 
	(
		[SectionReference]					VARCHAR(255)	NOT NULL,
		[SyndicateNumber]					INT				NOT NULL,
		[WrittenLineMultiplier]				NUMERIC(19, 12) NULL,
		[SignedLineMultiplier]				NUMERIC(19, 12) NULL,
		[WrittenIfNotSignedLineMultiplier]	NUMERIC(19, 12) NULL,
		[OfTotalMultiplier]					NUMERIC(19, 12) NULL
	)
	--TRUNCATE TABLE Staging.SectionLine

	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
		,OfTotalMultiplier
	)
	SELECT DISTINCT
		 SectionReference					= sl.SectionReference
		,SyndicateNumber					= sl.SyndicateNumber
		,WrittenLineMultiplier				= sl.WrittenLineMultiplier
		,SignedLineMultiplier				= sl.SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier	= sl.WrittenIfNotSignedLineMultiplier
		,OfTotalMultiplier					= sl.OfTotalMultiplier

	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionLine sl with (nolock)
	WHERE sl.SourceSystem in ('Eurobase', 'Unirisx' , 'myBeazley','Acturis')
	--AND (sl.AuditCreateDatetime > @LastAuditDate OR sl.AuditModifyDatetime > @LastAuditDate)
	

	/*Load data contract lines, using the same split as the parent binder*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		SectionReference                    = s.SectionReference
		,SyndicateNumber                    = sl.SyndicateNumber
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)* sl.OfTotalMultiplier
		,SignedLineMultiplier               = Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0) * sl.OfTotalMultiplier
		,WrittenIfNotSignedLineMultiplier   = Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0) * sl.OfTotalMultiplier                       
	FROM Staging_DataContract.DataContract_Staging.Section dcs

	INNER JOIN Staging.SectionLineBase s
	ON s.SectionReference = dcs.SectionReference

	INNER JOIN #SectionLineTemp sl 
	ON s.Facility = sl.SectionReference

	WHERE NOT EXISTS (
						SELECT 
							1 
						FROM #SectionLineTemp sl1 
						WHERE s.SectionReference = sl1.SectionReference
					)
	

	/*For sections which have no lines, we need to create the lines as follows:

1.    If the policy record has a facility reference, create the same lines for the policy as already exist for the facility.

2.    Otherwise

a.	For BICI:
i.	And YOA of the policy stub is < 2010, use the syndicate_split table to create the lines based on the lines for that YOA, allocating between 623 and 2623.
ii.	And YOA of the policy stub is >= 2010 and <=2017, allocate 100% to 3623.
iii.And YOA of the policy stub is 2018 and DepartmentName is “Marine”, allocate 100% to 3623.
iv. And YOA of the policy stub is <= 2020 and DepartmentName is “PCG”, allocate 100% to 3623.
v.  And YOA of the policy stub is >= 2018 and <=2022 and Trifocus is “BICI Intra Group RI”, allocate 100% to 3623.
vi. And YOA >2017, allocate 100% to 8022.
b.	i.       If the TriFocus group is starting with "PA Direct", "PA Reinsurance"  “PA RI” or is "Sports", allocate 100% to 3623, for YOA<2023.
    ii.      If the TriFocus group is "PA Direct", "PA Reinsurance" or "Sports", use the syndicate_split table to create the lines based on the lines for that YOA, allocating between 623 and 2623, for YOA>=2023.
c.	If the TriFocus group is "Life Direct" or "Life Reinsurance", allocate 100% to 3622.
d.	For all other TriFocus groups, use the syndicate_split table to create the lines based on the lines for that YOA, allocating between 623 and 2623.
For all of the above, we need to also check the data contract sections that don't attach to a binder, due to the fact that they may also have lines that are not 100%
*/

	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		SectionReference                    = s.SectionReference
		,SyndicateNumber                    = binder_sl.SyndicateNumber
		,WrittenLineMultiplier              = binder_sl.WrittenLineMultiplier
		,SignedLineMultiplier               = binder_sl.SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier   = binder_sl.WrittenIfNotSignedLineMultiplier

	FROM Staging.SectionLineBase s

	INNER JOIN #SectionLineTemp binder_sl 
	ON s.Facility = binder_sl.SectionReference

	WHERE s.SourceSystem NOT IN ('Eurobase', 'Unirisx') --This logic applies to non-EB policies only, we exclude Unirisx because the logic was applied in Extractor
	AND NOT EXISTS
		(
			SELECT 
				1 
			FROM #SectionLineTemp sl 
			WHERE s.SectionReference = sl.SectionReference
			)
	

	/*3623 lines*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		PolicyReference                     = s.SectionReference
		,SyndicateNumber                    = 3623
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ISNULL(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem <> 'Eurobase' THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s
	
	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	LEFT JOIN ODS.Trifocus tf
	ON s.Trifocus = tf.TriFocusName
	WHERE NOT EXISTS 
					(
						SELECT 
							1 
						FROM #SectionLineTemp sl 
						WHERE s.SectionReference = sl.SectionReference
					)
	AND  
	(
		((s.TriFocus like 'PA Direct%' OR s.TriFocus like 'PA Ri%' OR s.TriFocus like 'Sports') and s.FK_YOA < 2023)
		OR 
		(s.TriFocus LIKE 'BICI%' AND s.FK_YOA >= 2010 and s.FK_YOA <= 2017)
		OR
		(s.TriFocus LIKE 'BICI%' AND tf.DepartmentName='Marine' and s.FK_YOA = 2018)
		OR
		(s.TriFocus LIKE 'BICI%' AND tf.DepartmentName='PCG' and s.FK_YOA <= 2020)
		OR
		(s.TriFocus = 'BICI Intra Group RI' and s.FK_YOA >= 2018 and s.FK_YOA <= 2022)
	)

	
	/*8022 lines*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		PolicyReference                     = s.SectionReference
		,SyndicateNumber                    = 8022
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ISNULL(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem <> 'Eurobase' THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s
	
	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	WHERE NOT EXISTS 
					(
						SELECT 
							1 
						FROM #SectionLineTemp sl 
						WHERE s.SectionReference = sl.SectionReference
					)
	AND  
	(
		s.TriFocus LIKE 'BICI%' AND s.FK_YOA >= 2018
	)
	

	/*3622 lines*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		SectionReference                    = s.SectionReference
		,SyndicateNumber                    = 3622
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ISNULL(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem <> 'Eurobase' THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s

	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	WHERE NOT EXISTS 
				(
					SELECT 
						1 
					FROM #SectionLineTemp sl 
					WHERE s.SectionReference = sl.SectionReference
				)
	AND s.TriFocus IN ('Life Direct', 'Life Reinsurance')
	
	

		/*8044 lines*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		PolicyReference                     = s.SectionReference
		,SyndicateNumber                    = 8044
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ISNULL(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem <> 'Eurobase' THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s

	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	WHERE NOT EXISTS 
					(
						SELECT 
							1 
						FROM #SectionLineTemp sl 
						WHERE s.SectionReference = sl.SectionReference
					)
	AND s.CarrierIndicator = 'BESI'
	


	/*All others for years which split between 623 and 2623*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		SectionReference                    = s.SectionReference
		,SyndicateNumber                    = syn.SyndicateNumber
		,WrittenLineMultiplier              = ss.SyndicateMultiplier * COALESCE(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ss.SyndicateMultiplier * COALESCE(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem NOT IN ('Eurobase', 'Unirisx') THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ss.SyndicateMultiplier * ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s

	CROSS JOIN
				(
					SELECT
						LastYOA        = MAX(ss.FK_YOA)
					FROM ODS.SyndicateSplit ss
				) x 

	INNER JOIN ODS.SyndicateSplit ss 
	/*If the YOA is after the defined splits take the last YOA for which we have splits*/
	ON ss.FK_YOA = CASE
						WHEN s.FK_YOA > x.LastYOA THEN x.LastYOA
						ELSE s.FK_YOA
					END

	INNER JOIN ODS.Syndicate syn 
	ON ss.FK_Syndicate = syn.PK_Syndicate

	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	WHERE NOT EXISTS 
				(
					SELECT 
						1 
					FROM #SectionLineTemp sl 
					WHERE s.SectionReference = sl.SectionReference
				)

    AND (
	CASE WHEN
			 (
				(s.Trifocus LIKE 'BICI%' AND s.FK_YOA >= 2010)
				OR
				(s.Trifocus LIKE 'PA Direct%' AND s.FK_YOA <  2023)
				OR
				(s.Trifocus LIKE 'PA RI%' AND s.FK_YOA < 2023)
				OR
				(s.Trifocus = 'Sports'	AND 	s.FK_YOA < 2023)
			)
			THEN 0
		    ELSE 1
	      END = 1

)
--6775448

	/*For everything else, allocate 100% to 623*/
	INSERT INTO #SectionLineTemp
	(
		SectionReference
		,SyndicateNumber
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		SectionReference                    = s.SectionReference
		,SyndicateNumber                    = syn.SyndicateNumber
		,WrittenLineMultiplier              = ISNULL(Utility.udf_ProcessPercentage(dcs.WrittenLine,0,0,0), 1)
		,SignedLineMultiplier               = ISNULL(Utility.udf_ProcessPercentage(dcs.SignedLine, 0,0,0),
														CASE WHEN s.SourceSystem <> 'Eurobase' THEN 1 ELSE NULL END)
		,WrittenIfNotSignedLineMultiplier   = ISNULL(Utility.udf_ProcessPercentage(ISNULL(dcs.SignedLine, dcs.WrittenLine), 0,0,0), 1)

	FROM Staging.SectionLineBase s

	INNER JOIN ODS.Syndicate syn 
	ON syn.SyndicateNumber = 623

	LEFT OUTER JOIN Staging_DataContract.DataContract_Staging.Section dcs 
	ON s.SectionReference = dcs.SectionReference

	WHERE NOT EXISTS 
				(
					SELECT 
						1 
					FROM #SectionLineTemp sl 
					WHERE s.SectionReference = sl.SectionReference
				)

MERGE Staging.SectionLine target
USING 
#SectionLineTemp source
ON  (
	ISNULL(Source.SectionReference, 'Not Available') = ISNULL(Target.SectionReference, 'Not Available')
AND ISNULL(Source.SyndicateNumber, 'Not Available') = ISNULL(Target.SyndicateNumber, 'Not Available')
)

WHEN MATCHED THEN
UPDATE SET
   target.WrittenLineMultiplier				= source.WrittenLineMultiplier
   ,target.SignedLineMultiplier				= source.SignedLineMultiplier
   ,target.WrittenIfNotSignedLineMultiplier = source.WrittenIfNotSignedLineMultiplier
   ,target.OfTotalMultiplier				= source.OfTotalMultiplier
   ,target.AuditModifyDateTime				= GETDATE()						
   ,target.AuditModifyDetails				= 'Merge in Staging.usp_LoadSectionLine proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    SectionReference
    ,SyndicateNumber
    ,WrittenLineMultiplier
    ,SignedLineMultiplier
	,WrittenIfNotSignedLineMultiplier
	,OfTotalMultiplier
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.SectionReference
    ,source.SyndicateNumber
    ,source.WrittenLineMultiplier
    ,source.SignedLineMultiplier
	,source.WrittenIfNotSignedLineMultiplier
	,source.OfTotalMultiplier
	,GETDATE()
	,'New add in Staging.usp_LoadSectionLine proc'	
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;	

	/*Apply "written if not signed rule to the line*/
	UPDATE sl 
	SET WrittenIfNotSignedLineMultiplier    = ISNULL(sl.SignedLineMultiplier, sl.WrittenLineMultiplier)
	FROM Staging.SectionLine sl

END