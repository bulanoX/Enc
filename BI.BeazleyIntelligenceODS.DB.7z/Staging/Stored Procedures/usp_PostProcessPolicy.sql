﻿

CREATE PROCEDURE [Staging].[usp_PostProcessPolicy]
AS
BEGIN

	/*Update renewing ref on policy*/
	UPDATE p SET
	RenewingPolicy      = p2.PolicyReference
	FROM
		(
			SELECT
				 PolicyReference    = PolicyReference
				,RenewingPolicy	    = RenewingPolicy
			FROM Staging.Policy  WITH(NOLOCK)
		) p
	INNER JOIN
		(
			SELECT
				 PolicyReference	= PolicyReference
				,ExpiringPolicy		= ExpiringPolicy
			FROM Staging.Policy WITH(NOLOCK)
			WHERE IsQuote = 0
		) p2 
	ON p.PolicyReference = p2.ExpiringPolicy
	

	
	UPDATE p 
	SET	IsRenewal   = 1
	FROM staging.Policy p 

	WHERE p.ExpiringPolicy IS NOT NULL
	AND ISNULL(p.isrenewal,0) <> 1


	UPDATE pp
	SET pp.fk_yoa = yoa.PK_YOA
	FROM
		(
			SELECT 
				 sourcesystem	  = sourcesystem
				,yoa			  = yoa
				,fk_yoa			  = fk_yoa
			FROM staging.Policy
			WHERE fk_yoa = 0
			AND yoa <> 0
		) pp

	INNER JOIN ods.yoa yoa
	ON yoa.pk_yoa = pp.yoa


	/*Update expiring policy key*/
	UPDATE p 
	SET FK_ExpiringPolicy  = e.PK_Policy

	FROM 
		(
			SELECT 
				 PK_Policy			  = PK_Policy
				,ExpiringPolicy		  = ExpiringPolicy
				,FK_ExpiringPolicy	  = FK_ExpiringPolicy
			FROM Staging.Policy  WITH(NOLOCK)
			WHERE PK_Policy <> 0
		) p

	INNER JOIN 
		(
			SELECT
				 PK_Policy			 = PK_Policy
				,PolicyReference	 = PolicyReference
			FROM Staging.Policy WITH(NOLOCK)
		) e 
	ON p.ExpiringPolicy = e.PolicyReference


	
	/*Update renewing policy key*/
	UPDATE p 
	SET FK_RenewingPolicy = r.PK_Policy 

	FROM Staging.Policy p WITH(NOLOCK)

	INNER JOIN Staging.Policy r  WITH(NOLOCK)
	ON p.RenewingPolicy = r.PolicyReference

	WHERE p.PK_Policy <> 0


	
	UPDATE p 
	SET FK_PartyBrokerServiceOfSuit			=  ISNULL(b_sos.PK_PartyBroker, 0)

	FROM Staging.Policy p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.PartyBroker b_sos  WITH(NOLOCK)
	ON p.ServiceOfSuitBrokerNumber = b_sos.BrokerNumber
	

	UPDATE p 
	SET FK_QuoteFilter						= qf.PK_QuoteFilter

	FROM Staging.Policy p WITH(NOLOCK)

	INNER JOIN ODS.QuoteFilter qf WITH(NOLOCK)
	ON p.IsQuote = qf.IsQuote

	UPDATE p 
	SET FK_CRMBroker			=  NULL

	FROM Staging.Policy p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.CRMBroker crm_p  WITH(NOLOCK)
	ON  p.FK_CRMBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMBroker, 0) <> 0


	UPDATE p 
	SET FK_CRMProducingBroker			=  NULL

	FROM Staging.Policy p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.CRMBroker crm_p  WITH(NOLOCK)
	ON  p.FK_CRMProducingBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMProducingBroker, 0) <> 0
	
	UPDATE p 
	SET FK_CRMBroker			=  NULL

	FROM Staging.Policy p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.CRMBroker crm_p  WITH(NOLOCK)
	ON  p.FK_CRMBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMBroker, 0) <> 0


	UPDATE p 
	SET FK_CRMProducingBroker			=  NULL

	FROM Staging.Policy p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.CRMBroker crm_p  WITH(NOLOCK)
	ON  p.FK_CRMProducingBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMProducingBroker, 0) <> 0

	update p
	set FK_PartyBrokerProducing = 0
	from staging.policy p
	where FK_PartyBrokerProducing not in (select PK_PartyBroker from ods.PartyBroker)

	UPDATE P
	SET FK_PartyBrokerPlacing = 0
	from staging.policy P
	where FK_PartyBrokerPlacing not in (select PK_PartyBroker from ods.PartyBroker)



END