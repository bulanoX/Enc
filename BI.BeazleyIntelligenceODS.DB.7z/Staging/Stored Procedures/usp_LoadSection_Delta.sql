﻿CREATE  PROCEDURE [Staging].[usp_LoadSection_Delta]
AS
BEGIN


	
	TRUNCATE TABLE Staging.EtrekUnirisxDedupe
	
	INSERT Staging.EtrekUnirisxDedupe
	(
		 PolicyReference  
		,SectionReference
		,LondonRefNo
	)
	SELECT 
	  PolicyReference	= ep.policyreference
	 ,SectionReference	= es.SectionReference
	 ,LondonRefNo		= SUBSTRING(ese.LondonRefNo, 0, CASE WHEN CHARINDEX('/', ese.LondonRefNo) = 0 THEN LEN(ese.LondonRefNo) + 1  
	                                                         ELSE CHARINDEX('/',ese.LondonRefNo) END) 

	FROM Staging_DataContract.DataContract_Staging.SectionExtensions ese

	INNER JOIN Staging_DataContract.DataContract_Staging.Section es
	ON es.PK_Section = ese.FK_Section

	INNER JOIN Staging_DataContract.DataContract_Staging.policy ep
	ON es.FK_Policy = ep.pk_policy

	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Policy p
	ON p.PolicyReference = SUBSTRING(ese.LondonRefNo, 0, CASE WHEN CHARINDEX('/', ese.LondonRefNo) = 0 THEN LEN(ese.LondonRefNo) + 1  
	                                                          ELSE CHARINDEX('/',ese.LondonRefNo) END) --there are cases when we receive LondonRefNo as '%/001', but in Outbound we have them without '/001' 

	WHERE ep.SourceSystemName = 'Etrek' 
	AND p.SourceSystem = 'Unirisx'
	
 	--Exclude existing Etrek feed when data is coming from Unirisx/Eurobase

	-- Policy match
	INSERT Staging.EtrekUnirisxDedupe
	(
		 PolicyReference  
		,SectionReference
		,LondonRefNo
	)
	SELECT DISTINCT
	  PolicyReference	= ep.policyreference
	 ,SectionReference	= es.SectionReference
	 ,LondonRefNo		= ISNULL(ese.LondonRefNo,'')

	FROM Staging_DataContract.DataContract_Staging.SectionExtensions ese

	INNER JOIN Staging_DataContract.DataContract_Staging.Section es
	ON es.PK_Section = ese.FK_Section

	INNER JOIN Staging_DataContract.DataContract_Staging.Policy ep
	ON es.FK_Policy = ep.pk_policy

	INNER JOIN 
	(SELECT DISTINCT PrimaryLegacyReference, SourceSystem, OriginatingSourceSystem ,MigratedPolicy  FROM   Staging.Section_all sa
		UNION 
	SELECT DISTINCT PrimaryLegacyReference, SourceSystem, OriginatingSourceSystem ,MigratedPolicy  FROM   Staging.Section s
		UNION
	-- deduplication for new MTA's that don't have OriginatingSourceSystem, MigratedPolicy populated anymore in Fullset.Section is done based ON archive.Section
	 SELECT DISTINCT sa.PrimaryLegacyReference,'Unirisx' ,sa.OriginatingSourceSystem ,sa.MigratedPolicy
	from BeazleyIntelligenceLanding.Unirisx_Fullset.Section s 
	
		INNER JOIN (
			SELECT Policyreference,PrimaryLegacyReference, OriginatingSourceSystem ,MigratedPolicy, PolicyID   
			FROM  BeazleyIntelligenceLanding.Unirisx_Archive.Section s
			WHERE   MigratedPolicy ='Yes' and  s.OriginatingSourceSystem ='Etrek'
			) sa 
	 ON s.PolicyID = sa.PolicyID
	 WHERE  s.OriginatingSourceSystem is null


	)s
	--ON  LEFT(s.PrimaryLegacyReference, 11) = ese.LondonRefNo
	 ON s.PrimaryLegacyReference = ep.PolicyReference

	WHERE ep.SourceSystemName = 'Etrek' 
		  AND s.SourceSystem IN ('Unirisx','Eurobase')
		  AND s.OriginatingSourceSystem  = 'Etrek'
		  AND s.MigratedPolicy = 'Yes'
		  and es.SectionReference NOT in (select SectionReference from Staging.EtrekUnirisxDedupe)


    -- Section match
	INSERT Staging.EtrekUnirisxDedupe
	(
		 PolicyReference  
		,SectionReference
		,LondonRefNo
	)
	SELECT DISTINCT
	  PolicyReference	= ep.policyreference
	 ,SectionReference	= es.SectionReference
	 ,LondonRefNo		= ISNULL(ese.LondonRefNo,'')

	FROM Staging_DataContract.DataContract_Staging.SectionExtensions ese

	INNER JOIN Staging_DataContract.DataContract_Staging.Section es
	ON es.PK_Section = ese.FK_Section

	INNER JOIN Staging_DataContract.DataContract_Staging.Policy ep
	ON es.FK_Policy = ep.pk_policy

	INNER JOIN 
	(SELECT DISTINCT PrimaryLegacyReference, SourceSystem, OriginatingSourceSystem ,MigratedPolicy  FROM   Staging.Section_all sa
		UNION 
	SELECT DISTINCT PrimaryLegacyReference, SourceSystem, OriginatingSourceSystem ,MigratedPolicy  FROM   Staging.Section s
		UNION
	-- deduplication for new MTA's that don't have OriginatingSourceSystem, MigratedPolicy populated anymore in Fullset.Section is done based ON archive.Section
	 SELECT DISTINCT sa.PrimaryLegacyReference,'Unirisx' ,sa.OriginatingSourceSystem ,sa.MigratedPolicy
	from BeazleyIntelligenceLanding.Unirisx_Fullset.Section s 
	
		INNER JOIN (
			SELECT Policyreference,PrimaryLegacyReference, OriginatingSourceSystem ,MigratedPolicy, PolicyID   
			FROM  BeazleyIntelligenceLanding.Unirisx_Archive.Section s
			WHERE   MigratedPolicy ='Yes' and  s.OriginatingSourceSystem ='Etrek'
			) sa 
	 ON s.PolicyID = sa.PolicyID
	 WHERE  s.OriginatingSourceSystem is null


	)s
	 ON s.PrimaryLegacyReference =  es.SectionReference

	WHERE ep.SourceSystemName = 'Etrek' 
		  AND s.SourceSystem IN ('Unirisx','Eurobase')
		  AND s.OriginatingSourceSystem  = 'Etrek'
		  AND s.MigratedPolicy = 'Yes'
		  and es.SectionReference NOT in (select SectionReference from Staging.EtrekUnirisxDedupe)
	

	

	TRUNCATE TABLE Staging.Section_Temp

	----------------------------------------------------------------------------------------------------------------------------------------------
	--Insert sections from 'Eurobase', 'Unirisx', 'Gamechanger', 'CIPS','myBeazley'
	----------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO  Staging.Section_Temp
	(
		SourceSystem
 		,SectionReference										
 		,SectionDisplayReference								
 		,SectionDescription										
 		,CoverageName											
 		,SectionSequenceId										
 		,PolicyReference	
		,AccountHandler
 		,ATIAClassOfBusinessCode								
 		,AdditionalExposures									
 		,AdjustmentBaseAmountInOriginalCCY						
 		,AdjustmentMultiplier									
 		,AdjustmentPremiumInOriginalCCY							
 		,AdminPurposesFlag										
 		,AggregateAmount										
 		,AggregateQualifier										
 		,AggregatesRequired										
 		,AgressoReference	
		,ProductIsMultiTransactional									
 		,AreaCode												
 		,BeazleyIsAgreementParty								
 		,BeazleyOfficeLocation									
 		,BenchmarkApplies										
 		,BenchmarkDate											
 		,BenchmarkMultiplier									
 		,BIDeductible											
 		,Billings												
 		,BinderType												
 		,BreachResponseMultiplier								
 		,BreachResponseParentSection
		,CancelledDate
		,CancelledReason
 		,CapitaEntryTimeHours									
 		,CapitaQCTimeHours	
		,CapitaTotalTimeHours		
 		,CarrierIndicator
 		,CheckStatusCode
		,CIPsRiskCode				
 		,ClaimBasis												
 		,ClaimBasisCode	
		,ClaimDelegatedTo
 		,ClassOfBusinessCode									
 		,ClientClassificationCode	
        ,Comments
 		,Conditions												
 		,ConditionsCode	
        ,ConstructionPeriodFrom
 		,ConstructionPeriodTo									
 		,ConstructionTitle			
        ,ConstructionDays	
        ,ConstructionMonths
 		,ContractCertaintyControlsCompliantDate 				
 		,ContractCertaintyEnteredDate 							
 		,ContractCertaintyFullyCompliantDate 					
 		,ContractCertaintyModifiedDate 							
 		,ContractCertaintyPostBindComplete						
 		,ContractCertaintyPreBindComplete						
 		,ContractCertaintyPreBindSignatureDate 					
 		,ContractCertaintyPrimaryCompleteDate 					
 		,ContractCertaintyQuestionNote
		,ContractCertaintyRequired 							
 		,ContractCertaintyStatus 								
 		,ContractCertaintyStatusSortOrder 						
 		,CoreAccountType										
 		,CoreAccountTypeCode									
 		,Country												
 		,CountryCode											
 		,CoverageForm	
        ,CoverageSolution
 		,CoverType												
 		,CrossSelling											
 		,CrossSellingInitiator									
 		,DateModified											
 		,DaysBetweenConstructionPhaseToandFrom					
 		,DaysBetweenMaintenanceFromAndTo						
 		,DaysBetweenTestingFromAndTo							
 		,DeclarationWEPInOriginalCCY							
 		,DeductibleAmountInLimitCCY								
 		,DeductibleQualifier
		,DelegatedClaimsAuthority
 		,DepositPremiumInOriginalCCY							
 		,EngineeringProjectName									
 		,EngineeringSumInsuredInLimitCCY						
 		,EquipmentBreakdownContactName							
 		,EquipmentBreakdownContactNumber						
 		,EquipmentBreakdownReferral		
        ,ESGPolicyFlag
 		,EstimatedSigningMultiplier								
 		,EventLimitAmountInLimitCCY								
 		,EventLimitDescription									
 		,EventLimitQualifier									
 		,ExcessAmountInLimitCCY									
 		,ExcessQualifier			
        ,ExpensesMultiplier
 		,ExpiringSection										
 		,ExpiryDate												
 		,ExternalAcquisitionCostMultiplier						
 		,FACRIIndicator											
 		,Facility												
 		,Fees													
 		,FirstLiveDate											
 		,FullQuoteReference										
 		,FullTimeEquivalents									
 		,GulfOfMexicoRiskPremiumMultiplier						
 		,GulfOfMexicoWindstormMultiplier	
    ,HasConsortiumLink 
 		,HasGulfOfMexicoExposure								
 		,HasMultiYearLink					
     ,HasParentLink
 		,HazardClass											
 		,HiddenStatusFilter										
 		,ITVPerSQFT												
 		,InceptionDate											
 		,IncludeInMunichStacking	
        ,IncludePML
 		,Industry												
 		,IndustryCode											
 		,IndustryCodeQualifier									
 		,InnovationCampaign										
 		,InnovationPremiumMultiplier	
		,InsuredItem						
 		,Interest												
 		,InterestCode											
 		,InwardQuotaShareMultiplier								
 		,IsBeazleyLead											
 		,IsBreachResponseDummy									
 		,IsQuote												
 		,IsRenewal												
 		,IsRapidRenewal											
 		,IsSigned												
 		,IsSynergySection										
 		,KeyLocationAddress1									
 		,KeyLocationAddress2									
 		,KeyLocationCity										
 		,KeyLocationCountry										
 		,KeyLocationState										
 		,KeyLocationStreetNumber								
 		,KeyLocationZipCode	
		,LargeRiskReviewerUserInitials									
 		,LatestEPIInOriginalCCY									
 		,LeaderName												
 		,LeaderPseudonym										
 		,LimitAmountInLimitCCY									
 		,LimitAmountInOriginalCCY								
 		,LimitCCY												
 		,LimitCCYToSettlementCCYRateCurrent						
 		,LimitCCYToSettlementCCYRateMelded						
 		,LimitDescription										
 		,LimitMeldedRate										
 		,LimitQualifier	
        ,LimitTypeCode
        ,LimitTypeDescription
		,LinkedConsortiumReference
        ,LinkedESGBinderReference
		,LinkedESGSectionReference
 		,LinkedNonSynergyReference		
        ,LinkedParentReference
 		,LinkedSynergySection									
 		,LloydsClassOfBusiness									
 		,LloydsClassOfBusinessCode								
 		,LocalCurrency											
 		,MailingAddress1										
 		,MailingAddress2										
 		,MailingCity											
 		,MailingState											
 		,MailingZipCode											
 		,MaintenancePeriodFrom									
 		,MaintenancePeriodTo	
        ,MaintenanceMonths
 		,MASTerritory											
 		,MarketCapitalisation									
 		,MigratedPolicy											
 		,MinimumPremiumInOriginalCCY							
 		,MultiYearGroupReference								
 		,MultiYearIndicator	
        ,NewConditionsExpiryDate
 		,NotifiedIndividuals									
 		,NotifiedIndividualsName								
 		,NumberOfEmployees										
 		,NumberOfLawyers										
 		,NumberOfLives
		,NumberOfLocations
 		,NumberOfReinstatements									
 		,Obligor												
 		,ObligorOccupation										
 		,ObligorOccupationCode									
 		,Occupation												
 		,OccupationCode											
 		,OriginalCCY											
 		,OriginalCCYToLocalCCYRate								
 		,OriginalCCYToSettlementCCYRate							
 		,OriginalCoverageName									
 		,OriginalEPIInOriginalCCY								
 		,OriginalEPITotalAcquisitionCostMultiplier				
 		,OriginalGrossPremiumInOriginalCCY						
 		,OriginalInsured										
 		,OriginalInsuredArea									
 		,OriginalInsuredAreaCode								
 		,OriginalLimitInOriginalCCY
		,OriginatingSourceSystem						
 		,PDDeductible	
        ,PDSI
 		,PMLExposure	
        ,PMLExposureOurShareUSD			
        ,PMLExposure100PerctShareUSD	
        ,PMLExposure100PerctShareOrigCcy
        ,PMLPercentage
        ,TSI100PercForPMLOrigCcy
        ,PolicyRate
 		,Peril													
 		,PerilCode												
 		,PremiumIncomeLimitInOriginalCCY						
 		,PremiumRates	
		,PrimaryLegacyReference		
 		,PrimaryOrExcess										
 		,PrimarySectionURL										
 		,PrimarySectionURLLabel									
 		,Product												
 		,ProfitCommissionMultiplier								
 		,ProgramName											
 		,ProgramNumber											
 		,ProgramPeriod	
        ,ProgramType 
        ,ProgramYear 
 		,QuoteBoundSectionReference								
 		,QuoteDaysValid											
 		,QuoteLapsedDate										
 		,QuoteOrBindDate	
		,RatingAdequacyMultiplier
 		,RateChangeControlComplete
 		,RateChangeDate											
 		,RateChangeDeductibleMultiplier							
 		,RateChangeExposureMultiplier							
 		,RateChangeLimitMultiplier								
 		,RateChangeMethod										
 		,RateChangeMultiplier									
 		,RateChangeOtherMultiplier								
 		,RateChangeRiskMultiplier								
 		,RateChangeTermsAndConditionsMultiplier					
 		,RateOnLineMultiplierEntered							
 		,RateOnLinePremiumEnteredInOriginalCCY					
 		,RationaleQuestionnaireComplete							
 		,RationaleQuestionnaireDate								
 		,ReSigningIndicator										
 		,ReactivationReason										
 		,ReactivationReasonCode									
 		,ReinstatementMultiplier								
 		,ReinstatementPremiumInOriginalCCY						
 		,ReinsuranceIndicator									
 		,RetroInceptionDate										
 		,Revenues												
 		,RiskClass												
 		,RiskClassCode											
 		,SICCode
        ,SigningNumberDate
        ,SLSpecificCoverage		
		,ReKeyReference 
        ,ReKeySource
 		,SecondarySectionURL									
 		,SecondarySectionURLLabel								
 		,SectionReferenceCOBCode								
 		,SectionReferenceReinsuranceIndicator					
 		,SectionReferenceSectionIdentifier						
 		,SectionStatus											
 		,SectionStatusCode	
		,ServiceCompanyCode											
 		,SettlementCCY										
 		,SignedLineMultiplier									
 		,SignedOrderMultiplier									
 		,SpecialPurposeSyndicateApplies							
 		,StatsCode												
 		,StatsDescription										
 		,SubmissionDate											
 		,SwordTreatyCoverage			
        ,TechnicalPremium
 		,TermsOfTradeDate					
        ,TotalSIExposureOurShare
 		,TerritorialFocusGroup 
        ,TerrorismReference 									
 		,TestingPeriodFrom										
 		,TestingPeriodTo
        ,TestingMonths
 		,TimeExcess				
        ,TimeExcessAmount
 		,TopLocationTSI											
 		,TotalSumInsured										
 		,TransactionLiabilityProject
        ,TransactionType
        ,TransactionTypeCode	    
 		,TransactionValue										
 		,TriFocus										
 		,UltimateLossRatioMultiplier							
 		,UnderwriterAssistantContractCertaintyUserInitials		
 		,UnderwriterContractCertainty							
 		,UnderwriterContractCertaintyUserInitials				
 		,UnderwriterUserInitials								
 		,UnderwritingPlatformCode								
 		,USUnderwritingCoverageCode
		,VATNumber								
 		,WEPLastUpdatedDate										
 		,WrittenIfNotSignedLineMultiplier						
 		,WrittenLineMultiplier									
 		,WrittenOrEstimatedPremiumInOriginalCCY	
        ,WEPBasis
 		,WrittenOrderMultiplier									
 		,TotalWrittenMultiplier									
		,WrittenIfNotSignedOrderMultiplier						
		,TotalWrittenIfNotSignedMultiplier						
		,DQ_AdditionalInsuredParty								
 		,DQ_Address1											
 		,DQ_Address2											
 		,DQ_Address3											
 		,DQ_InsuredParty										
 		,DQ_MethodOfPlacementCode								
 		,DQ_NoticeOfClaimBrokerNumber							
 		,DQ_PlacingBrokerContact								
 		,DQ_PlacingBrokerNumber									
 		,DQ_ProducingBrokerContact								
 		,DQ_ProducingBrokerNumber								
 		,DQ_ReinsuredParty										
 		,DQ_ServiceOfSuitBrokerNumber							
 		,DQ_UniqueMarketReference								
 		,DQ_YOA
		,UnderwriterRiskEnteredBy	
		,UnderwriterAssistant
 		,UnderwriterName
		,HashbytesId		
		,DurationMonths     			
		--,DaysSinceQuoteOrBindDate       
		--,DaysBetweenQBAndRateChangeDate 
		--,DaysBetweenQBAndBenchmarkDate  
		,MonthsSinceInception           
		,MonthsSinceTOT     
		,LiveStatus									
		,TermsOfTradeExpired						            
		,DaysBetweenQBAndCCCCDateOrToday         
		,DaysBetweenQBAndCCFCDateOrToday         
		,DaysBetweenQBAndCCPCDateOrToday         
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday  
		,NoticeDate								
		,NotificationThreshold					
		,TacitRenewal
		,IsPolicyholderAPrivateIndividual															
	)
	SELECT 
		 SourceSystem											= CASE 
																		WHEN s.SourceSystem = 'StagingDataContract' THEN s.OriginatingSourceSystem
																		ELSE REPLACE(s.SourceSystem,'USHVH','US High Value Homeowners')
																	END
		,SectionReference										= s.SectionReference
		,SectionDisplayReference								= CASE 
																		WHEN (s.IsQuote = 1 or s.SectionStatusCode = 'J') THEN ISNULL(s.FullQuoteReference, s.SectionReference)
																		ELSE s.SectionReference 
																  END	

		,SectionDescription										= s.SectionDescription
		,CoverageName											= s.CoverageName
		,SectionSequenceId										= s.SectionSequenceId
		,PolicyReference										= s.PolicyReference
		,AccountHandler											= s.AccountHandler
		,ATIAClassOfBusinessCode								= s.ATIAClassOfBusiness
		,AdditionalExposures									= s.AdditionalExposures
		,AdjustmentBaseAmountInOriginalCCY						= s.AdjustmentBaseAmountInOriginalCCY
		,AdjustmentMultiplier									= s.AdjustmentMultiplier
		,AdjustmentPremiumInOriginalCCY							= s.AdjustmentPremiumAmountInOriginalCCY
		,AdminPurposesFlag										= s.AdminPurposesFlag
		,AggregateAmount										= s.AggregateAmountInOriginalCCY
		,AggregateQualifier										= s.AggregateQualifier
		,AggregatesRequired										= s.AggregatesRequired
		,AgressoReference										= s.AgressoReference
		,ProductIsMultiTransactional							= s.ProductIsMultiTransactional --NULL
		,AreaCode												= s.Area
																						
																 
		,BeazleyIsAgreementParty								= CASE WHEN s.BeazleyIsAgreementParty = '1' THEN 'Yes' 
																	   WHEN s.BeazleyIsAgreementParty = '0' THEN 'No'
																	   WHEN s.SourceSystem = 'Unirisx' THEN 'Yes'
																	   WHEN s.SourceSystem = 'FDR' THEN ISNULL(s.BeazleyIsAgreementParty,'')
																	   ELSE ISNULL(s.BeazleyIsAgreementParty,'')
																   END
						 
		,BeazleyOfficeLocation									= s.OfficeLocation
		,BenchmarkApplies										= ISNULL(s.BenchmarkApplies,0)
		,BenchmarkDate											= s.BenchmarkDate
		,BenchmarkMultiplier									= CASE 
																		WHEN s.SourceSystem = 'Gamechanger' THEN CASE
																														WHEN (s.WrittenOrEstimatedPremiumAmountInOriginalCCY = 0 OR s.BenchmarkPremiumAmountInOriginalCCY = 0) THEN NULL
																														ELSE (s.BenchmarkPremiumAmountInOriginalCCY / s.WrittenOrEstimatedPremiumAmountInOriginalCCY) --BI-4466 
																												END
																		WHEN s.SourceSystem = 'FDR' THEN s.BenchmarkPremiumMultiplier
																		WHEN s.SourceSystem IN ('myBeazley','CIPS', 'Acturis','RulebookUS') THEN CASE
																													                    WHEN s.BenchmarkPremiumMultiplier = 0 THEN null
																													                    ELSE 1/s.BenchmarkPremiumMultiplier
																												                    END
																		ELSE CASE 
																					WHEN s.BenchmarkPremiumMultiplier = 0 THEN NULL ELSE s.BenchmarkPremiumMultiplier 
																			END
																 END
		,BIDeductible											= s.BIDeductible
		,Billings												= s.Billings
		,BinderType												= s.BinderType
		,BreachResponseMultiplier								= s.BreachResponseMultiplier
		,BreachResponseParentSection							= s.BreachResponseParentSection
		,CancelledDate											= s.CancelledDate
		,CancelledReason										= s.CancelledReason
		,CapitaEntryTimeHours									= s.CapitaEntryTimeHours
		,CapitaQCTimeHours										= s.CapitaQCTimeHours
		,CapitaTotalTimeHours									= s.CapitaTotalTimeHours		
		,CarrierIndicator										= s.CarrierIndicator
		,CheckStatusCode										= s.CheckStatusCode
		,CIPsRiskCode                                           = s.CIPsRiskCode
		,ClaimBasis												= s.ClaimBasis
		,ClaimBasisCode											= s.ClaimBasisCode
		,ClaimDelegatedTo										= s.ClaimDelegatedTo
		,ClassOfBusinessCode									= s.ClassOfBusiness
		,ClientClassificationCode								= s.ClientClassificationCode
        ,Comments                                               = s.Comments
		,Conditions												= s.Conditions
		,ConditionsCode											= s.ConditionsCode
		,ConstructionPeriodFrom                                 = s.ConstructionPeriodFrom 
        ,ConstructionPeriodTo									= s.ConstructionPeriodTo
		,ConstructionTitle										= s.ConstructionTitle
        ,ConstructionDays	                                    = s.ConstructionDays
        ,ConstructionMonths                                     = s.ConstructionMonths
		,ContractCertaintyControlsCompliantDate 				= s.ContractCertaintyControlsCompliantDate
		,ContractCertaintyEnteredDate 							= s.ContractCertaintyEnteredDate
		,ContractCertaintyFullyCompliantDate 					= s.ContractCertaintyFullyCompliantDate
		,ContractCertaintyModifiedDate 							= s.ContractCertaintyModifiedDate
		,ContractCertaintyPostBindComplete						= ISNULL(s.ContractCertaintyPostBindComplete, 0)
		,ContractCertaintyPreBindComplete						= ISNULL(s.ContractCertaintyPreBindComplete, 0)
		,ContractCertaintyPreBindSignatureDate 					= CASE 
																		WHEN s.SourceSystem = 'Unirisx' THEN s.DocumentSignedDate 
																		ELSE s.ContractCertaintyPreBindSignatureDate 
																	END
		,ContractCertaintyPrimaryCompleteDate 					= CASE 
																		WHEN s.SourceSystem = 'Unirisx' THEN s.CreatedAt 
																		ELSE s.ContractCertaintyPrimaryCompleteDate 
																	END
		,ContractCertaintyQuestionNote 							= s.ContractCertaintyQuestionNote
		,ContractCertaintyRequired								= CASE WHEN s.IsPrimarySection = 1 THEN 1 ELSE 0 END
		,ContractCertaintyStatus 								= ISNULL(s.ContractCertaintyStatus, 'No Status')
		,ContractCertaintyStatusSortOrder 						= ISNULL(s.ContractCertaintyStatusSortOrder, 6)
		,CoreAccountType										= s.CoreAccountType
		,CoreAccountTypeCode									= s.CoreAccountTypeCode
		,Country												= s.Country
		,CountryCode											= s.CountryCode
		,CoverageForm											= s.CoverageForm
        ,CoverageSolution                                       = s.CoverageSolution
		,CoverType												= s.CoverType
		,CrossSelling											= s.CrossSelling
		,CrossSellingInitiator									= s.CrossSellingInitiator
		,DateModified											= s.DateModified
		,DaysBetweenConstructionPhaseToandFrom					= s.DaysBetweenConstructionPhaseToandFrom
		,DaysBetweenMaintenanceFromAndTo						= s.DaysBetweenMaintenanceFromAndTo
		,DaysBetweenTestingFromAndTo							= s.DaysBetweenTestingFromAndTo
		,DeclarationWEPInOriginalCCY							= s.DeclarationWEPAmountInOriginalCCY
		,DeductibleAmountInLimitCCY								= s.DeductibleAmountInLimitCCY
		,DeductibleQualifier									= s.DeductibleQualifier
		,DelegatedClaimsAuthority								= s.DelegatedClaimsAuthority
		,DepositPremiumInOriginalCCY							= s.DepositPremiumAmountInOriginalCCY
		,EngineeringProjectName									= s.EngineeringProjectName
		,EngineeringSumInsuredInLimitCCY						= s.EngineeringSumInsuredInLimitCCY
		,EquipmentBreakdownContactName							= s.EquipmentBreakdownContactName
		,EquipmentBreakdownContactNumber						= s.EquipmentBreakdownContactNumber
		,EquipmentBreakdownReferral								= s.EquipmentBreakdownReferral
        ,ESGPolicyFlag                                          = s.ESGPolicyFlag
		,EstimatedSigningMultiplier								= CASE 
																		WHEN s.SourceSystem in ('Eurobase', 'Unirisx','Gamechanger' ,'myBeazley', 'BeazleyPro', 'StagingDataContract') THEN ISNULL(s.EstimatedSigningMultiplier,1) 
																		WHEN s.SourceSystem = 'FDR' THEN s.EstimatedSigningMultiplier
																	    ELSE ISNULL(Utility.udf_ProcessPercentage(s.EstimatedSigningMultiplier, 0, 0, 0), 1) 
																	END
		,EventLimitAmountInLimitCCY								= s.EventLimitAmountInLimitCCY
		,EventLimitDescription									= s.EventLimitDescription
		,EventLimitQualifier									= s.EventLimitQualifier
		,ExcessAmountInLimitCCY									= s.ExcessAmountInLimitCCY
		,ExcessQualifier										= s.ExcessQualifier
        ,ExpensesMultiplier                                     = s.ExpensesMultiplier
		,ExpiringSection										= s.ExpiringSectionReference
		,ExpiryDate												= s.ExpiryDate
		,ExternalAcquisitionCostMultiplier						= s.ExternalAcquisitionCostMultiplier
		,FACRIIndicator											= ISNULL(s.FACRIIndicator,0)
		,Facility												= CASE
																		WHEN s.SourceSystem = 'FDR' THEN CASE 
																												WHEN s.FacilityReference = 'N/A' THEN NULL ELSE s.FacilityReference 
																											END
																		WHEN s.SourceSystem = 'StagingDataContract' and s.OriginatingSourceSystem = 'USHVH' THEN NULL
																		ELSE s.FacilityReference
																	END
		,Fees													= s.Fees
		,FirstLiveDate											= s.FirstLiveDate
		,FullQuoteReference										= s.FullQuoteReference
		,FullTimeEquivalents									= s.FullTimeEquivalents
		,GulfOfMexicoRiskPremiumMultiplier						= s.GulfOfMexicoRiskPremiumMultiplier
		,GulfOfMexicoWindstormMultiplier						= s.GulfOfMexicoWindstormMultiplier
        ,HasConsortiumLink                                      = ISNULL(s.HasConsortiumLink,0)
		,HasGulfOfMexicoExposure								= CASE WHEN s.GulfOfMexicoRiskPremiumMultiplier > 0 OR s.GulfOfMexicoWindstormMultiplier > 0 THEN 1 ELSE 0 END
		,HasMultiYearLink										= ISNULL(s.HasMultiYearLink,0)
        ,HasParentLink                                          = ISNULL(s.HasParentLink,0)
		,HazardClass											= s.HazardClass
		,HiddenStatusFilter										= CASE 
																		WHEN s.HiddenStatusFilter IS NOT NULL THEN s.HiddenStatusFilter
																		WHEN s.SectionStatusCode IN ('U', 'Z', 'P', 'I', 'J') THEN 'Show Hidden Statuses' 
																		ELSE 'Show Regular Statuses' 
																	END
		,ITVPerSQFT												= s.ITVPerSQFT
		,InceptionDate											= s.InceptionDate
		,IncludeInMunichStacking								= ISNULL(s.IncludeInMunichStacking,0)
        ,IncludePML                                             = s.IncludePML
		,Industry												= s.Industry
		,IndustryCode											= s.IndustryCode
		,IndustryCodeQualifier									= s.IndustryCodeQualifier
		,InnovationCampaign										= s.InnovationCampaign
		,InnovationPremiumMultiplier							= s.InnovationPremiumMultiplier	
		,InsuredItem											= s.InsuredItem												
		,Interest												= s.Interest
		,InterestCode											= s.InterestCode
		,InwardQuotaShareMultiplier								= s.InwardQuotaShareMultiplier
		,IsBeazleyLead											= ISNULL(s.IsBeazleyLead,0)
		,IsBreachResponseDummy									= ISNULL(s.IsBreachResponseDummy,0)
		,IsQuote												= ISNULL(s.IsQuote,0)
		,IsRenewal												= ISNULL(s.IsRenewal,0)
		,IsRapidRenewal											= ISNULL(s.IsRapidRenewal,0)
		,IsSigned												= ISNULL(s.IsSigned,0)
		,IsSynergySection										= ISNULL(s.IsSynergySection,0)
		,KeyLocationAddress1									= s.KeyLocationAddress1
		,KeyLocationAddress2									= s.KeyLocationAddress2
		,KeyLocationCity										= s.KeyLocationCity
		,KeyLocationCountry										= s.KeyLocationCountry
		,KeyLocationState										= s.KeyLocationState
		,KeyLocationStreetNumber								= s.KeyLocationStreetNumber
		,KeyLocationZipCode										= s.KeyLocationZipCode
		,LargeRiskReviewerUserInitials							= s.UnderwriterLargeRiskReviewer
		,LatestEPIInOriginalCCY									= s.LatestEPIInOriginalCCY
		,LeaderName												= s.LeaderName
		,LeaderPseudonym										= s.LeaderPseudonym
		,LimitAmountInLimitCCY									= s.LimitAmountInLimitCCY
		,LimitAmountInOriginalCCY								= s.LimitAmountInOriginalCCY
		,LimitCCY												= s.LimitCurrency
		,LimitCCYToSettlementCCYRateCurrent						= s.LimitCCYToSettlementCCYRateCurrent
		,LimitCCYToSettlementCCYRateMelded						= s.LimitCCYToSettlementCCYRateMelded
		,LimitDescription										= s.LimitDescription
		,LimitMeldedRate										= s.LimitMeldedRate
		,LimitQualifier											= s.LimitQualifier
        ,LimitTypeCode                                          = s.LimitTypeCode
        ,LimitTypeDescription                                   = s.LimitTypeDescription
		,LinkedConsortiumReference								= s.LinkedConsortiumReference
        ,LinkedESGBinderReference							    = s.LinkedESGBinderReference
		,LinkedESGSectionReference							    = s.LinkedESGSectionReference
		,LinkedNonSynergyReference								= s.LinkedNonSynergySectionReference
        ,LinkedParentReference                                  = s.LinkedParentReference
		,LinkedSynergySection									= s.LinkedSynergySectionReference
		,LloydsClassOfBusiness									= s.LloydsClassOfBusiness				
		,LloydsClassOfBusinessCode								= s.LloydsClassOfBusinessCode
		,LocalCurrency											= s.LocalCurrency
		,MailingAddress1										= s.MailingAddress1
		,MailingAddress2										= s.MailingAddress2
		,MailingCity											= s.MailingCity
		,MailingState											= s.MailingState
		,MailingZipCode											= s.MailingZipCode
		,MaintenancePeriodFrom									= s.MaintenancePeriodFrom
		,MaintenancePeriodTo									= s.MaintenancePeriodTo
        ,MaintenanceMonths                                      = s.MaintenanceMonths
		,MASTerritory											= s.MASTerritory
		,MarketCapitalisation									= s.MarketCapitalisation
		,MigratedPolicy											= s.MigratedPolicy
		,MinimumPremiumInOriginalCCY							= s.MinimumPremiumAmountInOriginalCCY
		,MultiYearGroupReference								= s.MultiYearGroupReference
		,MultiYearIndicator										= ISNULL(s.MultiYearIndicator,0)
        ,NewConditionsExpiryDate                                = s.NewConditionsExpiryDate
		,NotifiedIndividuals									= s.NotifiedIndividuals
		,NotifiedIndividualsName								= CASE 
																		WHEN s.SourceSystem = 'Eurobase' THEN CASE
																												WHEN s.NotifiedIndividuals IS NOT NULL THEN 'Number of Notified Individuals' ELSE NULL 
																											END
																		ELSE s.NotifiedIndividualsName
																	END
		,NumberOfEmployees										= s.NumberOfEmployees
		,NumberOfLawyers										= s.NumberOfLawyers
		,NumberOfLives											= s.NumberOfLives
		,NumberOfLocations										= s.NumberOfLocations
		,NumberOfReinstatements									= s.NumberOfReinstatements
		,Obligor												= s.Obligor
		,ObligorOccupation										= s.ObligorOccupation
		,ObligorOccupationCode									= s.ObligorOccupationCode 
		,Occupation												= s.Occupation
		,OccupationCode											= s.OccupationCode
		,OriginalCCY											= s.OriginalCurrency
		,OriginalCCYToLocalCCYRate								= s.OriginalCCYToLocalCCYRate
		,OriginalCCYToSettlementCCYRate							= s.OriginalCCYToSettlementCCYRate
		,OriginalCoverageName									= s.OriginalCoverageName
		,OriginalEPIInOriginalCCY								= s.OriginalEPIAmountInOriginalCCY
		,OriginalEPITotalAcquisitionCostMultiplier				= s.OriginalEPITotalAcquisitionCostMultiplier
		,OriginalGrossPremiumInOriginalCCY						= s.OriginalGrossPremiumAmountInOriginalCCY
		,OriginalInsured										= s.OriginalInsured
		,OriginalInsuredArea									= s.OriginalInsuredArea
		,OriginalInsuredAreaCode								= s.OriginalInsuredAreaCode
		,OriginalLimitInOriginalCCY								= s.OriginalLimitAmountInOriginalCCY
		,OriginatingSourceSystem								= s.OriginatingSourceSystem /*CASE
																		WHEN s.SourceSystem = 'StagingDataContract' THEN NULL
																		ELSE s.OriginatingSourceSystem
																	END*/ --BI-7373
		,PDDeductible											= s.PDDeductible
        ,PDSI                                                   = s.PDSI
		,PMLExposure											= s.PMLExposure
        ,PMLExposureOurShareUSD			                        = s.PMLExposureOurShareUSD
        ,PMLExposure100PerctShareUSD	                        = s.PMLExposure100PerctShareUSD
        ,PMLExposure100PerctShareOrigCcy                        = s.PMLExposure100PerctShareOrigCcy
        ,PMLPercentage                                          = s.PMLPercentage
        ,TSI100PercForPMLOrigCcy                                = s.TSI100PercForPMLOrigCcy
        ,PolicyRate                                             = s.PolicyRate
		,Peril													= s.Peril
		,PerilCode												= s.PerilCode
		,PremiumIncomeLimitInOriginalCCY						= s.PremiumIncomeLimitAmountInOriginalCCY
		,PremiumRates											= s.PremiumRates
		,PrimaryLegacyReference									= s.PrimaryLegacyReference
		,PrimaryOrExcess										= s.PrimaryOrExcess
		,PrimarySectionURL										= CASE	
																		WHEN s.sourcesystem = 'BeazleyPro' THEN PolicyURL
																		ELSE s.PrimarySectionURL
																	END
		,PrimarySectionURLLabel									= CASE	
																		WHEN s.sourcesystem = 'BeazleyPro' THEN p.PolicyURLLabel
																		ELSE s.PrimarySectionURLLabel
																	END
		,Product												= s.ProductName
		,ProfitCommissionMultiplier								= s.ProfitCommissionMultiplier
		,ProgramName											= s.ProgramName  
		,ProgramNumber											= s.ProgramNumber
		,ProgramPeriod											= s.ProgramPeriod
		,ProgramType                                            = s.ProgramType 
        ,ProgramYear                                            = s.ProgramYear 
        ,QuoteBoundSectionReference								= s.QuoteBoundSectionReference
		,QuoteDaysValid											= s.QuoteDaysValid
		,QuoteLapsedDate										= s.QuoteLapsedDate
		,QuoteOrBindDate										= s.QuoteOrBindDate
		,RatingAdequacyMultiplier								= s.RatingAdequacyMultiplier
		,RateChangeControlComplete								= CASE 
																		WHEN s.SourceSystem = 'Unirisx' THEN CASE                                             
																												WHEN s.RateChangeControlComplete = 'Complete' THEN 1 ELSE 0 
																											END
																		ELSE ISNULL(s.RateChangeControlComplete, 0) 
																	END   
		,RateChangeDate											= s.RateChangeDate
		,RateChangeDeductibleMultiplier							= s.RateChangeDeductibleMultiplier
		,RateChangeExposureMultiplier							= s.RateChangeExposureMultiplier
		,RateChangeLimitMultiplier								= s.RateChangeLimitMultiplier
		,RateChangeMethod										= s.RateChangeMethod
		,RateChangeMultiplier									= CASE 
																		WHEN s.RateChangeMultiplier = 0 THEN NULL 
																		WHEN s.SourceSystem IN ('myBeazley','CIPS') THEN  1/s.RateChangeMultiplier
																		ELSE s.RateChangeMultiplier 
																	END
		,RateChangeOtherMultiplier								= s.RateChangeOtherMultiplier
		,RateChangeRiskMultiplier								= s.RateChangeRiskMultiplier
		,RateChangeTermsAndConditionsMultiplier					= s.RateChangeTermsAndConditionsMultiplier
		,RateOnLineMultiplierEntered							= s.RateOnLineEnteredMultiplier
		,RateOnLinePremiumEnteredInOriginalCCY					= s.RateOnLinePremiumEnteredInOriginalCCY
		,RationaleQuestionnaireComplete							= ISNULL(s.RationaleQuestionnaireComplete, 0)
		,RationaleQuestionnaireDate								= s.RationaleQuestionnaireDate
		,ReSigningIndicator										= s.ReSigningIndicator
		,ReactivationReason										= s.ReactivationReason
		,ReactivationReasonCode									= s.ReactivationReasonCode
		,ReinstatementMultiplier								= s.ReinstatementMultiplier
		,ReinstatementPremiumInOriginalCCY						= s.ReinstatementPremiumAmountInOriginalCCY
		,ReinsuranceIndicator									= s.ReinsuranceIndicator
		,RetroInceptionDate										= s.RetroInceptionDate
		,Revenues												= s.Revenues
		,RiskClass												= s.RiskClassDescription
		,RiskClassCode											= s.RiskClassCode
		,SICCode												= s.SICCode
        ,SigningNumberDate                                      = s.SigningNumberDate
        ,SLSpecificCoverage										= s.SLSpecificCoverage
		,ReKeyReference 	        							= s.ReKeyReference 
        ,ReKeySource                                            = s.ReKeySource
		,SecondarySectionURL									= s.SecondarySectionURL
		,SecondarySectionURLLabel								= s.SecondarySectionURLLabel
		,SectionReferenceCOBCode								= s.SectionReferenceCOBCode
		,SectionReferenceReinsuranceIndicator					= s.SectionReferenceReinsuranceIndicator
		,SectionReferenceSectionIdentifier						= s.SectionReferenceSectionIdentifier
		,SectionStatus                                          = COALESCE(s.StatusName, s.SectionStatus)
		,SectionStatusCode                                      = COALESCE(s.StatusCode, s.SectionStatusCode)
		,ServiceCompanyCode										= s.ServiceCompanyCode
		,SettlementCCY											= s.SettlementCurrency
		,SignedLineMultiplier									= s.SignedLineMultiplier
		,SignedOrderMultiplier									= s.SignedOrderMultiplier
		,SpecialPurposeSyndicateApplies							= ISNULL(s.SpecialPurposeSyndicateApplies,0)							
		,StatsCode												= s.StatsCode
		,StatsDescription										= s.StatsDescription
		,SubmissionDate											= s.SubmissionDate
		,SwordTreatyCoverage									= ISNULL(s.SwordTreatyCoverage,0)
        ,TechnicalPremium                                       = s.TechnicalPremium
		,TermsOfTradeDate										= s.TermsOfTradeDate
        ,TotalSIExposureOurShare                                = s.TotalSIExposureOurShare
		,TerritorialFocusGroup                                  = s.TerritorialFocusGroup 
        ,TerrorismReference 									= s.TerrorismReference
		,TestingPeriodFrom										= s.TestingPeriodFrom
		,TestingPeriodTo										= s.TestingPeriodTo
        ,TestingMonths                                          = s.TestingMonths
		,TimeExcess												= s.TimeExcess
        ,TimeExcessAmount                                       = s.TimeExcessAmount
		,TopLocationTSI											= s.TopLocationTSI
		,TotalSumInsured										= s.TotalSumInsured
		,TransactionLiabilityProject							= s.TransactionLiabilityProject
        ,TransactionType                                        = s.TransactionTypeDescription
        ,TransactionTypeCode                                    = s.TransactionTypeCode
		,TransactionValue										= s.TransactionValue
		,TriFocus												= CASE 
																		WHEN s.SourceSystem = 'Gamechanger' OR (s.SourceSystem =  'myBeazley' AND s.ProductName <> 'MyBeazley Broker Access PCG') THEN s.TrifocusName 
																		ELSE s.TriFocus 
																	END										
		,UltimateLossRatioMultiplier							= s.UltimateLossRatioMultiplier
		,UnderwriterAssistantContractCertaintyUserInitials		= s.UnderwriterAssistantContractCertainty
		,UnderwriterContractCertainty							= s.UnderwriterContractCertainty
		,UnderwriterContractCertaintyUserInitials				= s.UnderwriterContractCertainty
		,UnderwriterUserInitials								= s.UnderwriterUserInitials
		,UnderwritingPlatformCode								= s.UnderwritingPlatformCode
		,USUnderwritingCoverageCode								= s.USUnderwritingCoverageCode
		,VATNumber                                              = s.VATNumber
		,WEPLastUpdatedDate										= s.WEPLastUpdatedDate
		,WrittenIfNotSignedLineMultiplier						= s.WrittenIfNotSignedLineMultiplier
		,WrittenLineMultiplier									= s.WrittenLineMultiplier
		,WrittenOrEstimatedPremiumInOriginalCCY					= s.WrittenOrEstimatedPremiumAmountInOriginalCCY
																	--CASE 
																	--	WHEN	s.SourceSystem = 'Unirisx' 
																	--		AND (
																	--				(s.Division IN ('SL', 'CyEx') AND s.MethodOfPlacementCode = 'P')
																	--			OR (s.InsuranceType = 'Delegated')
																	--		)
																	--	THEN	ISNULL(OriginalEPIAmountInOriginalCCY, 0)
																	--	ELSE	s.WrittenOrEstimatedPremiumAmountInOriginalCCY
																	--END
        ,WEPBasis                                               = s.WEPBasis
		,WrittenOrderMultiplier									= s.WrittenOrderMultiplier

		,TotalWrittenMultiplier									= s.TotalWrittenMultiplier
		,WrittenIfNotSignedOrderMultiplier						= s.WrittenIfNotSignedOrderMultiplier
		,TotalWrittenIfNotSignedMultiplier						= s.TotalWrittenIfNotSignedMultiplier

		/*DQ fields*/																					
		,DQ_AdditionalInsuredParty								= s.AdditionalInsuredParty
		,DQ_Address1											= s.InsuredCity
		,DQ_Address2											= s.InsuredState
		,DQ_Address3											= s.InsuredCountry
		,DQ_InsuredParty										= s.InsuredParty
		,DQ_MethodOfPlacementCode								= s.MethodOfPlacementCode
		,DQ_NoticeOfClaimBrokerNumber							= ISNULL(s.BrokerNoticeOfClaim, 0)
		,DQ_PlacingBrokerContact								= s.PlacingBrokerContact
		,DQ_PlacingBrokerNumber									= s.PlacingBrokerNumber
		,DQ_ProducingBrokerContact								= s.ProducingBrokerContact
		,DQ_ProducingBrokerNumber								= s.ProducingBrokerNumber
		,DQ_ReinsuredParty										= s.ReinsuredParty
		,DQ_ServiceOfSuitBrokerNumber							= s.BrokerServiceOfSuit
		,DQ_UniqueMarketReference								= s.UniqueMarketReference
		,DQ_YOA													= CASE
																		WHEN s.YearOfAccount IS NULL AND s.FacilityReference IS NULL THEN YEAR(s.InceptionDate)	
																									/*YOA defaults - for decs, this is going to be the YOA of the facility,
																															 for everything else the year of the inception date*/
																		WHEN s.SourceSystem = 'FDR' THEN s.YearOfAccount
																		ELSE s.YearOfAccount
																	END
		,UnderwriterRiskEnteredBy								= s.UnderwriterRiskEnteredBy
		,UnderwriterAssistant									= s.UnderwriterAssistant
		,UnderwriterName										= s.UnderwriterName
		,HashbytesId											= s.HashbytesId
		,DurationMonths                              = CASE
														WHEN s.InceptionDate > s.ExpiryDate THEN NULL 
														WHEN DATEDIFF(DAY, s.InceptionDate, s.ExpiryDate) < 16 THEN 1
														ELSE ROUND(DATEDIFF(DAY, s.InceptionDate, s.ExpiryDate) / 30.5, 0)
													  END
	
		--,DaysSinceQuoteOrBindDate                   = DATEDIFF(DAY, s.QuoteOrBindDate, GETDATE())
		--,DaysBetweenQBAndRateChangeDate             = DATEDIFF(DAY, s.QuoteOrBindDate, s.RateChangeDate)
		--,DaysBetweenQBAndBenchmarkDate              = DATEDIFF(DAY, s.QuoteOrBindDate, s.BenchmarkDate)

		,MonthsSinceInception                       = DATEDIFF(MONTH, s.InceptionDate,GETDATE()) 
		,MonthsSinceTOT                             = DATEDIFF(MONTH, s.TermsOfTradeDate, GETDATE()) 
		,LiveStatus									= s.LiveStatus
		,TermsOfTradeExpired						= s.TermsOfTradeExpired							            
	
																																																																															  
		,DaysBetweenQBAndCCCCDateOrToday         	= CASE
															WHEN s.SourceSystem = 'FDR' THEN CASE
																									WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCCCDateOrToday        
																									ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyControlsCompliantDate, GETDATE()))																	   
																								END	
															ELSE s.DaysBetweenQBAndCCCCDateOrToday
														END        --CASE WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCCCDateOrToday        ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyControlsCompliantDate, GETDATE()))																	   END
		,DaysBetweenQBAndCCFCDateOrToday         	= CASE
															WHEN s.SourceSystem = 'FDR' THEN CASE
																									WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCFCDateOrToday        ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyFullyCompliantDate, GETDATE()))																		   
																								END											
															ELSE s.DaysBetweenQBAndCCFCDateOrToday  
														END      --CASE WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCFCDateOrToday        ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyFullyCompliantDate, GETDATE()))																		   END
		,DaysBetweenQBAndCCPCDateOrToday         	= CASE 
															WHEN s.SourceSystem = 'FDR' THEN CASE
																									WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCPCDateOrToday        ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyPrimaryCompleteDate, GETDATE()))																		   
																								END
															ELSE s.DaysBetweenQBAndCCPCDateOrToday 
														END       --CASE WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCPCDateOrToday        ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(s.ContractCertaintyPrimaryCompleteDate, GETDATE()))																		   END
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday  	= CASE 
															WHEN s.SourceSystem = 'FDR' THEN CASE
																									WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(Utility.udf_EarlierDate(s.ContractCertaintyPrimaryCompleteDate,s.ContractCertaintyPreBindSignatureDate)    ,GETDATE()))    
																								END
															ELSE s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday
														END --CASE WHEN s.IsBreachResponseDummy <> 0 THEN s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday ELSE DATEDIFF(DAY, s.QuoteOrBindDate,ISNULL(Utility.udf_EarlierDate(s.ContractCertaintyPrimaryCompleteDate,s.ContractCertaintyPreBindSignatureDate)    ,GETDATE()))    END
		,NoticeDate									= CASE 
															WHEN s.SourceSystem = 'FDR' THEN NULL
															ELSE s.NoticeDate
														END
		,NotificationThreshold						= CASE 
															WHEN s.SourceSystem = 'FDR' THEN NULL
															ELSE s.NotificationThreshold
														END
		,TacitRenewal								= CASE 
															WHEN s.SourceSystem ='FDR' THEN NULL
															ELSE s.TacitRenewal
														END
		,IsPolicyholderAPrivateIndividual			= s.IsPolicyholderAPrivateIndividual

	FROM Staging.Section_All  s         

	LEFT JOIN Staging.EtrekUnirisxDedupe eud
	ON eud.PolicyReference = s.PolicyReference


	LEFT JOIN Staging.Policy_All p 
	ON p.PolicyReference = s.PolicyReference

	WHERE eud.SectionReference IS NULL
	    
	
	--CREATE INDEX b on Staging.Section(PolicyReference)
	--00:00
	
	
	----------------------------------------------------------------------------------------------------------------------------------------------
	-- insert Sections for ClaimCenter policies
	----------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO Staging.Section_temp
	(
 		SourceSystem
		,SectionReference
		,SectionDisplayReference
		,SectionSequenceId
		,PolicyReference
		,AgressoReference
		,ProductIsMultiTransactional
		,ClassOfBusinessCode
		,ContractCertaintyStatus
		,ContractCertaintyStatusSortOrder
		,EstimatedSigningMultiplier
		,ExpiryDate
		,ExternalAcquisitionCostMultiplier
		,HiddenStatusFilter
		,InceptionDate
		,IsQuote
		,LimitCCY
		,LimitQualifier
		,OriginalCCY
		,PrimaryOrExcess
		,SettlementCCY
		,SignedOrderMultiplier
		,TriFocus
		,UnderwritingPlatformCode
		,WrittenOrderMultiplier
		,FK_Underwriter  
		,IncludeInMunichStacking
		,WrittenLineMultiplier            
		,TotalWrittenMultiplier             
		,WrittenIfNotSignedLineMultiplier   
		,WrittenIfNotSignedOrderMultiplier  
		,TotalWrittenIfNotSignedMultiplier  
		,DurationMonths
		,LiveStatus
		,MonthsSinceInception
		,MultiYearGroupDurationMonths
        ,WEPBasis                                             
	)

	SELECT
		SourceSystem
		,s.SectionReference
		,SectionDisplayReference
		,SectionSequenceId
		,PolicyReference
		,AgressoReference
		,ProductIsMultiTransactional
		,ClassOfBusinessCode
		,ContractCertaintyStatus
		,ContractCertaintyStatusSortOrder
		,EstimatedSigningMultiplier
		,ExpiryDate
		,ExternalAcquisitionCostMultiplier
		,HiddenStatusFilter
		,InceptionDate
		,IsQuote
		,LimitCCY
		,LimitQualifier
		,OriginalCCY
		,PrimaryOrExcess
		,SettlementCCY
		,SignedOrderMultiplier
		,TriFocus
		,UnderwritingPlatformCode
		,WrittenOrderMultiplier
		,FK_Underwriter
		,IncludeInMunichStacking
		,WrittenLineMultiplier              = 1
		,TotalWrittenMultiplier             = 1
		,WrittenIfNotSignedLineMultiplier   = 1
		,WrittenIfNotSignedOrderMultiplier  = 1
		,TotalWrittenIfNotSignedMultiplier  = 1
		,DurationMonths
		,LiveStatus		
		,MonthsSinceInception                       = DATEDIFF(MONTH, s.InceptionDate,GETDATE()) 
		,MultiYearGroupDurationMonths
        ,WEPBasis                                          
	FROM 
		(
			SELECT                                   
					 SourceSystem							= s.SourceSystem			
					,SectionReference						= s.SectionReference		
					,SectionDisplayReference				= s.SectionDisplayReference
					,SectionSequenceId						= 1 ---ROW_NUMBER() OVER(PARTITION BY s.PolicyReference ORDER BY s.SectionReference) -- 1
					,PolicyReference						= s.PolicyReference			
					,AgressoReference						= s.AgressoReference			
					,ProductIsMultiTransactional			= s.ProductIsMultiTransactional
					,ClassOfBusinessCode					= ClassOfBusinessCode
					,ContractCertaintyStatus				= s.ContractCertaintyStatus
					,ContractCertaintyStatusSortOrder		= s.ContractCertaintyStatusSortOrder
					,EstimatedSigningMultiplier				= s.EstimatedSigningMultiplier
					,ExpiryDate								= s.ExpiryDate
					,ExternalAcquisitionCostMultiplier		= s.ExternalAcquisitionCostMultiplier
					,HiddenStatusFilter						= s.HiddenStatusFilter
					,InceptionDate							= s.InceptionDate
					,IsQuote								= s.IsQuote
					,LimitCCY								= s.LimitCCY
					,LimitQualifier							= s.LimitQualifier
					,OriginalCCY							= s.OriginalCCY
					,PrimaryOrExcess						= s.PrimaryOrExcess 
					,SettlementCCY							= s.SettlementCCY
					,SignedOrderMultiplier					= s.SignedOrderMultiplier
					,TriFocus								= tf.TriFocusName
					,UnderwritingPlatformCode				= s.UnderwritingPlatformCode
					,WrittenOrderMultiplier					= s.WrittenOrderMultiplier
					,FK_Underwriter							= s.FK_Underwriter
					,IncludeInMunichStacking				= 0
					,RowId									= ROW_NUMBER() OVER(PARTITION BY s.PolicyReference ORDER BY s.SectionReference)
					,DurationMonths							= s.DurationMonths
					,LiveStatus								= s.LiveStatus			
					,MultiYearGroupDurationMonths	= NULL
                    ,WEPBasis                               = s.WEPBasis

				FROM Staging.Section_Claims s
					
				LEFT JOIN ODS.TriFocus tf 
				ON tf.TriFocusCode = s.TrifocusCode
	
			WHERE NOT EXISTS
								(
									SELECT 
										1 
									FROM Staging.Section_temp s1 --original code: Staging.Section ; I've change it as now this table contains only delta
									WHERE s.SectionReference = s1.SectionReference
								)
				AND NOT EXISTS
								(
									SELECT 
										1 
									FROM Staging.Section s1 
									WHERE s.SectionReference = s1.SectionReference
								)

		) s

	
	WHERE s.RowId = 1
	
	-------------------------------------------------------------------------
	--The next piece of code was moved to a new stored procedure: staging.usp_LoadSectionFacility
	--DROP TABLE IF EXISTS #FacilityLink

	--CREATE TABLE #FacilityLink
	--(
	--	FacilityReference       varchar(255)    NOT NULL
	--	,DeclarationReference   varchar(255)    NOT NULL
	--	PRIMARY KEY (DeclarationReference)
	--)

	----Add Eurobase link - needed for ClaimCenter; Add also Unirisx and Gamechanger
	--INSERT INTO #FacilityLink
	--(
	--	DeclarationReference
	--	,FacilityReference
	--)
	--SELECT DISTINCT
	--	DeclarationReference    = s.SectionReference
	--	,FacilityReference		= s.Facility
	--FROM Staging.Section_temp s
	--WHERE s.Facility IS NOT NULL

	--/*Eurobase reference changes*/
	--DROP TABLE IF EXISTS #ProcessReferenceChanges

	--CREATE TABLE #ProcessReferenceChanges
	--(
	--	OldReference          varchar(255)  NOT NULL
	--	,UltimateNewReference varchar(255)  NOT NULL
	--	,UltimateDepth        int           NOT NULL
	--	,CyclesDetected       bit           NOT NULL
	--	,PRIMARY KEY(OldReference)
	--)

	--INSERT INTO #ProcessReferenceChanges
	--(
	--	OldReference
	--	,UltimateNewReference
	--	,UltimateDepth
	--	,CyclesDetected
	--)
	--SELECT 
	--	OldReference                    = x.OldReference
	--	,UltimateNewReference           = x.UltimateNewReference
	--	,UltimateDepth                  = x.UltimateDepth
	--	,CyclesDetected                 = x.CyclesDetected
	--FROM Utility.udf_ProcessReferenceChanges() x 


	--/*Add BeazleyPro links - join through the reference log for changes*/
	--INSERT INTO #FacilityLink
	--(
	--	DeclarationReference
	--	,FacilityReference
	--)
	--SELECT DISTINCT
	--	DeclarationReference    = s.SectionReference
	--	,FacilityReference      = ISNULL(rc.UltimateNewReference, s.FacilityReference)
	--FROM Staging_Matlock.Matlock.section s

	--LEFT OUTER JOIN #ProcessReferenceChanges rc 
	--ON s.FacilityReference = rc.OldReference

	--WHERE EXISTS
	--		(
	--			SELECT 
	--				1
	--			FROM Staging.Section_temp s1 --original code: Staging.Section ; I've change it as now this table contains only delta
	--			WHERE s1.SectionReference = ISNULL(rc.UltimateNewReference, s.FacilityReference)
	--		)
		

	--/*Add data contract links*/
	--INSERT INTO #FacilityLink
	--(
	--	DeclarationReference
	--	,FacilityReference
	--)
	--SELECT DISTINCT
	--	DeclarationReference    = s.SectionReference
	--	,FacilityReference      = ISNULL(rc.UltimateNewReference, s.FacilityReference)
	--FROM Staging_DataContract.DataContract_Staging.Section s

	--INNER JOIN Staging_DataContract.DataContract_Staging.Policy p
	--ON s.FK_Policy = p.PK_Policy

	--LEFT OUTER JOIN #ProcessReferenceChanges rc 
	--ON s.FacilityReference = rc.OldReference

	--LEFT OUTER JOIN #FacilityLink fl1 
	--ON fl1.DeclarationReference = s.SectionReference

	--LEFT OUTER JOIN Staging.Section_temp s1 --original code: Staging.Section ; I've change it as now this table contains only delta
	--ON s1.SectionReference = ISNULL(rc.UltimateNewReference, s.FacilityReference)

	--WHERE fl1.DeclarationReference IS NULL
	--AND s1.SectionReference IS NOT NULL
	--AND s.SourceSystemName NOT IN ('FDR', 'USHVH', 'US High Value Homeowners')
	--AND ( (p.SourceSystemFriendlyName = 'EazyPro' AND p.YearOfAccount < 2017) OR (p.SourceSystemFriendlyName != 'EazyPro') )
	
	
	--/*Add ClaimCenter links*/
	--INSERT INTO #FacilityLink

	--(
	--	DeclarationReference
	--	,FacilityReference
	--)
	--select 
	--	declarationreference,
	--	FacilityReference 
	--from
	--	(
	--		SELECT --DISTINCT
	--			DeclarationReference    = s.SectionReference
	--			,FacilityReference      = s_b.SectionReference
	--			,RowNo = Row_number() over (partition by s.sectionreference order by s_b.sectionreference) 

	--		FROM Staging.Section_temp s

	--		INNER HASH JOIN 
	--					(
	--						SELECT
	--							PolicyReference
	--						FROM Staging.Policy 
	--						WHERE SourceSystem = 'ClaimCenter'
	--					) p 
	--		ON s.PolicyReference = p.PolicyReference
		
	--		INNER HASH JOIN Staging.ClaimCenter_Claims cp 
	--		ON p.PolicyReference = cp.PolicyNumber

	--		LEFT JOIN #ProcessReferenceChanges pfc 
	--		ON cp.BinderReference = pfc.OldReference

	--		INNER JOIN Staging.Section_temp s_b 
	--		ON ISNULL(pfc.UltimateNewReference, cp.BinderReference) = s_b.SectionReference --We only want binders that exist in Eurobase
		
	--		LEFT OUTER JOIN #FacilityLink fl1 
	--		ON fl1.DeclarationReference = s.SectionReference

	--		WHERE fl1.DeclarationReference IS NULL
	--	) as t
	--where rowno = 1


	/*Sometimes Eurobase or ClaimCenter may give us a multi-level tree for facility-declaration.
	We flatten these out so that every dec is attached to the topmost parent in the hierarchy.
	Otherwise the check constraint on ODS.Section will be violated (the one that enforces that a record can't
	be both a facility and a dec). We do this to ensure that the facility - declaration tree is never more than 
	one level deep. If the check constraint is removed, and the one-level rule is violated, the cube may fail 
	in subtle ways*/
	
	--DROP TABLE IF EXISTS #CTEFacTree

	--CREATE TABLE #CTEFacTree
	--(
	--	 UltimateParent         varchar(255) NOT NULL
	--	,ChildPolicyReference   varchar(255) NOT NULL
	--	,ParentPolicyReference  varchar(255) NOT NULL
	--	,ParentLevel            int          NOT NULL
	--)

	--;WITH CTEFacilityTree 
	--AS
	--(
	--	/*Anchor members*/
	--	SELECT TOP (2147483647)
	--		UltimateParent              = f.FacilityReference 
	--		,ChildPolicyReference       = f.DeclarationReference
	--		,ParentPolicyReference      = f.FacilityReference
	--		,ParentLevel                = 1 
	--	FROM #FacilityLink f
	--	-- WHERE NOT EXISTS (SELECT 1 FROM #FacilityLink f1 WHERE f.FacilityReference = f1.DeclarationReference)
	--	LEFT OUTER JOIN #FacilityLink f1
	--	ON f.FacilityReference = f1.DeclarationReference
	
	--	WHERE f1.DeclarationReference IS NULL
   
	--	UNION ALL
    
	--	/*Recursive members*/
	--	SELECT
	--		UltimateParent              = ft.UltimateParent 
	--		,ChildPolicyReference       = f.DeclarationReference 
	--		,ParentPolicyReference      = f.FacilityReference 
	--		,ParentLevel                = ft.ParentLevel + 1 
	--	FROM CTEFacilityTree ft
    
	--	INNER JOIN #FacilityLink f 
	--	ON ft.ChildPolicyReference = f.FacilityReference
	--)

	--INSERT INTO #CTEFacTree
	--(
	--	 UltimateParent
	--	,ChildPolicyReference
	--	,ParentPolicyReference
	--	,ParentLevel
	--)
	--SELECT
	--	 UltimateParent
	--	,ChildPolicyReference
	--	,ParentPolicyReference
	--	,ParentLevel
	--FROM CTEFacilityTree

	--UPDATE f 
	--SET FacilityReference = ft.UltimateParent

	--FROM #FacilityLink f

	--INNER JOIN #CTEFacTree ft 
	--ON f.DeclarationReference = ft.ChildPolicyReference

	--WHERE ft.ParentLevel > 1

	--/*Update facility reference*/
	--UPDATE s 
	--SET Facility = fl.FacilityReference

	--FROM Staging.Section_temp s

	--INNER JOIN #FacilityLink fl 
	--ON s.SectionReference = fl.DeclarationReference


	
	--delete deactivated sections
	DELETE		o 
	FROM		Staging.Section o 
	LEFT JOIN	BeazleyIntelligenceDataContract.Outbound.vw_Section s 
			ON	o.SectionReference = s.SectionReference
	WHERE		s.SectionReference IS NULL
	AND o.SourceSystem <> 'ClaimCenter'


	--delete unverified policies which are not comming anymore from ClaimCenter
	DELETE		s
	FROM		Staging.Section s
	LEFT JOIN	(
				--this subquery is inspired from usp_LoadSection_Claims_Delta
				SELECT      SectionReference						= case when coveragename <> 'UNirisx' then  ISNULL(ce.SectionReference, p.PolicyReference) else p.PolicyReference + '-01' end--ISNULL(ce.SectionReference, p.PolicyNumber)
							,PolicyReference						= p.PolicyReference
				FROM		Staging.Policy p
				INNER JOIN	BeazleyIntelligenceDataContract.outbound.vw_Claim c 
						ON	c.PolicyNumber = p.PolicyReference
				LEFT JOIN 	(
							SELECT 		ClaimSourceId					= ce.ClaimSourceId
										,ClaimExposureSourceId			= ce.ClaimExposureSourceId
										,SectionReference				= cee.PrimarySectionName
										,CoverageName					= ce.CoverageName
										,RowId							= ROW_NUMBER()OVER (PARTITION BY cee.PrimarySectionName ORDER BY  ce.AuditCreateDateTime)
							FROM		BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce
							INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee
									ON	ce.ClaimSourceId = cee.ClaimSourceId 
									AND ce.ClaimExposureSourceId = cee.ClaimExposureSourceId
									AND cee.SourceSystem = ce.SourceSystem
							WHERE		ce.SourceSystem ='ClaimCenter' 
				) ce	ON	ce.ClaimSourceId = c.ClaimSourceId
				WHERE		c.SourceSystem ='ClaimCenter'
						AND ce.RowId = 1
						AND ISNULL(c.IsRetired, 0) = 0
	) cc
			ON	s.SectionReference = cc.SectionReference
	WHERE		s.SourceSystem = 'ClaimCenter'
			AND cc.SectionReference IS NULL

----Update SectionSequenceId with new values from DataContract
--UPDATE s
--SET  s.SectionSequenceId    = dc.SectionSequenceId
--    ,s.AuditModifyDateTime	= GETDATE()						
--	,s.AuditModifyDetails	= 'Update SectionSequenceId with new value from BeazleyIntelligenceDataContract '
--FROM Staging.section s
--INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section dc on s.SectionReference = dc.SectionReference
--WHERE  s.SectionSequenceId <> dc.SectionSequenceId

--Merge into Staging.Section		
;MERGE Staging.Section t
USING Staging.Section_Temp s
ON 
		t.SectionReference = s.SectionReference

WHEN MATCHED 
AND NOT
	(
		(t.SourceSystem = 'BeazleyPro' and s.SourceSystem = 'FDR')
			OR 
		(t.SourceSystem = 'Unirisx' and s.SourceSystem = 'StagingDataContract')
	)
	THEN 
		UPDATE SET
				 t.SectionDisplayReference													   =	s.SectionDisplayReference								
 				,t.SectionDescription														   =	s.SectionDescription										
 				,t.CoverageName																   =	s.CoverageName											
 				,t.SectionSequenceId														   =	s.SectionSequenceId
                ,t.FK_Policy															       =	s.FK_Policy	
 				,t.PolicyReference															   =	s.PolicyReference	
				,t.AccountHandler															   =	s.AccountHandler
				,t.ATIAClassOfBusinessCode													   =	s.ATIAClassOfBusinessCode								
 				,t.AdditionalExposures														   =	s.AdditionalExposures									
 				,t.AdjustmentBaseAmountInOriginalCCY										   =	s.AdjustmentBaseAmountInOriginalCCY						
 				,t.AdjustmentMultiplier														   =	s.AdjustmentMultiplier									
 				,t.AdjustmentPremiumInOriginalCCY											   =	s.AdjustmentPremiumInOriginalCCY							
 				,t.AdminPurposesFlag														   =	s.AdminPurposesFlag										
 				,t.AggregateAmount															   =	s.AggregateAmount										
 				,t.AggregateQualifier														   =	s.AggregateQualifier										
 				,t.AggregatesRequired														   =	s.AggregatesRequired										
 				,t.AgressoReference															   =	s.AgressoReference	
				,t.ProductIsMultiTransactional												   =	s.ProductIsMultiTransactional									
 				,t.AreaCode																	   =	s.AreaCode												
 				,t.BeazleyIsAgreementParty													   =	s.BeazleyIsAgreementParty								
 				,t.BeazleyOfficeLocation													   =	s.BeazleyOfficeLocation									
 				,t.BenchmarkApplies															   =	s.BenchmarkApplies										
 				,t.BenchmarkDate															   =	s.BenchmarkDate											
 				,t.BenchmarkMultiplier														   =	s.BenchmarkMultiplier									
 				,t.BIDeductible																   =	s.BIDeductible											
 				,t.Billings																	   =	s.Billings												
 				,t.BinderType																   =	s.BinderType												
 				,t.BreachResponseMultiplier													   =	s.BreachResponseMultiplier								
 				,t.BreachResponseParentSection												   =	s.BreachResponseParentSection
				,t.CancelledDate															   =	s.CancelledDate
				,t.CancelledReason															   =	s.CancelledReason		
 				,t.CapitaEntryTimeHours														   =	s.CapitaEntryTimeHours									
 				,t.CapitaQCTimeHours														   =	s.CapitaQCTimeHours	
				,t.CapitaTotalTimeHours														   =	s.CapitaTotalTimeHours		
 				,t.CarrierIndicator															   =	s.CarrierIndicator
 				,t.CheckStatusCode															   =	s.CheckStatusCode
				,t.CIPSRiskCode																   =	s.CIPSRiskCode				
 				,t.ClaimBasis																   =	s.ClaimBasis												
 				,t.ClaimBasisCode															   =	s.ClaimBasisCode	
				,t.ClaimDelegatedTo															   = 	s.ClaimDelegatedTo
 				,t.ClassOfBusinessCode														   =	s.ClassOfBusinessCode									
 				,t.ClientClassificationCode													   =	s.ClientClassificationCode								
 				,t.Comments                                                                    =    s.Comments
                ,t.Conditions																   =	s.Conditions												
 				,t.ConditionsCode															   =	s.ConditionsCode											
 				,t.ConstructionPeriodFrom                                                      =    s.ConstructionPeriodFrom                  
                ,t.ConstructionPeriodTo														   =	s.ConstructionPeriodTo									
 				,t.ConstructionTitle														   =	s.ConstructionTitle										
 				,t.ConstructionDays	                                                           =    s.ConstructionDays
                ,t.ConstructionMonths                                                          =    s.ConstructionMonths 
                ,t.ContractCertaintyControlsCompliantDate 									   =	s.ContractCertaintyControlsCompliantDate 				
 				,t.ContractCertaintyEnteredDate 											   =	s.ContractCertaintyEnteredDate 							
 				,t.ContractCertaintyFullyCompliantDate 										   =	s.ContractCertaintyFullyCompliantDate 					
 				,t.ContractCertaintyModifiedDate 											   =	s.ContractCertaintyModifiedDate 							
 				,t.ContractCertaintyPostBindComplete										   =	s.ContractCertaintyPostBindComplete						
 				,t.ContractCertaintyPreBindComplete											   =	s.ContractCertaintyPreBindComplete						
 				,t.ContractCertaintyPreBindSignatureDate 									   =	s.ContractCertaintyPreBindSignatureDate 					
 				,t.ContractCertaintyPrimaryCompleteDate 									   =	s.ContractCertaintyPrimaryCompleteDate 					
 				,t.ContractCertaintyQuestionNote											   =	s.ContractCertaintyQuestionNote
				,t.ContractCertaintyRequired 												   =	s.ContractCertaintyRequired 							
 				,t.ContractCertaintyStatus 													   =	s.ContractCertaintyStatus 								
 				,t.ContractCertaintyStatusSortOrder 										   =	s.ContractCertaintyStatusSortOrder 						
 				,t.CoreAccountType															   =	s.CoreAccountType										
 				,t.CoreAccountTypeCode														   =	s.CoreAccountTypeCode									
 				,t.Country																	   =	s.Country												
 				,t.CountryCode																   =	s.CountryCode											
 				,t.CoverageForm																   =	s.CoverageForm	
                ,t.CoverageSolution                                                            =    s.CoverageSolution
 				,t.CoverType																   =	s.CoverType												
 				,t.CrossSelling																   =	s.CrossSelling											
 				,t.CrossSellingInitiator													   =	s.CrossSellingInitiator									
 				,t.DateModified																   =	s.DateModified											
 				,t.DaysBetweenConstructionPhaseToandFrom									   =	s.DaysBetweenConstructionPhaseToandFrom					
 				,t.DaysBetweenMaintenanceFromAndTo											   =	s.DaysBetweenMaintenanceFromAndTo						
 				,t.DaysBetweenTestingFromAndTo												   =	s.DaysBetweenTestingFromAndTo							
 				,t.DeclarationWEPInOriginalCCY												   =	s.DeclarationWEPInOriginalCCY							
 				,t.DeductibleAmountInLimitCCY												   =	s.DeductibleAmountInLimitCCY								
 				,t.DeductibleQualifier														   =	s.DeductibleQualifier	
				,t.DelegatedClaimsAuthority													   =    s.DelegatedClaimsAuthority
 				,t.DepositPremiumInOriginalCCY												   =	s.DepositPremiumInOriginalCCY							
 				,t.EngineeringProjectName													   =	s.EngineeringProjectName									
 				,t.EngineeringSumInsuredInLimitCCY											   =	s.EngineeringSumInsuredInLimitCCY						
 				,t.EquipmentBreakdownContactName											   =	s.EquipmentBreakdownContactName							
 				,t.EquipmentBreakdownContactNumber											   =	s.EquipmentBreakdownContactNumber						
 				,t.EquipmentBreakdownReferral												   =	s.EquipmentBreakdownReferral	
                ,t.ESGPolicyFlag                                                               =    s.ESGPolicyFlag
 				,t.EstimatedSigningMultiplier												   =	s.EstimatedSigningMultiplier								
 				,t.EventLimitAmountInLimitCCY												   =	s.EventLimitAmountInLimitCCY								
 				,t.EventLimitDescription													   =	s.EventLimitDescription									
 				,t.EventLimitQualifier														   =	s.EventLimitQualifier									
 				,t.ExcessAmountInLimitCCY													   =	s.ExcessAmountInLimitCCY									
 				,t.ExcessQualifier															   =	s.ExcessQualifier										
                ,t.ExpensesMultiplier                                                          =    s.ExpensesMultiplier
 				,t.ExpiringSection															   =	s.ExpiringSection										
 				,t.ExpiryDate																   =	s.ExpiryDate												
 				,t.ExternalAcquisitionCostMultiplier										   =	s.ExternalAcquisitionCostMultiplier						
 				,t.FACRIIndicator															   =	s.FACRIIndicator											
 				,t.Facility																	   =	s.Facility												
 				,t.Fees																		   =	s.Fees													
 				,t.FirstLiveDate															   =	s.FirstLiveDate											
 				,t.FullQuoteReference														   =	s.FullQuoteReference										
 				,t.FullTimeEquivalents														   =	s.FullTimeEquivalents									
 				,t.GulfOfMexicoRiskPremiumMultiplier										   =	s.GulfOfMexicoRiskPremiumMultiplier						
 				,t.GulfOfMexicoWindstormMultiplier											   =	s.GulfOfMexicoWindstormMultiplier						
 				,t.HasConsortiumLink                                                           =    s.HasConsortiumLink 
        ,t.HasGulfOfMexicoExposure													   =	s.HasGulfOfMexicoExposure								
 				,t.HasMultiYearLink															   =	s.HasMultiYearLink	
        ,t.HasParentLink                                                               =    s.HasParentLink
 				,t.HazardClass																   =	s.HazardClass											
 				,t.HiddenStatusFilter														   =	s.HiddenStatusFilter										
 				,t.ITVPerSQFT																   =	s.ITVPerSQFT												
 				,t.InceptionDate															   =	s.InceptionDate											
 				,t.IncludeInMunichStacking													   =	s.IncludeInMunichStacking	
                ,t.IncludePML                                                                  =    s.IncludePML
 				,t.Industry																	   =	s.Industry												
 				,t.IndustryCode																   =	s.IndustryCode											
 				,t.IndustryCodeQualifier													   =	s.IndustryCodeQualifier									
 				,t.InnovationCampaign														   =	s.InnovationCampaign										
 				,t.InnovationPremiumMultiplier												   =	s.InnovationPremiumMultiplier	
				,t.InsuredItem																   =	s.InsuredItem						
 				,t.Interest																	   =	s.Interest												
 				,t.InterestCode																   =	s.InterestCode											
 				,t.InwardQuotaShareMultiplier												   =	s.InwardQuotaShareMultiplier								
 				,t.IsBeazleyLead															   =	s.IsBeazleyLead											
 				,t.IsBreachResponseDummy													   =	s.IsBreachResponseDummy									
 				,t.IsQuote																	   =	s.IsQuote												
 				,t.IsRenewal																   =	s.IsRenewal												
 				,t.IsRapidRenewal															   =	s.IsRapidRenewal											
 				,t.IsSigned																	   =	s.IsSigned												
 				,t.IsSynergySection															   =	s.IsSynergySection										
 				,t.KeyLocationAddress1														   =	s.KeyLocationAddress1									
 				,t.KeyLocationAddress2														   =	s.KeyLocationAddress2									
 				,t.KeyLocationCity															   =	s.KeyLocationCity										
 				,t.KeyLocationCountry														   =	s.KeyLocationCountry										
 				,t.KeyLocationState															   =	s.KeyLocationState										
 				,t.KeyLocationStreetNumber													   =	s.KeyLocationStreetNumber								
 				,t.KeyLocationZipCode														   =	s.KeyLocationZipCode	
				,t.LargeRiskReviewerUserInitials											   =	s.LargeRiskReviewerUserInitials								
 				,t.LatestEPIInOriginalCCY													   =	s.LatestEPIInOriginalCCY									
 				,t.LeaderName																   =	s.LeaderName												
 				,t.LeaderPseudonym															   =	s.LeaderPseudonym										
 				,t.LimitAmountInLimitCCY													   =	s.LimitAmountInLimitCCY									
 				,t.LimitAmountInOriginalCCY													   =	s.LimitAmountInOriginalCCY								
 				,t.LimitCCY																	   =	s.LimitCCY												
 				,t.LimitCCYToSettlementCCYRateCurrent										   =	s.LimitCCYToSettlementCCYRateCurrent						
 				,t.LimitCCYToSettlementCCYRateMelded										   =	s.LimitCCYToSettlementCCYRateMelded						
 				,t.LimitDescription															   =	s.LimitDescription										
 				,t.LimitMeldedRate															   =	s.LimitMeldedRate										
 				,t.LimitQualifier															   =	s.LimitQualifier
                ,t.LimitTypeCode                                                               =    s.LimitTypeCode
                ,t.LimitTypeDescription                                                        =    s.LimitTypeDescription
				,t.LinkedConsortiumReference												   =    s.LinkedConsortiumReference
                ,t.LinkedESGBinderReference							                           =    s.LinkedESGBinderReference
		        ,t.LinkedESGSectionReference							                       =    s.LinkedESGSectionReference
 				,t.LinkedNonSynergyReference												   =	s.LinkedNonSynergyReference								
                ,t.LinkedParentReference                                                       =    s.LinkedParentReference
 				,t.LinkedSynergySection														   =	s.LinkedSynergySection									
 				,t.LloydsClassOfBusiness													   =	s.LloydsClassOfBusiness									
 				,t.LloydsClassOfBusinessCode												   =	s.LloydsClassOfBusinessCode								
 				,t.LocalCurrency															   =	s.LocalCurrency											
 				,t.MailingAddress1															   =	s.MailingAddress1										
 				,t.MailingAddress2															   =	s.MailingAddress2										
 				,t.MailingCity																   =	s.MailingCity											
 				,t.MailingState																   =	s.MailingState											
 				,t.MailingZipCode															   =	s.MailingZipCode											
 				,t.MaintenancePeriodFrom													   =	s.MaintenancePeriodFrom									
 				,t.MaintenancePeriodTo														   =	s.MaintenancePeriodTo									
 				,t.MaintenanceMonths                                                           =    s.MaintenanceMonths
                ,t.MASTerritory																   =	s.MASTerritory											
 				,t.MarketCapitalisation														   =	s.MarketCapitalisation									
 				,t.MigratedPolicy															   =	s.MigratedPolicy											
 				,t.MinimumPremiumInOriginalCCY												   =	s.MinimumPremiumInOriginalCCY							
 				,t.MultiYearGroupReference													   =	s.MultiYearGroupReference								
 				,t.MultiYearIndicator														   =	s.MultiYearIndicator	
                ,t.NewConditionsExpiryDate                                                     =    s.NewConditionsExpiryDate
 				,t.NotifiedIndividuals														   =	s.NotifiedIndividuals									
 				,t.NotifiedIndividualsName													   =	s.NotifiedIndividualsName								
 				,t.NumberOfEmployees														   =	s.NumberOfEmployees										
 				,t.NumberOfLawyers															   =	s.NumberOfLawyers										
 				,t.NumberOfLives															   =	s.NumberOfLives
				,t.NumberOfLocations														   =	s.NumberOfLocations
 				,t.NumberOfReinstatements													   =	s.NumberOfReinstatements									
 				,t.Obligor																	   =	s.Obligor												
 				,t.ObligorOccupation														   =	s.ObligorOccupation										
 				,t.ObligorOccupationCode													   =	s.ObligorOccupationCode									
 				,t.Occupation																   =	s.Occupation												
 				,t.OccupationCode															   =	s.OccupationCode											
 				,t.OriginalCCY																   =	s.OriginalCCY											
 				,t.OriginalCCYToLocalCCYRate												   =	s.OriginalCCYToLocalCCYRate								
 				,t.OriginalCCYToSettlementCCYRate											   =	s.OriginalCCYToSettlementCCYRate							
 				,t.OriginalCoverageName														   =	s.OriginalCoverageName									
 				,t.OriginalEPIInOriginalCCY													   =	s.OriginalEPIInOriginalCCY								
 				,t.OriginalEPITotalAcquisitionCostMultiplier								   =	s.OriginalEPITotalAcquisitionCostMultiplier				
 				,t.OriginalGrossPremiumInOriginalCCY										   =	s.OriginalGrossPremiumInOriginalCCY						
 				,t.OriginalInsured															   =	s.OriginalInsured										
 				,t.OriginalInsuredArea														   =	s.OriginalInsuredArea									
 				,t.OriginalInsuredAreaCode													   =	s.OriginalInsuredAreaCode								
 				,t.OriginalLimitInOriginalCCY												   =	s.OriginalLimitInOriginalCCY
				,t.OriginatingSourceSystem  												   =	s.OriginatingSourceSystem						
 				,t.PDDeductible																   =	s.PDDeductible	
                ,t.PDSI                                                                        =    s.PDSI
 				,t.PMLExposure																   =	s.PMLExposure
                ,t.PMLExposureOurShareUSD			                                           =    s.PMLExposureOurShareUSD
                ,t.PMLExposure100PerctShareUSD	                                               =    s.PMLExposure100PerctShareUSD
                ,t.PMLExposure100PerctShareOrigCcy                                             =    s.PMLExposure100PerctShareOrigCcy
                ,t.PMLPercentage                                                               =    s.PMLPercentage
                ,t.TSI100PercForPMLOrigCcy                                                     =    s.TSI100PercForPMLOrigCcy
                ,t.PolicyRate                                                                  =    s.PolicyRate
 				,t.Peril												    				   =	s.Peril													
 				,t.PerilCode																   =	s.PerilCode												
 				,t.PremiumIncomeLimitInOriginalCCY											   =	s.PremiumIncomeLimitInOriginalCCY						
 				,t.PremiumRates																   =	s.PremiumRates			
				,t.PrimaryLegacyReference													   =    s.PrimaryLegacyReference
 				,t.PrimaryOrExcess															   =	s.PrimaryOrExcess										
 				,t.PrimarySectionURL														   =	s.PrimarySectionURL										
 				,t.PrimarySectionURLLabel													   =	s.PrimarySectionURLLabel									
 				,t.Product																	   =	s.Product												
 				,t.ProfitCommissionMultiplier												   =	s.ProfitCommissionMultiplier								
 				,t.ProgramName																   =	s.ProgramName											
 				,t.ProgramNumber															   =	s.ProgramNumber											
 				,t.ProgramPeriod															   =	s.ProgramPeriod											
 				,t.ProgramType                                                                 =    s.ProgramType                                                               
                ,t.ProgramYear                                                                 =    s.ProgramYear              
                ,t.QuoteBoundSectionReference												   =	s.QuoteBoundSectionReference								
 				,t.QuoteDaysValid															   =	s.QuoteDaysValid											
 				,t.QuoteLapsedDate															   =	s.QuoteLapsedDate										
 				,t.QuoteOrBindDate															   =	s.QuoteOrBindDate	
				,t.RatingAdequacyMultiplier													   =	s.RatingAdequacyMultiplier
 				,t.RateChangeControlComplete												   =	s.RateChangeControlComplete
 				,t.RateChangeDate															   =	s.RateChangeDate											
 				,t.RateChangeDeductibleMultiplier											   =	s.RateChangeDeductibleMultiplier							
 				,t.RateChangeExposureMultiplier												   =	s.RateChangeExposureMultiplier							
 				,t.RateChangeLimitMultiplier												   =	s.RateChangeLimitMultiplier								
 				,t.RateChangeMethod															   =	s.RateChangeMethod										
 				,t.RateChangeMultiplier														   =	s.RateChangeMultiplier									
 				,t.RateChangeOtherMultiplier												   =	s.RateChangeOtherMultiplier								
 				,t.RateChangeRiskMultiplier													   =	s.RateChangeRiskMultiplier								
 				,t.RateChangeTermsAndConditionsMultiplier									   =	s.RateChangeTermsAndConditionsMultiplier					
 				,t.RateOnLineMultiplierEntered												   =	s.RateOnLineMultiplierEntered							
 				,t.RateOnLinePremiumEnteredInOriginalCCY									   =	s.RateOnLinePremiumEnteredInOriginalCCY					
 				,t.RationaleQuestionnaireComplete											   =	s.RationaleQuestionnaireComplete							
 				,t.RationaleQuestionnaireDate												   =	s.RationaleQuestionnaireDate								
 				,t.ReSigningIndicator														   =	s.ReSigningIndicator										
 				,t.ReactivationReason														   =	s.ReactivationReason										
 				,t.ReactivationReasonCode													   =	s.ReactivationReasonCode									
 				,t.ReinstatementMultiplier													   =	s.ReinstatementMultiplier								
 				,t.ReinstatementPremiumInOriginalCCY										   =	s.ReinstatementPremiumInOriginalCCY						
 				,t.ReinsuranceIndicator														   =	s.ReinsuranceIndicator									
 				,t.RetroInceptionDate														   =	s.RetroInceptionDate										
 				,t.Revenues																	   =	s.Revenues												
 				,t.RiskClass																   =	s.RiskClass												
 				,t.RiskClassCode															   =	s.RiskClassCode											
 				,t.SICCode																	   =	s.SICCode	
                ,t.SigningNumberDate                                                           =    s.SigningNumberDate
                ,t.SLSpecificCoverage														   =	s.SLSpecificCoverage	
				,t.ReKeyReference            												   =    s.ReKeyReference 
                ,t.ReKeySource                                                                 =    s.ReKeySource
 				,t.SecondarySectionURL														   =	s.SecondarySectionURL									
 				,t.SecondarySectionURLLabel													   =	s.SecondarySectionURLLabel								
 				,t.SectionReferenceCOBCode													   =	s.SectionReferenceCOBCode								
 				,t.SectionReferenceReinsuranceIndicator										   =	s.SectionReferenceReinsuranceIndicator					
 				,t.SectionReferenceSectionIdentifier										   =	s.SectionReferenceSectionIdentifier						
 				,t.SectionStatus															   =	s.SectionStatus											
 				,t.SectionStatusCode														   =	s.SectionStatusCode	
				,t.ServiceCompanyCode														   =	s.ServiceCompanyCode											
 				,t.SettlementCCY															   =	s.SettlementCCY										
 				,t.SignedLineMultiplier														   =	s.SignedLineMultiplier									
 				,t.SignedOrderMultiplier													   =	s.SignedOrderMultiplier									
 				,t.SpecialPurposeSyndicateApplies											   =	s.SpecialPurposeSyndicateApplies							
 				,t.StatsCode																   =	s.StatsCode												
 				,t.StatsDescription															   =	s.StatsDescription										
 				,t.SubmissionDate															   =	s.SubmissionDate											
 				,t.SwordTreatyCoverage														   =	s.SwordTreatyCoverage	
                ,t.TechnicalPremium                                                            =    s.TechnicalPremium
 				,t.TermsOfTradeDate															   =	s.TermsOfTradeDate	
                ,t.TotalSIExposureOurShare                                                     =    s.TotalSIExposureOurShare
 				,t.TerritorialFocusGroup                                                       =    s.TerritorialFocusGroup              
                ,t.TerrorismReference 														   =	s.TerrorismReference 									
 				,t.TestingPeriodFrom														   =	s.TestingPeriodFrom										
 				,t.TestingPeriodTo															   =	s.TestingPeriodTo
                ,t.TestingMonths                                                               =    s.TestingMonths
 				,t.TimeExcess																   =	s.TimeExcess
                ,t.TimeExcessAmount                                                            =    s.TimeExcessAmount
 				,t.TopLocationTSI															   =	s.TopLocationTSI											
 				,t.TotalSumInsured															   =	s.TotalSumInsured										
 				,t.TransactionLiabilityProject												   =	s.TransactionLiabilityProject	
                ,t.TransactionType                                                             =    s.TransactionType
                ,t.TransactionTypeCode                                                         =    s.TransactionTypeCode
 				,t.TransactionValue															   =	s.TransactionValue										
 				,t.TriFocus																	   =	s.TriFocus										
 				,t.UltimateLossRatioMultiplier												   =	s.UltimateLossRatioMultiplier							
 				,t.UnderwriterAssistantContractCertaintyUserInitials						   =	s.UnderwriterAssistantContractCertaintyUserInitials		
 				,t.UnderwriterContractCertainty												   =	s.UnderwriterContractCertainty							
 				,t.UnderwriterContractCertaintyUserInitials									   =	s.UnderwriterContractCertaintyUserInitials				
 				,t.UnderwriterUserInitials													   =	s.UnderwriterUserInitials								
 				,t.UnderwritingPlatformCode													   =	s.UnderwritingPlatformCode								
 				,t.USUnderwritingCoverageCode												   =	s.USUnderwritingCoverageCode
				,t.VATNumber																   =	s.VATNumber								
 				,t.WEPLastUpdatedDate														   =	s.WEPLastUpdatedDate										
 				,t.WrittenIfNotSignedLineMultiplier											   =	s.WrittenIfNotSignedLineMultiplier						
 				,t.WrittenLineMultiplier													   =	s.WrittenLineMultiplier									
 				,t.WrittenOrEstimatedPremiumInOriginalCCY									   =	s.WrittenOrEstimatedPremiumInOriginalCCY	
                ,t.WEPBasis                                                                    =    s.WEPBasis
 				,t.WrittenOrderMultiplier													   =	s.WrittenOrderMultiplier									
				,t.TotalWrittenMultiplier													   =	s.TotalWrittenMultiplier									
				,t.WrittenIfNotSignedOrderMultiplier										   =	s.WrittenIfNotSignedOrderMultiplier						
				,t.TotalWrittenIfNotSignedMultiplier										   =	s.TotalWrittenIfNotSignedMultiplier						
 				,t.DQ_AdditionalInsuredParty												   =	s.DQ_AdditionalInsuredParty								
 				,t.DQ_Address1																   =	s.DQ_Address1											
 				,t.DQ_Address2																   =	s.DQ_Address2											
 				,t.DQ_Address3																   =	s.DQ_Address3											
 				,t.DQ_InsuredParty															   =	s.DQ_InsuredParty										
 				,t.DQ_MethodOfPlacementCode													   =	s.DQ_MethodOfPlacementCode								
 				,t.DQ_NoticeOfClaimBrokerNumber												   =	s.DQ_NoticeOfClaimBrokerNumber							
 				,t.DQ_PlacingBrokerContact													   =	s.DQ_PlacingBrokerContact								
 				,t.DQ_PlacingBrokerNumber													   =	s.DQ_PlacingBrokerNumber									
 				,t.DQ_ProducingBrokerContact												   =	s.DQ_ProducingBrokerContact								
 				,t.DQ_ProducingBrokerNumber													   =	s.DQ_ProducingBrokerNumber								
 				,t.DQ_ReinsuredParty														   =	s.DQ_ReinsuredParty										
 				,t.DQ_ServiceOfSuitBrokerNumber												   =	s.DQ_ServiceOfSuitBrokerNumber							
 				,t.DQ_UniqueMarketReference													   =	s.DQ_UniqueMarketReference								
 				,t.DQ_YOA																	   =	s.DQ_YOA
				,t.UnderwriterRiskEnteredBy													   =	s.UnderwriterRiskEnteredBy
				,t.UnderwriterAssistant														   =	s.UnderwriterAssistant
 				,t.UnderwriterName															   =	s.UnderwriterName
				,t.HashbytesId																   =	s.HashbytesId		
				,t.DurationMonths     														   =	s.DurationMonths     			
				--,t.DaysSinceQuoteOrBindDate       											   =	s.DaysSinceQuoteOrBindDate       
				--,t.DaysBetweenQBAndRateChangeDate 											   =	s.DaysBetweenQBAndRateChangeDate 
				--,t.DaysBetweenQBAndBenchmarkDate  											   =	s.DaysBetweenQBAndBenchmarkDate  
				,t.MonthsSinceInception           											   =	s.MonthsSinceInception           
				,t.MonthsSinceTOT     														   =	s.MonthsSinceTOT     
				,t.LiveStatus																   =	s.LiveStatus									
				,t.TermsOfTradeExpired						            					   =	s.TermsOfTradeExpired						            
				,t.DaysBetweenQBAndCCCCDateOrToday         									   =	s.DaysBetweenQBAndCCCCDateOrToday         
				,t.DaysBetweenQBAndCCFCDateOrToday         									   =	s.DaysBetweenQBAndCCFCDateOrToday         
				,t.DaysBetweenQBAndCCPCDateOrToday         									   =	s.DaysBetweenQBAndCCPCDateOrToday         
				,t.DaysBetweenQBAndCCPCOrCCPBSDateOrToday  									   =	s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday  
				,t.NoticeDate																   =	s.NoticeDate								
				,t.NotificationThreshold													   =	s.NotificationThreshold					
				,t.TacitRenewal																   =	s.TacitRenewal
				,t.IsPolicyholderAPrivateIndividual											   =	s.IsPolicyholderAPrivateIndividual
				,t.AuditModifyDateTime						=	GETDATE()						
				,t.AuditModifyDetails						=	'Merge from `Staging.usp_LoadSection` procedure'
				
WHEN NOT MATCHED BY TARGET THEN
		
INSERT 
(
	 	SourceSystem
 		,SectionReference										
 		,SectionDisplayReference								
 		,SectionDescription										
 		,CoverageName											
 		,SectionSequenceId										
 		,PolicyReference	
		,AccountHandler
 		,ATIAClassOfBusinessCode								
 		,AdditionalExposures									
 		,AdjustmentBaseAmountInOriginalCCY						
 		,AdjustmentMultiplier									
 		,AdjustmentPremiumInOriginalCCY							
 		,AdminPurposesFlag										
 		,AggregateAmount										
 		,AggregateQualifier										
 		,AggregatesRequired										
 		,AgressoReference	
		,ProductIsMultiTransactional									
 		,AreaCode												
 		,BeazleyIsAgreementParty								
 		,BeazleyOfficeLocation									
 		,BenchmarkApplies										
 		,BenchmarkDate											
 		,BenchmarkMultiplier									
 		,BIDeductible											
 		,Billings												
 		,BinderType												
 		,BreachResponseMultiplier								
 		,BreachResponseParentSection
		,CancelledDate
		,CancelledReason		
 		,CapitaEntryTimeHours									
 		,CapitaQCTimeHours	
		,CapitaTotalTimeHours		
 		,CarrierIndicator
 		,CheckStatusCode
		,CIPSRiskCode				
 		,ClaimBasis												
 		,ClaimBasisCode		
		,ClaimDelegatedTo
 		,ClassOfBusinessCode									
 		,ClientClassificationCode		
        ,Comments
 		,Conditions												
 		,ConditionsCode											
 		,ConstructionPeriodFrom 
        ,ConstructionPeriodTo									
 		,ConstructionTitle	
        ,ConstructionDays	  
        ,ConstructionMonths 
 		,ContractCertaintyControlsCompliantDate 				
 		,ContractCertaintyEnteredDate 							
 		,ContractCertaintyFullyCompliantDate 					
 		,ContractCertaintyModifiedDate 							
 		,ContractCertaintyPostBindComplete						
 		,ContractCertaintyPreBindComplete						
 		,ContractCertaintyPreBindSignatureDate 					
 		,ContractCertaintyPrimaryCompleteDate 					
 		,ContractCertaintyQuestionNote
		,ContractCertaintyRequired 							
 		,ContractCertaintyStatus 								
 		,ContractCertaintyStatusSortOrder 						
 		,CoreAccountType										
 		,CoreAccountTypeCode									
 		,Country												
 		,CountryCode											
 		,CoverageForm		
        ,CoverageSolution
 		,CoverType												
 		,CrossSelling											
 		,CrossSellingInitiator									
 		,DateModified											
 		,DaysBetweenConstructionPhaseToandFrom					
 		,DaysBetweenMaintenanceFromAndTo						
 		,DaysBetweenTestingFromAndTo							
 		,DeclarationWEPInOriginalCCY							
 		,DeductibleAmountInLimitCCY								
 		,DeductibleQualifier	
		,DelegatedClaimsAuthority
 		,DepositPremiumInOriginalCCY							
 		,EngineeringProjectName									
 		,EngineeringSumInsuredInLimitCCY						
 		,EquipmentBreakdownContactName							
 		,EquipmentBreakdownContactNumber						
 		,EquipmentBreakdownReferral	
        ,ESGPolicyFlag
 		,EstimatedSigningMultiplier								
 		,EventLimitAmountInLimitCCY								
 		,EventLimitDescription									
 		,EventLimitQualifier									
 		,ExcessAmountInLimitCCY									
 		,ExcessQualifier
        ,ExpensesMultiplier
 		,ExpiringSection										
 		,ExpiryDate												
 		,ExternalAcquisitionCostMultiplier						
 		,FACRIIndicator											
 		,Facility												
 		,Fees													
 		,FirstLiveDate											
 		,FullQuoteReference										
 		,FullTimeEquivalents									
 		,GulfOfMexicoRiskPremiumMultiplier						
 		,GulfOfMexicoWindstormMultiplier						
    ,HasConsortiumLink 
 		,HasGulfOfMexicoExposure								
 		,HasMultiYearLink				
        ,HasParentLink
 		,HazardClass											
 		,HiddenStatusFilter										
 		,ITVPerSQFT												
 		,InceptionDate											
 		,IncludeInMunichStacking					
        ,IncludePML
 		,Industry												
 		,IndustryCode											
 		,IndustryCodeQualifier									
 		,InnovationCampaign										
 		,InnovationPremiumMultiplier	
		,InsuredItem						
 		,Interest												
 		,InterestCode											
 		,InwardQuotaShareMultiplier								
 		,IsBeazleyLead											
 		,IsBreachResponseDummy									
 		,IsQuote												
 		,IsRenewal												
 		,IsRapidRenewal											
 		,IsSigned												
 		,IsSynergySection										
 		,KeyLocationAddress1									
 		,KeyLocationAddress2									
 		,KeyLocationCity										
 		,KeyLocationCountry										
 		,KeyLocationState										
 		,KeyLocationStreetNumber								
 		,KeyLocationZipCode	
		,LargeRiskReviewerUserInitials									
 		,LatestEPIInOriginalCCY									
 		,LeaderName												
 		,LeaderPseudonym										
 		,LimitAmountInLimitCCY									
 		,LimitAmountInOriginalCCY								
 		,LimitCCY												
 		,LimitCCYToSettlementCCYRateCurrent						
 		,LimitCCYToSettlementCCYRateMelded						
 		,LimitDescription										
 		,LimitMeldedRate										
 		,LimitQualifier		
        ,LimitTypeCode
        ,LimitTypeDescription
		,LinkedConsortiumReference
        ,LinkedESGBinderReference
		,LinkedESGSectionReference
 		,LinkedNonSynergyReference			
        ,LinkedParentReference
 		,LinkedSynergySection									
 		,LloydsClassOfBusiness									
 		,LloydsClassOfBusinessCode								
 		,LocalCurrency											
 		,MailingAddress1										
 		,MailingAddress2										
 		,MailingCity											
 		,MailingState											
 		,MailingZipCode											
 		,MaintenancePeriodFrom									
 		,MaintenancePeriodTo	
        ,MaintenanceMonths
 		,MASTerritory											
 		,MarketCapitalisation									
 		,MigratedPolicy											
 		,MinimumPremiumInOriginalCCY							
 		,MultiYearGroupReference								
 		,MultiYearIndicator		
        ,NewConditionsExpiryDate
 		,NotifiedIndividuals									
 		,NotifiedIndividualsName								
 		,NumberOfEmployees										
 		,NumberOfLawyers										
 		,NumberOfLives
		,NumberOfLocations
 		,NumberOfReinstatements									
 		,Obligor												
 		,ObligorOccupation										
 		,ObligorOccupationCode									
 		,Occupation												
 		,OccupationCode											
 		,OriginalCCY											
 		,OriginalCCYToLocalCCYRate								
 		,OriginalCCYToSettlementCCYRate							
 		,OriginalCoverageName									
 		,OriginalEPIInOriginalCCY								
 		,OriginalEPITotalAcquisitionCostMultiplier				
 		,OriginalGrossPremiumInOriginalCCY						
 		,OriginalInsured										
 		,OriginalInsuredArea									
 		,OriginalInsuredAreaCode								
 		,OriginalLimitInOriginalCCY
		,OriginatingSourceSystem						
 		,PDDeductible			
        ,PDSI
 		,PMLExposure
        ,PMLExposureOurShareUSD				
        ,PMLExposure100PerctShareUSD	   
        ,PMLExposure100PerctShareOrigCcy 
        ,PMLPercentage   
        ,TSI100PercForPMLOrigCcy
        ,PolicyRate                                            
 		,Peril													
 		,PerilCode												
 		,PremiumIncomeLimitInOriginalCCY						
 		,PremiumRates	
		,PrimaryLegacyReference
 		,PrimaryOrExcess										
 		,PrimarySectionURL										
 		,PrimarySectionURLLabel									
 		,Product												
 		,ProfitCommissionMultiplier								
 		,ProgramName											
 		,ProgramNumber											
 		,ProgramPeriod											
 		,ProgramType 
        ,ProgramYear 
        ,QuoteBoundSectionReference								
 		,QuoteDaysValid											
 		,QuoteLapsedDate										
 		,QuoteOrBindDate		
		,RatingAdequacyMultiplier
 		,RateChangeControlComplete
 		,RateChangeDate											
 		,RateChangeDeductibleMultiplier							
 		,RateChangeExposureMultiplier							
 		,RateChangeLimitMultiplier								
 		,RateChangeMethod										
 		,RateChangeMultiplier									
 		,RateChangeOtherMultiplier								
 		,RateChangeRiskMultiplier								
 		,RateChangeTermsAndConditionsMultiplier					
 		,RateOnLineMultiplierEntered							
 		,RateOnLinePremiumEnteredInOriginalCCY					
 		,RationaleQuestionnaireComplete							
 		,RationaleQuestionnaireDate								
 		,ReSigningIndicator										
 		,ReactivationReason										
 		,ReactivationReasonCode									
 		,ReinstatementMultiplier								
 		,ReinstatementPremiumInOriginalCCY						
 		,ReinsuranceIndicator									
 		,RetroInceptionDate										
 		,Revenues												
 		,RiskClass												
 		,RiskClassCode											
 		,SICCode	
        ,SigningNumberDate  
 		,SLSpecificCoverage	
		,ReKeyReference 
        ,ReKeySource
 		,SecondarySectionURL									
 		,SecondarySectionURLLabel								
 		,SectionReferenceCOBCode								
 		,SectionReferenceReinsuranceIndicator					
 		,SectionReferenceSectionIdentifier						
 		,SectionStatus											
 		,SectionStatusCode	
		,ServiceCompanyCode											
 		,SettlementCCY										
 		,SignedLineMultiplier									
 		,SignedOrderMultiplier									
 		,SpecialPurposeSyndicateApplies							
 		,StatsCode												
 		,StatsDescription										
 		,SubmissionDate											
 		,SwordTreatyCoverage	
        ,TechnicalPremium
 		,TermsOfTradeDate		
        ,TotalSIExposureOurShare
 		,TerritorialFocusGroup 
        ,TerrorismReference 									
 		,TestingPeriodFrom										
 		,TestingPeriodTo		
        ,TestingMonths
 		,TimeExcess	
        ,TimeExcessAmount
 		,TopLocationTSI											
 		,TotalSumInsured										
 		,TransactionLiabilityProject
        ,TransactionType
        ,TransactionTypeCode
 		,TransactionValue										
 		,TriFocus										
 		,UltimateLossRatioMultiplier							
 		,UnderwriterAssistantContractCertaintyUserInitials		
 		,UnderwriterContractCertainty							
 		,UnderwriterContractCertaintyUserInitials				
 		,UnderwriterUserInitials								
 		,UnderwritingPlatformCode								
 		,USUnderwritingCoverageCode
		,VATNumber								
 		,WEPLastUpdatedDate										
 		,WrittenIfNotSignedLineMultiplier						
 		,WrittenLineMultiplier									
 		,WrittenOrEstimatedPremiumInOriginalCCY	
        ,WEPBasis
 		,WrittenOrderMultiplier									
 		,TotalWrittenMultiplier									
		,WrittenIfNotSignedOrderMultiplier						
		,TotalWrittenIfNotSignedMultiplier						
		,DQ_AdditionalInsuredParty								
 		,DQ_Address1											
 		,DQ_Address2											
 		,DQ_Address3											
 		,DQ_InsuredParty										
 		,DQ_MethodOfPlacementCode								
 		,DQ_NoticeOfClaimBrokerNumber							
 		,DQ_PlacingBrokerContact								
 		,DQ_PlacingBrokerNumber									
 		,DQ_ProducingBrokerContact								
 		,DQ_ProducingBrokerNumber								
 		,DQ_ReinsuredParty										
 		,DQ_ServiceOfSuitBrokerNumber							
 		,DQ_UniqueMarketReference								
 		,DQ_YOA
		,UnderwriterRiskEnteredBy
		,UnderwriterAssistant
 		,UnderwriterName
		,HashbytesId		
		,DurationMonths     			
		--,DaysSinceQuoteOrBindDate       
		--,DaysBetweenQBAndRateChangeDate 
		--,DaysBetweenQBAndBenchmarkDate  
		,MonthsSinceInception           
		,MonthsSinceTOT     
		,LiveStatus									
		,TermsOfTradeExpired						            
		,DaysBetweenQBAndCCCCDateOrToday         
		,DaysBetweenQBAndCCFCDateOrToday         
		,DaysBetweenQBAndCCPCDateOrToday         
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday  
		,NoticeDate								
		,NotificationThreshold					
		,TacitRenewal
		,IsPolicyholderAPrivateIndividual
		,AuditCreateDateTime
		,AuditModifyDetails	
)
Values
(
		 s.SourceSystem
 		,s.SectionReference										
 		,s.SectionDisplayReference								
 		,s.SectionDescription										
 		,s.CoverageName											
 		,s.SectionSequenceId										
 		,s.PolicyReference	
		,s.AccountHandler
		,s.ATIAClassOfBusinessCode								
 		,s.AdditionalExposures									
 		,s.AdjustmentBaseAmountInOriginalCCY						
 		,s.AdjustmentMultiplier									
 		,s.AdjustmentPremiumInOriginalCCY							
 		,s.AdminPurposesFlag										
 		,s.AggregateAmount										
 		,s.AggregateQualifier										
 		,s.AggregatesRequired										
 		,s.AgressoReference	
		,s.ProductIsMultiTransactional									
 		,s.AreaCode												
 		,s.BeazleyIsAgreementParty								
 		,s.BeazleyOfficeLocation									
 		,s.BenchmarkApplies										
 		,s.BenchmarkDate											
 		,s.BenchmarkMultiplier									
 		,s.BIDeductible											
 		,s.Billings												
 		,s.BinderType												
 		,s.BreachResponseMultiplier								
 		,s.BreachResponseParentSection
		,s.CancelledDate
		,s.CancelledReason		
 		,s.CapitaEntryTimeHours									
 		,s.CapitaQCTimeHours	
		,s.CapitaTotalTimeHours		
 		,s.CarrierIndicator
 		,s.CheckStatusCode
		,s.CIPSRiskCode				
 		,s.ClaimBasis												
 		,s.ClaimBasisCode	
		,s.ClaimDelegatedTo
 		,s.ClassOfBusinessCode									
 		,s.ClientClassificationCode		
        ,s.Comments
 		,s.Conditions												
 		,s.ConditionsCode
        ,s.ConstructionPeriodFrom 
 		,s.ConstructionPeriodTo									
 		,s.ConstructionTitle		
        ,s.ConstructionDays	  
        ,s.ConstructionMonths 
 		,s.ContractCertaintyControlsCompliantDate 				
 		,s.ContractCertaintyEnteredDate 							
 		,s.ContractCertaintyFullyCompliantDate 					
 		,s.ContractCertaintyModifiedDate 							
 		,s.ContractCertaintyPostBindComplete						
 		,s.ContractCertaintyPreBindComplete						
 		,s.ContractCertaintyPreBindSignatureDate 					
 		,s.ContractCertaintyPrimaryCompleteDate 					
 		,s.ContractCertaintyQuestionNote
		,s.ContractCertaintyRequired 							
 		,s.ContractCertaintyStatus 								
 		,s.ContractCertaintyStatusSortOrder 						
 		,s.CoreAccountType										
 		,s.CoreAccountTypeCode									
 		,s.Country												
 		,s.CountryCode											
 		,s.CoverageForm		
        ,s.CoverageSolution
 		,s.CoverType												
 		,s.CrossSelling											
 		,s.CrossSellingInitiator									
 		,s.DateModified											
 		,s.DaysBetweenConstructionPhaseToandFrom					
 		,s.DaysBetweenMaintenanceFromAndTo						
 		,s.DaysBetweenTestingFromAndTo							
 		,s.DeclarationWEPInOriginalCCY							
 		,s.DeductibleAmountInLimitCCY								
 		,s.DeductibleQualifier	
		,s.DelegatedClaimsAuthority
 		,s.DepositPremiumInOriginalCCY							
 		,s.EngineeringProjectName									
 		,s.EngineeringSumInsuredInLimitCCY						
 		,s.EquipmentBreakdownContactName							
 		,s.EquipmentBreakdownContactNumber						
 		,s.EquipmentBreakdownReferral	
        ,s.ESGPolicyFlag
 		,s.EstimatedSigningMultiplier								
 		,s.EventLimitAmountInLimitCCY								
 		,s.EventLimitDescription									
 		,s.EventLimitQualifier									
 		,s.ExcessAmountInLimitCCY									
 		,s.ExcessQualifier		
        ,s.ExpensesMultiplier
 		,s.ExpiringSection										
 		,s.ExpiryDate												
 		,s.ExternalAcquisitionCostMultiplier						
 		,s.FACRIIndicator											
 		,s.Facility												
 		,s.Fees													
 		,s.FirstLiveDate											
 		,s.FullQuoteReference										
 		,s.FullTimeEquivalents									
 		,s.GulfOfMexicoRiskPremiumMultiplier						
 		,s.GulfOfMexicoWindstormMultiplier	
    ,s.HasConsortiumLink 
 		,s.HasGulfOfMexicoExposure								
 		,s.HasMultiYearLink		
        ,s.HasParentLink
 		,s.HazardClass											
 		,s.HiddenStatusFilter										
 		,s.ITVPerSQFT												
 		,s.InceptionDate											
 		,s.IncludeInMunichStacking	
        ,s.IncludePML
 		,s.Industry												
 		,s.IndustryCode											
 		,s.IndustryCodeQualifier									
 		,s.InnovationCampaign										
 		,s.InnovationPremiumMultiplier	
		,s.InsuredItem						
 		,s.Interest												
 		,s.InterestCode											
 		,s.InwardQuotaShareMultiplier								
 		,s.IsBeazleyLead											
 		,s.IsBreachResponseDummy									
 		,s.IsQuote												
 		,s.IsRenewal												
 		,s.IsRapidRenewal											
 		,s.IsSigned												
 		,s.IsSynergySection										
 		,s.KeyLocationAddress1									
 		,s.KeyLocationAddress2									
 		,s.KeyLocationCity										
 		,s.KeyLocationCountry										
 		,s.KeyLocationState										
 		,s.KeyLocationStreetNumber								
 		,s.KeyLocationZipCode	
		,s.LargeRiskReviewerUserInitials									
 		,s.LatestEPIInOriginalCCY									
 		,s.LeaderName												
 		,s.LeaderPseudonym										
 		,s.LimitAmountInLimitCCY									
 		,s.LimitAmountInOriginalCCY								
 		,s.LimitCCY												
 		,s.LimitCCYToSettlementCCYRateCurrent						
 		,s.LimitCCYToSettlementCCYRateMelded						
 		,s.LimitDescription										
 		,s.LimitMeldedRate										
 		,s.LimitQualifier	
        ,s.LimitTypeCode
        ,s.LimitTypeDescription
		,s.LinkedConsortiumReference
        ,s.LinkedESGBinderReference
		,s.LinkedESGSectionReference
 		,s.LinkedNonSynergyReference			
        ,s.LinkedParentReference
 		,s.LinkedSynergySection									
 		,s.LloydsClassOfBusiness									
 		,s.LloydsClassOfBusinessCode								
 		,s.LocalCurrency											
 		,s.MailingAddress1										
 		,s.MailingAddress2										
 		,s.MailingCity											
 		,s.MailingState											
 		,s.MailingZipCode											
 		,s.MaintenancePeriodFrom									
 		,s.MaintenancePeriodTo		
        ,s.MaintenanceMonths
 		,s.MASTerritory											
 		,s.MarketCapitalisation									
 		,s.MigratedPolicy											
 		,s.MinimumPremiumInOriginalCCY							
 		,s.MultiYearGroupReference								
 		,s.MultiYearIndicator
        ,s.NewConditionsExpiryDate
 		,s.NotifiedIndividuals									
 		,s.NotifiedIndividualsName								
 		,s.NumberOfEmployees										
 		,s.NumberOfLawyers										
 		,s.NumberOfLives
		,s.NumberOfLocations
 		,s.NumberOfReinstatements									
 		,s.Obligor												
 		,s.ObligorOccupation										
 		,s.ObligorOccupationCode									
 		,s.Occupation												
 		,s.OccupationCode											
 		,s.OriginalCCY											
 		,s.OriginalCCYToLocalCCYRate								
 		,s.OriginalCCYToSettlementCCYRate							
 		,s.OriginalCoverageName									
 		,s.OriginalEPIInOriginalCCY								
 		,s.OriginalEPITotalAcquisitionCostMultiplier				
 		,s.OriginalGrossPremiumInOriginalCCY						
 		,s.OriginalInsured										
 		,s.OriginalInsuredArea									
 		,s.OriginalInsuredAreaCode								
 		,s.OriginalLimitInOriginalCCY
		,s.OriginatingSourceSystem						
 		,s.PDDeductible						
        ,s.PDSI
 		,s.PMLExposure		
        ,s.PMLExposureOurShareUSD					
        ,s.PMLExposure100PerctShareUSD	   
        ,s.PMLExposure100PerctShareOrigCcy 
        ,s.PMLPercentage
        ,s.TSI100PercForPMLOrigCcy
        ,s.PolicyRate
 		,s.Peril													
 		,s.PerilCode												
 		,s.PremiumIncomeLimitInOriginalCCY						
 		,s.PremiumRates		
		,s.PrimaryLegacyReference
 		,s.PrimaryOrExcess										
 		,s.PrimarySectionURL										
 		,s.PrimarySectionURLLabel									
 		,s.Product												
 		,s.ProfitCommissionMultiplier								
 		,s.ProgramName											
 		,s.ProgramNumber											
 		,s.ProgramPeriod											
 		,s.ProgramType 
        ,s.ProgramYear 
        ,s.QuoteBoundSectionReference								
 		,s.QuoteDaysValid											
 		,s.QuoteLapsedDate										
 		,s.QuoteOrBindDate		
		,s.RatingAdequacyMultiplier
 		,s.RateChangeControlComplete
 		,s.RateChangeDate											
 		,s.RateChangeDeductibleMultiplier							
 		,s.RateChangeExposureMultiplier							
 		,s.RateChangeLimitMultiplier								
 		,s.RateChangeMethod										
 		,s.RateChangeMultiplier									
 		,s.RateChangeOtherMultiplier								
 		,s.RateChangeRiskMultiplier								
 		,s.RateChangeTermsAndConditionsMultiplier					
 		,s.RateOnLineMultiplierEntered							
 		,s.RateOnLinePremiumEnteredInOriginalCCY					
 		,s.RationaleQuestionnaireComplete							
 		,s.RationaleQuestionnaireDate								
 		,s.ReSigningIndicator										
 		,s.ReactivationReason										
 		,s.ReactivationReasonCode									
 		,s.ReinstatementMultiplier								
 		,s.ReinstatementPremiumInOriginalCCY						
 		,s.ReinsuranceIndicator									
 		,s.RetroInceptionDate										
 		,s.Revenues												
 		,s.RiskClass												
 		,s.RiskClassCode											
 		,s.SICCode		
        ,s.SigningNumberDate
        ,s.SLSpecificCoverage	
		,s.ReKeyReference 
        ,s.ReKeySource
 		,s.SecondarySectionURL									
 		,s.SecondarySectionURLLabel								
 		,s.SectionReferenceCOBCode								
 		,s.SectionReferenceReinsuranceIndicator					
 		,s.SectionReferenceSectionIdentifier						
 		,s.SectionStatus											
 		,s.SectionStatusCode	
		,s.ServiceCompanyCode											
 		,s.SettlementCCY										
 		,s.SignedLineMultiplier									
 		,s.SignedOrderMultiplier									
 		,s.SpecialPurposeSyndicateApplies							
 		,s.StatsCode												
 		,s.StatsDescription										
 		,s.SubmissionDate											
 		,s.SwordTreatyCoverage
        ,s.TechnicalPremium
 		,s.TermsOfTradeDate	
        ,s.TotalSIExposureOurShare
 		,s.TerritorialFocusGroup 
        ,s.TerrorismReference 									
 		,s.TestingPeriodFrom										
 		,s.TestingPeriodTo					
        ,s.TestingMonths
 		,s.TimeExcess				
        ,s.TimeExcessAmount
 		,s.TopLocationTSI											
 		,s.TotalSumInsured										
 		,s.TransactionLiabilityProject		
        ,s.TransactionType
        ,s.TransactionTypeCode
 		,s.TransactionValue										
 		,s.TriFocus										
 		,s.UltimateLossRatioMultiplier							
 		,s.UnderwriterAssistantContractCertaintyUserInitials		
 		,s.UnderwriterContractCertainty							
 		,s.UnderwriterContractCertaintyUserInitials				
 		,s.UnderwriterUserInitials								
 		,s.UnderwritingPlatformCode								
 		,s.USUnderwritingCoverageCode
		,s.VATNumber								
 		,s.WEPLastUpdatedDate										
 		,s.WrittenIfNotSignedLineMultiplier						
 		,s.WrittenLineMultiplier									
 		,s.WrittenOrEstimatedPremiumInOriginalCCY
        ,s.WEPBasis
 		,s.WrittenOrderMultiplier									
 		,s.TotalWrittenMultiplier									
		,s.WrittenIfNotSignedOrderMultiplier						
		,s.TotalWrittenIfNotSignedMultiplier						
		,s.DQ_AdditionalInsuredParty								
 		,s.DQ_Address1											
 		,s.DQ_Address2											
 		,s.DQ_Address3											
 		,s.DQ_InsuredParty										
 		,s.DQ_MethodOfPlacementCode								
 		,s.DQ_NoticeOfClaimBrokerNumber							
 		,s.DQ_PlacingBrokerContact								
 		,s.DQ_PlacingBrokerNumber									
 		,s.DQ_ProducingBrokerContact								
 		,s.DQ_ProducingBrokerNumber								
 		,s.DQ_ReinsuredParty										
 		,s.DQ_ServiceOfSuitBrokerNumber							
 		,s.DQ_UniqueMarketReference								
 		,s.DQ_YOA
		,s.UnderwriterRiskEnteredBy	
		,s.UnderwriterAssistant
 		,s.UnderwriterName
		,s.HashbytesId		
		,s.DurationMonths     			
		--,s.DaysSinceQuoteOrBindDate       
		--,s.DaysBetweenQBAndRateChangeDate 
		--,s.DaysBetweenQBAndBenchmarkDate  
		,s.MonthsSinceInception           
		,s.MonthsSinceTOT     
		,s.LiveStatus									
		,s.TermsOfTradeExpired						            
		,s.DaysBetweenQBAndCCCCDateOrToday         
		,s.DaysBetweenQBAndCCFCDateOrToday         
		,s.DaysBetweenQBAndCCPCDateOrToday         
		,s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday  
		,s.NoticeDate								
		,s.NotificationThreshold					
		,s.TacitRenewal	
		,s.IsPolicyholderAPrivateIndividual														

		,GETDATE()
		,'New Section - `Staging.usp_LoadSection` procedure'				
)
;

-- 1st Delete for deduplication -> from Staging.Section the etrek sections for which we have a substitute as LondonRefNo
-- Delete the sections linked to ETREK PolicyReferences that have a valid LondonRefNo
DELETE s 
FROM Staging.Section s
INNER JOIN Staging.EtrekUnirisxDedupe et on s.PolicyReference = et.PolicyReference
WHERE et.LondonRefNo IN ( SELECT DISTINCT et.LondonRefNo   
                          FROM Staging.EtrekUnirisxDedupe  et
						   INNER JOIN Staging.Section s on et.PolicyReference = s.PolicyReference)
AND s.SourceSystem = 'Etrek'


-- 2nd Delete fro deduplication -> from Staging.Policy the etrek polices that have a substitute as LondonRefNo
-- Delete the ETREK policies for which we have a valid LondonRefNo
DELETE p
FROM Staging.Policy p
INNER JOIN Staging.EtrekUnirisxDedupe et on p.PolicyReference = et.PolicyReference
WHERE et.LondonRefNo IN ( SELECT DISTINCT et.LondonRefNo
                          FROM  Staging.EtrekUnirisxDedupe  et
						  INNER JOIN Staging.Policy p on et.PolicyReference = p.PolicyReference)
AND p.SourceSystem = 'Etrek'


UPDATE s 
	SET FK_TriFocus								= ISNULL(tf.PK_TriFocus, 0)
		
	FROM Staging.Section s WITH(NOLOCK)

	LEFT OUTER JOIN	ODS.TriFocus tf  WITH(NOLOCK)
	ON s.TriFocus = tf.TriFocusName
	

	UPDATE s 
	SET	ExpectedLossRatioMultiplier =  s.BenchmarkMultiplier * 
									CASE 
									WHEN (s.FK_YOA < 2022) AND t.trifocusname = 'War' THEN 0.25
									WHEN (s.FK_YOA < 2020) AND t.trifocusname = 'Cat' THEN 0.5
									ELSE  t.LongTermBenchmarkMultiplier
									END
    
	FROM Staging.Section s

	INNER JOIN ODS.TriFocus t 
	ON s.FK_TriFocus = t.PK_TriFocus


END
GO


