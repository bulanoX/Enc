﻿CREATE PROCEDURE [Staging].[usp_PostProcessSection]
AS
BEGIN
	
DROP TABLE IF EXISTS #Section
CREATE TABLE #Section
(
PK_Section													BIGINT NULL
,SectionReference											VARCHAR (255) NULL
,WrittenLineMultiplier										NUMERIC (19, 12) NULL
,SignedLineMultiplier										NUMERIC (19, 12) NULL
,WrittenIfNotSignedLineMultiplier							NUMERIC (19, 12) NULL
,SignedOrderMultiplier										NUMERIC (19, 12) NULL
,IsSigned													BIT NULL
,TotalWrittenMultiplier										NUMERIC (19, 12) NULL
,TotalSignedMultiplier										NUMERIC (19, 12) NULL
,WrittenOrderMultiplier										NUMERIC (19, 12) NULL
,EstimatedSigningMultiplier									NUMERIC (19, 12) NULL
,WrittenIfNotSignedOrderMultiplier							NUMERIC (19, 12) NULL
,TotalWrittenIfNotSignedMultiplier							NUMERIC (19, 12) NULL
,LineMultiplierBandKey										NUMERIC (19, 12) NULL
,LineMultiplierBand											VARCHAR (255)    NULL   
)

INSERT INTO #Section
(
PK_Section
,SectionReference					
,WrittenLineMultiplier				
,SignedLineMultiplier				
,WrittenIfNotSignedLineMultiplier	
,SignedOrderMultiplier				
,IsSigned							
,TotalWrittenMultiplier				
,TotalSignedMultiplier				
,WrittenOrderMultiplier				
,EstimatedSigningMultiplier			
,WrittenIfNotSignedOrderMultiplier	
,TotalWrittenIfNotSignedMultiplier	
,LineMultiplierBandKey		
,LineMultiplierBand			
)

SELECT
PK_Section
,SectionReference					
,WrittenLineMultiplier				
,SignedLineMultiplier				
,WrittenIfNotSignedLineMultiplier	
,SignedOrderMultiplier				
,IsSigned							
,TotalWrittenMultiplier				
,TotalSignedMultiplier				
,WrittenOrderMultiplier				
,EstimatedSigningMultiplier			
,WrittenIfNotSignedOrderMultiplier	
,TotalWrittenIfNotSignedMultiplier	
,LineMultiplierBandKey		
,LineMultiplierBand			
FROM Staging.Section





CREATE NONCLUSTERED INDEX [IDX_#StagingSection_SectionReference] ON #Section (SectionReference ASC) INCLUDE ([SignedOrderMultiplier])  WITH (FILLFACTOR = 90)
	UPDATE s SET
		WrittenLineMultiplier               = x.WrittenLineMultiplier
		,SignedLineMultiplier               = x.SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier   = x.WrittenIfNotSignedMultiplier
		,SignedOrderMultiplier              = CASE WHEN x.SignedLineMultiplier IS NOT NULL THEN ISNULL(s.SignedOrderMultiplier, 1) ELSE NULL END
		,IsSigned                           = CASE WHEN x.SignedLineMultiplier IS NOT NULL THEN 1 ELSE 0 END

	FROM #Section s  

	INNER JOIN
			(   
				SELECT
					SectionReference									= sl.SectionReference
					,WrittenLineMultiplier                      = SUM(sl.WrittenLineMultiplier)
					,SignedLineMultiplier                       = SUM(sl.SignedLineMultiplier)
					,WrittenIfNotSignedMultiplier               = SUM(sl.WrittenIfNotSignedLineMultiplier)
    
				FROM Staging.SectionLine sl  
    
				GROUP BY sl.SectionReference
			) x 
	ON s.SectionReference = x.SectionReference
	--00:00:55	3817192


		/*Total lines*/
	UPDATE s SET
		TotalWrittenMultiplier      = s.WrittenLineMultiplier * s.WrittenOrderMultiplier * s.EstimatedSigningMultiplier/*  /  case 
																														when s.SourceSystem = 'USHVH' then 1000
																														when s.sourcesystem = 'FDR' then 100 
																														else 1 
																														end*/
		,TotalSignedMultiplier      = s.SignedLineMultiplier * s.SignedOrderMultiplier
	FROM	#Section s

	/*Apply "written if not signed rule to the order and the total %*/
	UPDATE s SET
	WrittenIfNotSignedOrderMultiplier  = ISNULL(s.SignedOrderMultiplier, s.WrittenOrderMultiplier)
	,TotalWrittenIfNotSignedMultiplier = ISNULL(s.TotalSignedMultiplier, s.TotalWrittenMultiplier)
	FROM	#Section s


	UPDATE s 
	SET 
		WrittenLineMultiplier               = 1
		,WrittenOrderMultiplier             = 1
		,TotalWrittenMultiplier             = 1
		,WrittenIfNotSignedLineMultiplier   = 1
		,WrittenIfNotSignedOrderMultiplier  = 1
		,TotalWrittenIfNotSignedMultiplier  = 1

	FROM #Section s  

	WHERE s.WrittenLineMultiplier IS NULL

	
	
	UPDATE s 
	SET 
		WrittenIfNotSignedLineMultiplier   = 1
		
	FROM #Section s  

	WHERE ISNULL(s.WrittenIfNotSignedLineMultiplier, 0) = 0

	
		UPDATE s 

	SET 
		 LineMultiplierBandKey						= ISNULL(lmb.BandMin, 0)
		,LineMultiplierBand						    = ISNULL(lmb.Name, 'N/A')	
	FROM #Section s  

	LEFT OUTER JOIN Staging_MDS.MDS_Staging.LineMultiplierBand lmb   
	ON s.TotalWrittenIfNotSignedMultiplier > lmb.BandMin
	AND s.TotalWrittenIfNotSignedMultiplier <= lmb.BandMax



	UPDATE TARGET SET
	 TARGET.WrittenLineMultiplier                     = SOURCE.WrittenLineMultiplier
	,TARGET.SignedLineMultiplier            		  = SOURCE.SignedLineMultiplier
	,TARGET.WrittenIfNotSignedLineMultiplier		  = SOURCE.WrittenIfNotSignedLineMultiplier
	,TARGET.SignedOrderMultiplier           		  = SOURCE.SignedOrderMultiplier
	,TARGET.IsSigned     							  = SOURCE.IsSigned
	,TARGET.TotalWrittenMultiplier					  = SOURCE.TotalWrittenMultiplier
	,TARGET.TotalSignedMultiplier					  = SOURCE.TotalSignedMultiplier
	,TARGET.WrittenOrderMultiplier        			  = SOURCE.WrittenOrderMultiplier
	,TARGET.WrittenIfNotSignedOrderMultiplier		  = SOURCE.WrittenIfNotSignedOrderMultiplier
	,TARGET.TotalWrittenIfNotSignedMultiplier		  = SOURCE.TotalWrittenIfNotSignedMultiplier
	,TARGET.LineMultiplierBandKey					  = SOURCE.LineMultiplierBandKey
	,TARGET.LineMultiplierBand					      = SOURCE.LineMultiplierBand
	
	FROM
Staging.Section target
INNER JOIN #Section source
ON target.PK_Section = source.PK_Section

DROP TABLE IF EXISTS #Section
END 
GO