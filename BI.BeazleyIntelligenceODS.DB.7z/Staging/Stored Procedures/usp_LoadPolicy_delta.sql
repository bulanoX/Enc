﻿CREATE PROCEDURE [Staging].[usp_LoadPolicy_delta]
AS
BEGIN


	TRUNCATE TABLE Staging.Policy_temp 
	--DataContract
	INSERT INTO Staging.Policy_temp 
	(
		PolicyReference							
		,SourceSystem							
		,AdditionalInsuredParty					
		,Address0								
		,Address1								
		,Address2								
		,Address3								
		,Address4								
		,AdmittedNonAdmitted					
		,AffinityIdentifier						
		,AgressoBrokerID						
		,AnnualRevenues											
		,AttachmentPoint												
		,BrokerAccessPolicyNumber				
		,BrokerNetworkName						
		,CapitaBrokerID							
		,Cedant												
		,Coinsurance							
		,ContractBasis							
		,CoverholderName		
		,DomicileCountry
		,EarliestRationaleQuestionnaireDate		
		,EarliestRationaleDate					
		,ErpExpirationDate                 		
		,ExpiringPolicy			
		,EndorsementNumber
		,FundType								
		,InitiativeUS							
		,InsuranceType							
		,InsuredParty	
		 ,InsuredLegalTradingName 
		,IsBrokerAccessReferral					
		,IsNewYorkFreeTradeZone					
		,IsQuote								
		,IsBoundQuote							
		,IsRenewal	
		,LargeRiskExemption		
		,LeadFeesPercentage
		,MarketSegment							
		,MarketSegmentCode						
		,McareAssessment						
		,MethodOfPlacement						
		,MethodOfPlacementCode					
		,NetworkEndDate							
		,NetworkStartDate						
		,NoticeOfClaimBrokerNumber				
		,PatientCompensationFund				
		,PlacingBrokerContact					
		,PlacingBrokerNumber					
		,PolicyReferenceMOPCode					
		,PolicyReferenceMOPCodeRiskNumber		
		,PolicyReferenceRiskNumber				
		,PolicyReferenceYOA		
		,PolicyType
		,PolicyURL								
		,PolicyURLLabel											
		,ProducingBrokerContact					
		,ProducingBrokerNumber					
		,ReinsuredParty	
		,RiskType
		,RunOffDate
		,ServiceCompanyLocation
		,SourceSystemInsuredId							
		,ServiceOfSuitBrokerNumber	
		,TaxPercentage
		,TriaPercentage							
		,UPIFlag								
		,UniqueMarketReference	
		,USMiscMedLifeSciencesPolicyCOBCode
		,USMiscMedLifeSciencesPolicyCOB
		,YOA	
		,FK_CRMBroker	
		,FK_CRMProducingBroker
		,FK_PartyBrokerPlacing	
		,FK_PartyBrokerProducing
		,FK_PartyInsured				
		,FK_Submission
		,FK_YOA		
		,HashBytesId	
		,SourcesystemKey					
	)
	SELECT
	PolicyReference						= p.PolicyReference
	,SourceSystem						= CASE 
												WHEN p.SourceSystem = 'StagingDataContract' THEN p.OriginatingSourceSystem
												ELSE REPLACE(p.SourceSystem,'USHVH','US High Value Homeowners')
											END
	,AdditionalInsuredParty				= p.AdditionalInsuredParty
	,Address0							= p.InsuredAddress
	,Address1							= p.InsuredCity
	,Address2							= p.InsuredState
	,Address3							= p.InsuredCountry
	,Address4							= p.InsuredPostCode
	,AdmittedNonAdmitted				= p.IsAdmitted
	,AffinityIdentifier					= p.AffinityIdentifier 
	,AgressoBrokerID					= p.AgressoBrokerID
	,AnnualRevenues						= p.AnnualRevenues
	,AttachmentPoint					= p.AttachmentPoint
	,BrokerAccessPolicyNumber			= p.BrokerAccessPolicyNumber
	,BrokerNetworkName					= p.BrokerNetworkName
	,CapitaBrokerID						= p.CapitaBrokerID
	,Cedant								= p.Cedant								
	,Coinsurance						= p.Coinsurance
	,ContractBasis						= p.ContractBasis
	,CoverholderName					= p.CoverholderName						
	,DomicileCountry                    = p.DomicileCountry
	,EarliestRationaleQuestionnaireDate	= p.EarliestRationaleQuestionnaireDate
	,EarliestRationaleDate				= p.EarliestRationaleQuestionnaireDate
	,ErpExpirationDate					= p.ErpExpirationDate
	,ExpiringPolicy						= p.ExpiringPolicyReference	
	,EndorsementNumber					= p.EndorsementNumber
	,FundType							= p.FundType								
	,InitiativeUS						= p.InitiativeUS							
	,InsuranceType						= p.InsuranceType							
	,InsuredParty						= p.InsuredName	
	 ,InsuredLegalTradingName			= p.InsuredLegalTradingName	 
	,IsBrokerAccessReferral				= ISNULL(p.BrokerAccessReferralFlag, 0)					
	,IsNewYorkFreeTradeZone				= ISNULL(p.IsNewYorkFreeTradeZone, 0)					
	,IsQuote							= p.IsQuote
	,IsBoundQuote						= p.IsBoundQuote
	,IsRenewal							= CASE 
													WHEN p.ExpiringPolicyReference IS NOT NULL THEN 1 
													ELSE p.IsRenewal 
												END													
	,LargeRiskExemption					= p.LargeRiskExemption
	,LeadFeesPercentage					= p.LeadFeesPercentage
	,MarketSegment						=CASE WHEN p.SourceSystem = 'BeazleyPro' 
												THEN s.MarketSegment
											  WHEN p.SourceSystem = 'StagingDataContract'
												THEN CASE p.MarketSegment
														WHEN 'PE' THEN 'Private Enterprise'
														WHEN 'MM' THEN 'Mid-Market'
														ELSE p.marketSegment
													END
											 ELSE p.MarketSegment
										 END
	,MarketSegmentCode					=CASE WHEN p.SourceSystem = 'BeazleyPro' 
												THEN s.MarketSegmentCode
											 ELSE p.MarketSegmentCode
										 END
	,McareAssessment					= p.McareAssessment
	,MethodOfPlacement					= p.MethodOfPlacement
	,MethodOfPlacementCode				= p.MethodOfPlacementCode
	,NetworkEndDate						= p.NetworkEndDate
	,NetworkStartDate					= p.NetworkStartDate
	,NoticeOfClaimBrokerNumber			= p.BrokerNoticeOfClaim
	,PatientCompensationFund			= p.PatientCompensationFund
	,PlacingBrokerContact				= p.PlacingBrokerContact
	,PlacingBrokerNumber				= ISNULL(pb.BrokerNumber,p.PlacingBrokerNumber)											
	,PolicyReferenceMOPCode				= p.PolicyReferenceMOPCode
	,PolicyReferenceMOPCodeRiskNumber	= p.PolicyReferenceMOPCodeRiskNumber
	,PolicyReferenceRiskNumber			= p.PolicyReferenceRiskNumber
	,PolicyReferenceYOA					= p.PolicyReferenceYOA
	,PolicyType							= p.PolicyType
	,PolicyURL							= p.PolicyURL
	,PolicyURLLabel						= p.PolicyURLLabel
	,ProducingBrokerContact				= p.ProducingBrokerContact
	,ProducingBrokerNumber				= ISNULL (pbpr.BrokerNumber, p.ProducingBrokerNumber)
	,ReinsuredParty						= p.ReinsuredParty
	,RiskType                           = p.RiskType
	,RunOffDate							= p.RunOffDate
	,ServiceCompanyLocation				= p.ServiceCompanyLocation
	,SourceSystemInsuredId				= CASE WHEN p.SourceSystem = 'BeazleyPro' THEN i.SourceSystemId END
	,ServiceOfSuitBrokerNumber			= p.BrokerServiceOfSuit
	,TaxPercentage						= p.TaxPercentage
	,TriaPercentage					    = CASE
												WHEN p.SourceSystem = 'BeazleyPro' THEN p.triaPercentage
												ELSE NULL
											END
	,UPIFlag							= CASE
												WHEN p.SourceSystem = 'BeazleyPro' THEN p.UPIFlag
												ELSE 0
											END
	,UniqueMarketReference				= p.UniqueMarketReference
	,USMiscMedLifeSciencesPolicyCOBCode = p.USMiscMedLifeSciencesPolicyCOBCode
	,USMiscMedLifeSciencesPolicyCOB     = uscob.ClassOfBusiness
	,YOA								= p.YearOfAccount
	,FK_CRMBroker						= CASE
												WHEN p.SourceSystem = 'BeazleyPro' THEN crm_pl.PK_CRMBroker
												WHEN p.SourceSystem in ('FDR', 'USHVH', 'StagingDataContract') THEN bb.PK_CRMBroker
												WHEN p.SourceSystem IN ( 'Gamechanger', 'myBeazley','CIPS') THEN crm.PK_CRMBroker 
												
												ELSE b.PK_CRMBroker 
										  END 
	,FK_CRMProducingBroker				= CASE 
												WHEN p.SourceSystem IN ( 'Gamechanger', 'myBeazley') THEN crm_p.PK_CRMBroker 
												WHEN p.SourceSystem = 'BeazleyPro' THEN ISNULL(crm_p.PK_CRMBroker, crm_pl.PK_CRMBroker)
											END
	,FK_PartyBrokerPlacing				= CASE WHEN p.PlacingBrokerNumber is not null then isnull( pb.PK_PartyBroker,0) ELSE ISNULL(brk.PK_PartyBroker,0) END							
	,FK_PartyBrokerProducing			= CASE WHEN p.ProducingBrokerNumber is not null then isnull( pbpr.PK_PartyBroker,0) ELSE ISNULL(brkpr.PK_PartyBroker,0) END
	,FK_PartyInsured					= i.PK_PartyInsured
	,FK_Submission						= CASE 
												WHEN p.SourceSystem = 'BeazleyPro' THEN s.PK_Submission 
											END
	,FK_YOA								= yoa.PK_YOA
	,HashBytesId						= p.HashBytesId
	,SourcesystemKey					= p.SourcesystemKey
	

	FROM Staging.Policy_All p WITH(NOLOCK)

	LEFT OUTER JOIN ODS.Submission s  WITH(NOLOCK)
	ON CAST(p.SourceSystemRiskId as nvarchar(255)) = s.SubmissionSourceId
	AND s.SourceSystemName = 'BeazleyPro'
	
	LEFT OUTER JOIN ODS.PartyInsured i  WITH(NOLOCK)
	ON s.FK_PartyInsured = i.PK_PartyInsured

	LEFT OUTER JOIN 
	(	SELECT	BrokerName		= pb.BrokerName
				,BrokerNumber	= MAX(pb.BrokerNumber)
				,PK_PartyBroker = MAX(PK_PartyBroker)
		FROM ODS.PartyBroker pb WITH(NOLOCK)
		GROUP BY pb.BrokerName
	) brk 
	ON p.PlacingBrokerBranchName = brk.BrokerName

	LEFT OUTER JOIN 
	(	SELECT	BrokerName		= pb.BrokerName
				,BrokerNumber	= MAX(pb.BrokerNumber)
				,PK_PartyBroker = MAX(PK_PartyBroker)
		FROM ODS.PartyBroker pb WITH(NOLOCK)
		GROUP BY pb.BrokerName
	  ) brkpr 
	ON p.ProducingBrokerBranchName = brkpr.BrokerName

	LEFT OUTER JOIN ODS.PartyBroker pb WITH(NOLOCK)
	ON  brk.BrokerName   = pb.BrokerName
	AND CASE WHEN p.PlacingBrokerNumber is not null then isnull( NULLIF(pb.OriginalBrokerNumber,0) , pb.BrokerNumber) ELSE ISNULL(brk.BrokerNumber,0) END = ISNULL(p.PlacingBrokerNumber,0)
	
	LEFT OUTER JOIN ODS.PartyBroker pbpr WITH(NOLOCK)
	ON  brkpr.BrokerName   = pbpr.BrokerName
	AND CASE WHEN p.ProducingBrokerNumber is not null then isnull(  NULLIF(pbpr.OriginalBrokerNumber,0) , pbpr.BrokerNumber) ELSE ISNULL(brkpr.BrokerNumber,0) END = ISNULL(p.ProducingBrokerNumber,0)

	LEFT JOIN ODS.CRMBroker crm  WITH(NOLOCK)
	ON p.CRMBrokerName = CAST(crm.CRMBrokerId AS VARCHAR(255)) 
	AND p.SourceSystem IN ( 'Gamechanger', 'myBeazley','CIPS')

	LEFT JOIN ODS.CRMBroker crm_p  WITH(NOLOCK)
	ON p.ProducingBrokerSourceId = CAST(crm_p.CRMBrokerId AS VARCHAR(255)) 
	AND p.SourceSystem IN ( 'Gamechanger', 'myBeazley', 'BeazleyPro')

	LEFT JOIN ODS.CRMBroker crm_pl WITH(NOLOCK)
	ON p.PlacingBrokerSourceId = CAST(crm_pl.CRMBrokerId AS VARCHAR(255)) 
	AND p.SourceSystem = 'BeazleyPro'

	LEFT OUTER JOIN
				(
					 SELECT
						PK_CRMBroker			= b.PK_CRMBroker
						,AccountNumber			= TRY_CAST(b.AccountNumber AS INT) -- remove N/A member and any possible strings
						,SequenceId				= ROW_NUMBER() OVER(
																PARTITION BY b.AccountNumber
																ORDER BY b.HierarchyLevel DESC, b.PK_CRMBroker ASC) --Tie breaker
					FROM ODS.CRMBroker b WITH(NOLOCK)
					WHERE b.AccountNumber IS NOT NULL 
				) b 
	ON TRY_CAST(p.CRMBrokerName AS INT) = b.AccountNumber
	AND b.SequenceId = 1 
	AND p.SourceSystem IN  ('Unirisx', 'CIPS')
	
	LEFT OUTER JOIN
	(
		SELECT
		PK_CRMBroker                = b.PK_CRMBroker
		,CRMBrokerLinkId            = b.CRMBrokerLinkId
		,SequenceId                 = ROW_NUMBER() OVER(
												PARTITION BY b.CRMBrokerLinkId
												ORDER BY b.HierarchyLevel DESC, b.PK_CRMBroker ASC) --Tie breaker
		FROM
		ODS.CRMBroker b
		WHERE
		b.CRMBrokerLinkId IS NOT NULL
	) bb ON
	p.BrokerBeazleyTradeId = bb.CRMBrokerLinkId
	AND bb.SequenceId = 1

	LEFT OUTER JOIN ODS.YOA yoa WITH(NOLOCK)
	ON p.YearOfAccount = yoa.PK_YOA
	
	LEFT OUTER JOIN ODS.ClassOfBusiness uscob WITH(NOLOCK)
	ON p.USMiscMedLifeSciencesPolicyCOBCode = uscob.ClassOfBusinessCode



	/*Load ClaimCenter policy data*/ -- WITH(NOLOCK)
	INSERT INTO Staging.Policy_Temp
	(
		PolicyReference
		,ClaimCenterPolicyId
		,YOA
		,IsQuote
		,AdmittedNonAdmitted
		,SourceSystem
		,IsBoundQuote
		,MethodOfPlacementCode
		,MethodOfPlacement
		,FK_YOA
	)
		SELECT
		 PolicyReference				= P.PolicyReference
		,ClaimCenterPolicyId			= P.ClaimCenterPolicyId
		,YOA							= P.YOA
		,IsQuote						= P.IsQuote
		,AdmittedNonAdmitted			= P.AdmittedNonAdmitted
		,SourceSystem					= P.SourceSystem
		,IsBoundQuote					= P.IsBoundQuote
		,MethodOfPlacementCode			= P.MethodOfPlacementCode
		,MethodOfPlacement   			= ISNULL(mp.[Name], P.MethodOfPlacementCode)
		,FK_YOA							= yoa.PK_YOA

	FROM
		(
			SELECT 
				PolicyReference                         = g.PolicyNumber
				,ClaimCenterPolicyId                    = 0
				,YOA                                    = MAX(g.YOA)
				,IsQuote                                = 0
				,AdmittedNonAdmitted                    = 'N/A'
				,SourceSystem                           = 'ClaimCenter'
				,IsBoundQuote                           = 0
				,MethodOfPlacementCode                  = MAX(g.MethodOfPlacementCode)
			FROM 
				(
					SELECT			
						PolicyNumber						= p.PolicyNumber
						,MethodOfPlacementCode              = CASE 
																	WHEN tf.TriFocusName LIKE 'BICI%' THEN 'V' --BICI
																	ELSE 'ZZ' --This is the MOP we use for external decs
																	END
						,YOA								= ISNULL(TRY_CONVERT(INT, p.YOA), 0) 
					FROM Staging.Policy_Claims p

					INNER JOIN ODS.TriFocus tf 
					ON tf.TriFocusCode = p.TrifocusCode
 
					WHERE NOT EXISTS 
							(SELECT 1 FROM Staging.Policy p1 WHERE LEFT(p.PolicyNumber, 8) = p1.PolicyReference)
							AND NOT EXISTS
							(SELECT 1 FROM Staging.Policy p1 WHERE p.PolicyNumber = p1.PolicyReference)
							AND NOT EXISTS --C.D. I'm adding staging.Policy_TEMP into filtering in case a policy comes through the first flow (query)
							(SELECT 1 FROM Staging.Policy_temp p1 WHERE LEFT(p.PolicyNumber, 8) = p1.PolicyReference)
							AND NOT EXISTS
							(SELECT 1 FROM Staging.Policy_temp p1 WHERE p.PolicyNumber = p1.PolicyReference)
				) G
			GROUP BY G.PolicyNumber
		) P

	LEFT JOIN Staging_MDS.MDS_Staging.MethodOfPlacement mp 
	ON p.MethodOfPlacementCode = mp.Code

	
	LEFT OUTER JOIN ODS.YOA yoa WITH(NOLOCK)
	ON p.YOA = yoa.PK_YOA

		--delete deactivated policies
	DELETE		o
	FROM		Staging.Policy o 
	LEFT JOIN	BeazleyIntelligenceDataContract.Outbound.vw_Policy p 
			ON	o.PolicyReference = p.PolicyReference
	WHERE		p.PolicyReference IS NULL
	AND o.SourceSystem <> 'ClaimCenter'

	--delete unverified policies which are not comming anymore from ClaimCenter
	DELETE		p
	FROM		staging.Policy p
	LEFT JOIN	(
					--this query is taken from [usp_LoadPolicy_Claims_Delta]
					SELECT		c.PolicyNumber
					FROM		BeazleyIntelligenceDataContract.outbound.vw_Claim c  WITH(NOLOCK)
					INNER JOIN 	(
									SELECT 		ClaimSourceId			= ClaimSourceId
												, RowId					= ROW_NUMBER()OVER (PARTITION BY ClaimSourceId ORDER BY TriFocusCode, AuditCreateDateTime)
									FROM		BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure  WITH(NOLOCK)
									WHERE		SourceSystem			='ClaimCenter'
					) ce 	ON	ce.ClaimSourceId = c.ClaimSourceId
					WHERE		c.SourceSystem = 'ClaimCenter'
							AND ce.RowId = 1
							AND ISNULL(c.IsRetired, 0) = 0
	)c		ON	p.PolicyReference = c.PolicyNumber
	WHERE		p.SourceSystem='ClaimCenter'
			AND c.PolicyNumber IS NULL
	

;MERGE Staging.Policy t
USING Staging.Policy_Temp s
ON 
		t.PolicyReference = s.PolicyReference

WHEN MATCHED 
AND NOT
	(
		(t.SourceSystem = 'BeazleyPro' and s.SourceSystem = 'FDR')
			OR 
		(t.SourceSystem = 'Unirisx' and s.SourceSystem = 'StagingDataContract')
	)
THEN 
		UPDATE SET
				 t.SourceSystem								=	s.SourceSystem							
				,t.AdditionalInsuredParty					=	s.AdditionalInsuredParty				
				,t.Address0									=	s.Address0								
				,t.Address1									=	s.Address1								
				,t.Address2									=	s.Address2								
				,t.Address3									=	s.Address3								
				,t.Address4									=	s.Address4								
				,t.AdmittedNonAdmitted						=	s.AdmittedNonAdmitted					
				,t.AffinityIdentifier						=	s.AffinityIdentifier					
				,t.AgressoBrokerID							=	s.AgressoBrokerID						
				,t.AnnualRevenues							=	s.AnnualRevenues										
				,t.AttachmentPoint							=	s.AttachmentPoint											
				,t.BrokerAccessPolicyNumber					=	s.BrokerAccessPolicyNumber				
				,t.BrokerNetworkName						=	s.BrokerNetworkName					
				,t.CapitaBrokerID							=	s.CapitaBrokerID						
				,t.Cedant									=	s.Cedant											
				,t.Coinsurance								=	s.Coinsurance							
				,t.ContractBasis							=	s.ContractBasis						
				,t.CoverholderName							=	s.CoverholderName	
				,t.DomicileCountry                          =   s.DomicileCountry
				,t.ClaimCenterPolicyId						=   s.ClaimCenterPolicyId					
				,t.EarliestRationaleQuestionnaireDate		=	s.EarliestRationaleQuestionnaireDate	
				,t.EarliestRationaleDate					=	s.EarliestRationaleDate				
				,t.ErpExpirationDate                 		=	s.ErpExpirationDate                 	
				,t.ExpiringPolicy							=	s.ExpiringPolicy
				,t.EndorsementNumber						=	s.EndorsementNumber
				,t.FundType									=	s.FundType								
				,t.InitiativeUS								=	s.InitiativeUS							
				,t.InsuranceType							=	s.InsuranceType						
				,t.InsuredParty								=	s.InsuredParty
				 ,t.InsuredLegalTradingName					=	s.InsuredLegalTradingName 
				,t.IsBrokerAccessReferral					=	s.IsBrokerAccessReferral				
				,t.IsNewYorkFreeTradeZone					=	s.IsNewYorkFreeTradeZone				
				,t.IsQuote									=	s.IsQuote								
				,t.IsBoundQuote								=	s.IsBoundQuote							
				,t.IsRenewal								=	s.IsRenewal	
				,t.LargeRiskExemption						=   s.LargeRiskExemption
				,t.LeadFeesPercentage						=	s.LeadFeesPercentage
				,t.MarketSegment							=	s.MarketSegment						
				,t.MarketSegmentCode						=	s.MarketSegmentCode					
				,t.McareAssessment							=	s.McareAssessment						
				,t.MethodOfPlacement						=	s.MethodOfPlacement					
				,t.MethodOfPlacementCode					=	s.MethodOfPlacementCode				
				,t.NetworkEndDate							=	s.NetworkEndDate						
				,t.NetworkStartDate							=	s.NetworkStartDate						
				,t.NoticeOfClaimBrokerNumber				=	s.NoticeOfClaimBrokerNumber			
				,t.PatientCompensationFund					=	s.PatientCompensationFund				
				,t.PlacingBrokerContact						=	s.PlacingBrokerContact					
				,t.PlacingBrokerNumber						=	s.PlacingBrokerNumber					
				,t.PolicyReferenceMOPCode					=	s.PolicyReferenceMOPCode				
				,t.PolicyReferenceMOPCodeRiskNumber			=	s.PolicyReferenceMOPCodeRiskNumber		
				,t.PolicyReferenceRiskNumber				=	s.PolicyReferenceRiskNumber			
				,t.PolicyReferenceYOA						=	s.PolicyReferenceYOA		
				,t.PolicyType								=	s.PolicyType
				,t.PolicyURL								=	s.PolicyURL							
				,t.PolicyURLLabel							=	s.PolicyURLLabel										
				,t.ProducingBrokerContact					=	s.ProducingBrokerContact				
				,t.ProducingBrokerNumber					=	s.ProducingBrokerNumber				
				,t.ReinsuredParty							=	s.ReinsuredParty												
				,t.RiskType                                 =   s.RiskType
				,t.RunOffDate								=	s.RunOffDate	
				,t.ServiceCompanyLocation					=   s.ServiceCompanyLocation
				,t.SourceSystemInsuredId					=	s.SourceSystemInsuredId						
				,t.ServiceOfSuitBrokerNumber				=	s.ServiceOfSuitBrokerNumber	
				,t.TaxPercentage							=	s.TaxPercentage
				,t.TriaPercentage							=	s.TriaPercentage						
				,t.UPIFlag									=	s.UPIFlag								
				,t.UniqueMarketReference					=	s.UniqueMarketReference	
				,t.USMiscMedLifeSciencesPolicyCOBCode		=   s.USMiscMedLifeSciencesPolicyCOBCode
				,t.USMiscMedLifeSciencesPolicyCOB			=   s.USMiscMedLifeSciencesPolicyCOB
				,t.YOA										=	s.YOA	
				,t.FK_CRMBroker								=	s.FK_CRMBroker	
				,t.FK_CRMProducingBroker					=	s.FK_CRMProducingBroker
				,t.FK_PartyBrokerPlacing					=	s.FK_PartyBrokerPlacing	
				,t.FK_PartyBrokerProducing					=	s.FK_PartyBrokerProducing
				,t.FK_PartyInsured							=	s.FK_PartyInsured				
				,t.FK_Submission							=	s.FK_Submission
				,t.FK_YOA									=	s.FK_YOA		
				,t.HashBytesId								=	s.HashBytesId	
				,t.SourcesystemKey							=	s.SourcesystemKey	
				,t.AuditModifyDateTime						=	GETDATE()						
				,t.AuditModifyDetails						=	'Merge from `Staging.usp_LoadPolicy` procedure'
				
WHEN NOT MATCHED BY TARGET THEN
		
INSERT 
(
	 PolicyReference							
		,SourceSystem							
		,AdditionalInsuredParty					
		,Address0								
		,Address1								
		,Address2								
		,Address3								
		,Address4								
		,AdmittedNonAdmitted					
		,AffinityIdentifier						
		,AgressoBrokerID						
		,AnnualRevenues											
		,AttachmentPoint												
		,BrokerAccessPolicyNumber				
		,BrokerNetworkName						
		,CapitaBrokerID							
		,Cedant												
		,Coinsurance							
		,ContractBasis							
		,CoverholderName	
		,DomicileCountry
		,ClaimCenterPolicyId					
		,EarliestRationaleQuestionnaireDate		
		,EarliestRationaleDate					
		,ErpExpirationDate                 		
		,ExpiringPolicy		
		,EndorsementNumber
		,FundType								
		,InitiativeUS							
		,InsuranceType							
		,InsuredParty
		 ,InsuredLegalTradingName 
		,IsBrokerAccessReferral					
		,IsNewYorkFreeTradeZone					
		,IsQuote								
		,IsBoundQuote							
		,IsRenewal	
		,LargeRiskExemption
		,LeadFeesPercentage
		,MarketSegment							
		,MarketSegmentCode						
		,McareAssessment						
		,MethodOfPlacement						
		,MethodOfPlacementCode					
		,NetworkEndDate							
		,NetworkStartDate						
		,NoticeOfClaimBrokerNumber				
		,PatientCompensationFund				
		,PlacingBrokerContact					
		,PlacingBrokerNumber					
		,PolicyReferenceMOPCode					
		,PolicyReferenceMOPCodeRiskNumber		
		,PolicyReferenceRiskNumber				
		,PolicyReferenceYOA		
		,PolicyType
		,PolicyURL								
		,PolicyURLLabel											
		,ProducingBrokerContact					
		,ProducingBrokerNumber					
		,ReinsuredParty		
		,RiskType
		,RunOffDate	
		,ServiceCompanyLocation
		,SourceSystemInsuredId							
		,ServiceOfSuitBrokerNumber			
		,TaxPercentage
		,TriaPercentage							
		,UPIFlag								
		,UniqueMarketReference
		,USMiscMedLifeSciencesPolicyCOBCode
		,USMiscMedLifeSciencesPolicyCOB		
		,YOA	
		,FK_CRMBroker	
		,FK_CRMProducingBroker
		,FK_PartyBrokerPlacing	
		,FK_PartyBrokerProducing
		,FK_PartyInsured				
		,FK_Submission
		,FK_YOA		
		,HashBytesId	
		,SourcesystemKey	
		,AuditCreateDateTime
		,AuditModifyDetails
)
Values
(
		 s.PolicyReference							
		,s.SourceSystem							
		,s.AdditionalInsuredParty					
		,s.Address0								
		,s.Address1								
		,s.Address2								
		,s.Address3								
		,s.Address4								
		,s.AdmittedNonAdmitted					
		,s.AffinityIdentifier						
		,s.AgressoBrokerID						
		,s.AnnualRevenues											
		,s.AttachmentPoint												
		,s.BrokerAccessPolicyNumber				
		,s.BrokerNetworkName						
		,s.CapitaBrokerID							
		,s.Cedant												
		,s.Coinsurance							
		,s.ContractBasis							
		,s.CoverholderName	
		,s.DomicileCountry
		,s.ClaimCenterPolicyId					
		,s.EarliestRationaleQuestionnaireDate		
		,s.EarliestRationaleDate					
		,s.ErpExpirationDate                 		
		,s.ExpiringPolicy			
		,s.EndorsementNumber
		,s.FundType								
		,s.InitiativeUS							
		,s.InsuranceType							
		,s.InsuredParty	
		 ,s.InsuredLegalTradingName 
		,s.IsBrokerAccessReferral					
		,s.IsNewYorkFreeTradeZone					
		,s.IsQuote								
		,s.IsBoundQuote							
		,s.IsRenewal	
		,s.LargeRiskExemption
		,s.LeadFeesPercentage
		,s.MarketSegment							
		,s.MarketSegmentCode						
		,s.McareAssessment						
		,s.MethodOfPlacement						
		,s.MethodOfPlacementCode					
		,s.NetworkEndDate							
		,s.NetworkStartDate						
		,s.NoticeOfClaimBrokerNumber				
		,s.PatientCompensationFund				
		,s.PlacingBrokerContact					
		,s.PlacingBrokerNumber					
		,s.PolicyReferenceMOPCode					
		,s.PolicyReferenceMOPCodeRiskNumber		
		,s.PolicyReferenceRiskNumber				
		,s.PolicyReferenceYOA			
		,s.PolicyType
		,s.PolicyURL								
		,s.PolicyURLLabel											
		,s.ProducingBrokerContact					
		,s.ProducingBrokerNumber					
		,s.ReinsuredParty			
		,s.RiskType
		,s.RunOffDate	
		,s.ServiceCompanyLocation
		,s.SourceSystemInsuredId							
		,s.ServiceOfSuitBrokerNumber
		,s.TaxPercentage
		,s.TriaPercentage							
		,s.UPIFlag								
		,s.UniqueMarketReference	
		,s.USMiscMedLifeSciencesPolicyCOBCode
		,s.USMiscMedLifeSciencesPolicyCOB		
		,s.YOA	
		,s.FK_CRMBroker	
		,s.FK_CRMProducingBroker
		,s.FK_PartyBrokerPlacing	
		,s.FK_PartyBrokerProducing
		,s.FK_PartyInsured				
		,s.FK_Submission
		,s.FK_YOA		
		,s.HashBytesId	
		,s.SourcesystemKey	
		,GETDATE()
		,'New Policy - `Staging.usp_LoadPolicy` procedure'				
)
;

	
END