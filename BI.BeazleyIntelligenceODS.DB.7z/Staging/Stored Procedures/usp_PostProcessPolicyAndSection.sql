CREATE PROCEDURE  [Staging].[usp_PostProcessPolicyAndSection]
AS

BEGIN
                
DROP TABLE IF EXISTS #Policy
CREATE TABLE #Policy
(
PK_Policy								BIGINT NOT NULL
,RenewingPolicy							VARCHAR (255)   NULL
,PolicyReference						VARCHAR (255)   NULL
,ExpiringPolicy							VARCHAR (255)   NULL
,IsQuote								BIT NULL
,IsRenewal								BIT NULL
,fk_yoa									BIGINT NULL
,YOA									INT NULL
,sourcesystem							VARCHAR (255)   NULL
,FK_ExpiringPolicy						BIGINT NULL
,FK_RenewingPolicy						BIGINT NULL
,FK_PartyBrokerServiceOfSuit			BIGINT NULL
,ServiceOfSuitBrokerNumber				INT NULL
,FK_QuoteFilter							BIGINT NULL
,FK_CRMBroker							BIGINT NULL
,FK_CRMProducingBroker					BIGINT NULL
,FK_PartyBrokerProducing				BIGINT NULL
,FK_PartyBrokerPlacing					BIGINT NULL
,AdditionalInsuredParty					VARCHAR (255)   NULL
,NoticeOfClaimBrokerNumber				INT NULL
,PlacingBrokerContact					VARCHAR (255)   NULL
,PlacingBrokerNumber					INT NULL
,ProducingBrokerContact					VARCHAR (255)   NULL
,ProducingBrokerNumber					INT NULL
,ReinsuredParty							VARCHAR (255)   NULL
,FK_Submission							BIGINT NULL
,MarKetSegmentCode							VARCHAR (255)   NULL
,PrimarySectionBinderType				VARCHAR (255)   NULL
,RunOffDate							DATETIME        NULL
,IsRunOff							BIT NULL
,AnySectionIsSynergy					BIT NULL
,AnySectionIsBreachResponseDummy		BIT NULL
,MethodOfPlacementCode			VARCHAR (255)   NULL
,InsuredParty					VARCHAR (255)   NULL
,FK_AccountingCalendar						BIGINT NULL
,FK_PartyBrokerNoticeOfClaim				BIGINT NULL
,FK_ServiceCompany							BIGINT NULL
,FK_PartyInsured							BIGINT NULL
,FK_UnderwritingPlatform					BIGINT NULL
,IsBID									BIT NULL
)

INSERT INTO #Policy
(
PK_Policy
,RenewingPolicy
,PolicyReference
,ExpiringPolicy
,IsQuote
,IsRenewal
,fk_yoa
,YOA
,sourcesystem
,FK_ExpiringPolicy
,FK_RenewingPolicy
,FK_PartyBrokerServiceOfSuit
,ServiceOfSuitBrokerNumber
,FK_QuoteFilter
,FK_CRMBroker
,FK_CRMProducingBroker
,FK_PartyBrokerProducing
,FK_PartyBrokerPlacing
,AdditionalInsuredParty
,NoticeOfClaimBrokerNumber
,PlacingBrokerContact
,PlacingBrokerNumber
,ProducingBrokerContact
,ProducingBrokerNumber
,ReinsuredParty
,FK_Submission
,MarKetSegmentCode
,PrimarySectionBinderType
,RunOffDate
,IsRunOff
,AnySectionIsSynergy
,AnySectionIsBreachResponseDummy
,MethodOfPlacementCode
,InsuredParty
,FK_AccountingCalendar			
,FK_PartyBrokerNoticeOfClaim	
,FK_ServiceCompany
,FK_PartyInsured
,FK_UnderwritingPlatform	
,IsBID					
)

SELECT 
PK_Policy
,RenewingPolicy
,PolicyReference
,ExpiringPolicy
,IsQuote
,IsRenewal
,fk_yoa
,YOA
,sourcesystem
,FK_ExpiringPolicy
,FK_RenewingPolicy
,FK_PartyBrokerServiceOfSuit
,ServiceOfSuitBrokerNumber
,FK_QuoteFilter
,FK_CRMBroker
,FK_CRMProducingBroker
,FK_PartyBrokerProducing
,FK_PartyBrokerPlacing
,AdditionalInsuredParty
,NoticeOfClaimBrokerNumber
,PlacingBrokerContact
,PlacingBrokerNumber
,ProducingBrokerContact
,ProducingBrokerNumber
,ReinsuredParty
,FK_Submission
,MarKetSegmentCode
,PrimarySectionBinderType
,RunOffDate
,IsRunOff
,AnySectionIsSynergy
,AnySectionIsBreachResponseDummy
,MethodOfPlacementCode
,InsuredParty
,FK_AccountingCalendar			
,FK_PartyBrokerNoticeOfClaim	
,FK_ServiceCompany
,FK_PartyInsured
,FK_UnderwritingPlatform	
,IsBID		
FROM Staging.Policy



DROP TABLE IF EXISTS #Section
CREATE TABLE #Section
(
PK_Section													BIGINT NULL
,FK_Policy													BIGINT NULL
,SectionReference											VARCHAR (255) NULL
,Policyreference											VARCHAR (255) NULL
,ProgramNumber												INT NULL
,ProgramPeriod												INT NULL
,ProgramName												VARCHAR (255) NULL
,IsBreachResponseDummy										BIT NULL
,DQ_AdditionalInsuredParty									VARCHAR (255)    NULL
,DQ_NoticeOfClaimBrokerNumber								INT    NULL
,DQ_PlacingBrokerContact									VARCHAR (255)    NULL
,DQ_PlacingBrokerNumber										INT   NULL
,DQ_ProducingBrokerContact									VARCHAR (255)    NULL
,DQ_ProducingBrokerNumber									INT    NULL
,DQ_ReinsuredParty											VARCHAR (255)    NULL
,DQ_ServiceOfSuitBrokerNumber								INT    NULL
,DQ_YOA														INT NULL
,Country													VARCHAR (255)    NULL
,CountryCode												VARCHAR (255)    NULL
--,WrittenLineMultiplier										NUMERIC (19, 12) NULL
--,SignedLineMultiplier										NUMERIC (19, 12) NULL
--,WrittenIfNotSignedLineMultiplier							NUMERIC (19, 12) NULL
--,SignedOrderMultiplier										NUMERIC (19, 12) NULL
--,IsSigned													BIT NULL
,RateOnLinePremiumEnteredInOriginalCCY						NUMERIC (38, 4)  NULL    
,LimitAmountInLimitCCY										NUMERIC (19, 4)  NULL
,LimitCCYToSettlementCCYRateMelded							NUMERIC (38, 12) NULL
,LimitCCYToSettlementCCYRateCurrent							NUMERIC (38, 12) NULL
,OriginalCCYToSettlementCCYRate								NUMERIC (38, 12) null
,RateOnLineMultiplierEntered								NUMERIC (19, 12) NULL
,LimitCCY													VARCHAR (255)    NULL
,OriginalCCY												VARCHAR (255)    NULL
,SourceSystem												VARCHAR (255)    NULL
,DQ_FK_YOA													BIGINT NULL
,Facility													VARCHAR (255)    NULL
,SectionSequenceId											VARCHAR (255)    NULL
,MultiYearGroupDurationMonths								NUMERIC (19, 4)  NULL
,DurationMonths												INT NULL
,MultiYearGroupReference									INT NULL
,InceptionDate												DATETIME NULL
,ExpiryDate													DATETIME NULL
,BICICessionMultiplier										NUMERIC (19, 12) NULL
,AgressoReference											VARCHAR (255)    NULL
,LinkedSynergySection										VARCHAR (255)    NULL
,LinkedNonSynergyReference									VARCHAR (255)    NULL
,TransactionLiabilitySectionType							VARCHAR (255)    NULL
,ClassOfBusinessCode										VARCHAR (255)    NULL
,CargoOrFreight												VARCHAR (255)    NULL
--,TotalWrittenMultiplier										NUMERIC (19, 12) NULL
--,WrittenOrderMultiplier										NUMERIC (19, 12) NULL
--,EstimatedSigningMultiplier									NUMERIC (19, 12) NULL
--,TotalSignedMultiplier										NUMERIC (19, 12) NULL
--,WrittenIfNotSignedOrderMultiplier							NUMERIC (19, 12) NULL
--,TotalWrittenIfNotSignedMultiplier							NUMERIC (19, 12) NULL
--,LineMultiplierBandKey										NUMERIC (19, 12) NULL
--,LineMultiplierBand											VARCHAR (255)    NULL   
,DQ_FK_PartyBrokerNoticeOfClaim								BIGINT NULL	
,DQ_FK_PartyBrokerPlacing									BIGINT NULL
,DQ_FK_PartyBrokerProducing									BIGINT NULL
,DQ_FK_PartyBrokerServiceOfSuit								BIGINT NULL		
,FK_ATIAClassOfBusiness										BIGINT NULL	
,FK_Area													BIGINT NULL	
,FK_ClassOfBusiness											BIGINT NULL	
,FK_ClientClassificationCode								BIGINT NULL	
,FK_LocalCurrency											BIGINT NULL	
,FK_LimitCurrency											BIGINT NULL	
,FK_OriginalCurrency										BIGINT NULL	
,FK_ServiceCompany											BIGINT NULL	
,FK_EnteredBy												BIGINT NULL	
,FK_Underwriter												BIGINT NULL	
,FK_UnderwriterAssistantContractCertainty					BIGINT NULL	
,FK_UnderwriterContractCertainty							BIGINT NULL	
,FK_UnderwriterLargeRiskReviewer							BIGINT NULL					
,FK_MultiYearGroupDurationBand								BIGINT NULL	
,FK_DurationBand											BIGINT NULL			
,MonthsSinceInceptionBandKey								INT NULL		    
,MonthsSinceInceptionBand									VARCHAR (255)    NULL
,FK_HiddenStatusFilter										BIGINT NULL	
,HiddenStatusFilter											VARCHAR (255)    NULL
,FK_SettlementCurrency										BIGINT NULL	
,SettlementCCY												VARCHAR (255)    NULL
,FK_QuoteFilter												BIGINT NULL	
,IsQuote													BIT NULL
,UnderwriterUserInitials									VARCHAR (255)    NULL
,OriginalCCYToLocalCCYRate									NUMERIC (19, 12) NULL
,IsFacility													BIT NULL			
,IsDeclaration												BIT NULL	
,HasDataContractSections									BIT NULL
,HasNonEurobaseSections										BIT NULL
,FK_Facility												BIGINT NULL	
,FK_BreachResponseParentSection								BIGINT NULL	
,BreachResponseParentSection								VARCHAR (255)    NULL
,FK_ATIAChildSection										BIGINT NULL	
,TerrorismReference											VARCHAR (255)    NULL
,FK_LinkedESGBinder											BIGINT NULL	
,FK_LinkedESGTrifocus										BIGINT NULL	
,FK_TriFocus												BIGINT NULL	
,LinkedESGBinderReference									VARCHAR (255)    NULL
,FK_LinkedESGSection										BIGINT NULL	
,LinkedESGSectionReference									VARCHAR (255)    NULL
,ATIAClassOfBusinessCode									VARCHAR (255)    NULL
,AreaCode													VARCHAR (255)    NULL
,ClientClassificationCode									VARCHAR (255)    NULL
,LocalCurrency												VARCHAR (255)    NULL
,ServiceCompanyCode											VARCHAR (255)    NULL
,UnderwriterName											VARCHAR (255)    NULL
,UnderwriterRiskEnteredBy									VARCHAR (255)    NULL
,UnderwriterAssistantContractCertaintyUserInitials			VARCHAR (255)    NULL
,UnderwriterContractCertaintyUserInitials					VARCHAR (255)    NULL
,UnderwriterContractCertainty								VARCHAR (255)    NULL
,LargeRiskReviewerUserInitials								VARCHAR (255)    NULL
,MonthsSinceInception										INT NULL
,SimpleProduct												VARCHAR (255)    NULL
,Team														VARCHAR (255)    NULL
,Product													VARCHAR (255)    NULL
,TechnologyCoverageName										VARCHAR (255)    NULL
,ClassifiedAsTechnology										VARCHAR (255)    NULL
,Trifocus													VARCHAR (255)    NULL
,CoverageName												VARCHAR (255)    NULL
,BinderType													VARCHAR (255)    NULL
,WEPMeldedRate												NUMERIC (38, 12) NULL
,WEPCurrentRate												NUMERIC (38, 12) NULL
,LimitMeldedRate											NUMERIC (38, 12) NULL
,RateOnLineMultiplier										NUMERIC (38, 12) NULL
,RateOnLineBandKey											NUMERIC (38, 12) NULL
,RateOnLineBandName											VARCHAR (255)    NULL
,ExpiringSection											VARCHAR (255)    NULL
,RenewingSection											VARCHAR (255)    NULL
,FK_ExpiringSection											BIGINT NULL	
,FK_RenewingSection											BIGINT NULL	
,IsRenewed													BIT NULL
,IsRenewal													BIT NULL
,QuoteOrBindDate											DATETIME         NULL
,WrittenOrEstimatedPremiumInOriginalCCY						NUMERIC (38, 4)  NULL
,IsSynergySection											BIT NULL
,RenewalDueDate												DATETIME         NULL
,LeaderPseudonym											VARCHAR (255)    NULL
,LeaderName													VARCHAR (255)    NULL
,IsBeazleyLead												BIT NULL
,ExpectedPICCTransactions									INT NULL
,IncludeInMunichStacking									BIT NULL
,TransactionLiabilityProject								VARCHAR (255)    NULL
,DQ_InsuredParty											VARCHAR (255)    NULL
,FK_InternalWrittenBinderStatus								BIGINT NULL	
,BinderTypeInternalExternal									VARCHAR (255)    NULL
,FK_YOA														BIGINT NULL	
,FK_CRMBroker												BIGINT NULL	
,ContractCertaintyPreBindOnTime								BIT NULL
,ContractCertaintyPostBindOnTime							BIT NULL
,CarrierIndicator											VARCHAR (255)    NULL
,ContractCertaintyPostBindComplete							BIT NULL
,DaysBetweenQBAndCCCCDateOrToday							INT NULL
,DaysBetweenQBAndCCPCOrCCPBSDateOrToday						INT NULL
,ContractCertaintyPreBindComplete							BIT NULL
,DaysBetweenQBAndCCFCDateOrToday							INT NULL
,FK_UnderwritingPlatform									BIGINT NULL	
,UnderwritingPlatformCode									VARCHAR (255)    NULL
,IsBID														BIT NULL
,OriginatingSourceSystem									VARCHAR (255)    NULL
,FacilityFilter												VARCHAR (255)    NULL
,FacilityType												VARCHAR (255)    NULL
,SourceOfBusiness											VARCHAR (255)    NULL
,LloydsClassOfBusinessCode									VARCHAR (255)    NULL
,LloydsClassOfBusiness										VARCHAR (255)    NULL
,RiskClassCode												VARCHAR (255)    NULL
,FK_LinkedSynergySection									BIGINT NULL	
,EntityGrouping												NVARCHAR (250)   NULL
,EntitySplit 												NVARCHAR (250)   NULL
,Entity 													NVARCHAR (250)   NULL
,MarketPlatform												NVARCHAR (250)   NULL
,BeazleyOfficeLocation										VARCHAR (255)    NULL
,TermsOfTradeExpired										BIT NULL
,TermsOfTradeDate											DATETIME         NULL
,ContractCertaintyControlsCompliantDate						DATETIME         NULL
,ContractCertaintyFullyCompliantDate						DATETIME         NULL
,ContractCertaintyPrimaryCompleteDate						DATETIME         NULL
,ContractCertaintyPreBindSignatureDate						DATETIME         NULL
,DaysBetweenQBAndCCPCDateOrToday							INT NULL
,LiveStatus													VARCHAR (255)    NULL
,MonthsSinceTOT												INT NULL
)

INSERT INTO #Section
(
PK_Section
,FK_Policy
,SectionReference
,Policyreference
,ProgramNumber
,ProgramPeriod
,ProgramName
,IsBreachResponseDummy
,DQ_AdditionalInsuredParty				
,DQ_NoticeOfClaimBrokerNumber			
,DQ_PlacingBrokerContact				
,DQ_PlacingBrokerNumber					
,DQ_ProducingBrokerContact				
,DQ_ProducingBrokerNumber				
,DQ_ReinsuredParty						
,DQ_ServiceOfSuitBrokerNumber			
,DQ_YOA	
,Country
,CountryCode
--,WrittenLineMultiplier            
--,SignedLineMultiplier            
--,WrittenIfNotSignedLineMultiplier
--,SignedOrderMultiplier           
--,IsSigned            
,RateOnLinePremiumEnteredInOriginalCCY       
,LimitAmountInLimitCCY
,LimitCCYToSettlementCCYRateMelded
,LimitCCYToSettlementCCYRateCurrent
,OriginalCCYToSettlementCCYRate 
,RateOnLineMultiplierEntered
,LimitCCY
,OriginalCCY
,SourceSystem
,DQ_FK_YOA
,Facility
,SectionSequenceId
,MultiYearGroupDurationMonths
,DurationMonths
,MultiYearGroupReference
,InceptionDate
,ExpiryDate
,BICICessionMultiplier
,AgressoReference
,LinkedSynergySection
,LinkedNonSynergyReference

,TransactionLiabilitySectionType
,ClassOfBusinessCode
,CargoOrFreight
--,TotalWrittenMultiplier 
--,WrittenOrderMultiplier 
--,EstimatedSigningMultiplier
--,TotalSignedMultiplier  
--,WrittenIfNotSignedOrderMultiplier 
--,TotalWrittenIfNotSignedMultiplier
--,LineMultiplierBandKey						
--,LineMultiplierBand						    
,DQ_FK_PartyBrokerNoticeOfClaim				
,DQ_FK_PartyBrokerPlacing					
,DQ_FK_PartyBrokerProducing					
,DQ_FK_PartyBrokerServiceOfSuit				
							
,FK_ATIAClassOfBusiness						
,FK_Area									
,FK_ClassOfBusiness							
,FK_ClientClassificationCode				
,FK_LocalCurrency							
,FK_LimitCurrency							
,FK_OriginalCurrency						
,FK_ServiceCompany							
,FK_EnteredBy								
,FK_Underwriter								

,FK_UnderwriterAssistantContractCertainty	
,FK_UnderwriterContractCertainty			
,FK_UnderwriterLargeRiskReviewer			
							
,FK_MultiYearGroupDurationBand				
,FK_DurationBand							
,MonthsSinceInceptionBandKey			    
,MonthsSinceInceptionBand	
,FK_HiddenStatusFilter
,HiddenStatusFilter
,FK_SettlementCurrency
,SettlementCCY
,FK_QuoteFilter
,IsQuote
,UnderwriterUserInitials
,OriginalCCYToLocalCCYRate
,IsFacility				
,IsDeclaration			
,HasDataContractSections
,HasNonEurobaseSections	
,FK_Facility
,FK_BreachResponseParentSection
,BreachResponseParentSection
,FK_ATIAChildSection
,TerrorismReference
,FK_LinkedESGBinder  
,FK_LinkedESGTrifocus
,FK_TriFocus
,LinkedESGBinderReference
,FK_LinkedESGSection
,LinkedESGSectionReference
,ATIAClassOfBusinessCode
,AreaCode
,ClientClassificationCode
,LocalCurrency
,ServiceCompanyCode
,UnderwriterName
,UnderwriterRiskEnteredBy
,UnderwriterAssistantContractCertaintyUserInitials
,UnderwriterContractCertaintyUserInitials
,UnderwriterContractCertainty
,LargeRiskReviewerUserInitials
,MonthsSinceInception
,SimpleProduct
,Team 
,Product  
,TechnologyCoverageName 
,ClassifiedAsTechnology
,Trifocus
,CoverageName
,BinderType
,WEPMeldedRate	
,WEPCurrentRate
,LimitMeldedRate
,RateOnLineMultiplier
,RateOnLineBandKey
,RateOnLineBandName
,ExpiringSection
,RenewingSection
,FK_ExpiringSection			
,FK_RenewingSection	
,IsRenewed
,IsRenewal
,QuoteOrBindDate
,WrittenOrEstimatedPremiumInOriginalCCY
,IsSynergySection
,RenewalDueDate
,LeaderPseudonym
,LeaderName
,IsBeazleyLead
,ExpectedPICCTransactions
,IncludeInMunichStacking
,TransactionLiabilityProject
,DQ_InsuredParty
,FK_InternalWrittenBinderStatus
,BinderTypeInternalExternal
,FK_YOA		
,FK_CRMBroker
,ContractCertaintyPreBindOnTime
,ContractCertaintyPostBindOnTime
,CarrierIndicator
,ContractCertaintyPostBindComplete
,DaysBetweenQBAndCCCCDateOrToday
,DaysBetweenQBAndCCPCOrCCPBSDateOrToday
,ContractCertaintyPreBindComplete
,DaysBetweenQBAndCCFCDateOrToday
,FK_UnderwritingPlatform
,UnderwritingPlatformCode
,IsBID
,OriginatingSourceSystem
,FacilityFilter
,FacilityType
,SourceOfBusiness
,LloydsClassOfBusinessCode	
,LloydsClassOfBusiness		
,RiskClassCode			
,FK_LinkedSynergySection
,EntityGrouping
,EntitySplit 
,Entity 
,MarketPlatform
,BeazleyOfficeLocation
,TermsOfTradeExpired
,TermsOfTradeDate
,ContractCertaintyControlsCompliantDate
,ContractCertaintyFullyCompliantDate
,ContractCertaintyPrimaryCompleteDate
,ContractCertaintyPreBindSignatureDate
,DaysBetweenQBAndCCPCDateOrToday
,LiveStatus
,MonthsSinceTOT
)

SELECT 
PK_Section
,FK_Policy
,SectionReference
,Policyreference
,ProgramNumber
,ProgramPeriod
,ProgramName
,IsBreachResponseDummy
,DQ_AdditionalInsuredParty				
,DQ_NoticeOfClaimBrokerNumber			
,DQ_PlacingBrokerContact				
,DQ_PlacingBrokerNumber					
,DQ_ProducingBrokerContact				
,DQ_ProducingBrokerNumber				
,DQ_ReinsuredParty						
,DQ_ServiceOfSuitBrokerNumber			
,DQ_YOA	
,Country
,CountryCode
--,WrittenLineMultiplier            
--,SignedLineMultiplier            
--,WrittenIfNotSignedLineMultiplier
--,SignedOrderMultiplier           
--,IsSigned            
,RateOnLinePremiumEnteredInOriginalCCY       
,LimitAmountInLimitCCY
,LimitCCYToSettlementCCYRateMelded
,LimitCCYToSettlementCCYRateCurrent
,OriginalCCYToSettlementCCYRate 
,RateOnLineMultiplierEntered
,LimitCCY
,OriginalCCY
,SourceSystem
,DQ_FK_YOA
,Facility
,SectionSequenceId
,MultiYearGroupDurationMonths
,DurationMonths
,MultiYearGroupReference
,InceptionDate
,ExpiryDate
,BICICessionMultiplier
,AgressoReference
,LinkedSynergySection
,LinkedNonSynergyReference

,TransactionLiabilitySectionType
,ClassOfBusinessCode
,CargoOrFreight
--,TotalWrittenMultiplier 
--,WrittenOrderMultiplier 
--,EstimatedSigningMultiplier
--,TotalSignedMultiplier  
--,WrittenIfNotSignedOrderMultiplier 
--,TotalWrittenIfNotSignedMultiplier
--,LineMultiplierBandKey						
--,LineMultiplierBand						    
,DQ_FK_PartyBrokerNoticeOfClaim				
,DQ_FK_PartyBrokerPlacing					
,DQ_FK_PartyBrokerProducing					
,DQ_FK_PartyBrokerServiceOfSuit				
							
,FK_ATIAClassOfBusiness						
,FK_Area									
,FK_ClassOfBusiness							
,FK_ClientClassificationCode				
,FK_LocalCurrency							
,FK_LimitCurrency							
,FK_OriginalCurrency						
,FK_ServiceCompany							
,FK_EnteredBy								
,FK_Underwriter								

,FK_UnderwriterAssistantContractCertainty	
,FK_UnderwriterContractCertainty			
,FK_UnderwriterLargeRiskReviewer			
							
,FK_MultiYearGroupDurationBand				
,FK_DurationBand							
,MonthsSinceInceptionBandKey			    
,MonthsSinceInceptionBand	
,FK_HiddenStatusFilter
,HiddenStatusFilter
,FK_SettlementCurrency
,SettlementCCY
,FK_QuoteFilter
,IsQuote
,UnderwriterUserInitials
,OriginalCCYToLocalCCYRate
,IsFacility				
,IsDeclaration			
,HasDataContractSections
,HasNonEurobaseSections	
,FK_Facility
,FK_BreachResponseParentSection
,BreachResponseParentSection
,FK_ATIAChildSection
,TerrorismReference
,FK_LinkedESGBinder  
,FK_LinkedESGTrifocus
,FK_TriFocus
,LinkedESGBinderReference
,FK_LinkedESGSection
,LinkedESGSectionReference
,ATIAClassOfBusinessCode
,AreaCode
,ClientClassificationCode
,LocalCurrency
,ServiceCompanyCode
,UnderwriterName
,UnderwriterRiskEnteredBy
,UnderwriterAssistantContractCertaintyUserInitials
,UnderwriterContractCertaintyUserInitials
,UnderwriterContractCertainty
,LargeRiskReviewerUserInitials
,MonthsSinceInception
,SimpleProduct
,Team 
,Product  
,TechnologyCoverageName 
,ClassifiedAsTechnology
,Trifocus
,CoverageName
,BinderType
,WEPMeldedRate	
,WEPCurrentRate
,LimitMeldedRate
,RateOnLineMultiplier
,RateOnLineBandKey
,RateOnLineBandName
,ExpiringSection
,RenewingSection
,FK_ExpiringSection			
,FK_RenewingSection	
,IsRenewed
,IsRenewal
,QuoteOrBindDate
,WrittenOrEstimatedPremiumInOriginalCCY
,IsSynergySection
,RenewalDueDate
,LeaderPseudonym
,LeaderName
,IsBeazleyLead
,ExpectedPICCTransactions
,IncludeInMunichStacking
,TransactionLiabilityProject
,DQ_InsuredParty
,FK_InternalWrittenBinderStatus
,BinderTypeInternalExternal
,FK_YOA		
,FK_CRMBroker
,ContractCertaintyPreBindOnTime
,ContractCertaintyPostBindOnTime
,CarrierIndicator
,ContractCertaintyPostBindComplete
,DaysBetweenQBAndCCCCDateOrToday
,DaysBetweenQBAndCCPCOrCCPBSDateOrToday
,ContractCertaintyPreBindComplete
,DaysBetweenQBAndCCFCDateOrToday
,FK_UnderwritingPlatform
,UnderwritingPlatformCode
,IsBID
,OriginatingSourceSystem
,FacilityFilter
,FacilityType
,SourceOfBusiness
,LloydsClassOfBusinessCode	
,LloydsClassOfBusiness		
,RiskClassCode			
,FK_LinkedSynergySection
,EntityGrouping
,EntitySplit 
,Entity 
,MarketPlatform
,BeazleyOfficeLocation
,TermsOfTradeExpired
,TermsOfTradeDate
,ContractCertaintyControlsCompliantDate
,ContractCertaintyFullyCompliantDate
,ContractCertaintyPrimaryCompleteDate
,ContractCertaintyPreBindSignatureDate
,DaysBetweenQBAndCCPCDateOrToday
,LiveStatus
,MonthsSinceTOT

FROM Staging.Section



CREATE NONCLUSTERED INDEX [IDX_#StagingSection_PK_Section] ON #Section ([PK_Section] ASC)  WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#StagingSection_FK_Policy] ON #Section ([FK_Policy] ASC)  WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#StagingPolicy_PK_Policy] ON #Policy ([Pk_Policy] ASC)   WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#StagingPolicy_SourceSystem] ON #Policy ([SourceSystem] ASC)   WITH (FILLFACTOR = 90)

	/*Update renewing ref on policy*/
	UPDATE p SET
	RenewingPolicy      = p2.PolicyReference
	FROM
		(
			SELECT
				 PolicyReference    = PolicyReference
				,RenewingPolicy	    = RenewingPolicy
			FROM #Policy   
		) p
	INNER JOIN
		(
			SELECT
				 PolicyReference	= PolicyReference
				,ExpiringPolicy		= ExpiringPolicy
			FROM #Policy  
			WHERE IsQuote = 0
		) p2 
	ON p.PolicyReference = p2.ExpiringPolicy
	

	
	UPDATE p 
	SET	IsRenewal   = 1
	FROM #Policy p 
	WHERE p.ExpiringPolicy IS NOT NULL
	AND ISNULL(p.isrenewal,0) <> 1


	UPDATE pp
	SET pp.fk_yoa = yoa.PK_YOA
	FROM
		(
			SELECT 
				 sourcesystem	  = sourcesystem
				,yoa			  = yoa
				,fk_yoa			  = fk_yoa
			FROM #Policy
			WHERE fk_yoa = 0
			AND yoa <> 0
		) pp

	INNER JOIN ods.yoa yoa
	ON yoa.pk_yoa = pp.yoa


	/*Update expiring policy key*/
	UPDATE p 
	SET FK_ExpiringPolicy  = e.PK_Policy

	FROM 
		(
			SELECT 
				 PK_Policy			  = PK_Policy
				,ExpiringPolicy		  = ExpiringPolicy
				,FK_ExpiringPolicy	  = FK_ExpiringPolicy
			FROM #Policy   
			WHERE PK_Policy <> 0
		) p

	INNER JOIN 
		(
			SELECT
				 PK_Policy			 = PK_Policy
				,PolicyReference	 = PolicyReference
			FROM #Policy  
		) e 
	ON p.ExpiringPolicy = e.PolicyReference


	
	/*Update renewing policy key*/
	UPDATE p 
	SET FK_RenewingPolicy = r.PK_Policy 

	FROM #Policy p  

	INNER JOIN #Policy r   
	ON p.RenewingPolicy = r.PolicyReference

	WHERE p.PK_Policy <> 0


	
	UPDATE p 
	SET FK_PartyBrokerServiceOfSuit			=  ISNULL(b_sos.PK_PartyBroker, 0)

	FROM #Policy p  

	LEFT OUTER JOIN ODS.PartyBroker b_sos   
	ON p.ServiceOfSuitBrokerNumber = b_sos.BrokerNumber
	

	UPDATE p 
	SET FK_QuoteFilter						= qf.PK_QuoteFilter

	FROM #Policy p  

	INNER JOIN ODS.QuoteFilter qf  
	ON p.IsQuote = qf.IsQuote

	
	UPDATE p 
	SET FK_CRMBroker			=  NULL

	FROM #Policy p  

	LEFT OUTER JOIN ODS.CRMBroker crm_p   
	ON  p.FK_CRMBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMBroker, 0) <> 0


	UPDATE p 
	SET FK_CRMProducingBroker			=  NULL

	FROM #Policy p  

	LEFT OUTER JOIN ODS.CRMBroker crm_p   
	ON  p.FK_CRMProducingBroker = crm_p.PK_CRMBroker

	WHERE ISNULL(crm_p.PK_CRMBroker,0) = 0
	AND ISNULL(p.FK_CRMProducingBroker, 0) <> 0

	update p
	set FK_PartyBrokerProducing = 0
	from #Policy p
	where FK_PartyBrokerProducing not in (select PK_PartyBroker from ods.PartyBroker)

	UPDATE P
	SET FK_PartyBrokerPlacing = 0
	from #Policy P
	where FK_PartyBrokerPlacing not in (select PK_PartyBroker from ods.PartyBroker)

	UPDATE s 
	SET ProgramName     = x.SectionReference
	FROM #Section s	  
		INNER JOIN
		(
			SELECT
				SectionReference        = s.SectionReference
				,ProgramNumber          = s.ProgramNumber
				,SequenceId             = ROW_NUMBER() OVER	(PARTITION BY s.ProgramNumber ORDER BY s.ProgramPeriod DESC, s.SectionReference ASC)          
			FROM #Section s
			WHERE s.ProgramNumber IS NOT NULL
			AND s.IsBreachResponseDummy = 0
		) x 
		ON s.ProgramNumber = x.ProgramNumber
		AND x.SequenceId = 1


	UPDATE s
	SET
		DQ_AdditionalInsuredParty				= pol.AdditionalInsuredParty
		-- BI-12429
		--,DQ_Address1							= pol.Address1
		--,DQ_Address2							= pol.Address2
		--,DQ_Address3							= pol.Address3
		--,DQ_InsuredParty						= pol.InsuredParty
		-- BI-12429
		,DQ_NoticeOfClaimBrokerNumber			= pol.NoticeOfClaimBrokerNumber
		,DQ_PlacingBrokerContact				= pol.PlacingBrokerContact
		,DQ_PlacingBrokerNumber					= pol.PlacingBrokerNumber
		,DQ_ProducingBrokerContact				= pol.ProducingBrokerContact
		,DQ_ProducingBrokerNumber				= pol.ProducingBrokerNumber
		,DQ_ReinsuredParty						= pol.ReinsuredParty
		,DQ_ServiceOfSuitBrokerNumber			= pol.ServiceOfSuitBrokerNumber
		,DQ_YOA									= pol.YOA
	
	FROM #Section s

	INNER JOIN #Policy pol

	ON pol.policyreference = s.policyreference

	WHERE pol.SourceSystem = 'BeazleyPro'  


	

	/*Update country name*/
	UPDATE s 
	SET Country         = x.Country
	
	FROM #Section s
	INNER JOIN
		(
			SELECT
				CountryCode             = ac.CountryCode
				,Country                = MIN(Utility.udf_ProcessString(ac.Country, 1))
			FROM Staging_MDS.dbo.vw_area_country_code ac
			WHERE ac.CountryCode IS NOT NULL
			GROUP BY ac.CountryCode
		) x 
	ON s.CountryCode = x.CountryCode
	WHERE s.Country IS NULL

	--MOVED IN Stagin.PostProcessSection as columns from this update are used in Staging.SectionLine
	--/*Update line multipliers on section table*/  
	--UPDATE s SET
	--	WrittenLineMultiplier               = x.WrittenLineMultiplier
	--	,SignedLineMultiplier               = x.SignedLineMultiplier
	--	,WrittenIfNotSignedLineMultiplier   = x.WrittenIfNotSignedMultiplier
	--	,SignedOrderMultiplier              = CASE WHEN x.SignedLineMultiplier IS NOT NULL THEN ISNULL(s.SignedOrderMultiplier, 1) ELSE NULL END
	--	,IsSigned                           = CASE WHEN x.SignedLineMultiplier IS NOT NULL THEN 1 ELSE 0 END

	--FROM #Section s  

	--INNER JOIN
	--		(   
	--			SELECT
	--				SectionReference									= sl.SectionReference
	--				,WrittenLineMultiplier                      = SUM(sl.WrittenLineMultiplier)
	--				,SignedLineMultiplier                       = SUM(sl.SignedLineMultiplier)
	--				,WrittenIfNotSignedMultiplier               = SUM(sl.WrittenIfNotSignedLineMultiplier)
    
	--			FROM Staging.SectionLine sl  
    
	--			GROUP BY sl.SectionReference
	--		) x 
	--ON s.SectionReference = x.SectionReference
	----00:00:55	3817192



	/*Convert limit to original currency - use melded rate here for limit*/
	UPDATE s 
	SET	RateOnLinePremiumEnteredInOriginalCCY       = (s.LimitAmountInLimitCCY / ISNULL(s.LimitCCYToSettlementCCYRateMelded, s.LimitCCYToSettlementCCYRateCurrent)) * s.OriginalCCYToSettlementCCYRate * s.RateOnLineMultiplierEntered
	
	FROM #Section s  

	
	WHERE s.LimitCCY IS NOT NULL
	AND s.OriginalCCY IS NOT NULL
	AND s.SourceSystem <> 'Eurobase'
	

	

	UPDATE s 
	SET DQ_FK_YOA      = f.DQ_FK_YOA
	FROM #Section s 

	INNER JOIN #Section f   
	ON s.Facility = f.SectionReference

	WHERE s.DQ_FK_YOA IS NULL
	AND s.Facility IS NOT NULL
	

	UPDATE p 
	SET FK_YOA         = s.DQ_FK_YOA
	FROM #Policy p  

	INNER JOIN #Section s   
	ON p.policyreference = s.policyreference
	AND s.SectionSequenceId = 1

	WHERE ISNULL(p.FK_YOA, 0) = 0
	and isnull(s.DQ_FK_YOA, 0) <> 0
	


	/*Update multi-year duration*/
	UPDATE s 
	SET MultiYearGroupDurationMonths    = ISNULL(x.MultiYearGroupDurationMonths, s.DurationMonths)
	FROM #Section s   

	LEFT OUTER JOIN
		(
			SELECT
				MultiYearGroupReference             = s.MultiYearGroupReference
				/*Group duration is earliest inception -> latest expiry*/
				,MultiYearGroupDurationMonths       = CASE
														WHEN DATEDIFF(DAY, MIN(s.InceptionDate), MAX(s.ExpiryDate)) < 16 THEN 1
														ELSE ROUND(DATEDIFF(DAY, MIN(s.InceptionDate), MAX(s.ExpiryDate)) / 30.5, 0)
													  END
			FROM #Section s  
			WHERE s.MultiYearGroupReference IS NOT NULL
			GROUP BY s.MultiYearGroupReference
		) x 
	ON s.MultiYearGroupReference = x.MultiYearGroupReference



	/*Update BICI Cession multiplier*/
	UPDATE s 
	SET BICICessionMultiplier   = bcm.CessionMultiplier

	FROM #Section s  
	INNER JOIN Staging.BICICessionMultiplier bcm   
	ON s.AgressoReference = bcm.AgressoReference



	/*Update linked Synergy ref from MDS for Bpro links by section*/
	UPDATE s 
	SET LinkedSynergySection        = dm.Name

	FROM  #Section s  

	INNER JOIN Staging_MDS.MDS_Staging.DeclarationMapping dm 
	ON s.SectionReference = dm.SourceSystemReference

	INNER JOIN #Section l_s  
	ON dm.Name = l_s.SectionReference	


	
	/*Update LinkedNonSynergyRef from MDS for BPro links*/

	UPDATE s 
	SET LinkedNonSynergyReference       = CASE
										WHEN ls.FirstLinkedReference = ls.LastLinkedReference 
										THEN ls.FirstLinkedReference
										ELSE 'Multiple'
									END
	FROM #Section s  

	INNER JOIN
		(
			SELECT
				SynergySectionReference     = Name
				,FirstLinkedReference       = MIN(SourceSystemReference) 
				,LastLinkedReference        = MAX(SourceSystemReference)

			FROM Staging_MDS.MDS_Staging.DeclarationMapping dm  
			GROUP BY dm.Name
		) ls 
	ON s.SectionReference = ls.SynergySectionReference	



	/*Update LinkedSynergyReference by joining back on the non-Synergy reference to the *section ref*/
	UPDATE s_nonsyn 
	SET LinkedSynergySection        = s_syn.SectionReference

	FROM #Section s_nonsyn  

	INNER JOIN #Section s_syn  
	ON s_syn.LinkedNonSynergyReference = s_nonsyn.SectionReference
	--00:01:06	140


	/*Update TransactionLiabilitySectionType field*/
	UPDATE s SET
	TransactionLiabilitySectionType = tlpt.Name

	FROM #Section s  

	INNER JOIN Staging_MDS.MDS_Staging.TransactionLiabilityPolicyType tlpt   
	ON s.ClassOfBusinessCode = tlpt.Code
	


	/*Update "Cargo Or Freight" field*/
	UPDATE s SET
	CargoOrFreight  = CASE s.ClassOfBusinessCode
						WHEN 'WV' THEN 'Cargo'
						WHEN 'WO' THEN 'Freight'
					  END
	FROM #Section s
	WHERE 
	s.ClassOfBusinessCode IN ('WV', 'WO')
	AND s.CargoOrFreight IS NULL
	AND s.IsBreachResponseDummy = 0
	

--MOVED IN Stagin.PostProcessSection as columns from this update are used in Staging.SectionLine

	--/*Total lines*/
	--UPDATE s SET
	--	TotalWrittenMultiplier      = s.WrittenLineMultiplier * s.WrittenOrderMultiplier * s.EstimatedSigningMultiplier/*  /  case 
	--																													when s.SourceSystem = 'USHVH' then 1000
	--																													when s.sourcesystem = 'FDR' then 100 
	--																													else 1 
	--																													end*/
	--	,TotalSignedMultiplier      = s.SignedLineMultiplier * s.SignedOrderMultiplier
	--FROM	#Section s

	--/*Apply "written if not signed rule to the order and the total %*/
	--UPDATE s SET
	--WrittenIfNotSignedOrderMultiplier  = ISNULL(s.SignedOrderMultiplier, s.WrittenOrderMultiplier)
	--,TotalWrittenIfNotSignedMultiplier = ISNULL(s.TotalSignedMultiplier, s.TotalWrittenMultiplier)
	--FROM	#Section s


	--UPDATE s 
	--SET 
	--	WrittenLineMultiplier               = 1
	--	,WrittenOrderMultiplier             = 1
	--	,TotalWrittenMultiplier             = 1
	--	,WrittenIfNotSignedLineMultiplier   = 1
	--	,WrittenIfNotSignedOrderMultiplier  = 1
	--	,TotalWrittenIfNotSignedMultiplier  = 1

	--FROM #Section s  

	--WHERE s.WrittenLineMultiplier IS NULL

	
	
	--UPDATE s 
	--SET 
	--	WrittenIfNotSignedLineMultiplier   = 1
		
	--FROM #Section s  

	--WHERE ISNULL(s.WrittenIfNotSignedLineMultiplier, 0) = 0



	/*Update line % bands*/

		UPDATE s 

	SET 
		-- LineMultiplierBandKey						= ISNULL(lmb.BandMin, 0)   --Moved in Staging.PostProcessSection
		--,LineMultiplierBand						    = ISNULL(lmb.Name, 'N/A')	
		DQ_FK_PartyBrokerNoticeOfClaim				= ISNULL(b_noc.PK_PartyBroker, 0)
		,DQ_FK_PartyBrokerPlacing					= CASE WHEN se.PlacingBrokerNumber is not null then isnull( b_pl.PK_PartyBroker,0) ELSE ISNULL(brk.PK_PartyBroker,0) END
		,DQ_FK_PartyBrokerProducing					= CASE WHEN se.ProducingBrokerNumber is not null then isnull( b_pr.PK_PartyBroker,0) ELSE ISNULL(brkpr.PK_PartyBroker,0) END
		,DQ_FK_PartyBrokerServiceOfSuit				= ISNULL(b_sos.PK_PartyBroker, 0)
		,DQ_FK_YOA									= ISNULL(yoa.PK_YOA, 0)
		,FK_ATIAClassOfBusiness						= ISNULL(atia_cob.PK_ClassOfBusiness, 0)
		,FK_Area									= ISNULL(a.PK_Area, 0)
		,FK_ClassOfBusiness							= ISNULL(cob.PK_ClassOfBusiness, 0)
		,FK_ClientClassificationCode				= ISNULL(ccc.PK_ClientClassificationCode, 0)
		,FK_LocalCurrency							= ISNULL(lc.PK_LocalCurrency, 0)
		,FK_LimitCurrency							= ISNULL(oc_lim.PK_OriginalCurrency, 0)
		,FK_OriginalCurrency						= ISNULL(oc.PK_OriginalCurrency, 0)
		,FK_ServiceCompany							= ISNULL(sco.PK_ServiceCompany, 0)
		,FK_EnteredBy								= COALESCE(inputby.PK_Underwriter, 0)
		,FK_Underwriter								= COALESCE(und.PK_Underwriter, 0)
		
		,FK_UnderwriterAssistantContractCertainty	= ISNULL(ua_cc.PK_Underwriter, 0)
		,FK_UnderwriterContractCertainty			= ISNULL(u_cc.PK_Underwriter, 0)
		,FK_UnderwriterLargeRiskReviewer			= ISNULL(u_lrr.PK_Underwriter, 0)
	--	,FK_UnderwritingPlatform					= ISNULL(up.PK_UnderwritingPlatform, 0)	
	--	,IsBID										= ISNULL(up.IsBID, 0)	
		,FK_MultiYearGroupDurationBand				= ISNULL(db_m.PK_DurationBand, 0)
		,FK_DurationBand							= ISNULL(db_s.PK_DurationBand, 0)
		,MonthsSinceInceptionBandKey			    = md.BandMin
		,MonthsSinceInceptionBand					= ISNULL(md.BandName, 'N/A')
		
	FROM #Section s  

	LEFT OUTER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension se
	ON s.SectionReference = se.SectionReference

	--LEFT OUTER JOIN Staging_MDS.MDS_Staging.LineMultiplierBand lmb   
	--ON s.TotalWrittenIfNotSignedMultiplier > lmb.BandMin
	--AND s.TotalWrittenIfNotSignedMultiplier <= lmb.BandMax

	LEFT OUTER JOIN ODS.PartyBroker b_noc   
	ON s.DQ_NoticeOfClaimBrokerNumber = b_noc.BrokerNumber

	LEFT OUTER JOIN 
	(	SELECT	BrokerName		= pb.BrokerName
				,BrokerNumber	= MAX(pb.BrokerNumber)
				,PK_PartyBroker = MAX(PK_PartyBroker)
		FROM ODS.PartyBroker pb  
		GROUP BY pb.BrokerName
	) brk 
	ON se.PlacingBrokerBranchName = brk.BrokerName


	LEFT OUTER JOIN ODS.PartyBroker b_pl   
	ON  CASE WHEN s.DQ_PlacingBrokerNumber is not null then isnull( NULLIF(b_pl.OriginalBrokerNumber,0) , b_pl.BrokerNumber) ELSE ISNULL(brk.BrokerNumber,0) END = ISNULL(s.DQ_PlacingBrokerNumber,0)
	AND se.PlacingBrokerBranchName = b_pl.BrokerName
	
	LEFT OUTER JOIN 
	(	SELECT	BrokerName		= pb.BrokerName
				,BrokerNumber	= MAX(pb.BrokerNumber)
				,PK_PartyBroker = MAX(PK_PartyBroker)
		FROM ODS.PartyBroker pb  
		GROUP BY pb.BrokerName
	  ) brkpr 
	ON se.ProducingBrokerBranchName = brkpr.BrokerName
	
	LEFT OUTER JOIN	ODS.PartyBroker b_pr   
	ON  CASE WHEN s.DQ_ProducingBrokerNumber is not null then isnull(  NULLIF(b_pr.OriginalBrokerNumber,0) , b_pr.BrokerNumber) ELSE ISNULL(brkpr.BrokerNumber,0) END = ISNULL(s.DQ_ProducingBrokerNumber,0)
	AND se.ProducingBrokerBranchName = b_pr.BrokerName

	LEFT OUTER JOIN	ODS.PartyBroker b_sos   
	ON s.DQ_ServiceOfSuitBrokerNumber = b_sos.BrokerNumber

	LEFT OUTER JOIN	ODS.YOA yoa   
	ON s.DQ_YOA = yoa.PK_YOA

	LEFT OUTER JOIN	ODS.ClassOfBusiness atia_cob   
	ON s.ATIAClassOfBusinessCode = atia_cob.ClassOfBusinessCode

	LEFT OUTER JOIN	ODS.Area a   
	ON s.AreaCode = a.AreaCode

	LEFT OUTER JOIN	ODS.ClassOfBusiness cob   
	ON s.ClassOfBusinessCode = cob.ClassOfBusinessCode

	LEFT OUTER JOIN ODS.ClientClassificationCode ccc   
	ON s.ClientClassificationCode = ccc.ClientClassificationCode

	LEFT OUTER JOIN	ODS.LocalCurrency lc   
	ON s.LocalCurrency = lc.CurrencyCode

	LEFT OUTER JOIN	ODS.OriginalCurrency oc_lim   
	ON s.LimitCCY = oc_lim.CurrencyCode

	LEFT OUTER JOIN	ODS.OriginalCurrency oc   
	ON s.OriginalCCY = oc.CurrencyCode

	LEFT OUTER JOIN	ODS.ServiceCompany sco   
	ON sco.ServiceCompanyCode = s.ServiceCompanyCode

	LEFT OUTER JOIN 
		( 
			SELECT 
				PK_Underwriter						= MIN(u.PK_Underwriter)
				,UnderwriterName					= u.UnderwriterName
			FROM ODS.Underwriter u
			GROUP BY u.UnderwriterName
		) und 
	ON s.UnderwriterName = und.UnderwriterName

	-- Risk Entered By key for sections
	LEFT OUTER JOIN 
		( 
			SELECT 

				PK_Underwriter						= MIN(u.PK_Underwriter)
				,UnderwriterName					= u.UnderwriterName
			FROM ODS.Underwriter u
			GROUP BY u.UnderwriterName
		) inputby
	ON s.UnderwriterRiskEnteredBy = inputby.UnderwriterName

	LEFT OUTER JOIN	ODS.Underwriter ua_cc   
	ON s.UnderwriterAssistantContractCertaintyUserInitials = ua_cc.UnderwriterUserInitials 

	LEFT OUTER JOIN	ODS.Underwriter u_cc   
	ON s.UnderwriterContractCertaintyUserInitials = u_cc.UnderwriterUserInitials 
	OR s.UnderwriterContractCertainty = u_cc.UnderwriterName

	LEFT OUTER JOIN	ODS.Underwriter u_lrr   
	ON s.LargeRiskReviewerUserInitials = u_lrr.UnderwriterUserInitials
		
	--LEFT OUTER JOIN	ODS.UnderwritingPlatform up   
	--ON up.UnderwritingPlatformCode = s.UnderwritingPlatformCode

	LEFT OUTER JOIN ODS.DurationBand db_m 
	ON s.MultiYearGroupDurationMonths >= db_m.BandMinMonths 
	AND s.MultiYearGroupDurationMonths < db_m.BandMaxMonths

	LEFT OUTER JOIN ODS.DurationBand db_s   
	ON s.DurationMonths >= db_s.BandMinMonths 
	AND s.DurationMonths < db_s.BandMaxMonths
	--- 4:28 min 
	LEFT OUTER JOIN  Staging_MDS.MDS_Staging.MovementDurationBand md 
	ON  s.MonthsSinceInception >= md.BandMin  
	AND s.MonthsSinceInception < md.BandMax 
	AND s.MonthsSinceInception >= 0

	
	

		
	UPDATE s 
	SET FK_HiddenStatusFilter						= hsf.PK_HiddenStatusFilter

	FROM #Section s  

	INNER JOIN ODS.HiddenStatusFilter hsf   
	ON s.HiddenStatusFilter = hsf.HiddenStatusFilter
	

	UPDATE s 
	SET FK_SettlementCurrency						= sc.PK_SettlementCurrency

	FROM #Section s  

	INNER JOIN ODS.SettlementCurrency sc   
	ON s.SettlementCCY = sc.CurrencyCode
	


	UPDATE s 
	SET FK_QuoteFilter								= qf.PK_QuoteFilter

	FROM #Section s  
	
	INNER JOIN ODS.QuoteFilter qf   
	ON s.IsQuote = qf.IsQuote
	

	UPDATE s 
	SET FK_Underwriter								= COALESCE(s.FK_Underwriter, u.PK_Underwriter, 0)

	FROM #Section s  

	LEFT OUTER JOIN ODS.Underwriter u   
	ON s.UnderwriterUserInitials = u.UnderwriterUserInitials


	/* Default local currency rate to 1 where there is no local currency */
	UPDATE s 
	SET OriginalCCYToLocalCCYRate = 1

	FROM #Section s  

	WHERE s.FK_LocalCurrency = 0
	
	/*Clear logic ncessary for delta load(BI12521)*/
	UPDATE s 
	SET IsFacility					= 0
		,IsDeclaration				= 0
		,HasDataContractSections	= 0
		,HasNonEurobaseSections		= 0
	FROM #Section s


	/*Update facility key and declaration flag*/
	UPDATE s 
	SET FK_Facility                         = f.PK_Section 
		,IsDeclaration                      = 1

	FROM #Section s

	INNER JOIN #Section f 
	ON s.Facility = f.SectionReference

	WHERE s.PK_Section <> 0
	


	/*Update facility flag and set FK_Facility = PK_Section for facilities*/
	UPDATE s 
	SET IsFacility                      = 1
		,FK_Facility                    = s.PK_Section

	FROM #Section s  

	INNER JOIN #Section d   
	ON s.PK_Section = d.FK_Facility

	WHERE s.PK_Section <> 0
	
	
	
	/*Update breach response parent key*/
	UPDATE s 
	SET FK_BreachResponseParentSection = ISNULL(brp.PK_Section, 0) 

	FROM #Section s  

	LEFT JOIN #Section brp   
	ON s.BreachResponseParentSection = brp.SectionReference

	WHERE s.PK_Section <> 0
		
	/* End Binder written status */

	/*Update ATIA Child section Key*/
	UPDATE s 
	SET FK_ATIAChildSection = atia.PK_Section

	FROM #Section s  

	LEFT JOIN #Section atia   
	ON s.TerrorismReference = atia.SectionReference

	WHERE s.PK_Section <> 0
	
	--BI-7113 - ESG linked columns
	
	UPDATE s 
	SET  FK_LinkedESGBinder      = f.PK_Section
	    ,FK_LinkedESGTrifocus    = f.FK_Trifocus
	FROM #Section s
	INNER JOIN #Section f 
	ON s.LinkedESGBinderReference = f.SectionReference
	WHERE s.PK_Section <> 0
	
	UPDATE s 
	SET FK_LinkedESGSection     = f.PK_Section
	FROM #Section s
	INNER JOIN #Section f 
	ON s.LinkedESGSectionReference = f.SectionReference
	WHERE s.PK_Section <> 0


--	BI-9310 - Link ESG section to it's linked section

	UPDATE s 
	SET  FK_LinkedESGSection		= f.PK_Section
	    ,LinkedESGSectionReference  = f.SectionReference
	    ,FK_LinkedESGTrifocus       = f.FK_TriFocus
	FROM #Section s
	INNER JOIN #Section f 
	ON s.SectionReference = f.LinkedESGSectionReference
	WHERE s.PK_Section <> 0


	---PostProcessPolicyAndSection
	                
UPDATE s
	SET s.FK_Policy = p.PK_Policy
	FROM #Section  s
	
	INNER JOIN #Policy  p 
	ON p.policyreference = s.policyreference
	

	update s
	set s.dq_yoa = p.yoa

	FROM #Section  s

	INNER JOIN #Policy  p 
	on p.pk_policy = s.fk_policy

	WHERE p.sourcesystem not in ('Eurobase', 'unirisx', 'Gamechanger', 'CIPS', 'MyBeazley', 'FDR', 'USHVH', 'US High Value Homeowners')

	
	DROP TABLE IF EXISTS #PoliciesToDelete
	
	SELECT
		p.PolicyReference
	INTO #PoliciesToDelete
	FROM #Policy  p
	WHERE 
	NOT EXISTS(SELECT 1 FROM #Section  s WHERE s.policyreference = p.policyreference)

	

	UPDATE p
	SET  RenewingPolicy = NULL
		,FK_RenewingPolicy = NULL
	
	FROM #Policy  p

	INNER Join #PoliciesToDelete pd

	ON pd.policyreference = p.RenewingPolicy
	

	
	UPDATE p
	SET  ExpiringPolicy = NULL
		,FK_ExpiringPolicy = NULL
	
	FROM #Policy  p

	INNER Join #PoliciesToDelete pd

	ON pd.policyreference = p.ExpiringPolicy


	DELETE p
	
	FROM #Policy  p

	INNER JOIN #PoliciesToDelete pd 
	
	ON pd.PolicyReference = p.PolicyReference
	


	DELETE s
	
	FROM #Section  s 

	WHERE 
	NOT EXISTS(SELECT 1 FROM #Policy  p WHERE s.policyreference = p.policyreference)

	DELETE s
	FROM 
		(
			SELECT
				Pk_Section			= Pk_Section
				,policyreference	= policyreference
			FROM #Section 
			WHERE SourceSystem = 'ClaimCenter'
		) s
	LEFT JOIN 
		(
			SELECT 
				policyreference		= policyreference
			FROM #Policy 
			WHERE SourceSystem = 'ClaimCenter'
		) p
	ON p.policyreference = s.policyreference
	WHERE p.policyreference IS NULL

	DELETE FROM staging.Policy WHERE PK_Policy not in (SELECT PK_Policy from #Policy)
	DELETE FROM staging.Section WHERE PK_Section not in (SELECT PK_Section from #Section)

	Update s
	SET s.FK_Underwriter = sub.FK_Underwriter
	FROM 
		(
			SELECT
				 fk_policy			 = 	fk_policy		
				,FK_Underwriter		 = 	FK_Underwriter	
			FROM #Section 
		) s

	INNER  JOIN 
		(
			SELECT					  
				 pk_policy			  =	 pk_policy
				,FK_Submission		  =	 FK_Submission
			FROM #Policy 
			WHERE SourceSystem = 'BeazleyPro'
		)p
	on p.pk_policy = s.fk_policy
	
	INNER JOIN ODS.Submission sub
	ON p.FK_Submission = sub.PK_Submission


	/*Simple product code & team lookup*/
	   UPDATE s 
    SET 
      SimpleProduct = COALESCE(uspt.SimpleProductName, pt.SimpleProductName), 
      Team = COALESCE(sec.ProductTeam, CASE WHEN p.MarketSegmentCode = 'MM' THEN pt.MMTeamName WHEN p.MarketSegmentCode = 'PE' THEN pt.PETeamName END) 
    FROM 
      (
        SELECT 
          SimpleProduct = SimpleProduct, 
          Team = Team, 
          Product = Product, 
          SectionReference = SectionReference, 
          FK_Policy = FK_Policy 
        FROM #Section  
          ) s 
      INNER JOIN (
        SELECT 
          PK_Policy = PK_Policy, 
          MarKetSegmentCode = MarKetSegmentCode 
        FROM #policy  
          ) p 
		  ON s.FK_Policy = p.PK_Policy 
      INNER JOIN Staging_MDS.MDS_Staging.Product pt 
	  ON s.Product = pt.[Name] 
      LEFT OUTER JOIN (
        SELECT 
          SectionReference = SectionReference, 
          ProductTeam = ProductTeam 
        FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension
		WHERE SourceSystem = 'BeazleyPro'
      ) sec 
	  ON s.SectionReference = sec.SectionReference 
      LEFT OUTER JOIN Staging_MDS.MDS_Staging.USProduct uspt 
	  ON s.Product = uspt.Name
	


	
	/* TechnologyCoverageName */
	UPDATE s 
	SET
		TechnologyCoverageName  = tm.TechnologyCoverageName
		,ClassifiedAsTechnology = CASE
										WHEN tm.TechnologyCoverageName IS NULL OR tm.TechnologyCoverageName = 'N/A' THEN 'NA' 
										ELSE 'Technology' 
									END
	
	FROM #Section  s
	
	INNER JOIN #Policy  p 
	ON p.PolicyReference = s.PolicyReference
	
	LEFT OUTER JOIN Staging_MDS.MDS_Staging.TechnologyMapping tm
	ON  tm.Trifocus_Name = s.Trifocus
		AND tm.ClassOfBusinessCode = s.ClassOfBusinessCode
		AND ISNULL(tm.ProductName,'') = ISNULL(s.Product,'') 
		AND tm.CoverageName = s.CoverageName
		AND tm.SourceSystem_Name = p.SourceSystem


	/*Update primary section values on policy table*/
	UPDATE p 
	SET PrimarySectionBinderType   = s.BinderType

	FROM #Policy  p  

	INNER JOIN #Section  s   
	ON p.PK_Policy = s.FK_Policy
	AND s.SectionSequenceId = 1
	

	
	/*Update GBP (melded/current) rates*/
	DROP TABLE IF EXISTS #SectionMeldedRate

	SELECT 
		 Currency			= Currency
		,SectionReference	= SectionReference
		,RateIdentifier		= RateIdentifier
		,MeldedRate			= MeldedRate
		INTO #SectionMeldedRate
	FROM Utility.SectionMeldedRate   
	WHERE RateIdentifier = 'MEL'
	
	
	

	UPDATE s
	SET  s.WEPMeldedRate							= mwep.MeldedRate
		,s.WEPCurrentRate							= crwep.ExchangeRate
		,s.LimitMeldedRate							= mlim.MeldedRate
		

	FROM 
		(
			SELECT 
				PK_Section				= ss.PK_Section
				,SectionReference		= ss.SectionReference
				,OriginalCCY			= ss.OriginalCCY	
				,LimitCCY				= ss.LimitCCY		
				,SettlementCCY			= ss.SettlementCCY
				,FK_Policy				= ss.FK_Policy
				,SourceSystem			= p.SourceSystem
				,WEPMeldedRate			= ss.WEPMeldedRate	
				,WEPCurrentRate			= ss.WEPCurrentRate
				,LimitMeldedRate		= ss.LimitMeldedRate

			FROM #Section  ss  
			INNER JOIN 
					(
						SELECT
							 PK_Policy			= PK_Policy
							,SourceSystem		= SourceSystem
						FROM  #Policy    
						WHERE SourceSystem <> 'Eurobase'
					) p 
			ON p.PK_Policy = ss.FK_Policy


		) s

	LEFT OUTER JOIN #SectionMeldedRate mwep   
	ON s.SectionReference = mwep.SectionReference 
	AND s.OriginalCCY = mwep.Currency 


	LEFT OUTER JOIN #SectionMeldedRate mlim   
	ON s.SectionReference = mlim.SectionReference 
	AND s.LimitCCY = mlim.Currency 

	LEFT OUTER JOIN Utility.CurrencyRate crwep   
	ON s.OriginalCCY = crwep.Currency
	AND crwep.RateType = 'Current'
	

	/*Update original CCY to settlement CCY rate*/
	UPDATE s 
	SET OriginalCCYToSettlementCCYRate      =   COALESCE(s.OriginalCCYToSettlementCCYRate, s.WEPMeldedRate / ISNULL(msett.MeldedRate, crsett.ExchangeRate), s.WEPCurrentRate / crsett.ExchangeRate)

	FROM #Section  s  

	LEFT OUTER JOIN #SectionMeldedRate msett  
	ON s.SectionReference = msett.SectionReference 
	AND s.SettlementCCY = msett.Currency 

	LEFT OUTER JOIN Utility.CurrencyRate crsett   
	ON s.SettlementCCY = crsett.Currency
	AND crsett.RateType = 'Current'
	
	
	/*Update Limit melded rate*/
	UPDATE ss
	SET LimitCCYToSettlementCCYRateMelded      = COALESCE(s.LimitCCYToSettlementCCYRateMelded, 
													mlim.MeldedRate / ISNULL(msett.MeldedRate, crsett.ExchangeRate))
	FROM #Section  ss   

	LEFT JOIN  Staging.Staging_MeldedRate s  
	on ss.sectionreference = s.SectionReference

	LEFT OUTER JOIN #SectionMeldedRate mlim   
	ON ss.SectionReference = mlim.SectionReference 
	AND ss.LimitCCY = mlim.Currency 

	LEFT OUTER JOIN #SectionMeldedRate msett   
	ON ss.SectionReference = msett.SectionReference 
	AND ss.SettlementCCY = msett.Currency 

	LEFT OUTER JOIN Utility.CurrencyRate crsett   
	ON ss.SettlementCCY = crsett.Currency
	AND crsett.RateType = 'Current'

	INNER JOIN 
		(
			SELECT 
				PK_Policy		= PK_Policy
			FROM #Policy    
			WHERE SourceSystem <> 'Eurobase'
		) p
	ON p.PK_Policy = ss.FK_Policy
	

	/*Update Limit rate*/
	UPDATE ss 
	SET	LimitCCYToSettlementCCYRateCurrent      = COALESCE(ss.LimitCCYToSettlementCCYRateCurrent, crlim.ExchangeRate / crsett.ExchangeRate)

	FROM #Section  ss   

	LEFT JOIN  Staging.Staging_MeldedRate s  
	on ss.sectionreference = s.SectionReference

	LEFT OUTER JOIN Utility.CurrencyRate crlim   
	ON ss.LimitCCY = crlim.Currency
	AND crlim.RateType = 'Current'

	LEFT OUTER JOIN Utility.CurrencyRate crsett   
	ON ss.SettlementCCY = crsett.Currency
	AND crsett.RateType = 'Current'

	INNER JOIN 
		(
			SELECT 
				PK_Policy		= PK_Policy 
			FROM #Policy    
			WHERE SourceSystem <> 'Eurobase'
		) p
	ON p.PK_Policy = ss.FK_Policy
	
			
	/*Update ROL multiplier - convert to sett ccy first*/
	UPDATE s 
	SET	RateOnLineMultiplier    = NULLIF((s.WrittenOrEstimatedPremiumInOriginalCCY / s.OriginalCCYToSettlementCCYRate), 0)
							  /
							  NULLIF((s.LimitAmountInLimitCCY / s.LimitCCYToSettlementCCYRateCurrent), 0)
	FROM #Section  s


	/*Update ROL bandings*/
	UPDATE s 
	SET RateOnLineBandKey           = ISNULL(rolb.BandMin, 0)
		,RateOnLineBandName         = ISNULL(rolb.[Name], 'N/A')

	FROM 
		(
			SELECT
				 SectionReference		 = SectionReference
				,RateOnLineMultiplier	 = RateOnLineMultiplier
				,RateOnLineBandKey		 = RateOnLineBandKey
				,RateOnLineBandName		 = RateOnLineBandName
			FROM #Section   
		) s

	LEFT OUTER JOIN Staging_MDS.MDS_Staging.RateOnLineBand rolb   
	ON s.RateOnLineMultiplier > rolb.BandMin
		AND s.RateOnLineMultiplier <= rolb.BandMax
	

	/*Expiring section for policies where the product or coverage names are different. 
	We use the MDS mappings provided (ProductCoverageRenewalMapping).*/
	DROP TABLE IF EXISTS #Expiring_Policy
	SELECT
		 PK_Policy			= p.PK_Policy
		,PolicyReference		= p.PolicyReference
		,ExpiringPolicy		= p.ExpiringPolicy
		,RenewingPolicy		= p.RenewingPolicy
		,SourceSystem		= p.SourceSystem

		INTO #Expiring_Policy 
	FROM #Policy  p  

	DROP TABLE IF EXISTS #Expiring_Section

	SELECT
		 PK_Section		    = PK_Section
		,SectionReference   = SectionReference
		,ExpiringSection    = ExpiringSection
		,RenewingSection    = RenewingSection
		,Product		    = Product
		,CoverageName	    = CoverageName
		,FK_Policy		    = FK_Policy
		,PolicyReference	= CAST(null as varchar(255))
		INTO #Expiring_Section 
	FROM #Section   

	UPDATE s
	SET s.PolicyReference = p.PolicyReference
	
	FROM #Expiring_Section s  
		
	INNER JOIN #Expiring_Policy p  
	ON p.pk_policy = s.fk_policy

	--clear logic for Expiring and Renewing section (ncessary for delta load)
	UPDATE s 
		SET FK_ExpiringSection	= NULL,
			RenewingSection		= NULL,
			FK_RenewingSection	= NULL 
	FROM	#Section  s  

	UPDATE s 
	SET s.ExpiringSection             = s_e.SectionReference
		,s.FK_ExpiringSection		  = s_e.PK_Section

	FROM 
		(
			SELECT
				 SectionReference	   = SectionReference
				,Product			   = Product
				,CoverageName		   = CoverageName
				,FK_Policy			   = FK_Policy	
				,ExpiringSection	   = ExpiringSection
				,FK_ExpiringSection	   = FK_ExpiringSection
			FROM #Section  
			WHERE IsBreachResponseDummy = 0
		) s

	INNER JOIN #Expiring_Policy p   
	ON s.FK_Policy = p.pk_policy

	INNER JOIN #Expiring_Policy p_e   
	ON p.ExpiringPolicy = p_e.PolicyReference

	INNER JOIN #Expiring_Section s_e   
	ON p_e.PolicyReference = s_e.PolicyReference 

	INNER JOIN Staging_MDS.MDS_Staging.ProductCoverageRenewalMapping prodmap  
	ON  s_e.Product         = prodmap.ProductNameSource
		AND s_e.CoverageName    = prodmap.CoverageNameSource
		AND s.Product           = prodmap.ProductNameTarget
		AND s.CoverageName      = prodmap.CoverageNameTarget
		AND p.SourceSystem      = prodmap.SourceSystem_Name
	

		
	--/*Update expiring section key*/
	UPDATE s 
	SET FK_ExpiringSection  = e.PK_Section

	FROM #Section  s  

	INNER JOIN #Section  e   
	ON s.ExpiringSection = e.SectionReference 

	WHERE s.PK_Section <> 0
	AND ISNULL(s.FK_ExpiringSection, 0) <> e.PK_Section

	
	/*Update renewing ref on section*/
	UPDATE s 
	SET	s.RenewingSection          = s2.SectionReference
		,s.FK_RenewingSection		= s2.Pk_Section
	FROM
		(
			SELECT
				 SectionReference	   = SectionReference
				,RenewingSection	   = RenewingSection
				,FK_RenewingSection	   = FK_RenewingSection
			FROM #Section    
			WHERE IsBreachResponseDummy = 0
		) s
	LEFT JOIN 
		(
			SELECT						
				 PK_Section				= PK_Section
				,SectionReference		= SectionReference
				,ExpiringSection		= ExpiringSection
			FROM #Section    
			WHERE IsQuote = 0
		) s2 
	ON s.SectionReference = s2.ExpiringSection
	

	
	/*Set the corresponding renewing section for dummy BBR sections*/
	UPDATE s 
	SET RenewingSection				= s_ren.SectionReference	
		,s.FK_RenewingSection		= s_ren.Pk_Section
		,IsRenewed					= 1

	FROM 
		(
			SELECT
				 RenewingSection	   = RenewingSection
				,IsRenewed			   = IsRenewed
				,SectionReference	   = SectionReference
				,FK_RenewingSection	   = FK_RenewingSection
			FROM #Section    
		) s 

	INNER JOIN 
		(
			SELECT
				 PK_Section				= PK_Section
				,SectionReference		= SectionReference
				,ExpiringSection		= ExpiringSection
			FROM #Section    
			WHERE IsBreachResponseDummy = 1
		) s_ren 
	ON s_ren.ExpiringSection = s.SectionReference
	
	
	/*Update renewal flag on section*/
	UPDATE s SET
	IsRenewal   = 1 --Might already be set to 1 for data contract sections where there is no expiring ref

	FROM #Section  s
	WHERE	s.ExpiringSection IS NOT NULL

	/*Update renewed flag on section*/
	UPDATE s SET
	IsRenewed   = 1

	FROM  #Section  s
	WHERE s.RenewingSection IS NOT NULL

	
	UPDATE p 
	SET	p.IsRunOff = CASE
						WHEN p.RunOffDate IS NOT NULL AND x.QuoteOrBindDate IS NOT NULL AND x.GrossPremium > 1 	THEN 1
						ELSE 0
				   END

	FROM 
		(
			SELECT
				 Pk_policy	   =  Pk_policy
				,RunOffDate	   =  RunOffDate
				,IsRunOff	   =  IsRunOff
			FROM #Policy  
			WHERE SourceSystem = 'BeazleyPro'
		)p

	INNER JOIN (
					SELECT 
							FK_Policy				= s.FK_Policy
						,QuoteOrBindDate		= MAX(s.QuoteOrBindDate)
						,GrossPremium			= SUM(ISNULL(s.WrittenOrEstimatedPremiumInOriginalCCY,0))                                                                               
					FROM #Section  s				
					
					WHERE s.SourceSystem = 'BeazleyPro'					
					GROUP BY s.FK_Policy
					
				) x 
	ON p.pk_Policy = x.FK_Policy


	/*Update AnySectionIsSynergy flag on policy*/
	UPDATE p 
	SET AnySectionIsSynergy = 1

	FROM 
		(
			SELECT
				 PK_Policy				= PK_Policy
				,AnySectionIsSynergy	= AnySectionIsSynergy
			FROM #Policy  
		)p 

	INNER JOIN 
		(
			SELECT
				FK_policy		= FK_policy
			FROM #Section    
			WHERE IsSynergySection = 1
		)s 
	ON p.PK_Policy = s.FK_Policy
	

	
	/*Update renewal due date. Rules are as follows:
    - If it has renewed and the inception of the renewal is within 1 day of the expiry, then use the inception of the renewal
    - Otherwise, use expiry date + 1 day for Eurobase, expiry date for pro & everything else
	*/
	UPDATE s SET
	RenewalDueDate      = CASE 
							WHEN ABS(DATEDIFF(DAY, s.ExpiryDate, s_r.InceptionDate)) <= 1 THEN s_r.InceptionDate
							ELSE 
							  CASE 
									WHEN p.SourceSystem IN ( 'Eurobase', 'Etrek') THEN DATEADD(DAY, 1, s.ExpiryDate)
									ELSE s.ExpiryDate
							  END
							END
	FROM 
		(
			SELECT
				 RenewalDueDate		  = RenewalDueDate
				,ExpiryDate			  = ExpiryDate
				,RenewingSection	  = RenewingSection
				,FK_Policy			  = FK_Policy
			FROM #Section    
		)s

	LEFT OUTER JOIN 
		(
			SELECT					  
				 SectionReference	  =	SectionReference
				,InceptionDate		  =	InceptionDate
			FROM #Section    
		) s_r 
	ON s.RenewingSection = s_r.SectionReference

	INNER JOIN 
		(
			SELECT
				 SourceSystem	   = SourceSystem
				,PK_Policy		   = PK_Policy
			FROM #Policy    
		) p 
	ON s.FK_Policy = p.PK_Policy
	



	/*Set flag on policy table for dummy BBR sections*/
	UPDATE p SET
	AnySectionIsBreachResponseDummy = 1
	FROM
		(
			SELECT
				FK_Policy		= FK_Policy
			FROM #Section    
			WHERE IsBreachResponseDummy = 1
		) s 

	INNER JOIN 
		(
			SELECT
				 PK_Policy							= PK_Policy
				,AnySectionIsBreachResponseDummy	= AnySectionIsBreachResponseDummy
			FROM #Policy    
		) p 
	ON s.FK_Policy = p.PK_Policy
	

	
	/*For BeazleyPro and ClaimCenter policies, update leader from parent facility*/
	UPDATE s SET
	LeaderPseudonym     = f.LeaderPseudonym
	,LeaderName         = f.LeaderName

	FROM 
		(
			SELECT
				 LeaderPseudonym	  = LeaderPseudonym
				,LeaderName			  = LeaderName
				,FK_Policy			  = FK_Policy
				,Facility			  = Facility
			FROM #Section    
			WHERE  ISNULL(Product,'') <> 'MyBeazley Broker Access PCG'	
		)s

	INNER JOIN 
		(
			SELECT
				PK_Policy		= PK_Policy
			FROM #Policy    
			WHERE SourceSystem IN ('BeazleyPro','Gamechanger','myBeazley')
		) p 
	ON s.FK_Policy = p.PK_Policy

	INNER JOIN #Section  f   
	ON s.Facility = f.SectionReference
	



	/*Update leader flag on section*/
	UPDATE s 
	SET IsBeazleyLead = CASE 
							WHEN s.LeaderPseudonym = 'AFB' THEN 1 
							ELSE 0 
						END
	FROM 
		(
			SELECT
				 FK_Policy			 = FK_Policy
				,LeaderPseudonym	 = LeaderPseudonym
				,IsBeazleyLead		 = IsBeazleyLead
			FROM #Section    
		) s
	INNER JOIN 
		(
			SELECT 
				PK_Policy	= PK_Policy
			FROM #Policy    
			WHERE SourceSystem NOT IN ( 'Eurobase', 'Unirisx') 
		)p 
	ON s.FK_Policy = p.PK_Policy
	

	/*Update expected PICC transactions - see utility function for logic*/
	UPDATE s 
	SET ExpectedPICCTransactions        = Utility.udf_ExpectedPICCTransactions(s.InceptionDate, s.DurationMonths, GETDATE())

	FROM 
		(
			SELECT
				 FK_Policy					   =  FK_Policy
				,InceptionDate				   =  InceptionDate
				,DurationMonths				   =  DurationMonths
				,ExpectedPICCTransactions	   =  ExpectedPICCTransactions
			FROM #Section    
			WHERE DurationMonths > 0
				AND IsBreachResponseDummy = 0
		) s

	INNER JOIN 
		(
			SELECT
				PK_Policy  = PK_Policy
			FROM #Policy    
			WHERE MethodOfPlacementCode = 'B'
				AND IsQuote = 0
		) p 
	ON s.FK_Policy = p.PK_Policy
	--00:00:02	27232




	/*For unverified policies, where the binder attaches to R1139*/
	UPDATE s 
	SET	IncludeInMunichStacking = 1
	FROM #Section  s

	INNER JOIN #Policy  p 
	ON s.PolicyReference = p.PolicyReference

	INNER JOIN Staging_MDS.dbo.vw_policy_reinsurance_link pr 
	ON s.Facility = pr.SectionReference
	
	WHERE p.SourceSystem = 'ClaimCenter'
		AND pr.ContractReference LIKE 'R1139%'

	UPDATE s 
	SET	IncludeInMunichStacking = 1
	FROM #Section  s

	INNER JOIN #Policy  p 
	ON s.PolicyReference = p.PolicyReference

	INNER JOIN Staging_MDS.dbo.vw_policy_reinsurance_link_qqs pr 
	ON s.Facility = pr.SectionReference
	
	WHERE p.SourceSystem = 'ClaimCenter'
		AND pr.ContractReference LIKE 'R1139%'


	/*Update linked Synergy ref from MDS for Bpro links by policy*/
	UPDATE s 
	SET LinkedSynergySection        = dm.Name

	FROM 
		(
			SELECT
				 SectionReference		   =  SectionReference
				,LinkedSynergySection	   =  LinkedSynergySection
				,FK_Policy				   =  FK_Policy
			FROM #Section   
		) s

	INNER JOIN
		(
			SELECT
				 PK_Policy				   =  PK_Policy
				,PolicyReference		   =  PolicyReference
			FROM #Policy   
		) p
	ON p.PK_Policy = s.FK_Policy

	INNER JOIN Staging_MDS.MDS_Staging.DeclarationMapping dm   
	ON p.PolicyReference = dm.SourceSystemReference

	INNER JOIN  
		(
			SELECT
				SectionReference     = SectionReference
			FROM #Section 
		) l_s 
	ON dm.Name = l_s.SectionReference
	


	/*Update LinkedSynergyReference by joining back on the non-Synergy reference to the *policy* ref*/
	UPDATE s 
	SET LinkedSynergySection        = g.SectionReference

	FROM #Section  s

	INNER JOIN 
		(
			SELECT   
				FK_Policy			= s_nonsyn.FK_Policy
				,sectionreference	= s_syn.sectionreference
				,rownum				= ROW_NUMBER()OVER(PARTITION BY p.PolicyReference  ORDER BY s_syn.sectionreference )
			FROM  #Section  s_nonsyn  

			INNER JOIN
				(
					SELECT
						 PK_Policy			= PK_Policy
						,PolicyReference	= PolicyReference
					FROM #Policy   
				) p
			ON p.PK_Policy = s_nonsyn.FK_Policy

			INNER JOIN #Section  s_syn   
			ON s_syn.LinkedNonSynergyReference = p.PolicyReference

			GROUP BY s_nonsyn.FK_Policy, s_syn.sectionreference, p.PolicyReference
		) g
	ON g.FK_Policy = s.FK_Policy
		AND rownum = 1
	



	/*Update Project for Transaction Liability*/
	UPDATE s SET
	TransactionLiabilityProject = ISNULL(s.DQ_InsuredParty, p.InsuredParty)
	FROM #Section  s  

	INNER JOIN 
		(
			SELECT
				 PK_Policy		  =	PK_Policy
				,InsuredParty	  =	InsuredParty
			FROM #Policy   
			WHERE SourceSystem NOT IN ('BeazleyPro')
				AND MethodOfPlacementCode <> 'B'
		) p 
	ON s.FK_Policy = p.PK_Policy

	INNER JOIN ODS.TriFocus tf   
	on tf.PK_TriFocus = s.FK_TriFocus

	WHERE s.TriFocus = 'REPS & WARRANTIES'  
		or s.TriFocus =  'Intl R&W'
	


	/*Update policy keys*/
	UPDATE p SET
		FK_AccountingCalendar				= ac.PK_AccountingCalendar
		,FK_PartyBrokerNoticeOfClaim		= ISNULL(b_noc.PK_PartyBroker, 0)
		,FK_PartyBrokerServiceOfSuit		= ISNULL(b_sos.PK_PartyBroker, 0)
		,FK_QuoteFilter						= qf.PK_QuoteFilter
		,FK_ServiceCompany					= ISNULL(sco.PK_ServiceCompany, 0)
		,FK_YOA								= ISNULL(y.PK_YOA, 0)
		/*BeazleyPro and Gamechanger only - keys already populated*/
		,FK_CRMBroker						= ISNULL(p.FK_CRMBroker, 0)
		,FK_CRMProducingBroker				= ISNULL(p.FK_CRMProducingBroker, 0)
		,FK_PartyInsured					= ISNULL(p.FK_PartyInsured, 0)
		,FK_Submission						= ISNULL(p.FK_Submission, 0)

	FROM #Policy  p  


	INNER JOIN #Section  s   
	ON p.PK_Policy = s.FK_Policy

	
	INNER JOIN ODS.QuoteFilter qf  
	ON p.IsQuote = qf.IsQuote

	INNER JOIN ODS.AccountingCalendar ac   
	ON CASE
			WHEN p.SourceSystem IN ('BeazleyPro','Gamechanger', 'FDR','myBeazley','RulebookUS', 'US High Value Homeowners','USHVH')  AND ISNULL(s.Product,'') <> 'MyBeazley Broker Access PCG' THEN 'US Policy'
			ELSE 'UK Policy'
		END = ac.AccountingCalendarName

	LEFT OUTER JOIN ODS.YOA y   
	ON p.FK_YOA = y.PK_YOA


	LEFT OUTER JOIN ODS.PartyBroker b_sos   
	ON p.ServiceOfSuitBrokerNumber = b_sos.BrokerNumber

	LEFT OUTER JOIN ODS.PartyBroker b_noc   
	ON p.NoticeOfClaimBrokerNumber = b_noc.BrokerNumber

	LEFT OUTER JOIN ODS.ServiceCompany sco   
	ON sco.ServiceCompanyCode = s.ServiceCompanyCode
	


	/*Update policy keys*/
	UPDATE p SET
		FK_AccountingCalendar				= ac.PK_AccountingCalendar
	FROM #Policy  p  

	INNER JOIN #Section  s 
	ON p.PK_Policy = s.FK_Policy

	INNER JOIN ODS.AccountingCalendar ac   
	ON CASE
			WHEN p.SourceSystem IN ('BeazleyPro','Gamechanger', 'FDR','myBeazley','RulebookUS', 'US High Value Homeowners','USHVH')  AND ISNULL(s.Product,'') <> 'MyBeazley Broker Access PCG' THEN 'US Policy'
			ELSE 'UK Policy'
		END = ac.AccountingCalendarName
	
	
	/*Update all binders and lineslips to be facilities
	We need to do this explicitly because there are policies
	which have a MOP 'L' or 'B', but have no attaching decs, 
	so they won't have been picked up by the previous logic.
	Sometimes a 'family' will have more than one 'B' or 'L' MOP code. 
	In this case one of them will be treated as the facility, the rest will be treated as Decs.
	*/
	UPDATE s 
	SET IsFacility                  = 1
		,FK_Facility                = s.PK_Section

	FROM #Section  s  

	INNER JOIN #Policy  p   
	ON s.FK_Policy = p.PK_Policy

	WHERE p.MethodOfPlacementCode IN ('L', 'B','M') 
		AND s.IsDeclaration = 0
		AND s.PK_Section <> 0
	

	/* Start Binder written status */
	;WITH binder AS
		(
			SELECT 
				 BinderReference  = binder.PK_Section
				,InternalBinder = CASE 
										WHEN COUNT(DISTINCT risk.SectionReference) < 2 THEN 'Internal Unwritten Binder' 
										WHEN COUNT(DISTINCT risk.SectionReference) > 1 THEN 'Internal Written Binder'
										ELSE 'N/A'
								  END
			FROM #Section  binder  

			LEFT OUTER JOIN #Section  risk
			ON binder.PK_Section = risk.FK_Facility

			WHERE binder.IsFacility  = 1 
			  AND binder.BinderType  = '4'
			GROUP BY binder.PK_Section
		)

	-- update binders with 'Internal Unwritten Binder' or 'Internal Written Binder'
	UPDATE s SET
		FK_InternalWrittenBinderStatus = IWBS.PK_InternalWrittenBinderStatus
	FROM ODS.InternalWrittenBinderStatus IWBS  

	JOIN binder  
	ON binder.InternalBinder = IWBS.InternalWrittenBinderStatus

	JOIN #Section  s   
	ON s.PK_Section = binder.BinderReference
	


	-- update risks assigned to 'Internal Written Binders'
	UPDATE r SET
		FK_InternalWrittenBinderStatus = s.FK_InternalWrittenBinderStatus
	FROM #Section  s  
	
	JOIN #Section  r   
	
	ON s.PK_Section = r.FK_Facility

	WHERE s.FK_InternalWrittenBinderStatus = (
												SELECT 
													PK_InternalWrittenBinderStatus 
												FROM ODS.InternalWrittenBinderStatus 
												WHERE InternalWrittenBinderStatus = 'Internal Written Binder'
											 )
	

	/*Set binder type group*/
	UPDATE s 
	SET BinderTypeInternalExternal  = CASE 
											WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 'N/A'
											WHEN s.BinderType IN ('4', '5') THEN 'Internal' 
											ELSE 'External'
									   END
	FROM #Section  s  

	WHERE s.PK_Section <> 0
		

	/*Update "HasDataContractSections" flag*/
	UPDATE f 
	SET HasDataContractSections = 1

	FROM #Section  f  

	INNER JOIN #Section  d   
	ON f.PK_Section = d.FK_Facility

	INNER JOIN #Policy  p   
	ON d.FK_Policy = p.PK_Policy

	WHERE
		(
			p.SourceSystem NOT IN ('Eurobase','ClaimCenter' ,'BeazleyPro','GameChanger','Unirisx', 'CIPS','FDR','myBeazley','US High Value Homeowners')
			OR 
			(
				p.SourceSystem = 'myBeazley' 
				AND ISNULL(d.Product,'') = 'MyBeazley Broker Access PCG' 
			)
		)																			   
 
	AND f.PK_Section <> 0
	


	/*Update "HasNonEurobaseSections" flag*/
	UPDATE f 
	SET HasNonEurobaseSections = 1

	FROM #Section  f  

	INNER JOIN #Section  d   
	ON f.PK_Section = d.FK_Facility

	INNER JOIN #Policy  p   
	ON d.FK_Policy = p.PK_Policy

	WHERE p.SourceSystem <> 'Eurobase'
		AND p.SourceSystem <> 'ClaimCenter' --These don't count as they're not premium bearing
		AND f.PK_Section <> 0

	
	
	update p
	set p.FK_YOA = ISNULL( yoa.pk_yoa, 0)
		, p.YOA = ISNULL( yoa.pk_yoa, 0)

	from
		(
			select 
				 PK_Policy		=  PK_Policy
				,YOA			=  YOA
				,FK_YOA			=  FK_YOA
			from #Policy 
			where fk_yoa = 0
		) p

	inner join 
		(
			SELECT
				 InceptionDate		= InceptionDate
				,FK_Policy			= FK_Policy
			FROM #Section 
			where SectionSequenceId = 1
				and InceptionDate is not null
		) s 
	on s.FK_Policy = p.PK_Policy

	LEFT JOIN ODS.YOA yoa 
	on yoa.pk_yoa = year(s.InceptionDate)

	UPDATE s SET
		FK_YOA										= ISNULL(yoa.pk_yoa, 0)
		,FK_CRMBroker								= p.FK_CRMBroker

	FROM #Section  s  

	INNER JOIN #Policy  p   
	ON s.FK_Policy = p.PK_Policy
	
	LEFT JOIN ODS.YOA yoa 
	on yoa.pk_yoa = p.FK_YOA


	
	UPDATE s 
	SET DQ_FK_YOA									= ISNULL(yoa.PK_YOA, 0)

	FROM #Section  s  

	INNER JOIN	ODS.YOA yoa   
	ON s.DQ_YOA = yoa.PK_YOA

	

		


	UPDATE s 
	SET DQ_FK_YOA									= ISNULL(yoa.PK_YOA, 0)

	FROM #Section  s  

	INNER JOIN	ODS.YOA yoa   
	ON s.FK_YOA = yoa.PK_YOA
	
	WHERE ISNULL(s.DQ_FK_YOA, 0) = 0



	
	/* Update FK_YOA and DQ_FK_YOA for Section table*/
	UPDATE sec 
	SET fk_yoa	= binderpol.fk_yoa
		,DQ_FK_YOA	= binderpol.fk_yoa
	FROM #Section  sec   

	INNER JOIN #Policy  pol 
	ON pol.PK_Policy = sec.FK_Policy 

	INNER JOIN #Section  bindersec   
	ON bindersec.PK_Section = sec.FK_Facility 

	INNER JOIN #Policy  binderpol   
	ON binderpol.PK_Policy = bindersec.FK_Policy 
		AND binderpol.SourceSystem <> 'N/A'
	
	--00:00:20  3897388




	/* Update FK_YOA and DQ_FK_YOA for Policy table*/
	UPDATE pol 
	SET fk_yoa	= binderpol.fk_yoa

	FROM  #Policy  pol  

	INNER JOIN #Section  sec  
	ON pol.PK_Policy = sec.FK_Policy 

	INNER JOIN #Section  bindersec   
	ON bindersec.PK_Section = sec.FK_Facility 

	INNER JOIN #Policy  binderpol   
	ON binderpol.PK_Policy = bindersec.FK_Policy 
		AND binderpol.SourceSystem <> 'N/A'

	WHERE sec.SectionSequenceId = 1
	AND ISNULL(binderpol.fk_yoa, 0 ) <> 0
	--and isnull(pol.fk_yoa, 0) = 0

	
	UPDATE s SET
	ContractCertaintyPreBindOnTime      = CASE
											WHEN s.ContractCertaintyPreBindComplete = 0 THEN 0
											WHEN CASE WHEN p.SourceSystem IN ('Eurobase','Unirisx') THEN s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday - 1 
													  ELSE s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday 
												 END  > 0 THEN 0
											ELSE 1
										  END
	,ContractCertaintyPostBindOnTime    = CASE
											WHEN ISNULL(s.ContractCertaintyPostBindComplete,0) = 0 THEN 0
											WHEN Utility.udf_LesserOf(ISNULL(s.DaysBetweenQBAndCCCCDateOrToday,0), ISNULL(s.DaysBetweenQBAndCCFCDateOrToday,0)) > 21 THEN 0
											ELSE 1
										  END
	,CarrierIndicator					= CASE																
										--WHEN p.SourceSystem IN ('BeazleyPro', 'GameChanger') THEN s.CarrierIndicator --BI-5144											
										WHEN p.SourceSystem = 'BeazleyPro' THEN s.CarrierIndicator											
										WHEN p.SourceSystem = 'GameChanger' THEN CASE											
																			WHEN LEFT(p.PolicyReference,1) = 'V' THEN 'BICI'
																			WHEN LEFT(p.PolicyReference,1) = 'W' AND s.FK_YOA <= 2023 THEN 'BUSA'
																			WHEN LEFT(p.PolicyReference,1) = 'W' AND s.FK_YOA > 2023 THEN 'BUSB'
																			WHEN LEFT(p.PolicyReference,1) = 'C' THEN 'BAIC'
																			WHEN LEFT(p.PolicyReference,1) = 'D' THEN 'BESI'					
															END						
																					
										ELSE											
											CASE WHEN s.TriFocus LIKE 'BICI%' THEN 'BICI'										
											WHEN s.FK_YOA > 2023 AND s.TriFocus LIKE 'BUSA%' THEN 'BUSB'										
											WHEN s.FK_YOA  <= 2023 AND (s.TriFocus LIKE 'BUSA%' OR s.TriFocus LIKE 'FS Core%') THEN 'BUSA'										
											WHEN s.TriFocus LIKE 'BESI%' THEN 'BESI'										
											ELSE 'Non US carrier'										
										END
										END
	
	FROM 
		(
			SELECT
				 FK_Policy									   = FK_Policy
				,ContractCertaintyPreBindOnTime				   = ContractCertaintyPreBindOnTime
				,ContractCertaintyPostBindOnTime			   = ContractCertaintyPostBindOnTime
				,CarrierIndicator							   = CarrierIndicator
				,ContractCertaintyPostBindComplete			   = ContractCertaintyPostBindComplete
				,DaysBetweenQBAndCCCCDateOrToday			   = DaysBetweenQBAndCCCCDateOrToday
				,DaysBetweenQBAndCCPCOrCCPBSDateOrToday		   = DaysBetweenQBAndCCPCOrCCPBSDateOrToday
				,ContractCertaintyPreBindComplete			   = ContractCertaintyPreBindComplete
				,DaysBetweenQBAndCCFCDateOrToday			   = DaysBetweenQBAndCCFCDateOrToday
				,FK_UnderwritingPlatform					   = FK_UnderwritingPlatform
				,FK_TriFocus								   = FK_TriFocus
				,TriFocus									   = TriFocus
				,UnderwritingPlatformCode					   = UnderwritingPlatformCode
				,FK_YOA										   = FK_YOA
			FROM #Section    
		) s

	INNER JOIN 
		(
			SELECT						
				 PK_Policy				=  PK_Policy
				,PolicyReference		=  PolicyReference
				,SourceSystem			=  SourceSystem
			FROM #Policy    
		) p 
	ON s.FK_Policy = p.PK_Policy
	


	/*Moved update for UnderwritingPlatformCode from Staging_Delta to use the latest version of CarrierIndicator*/
	UPDATE s
	SET UnderwritingPlatformCode  =  CASE WHEN CarrierIndicator IN ('BUSA','BUSB') THEN 'SCPY'
																		WHEN CarrierIndicator IN ('BICI','BAIC','BESI') THEN CarrierIndicator  
																		ELSE CASE 
																				WHEN s.SourceSystem IN('Eurobase', 'Unirisx', 'myBeazley', 'Gamechanger', 'BeazleyPro', 'FDR', 'CIPS', 'Acturis')  THEN s.UnderwritingPlatformCode
																				WHEN s.SourceSystem = 'StagingDataContract' and s.OriginatingSourceSystem = 'myBeazley' THEN 'SCPY'
																				WHEN s.SourceSystem = 'USHVH' and s.trifocus like 'BUSA%' THEN 'SCPY'
																				WHEN s.SourceSystem = 'USHVH' and s.trifocus like 'BESI%' THEN 'BESI'
																			  ELSE 'SYND'
																	END
																  END
	FROM #Section  s

	UPDATE s
	SET FK_UnderwritingPlatform			= ISNULL(up.PK_UnderwritingPlatform, 0)	
	,IsBID								= ISNULL(up.IsBID, 0)	
	FROM #Section s
	LEFT OUTER JOIN	ODS.UnderwritingPlatform up   
	ON up.UnderwritingPlatformCode = s.UnderwritingPlatformCode

	/* MOVED these two updates from -Update policy keys- from above as the UnderwritingPlatformCode update was moved from Staging_delta to this procedure */
	UPDATE p SET
		FK_UnderwritingPlatform			= ISNULL(up.PK_UnderwritingPlatform, 0)
		,IsBID							= ISNULL(up.IsBID, 0)

	FROM #Policy  p  

	LEFT OUTER JOIN 
		( 
			SELECT 
				PolicyReference			= s1.PolicyReference
				, UnderwritingPlatformCode	= CASE 
													WHEN (MAX(s1.UnderwritingPlatformCode) OVER (PARTITION BY s1.PolicyReference ) <> MIN(s1.UnderwritingPlatformCode) OVER (PARTITION BY s1.PolicyReference )) 

					 								THEN 'MULTI' 

													ELSE s1.UnderwritingPlatformCode 
					 							END
			FROM #Section  s1  
		
		) up_code 
	ON p.PolicyReference = up_code.PolicyReference

	LEFT OUTER JOIN ODS.UnderwritingPlatform up   
	ON up.UnderwritingPlatformCode = up_code.UnderwritingPlatformCode

	

	/*Set facility filter and facility type*/
	UPDATE s 
	SET
		FacilityFilter          = CASE
										WHEN s.CarrierIndicator IN ('BICI','BAIC','BESI') THEN s.CarrierIndicator
										/*Shouldn't need this but we need to pick up BUSA decs that attach to 
										non-existent binders due to a DQ issue*/
										WHEN s.CarrierIndicator in('BUSA','BUSB') AND p.SourceSystem <> 'Eurobase' THEN 'Facility'
										WHEN s.IsFacility = 1 THEN 'Facility'
										WHEN s.IsDeclaration = 1 THEN 'Facility'
										ELSE 'Non-Facility'
								  END 
		,FacilityType           = CASE 
										WHEN s.CarrierIndicator = 'BICI' AND p.SourceSystem = 'Eurobase'   THEN 'BICI Program'
										WHEN s.CarrierIndicator = 'BICI' AND p.SourceSystem <> 'Eurobase'  THEN 'BICI Original Risk'
										WHEN s.CarrierIndicator = 'BUSA' AND p.SourceSystem <> 'Eurobase'  THEN 'BUSA Original Risk'
										WHEN s.CarrierIndicator = 'BUSB' AND p.SourceSystem <> 'Eurobase' THEN 'BUSB Original Risk'
										WHEN s.CarrierIndicator = 'BESI' AND p.SourceSystem <> 'Eurobase' THEN 'BESI Original Risk'
										WHEN s.CarrierIndicator = 'BAIC' AND p.SourceSystem = 'Eurobase'   THEN 'BAIC Program'
										WHEN s.CarrierIndicator = 'BAIC' AND p.SourceSystem <> 'Eurobase'  THEN 'BAIC Original Risk'
										WHEN s.IsFacility = 1 THEN 'Facility'
										WHEN s.IsDeclaration = 1 THEN 'Declaration'
										ELSE 'Open Market'
								  END

	FROM #Section  s  

	INNER JOIN #Policy  p   
	ON s.FK_Policy = p.PK_Policy

	WHERE s.PK_Section <> 0



	/*Update Source of Business*/
	DROP TABLE IF EXISTS #SecFacBinder
	SELECT  PK_Section, FK_Facility, BinderTypeInternalExternal
	INTO #SecFacBinder
	FROM #Section   

	CREATE INDEX a ON #SecFacBinder(PK_Section)


	UPDATE s 
	SET SourceOfBusiness             = CASE
											WHEN s.CarrierIndicator IN ('BICI','BAIC','BESI') THEN s.CarrierIndicator							
											WHEN s.CarrierIndicator IN ('BUSA','BUSB') THEN 'Service Company'
											WHEN p.MethodOfPlacementCode IN ('T', 'P', 'X') THEN 'Reinsurance'
											WHEN f.BinderTypeInternalExternal = 'Internal' THEN 'Service Company'
											WHEN f.BinderTypeInternalExternal = 'External' THEN 'Lloyds Binder'
											ELSE 'Open Market'
									  END
	FROM #Section  s  

	INNER JOIN #Policy  p   
	ON s.FK_Policy = p.PK_Policy

	LEFT OUTER JOIN #SecFacBinder f   
	ON s.FK_Facility = f.PK_Section

	WHERE s.IsQuote = 0
		AND s.PK_Section <> 0

	

	
	--00:00:34	0

		/*Update Lloyds COB code & Lloyds COB*/
	UPDATE s 
	SET	LloydsClassOfBusinessCode   = COALESCE(lcbm_riskarea.LloydsClassOfBusiness_Code, lcbm_risk.LloydsClassOfBusiness_Code, lcbm_def.LloydsClassOfBusiness_Code)
		,LloydsClassOfBusiness      = CASE
											WHEN lcbm_riskarea.LloydsClassOfBusiness_Code IS NOT NULL THEN lcbm_riskarea.LloydsClassOfBusiness_Name
											WHEN lcbm_risk.LloydsClassOfBusiness_Code IS NOT NULL THEN lcbm_risk.LloydsClassOfBusiness_Name
											ELSE lcbm_def.LloydsClassOfBusiness_Name
									   END
	FROM 
		(
			SELECT
				 FK_Policy							= ss.FK_Policy					
				,LloydsClassOfBusinessCode			= ss.LloydsClassOfBusinessCode	
				,LloydsClassOfBusiness				= ss.LloydsClassOfBusiness		
				,RiskClassCode						= ss.RiskClassCode				
				,Trifocus							= tf.TriFocusName
				,AreaCode							= a.AreaCode

			FROM #Section  ss  

			INNER JOIN ODS.Trifocus tf   
			ON tf.PK_TriFocus = ss.FK_TriFocus

			INNER JOIN ODS.Area a  
			ON a.PK_Area = ss.FK_Area

		) s

	INNER JOIN 
		(
			SELECT
				 PK_Policy		= pp.PK_Policy
				,YOA			= pp.FK_YOA
			FROM #Policy  pp  
			WHERE pp.SourceSystem NOT IN ( 'Eurobase', 'Unirisx') 
		) p 
	ON s.FK_Policy = p.PK_Policy

	LEFT OUTER JOIN 
		(
			SELECT
				 TriFcocus_Name					  =	TriFcocus_Name
				,YearOfAccount					  =	YearOfAccount
				,LloydsClassOfBusiness_Code		  =	LloydsClassOfBusiness_Code
				,LloydsClassOfBusiness_Name		  =	LloydsClassOfBusiness_Name
			FROM Staging_MDS.MDS_Staging.LloydsClassOfBusinessMapping  
			WHERE RiskCode = '*' --All areas
				AND AreaCode = '*' --All risk codes
		) lcbm_def 
	ON lcbm_def.YearOfAccount = p.YOA
		AND lcbm_def.TriFcocus_Name = s.TriFocus

	LEFT OUTER JOIN 
		(
			SELECT								 
				 TriFcocus_Name					 =	TriFcocus_Name
				,RiskCode						 =	RiskCode
				,YearOfAccount					 =	YearOfAccount
				,LloydsClassOfBusiness_Code		 =	LloydsClassOfBusiness_Code
				,LloydsClassOfBusiness_Name		 =	LloydsClassOfBusiness_Name
			FROM Staging_MDS.MDS_Staging.LloydsClassOfBusinessMapping  
			WHERE AreaCode = '*' --All areas
		) lcbm_risk 
	ON lcbm_risk.YearOfAccount = p.YOA 
		AND lcbm_risk.TriFcocus_Name = s.TriFocus
		AND lcbm_risk.RiskCode = s.RiskClassCode --By risk code

	LEFT OUTER JOIN Staging_MDS.MDS_Staging.LloydsClassOfBusinessMapping lcbm_riskarea   
	ON lcbm_riskarea.YearOfAccount = p.YOA
		AND lcbm_riskarea.TriFcocus_Name = s.TriFocus 
		AND lcbm_riskarea.RiskCode = s.RiskClassCode --By risk code
		AND lcbm_riskarea.AreaCode = s.AreaCode --By area
	

	 
	/*Update linked synergy section key*/
	UPDATE s 
	SET FK_LinkedSynergySection     = syn.PK_Section

	FROM #Section  s


	LEFT JOIN #Section  syn 
	ON s.LinkedSynergySection = syn.SectionReference



	--UPDATE #Section  
	--SET   FK_Facility = 0
	--	, IsDeclaration = 0 
	--WHERE FK_Facility NOT IN 
	--						(
	--							select 
	--								PK_Section 
	--							from #Section 
	--						)

	UPDATE s
	SET   FK_Facility = 0
		, IsDeclaration = 0 
	FROM #Section s
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_Facility
	WHERE f.PK_Section IS NULL AND s.FK_Facility IS NOT NULL
	--Remove BI-12504

	--UPDATE #Section
	--SET Facility = 'N/A'
	--WHERE FK_Facility = 0
	
	--/*Update Entity fileds for forecasting*/
	update s 
			set	s.EntityGrouping = es.EntityGrouping,
				s.EntitySplit = es.EntitySplit,
				s.Entity = es.Entity,
				s.MarketPlatform = es.MarketPlatform_Code
	from		#Section  s 
	INNER JOIN	ods.UnderwritingPlatform up 
			ON	s.FK_UnderwritingPlatform = up.PK_UnderwritingPlatform
	INNER JOIN	staging_mds.MDS_Staging.EntitySplits ES 
			ON	s.CarrierIndicator = es.CarrierIndicator
			    AND up.UnderwritingPlatformName = ISNULL(es.UnderwritingPlatform , 'N/A')
				AND (
					CASE WHEN (es.OfficeLocation IS NOT NULL OR es.CarrierIndicator = 'Non US carrier') THEN ISNULL(es.OfficeLocation,'') 
						 ELSE ISNULL(s.BeazleyOfficeLocation,'') 
				     END = ISNULL(s.BeazleyOfficeLocation,'') 
				)



--BI9440
	UPDATE #Section   
	SET    [TermsOfTradeExpired] = CASE
									WHEN DATEDIFF(DAY, TermsOfTradeDate, GETDATE()) > 0 THEN 1
									ELSE 0
									 END,
		   [DaysBetweenQBAndCCCCDateOrToday]         	       = CASE
															WHEN SourceSystem = 'FDR' THEN CASE
																									WHEN IsBreachResponseDummy <> 0 THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())       
																									ELSE DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyControlsCompliantDate, GETDATE()))																	   
																								END	
															ELSE CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())
																	ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyControlsCompliantDate, GETDATE()))   END
																END
														END,
			[DaysBetweenQBAndCCFCDateOrToday]         	       = CASE
															WHEN SourceSystem = 'FDR' THEN CASE
																									WHEN IsBreachResponseDummy <> 0 THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())        
																									ELSE DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyFullyCompliantDate, GETDATE()))																		   
																								END											
															ELSE CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())
																	ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyFullyCompliantDate, GETDATE())) END
																END 
														END,
			[DaysBetweenQBAndCCPCDateOrToday]         	       = CASE 
															WHEN SourceSystem = 'FDR' THEN CASE
																									WHEN IsBreachResponseDummy <> 0 THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())        
																									ELSE DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyPrimaryCompleteDate, GETDATE()))																		   
																								END
															ELSE CASE WHEN IsBreachResponseDummy IS NULL THEN DATEDIFF(DAY, QuoteOrBindDate, GETDATE())
																		ELSE CASE WHEN IsBreachResponseDummy = 0 THEN DATEDIFF(DAY, QuoteOrBindDate,ISNULL(ContractCertaintyPrimaryCompleteDate, GETDATE())) END
																END 
														END,
			[DaysBetweenQBAndCCPCOrCCPBSDateOrToday]  	       = CASE 
															WHEN SourceSystem = 'FDR' THEN CASE
																									WHEN IsBreachResponseDummy <> 0 THEN NULL 
																									ELSE DATEDIFF(DAY, QuoteOrBindDate,ISNULL(Utility.udf_EarlierDate(ContractCertaintyPrimaryCompleteDate,ContractCertaintyPreBindSignatureDate)    ,GETDATE()))    
																								END
															ELSE CASE
																	WHEN SourceSystem = 'StagingDataContract' THEN NULL
																	ELSE CASE 
																			WHEN IsBreachResponseDummy = 0 
																			THEN DATEDIFF(DAY, QuoteOrBindDate,
																			ISNULL(Utility.udf_EarlierDate(ContractCertaintyPrimaryCompleteDate,ContractCertaintyPreBindSignatureDate),GETDATE())) 
																		END
																END
                                                         END,
			[LiveStatus]                                       = CASE 
																	WHEN InceptionDate <= GETDATE() AND ExpiryDate > GETDATE()  THEN 'Live' 
																	WHEN (InceptionDate > GETDATE()) THEN 'To Inception' 
																	WHEN InceptionDate IS NULL OR ExpiryDate IS NULL THEN 'N/A'
																	ELSE 'Expired' 
												        END,

				 [MonthsSinceInception]                             = DATEDIFF(MONTH, InceptionDate,GETDATE()),
			 [MonthsSinceTOT]                               = DATEDIFF(MONTH, TermsOfTradeDate, GETDATE())



--BI-12715

	UPDATE s 
	SET s.FK_LinkedESGSection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_LinkedESGSection 
	WHERE f.PK_Section IS NULL AND s.FK_LinkedESGSection <> 0

	UPDATE s 
	SET s.FK_ATIAChildSection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_ATIAChildSection
	WHERE f.PK_Section IS NULL AND s.FK_ATIAChildSection IS NOT NULL

	UPDATE s 
	SET s.FK_BreachResponseParentSection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_BreachResponseParentSection
	WHERE f.PK_Section IS NULL AND s.FK_BreachResponseParentSection <> 0

	UPDATE s 
	SET s.FK_ExpiringSection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_ExpiringSection
	WHERE f.PK_Section IS NULL AND s.FK_ExpiringSection IS NOT NULL

	UPDATE s 
	SET s.FK_Facility = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_Facility
	WHERE f.PK_Section IS NULL AND s.FK_Facility <> 0

	UPDATE s 
	SET s.FK_LinkedSynergySection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_LinkedSynergySection
	WHERE f.PK_Section IS NULL AND s.FK_LinkedSynergySection IS NOT NULL

	UPDATE s 
	SET s.FK_RenewingSection = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_RenewingSection
	WHERE f.PK_Section IS NULL AND s.FK_RenewingSection IS NOT NULL

	UPDATE s 
	SET s.FK_LinkedESGBinder = 0
	FROM #Section s 
	LEFT JOIN #Section f 
	ON f.PK_Section = s.FK_LinkedESGBinder
	WHERE f.PK_Section IS NULL AND s.FK_LinkedESGBinder IS NOT NULL
	---PostProcessPolicyAndSection
UPDATE TARGET SET
 TARGET.RenewingPolicy						= SOURCE.RenewingPolicy
,TARGET.IsRenewal							= SOURCE.IsRenewal
,TARGET.FK_YOA								= SOURCE.FK_YOA
,TARGET.FK_ExpiringPolicy					= SOURCE.FK_ExpiringPolicy
,TARGET.FK_RenewingPolicy					= SOURCE.FK_RenewingPolicy
,TARGET.FK_PartyBrokerServiceOfSuit			= SOURCE.FK_PartyBrokerServiceOfSuit
,TARGET.FK_QuoteFilter						= SOURCE.FK_QuoteFilter
,TARGET.FK_CRMBroker						= SOURCE.FK_CRMBroker
,TARGET.FK_CRMProducingBroker				= SOURCE.FK_CRMProducingBroker
,TARGET.FK_PartyBrokerProducing				= SOURCE.FK_PartyBrokerProducing
,TARGET.FK_PartyBrokerPlacing				= SOURCE.FK_PartyBrokerPlacing
,TARGET.FK_Submission						= SOURCE.FK_Submission
,TARGET.MarKetSegmentCode					= SOURCE.MarKetSegmentCode
,TARGET.PrimarySectionBinderType			= SOURCE.PrimarySectionBinderType
,TARGET.AnySectionIsSynergy					= SOURCE.AnySectionIsSynergy
,TARGET.AnySectionIsBreachResponseDummy		= SOURCE.AnySectionIsBreachResponseDummy
,TARGET.IsRunOff							= SOURCE.IsRunOff
,TARGET.FK_AccountingCalendar				= SOURCE.FK_AccountingCalendar
,TARGET.FK_PartyBrokerNoticeOfClaim			= SOURCE.FK_PartyBrokerNoticeOfClaim
,TARGET.FK_ServiceCompany					= SOURCE.FK_ServiceCompany
,TARGET.FK_PartyInsured						= SOURCE.FK_PartyInsured
,TARGET.FK_UnderwritingPlatform				= SOURCE.FK_UnderwritingPlatform
,TARGET.IsBID								= SOURCE.IsBID
FROM Staging.Policy target
INNER JOIN  #Policy source
ON target.PK_Policy = source.PK_Policy

UPDATE TARGET SET
  Target.ProgramName									= SOURCE.ProgramName
, Target.DQ_AdditionalInsuredParty						= SOURCE.DQ_AdditionalInsuredParty
, Target.DQ_NoticeOfClaimBrokerNumber					= SOURCE.DQ_NoticeOfClaimBrokerNumber
, Target.DQ_PlacingBrokerContact						= SOURCE.DQ_PlacingBrokerContact
, Target.DQ_PlacingBrokerNumber							= SOURCE.DQ_PlacingBrokerNumber
, Target.DQ_ProducingBrokerContact						= SOURCE.DQ_ProducingBrokerContact
, Target.DQ_ProducingBrokerNumber						= SOURCE.DQ_ProducingBrokerNumber
, Target.DQ_ReinsuredParty								= SOURCE.DQ_ReinsuredParty
, Target.DQ_ServiceOfSuitBrokerNumber					= SOURCE.DQ_ServiceOfSuitBrokerNumber
, Target.DQ_YOA											= SOURCE.DQ_YOA
, Target.Country										= SOURCE.Country
--, Target.SignedLineMultiplier            				= SOURCE.SignedLineMultiplier
--, Target.WrittenIfNotSignedLineMultiplier				= SOURCE.WrittenIfNotSignedLineMultiplier
--, Target.SignedOrderMultiplier           				= SOURCE.SignedOrderMultiplier
--, Target.IsSigned    									= SOURCE.IsSigned
, Target.RateOnLinePremiumEnteredInOriginalCCY			= SOURCE.RateOnLinePremiumEnteredInOriginalCCY
, Target.MultiYearGroupDurationMonths					= SOURCE.MultiYearGroupDurationMonths
, Target.BICICessionMultiplier							= SOURCE.BICICessionMultiplier
, Target.LinkedSynergySection							= SOURCE.LinkedSynergySection
, Target.LinkedNonSynergyReference						= SOURCE.LinkedNonSynergyReference
, Target.TransactionLiabilitySectionType				= SOURCE.TransactionLiabilitySectionType
, Target.CargoOrFreight									= SOURCE.CargoOrFreight
--, Target.TotalSignedMultiplier							= SOURCE.TotalSignedMultiplier
--, Target.WrittenIfNotSignedOrderMultiplier 				= SOURCE.WrittenIfNotSignedOrderMultiplier
--, Target.TotalWrittenIfNotSignedMultiplier				= SOURCE.TotalWrittenIfNotSignedMultiplier
--, Target.WrittenLineMultiplier             				= SOURCE.WrittenLineMultiplier
--, Target.WrittenOrderMultiplier           				= SOURCE.WrittenOrderMultiplier
--, Target.TotalWrittenMultiplier           				= SOURCE.TotalWrittenMultiplier
--, Target.LineMultiplierBandKey							= SOURCE.LineMultiplierBandKey
--, Target.LineMultiplierBand						    	= SOURCE.LineMultiplierBand
, Target.DQ_FK_PartyBrokerNoticeOfClaim					= SOURCE.DQ_FK_PartyBrokerNoticeOfClaim
, Target.DQ_FK_PartyBrokerPlacing						= SOURCE.DQ_FK_PartyBrokerPlacing
, Target.DQ_FK_PartyBrokerProducing						= SOURCE.DQ_FK_PartyBrokerProducing
, Target.DQ_FK_PartyBrokerServiceOfSuit					= SOURCE.DQ_FK_PartyBrokerServiceOfSuit
, Target.DQ_FK_YOA										= SOURCE.DQ_FK_YOA
, Target.FK_ATIAClassOfBusiness							= SOURCE.FK_ATIAClassOfBusiness
, Target.FK_Area										= SOURCE.FK_Area
, Target.FK_ClassOfBusiness								= SOURCE.FK_ClassOfBusiness
, Target.FK_ClientClassificationCode					= SOURCE.FK_ClientClassificationCode
, Target.FK_LocalCurrency								= SOURCE.FK_LocalCurrency
, Target.FK_LimitCurrency								= SOURCE.FK_LimitCurrency
, Target.FK_OriginalCurrency							= SOURCE.FK_OriginalCurrency
, Target.FK_ServiceCompany								= SOURCE.FK_ServiceCompany
, Target.FK_EnteredBy									= SOURCE.FK_EnteredBy
, Target.FK_Underwriter									= SOURCE.FK_Underwriter
, Target.FK_UnderwriterAssistantContractCertainty		= SOURCE.FK_UnderwriterAssistantContractCertainty
, Target.FK_UnderwriterContractCertainty				= SOURCE.FK_UnderwriterContractCertainty
, Target.FK_UnderwriterLargeRiskReviewer				= SOURCE.FK_UnderwriterLargeRiskReviewer
, Target.FK_MultiYearGroupDurationBand					= SOURCE.FK_MultiYearGroupDurationBand
, Target.FK_DurationBand								= SOURCE.FK_DurationBand
, Target.MonthsSinceInceptionBandKey			    	= SOURCE.MonthsSinceInceptionBandKey
, Target.MonthsSinceInceptionBand						= SOURCE.MonthsSinceInceptionBand
, Target.FK_HiddenStatusFilter							= SOURCE.FK_HiddenStatusFilter
, Target.FK_SettlementCurrency							= SOURCE.FK_SettlementCurrency
, Target.FK_QuoteFilter									= SOURCE.FK_QuoteFilter
, Target.OriginalCCYToLocalCCYRate						= SOURCE.OriginalCCYToLocalCCYRate
, Target.IsFacility										= SOURCE.IsFacility
, Target.IsDeclaration									= SOURCE.IsDeclaration
, Target.HasDataContractSections						= SOURCE.HasDataContractSections
, Target.HasNonEurobaseSections							= SOURCE.HasNonEurobaseSections
, Target.FK_Facility    								= SOURCE.FK_Facility
, Target.FK_BreachResponseParentSection					= SOURCE.FK_BreachResponseParentSection
, Target.FK_ATIAChildSection							= SOURCE.FK_ATIAChildSection
, Target.FK_LinkedESGBinder  							= SOURCE.FK_LinkedESGBinder
, Target.FK_LinkedESGTrifocus							= SOURCE.FK_LinkedESGTrifocus
, TARGET.FK_Policy										= SOURCE.FK_Policy
, TARGET.SimpleProduct									= SOURCE.SimpleProduct
, TARGET.Team 											= SOURCE.Team
, TARGET.TechnologyCoverageName 						= SOURCE.TechnologyCoverageName
, TARGET.ClassifiedAsTechnology							= SOURCE.ClassifiedAsTechnology
, TARGET.WEPMeldedRate									= SOURCE.WEPMeldedRate
, TARGET.WEPCurrentRate									= SOURCE.WEPCurrentRate
, TARGET.LimitMeldedRate								= SOURCE.LimitMeldedRate
, TARGET.RateOnLineMultiplier							= SOURCE.RateOnLineMultiplier
, TARGET.RateOnLineBandKey								= SOURCE.RateOnLineBandKey
, TARGET.RateOnLineBandName								= SOURCE.RateOnLineBandName
, TARGET.IsRenewed										= SOURCE.IsRenewed
, TARGET.IsRenewal										= SOURCE.IsRenewal
, TARGET.RenewalDueDate									= SOURCE.RenewalDueDate
, TARGET.IsBeazleyLead									= SOURCE.IsBeazleyLead
, TARGET.ExpectedPICCTransactions						= SOURCE.ExpectedPICCTransactions
, TARGET.IncludeInMunichStacking						= SOURCE.IncludeInMunichStacking
, TARGET.TransactionLiabilityProject					= SOURCE.TransactionLiabilityProject
, TARGET.FK_InternalWrittenBinderStatus					= SOURCE.FK_InternalWrittenBinderStatus
, TARGET.BinderTypeInternalExternal						= SOURCE.BinderTypeInternalExternal
, TARGET.FK_YOA											= SOURCE.FK_YOA
, TARGET.FK_CRMBroker									= SOURCE.FK_CRMBroker
, TARGET.ContractCertaintyPreBindOnTime  				= SOURCE.ContractCertaintyPreBindOnTime	
, TARGET.ContractCertaintyPostBindOnTime				= SOURCE.ContractCertaintyPostBindOnTime
, TARGET.CarrierIndicator								= SOURCE.CarrierIndicator
, TARGET.IsBID											= SOURCE.IsBID
, TARGET.FacilityFilter									= SOURCE.FacilityFilter
, TARGET.FacilityType									= SOURCE.FacilityType
--, TARGET.Facility										= SOURCE.Facility
, TARGET.SourceOfBusiness								= SOURCE.SourceOfBusiness
, TARGET.LloydsClassOfBusinessCode						= SOURCE.LloydsClassOfBusinessCode
, TARGET.LloydsClassOfBusiness							= SOURCE.LloydsClassOfBusiness
, TARGET.FK_LinkedSynergySection						= SOURCE.FK_LinkedSynergySection
, TARGET.EntityGrouping									= SOURCE.EntityGrouping
, TARGET.EntitySplit 									= SOURCE.EntitySplit
, TARGET.Entity 										= SOURCE.Entity
, TARGET.MarketPlatform									= SOURCE.MarketPlatform
, TARGET.TermsOfTradeExpired							= SOURCE.TermsOfTradeExpired
, TARGET.DaysBetweenQBAndCCPCDateOrToday				= SOURCE.DaysBetweenQBAndCCPCDateOrToday
, TARGET.LiveStatus										= SOURCE.LiveStatus
, TARGET.MonthsSinceTOT									= SOURCE.MonthsSinceTOT
--uitate
, TARGET.OriginalCCYToSettlementCCYRate					= SOURCE.OriginalCCYToSettlementCCYRate
, TARGET.FK_UnderwritingPlatform						= SOURCE.FK_UnderwritingPlatform
, TARGET.FK_ExpiringSection								= SOURCE.FK_ExpiringSection
, TARGET.ExpiringSection								= SOURCE.ExpiringSection
, TARGET.FK_RenewingSection								= SOURCE.FK_RenewingSection
, TARGET.RenewingSection								= SOURCE.RenewingSection
, TARGET.LimitCCYToSettlementCCYRateCurrent				= SOURCE.LimitCCYToSettlementCCYRateCurrent
, TARGET.LimitCCYToSettlementCCYRateMelded				= SOURCE.LimitCCYToSettlementCCYRateMelded
, TARGET.LeaderPseudonym							    = SOURCE.LeaderPseudonym
, TARGET.LeaderName										= SOURCE.LeaderName
, TARGET.FK_LinkedESGSection							= SOURCE.FK_LinkedESGSection
, TARGET.LinkedESGSectionReference						= SOURCE.LinkedESGSectionReference
, TARGET.UnderwritingPlatformCode						= SOURCE.UnderwritingPlatformCode
, TARGET.DaysBetweenQBAndCCCCDateOrToday				= SOURCE.DaysBetweenQBAndCCCCDateOrToday
, TARGET.DaysBetweenQBAndCCFCDateOrToday				= SOURCE.DaysBetweenQBAndCCFCDateOrToday
, TARGET.DaysBetweenQBAndCCPCOrCCPBSDateOrToday			= SOURCE.DaysBetweenQBAndCCPCOrCCPBSDateOrToday
, TARGET.MonthsSinceInception							= SOURCE.MonthsSinceInception
FROM
Staging.Section target
INNER JOIN #Section source
ON target.PK_Section = source.PK_Section

DROP TABLE IF EXISTS #Section
DROP TABLE IF EXISTS #Policy
END
GO

