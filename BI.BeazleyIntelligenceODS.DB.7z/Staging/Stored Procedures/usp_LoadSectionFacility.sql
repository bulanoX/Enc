﻿CREATE PROCEDURE staging.usp_LoadSectionFacility
AS BEGIN

--BI-12388 start
	WITH cte as (
				SELECT  s.PK_Section
					   ,s.SectionReference
					   ,s.Facility
					   ,s.FK_Facility
					   ,s.FK_TriFocus
					   ,SectionTrifocus = s.TriFocus
					   ,FacilityTrifocus = f.TriFocus
				FROM Staging.Section s
				INNER JOIN Staging.Section f ON s.Facility = f.SectionReference
				WHERE   (s.TriFocus LIKE '%BBR Services%' or s.TriFocus LIKE '%BBR Srv%')
							and s.TriFocus <> f.TriFocus
				)

	UPDATE s
	SET  Facility    = fac.SectionReference
	    ,FK_Facility = fac.PK_Section
	FROM cte ct
	INNER JOIN Staging.Section s ON ct.PK_Section = s.PK_Section
	INNER JOIN Staging.Section f ON s.Facility = f.SectionReference
	INNER JOIN Staging.Policy pf ON pf.PolicyReference = f.PolicyReference
	INNER JOIN Staging.Section fac ON fac.PolicyReference = pf.PolicyReference
	WHERE
		   (fac.TriFocus LIKE '%BBR Services%' or fac.TriFocus LIKE '%BBR Srv%')
		   and s.Trifocus = fac.TriFocus
		   and SUBSTRING( s.Facility,1,10) =  SUBSTRING(  fac.SectionReference,1,10)


--BI-12388 end


	DROP TABLE IF EXISTS #FacilityLink

	CREATE TABLE #FacilityLink
	(
		FacilityReference       varchar(255)    NOT NULL
		,DeclarationReference   varchar(255)    NOT NULL
		PRIMARY KEY (DeclarationReference)
	)

	--Add Eurobase link - needed for ClaimCenter; Add also Unirisx and Gamechanger
	INSERT INTO #FacilityLink
	(
		DeclarationReference
		,FacilityReference
	)
	SELECT DISTINCT
		DeclarationReference    = s.SectionReference
		,FacilityReference		= s.Facility
	FROM Staging.Section s
	WHERE s.Facility IS NOT NULL

	/*Eurobase reference changes*/
	DROP TABLE IF EXISTS #ProcessReferenceChanges

	CREATE TABLE #ProcessReferenceChanges
	(
		OldReference          varchar(255)  NOT NULL
		,UltimateNewReference varchar(255)  NOT NULL
		,UltimateDepth        int           NOT NULL
		,CyclesDetected       bit           NOT NULL
		,PRIMARY KEY(OldReference)
	)

	INSERT INTO #ProcessReferenceChanges
	(
		OldReference
		,UltimateNewReference
		,UltimateDepth
		,CyclesDetected
	)
	SELECT 
		OldReference                    = x.OldReference
		,UltimateNewReference           = x.UltimateNewReference
		,UltimateDepth                  = x.UltimateDepth
		,CyclesDetected                 = x.CyclesDetected
	FROM Utility.udf_ProcessReferenceChanges() x 


	/*Add BeazleyPro links - join through the reference log for changes*/
	INSERT INTO #FacilityLink
	(
		DeclarationReference
		,FacilityReference
	)
	SELECT DISTINCT
		DeclarationReference    = s.SectionReference
		,FacilityReference      = ISNULL(rc.UltimateNewReference, s.Facility)
	FROM Staging.section s

	LEFT OUTER JOIN #ProcessReferenceChanges rc 
	ON s.Facility = rc.OldReference

	WHERE  s.SourceSystem = 'BeazleyPro'
	AND EXISTS
			(
				SELECT 
					1
				FROM Staging.Section s1 
				WHERE s1.SectionReference = ISNULL(rc.UltimateNewReference, s.Facility)
			)
		AND s.SectionReference NOT IN (SELECT DeclarationReference FROM #FacilityLink)
	  

	/*Add data contract links*/
	INSERT INTO #FacilityLink
	(
		DeclarationReference
		,FacilityReference
	)
	SELECT DISTINCT
		DeclarationReference    = s.SectionReference
		,FacilityReference      = ISNULL(rc.UltimateNewReference, s.FacilityReference)
	FROM Staging_DataContract.DataContract_Staging.Section s

	INNER JOIN Staging_DataContract.DataContract_Staging.Policy p
	ON s.FK_Policy = p.PK_Policy

	LEFT OUTER JOIN #ProcessReferenceChanges rc 
	ON s.FacilityReference = rc.OldReference

	LEFT OUTER JOIN #FacilityLink fl1 
	ON fl1.DeclarationReference = s.SectionReference

	LEFT OUTER JOIN Staging.Section s1 
	ON s1.SectionReference = ISNULL(rc.UltimateNewReference, s.FacilityReference)

	WHERE fl1.DeclarationReference IS NULL
	AND s1.SectionReference IS NOT NULL
	AND s.SourceSystemName NOT IN ('FDR', 'USHVH', 'US High Value Homeowners')
	AND ( (p.SourceSystemFriendlyName = 'EazyPro' AND p.YearOfAccount < 2017) OR (p.SourceSystemFriendlyName != 'EazyPro') )
	
	
	/*Add ClaimCenter links*/
	INSERT INTO #FacilityLink

	(
		DeclarationReference
		,FacilityReference
	)
	select 
		declarationreference,
		FacilityReference 
	from
		(
			SELECT --DISTINCT
				DeclarationReference    = s.SectionReference
				,FacilityReference      = s_b.SectionReference
				,RowNo = Row_number() over (partition by s.sectionreference order by s_b.sectionreference) 

			FROM Staging.Section s

			INNER HASH JOIN 
						(
							SELECT
								PolicyReference
							FROM Staging.Policy 
							WHERE SourceSystem = 'ClaimCenter'
						) p 
			ON s.PolicyReference = p.PolicyReference
		
			INNER HASH JOIN Staging.ClaimCenter_Claims cp 
			ON p.PolicyReference = cp.PolicyNumber

			LEFT JOIN #ProcessReferenceChanges pfc 
			ON cp.BinderReference = pfc.OldReference

			INNER JOIN Staging.Section s_b 
			ON ISNULL(pfc.UltimateNewReference, cp.BinderReference) = s_b.SectionReference --We only want binders that exist in Eurobase
		
			LEFT OUTER JOIN #FacilityLink fl1 
			ON fl1.DeclarationReference = s.SectionReference

			WHERE fl1.DeclarationReference IS NULL
		) as t
	where rowno = 1


	/*Sometimes Eurobase or ClaimCenter may give us a multi-level tree for facility-declaration.
	We flatten these out so that every dec is attached to the topmost parent in the hierarchy.
	Otherwise the check constraint on ODS.Section will be violated (the one that enforces that a record can't
	be both a facility and a dec). We do this to ensure that the facility - declaration tree is never more than 
	one level deep. If the check constraint is removed, and the one-level rule is violated, the cube may fail 
	in subtle ways*/

	DROP TABLE IF EXISTS #CTEFacTree

	CREATE TABLE #CTEFacTree
	(
		 UltimateParent         varchar(255) NOT NULL
		,ChildPolicyReference   varchar(255) NOT NULL
		,ParentPolicyReference  varchar(255) NOT NULL
		,ParentLevel            int          NOT NULL
	)

	;WITH CTEFacilityTree 
	AS
	(
		/*Anchor members*/
		SELECT TOP (2147483647)
			UltimateParent              = f.FacilityReference 
			,ChildPolicyReference       = f.DeclarationReference
			,ParentPolicyReference      = f.FacilityReference
			,ParentLevel                = 1 
		FROM #FacilityLink f
		-- WHERE NOT EXISTS (SELECT 1 FROM #FacilityLink f1 WHERE f.FacilityReference = f1.DeclarationReference)
		LEFT OUTER JOIN #FacilityLink f1
		ON f.FacilityReference = f1.DeclarationReference
	
		WHERE f1.DeclarationReference IS NULL
   
		UNION ALL
    
		/*Recursive members*/
		SELECT
			UltimateParent              = ft.UltimateParent 
			,ChildPolicyReference       = f.DeclarationReference 
			,ParentPolicyReference      = f.FacilityReference 
			,ParentLevel                = ft.ParentLevel + 1 
		FROM CTEFacilityTree ft
    
		INNER JOIN #FacilityLink f 
		ON ft.ChildPolicyReference = f.FacilityReference
	)

	INSERT INTO #CTEFacTree
	(
		 UltimateParent
		,ChildPolicyReference
		,ParentPolicyReference
		,ParentLevel
	)
	SELECT
		 UltimateParent
		,ChildPolicyReference
		,ParentPolicyReference
		,ParentLevel
	FROM CTEFacilityTree

	UPDATE f 
	SET FacilityReference = ft.UltimateParent

	FROM #FacilityLink f

	INNER JOIN #CTEFacTree ft 
	ON f.DeclarationReference = ft.ChildPolicyReference

	WHERE ft.ParentLevel > 1

	/*Update facility reference*/
	UPDATE s 
	SET Facility = fl.FacilityReference

	FROM Staging.Section s

	INNER JOIN #FacilityLink fl 
	ON s.SectionReference = fl.DeclarationReference

	--Trifocus and Facility are used in the very next stored procedure, therefore I cannot move them to Post Process as should be.
	UPDATE s 
	SET FK_TriFocus								= ISNULL(tf.PK_TriFocus, 0)
		
	FROM Staging.Section s WITH(NOLOCK)

	LEFT OUTER JOIN	ODS.TriFocus tf  WITH(NOLOCK)
	ON s.TriFocus = tf.TriFocusName
	

	UPDATE s 
	SET	ExpectedLossRatioMultiplier =  s.BenchmarkMultiplier * 
									CASE 
									WHEN (s.FK_YOA < 2022) AND t.trifocusname = 'War' THEN 0.25
									WHEN (s.FK_YOA < 2020) AND t.trifocusname = 'Cat' THEN 0.5
									ELSE  t.LongTermBenchmarkMultiplier
									END
	
	FROM Staging.Section s

	INNER JOIN ODS.TriFocus t 
	ON s.FK_TriFocus = t.PK_TriFocus
END