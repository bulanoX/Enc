﻿
CREATE PROCEDURE [Staging].[usp_LoadSection_Claims_Delta]
As
BEGIN
	DECLARE @LastAuditDate DATETIME2(7)

	SELECT 
		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM Staging.Section

	SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


	TRUNCATE TABLE Staging.Section_Claims

	INSERT INTO Staging.Section_Claims
	(
		SourceSystem						
		,SectionReference					
		,SectionDisplayReference			
		,PolicyReference					
		,AgressoReference					
		,ProductIsMultiTransactional		
		,ClassOfBusinessCode				
		,ContractCertaintyStatus			
		,ContractCertaintyStatusSortOrder	
		,EstimatedSigningMultiplier			
		,ExpiryDate							
		,ExternalAcquisitionCostMultiplier	
		,HiddenStatusFilter					
		,InceptionDate						
		,IsQuote							
		,LimitCCY							
		,LimitQualifier						
		,OriginalCCY						
		,PrimaryOrExcess					
		,SettlementCCY						
		,SignedOrderMultiplier				
		,UnderwritingPlatformCode			
		,WrittenOrderMultiplier				
		,FK_Underwriter						
		,RowId								
		,DurationMonths						
		,LiveStatus							
		,TriFocusCode
		,WepBasis
	)
	SELECT                                   
		SourceSystem							= 'ClaimCenter'
		,SectionReference						= case when coveragename <> 'UNirisx' then  ISNULL(ce.SectionReference, p.PolicyNumber) else p.Policynumber + '-01' end--ISNULL(ce.SectionReference, p.PolicyNumber)
		,SectionDisplayReference				= case when coveragename <> 'UNirisx' then  ISNULL(ce.SectionReference, p.PolicyNumber) else p.Policynumber + '-01' end--ISNULL(ce.SectionReference, p.PolicyNumber)												  
		,PolicyReference						= p.PolicyNumber
		,AgressoReference						= p.PolicyNumber
		,ProductIsMultiTransactional			= 0	
		,ClassOfBusinessCode					= ce.ClassOfBusiness--???---ccp.SectionCOBCode_ext
		,ContractCertaintyStatus				= 'No Status'
		,ContractCertaintyStatusSortOrder		= 6
		,EstimatedSigningMultiplier				= 1
		,ExpiryDate								= ce.PolicyExpire
		,ExternalAcquisitionCostMultiplier		= 0
		,HiddenStatusFilter						= 'Show Regular Statuses'
		,InceptionDate							= ce.PolicyInception
		,IsQuote								= 0
		,LimitCCY								= 'USD'
		,LimitQualifier							= 'AGG' --In the absence of a real value, we default to "AGG" for inclusion in Munich stacking
		,OriginalCCY							= 'USD'
		,PrimaryOrExcess						= 'Primary' 
		,SettlementCCY							= 'USD'
		,SignedOrderMultiplier					= 1
		,UnderwritingPlatformCode				= 'SYND'
		,WrittenOrderMultiplier					= 1
		,FK_Underwriter							= 0--ods_u.PK_Underwriter				  
		,RowId									= ROW_NUMBER() OVER(PARTITION BY p.PolicyNumber ORDER BY ISNULL(ce.SectionReference, p.PolicyNumber))
		,DurationMonths							= CASE
														WHEN ce.PolicyInception > ce.PolicyExpire THEN NULL 
														WHEN DATEDIFF(DAY, ce.PolicyInception, ce.PolicyExpire) < 16 THEN 1
														ELSE ROUND(DATEDIFF(DAY, ce.PolicyInception, ce.PolicyExpire) / 30.5, 0)
													END
		,LiveStatus								= CASE 
														WHEN ce.PolicyInception <= GETDATE() AND ce.PolicyExpire > GETDATE()  THEN 'Live' 
														WHEN (ce.PolicyInception > GETDATE()) THEN 'To Inception' 
														WHEN ce.PolicyInception IS NULL OR ce.PolicyExpire IS NULL THEN 'N/A'
														ELSE 'Expired' 
													END
		,TriFocusCode							= ce.TrifocusCode
		,WEPBasis								= 'Booked Premium'
	

	FROM Staging.Policy_Claims p
	
	INNER JOIN BeazleyIntelligenceDataContract.outbound.vw_Claim c 
	ON c.PolicyNumber = p.PolicyNumber
	
	LEFT JOIN 
		(
			SELECT 
				ClaimSourceId					= ce.ClaimSourceId
				,ClaimExposureSourceId			= ce.ClaimExposureSourceId
				,TriFocusCode					= ce.TriFocusCode
				,ClassOfBusiness				= ce.ClassOfBusiness
				,SectionReference				= cee.PrimarySectionName
				,PolicyInception                = ce.PolicyInception
				,PolicyExpire                   = ce.PolicyExpire
				,CoverageName					= ce.CoverageName
				,RowId							= ROW_NUMBER()OVER (PARTITION BY cee.PrimarySectionName ORDER BY  ce.AuditCreateDateTime)
				,AuditCreateDateTime_CE			= ce.AuditCreateDatetime
				,AuditCreateDateTime_CEE		= cee.AuditCreateDatetime
				,AuditModifyDateTime_CE			= ce.AuditModifyDatetime
				,AuditModifyDateTime_CEE		= cee.AuditModifyDatetime
			FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce
			
			INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee
			ON ce.ClaimSourceId = cee.ClaimSourceId 
				AND ce.ClaimExposureSourceId = cee.ClaimExposureSourceId
				AND cee.SourceSystem = ce.SourceSystem
				
			WHERE ce.SourceSystem ='ClaimCenter' 
				
		) ce
	ON ce.ClaimSourceId = c.ClaimSourceId
			
	WHERE c.SourceSystem ='ClaimCenter'
		AND 
			(
				ISNULL(c.AuditModifyDatetime, c.AuditCreateDateTime) >= @LastAuditDate
				OR
				ISNULL(ce.AuditModifyDateTime_CE, ce.AuditCreateDateTime_CE) >= @LastAuditDate
				OR
				ISNULL(ce.AuditModifyDateTime_CEE, ce.AuditCreateDateTime_CEE) >= @LastAuditDate
			)
		AND ce.RowId = 1
		--and ce.rowid = 1
		AND ISNULL(c.IsRetired, 0) = 0
END