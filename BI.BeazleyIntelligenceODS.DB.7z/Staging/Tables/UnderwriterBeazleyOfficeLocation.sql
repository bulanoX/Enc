﻿CREATE TABLE [Staging].[UnderwriterBeazleyOfficeLocation] (
    [Implementation]        VARCHAR (255) NOT NULL,
    [FirstName]             VARCHAR (255) NOT NULL,
    [LastName]              VARCHAR (255) NOT NULL,
    [UserName]              VARCHAR (255) NULL,
    [BeazleyOfficeLocation] VARCHAR (255) NOT NULL,
    [AuditTimestamp]        DATETIME      CONSTRAINT [DEF_UnderwriterBeazleyOfficeLocation_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]             VARCHAR (255) CONSTRAINT [DEF_UnderwriterBeazleyOfficeLocation_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_UnderwriterBeazleyOfficeLocation_1] PRIMARY KEY CLUSTERED ([FirstName] ASC, [LastName] ASC) WITH (FILLFACTOR = 90)
);

