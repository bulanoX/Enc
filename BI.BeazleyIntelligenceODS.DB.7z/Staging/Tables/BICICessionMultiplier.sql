﻿CREATE TABLE [Staging].[BICICessionMultiplier] (
    [AgressoReference]          VARCHAR (255)    NOT NULL,
    [CessionMultiplier]         NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]       datetime2(7)     NULL,
	[AuditCreateDateTime]       datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]        nvarchar(255)    NULL,
    PRIMARY KEY CLUSTERED ([AgressoReference] ASC) WITH (FILLFACTOR = 90)
);

