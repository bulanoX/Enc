﻿CREATE TABLE [Staging].[BinderBeazleyOfficeLocation] (
    [BinderReferenceLeftSix] VARCHAR (255) NOT NULL,
    [BeazleyOfficeLocation]  VARCHAR (255) NOT NULL,
    [AuditTimestamp]         DATETIME      NOT NULL,
    [AuditUser]              VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_BinderReferenceLeftSix] PRIMARY KEY NONCLUSTERED ([BinderReferenceLeftSix] ASC) WITH (FILLFACTOR = 90)
);

