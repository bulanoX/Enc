﻿CREATE TABLE [Staging].[ClaimCenter_Claims] (
    [PolicyNumber]    NVARCHAR (255) NULL,
    [BinderReference] NVARCHAR (255) NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDateTime] DATETIME2 (7)  NULL,
    [AuditModifyDetails]  NVARCHAR (255) NULL
);

