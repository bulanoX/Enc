﻿CREATE TABLE [Staging].[DQ_Submission] (
    [SubmissionSourceId]        VARCHAR (255) NOT NULL,
    [SubmissionStatus]          VARCHAR (255) NOT NULL,
    [SubmissionDate]            DATETIME      NOT NULL,
    [ClearedDate]               DATETIME      NULL,
    [WasMigrated]               BIT           NOT NULL,
    [MarketSegment]             VARCHAR (255) NULL,
    [MarketSegmentCode]         VARCHAR (255) NULL,
    [RiskStatus]                VARCHAR (255) NULL,
    [ClearedProductName]        VARCHAR (255) NULL,
    [FK_CRMBroker]              BIGINT        NOT NULL,
    [FK_PartyInsured]           BIGINT        NOT NULL,
    [FK_Underwriter]            BIGINT        NOT NULL,
    [FK_ClearedClassOfBusiness] BIGINT        NOT NULL,
    [FK_ExpiringSubmission]     BIGINT        NULL,
    [SourceSystemName]          VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]       datetime2(7)  NULL,
	[AuditCreateDateTime]       datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]        nvarchar(255) NULL
);

