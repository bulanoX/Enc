﻿CREATE TABLE [Staging].[LPSOAcquisitionCostBasis] (
    [FK_LPSOTransaction]        BIGINT           NOT NULL,
    [FK_AcquisitionCostBasis]   BIGINT           NOT NULL,
    [AcquisitionCostMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]       datetime2(7)     NULL,
    [AuditCreateDateTime]       datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]        nvarchar(255)    NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_Stg_LPSOAcquisitionCostBasis]
    ON [Staging].[LPSOAcquisitionCostBasis]([FK_LPSOTransaction] ASC)
    INCLUDE([FK_AcquisitionCostBasis]) WITH (FILLFACTOR = 90);

