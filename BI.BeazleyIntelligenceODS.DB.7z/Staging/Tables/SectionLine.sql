CREATE TABLE [Staging].[SectionLine] (
    [SectionReference]                 VARCHAR (255)    NOT NULL,
    [SyndicateNumber]                  INT              NOT NULL,
    [WrittenLineMultiplier]            NUMERIC (19, 12) NULL,
    [SignedLineMultiplier]             NUMERIC (19, 12) NULL,
    [WrittenIfNotSignedLineMultiplier] NUMERIC (19, 12) NULL,
    [OfTotalMultiplier]                NUMERIC (19, 12) NULL,
    [AuditModifyDateTime]              datetime2(7)     NULL,
    [AuditCreateDateTime]              datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]               nvarchar(255)    NULL,
    PRIMARY KEY NONCLUSTERED ([SectionReference] ASC, [SyndicateNumber] ASC) WITH (FILLFACTOR = 90),
    CHECK ([SignedLineMultiplier]<>(0))
);

