﻿CREATE TABLE [Staging].[BordereauData] (
    [ContractNumber]      VARCHAR (255)  NULL,
    [BordereauFormat]     VARCHAR (255)  NULL,
    [CoverholderName]     VARCHAR (255)  NULL,
    [BordereauEventID]    INT            NULL,
    [CertificateNumber]   VARCHAR (255)  NULL,
    [TransactionType]     VARCHAR (255)  NULL,
    [DateInception]       DATETIME       NULL,
    [DateExpiry]          DATETIME       NULL,
    [I3048]               INT            NULL,
    [BordereauHeaderId]   VARCHAR (255)  NULL,
    [AuditCreateDateTime] DATETIME2 (7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDateTime] DATETIME2 (7)  NULL,
    [AuditModifyDetails]  NVARCHAR (255) NULL
);



