﻿CREATE TABLE [Staging].[SectionLineBase] (
    [SectionReference]      VARCHAR (255) NOT NULL,
    [PolicyReference]       VARCHAR (255) NOT NULL,
    [Facility]              VARCHAR (255) NULL,
    [FK_YOA]                BIGINT        NULL,
    [SourceSystem]          VARCHAR (255) NOT NULL,
    [Trifocus]              VARCHAR (255) NULL,
    [CarrierIndicator]      VARCHAR (255) NULL,
    [AuditModifyDateTime]   datetime2(7)  NULL,
    [AuditCreateDateTime]   datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]    nvarchar(255) NULL
);

