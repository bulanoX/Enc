﻿CREATE TABLE [Staging].[Staging_MeldedRate] (
    [SectionReference]                   NVARCHAR (255)   NULL,
    [LimitCCYToSettlementCCYRateCurrent] NUMERIC (38, 12) NULL,
    [LimitCCYToSettlementCCYRateMelded]  NUMERIC (38, 12) NULL,
    [AuditModifyDateTime]                datetime2(7)     NULL,
    [AuditCreateDateTime]                datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]                 nvarchar(255)    NULL

);

