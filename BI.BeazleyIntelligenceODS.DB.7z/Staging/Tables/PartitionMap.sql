﻿CREATE TABLE [Staging].[PartitionMap] (
    [StoredProcedureID]            INT              NULL,
    [StoredProcedureName]          VARCHAR (256)    NULL,
    [StagingTableName]             VARCHAR (256)    NULL,
    [PartitionID]                  INT              NULL,
    [PartitionGUID]                UNIQUEIDENTIFIER NULL,
    [FK_EntityPerspective]         INT              NULL,
    [FK_ReportingCurrencyOverride] INT              NULL,
    [FK_ShareType]                 INT              NULL,
    [FK_AcquisitionCostBasis]      INT              NULL,
    [FK_RateType]                  INT              NULL,
    [FK_SettlementCurrency]        INT              NULL
);


GO
CREATE NONCLUSTERED INDEX [g]
    ON [Staging].[PartitionMap]([FK_EntityPerspective] ASC, [FK_AcquisitionCostBasis] ASC, [FK_RateType] ASC, [FK_SettlementCurrency] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [f]
    ON [Staging].[PartitionMap]([FK_ShareType] ASC, [FK_ReportingCurrencyOverride] ASC, [FK_EntityPerspective] ASC, [FK_SettlementCurrency] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [e]
    ON [Staging].[PartitionMap]([FK_AcquisitionCostBasis] ASC, [FK_ReportingCurrencyOverride] ASC, [FK_EntityPerspective] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [d]
    ON [Staging].[PartitionMap]([StoredProcedureID] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [c]
    ON [Staging].[PartitionMap]([PartitionGUID] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [b]
    ON [Staging].[PartitionMap]([PartitionID] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [a]
    ON [Staging].[PartitionMap]([FK_ShareType] ASC, [FK_ReportingCurrencyOverride] ASC, [FK_EntityPerspective] ASC) WITH (FILLFACTOR = 90);

