﻿CREATE TABLE [Staging].[SourceSystemBeazleyOfficeLocation] (
    [SourceSystem]          VARCHAR (255) NOT NULL,
    [BeazleyOfficeLocation] VARCHAR (255) NOT NULL,
    [AuditTimestamp]        DATETIME      CONSTRAINT [DEF_SourceSystemBeazleyOfficeLocation_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]             VARCHAR (255) CONSTRAINT [DEF_SourceSystemBeazleyOfficeLocation_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_SourceSystem] PRIMARY KEY NONCLUSTERED ([SourceSystem] ASC) WITH (FILLFACTOR = 90)
);

