﻿CREATE TABLE [Staging].[Policy_Claims] (
    [PolicyNumber] NVARCHAR (255) NULL,
    [TrifocusCode] NVARCHAR (255) NULL,
    [YOA]          INT            NOT NULL
);

