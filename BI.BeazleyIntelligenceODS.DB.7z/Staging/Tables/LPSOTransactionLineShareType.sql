﻿CREATE TABLE [Staging].[LPSOTransactionLineShareType] (
    [FK_LPSOTransaction]                           BIGINT           NOT NULL,
    [FK_Syndicate]                                 BIGINT           NULL,
    [FK_ShareType]                                 BIGINT           NOT NULL,
    [TotalPositiveLineMultiplier]                  NUMERIC (19, 12) NOT NULL,
    [TotalNegativeLineMultiplier]                  NUMERIC (19, 12) NOT NULL,
    [TotalPositiveVATLineMultiplier]               NUMERIC (19, 12) NOT NULL,
    [TotalNegativeVATLineMultiplier]               NUMERIC (19, 12) NOT NULL,
    [TotalPositiveDelinkedLineMultiplier]          NUMERIC (19, 12) NOT NULL,
    [TotalNegativeDelinkedLineMultiplier]          NUMERIC (19, 12) NOT NULL,
    [TotalPositiveIPTOverseasTaxLineMultiplier]    NUMERIC (19, 12) NOT NULL,
    [TotalNegativeIPTOverseasTaxLineMultiplier]    NUMERIC (19, 12) NOT NULL,
    [TotalPositiveIPTUKTaxLineMultiplier]          NUMERIC (19, 12) NOT NULL,
    [TotalNegativeIPTUKTaxLineMultiplier]          NUMERIC (19, 12) NOT NULL,
    [TotalPositiveExcIPTOverseasTaxLineMultiplier] NUMERIC (19, 12) NOT NULL,
    [TotalNegativeExcIPTOverseasTaxLineMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]                          datetime2(7)     NULL,
    [AuditCreateDateTime]                          datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]                           nvarchar(255)    NULL

);


GO
CREATE NONCLUSTERED INDEX [IX_LPSOTransactionLineShareType]
    ON [Staging].[LPSOTransactionLineShareType]([FK_LPSOTransaction] ASC) WITH (FILLFACTOR = 90);

