﻿CREATE TABLE [Staging].[LPSOSpecialCategoryCatastropheMatrix] (
    [FK_LPSOTransaction]        BIGINT        NOT NULL,
    [GroupId]                   VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]       datetime2(7)  NULL,
    [AuditCreateDateTime]       datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]        nvarchar(255) NULL

);


GO
CREATE NONCLUSTERED INDEX [IX_LPSOSpecialCategoryCatastropheMatrix]
    ON [Staging].[LPSOSpecialCategoryCatastropheMatrix]([FK_LPSOTransaction] ASC) WITH (FILLFACTOR = 90);

