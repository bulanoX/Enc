﻿CREATE TABLE [Staging].[SectionBeazleyOfficeLocation] (
    [SectionReference]      VARCHAR (255) NOT NULL,
    [BeazleyOfficeLocation] VARCHAR (255) NOT NULL,
    [AuditTimestamp]        DATETIME      CONSTRAINT [DEF_SectionBeazleyOfficeLocation_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]             VARCHAR (255) CONSTRAINT [DEF_SectionBeazleyOfficeLocation_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_SectionBeazleyOfficeLocation] PRIMARY KEY NONCLUSTERED ([SectionReference] ASC) WITH (FILLFACTOR = 90)
);

