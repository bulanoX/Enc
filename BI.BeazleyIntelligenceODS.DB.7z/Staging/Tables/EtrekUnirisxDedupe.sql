﻿CREATE TABLE [Staging].[EtrekUnirisxDedupe] (
    [PolicyReference]       VARCHAR (255) NOT NULL,
    [SectionReference]      VARCHAR (255) NOT NULL,
    [LondonRefNo]           VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]   datetime2(7)  NULL,
    [AuditCreateDateTime]   datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]    nvarchar(255) NULL

);

