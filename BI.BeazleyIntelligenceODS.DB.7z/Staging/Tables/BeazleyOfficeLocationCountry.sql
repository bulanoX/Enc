﻿CREATE TABLE [Staging].[BeazleyOfficeLocationCountry] (
    [Country] NVARCHAR (255) NOT NULL,
    [Region]  NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_BeazleyOfficeLocationCountry] PRIMARY KEY CLUSTERED ([Country] ASC) WITH (FILLFACTOR = 90)
);

