﻿CREATE TABLE [Staging].[ValuesInReportingCurrency] (
    [FK_Section]                        BIGINT          NOT NULL,
    [FK_RateType]                       BIGINT          NOT NULL,
    [FK_ReportingCurrency]              BIGINT          NOT NULL,
    [FK_ReportingCurrencyOverride]      BIGINT          NOT NULL,
    [FK_ShareType]                      BIGINT          NOT NULL,
    [FK_AcquisitionCostBasis]           BIGINT          NOT NULL,
    [FK_EntityPerspective]              BIGINT          NOT NULL,
    [Department]                        VARCHAR (255)   NOT NULL,
    [Limit]                             NUMERIC (38, 4) NOT NULL,
    [Excess]                            NUMERIC (38, 4) NOT NULL,
    [Deductible]                        NUMERIC (38, 4) NOT NULL,
    [Exposure]                          NUMERIC (38, 4) NOT NULL,
    [WEPIncludingReinstatementPremuium] NUMERIC (38, 4) NULL,
    [AuditModifyDateTime]               datetime2(7)    NULL,
    [AuditCreateDateTime]               datetime2(7)    DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]                nvarchar(255)   NULL
);


GO
CREATE NONCLUSTERED INDEX [a]
    ON [Staging].[ValuesInReportingCurrency]([FK_RateType] ASC, [FK_AcquisitionCostBasis] ASC, [FK_EntityPerspective] ASC)
    INCLUDE([FK_Section], [FK_ReportingCurrency], [FK_ReportingCurrencyOverride], [FK_ShareType], [Department], [Limit], [Excess], [Deductible], [Exposure], [WEPIncludingReinstatementPremuium]) WITH (FILLFACTOR = 90);

