﻿CREATE TABLE [Staging].[SectionShareType] (
    [FK_Section]          BIGINT           NOT NULL,
    [FK_ShareType]        BIGINT           NOT NULL,
    [FK_Syndicate]        BIGINT           NULL,
    [TotalLineMultiplier] NUMERIC (19, 12) NULL,
    [AuditModifyDateTime] datetime2(7)     NULL,
    [AuditCreateDateTime] datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]  nvarchar(255)    NULL
);

