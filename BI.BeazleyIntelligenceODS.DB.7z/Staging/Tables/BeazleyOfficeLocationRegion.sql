﻿CREATE TABLE [Staging].[BeazleyOfficeLocationRegion] (
    [BeazleyOfficeLocation] VARCHAR (255) NOT NULL,
    [Region]                VARCHAR (255) NOT NULL,
    [AuditTimestamp]        DATETIME      CONSTRAINT [DEF_BeazleyOfficeLocation_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]             VARCHAR (255) CONSTRAINT [DEF_BeazleyOfficeLocation_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_BeazleyOfficeLocation] PRIMARY KEY NONCLUSTERED ([BeazleyOfficeLocation] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_BeazleyOfficeLocation_Region] UNIQUE NONCLUSTERED ([BeazleyOfficeLocation] ASC, [Region] ASC) WITH (FILLFACTOR = 90)
);

