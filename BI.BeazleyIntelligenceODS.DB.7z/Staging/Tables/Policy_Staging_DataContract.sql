﻿CREATE TABLE [Staging].[Policy_Staging_DataContract] (
    [SourceSystem]            NVARCHAR (255) NULL,
    [PolicyReference]         NVARCHAR (255) NULL,
    [IsQuote]                 BIT            NULL,
    [ExpiringPolicy]          NVARCHAR (255) NULL,
    [AdmittedNonAdmitted]     VARCHAR (6)    NOT NULL,
    [PlacingBrokerContact]    NVARCHAR (255) NULL,
    [InsuredName]             NVARCHAR (255) NULL,
    [InsuredCity]             NVARCHAR (255) NULL,
    [InsuredState]            NVARCHAR (255) NULL,
    [InsuredCountry]          NVARCHAR (255) NULL,
    [MarketSegmentCode]       NVARCHAR (255) NULL,
    [MarketSegment]           VARCHAR (18)   NULL,
    [MethodOfPlacementCode]   VARCHAR (1)    NOT NULL,
    [UniqueMarketReference]   NVARCHAR (255) NULL,
    [YearOfAccount]           INT            NULL,
    [MethodOfPlacement]       NVARCHAR (250) NULL,
    [PlacingBrokerBranchName] NVARCHAR (255) NULL,
    [BrokerBeazleyTradeId]    NVARCHAR (255) NULL,
    [ExpiringPolicyReference] NVARCHAR (255) NULL
);

