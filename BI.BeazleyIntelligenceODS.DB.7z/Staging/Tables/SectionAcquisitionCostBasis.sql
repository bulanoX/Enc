﻿CREATE TABLE [Staging].[SectionAcquisitionCostBasis] (
    [FK_Section]                                BIGINT           NOT NULL,
    [FK_AcquisitionCostBasis]                   BIGINT           NOT NULL,
    [FK_EntityPerspective]                      BIGINT           NOT NULL,
    [AcquisitionCostMultiplier]                 NUMERIC (19, 12) NOT NULL,
    [OriginalEPITotalAcquisitionCostMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]                       datetime2(7)     NULL,
    [AuditCreateDateTime]                       datetime2(7)     DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDetails]                        nvarchar(255)    NULL
);


GO
CREATE NONCLUSTERED INDEX [A]
    ON [Staging].[SectionAcquisitionCostBasis]([FK_Section] ASC, [FK_AcquisitionCostBasis] ASC, [FK_EntityPerspective] ASC)
    INCLUDE([AcquisitionCostMultiplier], [OriginalEPITotalAcquisitionCostMultiplier]) WITH (FILLFACTOR = 90);

