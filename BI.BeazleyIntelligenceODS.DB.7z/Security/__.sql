﻿CREATE SCHEMA [__]
    AUTHORIZATION [dbo];



