﻿CREATE PROCEDURE [Static].[usp_LoadListOfColumnsToTrim]
AS
    
SET NOCOUNT ON

MERGE INTO Utility.ListOfColumnsToTrim AS Target
USING (VALUES
('Ods.Claim', 'ClaimDescription',255,0),
('Ods.Claim', 'ClaimLeadNarrative',255,0),
('Ods.Claim', 'ClaimNarrative',255,0),
('Ods.Claim', 'ClaimURL',2048,0),
('Ods.ClaimExposure', 'BeazleyCat',255,0),
('Ods.ClaimExposure', 'BeazleyCatLongDescription',255,0),
('Ods.ClaimExposure', 'ExposureDescription',255,0),
('Ods.ClaimExposure', 'LastMovementNarrative',255,0),
('Ods.ClaimExposure', 'LastMovementNarrativeContainingIBNR',255,0),
('Ods.ClaimExposure', 'LatestBBRServicesNote',255,0),
('Ods.ClaimExposure', 'LatestCMSNote',255,0),
('Ods.ClaimExposure', 'LatestConsultationNote',255,0),
('Ods.ClaimExposure', 'LatestDiaryNote',255,0),
('Ods.ClaimExposure', 'LatestEvaluationNote',255,0),
('Ods.ClaimExposure', 'LatestFileNote',255,0),
('Ods.ClaimExposure', 'LatestFlaggedNote',255,0),
('Ods.ClaimExposure', 'LatestLossFundFileNote',255,0),
('Ods.ClaimExposure', 'LatestNonMovingNoteBroker',255,0),
('Ods.ClaimExposure', 'LatestNonMovingNoteInsured',255,0),
('Ods.ClaimExposure', 'LatestNonMovingNoteOther',255,0),
('Ods.ClaimExposure', 'LatestNonMovingNoteXCS',255,0),
('Ods.ClaimExposure', 'LatestPeerReviewNote',255,0),
('Ods.ClaimExposure', 'LatestTBANote',255,0),
('Ods.ClaimExposure', 'LatestTriageNote',255,0),
('Ods.ClaimExposure', 'LatestUnderwritingCommitteeNote',255,0),
('Ods.ClaimExposure', 'LawAndJurisdiction',255,0),
('Ods.ClaimExposure', 'LossDetails',255,0),
('Ods.ClaimExposure', 'MarketCat',255,0),
('Ods.ClaimExposure', 'MarketCatLongDescription',255,0),
('Ods.ClaimExposure', 'PrimarySectionURL',2048,0),
('Ods.ClaimExposure', 'SecondarySectionURL',2048,0),
('Ods.ClaimExposure', 'Strategy',255,0),
('Ods.ClaimMovement', 'MovementNarrative',255,0),
('Ods.ClaimMovement', 'MovementNarrativeAdditional',255,0),
('Ods.ControlQuestion', 'ControlQuestion',255,0),
--('Ods.CRMActivity', 'ActivityDescription',255,0),
--('Ods.CRMActivity', 'ActivityLocation',255,0),
--('Ods.CRMActivity', 'ActivitySubject',255,0),
--('Ods.CRMActivity', 'NotePurpose',255,0),
--('Ods.CRMActivity', 'NoteSummary',255,0),
--('Ods.CRMActivity', 'NoteTitle',255,0),
('Ods.CRMBroker', 'BrokerName',255,0),
--('Ods.CRMCampaign', 'CampaignDescription',255,0),
--('Ods.CRMOpportunity', 'Description1',255,0),
--('Ods.CRMOpportunity', 'Description2',255,0),
--('Ods.CRMOpportunity', 'Description3',255,0),
('Ods.Policy', 'PolicyURL',255,0),
('Ods.Section', 'ContractCertaintyQuestionNote',255,0),
('Ods.Section', 'PrimarySectionURL',2048,0),
('Ods.Section', 'SecondarySectionURL',2048,0),
('Ods.Section', 'SectionDescription',255,0),
('Ods.SectionControlQuestionAnswer', 'StringAnswer',255,0),
('Ods.ClaimExposure', 'InsuredName',250,0)

) AS Source(TableName, ColumnName, NewLength, Active)
ON (Target.TableName = Source.TableName AND Target.ColumnName = Source.ColumnName)
WHEN MATCHED AND (
	NULLIF(Source.NewLength, Target.NewLength) IS NOT NULL OR NULLIF(Target.NewLength, Source.NewLength) IS NOT NULL OR 
	NULLIF(Source.Active, Target.Active) IS NOT NULL OR NULLIF(Target.Active, Source.Active) IS NOT NULL
) THEN 
	UPDATE SET 
		NewLength = Source.NewLength, 
		Active = Source.Active
WHEN NOT MATCHED BY TARGET THEN
INSERT (TableName, ColumnName, NewLength, Active)
VALUES (Source.TableName, Source.ColumnName, Source.NewLength, Source.Active)
;


DECLARE @mergeError int
 , @mergeCount int
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF @mergeError != 0
 BEGIN
 PRINT 'ERROR OCCURRED IN MERGE FOR [Utility].[ListOfColumnsToTrim]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected
 END
ELSE
 BEGIN
 PRINT '[Utility].[ListOfColumnsToTrim] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
 END


SET NOCOUNT OFF
GO
