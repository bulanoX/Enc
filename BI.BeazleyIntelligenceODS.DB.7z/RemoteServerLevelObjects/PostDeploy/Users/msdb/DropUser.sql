﻿USE msdb

DECLARE @v_user varchar(50)
DECLARE @sql varchar(max)

IF EXISTS (SELECT * FROM sys.database_principals WHERE name like '%BFL\App.BeazleyIntelligence Admins%')
BEGIN 
    SELECT @v_user = name FROM sys.database_principals WHERE name like '%BFL\App.BeazleyIntelligence Admins%' 

    SET @sql = 'DROP USER ' +  quotename(@v_user)

    EXEC (@sql)
END
