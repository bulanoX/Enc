﻿
--exec [UC].[usp_ProcessEPIQuery] 'Query1' 
CREATE PROC [UC].[usp_ProcessEPIQuery] @p_EPIQueryName    AS NVARCHAR(255)

AS

	--declare @p_EPIQueryName    AS NVARCHAR(255) = 'query2'

	SET NOCOUNT ON
	SELECT 1
/*		
		-- Variables
		DECLARE @SQLInsertStatement  AS NVARCHAR(MAX) 
		DECLARE @SQLSelectStatement  AS NVARCHAR(MAX)
		DECLARE @SQLFromStatement    AS NVARCHAR(MAX)
		DECLARE @SQLWhereStatement   AS NVARCHAR(MAX) 
		DECLARE @SQLQuery            AS NVARCHAR(MAX) 


		DECLARE @FieldID           AS NVARCHAR(255)
		DECLARE @FieldName         AS NVARCHAR(255)
		DECLARE @FieldOperator     AS NVARCHAR(255)
		DECLARE @FieldValue        AS NVARCHAR(MAX)
		DECLARE @FieldValueSelect  AS NVARCHAR(MAX)
		DECLARE @Code			   AS NVARCHAR(255)

		-- Cursors
		DECLARE @EPIQueryFields    AS CURSOR

		IF (OBJECT_ID('tempdb..#EPIValueByRules') IS NOT NULL)
		DROP TABLE #EPIValueByRules

		CREATE TABLE #EPIValueByRules
		(
		     PK_Section								bigint				NOT NULL
			,FK_Syndicate							bigint				NOT NULL
			,FK_ShareType							bigint				NOT NULL
			,FK_AcquisitionCostBasis				bigint				NOT NULL
			,FK_ReportingCurrencyOverride			bigint				NOT NULL
			,FK_EntityPerspective					bigint				NOT NULL
			,SectionReference                       varchar(255)        NOT NULL
			,CurrencyCode                           varchar(255)        NOT NULL                      
			,SyndicateNumber				        varchar(255)        NOT NULL
			,FacilityReference						varchar(255)		NULL
			,Premium				                numeric(19,4)       NULL			
		)

		-- Set variable

		SET  @SQLInsertStatement =	'INSERT INTO #EPIValueByRules'											   + CHAR(13)
									+ '( '																	   + CHAR(13)
									+ '  PK_Section	'														   + CHAR(13)

									+ ' ,FK_Syndicate '														   + CHAR(13)
									+ ' ,FK_ShareType  '													   + CHAR(13)
									+ ' ,FK_AcquisitionCostBasis ' 											   + CHAR(13)
									+ ' ,FK_ReportingCurrencyOverride '										   + CHAR(13)
									+ ' ,FK_EntityPerspective '												   + CHAR(13)
									
									+ ' ,SectionReference '													   + CHAR(13)
									+ ' ,CurrencyCode  '													   + CHAR(13)                    
									+ ' ,SyndicateNumber '													   + CHAR(13)
									+ ' ,FacilityReference '												   + CHAR(13)
									+ ' ,Premium '															   + CHAR(13)									
									+ ' )'

		SET @SQLSelectStatement =   'SELECT '																	+ CHAR(13)
								  + 'PK_Section						= usec.PK_Section '							+ CHAR(13)  
								  + ',FK_Syndicate					= epi.FK_Syndicate '						+ CHAR(13)
								  + ',FK_ShareType					= epi.FK_ShareType '						+ CHAR(13)
								  + ',FK_AcquisitionCostBasis		= epi.FK_AcquisitionCostBasis' 			    + CHAR(13)
								  + ',FK_ReportingCurrencyOverride   = epi.FK_ReportingCurrencyOverride'		+ CHAR(13)
								  + ',FK_EntityPerspective			= epi.FK_EntityPerspective'					+ CHAR(13)
								  + ',SectionReference				= usec.SectionReference '					+ CHAR(13)
								  + ',CurrencyCode					= CurrencyCode'								+ CHAR(13)
								  + ',SyndicateNumber				= SyndicateNumber'							+ CHAR(13)
								  + ',FacilityReference				= usecFR.SectionReference'					+ CHAR(13)

		SET @SQLFromStatement   =   ' FROM UC.Section usec '													+ CHAR(13) + CHAR(13) 
		
								 +	' INNER JOIN  ODS.Section sec '												+ CHAR(13) 
								 +  ' ON usec.PK_Section = sec.PK_Section'										+ CHAR(13)

								 +	' LEFT OUTER JOIN  UC.Section usecFR'										+ CHAR(13) 
								 +  ' ON usec.FK_Facility = usecFR.PK_Section'									+ CHAR(13) + CHAR(13)
					 
								 +  ' INNER JOIN ODS.Policy pol'												+ CHAR(13) 
								 +  ' ON sec.FK_Policy = pol.PK_Policy'										    + CHAR(13) + CHAR(13)
						 
								 +  ' INNER JOIN ODS.TriFocus tri'												+ CHAR(13) 
								 +  ' ON sec.FK_TriFocus = tri.PK_TriFocus'										+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN ODS.Area ar'													+ CHAR(13) 
								 +  ' ON sec.FK_Area = ar.PK_Area'						        				+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN ODS.ClassOfBusiness cob'										+ CHAR(13) 
								 +  ' ON sec.FK_ClassOfBusiness = cob.PK_ClassOfBusiness'						+ CHAR(13) + CHAR(13)
								 
				 				 +  ' INNER JOIN ##FactWrittenEstimatedPremium epi'							    + CHAR(13)
								 +  ' ON epi.FK_Section = sec.PK_Section'										+ CHAR(13) + CHAR(13) 

								 +  ' INNER JOIN ODS.EntityPerspective pers'									+ CHAR(13)
								 +  ' ON epi.FK_EntityPerspective = pers.PK_EntityPerspective'					+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN Red.ShareType sh'												+ CHAR(13)
								 +  ' ON sh.PK_ShareType = epi.FK_ShareType'									+ CHAR(13)
								 +  ' AND sh.ShareTypeName = ''Beazley Share'''									+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN Red.AcquisitionCostBasis acq'									+ CHAR(13)
								 +  ' ON acq.PK_AcquisitionCostBasis = epi.FK_AcquisitionCostBasis'				+ CHAR(13)
								 +  ' AND acq.AcquisitionCostBasisName = ''Net Of All Acquisition Cost'''		+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN ODS.HiddenStatusFilter hidd'									+ CHAR(13)
								 +  ' ON hidd.PK_HiddenStatusFilter = epi.FK_HiddenStatusFilter'				+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN Red.ReportingCurrencyOverride rep'								+ CHAR(13)
								 +  ' ON epi.FK_ReportingCurrencyOverride = rep.PK_ReportingCurrencyOverride'	+ CHAR(13)
								 +  ' AND rep.ReportingCurrencyOverrideName = ''Original Currency'''			+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN ODS.OriginalCurrency ori'										+ CHAR(13)
								 +  ' ON epi.FK_OriginalCurrency = ori.PK_OriginalCurrency'						+ CHAR(13) + CHAR(13)

								 +  ' INNER JOIN ODS.Syndicate syn'												+ CHAR(13)
								 +  ' ON syn.PK_Syndicate = epi.FK_Syndicate'									+ CHAR(13) + CHAR(13)

		SET @SQLWhereStatement  = 'WHERE '

		-- Load list of fields that we want to transform in parameters
		SET @EPIQueryFields = CURSOR FOR SELECT DISTINCT que.FieldName_ID
														,que.FieldName_Name
														,que.FieldOperator_Name
														,que.Code
							  FROM  [Staging_MDS].[MDS_Staging].[UCEPIQuery] que
					     

		OPEN @EPIQueryFields 

		FETCH NEXT FROM @EPIQueryFields INTO  @FieldID, @FieldName, @FieldOperator, @Code

		WHILE @@FETCH_STATUS = 0
		BEGIN

		    IF (@FieldName = 'FacilityReference')
			BEGIN 
				SET @FieldName = 'usecFR.SectionReference'
			END


			IF (@FieldName = 'IsBinderExcludedName')
			BEGIN 
					set @FieldName = 'usec.' + @FieldName 
			END

			IF (@FieldName  = 'LatestEPI')
			BEGIN
					set @FieldName = 'epi.' + @FieldName 
			END
	
			SET @FieldValue = ''
			SET @FieldValueSelect = 'SELECT @FieldValue = que.' +  @p_EPIQueryName + ' FROM [Staging_MDS].[MDS_Staging].[UCEPIQuery] que ' + CHAR(13) +
									'WHERE que.Code=' + @Code 

			EXEC sp_executesql @FieldValueSelect, N'@FieldValue NVARCHAR(255) OUTPUT', @FieldValue OUTPUT

			--IF @FieldOperator <> 'SELECT' AND @FieldOperator <> 'IN' AND @FieldOperator <> 'NOT IN' AND COALESCE(@FieldValue,'')<>''
			--BEGIN						
			--	SELECT @SQLWhereStatement = @SQLWhereStatement + ' ' + @FieldName + ' ' + @FieldOperator + ' ('+ @FieldValue + ') ' + ' AND' + CHAR(13)
			--END

			IF @FieldOperator = 'SELECT' AND COALESCE(@FieldValue,'')<>''
			BEGIN						
				SELECT @SQLSelectStatement = @SQLSelectStatement + ',' + IIF(@FieldValue = 'LatestEPI', 'epi.'+@FieldValue, @FieldValue) + CHAR(13)
			END	

			IF @FieldOperator = 'IN' AND COALESCE(@FieldValue,'')<>''
			BEGIN	
	      	    SELECT @FieldValue = REPLACE(@FieldValue, '# ', '#')			
			    SELECT @FieldValue = REPLACE(@FieldValue,'#',''',''')
				SELECT @SQLWhereStatement = @SQLWhereStatement + ' ' + @FieldName + ' ' + @FieldOperator + ' ('''+ ltrim(rtrim(@FieldValue)) + ''') ' + ' AND' + CHAR(13)		
			END	   	

			IF (@FieldOperator = 'NOT IN') AND COALESCE(@FieldValue,'')<>''
			BEGIN	
				SELECT @FieldValue = REPLACE(@FieldValue, '# ', '#')			
			    SELECT @FieldValue = REPLACE(@FieldValue,'#',''',''')
				SELECT @SQLWhereStatement = @SQLWhereStatement + ' ( ' + @FieldName + ' ' + @FieldOperator + ' ('''+ ltrim(rtrim(@FieldValue)) + ''') ' + ' OR  ' + @FieldName + ' IS NULL ' + ' ) AND' + CHAR(13)
			END	   	

			IF @FieldOperator = 'LIKE' AND COALESCE(@FieldValue,'')<>''
			BEGIN		
				SELECT @FieldValue = REPLACE(@FieldValue, ' ' , '')	
				IF CHARINDEX('#',REVERSE(@FieldValue)) = 1	
					SELECT 	@FieldValue = 	LEFT(@FieldValue,LEN(@FieldValue)-1)
				
			    SELECT @FieldValue = REPLACE(@FieldValue,'#', '''' + ' OR ' + @FieldName + ' ' + @FieldOperator + ' ''')			
				SELECT @SQLWhereStatement = @SQLWhereStatement + ' (' + @FieldName + ' ' + @FieldOperator + ' '''+ @FieldValue + ''' ' + ') AND' + CHAR(13)			
			END	   	
			
			IF  @FieldOperator = 'NOT LIKE' AND COALESCE(@FieldValue,'')<>''
			BEGIN

				SELECT @FieldValue = REPLACE(@FieldValue, ' ' , '')		
				IF CHARINDEX(',',REVERSE(@FieldValue)) = 1	
					SELECT 	@FieldValue = 	LEFT(@FieldValue,LEN(@FieldValue)-1)
						
			    SELECT @FieldValue = REPLACE(@FieldValue,'#', '''' + ' AND ' + @FieldName + ' ' + @FieldOperator + ' ''')			
				SELECT @SQLWhereStatement = @SQLWhereStatement + ' (' + @FieldName + ' ' + @FieldOperator + ' '''+ @FieldValue + ''' ' + ') AND' + CHAR(13)	
			END	    	
			
    
			FETCH NEXT FROM @EPIQueryFields INTO @FieldID, @FieldName, @FieldOperator, @Code
		END

		CLOSE @EPIQueryFields
		DEALLOCATE @EPIQueryFields 		
		
		--PRINT @SQLInsertStatement
		--PRINT @SQLSelectStatement
		--PRINT @SQLFromStatement
		--PRINT LEFT(@SQLWhereStatement,LEN(@SQLWhereStatement)-4)

		SET @SQLQuery = @SQLInsertStatement + @SQLSelectStatement + @SQLFromStatement + LEFT(@SQLWhereStatement,LEN(@SQLWhereStatement)-4)
		EXECUTE sp_executesql @SQLQuery

		CREATE INDEX PK_section ON #EPIValueByRules (PK_Section)

		UPDATE s
		SET s.Premium = EPIGroup.Premium, s.IsFlashPremium = 1
		--SELECT EPIGroup.Premium, S.PK_Section
		FROM UC.Section s
		
		INNER JOIN
		(select 
		  Premium    = sum(ev.Premium) 
		 ,PK_Section = ev.PK_Section		
		FROM #EPIValueByRules ev
		GROUP BY PK_Section) AS EPIGroup 
		ON s.PK_Section = EPIGroup.PK_Section

		--IF EXIST DATA IN UC.FactWrittenPremium THAN DO NOTHING, ELSE INSERT
		--INSERT INTO [UC].[FactWrittenEstimatedPremium]									
		--	( FK_Section
		--	, FK_Syndicate
		--	, FK_ShareType
		--	, FK_AcquisitionCostBasis
		--	, FK_ReportingCurrencyOverride
		--	, FK_EntityPerspective
		--	, Premium ) 
		
		-- SELECT 
		--		  FK_Section								= tempTable.PK_Section
		--		, FK_Syndicate								= tempTable.FK_Syndicate
		--		, FK_ShareType								= tempTable.FK_ShareType
		--		, FK_AcquisitionCostBasis					= tempTable.FK_AcquisitionCostBasis
		--		, FK_ReportingCurrencyOverride				= tempTable.FK_ReportingCurrencyOverride
		--		, FK_EntityPerspective						= tempTable.FK_EntityPerspective
		--		, Premium									= tempTable.Premium
		--FROM #EPIValueByRules  tempTable
		
		--LEFT OUTER JOIN [UC].[FactWrittenEstimatedPremium]	ucFact
		--	ON 	  tempTable.PK_Section						 = ucFact.FK_Section
		--		AND tempTable.FK_Syndicate					 = ucFact.FK_Syndicate
		--		AND tempTable.FK_ShareType					 = ucFact.FK_ShareType
		--		AND tempTable.FK_AcquisitionCostBasis		 = ucFact.FK_AcquisitionCostBasis
		--		AND tempTable.FK_ReportingCurrencyOverride   = ucFact.FK_ReportingCurrencyOverride
		--		AND tempTable.FK_EntityPerspective			 = ucFact.FK_EntityPerspective
  --     WHERE ucFact.FK_Section IS NULL


-- Drop tmp tables
IF (OBJECT_ID('tempdb..#EPIValueByRules') IS NOT NULL) DROP TABLE #EPIValueByRules
*/