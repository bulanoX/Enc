﻿
CREATE PROCEDURE [UC].[usp_LoadSLSnapshotSubGroup]
AS

SET NOCOUNT ON

SELECT 1

/*
INSERT INTO UC.SLSnapshotSubGroup
(
	 SLSnapshotSubGroupCode 
	,SLSnapshotSubGroupName 
	,FK_SLSnapshotGroup
)
SELECT
	 SLSnapshotGroupCode			 = phSubGr.Code
	,SLSnapshotGroupName			 = phSubGr.Name
	,FK_SLSnapshotGroup			 = phGr.PK_SLSnapshotGroup

FROM Staging_MDS.MDS_Staging.UCSLSnapshotSubGroup phSubGr

INNER JOIN UC.SLSnapshotGroup  phGr
ON phGr.SLSnapshotGroupCode = phSubGr.SLSnapshotGroup_Code

*/