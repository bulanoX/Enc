﻿CREATE TABLE [UC].[Section] (
    [PK_Section]           BIGINT          NOT NULL,
    [SectionReference]     VARCHAR (255)   NOT NULL,
    [LatestEPI]            NUMERIC (19, 4) NULL,
    [LatestEPIEurobase]    NUMERIC (19, 4) NULL,
    [Premium]              NUMERIC (19, 4) NULL,
    [IsFlashPremium]       BIT             CONSTRAINT [DEF_UC_Section_IsFlashPremium] DEFAULT ((0)) NOT NULL,
    [IsFlashPremiumName]   AS              ([ODS].[udf_FormatBitAsYesNo]([IsFlashPremium])),
    [IsBinderExcluded]     BIT             CONSTRAINT [DEF_UC_Section_IsBinderExcluded] DEFAULT ((0)) NOT NULL,
    [IsBinderExcludedName] AS              ([ODS].[udf_FormatBitAsYesNo]([IsBinderExcluded])),
    [IsFacility]           BIT             CONSTRAINT [DEF_UC_Section_IsFacility] DEFAULT ((0)) NOT NULL,
    [IsQuote]              BIT             CONSTRAINT [DEF_UC_Section_IsQuote] DEFAULT ((0)) NOT NULL,
    [FK_TriFocus]          BIGINT          CONSTRAINT [DEF_UC_Section_FK_TriFocus] DEFAULT ((0)) NOT NULL,
    [FK_Facility]          BIGINT          CONSTRAINT [DEF_UC_Section_FK_Facility] DEFAULT ((0)) NOT NULL,
    [FK_Policy]            BIGINT          CONSTRAINT [DEF_UC_Section_FK_Policy] DEFAULT ((0)) NOT NULL,
    [FK_OriginalCurrency]  BIGINT          NOT NULL,
    CONSTRAINT [PK_Section] PRIMARY KEY NONCLUSTERED ([PK_Section] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Section_LogicalKey] UNIQUE NONCLUSTERED ([SectionReference] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IDX_UC_Section_003]
    ON [UC].[Section]([FK_Facility] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_UC_Section_002]
    ON [UC].[Section]([FK_TriFocus] ASC)
    INCLUDE([PK_Section]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_UC_Section_001]
    ON [UC].[Section]([FK_Policy] ASC) WITH (FILLFACTOR = 90);

