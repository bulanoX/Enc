﻿CREATE TABLE [UC].[SLSnapshotGroup] (
    [PK_SLSnapshotGroup]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([SLSnapshotGroupCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]     BIT           CONSTRAINT [DEF_UC_SLSnapshotGroup_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SLSnapshotGroupCode] VARCHAR (255) NOT NULL,
    [SLSnapshotGroupName] VARCHAR (255) NOT NULL,
    [AuditTimestamp]      DATETIME      CONSTRAINT [DEF_SLSnapshotGroup_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]           VARCHAR (255) CONSTRAINT [DEF_SLSnapshotGroup_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_SLSnapshotGroup] PRIMARY KEY NONCLUSTERED ([PK_SLSnapshotGroup] ASC) WITH (FILLFACTOR = 90)
);

