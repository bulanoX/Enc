﻿CREATE TABLE [UC].[SLSnapshotSubGroup] (
    [PK_SLSnapshotSubGroup]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([SLSnapshotSubGroupCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]        BIT           CONSTRAINT [DEF_UC_SLSnapshotSubGroup_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SLSnapshotSubGroupCode] VARCHAR (255) NOT NULL,
    [SLSnapshotSubGroupName] VARCHAR (255) NOT NULL,
    [FK_SLSnapshotGroup]     BIGINT        NOT NULL,
    [AuditTimestamp]         DATETIME      CONSTRAINT [DEF_SLSnapshotSubGroup_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]              VARCHAR (255) CONSTRAINT [DEF_SLSnapshotSubGroup_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_SLSnapshotSubGroup] PRIMARY KEY NONCLUSTERED ([PK_SLSnapshotSubGroup] ASC) WITH (FILLFACTOR = 90)
);

