﻿CREATE TABLE [UC].[LineOfBusiness] (
    [PK_LineOfBusiness]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([LineOfBusinessCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]    BIT           CONSTRAINT [DEF_UC_LineOfBusiness_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [LineOfBusinessCode] VARCHAR (255) NOT NULL,
    [LineOfBusinessName] VARCHAR (255) NOT NULL,
    [DepartmentName]     VARCHAR (255) NULL,
    [AuditTimestamp]     DATETIME      CONSTRAINT [DEF_LineOfBusiness_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]          VARCHAR (255) CONSTRAINT [DEF_LineOfBusiness_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_LineOfBusiness] PRIMARY KEY NONCLUSTERED ([PK_LineOfBusiness] ASC) WITH (FILLFACTOR = 90)
);

