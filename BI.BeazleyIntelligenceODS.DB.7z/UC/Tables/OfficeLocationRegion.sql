﻿CREATE TABLE [UC].[OfficeLocationRegion] (
    [PK_OfficeLocationRegion]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([OfficeLocationRegionCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]          BIT           CONSTRAINT [DEF_UC_OfficeLocationRegion_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [OfficeLocationRegionCode] VARCHAR (255) NOT NULL,
    [OfficeLocationRegionName] VARCHAR (255) NOT NULL,
    [AuditTimestamp]           DATETIME      CONSTRAINT [DEF_OfficeLocationRegion_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]                VARCHAR (255) CONSTRAINT [DEF_OfficeLocationRegion_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_OfficeLocationRegion] PRIMARY KEY NONCLUSTERED ([PK_OfficeLocationRegion] ASC) WITH (FILLFACTOR = 90)
);

