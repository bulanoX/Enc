﻿CREATE TABLE [UC].[BeazleyPIM] (
    [PK_BeazleyPIM]       AS              IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([BeazleyPIMCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]     BIT             CONSTRAINT [DEF_UC_BeazleyPIM_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [BeazleyPIMCode]      VARCHAR (255)   NOT NULL,
    [Year]                INT             NULL,
    [Value]               NUMERIC (19, 4) NULL,
    [FK_OriginalCurrency] BIGINT          NOT NULL,
    [AuditTimestamp]      DATETIME        CONSTRAINT [DEF_BeazleyPIM_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]           VARCHAR (255)   CONSTRAINT [DEF_BeazleyPIM_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_BeazleyPIM] PRIMARY KEY NONCLUSTERED ([PK_BeazleyPIM] ASC) WITH (FILLFACTOR = 90)
);

