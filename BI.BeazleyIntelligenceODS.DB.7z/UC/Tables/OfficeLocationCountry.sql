﻿CREATE TABLE [UC].[OfficeLocationCountry] (
    [PK_OfficeLocationCountry]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([OfficeLocationCountryCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]           BIT           CONSTRAINT [DEF_UC_OfficeLocationCountry_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [OfficeLocationCountryCode] VARCHAR (255) NOT NULL,
    [OfficeLocationCountryName] VARCHAR (255) NOT NULL,
    [FK_OfficeLocationRegion]   BIGINT        NULL,
    [AuditTimestamp]            DATETIME      CONSTRAINT [DEF_OfficeLocationCountry_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]                 VARCHAR (255) CONSTRAINT [DEF_OfficeLocationCountry_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_OfficeLocationCountry] PRIMARY KEY NONCLUSTERED ([PK_OfficeLocationCountry] ASC) WITH (FILLFACTOR = 90)
);

