﻿CREATE TABLE [UC].[OfficeLocationCity] (
    [PK_OfficeLocationCity]    AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([OfficeLocationCityCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]          BIT           CONSTRAINT [DEF_UC_OfficeLocationCity_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [OfficeLocationCityCode]   VARCHAR (255) NOT NULL,
    [OfficeLocationCityName]   VARCHAR (255) NOT NULL,
    [FK_OfficeLocationCountry] BIGINT        NULL,
    [AuditTimestamp]           DATETIME      CONSTRAINT [DEF_OfficeLocationCity_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]                VARCHAR (255) CONSTRAINT [DEF_OfficeLocationCity_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_OfficeLocationCity] PRIMARY KEY NONCLUSTERED ([PK_OfficeLocationCity] ASC) WITH (FILLFACTOR = 90)
);

