﻿CREATE TABLE [UC].[Budget] (
    [PK_Budget]         AS              IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([BudgetCode]))),(0)))PERSISTED NOT NULL,
    [IsUnknownMember]   BIT             CONSTRAINT [DEF_UC_Budget_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [BudgetCode]        VARCHAR (255)   NOT NULL,
    [Year]              INT             NOT NULL,
    [Month]             TINYINT         NOT NULL,
    [Value]             NUMERIC (19, 4) NOT NULL,
    [FK_LineOfBusiness] BIGINT          NOT NULL,
    [AuditTimestamp]    DATETIME        CONSTRAINT [DEF_Budget_TimeStamp] DEFAULT (getutcdate()) NOT NULL,
    [AuditUser]         VARCHAR (255)   CONSTRAINT [DEF_Budget_AuditUser] DEFAULT (suser_sname()) NOT NULL,
    CONSTRAINT [PK_Budget] PRIMARY KEY NONCLUSTERED ([PK_Budget] ASC) WITH (FILLFACTOR = 90)
);

