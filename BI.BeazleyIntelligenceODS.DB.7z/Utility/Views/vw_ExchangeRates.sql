﻿

CREATE VIEW [Utility].[vw_ExchangeRates]
AS
SELECT 
     RateType                       = er.RateType_Name                                    
    ,CurrencyCode                   = er.CurrencyCode_Name                                   
    ,EffectiveFromDate              = er.EffectiveFromDate                                            
    ,EffectiveToDate                = er.EffectiveToDate                                       
    ,RateToGBP						= er.RateToGBP
	,RateToEUR						= er.RateToEUR
	,RateToUSD						= er.RateToUSD
FROM [$(Staging_MDS)].MDS_Staging.ExchangeRates er