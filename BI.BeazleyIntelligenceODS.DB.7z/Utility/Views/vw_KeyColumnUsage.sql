﻿

CREATE VIEW [Utility].[vw_KeyColumnUsage]
AS

SELECT
SCHEMA_NAME(tbl.[schema_id])        AS TABLE_SCHEMA
,tbl.name                           AS TABLE_NAME
,i.name                             AS CONSTRAINT_NAME
,clmns.name                         AS COLUMN_NAME
,ic.key_ordinal                     AS ORDINAL_POSITION
FROM
sys.tables tbl
INNER JOIN 
sys.indexes i ON 
i.[object_id]=tbl.[object_id]
INNER JOIN 
sys.index_columns ic ON 
ic.index_id=CAST(i.index_id AS int) 
AND ic.[object_id]=i.[object_id]
INNER JOIN 
sys.columns clmns ON 
clmns.[object_id] = ic.[object_id] 
AND clmns.column_id = ic.column_id