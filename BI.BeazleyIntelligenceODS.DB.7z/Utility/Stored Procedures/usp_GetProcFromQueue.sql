﻿

CREATE PROC Utility.usp_GetProcFromQueue  
(
   @ThreadNo AS INT = NULL,
   @BatchID	 AS INT = NULL
)
AS

SET NOCOUNT ON;

BEGIN TRANSACTION
 
-- Declare temporary table to store the result of the delete
DECLARE @TmpTable TABLE (PK_ODSLoadProc int,   StoredProcName varchar(4000), PartitionId bigint,   DependencyLevel INT);
-- Declare integer variable for counting the delete result
DECLARE @QueryCount int;
 
-- FIRST CHECK NO ERRORS HAVE BEEN LOGGED IN [OperationalDataStoreLog]
IF NOT EXISTS (SELECT 1 FROM [Utility].[OperationalDataStoreLog] Where ErrorFlag = 1 and BatchID = @BatchID) 

BEGIN
 
	-- Select first record, lock it, delete it and store name in temporary table
	;WITH cte as (
	   SELECT TOP(1) 
		pc.FK_ODSProcId
	   ,pc.StoredProcName
	   ,pc.PartitionId
	   ,pc.DependencyLevel
	   FROM  [Utility].[ODSStoredProcedureQueue]  pc WITH (rowlock, readpast)
		WHERE NOT EXISTS (
						-- Check first to see whether dependent queue items have been grabbed from the pile
						SELECT 1 
						 FROM Utility.ODSStoredProcedureDependency olpd 
						 INNER JOIN [Utility].[ODSStoredProcedureQueue] pq
						 ON olpd.FK_ODSProcId = pq.FK_ODSProcId
						 WHERE pc.FK_ODSProcId = olpd.PK_ODSProcId

						UNION ALL
					
						-- Extra check to see whether queue items are off the pile but still being processed
						 SELECT 1 
						 FROM Utility.ODSStoredProcedureDependency olpd2 
						 INNER JOIN Utility.OperationalDataStoreLog pql
						 ON olpd2.FK_ODSProcId = pql.FK_StoredProcedureList
						 WHERE pc.FK_ODSProcId = olpd2.PK_ODSProcId
						 AND pql.EndDateTime IS NULL
						 AND pql.BatchID = @BatchID

						 UNION ALL
						 SELECT 1 
						 FROM Utility.ODSStoredProcedureDependency olpd2 
						 INNER JOIN Utility.OperationalDataStoreLog pql
						 ON olpd2.FK_ODSProcId = pql.FK_StoredProcedureList
						 WHERE pc.FK_ODSProcId = olpd2.PK_ODSProcId
						 AND pql.errorflag =1
						 AND pql.BatchID = @BatchID

							)	
 
		ORDER BY pc.FK_ODSProcId
	   )
	DELETE FROM cte 
	output deleted.FK_ODSProcId
	  ,deleted.StoredProcName
	  ,deleted.PartitionId
	  ,deleted.DependencyLevel
	INTO @TmpTable

	-- Check if there is 1 record in temporary table
	SELECT @QueryCount = count(*) FROM @TmpTable
	IF @QueryCount = 1
		BEGIN

			 -- Return query name
			 SELECT 
				   PK_ODSLoadProc   = PK_ODSLoadProc 
				  ,StoredProcName   = tt.StoredProcName 
				  ,PartitionId		= tt.PartitionId  
				  ,DependencyLevel  = tt.DependencyLevel  
			 FROM @TmpTable tt

					INSERT INTO  [Utility].[OperationalDataStoreLog]
						(
						 FK_StoredProcedureList
						,ProcName
						,StartDateTime
						,DependencyLevel
						,ThreadNo
						,BatchID
						)
					SELECT
						FK_StoredProcedureList = PK_ODSLoadProc 
						,StoredProcName		= tt.StoredProcName 
						,StartDateTime		= getdate()
						,DependencyLevel	= tt.DependencyLevel
						,ThreadNo			= @ThreadNo
						,BatchID			= @BatchID
					 FROM @TmpTable tt

		END
	ELSE

		BEGIN
		  
			-- Temporary table was empty but queue not empty
			-- Execute waitfor procedure for one second
	
			 IF EXISTS (SELECT 1 FROM [Utility].[OperationalDataStoreLog] Where ErrorFlag = 1 and BatchID = @BatchID) 
				BEGIN 
					 SELECT 
						 PK_ODSLoadProc		= 0 
						,StoredProcName		= '' 
						,PartitionId		= 0 
						,DependencyLevel	= 0 
				END
			 ELSE	
			 IF EXISTS (SELECT TOP(1) 1 FROM [Utility].[ODSStoredProcedureQueue]) 
				 BEGIN 
					SELECT 
					  PK_ODSLoadProc	= 0
					  ,StoredProcName	= '  Utility.usp_WaitForSeconds'
					  ,PartitionId		= 0
					  ,DependencyLevel	= NULL
				 END
 		
			ELSE
			 -- Temporary table was empty so queue was empty
			 -- Return empty string to stop next precedence constraint
				BEGIN
					 SELECT 
					   PK_ODSLoadProc	= 0	 
					  ,StoredProcName	= '' 
					  ,PartitionId		= 0 
					  ,DependencyLevel	= 0 
				END
		END

END
ELSE
	BEGIN
		SELECT 
			 PK_ODSLoadProc		= 0	 
			,StoredProcName		= '' 
			,PartitionId		= 0 
			,DependencyLevel	= 0 
	END 
	COMMIT TRANSACTION