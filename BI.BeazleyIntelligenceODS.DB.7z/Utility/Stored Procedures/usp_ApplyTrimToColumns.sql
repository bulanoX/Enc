﻿CREATE PROCEDURE [Utility].[usp_ApplyTrimToColumns] 
AS BEGIN
			DECLARE		@SQL NVARCHAR(MAX) = '';
			DECLARE		@i	int, @Max int;


			SELECT		@i			= MIN(ID),
						@Max		= MAX(ID)
			FROM		Utility.ListOfColumnsToTrim
			WHERE		Active		= 1


			WHILE		@i <= @Max BEGIN 
						SELECT		@SQL =  
									'--==Update ' + TableName + '.' + ColumnName + '==--' + CHAR(13)
									+ 'UPDATE ' + TableName + CHAR(13) 
									+ 'SET ' + ColumnName + ' = LEFT(' + ColumnName + ', ' + CAST(NewLength AS VARCHAR(MAX)) + ') + ''[...]''' + CHAR(13)
									+ 'WHERE LEN(' + ColumnName + ') > ' + CAST(NewLength AS VARCHAR(MAX)) + CHAR(13)
									+ CHAR(13)
						FROM		Utility.ListOfColumnsToTrim
						WHERE		ID = @i

						PRINT		@SQL;
						EXEC		sys.sp_executesql @SQL;

						SELECT		@i			= MIN(ID),
									@Max		= MAX(ID)
						FROM		Utility.ListOfColumnsToTrim
						WHERE		Active		= 1
								AND ID > @i
			END		
END