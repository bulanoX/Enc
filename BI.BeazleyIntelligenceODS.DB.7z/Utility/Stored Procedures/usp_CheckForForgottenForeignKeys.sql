﻿
CREATE   PROCEDURE [Utility].[usp_CheckForForgottenForeignKeys]
AS



BEGIN

DECLARE		@DeleteScript nvarchar(max) = ''

SELECT		@DeleteScript = @DeleteScript +-- char(13) +  
'DELETE FROM ' + substring(CreateSql, 12, CHARINDEX ( 'ADD CONSTRAINT' , CreateSql, 1 )-12) + 
' WHERE ' + substring(CreateSql, CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 ) + 13, CHARINDEX ( ') REFERENCES' , CreateSql, 1 )-CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 )-13) + 
' NOT IN (SELECT ' + substring(CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ) + 3, CHARINDEX ( '])' , CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ))-CHARINDEX ( ']([' , CreateSql, 1 )-3) +
' FROM ' + substring(CreateSql, CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) + 11, CHARINDEX ( ']([' , CreateSql, 30 ) - CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) - 10) + ')'
FROM BeazleyintelligenceODS.Utility.Constraints
WHERE ForeignKeyName not like '%FK_FactClaimExposure_ClaimExposureEntityPerspective%'
AND ReferencedTableSchema = 'ODS'
AND ReferencingTableSchema = 'ODS'
AND ReferencedTableName != 'Section'
AND ReferencingTableName != 'Section'
AND ReferencedTableName not like 'Claim%'
AND ReferencingTableName not like 'Claim%'

EXEC        sp_executesql @DeleteScript


SELECT		@DeleteScript = ''

SELECT		@DeleteScript = @DeleteScript +  
'DELETE FROM ' + substring(CreateSql, 12, CHARINDEX ( 'ADD CONSTRAINT' , CreateSql, 1 )-12) + 
' WHERE ' + substring(CreateSql, CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 ) + 13, CHARINDEX ( ') REFERENCES' , CreateSql, 1 )-CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 )-13) + 
' NOT IN (SELECT ' + substring(CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ) + 3, CHARINDEX ( '])' , CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ))-CHARINDEX ( ']([' , CreateSql, 1 )-3) +
' FROM ' + substring(CreateSql, CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) + 11, CHARINDEX ( ']([' , CreateSql, 30 ) - CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) - 10) + ') '
FROM BeazleyintelligenceODS.Utility.Constraints
WHERE ForeignKeyName not like '%FK_FactClaimExposure_ClaimExposureEntityPerspective%'
AND ReferencedTableSchema = 'Red'
AND ReferencingTableSchema = 'Red'

EXEC        sp_executesql @DeleteScript

SELECT		@DeleteScript = ''
/*
SELECT		@DeleteScript = @DeleteScript +  
'DELETE FROM ' + substring(CreateSql, 12, CHARINDEX ( 'ADD CONSTRAINT' , CreateSql, 1 )-12) + 
' WHERE ' + substring(CreateSql, CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 ) + 13, CHARINDEX ( ') REFERENCES' , CreateSql, 1 )-CHARINDEX ( 'FOREIGN KEY (' , CreateSql, 1 )-13) + 
' NOT IN (SELECT ' + substring(CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ) + 3, CHARINDEX ( '])' , CreateSql, CHARINDEX ( ']([' , CreateSql, 1 ))-CHARINDEX ( ']([' , CreateSql, 1 )-3) +
' FROM ' + substring(CreateSql, CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) + 11, CHARINDEX ( ']([' , CreateSql, 30 ) - CHARINDEX ( 'REFERENCES' , CreateSql, 1 ) - 10) + ') '
FROM BeazleyintelligenceODS.Utility.Constraints
WHERE ForeignKeyName not like '%FK_FactClaimExposure_ClaimExposureEntityPerspective%'
AND ForeignKeyName not like 'FK_FactClaimMovement_ClaimExposureEntityPerspective%'
AND ReferencedTableSchema = 'ODS'
AND ReferencingTableSchema = 'Red'
*/
SELECT @DeleteScript = @DeleteScript + 'DELETE from [Red].[FactClaimExposure]  where [FK_ClaimExposure] not in (SELECT [FK_ClaimExposure] FROM [ODS].[ClaimExposureEntityPerspective]) AND [FK_EntityPerspective] not in (SELECT [FK_EntityPerspective] FROM [ODS].[ClaimExposureEntityPerspective]) ' 
+ 'DELETE from [Red].[FactClaimMovement]  where [FK_ClaimExposure] not in (SELECT [FK_ClaimExposure] FROM [ODS].[ClaimExposureEntityPerspective]) AND [FK_EntityPerspective] not in (SELECT [FK_EntityPerspective] FROM [ODS].[ClaimExposureEntityPerspective]) '

EXEC sp_executesql @DeleteScript

END