﻿
CREATE PROC Utility.DropConstraints
AS

--EXEC sp_MSforeachtable @command1="ALTER TABLE ? NOCHECK CONSTRAINT ALL"


 
-- DROP CONSTRAINTS WHERE EXISTS 
DECLARE @RowString NVARCHAR(MAX)  SELECT @RowString = COALESCE(@RowString + '  ', '') + 
'
 ' 
 + ';IF EXISTS (SELECT 1 FROM Utility.Constraints WHERE ForeignKeyName = ''' + C.ForeignKeyName + ''')  BEGIN 
 '
 + DropSQL		
 + '
 END;
 '
FROM Utility.vw_ForeignKey vfk 
LEFT OUTER JOIN Utility.Constraints C
ON  vfk.ForeignKeyName = c.ForeignKeyName AND 
	vfk.ReferencingTableSchema = c.ReferencingTableSchema AND
	vfk.ReferencingTableName = c.ReferencingTableName 
WHERE vfk.ForeignKeyName is NOT NULL
AND VFK.OrdinalPosition  = 1

 -- select (@RowString)
 EXEC (@RowString)