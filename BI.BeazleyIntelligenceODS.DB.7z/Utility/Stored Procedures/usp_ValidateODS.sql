﻿

CREATE   PROC [Utility].[usp_ValidateODS] 

AS BEGIN

		DECLARE @tables_to_check table (id int identity(1,1), table_name sysname, where_condition nvarchar(1000))
		INSERT INTO @tables_to_check(table_name, where_condition)
					--Following is the list with all the tables to be checked for ValidateODS
					VALUES  ('[ODS].[AccountingCalendar]', 'IsUnknownMember=0'),
							('[ODS].[AccountingPeriod]', null),
							('[ODS].[AcquisitionCostType]', null),
							('[ODS].[Area]', 'IsUnknownMember=0'),
							--('[ODS].[BordereauLine]', null),
							('[ODS].[Claim]', null),
							('[ODS].[ClaimAssociation]', 'IsUnknownMember=0'),
							('[ODS].[ClaimAuthorityLimit]', 'IsUnknownMember=0'),
							('[ODS].[ClaimClaimAssociation]', null),
							('[ODS].[ClaimCostCategory]', null),
							('[ODS].[ClaimDeductibleTracking]', null),
							('[ODS].[ClaimEstimate]', null),
							('[ODS].[ClaimExposure]', null),
							('[ODS].[ClaimExposureEntityPerspective]', null),
							('[ODS].[ClaimExposureSection]', null),
							('[ODS].[ClaimIncurredBand]', 'IsUnknownMember=0'),
							('[ODS].[ClaimMovement]', null),
							('[ODS].[ClaimMovementLine]', null),
							('[ODS].[ClaimQuantifiedStatus]', 'IsUnknownMember=0'),
							('[ODS].[ClaimTeamExaminer]', 'IsUnknownMember=0'),
							('[ODS].[ClassOfBusiness]', 'IsUnknownMember=0'),
							('[ODS].[ClientClassificationCode]', 'IsUnknownMember=0'),
							('[ODS].[ControlQuestion]', null),
							('[ODS].[ControlQuestionType]', null),
							--('[ODS].[CRMActivity]', null),
							('[ODS].[CRMBroker]', 'IsUnknownMember=0'),
							--('[ODS].[CRMCampaign]', null),
							--('[ODS].[CRMCampaignBroker]', null),
							--('[ODS].[CRMOpportunity]', null),
							('[ODS].[DataAsAt]', null),
							('[ODS].[DevelopmentPeriod]', 'IsUnknownMember=0'),
							('[ODS].[DiaryEntry]', null),
							('[ODS].[DimDate]', null),
							('[ODS].[Document]', null),
							('[ODS].[DocumentType]', null),
							('[ODS].[DurationBand]', 'IsUnknownMember=0'),
							('[ODS].[EntityPerspective]', null),
							('[ODS].[Excess]', 'IsUnknownMember=0'),
							('[ODS].[ExposureProfileBand]', null),
							('[ODS].[GQDTransactionType]', 'IsUnknownMember=0'),
							('[ODS].[HiddenStatusFilter]', null),
							--('[ODS].[InceptionPeriod]', null),
							('[ODS].[InternalWrittenBinderStatus]', null),
							('[ODS].[LocalCurrency]', null),
							('[ODS].[LPSOTransaction]', null),
							('[ODS].[LPSOTransactionLine]', null),
							('[ODS].[LPSOTransactionSpecialCategoryCatastrophe]', null),
							('[ODS].[NonLloydsPremiumTransaction]', null),
							('[ODS].[OriginalCurrency]', 'IsUnknownMember=0'),
							('[ODS].[PartyBroker]', 'IsUnknownMember=0'),
							('[ODS].[PartyInsured]', 'IsUnknownMember=0'),
							('[ODS].[PICCTransaction]', null),
							('[ODS].[Policy]', 'IsUnknownMember=0'),
							('[ODS].[PolicyHiddenStatusFilter]', null),
							('[ODS].[QuoteFilter]', null),
							('[ODS].[ReinsuranceContractFac]', null),
							('[ODS].[ReinsuranceContractNonFac]', null),
							('[ODS].[ReinsuranceLPSOTransaction]', null),
							('[ODS].[ReinsuranceLPSOTransactionLine]', null),
							('[ODS].[ReinsuranceSectionContractFac]', null),
							('[ODS].[ReinsuranceSectionContractNonFac]', null),
							--('[ODS].[RiskLocation]', 'IsUnknownMember=0'),
							('[ODS].[Section]', 'IsUnknownMember=0'),
							('[ODS].[SectionAcquisitionCost]', null),
							('[ODS].[SectionATIA]', null),
							('[ODS].[SectionControlQuestionAnswer]', null),
							('[ODS].[SectionEntityPerspective]', null),
							('[ODS].[SectionExcess]', null),
							('[ODS].[SectionLimit]', null),
							('[ODS].[SectionLine]', null),
							('[ODS].[SectionRiskLocation]', null),
							('[ODS].[SectionSPA]', null),
							('[ODS].[SectionSpecialCategorySection]', null),
							('[ODS].[SectionTerritory]', null),
							('[ODS].[SectionWorkflow]', null),
							('[ODS].[SectionWorkflowCycle]', null),
							('[ODS].[ServiceCompany]', 'IsUnknownMember=0'),
							('[ODS].[SettlementCurrency]', null),
							('[ODS].[SlipLineNumber]', null),
							('[ODS].[SpecialCategoryCatastrophe]', 'IsUnknownMember=0'),
							('[ODS].[SpecialCategorySection]', 'IsUnknownMember=0'),
							('[ODS].[Sublimit]', 'IsUnknownMember=0'),
							('[ODS].[Submission]', 'IsUnknownMember=0'),
							('[ODS].[SubmissionExtension]', 'IsUnknownMember=0'),
							('[ODS].[Syndicate]', null),
							('[ODS].[SyndicateSplit]', null),
							('[ODS].[TriFocus]', 'IsUnknownMember=0'),
							('[ODS].[TriFocusYOA]', null),
							('[ODS].[UltimateLossRatio]', null),
							('[ODS].[Underwriter]', 'IsUnknownMember=0'),
							('[ODS].[UnderwriterAuthorityException]', null),
							('[ODS].[UnderwriterAuthorityExceptionNote]', null),
							('[ODS].[UnderwritingPlatform]', 'IsUnknownMember=0'),
							('[ODS].[vw_BIDTransaction]', null),
							('[ODS].[vw_DateSince]', null),
							--('[ODS].[vw_KnowledgeCenterBordereauHeader]', null),
							--('[ODS].[vw_KnowledgeCenterBordereauLine]', null),
							('[ODS].[vw_risk_class_codes]', null),
							('[ODS].[vw_SectionATIA]', null),
							('[ODS].[vw_SectionSyndicateLine]', null),
							('[ODS].[WorkflowCycle]', null),
							('[ODS].[WorkflowStatus]', 'IsUnknownMember=0'),
							('[ODS].[YOA]', null),
							('[Red].[AcquisitionCostBasis]', null),
							('[Red].[AreaHierarchyFlat]', null),
							('[Red].[ClaimMovementSection]', null),
							('[Red].[FactAcquisitionCost]', null),
							('[Red].[FactClaimDeductibleTracking]', null),
							('[Red].[FactClaimExposure]', null),
							('[Red].[FactClaimIncurredBand]', null),
							('[Red].[FactClaimMovement]', null),
							('[Red].[FactCombinedFinancialTransaction]', null),
							('[Red].[FactDocument]', null),
							('[Red].[FactExcess]', null),
							('[Red].[FactExposure]', null),
							('[Red].[FactTaxes]', null),
							('[Red].[FactExposureProfileBand]', null),
							('[Red].[FactLimit]', null),
							--('[Red].[FactOperationalMetric]', null),
							('[Red].[FactPICCTransaction]', null),
							('[Red].[FactReinsuranceCombinedFinancialTransaction]', null),
							('[Red].[FactSettlementCurrencyRate]', null),
							('[Red].[FactSpecialCategoryCatastropheMatrix]', null),
							('[Red].[FactSpecialPurposeSyndicateMultiplier]', null),
							('[Red].[FactUltimateLossRatio]', null),
							('[Red].[FactWrittenEstimatedPremium]', null),
							('[Red].[OperationalMetric]', null),
							('[Red].[PartyBrokerRole]', null),
							('[Red].[RateType]', null),
							('[Red].[ReportingCurrencyOverride]', null),
							('[Red].[SectionAreaHierarchyFlat]', null),
							('[Red].[SectionMultiYearGroupFirstLiveDate]', null),
							('[Red].[ShareType]', null),
							('[Red].[SpecialCategoryCatastropheMatrix]', null),
							('[Red].[SpecialPurposeSyndicateBasis]', null)

DECLARE		@i int = 1,
     					@sql nvarchar(max)
     
			WHILE EXISTS(	SELECT null 
							FROM @tables_to_check 
							WHERE id >= @i		) 

					BEGIN 
							SELECT		@sql = concat('if not exists(select null from ', table_name, 
													CASE 
														WHEN where_condition is not null 
														THEN ' where ' + where_condition 
														ELSE '' 
													END,')', ' raiserror(''','Fatal error: The table ', table_name,' is empty or contains only default or inactive records!',''',16,1 )') 
							FROM		@tables_to_check 
							WHERE		id = @i 
	                 
							EXEC		sys.sp_executesql @sql
								                 
							SELECT		@i = min(id) 
							FROM		@tables_to_check 
							WHERE		id > @i
					END

IF (select count(*) from utility.ODSStoredProcedureQueue) != 0 raiserror ('Fatal error: ODSStoredProcedureQueue is not empty!',16,1 )
	
END