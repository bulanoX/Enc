﻿--************************************************************************************************************
-- This procedure will be used as a validation for the ODS load.
-- It will be called with one parameter that can accept two values: PRE or POST

-- a) When the procedure will be called with PRE as parameter the tables from pre list will be checked;
-- b) When the procedure will be called with POST as parameter the tables from post list will be checked;

-- @StopODSValidation = 1 means the procedure will not escape the validation of the tables to be checked;
-- @StopODSValidation = 0 means the procedure will escape the validation of the tables to be checked;
--************************************************************************************************************

CREATE PROC [Utility].[usp_PrePostLoadODSValidation] (@PreOrPost varchar(5))

AS BEGIN
		DECLARE @tables_to_check table (id int identity(1,1), table_name sysname, where_condition nvarchar(1000))
		DECLARE @StopODSValidation int 

		SELECT @StopODSValidation = NumericValue 
		FROM [BeazleyIntelligence].[Control].[SourceParameter] 
		WHERE TokenName = 'ODS_StopODSValidation'
		--print @StopODSValidation

		IF @PreOrPost not in ('PRE', 'POST') raiserror ('Please use one of the available values for PreOrPost parameter!', 16, 1)

		-- @StopODSValidation is used as a flag for the case when the ODS Validation is failed but the Business feedback is positive 
		-- so the Load of ODS will not be stopped.
		IF @StopODSValidation = 1
			BEGIN
			IF @PreOrPost = 'PRE' 
					BEGIN
					INSERT INTO @tables_to_check(table_name, where_condition) 
 		 
 					--Following is the list with all the tables to be checked vor Pre Load ODS Validation
					VALUES   ('[BeazleyIntelligenceDataContract].[Outbound].[vw_Account]', null), --BI-7953
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_BordereauLine]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_BusinessWorkflow]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_Claim]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimAssociation]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimAuthorityLimit]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimDeductibleTracking]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposure]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureCatastrophe]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureEstimate]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureExtension]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureISODiscrimination]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureMovement]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureMovementExtension]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureNote]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExposureSection]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimExtension]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ClaimMovementLine]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_DiaryEntry]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_Document]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_Facility]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_FinancialTransaction]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_FinancialTransactionExtension]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_PICCTransaction]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_GlobalProgramme]', null),  
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_GlobalProgrammeRisk]', null),   
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_Policy]', null), 
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_PolicyExtension]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_RatingCore]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ReinsuranceContractFac]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_ReinsuranceContractNonFac]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_ReinsuranceFinancialTransaction]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_Section]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionAcquisitionCost]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionATIA]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionExcess]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionExtension]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionLimit]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionLine]', null),
							('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionQuestionAnswer]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionTerritory]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_SectionTerrorism]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_Submission]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_SubmissionExtension]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_UltimateLossRatio]', null),
							--('[BeazleyIntelligenceDataContract].[Outbound].[vw_UnderwriterAuthorityException]', null),
							('[Staging_BeazleyCentralStageIn].[Eurobase_Staging].[vw_transactions_details]', null),
							('[Staging_BeazleyCentralStageIn].[Eurobase_Staging].[vw_transactions_premium]', null),
							 --('[Staging_CRM].[CRM_Staging].[Account]', null), --BI-7953
							('[Staging_DataMart].[Datamart_Staging].[Benchmark_and_Business_Plan_ULRs]', null),
							('[Staging_DataMart].[Datamart_Staging].[Benchmark_and_Business_Plan_ULRs]', null),
							('[Staging_DataMart].[Datamart_Staging].[EPILPSOComments]', null),
							('[Staging_DataMart].[Datamart_Staging].[Lloyds_Class_Code_Mapping]', null),
							('[Staging_DataMart].[Datamart_Staging].[PICC]', null),
							('[Staging_DataMart].[Datamart_Staging].[PIMROE]', null),
							--('[Staging_DataMart].[Datamart_Staging].[PMD_Distribution_Channels]', null),
							--('[Staging_DataMart].[Datamart_Staging].[PMD_Lloyds_ROE]', null),
							('[Staging_Eurobase].[Eurobase_Staging].[common_policy_details_01]', null),
							('[Staging_Eurobase].[Eurobase_Staging].[risk_class_codes]', null),
							--('[Staging_KnowledgeCenter].[KnowledgeCenter_Staging].[Bordereau_Line]', null),
							--('[Staging_KnowledgeCenter].[KnowledgeCenter_Staging].[Bordereau_Header]', null),
							('[Staging_MDS].[MDS_Staging].[TriFocus]', null),
							('[ODS].[AccountingCalendar]', 'IsUnknownMember=0'),
							('[ODS].[ClaimIncurredBand]', null),
							('[ODS].[ClaimQuantifiedStatus]', 'IsUnknownMember=0'),
							('[ODS].[ControlQuestionType]', null),
							('[ODS].[DimDate]', null),
							('[ODS].[DurationBand]', 'IsUnknownMember=0'),
							('[ODS].[EntityPerspective]', null),
							('[ODS].[HiddenStatusFilter]', null),
							('[ODS].[InternalWrittenBinderStatus]', null),
							('[ODS].[LocalCurrency]', null),
							('[ODS].[QuoteFilter]', null),
							('[ODS].[SettlementCurrency]', null),
							('[ODS].[WorkflowCycle]', null),
							('[Red].[AcquisitionCostBasis]', null),
							('[Red].[RateType]', null),
							('[Red].[ReportingCurrencyOverride]', null),
							('[Red].[ShareType]', null),
							('[Red].[SpecialPurposeSyndicateBasis]', null),
							('[Staging_MDS].[dbo].[vw_policy_fac_link]', null)

					END
			ELSE IF @PreOrPost = 'POST' 
					BEGIN
					INSERT INTO @tables_to_check(table_name, where_condition)
 		 
					--Following is the list with all the tables to be checked vor Post Load ODS Validation
					VALUES  ('[ODS].[vw_BIDTransaction]', null),
							('[ODS].[vw_DateSince]', null),
							--('[ODS].[vw_KnowledgeCenterBordereauHeader]', null),
							--('[ODS].[vw_KnowledgeCenterBordereauLine]', null),
							('[ODS].[vw_risk_class_codes]', null),
							('[ODS].[vw_SectionATIA]', null),
							('[ODS].[vw_SectionSyndicateLine]', null),							
							('[Red].[FactClaimExposure]', null),
							('[Red].[FactCombinedFinancialTransaction]', null),
							('[Red].[FactExposureProfileBand]', null),
							('[Red].[FactWrittenEstimatedPremium]', null)
					END

			DECLARE		@i int = 1,
     					@sql nvarchar(max)
     
			WHILE EXISTS(	SELECT null 
							FROM @tables_to_check 
							WHERE id >= @i		) 

					BEGIN 
							SELECT		@sql = concat('if not exists(select null from ', table_name, 
													CASE 
														WHEN where_condition is not null 
														THEN ' where ' + where_condition 
														ELSE '' 
													END,')', 'raiserror(''','Fatal error: The table ', table_name,' is empty or contains only default or inactive records!',''',16,1 )') 
							FROM		@tables_to_check 
							WHERE		id = @i 
	                 
							EXEC		sys.sp_executesql @sql
	                 
							SELECT		@i = min(id) 
							FROM		@tables_to_check 
							WHERE		id > @i
					END

			END

		ELSE print 'Escaped ODS Load Validation';  
		
END