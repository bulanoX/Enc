﻿CREATE PROCEDURE Utility.usp_PostLoadODSValidation
AS BEGIN
	--check prerequisites of the ODS Load
	exec Utility.usp_PrePostLoadODSValidation @PreOrPost='POST';
END;