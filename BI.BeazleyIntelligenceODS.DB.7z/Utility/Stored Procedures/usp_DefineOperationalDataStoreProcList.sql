﻿CREATE PROCEDURE [Utility].[usp_DefineOperationalDataStoreProcList] --  0
(
@PartitionFlag   bit   
)


AS
 
TRUNCATE TABLE [Utility].[ODSStoredProcedureList]

-- /////////////////////////////////////////////////////////////////////////////////////
-- Define Stored Procedure List
-- /////////////////////////////////////////////////////////////////////////////////////
INSERT [Utility].[ODSStoredProcedureList] (ProcId,StoredProcName, PriorityOrder, ActiveFlag, ODSSource)
        SELECT	-3	,'Utility.usp_PreLoadODSValidation',								5, 1, 'BI'  
UNION   SELECT	-2	,'Utility.usp_ClearOperationalDataStore @RebuildConstraints=0',	10, 1, 'BI' 																																																							
UNION	SELECT	-1	,'utility.DropConstraints'	,						15, 0, 'BI' 																																															
UNION	SELECT	0	,'sp_updatestats'	,						20, 1, 'BI' 																																															
UNION	SELECT	1	,'ODS.usp_LoadTriFocus'	,22	,1	,'BI' 
UNION	SELECT	2	,'Staging.usp_LoadBICICessionMultiplier'	,25	,1	,'BI' 
UNION	SELECT	3	,'Staging.usp_LoadClaimCenter_Claims'	,25	,1	,'BI' 
UNION	SELECT	4	,'Staging.usp_LoadPolicy_All_Delta'	,25	,1	,'BI' 
UNION	SELECT	5	,'Staging.usp_LoadPolicy_Claims_Delta'	,25	,1	,'BI' 
UNION	SELECT	6	,'Staging.usp_LoadSection_All_Delta'	,25	,1	,'BI' 
UNION	SELECT	7	,'ODS.usp_LoadAccountingPeriod'	,30	,1	,'BI' 
UNION	SELECT	8	,'ODS.usp_LoadAcquisitionCostType'	,30	,1	,'BI' 
UNION	SELECT	9	,'ODS.usp_LoadArea'	,30	,1	,'BI' 
UNION	SELECT	10	,'ODS.usp_LoadClaimAssociation'	,30	,1	,'BI' 
UNION	SELECT	11	,'ODS.usp_LoadClaimCostCategory'	,30	,1	,'BI' 
UNION	SELECT	12	,'ODS.usp_LoadClassOfBusiness'	,30	,1	,'BI' 
UNION	SELECT	13	,'ODS.usp_LoadClientClassificationCode'	,30	,1	,'BI' 
UNION	SELECT	14	,'ODS.usp_LoadControlQuestion'	,30	,1	,'BI' 
UNION	SELECT	15	,'ODS.usp_LoadCRMBroker'	,30	,1	,'BI' 
UNION	SELECT	16	,'ODS.usp_LoadDataAsAt'	,30	,1	,'BI' 
UNION	SELECT	17	,'ODS.usp_LoadDocumentType'	,30	,1	,'BI' 
UNION	SELECT	18	,'ODS.usp_LoadExcess'	,30	,1	,'BI' 
UNION	SELECT	19	,'ODS.usp_LoadExposureProfileBand'	,30	,1	,'BI' 
UNION	SELECT	20	,'ODS.usp_LoadGQDTransactionType'	,30	,1	,'BI' 
UNION	SELECT	21	,'ODS.usp_LoadOriginalCurrency'	,30	,1	,'BI' 
UNION	SELECT	22	,'ODS.usp_LoadPartyBroker'	,30	,1	,'BI' 
UNION	SELECT	23	,'ODS.usp_LoadPartyInsured'	,30	,1	,'BI' 
UNION	SELECT	24	,'ODS.usp_LoadSlipLineNumber'	,30	,1	,'BI' 
UNION	SELECT	25	,'ODS.usp_LoadSpecialCategory'	,30	,1	,'BI' 
UNION	SELECT	26	,'ODS.usp_LoadSublimit'	,30	,1	,'BI' 
UNION	SELECT	27	,'ODS.usp_LoadSyndicate'	,30	,1	,'BI' 
UNION	SELECT	28	,'ODS.usp_LoadUnderwriter'	,30	,1	,'BI' 
UNION	SELECT	29	,'ODS.usp_LoadUnderwritingPlatform'	,30	,1	,'BI' 
UNION	SELECT	30	,'ODS.usp_LoadWorkflowStatus'	,30	,1	,'BI' 
UNION	SELECT	31	,'ODS.usp_LoadYOA'	,30	,1	,'BI' 
UNION	SELECT	32	,'ODS.usp_MaintainDimDate'	,30	,1	,'BI' 
UNION	SELECT	33	,'Staging.usp_LoadSection_Claims_Delta'	,30	,1	,'BI' 
UNION	SELECT	34	,'Staging.usp_LoadStaging_MeldedRate'	,30	,1	,'BI' 
UNION	SELECT	35	,'Utility.usp_LoadAsAtDate'	,30	,1	,'BI' 
UNION	SELECT	36	,'Utility.usp_LoadCoveragePerilMapping'	,30	,1	,'BI' 
UNION	SELECT	37	,'Utility.usp_LoadCurrencyRate'	,30	,1	,'BI' 
UNION	SELECT	38	,'Utility.usp_LoadSpecialPurposeSyndicateMultiplier'	,30	,1	,'BI' 
UNION	SELECT	39	,'BeazleyIntelligenceRatingODS.ODS.usp_LoadRatingCore'	,40	,1	,'Rating' 
UNION	SELECT	40	,'ODS.usp_LoadConditionType'	,40	,1	,'BI' 
UNION	SELECT	41	,'ODS.usp_LoadRiskClass'	,40	,1	,'BI' 
UNION	SELECT	42	,'ODS.usp_LoadServiceCompany'	,40	,1	,'BI' 
UNION	SELECT	43	,'ODS.usp_LoadSyndicateSplit'	,40	,1	,'BI' 
UNION	SELECT	44	,'ODS.usp_LoadTriFocusYOA'	,40	,1	,'BI' 
UNION	SELECT	45	,'sp_updatestats'	,50	,1	,'BI' 
UNION	SELECT	46	,'ODS.usp_LoadDevelopmentPeriod'	,60	,1	,'BI' 
UNION	SELECT	47	,'ODS.usp_LoadSubmission'	,60	,1	,'BI' 
UNION	SELECT	48	,'ODS.usp_LoadUltimateLossRatio'	,70	,1	,'BI' 
UNION	SELECT	49	,'Staging.usp_LoadPolicy_Delta'	,70	,1	,'BI' 
UNION	SELECT	50	,'Staging.usp_LoadSection_Delta'	,70	,1	,'BI' 
UNION	SELECT	51	,'Staging.usp_LoadSectionFacility'	,80	,1	,'BI' 
--UNION	SELECT	52	,'Staging.usp_PostProcessPolicy'	,95	,1	,'BI' 
UNION	SELECT	54	,'Staging.usp_PostProcessPolicyAndSection'	,90	,1	,'BI' 
UNION	SELECT	52	,'Staging.usp_LoadSectionLine'	,95	,1	,'BI' 
UNION	SELECT	53	,'Staging.usp_PostProcessSection'	,96	,1	,'BI' 
UNION	SELECT	56	,'ODS.usp_LoadPolicy'	,100	,1	,'BI' 
UNION	SELECT	57	,'ODS.usp_LoadSection'	,100	,1	,'BI' 
UNION	SELECT	58	,'ODS.usp_LoadSectionLine'	,100	,1	,'BI'
--UNION	SELECT	59	,'ODS.usp_LoadGlobalProgramme'	, 100	,1	,'BI'   
UNION	SELECT	60	,'ODS.usp_LoadNonLloydsPremiumTransaction'	,110	,1	,'BI' 
UNION	SELECT	61	,'ODS.usp_LoadSectionEntityPerspective'	,110	,1	,'BI' 
UNION	SELECT	62	,'ODS.usp_LoadTaxes'	,110	,1	,'BI' 
--UNION	SELECT	63	,'ODS.usp_LoadGlobalProgrammeRisk'	, 110	,1	,'BI'   
UNION	SELECT	64	,'ODS.usp_LoadClaimTeamExaminer'	,120	,1	,'BI' 
UNION	SELECT	65	,'ODS.usp_LoadDiaryEntry'	,120	,1	,'BI' 
UNION	SELECT	66	,'ODS.usp_LoadDocument'	,120	,1	,'BI' 
UNION	SELECT	67	,'ODS.usp_LoadPICCTransaction'	,120	,1	,'BI' 
UNION	SELECT	68	,'ODS.usp_LoadSectionAcquisitionCost'	,120	,1	,'BI' 
UNION	SELECT	69	,'ODS.usp_LoadSectionConditions'	,120	,1	,'BI' 
UNION	SELECT	70	,'ODS.usp_LoadSectionControlQuestionAnswer'	,120	,1	,'BI' 
UNION	SELECT	71	,'ODS.usp_LoadSectionLimitDeductibles'	,120	,1	,'BI' 
UNION	SELECT	72	,'ODS.usp_LoadSectionReinstatements'	,120	,1	,'BI' 
UNION	SELECT	73	,'ODS.usp_LoadSectionRiskClass'	,120	,1	,'BI' 
UNION	SELECT	74	,'ODS.usp_LoadSectionSpecialCategorySection'	,120	,1	,'BI' 
UNION	SELECT	75	,'ODS.usp_LoadSectionTerritory'	,120	,1	,'BI' 
UNION	SELECT	76	,'ODS.usp_LoadSectionWorkflow'	,120	,1	,'BI' 
UNION	SELECT	77	,'ODS.usp_LoadUnderwriterAuthorityException'	,120	,1	,'BI' 
UNION	SELECT	76	,'ODS.usp_PostProcessPolicyAndSection'	,130	,1	,'BI' 
--UNION	SELECT	78	,'ODS.usp_PostProcessPolicyAndSection_Policy_01'	,130	,1	,'BI' 
--UNION	SELECT	79	,'ODS.usp_PostProcessPolicyAndSection_Section_01'	,131	,1	,'BI' 
--UNION	SELECT	80	,'ODS.usp_PostProcessPolicyAndSection_Policy_02'	,132	,1	,'BI' 
--UNION	SELECT	81	,'ODS.usp_PostProcessPolicyAndSection_Section_02'	,133	,1	,'BI' 
UNION	SELECT	82	,'ODS.usp_PostProcessPolicyAndSection_PMD'	,134	,1	,'BI' 
UNION	SELECT	81	,'ODS.usp_PostProcessPolicyAndSection_GlobalProgramme'	,134	,1	,'BI'   
--UNION	SELECT	82	,'ODS.usp_LoadBordereauLine'	,140	,1	,'BI' 
UNION	SELECT	83	,'ODS.usp_LoadClaim'	,140	,1	,'BI' 
UNION	SELECT	84	,'ODS.usp_LoadSectionATIA'	,140	,1	,'BI' 
UNION	SELECT	85	,'Red.usp_LoadFacilityDetails'	,140	,1	,'BI' 
UNION	SELECT	86	,'Red.usp_LoadSectionMultiYearGroupFirstLiveDate'	,140	,1	,'BI' 
UNION	SELECT	87	,'ODS.usp_LoadClaimClaimAssociation'	,150	,1	,'BI' 
UNION	SELECT	88	,'ODS.usp_LoadClaimExposure'	,150	,1	,'BI' 
UNION	SELECT	89	,'ODS.usp_loadClaimExposureSection'	,160	,1	,'BI' 
UNION	SELECT	90	,'ODS.usp_PostProcessClaimAndExposure'	,165	,1	,'BI' 
UNION	SELECT	91	,'sp_updatestats'	,170	,1	,'BI' 
UNION	SELECT	92	,'ODS.usp_LoadClaimMovement'	,180	,1	,'BI' 
UNION	SELECT	93	,'ODS.usp_LoadLPSOTransaction'	,180	,1	,'BI' 
UNION	SELECT	94	,'ODS.usp_PostProcessDeleteClaimsAndExposures'	,181	,1	,'BI' 
UNION	SELECT	95	,'ODS.usp_LoadClaimMovementLine'	,182	,1	,'BI' 
UNION	SELECT	96	,'ODS.usp_PostProcessClaimExposureAndMovement'	,183	,1	,'BI' 
UNION	SELECT	97	,'ODS.usp_PostProcessLPSOTransaction'	,184	,1	,'BI' 
UNION	SELECT	98	,'ODS.usp_LoadClaimAuthorityLimit'	,185	,1	,'BI' 
UNION	SELECT	99	,'ODS.usp_LoadClaimDeductibleTracking'	,185	,1	,'BI' 
UNION	SELECT	100	,'ODS.usp_LoadClaimEstimate'	,185	,1	,'BI' 
UNION	SELECT	101	,'ODS.usp_PostProcessClaimExposure'	,190	,1	,'BI' 
UNION	SELECT	102	,'Red.usp_PreProcessFactWrittenPremium'	,190	,1	,'BI' 
UNION	SELECT	103 ,'ODS.usp_LoadClaimExposureEntityPerspective'	,195	,1	,'BI' 
UNION	SELECT	104	,'ODS.usp_LoadLPSOTransactionSpecialCategoryCatastrophe'	,200	,1	,'BI' 
UNION	SELECT	105	,'ODS.usp_LoadAgressoData'	,205	,1	,'BI' 
UNION	SELECT	106	,'sp_updatestats'	,210	,1	,'BI' 
UNION	SELECT	107	,'Red.usp_LoadFactSettlementCurrencyRate'	,220	,1	,'BI' 
UNION	SELECT	108	,'Red.usp_LoadFactSpecialPurposeSyndicateMultiplier'	,220	,1	,'BI' 
UNION	SELECT	109	,'Red.usp_LoadFactUltimateLossRatio'	,220	,1	,'BI' 
UNION	SELECT	110	,'Red.usp_LoadAreaHierarchyFlat'	,230	,1	,'BI' 
UNION	SELECT	111	,'Red.usp_LoadFactClaimMovement'	,230	,1	,'BI' 
UNION	SELECT	112	,'Red.usp_LoadFactDocument'	,230	,1	,'BI' 
UNION	SELECT	113	,'Red.usp_LoadFactExcess'	,230	,1	,'BI' 
UNION	SELECT	114	,'Red.usp_LoadFactExposure'	,230	,1	,'BI' 
UNION	SELECT	115	,'Red.usp_LoadFactLimit'	,230	,1	,'BI' 
UNION	SELECT	116	,'Red.usp_LoadFactPICCTransaction'	,230	,1	,'BI' 
UNION	SELECT	117	,'Red.usp_LoadFactWrittenEstimatedPremium'	,230	,1	,'BI' 
UNION	SELECT	118	,'Red.usp_LoadOperationalMetric'	,230	,1	,'BI' 
UNION	SELECT	119	,'Red.usp_LoadPartyBrokerRole'	,230	,1	,'BI' 
UNION	SELECT	120	,'Red.usp_PostProcessFactWrittenEstimatedPremium'	,235	,1	,'BI' 
UNION	SELECT	121	,'sp_updatestats'	,240	,1	,'BI' 
UNION	SELECT	122	,'Red.usp_LoadFactAcquisitionCost'	,250	,1	,'BI' 
UNION	SELECT	123	,'Red.usp_LoadFactTaxes'	,250	,1	,'BI' 
UNION	SELECT	124	,'Red.usp_LoadSectionAreaHierarchyFlat'	,250	,1	,'BI' 
UNION	SELECT	125	,'Red.usp_PreProcessFactClaimExposure'	,250	,1	,'BI' 
UNION	SELECT	126	,'Red.usp_PreProcessFactCombinedFinancialTransaction'	,250	,1	,'BI' 
UNION	SELECT	127	,'Red.usp_PreProcessFactExposureProfileBand'	,250	,1	,'BI' 
UNION	SELECT	128	,'sp_updatestats'	,260	,1	,'BI' 
UNION	SELECT	129	,'Red.usp_LoadFactClaimExposure'	,270	,1	,'BI' 
UNION	SELECT	130	,'Red.usp_LoadFactClaimIncurredBand'	,270	,1	,'BI' 
UNION	SELECT	131	,'Red.usp_LoadFactCombinedFinancialTransaction'	,270	,1	,'BI' 
UNION	SELECT	132	,'Red.usp_LoadFactClaimDeductibleTracking'	,275	,1	,'BI' 
UNION	SELECT	133,'Red.usp_LoadFactExposureProfileBand'	,275	,1	,'BI' 
UNION	SELECT	134	,'Red.usp_LoadFactRiskClass'	,275	,1	,'BI' 
UNION	SELECT	135	,'Red.usp_PostProcessFactClaimExposure'	,275	,1	,'BI' 
UNION	SELECT	136	,'Red.usp_PostProcessFactCombinedFinancialTransaction'	,275	,1	,'BI' 
UNION	SELECT	137	,'ODS.usp_LoadReinsuranceContractFac'	,276	,1	,'BI' 
UNION	SELECT	138	,'Red.usp_PostProcessSyndicateViewFields'	,276	,1	,'BI' 
UNION	SELECT	139	,'ODS.usp_LoadReinsuranceContractNonFac'	,277	,1	,'BI' 
UNION	SELECT	140	,'ODS.usp_LoadReinsuranceSectionContractFac'	,278	,1	,'BI' 
UNION	SELECT	141	,'ODS.usp_LoadReinsuranceSectionContractNonFac'	,279	,1	,'BI' 
UNION	SELECT	142	,'ODS.usp_LoadReinsuranceLPSOTransaction'	,280	,1	,'BI' 
UNION	SELECT	143	,'Red.usp_PreProcessFactReinsuranceCombinedFinancialTransaction'	,281	,1	,'BI' 
UNION	SELECT	144	,'Red.usp_LoadFactReinsuranceCombinedFinancialTransaction'	,282	,1	,'BI' 
UNION	SELECT	145	,'ODS.usp_LoadSectionUnderwrittingCommittee'	,284	,1	,'BI' 
UNION	SELECT	146	,'Utility.usp_LoadEurobaseSectionFilter'	,286	,1	,'BI' 
--UNION	SELECT	146	,'Utility.usp_CheckForForgottenForeignKeys',286	,1	,'BI'
UNION	SELECT	147	,'utility.CreateConstraints'	,289	,1	,'BI' 
UNION	SELECT	148	,'sp_updatestats'	,290	,1	,'BI' 
UNION	SELECT	149	,'utility.usp_ApplyTrimToColumns'	,291	,1	,'BI' 
--UNION	SELECT	150	,'Utility.usp_PostLoadODSValidation'	,300	,1	,'BI' 
UNION	SELECT	151	,'Utility.usp_DropSectionFK'	,301	,1	,'BI' 
UNION	SELECT	152	,'ODS.usp_LoadSublimitType'	,30	,1	,'BI' 

-- /////////////////////////////////////////////////////////////////////////////////////
-- Update DependencyLevel  (REDUCE PRIORITY ORDER TO SEQUENTIAL INTEGERS STARTING AT 1
-- /////////////////////////////////////////////////////////////////////////////////////
;WITH CTE AS 
(
SELECT  PK_ODSStoredProcedureList, a = DENSE_RANK() over ( order by PriorityOrder), DependencyLevel
FROM [Utility].[ODSStoredProcedureList]
WHERE ActiveFlag=1
)
UPDATE CTE
SET DependencyLevel = CTE.a
 

/*
TEMP STEP TO REMOVE FCE FROM PARTITIONING 
*/

--Update Staging.PartitionMap SET StoredProcedureName = 'DISABLED_red.usp_LoadFactClaimExposure' where StoredProcedureName = 'red.usp_LoadFactClaimExposure'
---- Update Staging.PartitionMap SET StoredProcedureName = 'red.usp_LoadFactClaimExposure' where StoredProcedureName =  'DISABLED_red.usp_LoadFactClaimExposure' 

DECLARE @GUID UNIQUEIDENTIFIER

-- /////////////////////// 
IF @PartitionFlag = 1

-- /////////////////////////////////////////////////////////////////////////////////////
-- @PartitionFlag = 1 ---- Automatically generate partitioned procs
-- /////////////////////////////////////////////////////////////////////////////////////
BEGIN
		-- Repopulate ODSLoadProc table with partitioned proc list
		IF OBJECT_ID('tempdb..#ODSLoadProc') IS NOT NULL DROP TABLE #ODSLoadProc
		SELECT * INTO #ODSLoadProc FROM [Utility].[ODSStoredProcedureList] WHERE ODSSource = 'BI'

		DELETE FROM [Utility].[ODSStoredProcedureList] WHERE ODSSource = 'BI'
		INSERT [Utility].[ODSStoredProcedureList]
			(StoredProcname
			,ProcId
			,DependencyLevel
			,PriorityOrder
			,PartitionId
			,ActiveFlag
			,ODSSource)
		SELECT DISTINCT 
			 COALESCE((L.StoredProcname + '_p' + CAST(pm.PartitionID as varchar(3)))	,L.StoredProcname)
			,ProcId
			,Dependencylevel
			,PriorityOrder
			,ISNULL(pm.PartitionID,1)
			,ActiveFlag
			,'BI'
		FROM #ODSLoadProc L
		LEFT OUTER JOIN Staging.PartitionMap pm 
				ON L.StoredProcname = pm.StoredProcedureName 
		ORDER BY DependencyLevel,ProcId,ISNULL(pm.PartitionID,1)

		-- Generate and deploy partitioned procs
		EXEC  Utility.usp_GeneratePartitionedProcs  @ProcSchema	 = 'Red', @ProcName	= 'usp_LoadFactClaimExposure'
		EXEC  Utility.usp_GeneratePartitionedProcs  @ProcSchema	 = 'Red', @ProcName	= 'usp_LoadFactCombinedFinancialTransaction'
		EXEC  Utility.usp_GeneratePartitionedProcs  @ProcSchema	 = 'Red', @ProcName	= 'usp_LoadFactWrittenEstimatedPremium'
		EXEC  Utility.usp_GeneratePartitionedProcs  @ProcSchema	 = 'Red', @ProcName	= 'usp_LoadFactExposureProfileBand'

		-- Update Staging.PartitionMap table with GUIDS per partition
		DECLARE @RowString VARCHAR(MAX)  SELECT   @RowString = COALESCE(@RowString + '  ', '') + 
		'SELECT @GUID = NEWID()  UPDATE staging.PartitionMap SET PartitionGUID = @GUID WHERE PartitionID=' + CAST(partitionId as varchar(3)) + '  AND StoredProcedureName = ''' + storedProcedureName +''''
		FROM staging.partitionMap 
		PRINT 'DECLARE @GUID UNIQUEIDENTIFIER ' + @RowString
		DECLARE @RowString2 VARCHAR(MAX) =  'DECLARE @GUID UNIQUEIDENTIFIER ' + @RowString
		EXEC (@RowString2)

END

IF @PartitionFlag = 0

-- ////////////////////////////////////////////////////////////////////////////////////////////////
-- @PartitionFlag = 0 - Update Staging.PartitionMap table with same GUID for each partitioned proc
-- ////////////////////////////////////////////////////////////////////////////////////////////////
BEGIN
		--DECLARE @GUID UNIQUEIDENTIFIER 
		SELECT @GUID = NEWID()  UPDATE staging.PartitionMap SET PartitionGUID = @GUID WHERE  StoredProcedureName = 'Red.usp_LoadFactClaimExposure'
		SELECT @GUID = NEWID()  UPDATE staging.PartitionMap SET PartitionGUID = @GUID WHERE  StoredProcedureName = 'Red.usp_LoadFactCombinedFinancialTransaction'
		SELECT @GUID = NEWID()  UPDATE staging.PartitionMap SET PartitionGUID = @GUID WHERE  StoredProcedureName = 'Red.usp_LoadFactWrittenEstimatedPremium'
		SELECT @GUID = NEWID()  UPDATE staging.PartitionMap SET PartitionGUID = @GUID WHERE  StoredProcedureName = 'Red.usp_LoadFactExposureProfileBand'
END
 
 
-- /////////////////////////////////////////////////////////////////////////////////////
-- Amend Red.usp_LoadFactCombinedFinancialTransaction and Red.usp_LoadFactClaimExposure paralelism config
--  These procs cannot run in parallel in dev due to server spec/resourses/capacities.
--   We need to adjust the PriorityOrder so that the do not run in parallel for DEV only

-- Determine environment
DECLARE @environment_name NVARCHAR (3) 
SELECT  @environment_name = CAST([value] AS NVARCHAR (3)) FROM [master].[sys].[fn_listextendedproperty] (NULL, NULL, NULL, NULL, NULL, NULL, NULL) WHERE [name] = N'Environment Name'
-- SELECT 'Environement  = ' + @environment_name

-- Update  PriorityOrder for DEV only
IF @environment_name = 'DEV' 
BEGIN 
	UPDATE [Utility].[ODSStoredProcedureList]
	SET PriorityOrder = PriorityOrder + 1
	WHERE StoredProcName = 'Red.usp_LoadFactClaimExposure'
END
  

-- /////////////////////////////////////////////////////////////////////////////////////
-- Populate staging.ODSLoadProcDependency
-- /////////////////////////////////////////////////////////////////////////////////////  
TRUNCATE TABLE Utility.ODSStoredProcedureDependency
INSERT Utility.ODSStoredProcedureDependency (PK_ODSProcId, FK_ODSProcId)
SELECT a.PK_ODSStoredProcedureList, b.PK_ODSStoredProcedureList
FROM [Utility].[ODSStoredProcedureList] a 
INNER JOIN [Utility].[ODSStoredProcedureList] b
		ON a.dependencyLevel = b.dependencyLevel + 1
ORDER BY a.DependencyLevel

/*
SELECT * FROM Staging.ODSLoadProc ORDER BY priorityorder, 1
SELECT * FROM Staging.PartitionMap
SELECT * FROM  staging.ODSLoadProcDependency 
*/

GRANT EXECUTE ON OBJECT::utility.usp_DefineOperationalDataStoreProcList TO [BFL\App.BeazleyIntelligence Admins]