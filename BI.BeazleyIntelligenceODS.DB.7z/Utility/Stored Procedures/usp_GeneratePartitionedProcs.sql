﻿
CREATE PROC Utility.usp_GeneratePartitionedProcs
(
 @ProcSchema		NVARCHAR(MAX) --= 'Red'
,@ProcName			NVARCHAR(MAX) --= 'usp_LoadFactClaimExposure'
)
AS

/*  TESTING  

EXEC Utility.usp_GeneratePartitionedProcs @ProcSchema = 'Red', @ProcName = 'usp_LoadFactClaimExposure'

*/
 

DECLARE @StagingTableName		NVARCHAR(MAX) = (SELECT TOP 1 StagingTableName FROM  Staging.PartitionMap WHERE StoredProcedureName = @ProcSchema + '.' + @ProcName)
DECLARE @PartitionsMax			INT			  
DECLARE @PartitionNumber		INT			  
DECLARE @SQLProcDrop			NVARCHAR(MAX)
DECLARE @SQLProc				NVARCHAR(MAX)
DECLARE @TableConstraintName	NVARCHAR(MAX)


SELECT	@PartitionNumber = 1 
SET		@PartitionsMax = (SELECT MAX(PartitionID) FROM staging.PartitionMap WHERE StoredProcedureName = @ProcSchema +'.'+ @ProcName)
-- PRINT @PartitionsMax
SET @TableConstraintName = 'CHK_' + REPLACE(@StagingTableName,'.','_') +'_p'
-- PRINT @TableConstraintName
 
WHILE  @PartitionNumber <= @PartitionsMax	

BEGIN
  
SELECT @SQLProcDrop = 
'
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES
		   WHERE ROUTINE_SCHEMA = ''' + @ProcSchema + '''' + '  AND ROUTINE_NAME = ''' +  @ProcName + '_p' + CAST(@PartitionNumber AS NVARCHAR(MAX)) + ''') 
BEGIN 
DROP PROC ' + @ProcSchema + '.' + @ProcName + '_p' + CAST(@PartitionNumber AS NVARCHAR(MAX)) + ' 
END
'

SELECT @SQLProc =	REPLACE (
								REPLACE (
										REPLACE (
													REPLACE (
															REPLACE( definition
		 															,@StagingTableName
																	,@StagingTableName + '_p' + CAST(@PartitionNumber AS NVARCHAR(MAX)) 
																	)
															,@ProcName
															,@ProcName + '_p' + CAST(@PartitionNumber AS NVARCHAR(MAX)) 
															)
												,'PartitionID=1'
												,'PartitionID='+ CAST(@PartitionNumber AS NVARCHAR(MAX))
												)
										,@TableConstraintName
										,@TableConstraintName + CAST(@PartitionNumber AS NVARCHAR(MAX))
										)
							,'Partition 1'
							,'Partition ' + CAST(@PartitionNumber AS NVARCHAR(MAX))
							)
										FROM sys.sql_modules m
										INNER JOIN sysobjects o ON o.id=m.object_id
										WHERE o.name = @ProcName


--PRINT @SQLProcDrop
EXEC (@SQLProcDrop)

--PRINT @SQLProc 
EXEC sp_executesql @statement = @SQLProc 

SELECT @PartitionNumber = @PartitionNumber+1
END