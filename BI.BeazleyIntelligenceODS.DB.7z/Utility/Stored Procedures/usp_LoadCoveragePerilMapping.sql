﻿CREATE PROCEDURE [Utility].[usp_LoadCoveragePerilMapping]
AS BEGIN
	SET NOCOUNT ON

	
	MERGE Utility.CoveragePerilMapping AS Target
	USING Staging_MDS.MDS_Staging.CoveragePerilMapping AS Source
		ON Target.LineOfBusiness = Source.LineOfBusiness 
		AND Target.RedistributedMajorClassCode = Source.RedistributedMajorClassCode
	WHEN MATCHED AND (
						   ISNULL(target.RedistributedMajorClass, '') <> ISNULL(source.RedistributedMajorClass, '')
						OR ISNULL(target.RedistributionMultiplier, 0) <> ISNULL(source.RedistributionMultiplier, 0)
						)
		THEN UPDATE 
				SET		TARGET.RedistributedMajorClass		= SOURCE.RedistributedMajorClass
						, TARGET.RedistributionMultiplier	= SOURCE.RedistributionMultiplier
						, TARGET.AuditModifyDateTime	    = GETDATE()	
						, TARGET.AuditModifyDetails	        = 'Merge in ODS.usp_LoadCoveragePerilMapping proc' 
	WHEN NOT MATCHED BY TARGET
		THEN INSERT (LineOfBusiness, RedistributedMajorClassCode, RedistributedMajorClass, RedistributionMultiplier, AuditCreateDateTime, AuditModifyDetails)
		VALUES (LineOfBusiness, RedistributedMajorClassCode, RedistributedMajorClass, RedistributionMultiplier, GETDATE(), 'New add in ODS.usp_LoadCoveragePerilMapping proc')
	WHEN NOT MATCHED BY SOURCE
		THEN DELETE;

END