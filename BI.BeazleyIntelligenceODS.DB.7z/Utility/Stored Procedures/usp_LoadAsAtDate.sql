﻿

CREATE PROCEDURE [Utility].[usp_LoadAsAtDate]
AS

SET NOCOUNT ON

TRUNCATE TABLE Utility.AsAtDate

INSERT INTO Utility.AsAtDate
(   
    AsAtDate
)
SELECT TOP 1
AsAtDate                = d.AsAtDate
FROM
Staging_MDS.MDS_Staging.AsAtDate d