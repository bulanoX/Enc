﻿
CREATE PROCEDURE [Utility].[usp_ClearOperationalDataStore]  -- exec [Utility].[usp_ClearOperationalDataStore] 1
(@RebuildConstraints BIT = 1) -- leaving this parameter as 1 allows for 'normal' behaviour - i.e. drop the contraints and rebuild them at the end.
							  -- If @RebuildContraints = 0 then constraints will not be rebuilt.  Proc required at end of load to rebuild all constraints.
AS

SELECT @RebuildConstraints

SET NOCOUNT ON

DECLARE @Tables TABLE 
(
    SchemaName      sysname             NOT NULL
    ,TableName      sysname             NOT NULL
    PRIMARY KEY (SchemaName, TableName)
) 

INSERT INTO @Tables  
(
    SchemaName
    ,TableName
)
VALUES
 --('Red','SectionAreaHierarchyFlat')
--('Red','AreaHierarchyFlat')
('Red','ClaimMovementSection')
,('Red','FactClaimExposure')
,('Red','FactClaimMovement')
,('Red','FactPICCTransaction')
,('Red','FactExposure')
,('Red','FactWrittenEstimatedPremium')
,('Red','FactOperationalMetric')
,('Red','FactCombinedFinancialTransaction')
,('Red','FactExposureProfileBand')
,('Red','FactRiskClass')
,('UC','Section')
,('UC','BeazleyPIM')
--,('ODS','ClaimEstimate')
,('ODS','PICCTransaction')
,('ODS','Section')
--,('ODS','CRMActivity')
--,('ODS','CRMCampaign')
--,('ODS','CRMOpportunity')
--,('ODS','CRMCampaignBroker')
,('ODS','NonLloydsPremiumTransaction')
,('ODS','DataAsAt')
,('ODS','AccountingPeriod')
,('ODS','Policy')
,('ODS','DevelopmentPeriod')

 -- for European Insurance Company (EIC)
,('ODS','SectionRiskLocation') 
,('ODS','RiskLocation') 
-- 

--,('Staging','ProcQueue')
--,('Staging','ProcQueueLog')
--,('Staging','ErrorRowLog')

--added for visualisation
--,('UC','FactWrittenEstimatedPremium')
,('UC','SLSnapshotSubGroup')
,('UC','SLSnapshotGroup')
,('UC','Budget')
,('UC','LineOfBusiness')
--,('UC','SectionBinderExcluded')

--,('UC','GroupCompanyArea')
--,('UC','GroupCompanyType')

,('UC','OfficeLocationCity')
,('UC','OfficeLocationCountry')
,('UC','OfficeLocationRegion')

--,('UC','UnstructuredData')
 
--TRUNCATE TABLE  [utility].[Constraints]
  
DECLARE @SchemaName                 sysname
DECLARE @TableName                  sysname

DECLARE @ForeignKeyName             sysname
DECLARE @ReferencedTableSchema      sysname
DECLARE @ReferencedTableName        sysname
DECLARE @ReferencingTableSchema     sysname
DECLARE @ReferencingTableName       sysname

DECLARE @ReferencingColumnList      nvarchar(MAX)
DECLARE @ReferencedColumnList       nvarchar(MAX)

DECLARE @DropKeySql                 nvarchar(MAX)
DECLARE @TruncateTableSql           nvarchar(MAX)
DECLARE @CreateKeySql               nvarchar(MAX)
DECLARE @ExistsCheck				nvarchar(MAX)
DECLARE @CreateKeys TABLE (CreateKeySql varchar(MAX) NOT NULL)

DECLARE rs CURSOR STATIC READ_ONLY FORWARD_ONLY FOR 
SELECT DISTINCT 
ForeignKeyName
,ReferencedTableSchema
,ReferencedTableName
,ReferencingTableSchema
,ReferencingTableName
FROM 
Utility.vw_ForeignKey fk

OPEN rs

FETCH NEXT FROM rs INTO
@ForeignKeyName
,@ReferencedTableSchema
,@ReferencedTableName
,@ReferencingTableSchema
,@ReferencingTableName

 
BEGIN TRY

    BEGIN TRANSACTION

    /*Generate SQL to drop & recreate keys and drop the keys*/
    WHILE (@@FETCH_STATUS = 0)
    BEGIN

        SET @DropKeySql = 
        'ALTER TABLE '  
        + '[' + @ReferencingTableSchema + ']'
        + '.' + '[' +  @ReferencingTableName + ']'
        + ' ' + 'DROP CONSTRAINT'
        + ' ' + '[' + @ForeignKeyName + ']'
        
        SET @ReferencingColumnList = ''
        SET @ReferencedColumnList = ''
        
        SELECT 
        @ReferencingColumnList =    @ReferencingColumnList
                                    + CASE WHEN fk.OrdinalPosition > 1 THEN ',' ELSE '' END
                                    + '[' + fk.ReferencingColumnName + ']'
        ,@ReferencedColumnList =    @ReferencedColumnList 
                                    + CASE WHEN fk.OrdinalPosition > 1 THEN ',' ELSE '' END
                                    + '[' + fk.ReferencedColumnName + ']'
        FROM 
        Utility.vw_ForeignKey fk
        WHERE
        fk.ForeignKeyName = @ForeignKeyName
        AND fk.ReferencedTableSchema = @ReferencedTableSchema
        AND fk.ReferencedTableName = @ReferencedTableName
        AND fk.ReferencingTableSchema = @ReferencingTableSchema
        AND fk.ReferencingTableName = @ReferencingTableName
        ORDER BY
        fk.OrdinalPosition

         SET @CreateKeySql = 
        'ALTER TABLE '
        + '[' + @ReferencingTableSchema + ']'
        + '.' + '[' + @ReferencingTableName + ']'
        + ' ' + 'ADD CONSTRAINT ' +  
        + ' ' + '[' + @ForeignKeyName + ']'
        + ' ' + 'FOREIGN KEY (' + @ReferencingColumnList + ')'
        + ' ' + 'REFERENCES' 
        + ' ' + '[' + @ReferencedTableSchema + ']'
        + '.' + '[' + @ReferencedTableName + ']'
        + '(' + @ReferencedColumnList + ')'
        
        --PRINT @CreateKeySql
         
		INSERT INTO @CreateKeys (CreateKeySql)
        VALUES (@CreateKeySql)

			INSERT INTO [utility].[Constraints] 
			(ForeignKeyName,ReferencedTableSchema,ReferencedTableName,ReferencingTableSchema,ReferencingTableName,DropSql,CreateSql)
			SELECT 
				@ForeignKeyName
			,@ReferencedTableSchema
			,@ReferencedTableName
			,@ReferencingTableSchema
			,@ReferencingTableName
			,@DropKeySql
			,@CreateKeySql
			WHERE NOT EXISTS (	SELECT 1 FROM [utility].[Constraints] c
								WHERE c.ForeignKeyName = @ForeignKeyName
								AND c.ReferencingTableSchema = @ReferencingTableSchema
								AND c.ReferencingTableName = @ReferencingTableName)
 
        --PRINT @DropKeySql
        EXEC sp_executesql @DropKeySql
        
        FETCH NEXT FROM rs INTO
        @ForeignKeyName
        ,@ReferencedTableSchema
        ,@ReferencedTableName
        ,@ReferencingTableSchema
        ,@ReferencingTableName
    END

    CLOSE rs
    DEALLOCATE rs
	  
    DECLARE rs1 CURSOR STATIC READ_ONLY FORWARD_ONLY FOR
    SELECT SchemaName, TableName FROM @Tables

    OPEN rs1

    FETCH NEXT FROM rs1 INTO @SchemaName, @TableName

    /*Truncate tables*/
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        
        SET @TruncateTableSql = 
        'TRUNCATE TABLE ' 
        + '[' + @SchemaName + ']'
        + '.' + '[' + @TableName + ']'
        
        --PRINT @TruncateTableSql
        EXEC sp_executesql @TruncateTableSql
        
        FETCH NEXT FROM rs1 INTO @SchemaName, @TableName
    END

    CLOSE rs1
    DEALLOCATE rs1

	 
--/////INSERT UNKNOWN MEMBERS
   
 
	--Unknown member Sectiom

		INSERT ODS.Section
		(	PK_Section										
		 ,	FK_CurrentWorkflowStatusFromDate			
		 ,	FK_ExpiryDate    							
		 ,	FK_FirstLiveDate							
		 ,	FK_InceptionDate							
		 ,	FK_RenewalDueDate							
		 ,	SyndicateViewMultiplier						
		 ,	BenchmarkApplies							
		 ,	BenchmarkAppliesName						
		 ,   CarrierIndicator							
		 ,	ContractCertaintyPostBindComplete			
		 ,	ContractCertaintyPostBindCompleteName		
		 ,	ContractCertaintyPostBindOnTime				
		 ,	ContractCertaintyPostBindOnTimeName			
		 ,	ContractCertaintyPreBindComplete			
		 ,	ContractCertaintyPreBindCompleteName		
		 ,	ContractCertaintyPreBindOnTime				
		 ,	ContractCertaintyRequired					
		 ,	ContractCertaintyRequiredName				
		 ,	ContractCertaintyStatus						
		 ,	ContractCertaintyStatusSortOrder			
		 ,	DelegatedClaimsAuthorityName				
		 ,	DQ_FK_PartyBrokerNoticeOfClaim				
		 ,	DQ_FK_PartyBrokerPlacing					
		 ,	DQ_FK_PartyBrokerProducing					
		 ,	DQ_FK_PartyBrokerServiceOfSuit				
		 ,	EstimatedSigningMultiplier					
		 ,	EstimatedSigningMultiplierName				
		 ,	ExternalAcquisitionCostMultiplier			
		 ,	FACRIIndicator								
		 ,	FACRIIndicatorName							
		 ,	FK_Area										
		 ,	FK_ATIAClassOfBusiness						
		 ,	FK_BreachResponseParentSection				
		 ,	FK_ClassOfBusiness							
		 ,	FK_CRMBroker								
		 ,	FK_CurrentWorkflowStatus					
		 ,	FK_DurationBand								
		 ,	FK_EnteredBy								
		 ,	FK_Facility									
		 ,	FK_HiddenStatusFilter						
		 ,	FK_LimitCurrency							
		 ,	FK_MultiYearGroupDurationBand				
		 ,	FK_OriginalCurrency							
		 ,	FK_Policy									
		 ,	FK_QuoteFilter								
		 ,	FK_SettlementCurrency						
		 ,	FK_LocalCurrency							
		 ,	FK_TriFocus									
		 ,	FK_Underwriter								
		 ,	FK_UnderwriterAssistantContractCertainty	
		 ,	FK_UnderwriterContractCertainty				
		 ,	FK_UnderwriterLargeRiskReviewer				
		 ,	FK_YOA	
		 ,  HasConsortiumLink 
		 ,  HasConsortiumLinkName 
		 ,	HasContractCertaintyDocument				
		 ,	HasDataContractSections						
		 ,	HasDataContractSectionsName					
		 ,	HasExceptionDocument						
		 ,	HasGulfOfMexicoExposure						
		 ,	HasGulfOfMexicoExposureName					
		 ,	HasLinkedSynergySection						
		 ,	HasMarketCapitalisation						
		 ,	HasMissingPICCTransactions					
		 ,	HasMultiYearLink							
		 ,	HasMultiYearLinkName						
		 ,	HasNonEurobaseSections						
		 ,   HasParentLink                               
		 ,	HasProfitCommission							
		 ,	HasProgramLink								
		 ,	HasProgramLinkName							
		 ,	HasRateChange								
		 ,	HasRateChangeName							
		 ,	HasRationaleDocument						
		 ,	HasReinstatementPremium						
		 ,	HasReinstatementPremiumName					
		 ,	HasTreatyAggsTerritory						
		 ,	HasUnderwriterAuthorityException			
		 ,	IncludeInMunichStacking						
		 ,	IsBeazleyLead								
		 ,	IsBeazleyLeadName							
		 ,	IsBreachResponseDummy						
		 ,	IsBreachResponseDummyName					
		 ,	IsDeclaration								
		 ,	IsFacility									
		 ,	IsQuote										
		 ,	IsRapidRenewalName							
		 ,	IsRenewal									
		 ,	IsRenewalForBordereauxName					
		 ,	IsRenewalName								
		 ,	IsRenewed									
		 ,	IsRenewedName								
		 ,	IsSigned									
		 ,	IsSignedName								
		 ,	IsSynergySection							
		 ,	IsSynergySectionName						
		 ,	IsUnknownMember								
		 ,	LatestBordereauPeriod						

		 ,	LineMultiplierBandKey						
		 ,	LiveStatus									
		 ,	MultiYearIndicator							
		 ,	MultiYearIndicatorName						
		 ,	OriginalCurrencyEqualsLimitCurrency			
		 ,	ProgramNumberName							
		 ,	ProgramPeriodName							
		 ,	RateChangeControlComplete					
		 ,	RateChangeControlCompleteName				
		 ,	RateOnLineBandKey							
		 ,	RateOnLineBandName							
		 ,	RationaleQuestionnaireComplete				
		 ,	RationaleQuestionnaireCompleteName			
		 ,	SectionDisplayReference						
		 ,	SectionReference							
		 ,	SectionSequenceId							
		 ,	SourceSystem								
		 ,	SpecialPurposeSyndicateApplies				
		 ,	SpecialPurposeSyndicateAppliesName			
		 ,	SignedOrderEqualsWrittenOrder				
		 ,	SignedOrderEqualsWrittenOrderName			
		 ,	SwordTreatyCoverage							
		 ,	SwordTreatyCoverageName						
		 ,	TermsOfTradeExpired							
		 ,	TermsOfTradeExpiredName						
		 ,	TotalWrittenIfNotSignedMultiplier			
		 ,	TotalWrittenIfNotSignedMultiplierName		
		 ,	TotalWrittenMultiplier						
		 ,	TotalWrittenMultiplierName					
		 ,	WrittenIfNotSignedLineMultiplier			
		 ,	WrittenIfNotSignedLineMultiplierName		
		 ,	WrittenIfNotSignedOrderMultiplier			
		 ,	WrittenIfNotSignedOrderMultiplierName		
		 ,	WrittenLineMultiplier						
		 ,	WrittenLineMultiplierName					
		 ,	WrittenOrderMultiplier						
		 ,	WrittenOrderMultiplierName					
		 ,  IsRapidRenewal								
		 ,	FK_UnderwritingPlatform						
		 ,	IsBID										
		 ,	FK_ServiceCompany							
		 ,	FK_BenchmarkDate							
		 ,	FK_ContractCertaintyControlsCompliantDate	
		 ,	FK_ContractCertaintyDocumentDate 			
		 ,	FK_ContractCertaintyEnteredDate 			
		 ,	FK_ContractCertaintyFullyCompliantDate 		
		 ,	FK_ContractCertaintyModifiedDate 			
		 ,	FK_ContractCertaintyPreBindSignatureDate 	
		 ,	FK_ContractCertaintyPrimaryCompleteDate 	
		 ,	FK_ExceptionDocumentDate 					
		 ,	FK_NoticeDate 								
		 ,	FK_QuoteLapsedDate 							
		 ,	FK_QuoteOrBindDate 							
		 ,	FK_SubmissionDate 							
		 ,	FK_WEPLastUpdatedDate 						
		 ,	FK_DateModified 							
		)
		SELECT
			PK_Section									= 0
		,	FK_CurrentWorkflowStatusFromDate			= '1753-01-01'
		,	FK_ExpiryDate    							= '1753-01-01'
		,	FK_FirstLiveDate							= '1753-01-01'
		,	FK_InceptionDate							= '1753-01-01'
		,	FK_RenewalDueDate							= '1753-01-01'
		,	SyndicateViewMultiplier						= 1
		,	BenchmarkApplies							= 0
		,	BenchmarkAppliesName						= 'No'
		,   CarrierIndicator							= 'Non US carrier'
		,	ContractCertaintyPostBindComplete			= 0
		,	ContractCertaintyPostBindCompleteName		= 'Incomplete'
		,	ContractCertaintyPostBindOnTime				= 0
		,	ContractCertaintyPostBindOnTimeName			= 'Not On Time'
		,	ContractCertaintyPreBindComplete			= 0
		,	ContractCertaintyPreBindCompleteName		= 'Incomplete'
		,	ContractCertaintyPreBindOnTime				= 0 
		,	ContractCertaintyRequired					= 0
		,	ContractCertaintyRequiredName				= 'Contract Certainty Not Required'
		,	ContractCertaintyStatus						= 'No Status'
		,	ContractCertaintyStatusSortOrder			= 6
		,	DelegatedClaimsAuthorityName				= 'No'
		,	DQ_FK_PartyBrokerNoticeOfClaim				= 0
		,	DQ_FK_PartyBrokerPlacing					= 0
		,	DQ_FK_PartyBrokerProducing					= 0
		,	DQ_FK_PartyBrokerServiceOfSuit				= 0
		,	EstimatedSigningMultiplier					= 0
		,	EstimatedSigningMultiplierName				= '0%'
		,	ExternalAcquisitionCostMultiplier			= 0
		,	FACRIIndicator								= 0
		,	FACRIIndicatorName							= 'No'
		,	FK_Area										= 0
		,	FK_ATIAClassOfBusiness						= 0
		,	FK_BreachResponseParentSection				= 0
		,	FK_ClassOfBusiness							= 0
		,	FK_CRMBroker								= 0
		,	FK_CurrentWorkflowStatus					= 0
		,	FK_DurationBand								= 0
		,	FK_EnteredBy								= 0
		,	FK_Facility									= 0
		,	FK_HiddenStatusFilter						= 2
		,	FK_LimitCurrency							= 0
		,	FK_MultiYearGroupDurationBand				= 0
		,	FK_OriginalCurrency							= 0
		,	FK_Policy									= 0
		,	FK_QuoteFilter								= 1
		,	FK_SettlementCurrency						= 1
		,	FK_LocalCurrency							= 0
		,	FK_TriFocus									= 0
		,	FK_Underwriter								= 0
		,	FK_UnderwriterAssistantContractCertainty	= 0
		,	FK_UnderwriterContractCertainty				= 0
		,	FK_UnderwriterLargeRiskReviewer				= 0
		,	FK_YOA										= 0
		,   HasConsortiumLink                           = 0 
		,   HasConsortiumLinkName						= 'No Consortium Link' 
		,	HasContractCertaintyDocument				= 0
		,	HasDataContractSections						= 0
		,	HasDataContractSectionsName					= 'No'
		,	HasExceptionDocument						= 0
		,	HasGulfOfMexicoExposure						= 0
		,	HasGulfOfMexicoExposureName					= 'No'
		,	HasLinkedSynergySection						= 'No'
		,	HasMarketCapitalisation						= 'No'
		,	HasMissingPICCTransactions					= 0
		,	HasMultiYearLink							= 0
		,	HasMultiYearLinkName						= 'No Multi-Year Link'
		,	HasNonEurobaseSections						= 0
        ,   HasParentLink                               = 0
		,	HasProfitCommission							= 'No'
		,	HasProgramLink								= 0
		,	HasProgramLinkName							= 'No Program Link'
		,	HasRateChange								= 0
		,	HasRateChangeName							= 'No'
		,	HasRationaleDocument						= 0
		,	HasReinstatementPremium						= 0
		,	HasReinstatementPremiumName					= 'No'
		,	HasTreatyAggsTerritory						= 0
		,	HasUnderwriterAuthorityException			= 0
		,	IncludeInMunichStacking						= 0
		,	IsBeazleyLead								= 0
		,	IsBeazleyLeadName							= 'No'
		,	IsBreachResponseDummy						= 0
		,	IsBreachResponseDummyName					= 'Regular Section'
		,	IsDeclaration								= 0
		,	IsFacility									= 1
		,	IsQuote										= 0
		,	IsRapidRenewalName							= 'Not Rapid Renewal'
		,	IsRenewal									= 0
		,	IsRenewalForBordereauxName					= 'New'
		,	IsRenewalName								= 'New'
		,	IsRenewed									= 0
		,	IsRenewedName								= 'Not Renewed'
		,	IsSigned									= 0
		,	IsSignedName								= 'Unsigned'
		,	IsSynergySection							= 0
		,	IsSynergySectionName						= 'No'
		,	IsUnknownMember								= 1
		,	LatestBordereauPeriod						= 0
 
		,	LineMultiplierBandKey						= 0
		,	LiveStatus									= 'N/A'
		,	MultiYearIndicator							= 0
		,	MultiYearIndicatorName						= 'No'
		,	OriginalCurrencyEqualsLimitCurrency			= 'Original And Limit Currency Same'
		,	ProgramNumberName							= ''
		,	ProgramPeriodName							= ''
		,	RateChangeControlComplete					= 0
		,	RateChangeControlCompleteName				= 'No'
		,	RateOnLineBandKey							= 0
		,	RateOnLineBandName							= 'N/A'
		,	RationaleQuestionnaireComplete				= 0
		,	RationaleQuestionnaireCompleteName			= 'No'
		,	SectionDisplayReference						= 'N/A'
		,	SectionReference							= 'N/A'
		,	SectionSequenceId							= 0
		,	SourceSystem								= 'N/A'
		,	SpecialPurposeSyndicateApplies				= 0
		,	SpecialPurposeSyndicateAppliesName			= 'No'
		,	SignedOrderEqualsWrittenOrder				= 'Signed Order <> Written Order'
		,	SignedOrderEqualsWrittenOrderName			= 'Signed Order <> Written Order'
		,	SwordTreatyCoverage							= 0
		,	SwordTreatyCoverageName						= 'No'
		,	TermsOfTradeExpired							= 0
		,	TermsOfTradeExpiredName						= 'No'
		,	TotalWrittenIfNotSignedMultiplier			= 0
		,	TotalWrittenIfNotSignedMultiplierName		= '0%'
		,	TotalWrittenMultiplier						= 0
		,	TotalWrittenMultiplierName					= '0%'
		,	WrittenIfNotSignedLineMultiplier			= 0
		,	WrittenIfNotSignedLineMultiplierName		= '0%'
		,	WrittenIfNotSignedOrderMultiplier			= 0
		,	WrittenIfNotSignedOrderMultiplierName		= '0%'
		,	WrittenLineMultiplier						= 0
		,	WrittenLineMultiplierName					= '0%'
		,	WrittenOrderMultiplier						= 0
		,	WrittenOrderMultiplierName					= '0%'
		,   IsRapidRenewal								= 0
		,	FK_UnderwritingPlatform						= 0
		,	IsBID										= 0
		,	FK_ServiceCompany							= 0
		,	FK_BenchmarkDate							= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyControlsCompliantDate	= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyDocumentDate 			= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyEnteredDate 			= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyFullyCompliantDate 		= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyModifiedDate 			= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyPreBindSignatureDate 	= '1753-01-01 00:00:00.000'
		,	FK_ContractCertaintyPrimaryCompleteDate 	= '1753-01-01 00:00:00.000'
		,	FK_ExceptionDocumentDate 					= '1753-01-01 00:00:00.000'
		,	FK_NoticeDate 								= '1753-01-01 00:00:00.000'
		,	FK_QuoteLapsedDate 							= '1753-01-01 00:00:00.000'
		,	FK_QuoteOrBindDate 							= '1753-01-01 00:00:00.000'
		,	FK_SubmissionDate 							= '1753-01-01 00:00:00.000'
		,	FK_WEPLastUpdatedDate 						= '1753-01-01 00:00:00.000'
		,	FK_DateModified 							= '1753-01-01 00:00:00.000'	
	--Unknown member Policy
	 
	--Unknown member Policy
	INSERT INTO ODS.Policy
	(
 
		 IsUnknownMember
		,PolicyReference 
		,AnySectionHasExceptionDocument
		,IsRenewal
		,AnySectionIsSynergy
		,RationaleCompletionMethod
		,SourceSystem
		,IsQuote
		,AdmittedNonAdmitted
		,FK_AccountingCalendar
		,FK_YOA
		,FK_PartyBrokerPlacing
		,FK_PartyBrokerProducing
		,FK_PartyBrokerServiceOfSuit
		,FK_PartyBrokerNoticeOfClaim
		,FK_QuoteFilter
		,FK_CRMBroker
		,FK_Submission
		,FK_PartyInsured
		,FK_CRMProducingBroker
		,FK_UnderwritingPlatform
		,IsBID
		,FK_ServiceCompany
	)
	SELECT
 
	 IsUnknownMember                    = 1
	,PolicyReference                    = 'N/A'
	,AnySectionHasExceptionDocument     = 0
	,IsRenewal                          = 0
	,AnySectionIsSynergy                = 0
	,RationaleCompletionMethod          = 'N/A'
	,SourceSystem                       = 'N/A'
	,IsQuote                            = 0
	,AdmittedNonAdmitted                = 'Lloyds'
	,FK_AccountingCalendar              = 0
	,FK_YOA                             = 0
	,FK_PartyBrokerPlacing              = 0
	,FK_PartyBrokerProducing            = 0
	,FK_PartyBrokerServiceOfSuit        = 0
	,FK_PartyBrokerNoticeOfClaim        = 0
	,FK_QuoteFilter                     = 1
	,FK_CRMBroker                       = 0
	,FK_Submission                      = 0
	,FK_PartyInsured                    = 0
	,FK_CRMProducingBroker				= 0
	,FK_UnderwritingPlatform			= 0
	,IsBID								= 0
	,FK_ServiceCompany					= 0


	-- Unknown member Submission
	--INSERT INTO ODS.Submission
	--(
	--	 IsUnknownMember
	--	,SubmissionSourceId
	--	,SubmissionStatus
	--	,SubmissionDate
	--	,ClearedDate
	--	,WasMigrated
	--	,FK_CRMBroker
	--	,FK_PartyInsured
	--	,FK_Underwriter
	--	,FK_ClearedClassOfBusiness
	--	,SourceSystemName
	--)
	--SELECT
	--	 IsUnknownMember			= 1
	--	,SubmissionSourceId          = 0
	--	,SubmissionStatus		    = 'N/A'
	--	,SubmissionDate			    = '1753-01-01'
	--	,ClearedDate				= '1753-01-01'
	--	,WasMigrated			    = 0     
	--	,FK_CRMBroker               = 0
	--	,FK_PartyInsured            = 0
	--	,FK_Underwriter             = 0
	--	,FK_ClearedClassOfBusiness  = 0
	--	,SourceSystemName			= 'N/A'

	-- Unknown member SubmissionExtension
	--INSERT INTO ODS.SubmissionExtension
	--(
	--	 FK_Submission		-- this is atipical but it's correct because in the table definition we don't use [Utility].[udf_ComputeIdentity] function to generate the key, 
	--	,IsUnknownMember	-- instead, we take it from the ODS.Sumbission table during the population of ODS.SubmissionExtension, inside the ODS.usp_LoadSubmission stored procedure
	--	,SubmissionSourceId
	--	,SourceSystemName
	--)
	--SELECT
	--	 FK_Submission		= 0
	--	,IsUnknownMember	= 1
	--	,SubmissionSourceId = 0
	--	,SourceSystemName	= 'N/A'
	

	
	---- Unknown member PartyBroker
	--INSERT INTO ODS.PartyBroker
	--(
	--	IsUnknownMember
	--	,BrokerNumber
	--	,BrokerPseudonym
	--	,BrokerName
	--	,GroupNumber
	--	,GroupName
	--)
	--SELECT
	--IsUnknownMember     = 1
	--,BrokerNumber       = 0
	--,BrokerPseudonym    = 'N/A'
	--,BrokerName         = 'N/A' 
	--,GroupNumber        = 0 
	--,GroupName          = 'N/A' 


	---- Unknown member TriFocus
	--INSERT INTO ODS.TriFocus
	--(
	--	IsUnknownMember
	--	,TriFocusCode
	--	,TriFocusName
	--	,DepartmentName
	--	,Division
	--)
	--SELECT
	--IsUnknownMember                 = 1
	--,TriFocusCode                   = 'N/A'
	--,TriFocusName                   = 'N/A'
	--,DepartmentName                 = 'N/A'
	--,Division						= 'N/A'

	    
	-----Unknown Member PartyInsured

	--INSERT INTO ODS.PartyInsured
	--(
	--	 IsUnknownMember
	--	,SourceSystem
	--	,SourceSystemId
	--	,InsuredName   
	--)
	--SELECT
	-- IsUnknownMember            = 1
	--,SourceSystem               = 'N/A'
	--,SourceSystemId             = 'N/A'
	--,InsuredName                = 'N/A'   
	


	/*Unknown member DevelopmentPeriod*/
	INSERT INTO ODS.DevelopmentPeriod
	(
		IsUnknownMember
		,DevelopmentMonth
		,DevelopmentMonthName
		,DevelopmentQuarter
		,DevelopmentQuarterName
		,DevelopmentYear
		,DevelopmentYearName
	)
	SELECT
	IsUnknownMember             = 1
	,DevelopmentMonth           = 0
	,DevelopmentMonthName       = 'N/A'
	,DevelopmentQuarter         = 0
	,DevelopmentQuarterName     = 'N/A'
	,DevelopmentYear            = 0
	,DevelopmentYearName        = 'N/A'



   /*Unknown member GQDTransactionType */
 --  INSERT INTO ODS.GQDTransactionType 
	--(
	--	IsUnknownMember
	--	,GQDTransactionTypeCode
	--	,GQDTransactionType
	--) 
	--SELECT
	--IsUnknownMember             = 1
	--,GQDTransactionTypeCode     = 'N/A'
	--,GQDTransactionType         = 'N/A'



	--Unknown mebmer UC.Budget
	INSERT INTO [UC].[Budget]
	(
		 [IsUnknownMember]
		,[BudgetCode]
		,[Year]
		,[Month]
		,[Value]
		,[FK_LineOfBusiness]
		,[AuditTimestamp]
		,[AuditUser]
	)

	SELECT
		 [IsUnknownMember]		= 1 
		,[BudgetCode]			= 'N/A'
		,[Year]					= 0
		,[Month]				= 0
		,[Value]				= 0
		,[FK_LineOfBusiness]	= 0
		,[AuditTimestamp]		= getdate()
		,[AuditUser]			= 'N/A'

	--Unknown mebmer UC.BeazleyPIM
	INSERT INTO [UC].[BeazleyPIM]
	(
		 [IsUnknownMember]
		,[BeazleyPIMCode]
		,[Year]
		,[Value]
		,[FK_OriginalCurrency]
		,[AuditTimestamp]
		,[AuditUser]
	)

	SELECT
		 [IsUnknownMember]		= 1 
		,[BeazleyPIMCode]		= 'N/A'
		,[Year]					= 0
		,[Value]				= 0
		,[FK_OriginalCurrency]	= 0
		,[AuditTimestamp]		= getdate()
		,[AuditUser]			= 'N/A'


	--Unknown mebmer UC.GroupCompanyType
	--INSERT INTO [UC].[GroupCompanyType]
	--(
	--	 [IsUnknownMember]
	--	,[GroupCompanyTypeCode]
	--	,[GroupCompanyTypeName]
	--	,[AuditTimestamp]
	--	,[AuditUser]
	--)

	--SELECT
	--	 [IsUnknownMember]		  = 1
	--	,[GroupCompanyTypeCode]	  = 'N/A'
	--	,[GroupCompanyTypeName]	  = 'N/A'
	--	,[AuditTimestamp]		  = getdate()
	--	,[AuditUser]			  = 'N/A'


	--Unknown mebmer UC.GroupCompanyArea
	--INSERT INTO [UC].[GroupCompanyArea]
	--(
	--	 [IsUnknownMember]
	--	,[GroupCompanyAreaCode]
	--	,[GroupCompanyAreaName]
	--	,[AuditTimestamp]
	--	,[AuditUser]
	--)

	--SELECT
	--	 [IsUnknownMember]		   = 1
	--	,[GroupCompanyAreaCode]	   = 'N/A'
	--	,[GroupCompanyAreaName]	   = 'N/A'
	--	,[AuditTimestamp]		   = getdate()
	--	,[AuditUser]			   = 'N/A'


	--Unknown mebmer UC.SectionBinderExcluded
	--INSERT INTO [UC].[SectionBinderExcluded]
	--(
	--	 [IsUnknownMember]
	--	,[ExcludedBinderCode]
	--	,[ExcludedBinderName]
	--	,[AuditTimestamp]
	--	,[AuditUser] 
	--)

	--SELECT
	--	 [IsUnknownMember]			  = 1
	--	,[ExcludedBinderCode]		  = 'N/A'
	--	,[ExcludedBinderName]		  = 'N/A'
	--	,[AuditTimestamp]			  = getdate()
	--	,[AuditUser] 				  = 0

	
	--Unknown mebmer UC.SLSnapshotSubGroup
	INSERT INTO [UC].[SLSnapshotSubGroup]
	(
		 [IsUnknownMember]
		,[SLSnapshotSubGroupCode]
		,[SLSnapshotSubGroupName]
		,[FK_SLSnapshotGroup]
		,[AuditTimestamp]
		,[AuditUser] 
	)

	SELECT
		 [IsUnknownMember]			 = 1
		,[SLSnapshotSubGroupCode]	 = 'N/A'
		,[SLSnapshotSubGroupName]	 = 'N/A'
		,[FK_SLSnapshotGroup]		 = 0
		,[AuditTimestamp]			 = getdate()
		,[AuditUser] 				 = 0


	--Unknown mebmer UC.SLSnapshotGroup
	INSERT INTO [UC].[SLSnapshotGroup]
	(
		 [IsUnknownMember]
		,[SLSnapshotGroupCode]
		,[SLSnapshotGroupName]
		,[AuditTimestamp]
		,[AuditUser] 
	)

	SELECT
		 [IsUnknownMember]			 = 1
		,[SLSnapshotGroupCode]		 = 'N/A'
		,[SLSnapshotGroupName]		 = 'N/A'
		,[AuditTimestamp]			 = getdate()
		,[AuditUser] 				 = 0


	--Unknown mebmer UC.LineOfBusiness
	INSERT INTO [UC].[LineOfBusiness]
	(
		 [IsUnknownMember]
		,[LineOfBusinessCode]
		,[LineOfBusinessName]
		,[DepartmentName]
		,[AuditTimestamp]
		,[AuditUser]
	)

	SELECT							  
		 [IsUnknownMember]			  = 1
		,[LineOfBusinessCode]		  = 'N/A'
		,[LineOfBusinessName]		  = 'N/A'
		,[DepartmentName]			  = 0
		,[AuditTimestamp]			  = getdate()
		,[AuditUser]				  = 0


   /*Unknown member UnderwritingPlatform */
 --  INSERT INTO [ODS].[UnderwritingPlatform]
	--(
	--	[IsUnknownMember]
	--	,[IsBID]
	--	,[IsFiltered]
	--	,[UnderwritingPlatformCode]
	--	,[UnderwritingPlatformName]
	--) 
	--SELECT
	--	[IsUnknownMember]           = 1
	--	,[IsBID]					= 0
	--	,[IsFiltered]				= 0
	--	,[UnderwritingPlatformCode] = 'N/A'
	--	,[UnderwritingPlatformName]	= 'N/A'

	/*Unknown member RiskLocation */
   INSERT INTO [ODS].[RiskLocation]
	(
		[IsUnknownMember]
		,[RiskLocation]
		,[RiskLocationState]
	) 
	SELECT
		[IsUnknownMember]		= 1
		,[RiskLocation]			= 'N/A'
		,[RiskLocationState]	= 'N/A'


	/*Unknown member for SectionRiskLocation */
   INSERT INTO [ODS].[SectionRiskLocation]
	(
		[FK_Section]
		,[FK_RiskLocation]
		,[RiskLocationMultiplier]
	) 
	SELECT
		[FK_Section]				= 0
		,[FK_RiskLocation]			= 0
		,[RiskLocationMultiplier]	= NULL



    DECLARE rs2 CURSOR STATIC READ_ONLY FORWARD_ONLY FOR 
    
    SELECT CreateKeySql FROM @CreateKeys

    OPEN rs2

    FETCH NEXT FROM rs2 INTO @CreateKeySql
    
    /*Recreate keys*/
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        IF @RebuildConstraints = 1
		BEGIN 
			--PRINT @CreateKeySql
			EXEC sp_executesql @CreateKeySql
        END

		FETCH NEXT FROM rs2 INTO @CreateKeySql

    END

    CLOSE rs2
    DEALLOCATE rs2
    
    COMMIT TRANSACTION
    
END TRY

BEGIN CATCH
    
    DECLARE @ErrorCode varchar(255)
    DECLARE @ErrorText varchar(MAX)
    DECLARE @ErrorSeverity int
    DECLARE @ErrorState int
    
    SET @ErrorCode      = ERROR_NUMBER()
    SET @ErrorText      = ERROR_MESSAGE()
    SET @ErrorSeverity  = ERROR_SEVERITY()
    SET @ErrorState     = ERROR_STATE()

    BEGIN TRY
        CLOSE rs
        DEALLOCATE rs
    END TRY
    
    BEGIN CATCH
        --Do nothing: cursor already closed
    END CATCH
    
    BEGIN TRY
        CLOSE rs1
        DEALLOCATE rs1
    END TRY
    
    BEGIN CATCH
        --Do nothing: cursor already closed
    END CATCH
    
    BEGIN TRY
        CLOSE rs2
        DEALLOCATE rs2
    END TRY
    
    BEGIN CATCH
        --Do nothing: cursor already closed
    END CATCH
    
    ROLLBACK TRANSACTION

    RAISERROR(@ErrorText, @ErrorSeverity, @ErrorState)
        
END CATCH
