﻿

CREATE PROCEDURE [Utility].[usp_LoadOperationalDataStore]   

(
 @p_StartFromProc            varchar(255) = NULL  -- first proc to run (leaving it null will default to first proc)
,@p_EndAtProc                varchar(255) = NULL  -- last proc to run  (leaving it null will default to last proc)
,@p_ManualBatch              bit          = 0     -- Set to "1" when running this proc in SSMS in isolation outside of the load.  
--                                                   This will open a requied Batch entry and subsequently close it on success or failure.
,@Debug						 bit		  = 0
)

AS

/*
This new version of the ODS load proc allows us to restart the ods proc from any proc and end at any proc based on the load order defined.
(Not useful for the ODS schema as we clear it all out first, but potentially useful for the Red schema which is intended to be truncate and reload on a proc by proc basis).

If we intend to use the proc in isolation outside of a load (prod and non-prod), then @p_ManualBatch needs to be set to 1 which will open batch entry E.g. 

    EXECUTE [Utility].[usp_LoadOperationalDataStore]  @p_ManualBatch = 1 

You can also run the proc via the (newly defined) "BeazleyIntelligence_Load_ODS" SQL Agent Job which enables you to run the ODS database load 
in isolation via a single click. Sweet.  

This ensures that the way we load the ODS in dev is exactly how it will get loaded in sys/uat/prod.
 
Log entries are recorded in the TasklogSummary view within the BeazleyIntelligence database.  However, if you are prone
to bouts of Tourettes at the mere mention of 'Framework', then you may avoid offending anyone in the office by viewing the 
log entries in the original ODS log table: 
    
    utility.OperationalDataStoreLog

*/
 
SET NOCOUNT ON
BEGIN TRY

---- Log Batch/Task variables -----------------------
DECLARE
         @Log_Batch                 int
		,@Log_TaskLog               int
        ,@Log_BatchStepLog          int
	   	,@Log_ErrorMessage          nvarchar(MAX)
		,@Log_ErrorNumber           int
		,@Log_ErrorSeverity         int
		,@Log_ErrorState            int
		,@Log_ErrorLine             int
		,@Log_Process				int
        ,@Log_ExecutableServer      nvarchar(MAX)
		,@Log_ExecutableDatabase    nvarchar(MAX)
		,@Log_ExecutableSchema      nvarchar(MAX)
		,@Log_ExecutableObject      nvarchar(MAX)
		,@Log_Description           nvarchar(MAX)
        ,@Log_Step_Name  			nvarchar(MAX)
        ,@Log_Step        			int
        ,@Log_Process_Name          nvarchar(MAX)
        ,@Task_Description		    nvarchar(MAX)
        ,@BatchStep_Description		nvarchar(MAX)
        ,@BatchId                   INT  = CAST(RAND() * 1000000 AS INT) 
 
---- Internal variables
DECLARE
         @db                        varchar(128)
        ,@source_schema             varchar(128)
        ,@target_schema             varchar(128)
        ,@cmd                       nvarchar(4000)
        ,@cmd2                      nvarchar(4000)
        ,@parameters                nvarchar(32)
        ,@returnvalue               int
        ,@StepName                  nvarchar(4000)
        ,@ControlDatabase           nvarchar(4000)
        ,@MinStartDateTime          datetime
        ,@MaxEndDateTime            datetime
        ,@PK_ODSLoad_START          int
        ,@PK_ODSLoad_END            int
        ,@MinPK_ODSLoad             int
        ,@MaxPK_ODSLoad             int
DECLARE  @ODSLoad                   TABLE            -- temp table that will contain the procedures we need to run
            (
             PK_ODSLoad             INT IDENTITY(1,1)
            ,ExecutableObject       NVARCHAR(255)
            )
---- Initialize Log Task Variables ------------
SELECT
       @Log_ExecutableServer      = @@SERVERNAME
      ,@Log_ExecutableDatabase    = DB_NAME()
      ,@Log_ExecutableSchema      = SCHEMA_NAME((SELECT [schema_id] FROM sys.objects WHERE [object_id] = @@PROCID))
      ,@Log_ExecutableObject      = OBJECT_NAME(@@PROCID)
      ,@Task_Description          = 'Load ODS - '
      ,@StepName                  = 'SSIS_Load_BeazleyIntelligenceODS'
      ,@BatchStep_Description     = 'Load Operational DataStore'
      ,@ControlDatabase           = 'BeazleyIntelligence'
      ,@BatchId                   = CAST(RAND() * 1000000 AS INT) 
 
------ Load proc order for ODS ------------
INSERT INTO @ODSLoad 
    (
      ExecutableObject 
    ) 
SELECT StoredProcName 
FROM  [Utility].[ODSStoredProcedureList]
WHERE dependencyLevel IS NOT null
ORDER BY DependencyLevel ASC, PK_ODSStoredProcedureList ASC

/*DEBUG*/  IF @Debug= 1 BEGIN SELECT * FROM @ODSLoad END /*DEBUG*/	

-------------------------------------------
--Validate parameters
IF @p_StartFromProc NOT IN (SELECT ExecutableObject FROM @ODSLoad) 
BEGIN
    SET @Log_ErrorMessage = 'Value "' + COALESCE(@p_StartFromProc,'NULL') + '" is not a valid ods load proc.'
    GOTO ERROR_HANDLING
END

IF  @p_EndAtProc NOT IN (SELECT ExecutableObject FROM @ODSLoad)
BEGIN
    SET @Log_ErrorMessage = 'Value "' + COALESCE(@p_EndAtProc,'NULL') + '" is not a valid ods load proc.'
    GOTO ERROR_HANDLING
END
 
---- Open Manual Batch for @p_ManualBatch = 1  ---------------

IF @p_ManualBatch = 1
BEGIN
    EXECUTE BeazleyIntelligence.Control.usp_Log @LogType  = 'BATCH',@Status  = 'STARTED'    ,@ProcessName = 'BeazleyIntelligence_Load_ODS'
END
     
---- Get current batch details  ---------------
SELECT
       @Log_Process      = procc.PK_Process
      ,@Log_Step_Name    = proccstp.StepName
      ,@Log_Process_Name = procc.ProcessName
      ,@Log_Step         = proccstp.PK_ProcessStep

FROM  [BeazleyIntelligence].[Control].Process procc

INNER JOIN [BeazleyIntelligence].[Control].ProcessVersion vers
ON procc.PK_Process = vers.FK_Process

INNER JOIN [BeazleyIntelligence].[Control].ProcessStep proccstp
ON vers.PK_ProcessVersion = proccstp.FK_ProcessVersion

WHERE vers.IsActiveVersion  = 1
     AND proccstp.StepName  = @StepName

EXEC [BeazleyIntelligence].[Control].[usp_Process_Execution_GetProcessDetails]
 @ProcessName     = @Log_Process_Name
,@ProcessStepName = @Log_Step_Name
,@Batch           = @Log_Batch  OUTPUT


/********************************************************************************/
--                              Execute ODS Procs                              --
/********************************************************************************/
 
-- Initialise variables
SELECT  
     @MinPK_ODSLoad = MIN(PK_ODSLoad)
    ,@MaxPK_ODSLoad = MAX(PK_ODSLoad)
FROM @ODSLoad

SET @PK_ODSLoad_START = ISNULL((SELECT PK_ODSLoad FROM @ODSLoad WHERE ExecutableObject = @p_StartFromProc),@MinPK_ODSLoad)
SET @PK_ODSLoad_END   = ISNULL((SELECT PK_ODSLoad FROM @ODSLoad WHERE ExecutableObject = @p_EndAtProc),@MaxPK_ODSLoad)

-- Declare cursor
DECLARE cursor_list CURSOR LOCAL FORWARD_ONLY FOR
SELECT ExecutableObject
FROM @ODSLoad
WHERE PK_ODSLoad BETWEEN @PK_ODSLoad_START AND @PK_ODSLoad_END
ORDER BY PK_ODSLoad

/*DEBUG*/  IF @Debug= 1 BEGIN SELECT '@PK_ODSLoad_START = ' + CAST(@PK_ODSLoad_START AS VARCHAR),  '@@PK_ODSLoad_END = ' + CAST(@PK_ODSLoad_END AS VARCHAR) END /*DEBUG*/	

DECLARE  @ExecutableObject           NVARCHAR(128)
       
OPEN cursor_list
FETCH NEXT FROM cursor_list INTO @ExecutableObject

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Log_Description = @ExecutableObject + ' proc now running...'

---- Start Logging task
    EXECUTE [BeazleyIntelligence].[Control].[usp_Log]
     @LogType               = 'TASK'
    ,@Status                = 'STARTED'
    ,@Description           = @ExecutableObject
    ,@Process               = @Log_Process
    ,@Batch                 = @Log_Batch
    ,@ExecutableServer      = @Log_ExecutableServer
    ,@ExecutableDatabase    = @Log_ExecutableDatabase
    ,@ExecutableSchema      = @Log_ExecutableSchema
    ,@ExecutableObject      = @Log_ExecutableObject
    ,@TaskLog               = @Log_TaskLog OUTPUT
    ,@ParentTaskLog         = @Log_BatchStepLog


    SET @Log_Description = 'Executing '  + @ExecutableObject

    EXECUTE [BeazleyIntelligence].[Control].[usp_Log]
             @LogType               = 'EVENT'
            ,@Status                = 'PROGRESS'
            ,@Description           = @Log_Description
            ,@Process               = @Log_Process
            ,@Batch                 = @Log_Batch
            ,@ExecutableServer      = @Log_ExecutableServer
            ,@ExecutableDatabase    = @Log_ExecutableDatabase
            ,@ExecutableSchema      = @Log_ExecutableSchema
            ,@ExecutableObject      = @Log_ExecutableObject
            ,@TaskLog               = @Log_TaskLog
            ,@ParentTaskLog         = @Log_TaskLog
 
-- EXECUTE OBJECT AND Utility.OperationalDataStoreLog INSERT

	SET @cmd    =   @ExecutableObject
 
    SET @cmd2   =
    
     ' INSERT INTO Utility.OperationalDataStoreLog 
        ( BatchId
         ,ProcName 
         ,StartDateTime) 
       VALUES (''' + CAST(@BatchId AS NVARCHAR(50)) + ''',''' + @ExecutableObject + ''',GETDATE()) 
     '
	  
	IF @debug = 1
	BEGIN
		PRINT @cmd
		PRINT @cmd2
	END

    EXEC sp_executesql @cmd2
    EXEC sp_executesql @cmd
 
    SET @cmd2   =
    
      ' UPDATE ODSLog 
          SET ODSLog.EndDateTime = GETDATE()
        , ODSLog.ErrorFlag = 0
        
          FROM Utility.OperationalDataStoreLog ODSLog 
          WHERE BatchId=''' + CAST(@BatchId AS NVARCHAR(50)) + ''' AND ProcName='  +  '''' + @ExecutableObject + '''
     '
 

    EXEC sp_executesql @cmd2
 
    EXECUTE [BeazleyIntelligence].[Control].[usp_Log]
             @LogType               = 'TASK'
            ,@Status                = 'SUCCEEDED'
            ,@Description           = @ExecutableObject
            ,@Process               = @Log_Process
            ,@Batch                 = @Log_Batch
            ,@ExecutableServer      = @Log_ExecutableServer
            ,@ExecutableDatabase    = @Log_ExecutableDatabase
            ,@ExecutableSchema      = @Log_ExecutableSchema
            ,@ExecutableObject      = @Log_ExecutableObject
            ,@ParentTaskLog         = @Log_BatchStepLog
            ,@TaskLog               = @Log_TaskLog

	FETCH NEXT FROM cursor_list INTO @ExecutableObject

END

CLOSE cursor_list
DEALLOCATE cursor_list
 
-- Calculate Batch total duration
SET @MinStartDateTime = (SELECT MIN(StartDateTime) FROM Utility.OperationalDataStoreLog WHERE BatchId=@BatchId)
SET @MaxEndDateTime   = (SELECT MAX(EndDateTime)   FROM Utility.OperationalDataStoreLog WHERE BatchId=@BatchId)

INSERT INTO Utility.OperationalDataStoreLog
    ( 
     BatchId         
    ,ProcName
    ,StartDateTime   
    ,EndDateTime     
	,ErrorFlag     
    )

VALUES ( @BatchId
        ,'Total Batch Duration'
        ,@MinStartDateTime
        ,@MaxEndDateTime
        ,0
        )

IF @p_ManualBatch = 1
BEGIN
    EXECUTE BeazleyIntelligence.Control.usp_Log @LogType  = 'BATCH',@Status  = 'SUCCEEDED'    ,@ProcessName = 'BeazleyIntelligence_Load_ODS'
END
     
END TRY

BEGIN CATCH
	SELECT
     @Log_ErrorMessage      = ERROR_MESSAGE()
    ,@Log_ErrorNumber       = ERROR_NUMBER()
    ,@Log_ErrorSeverity     = ERROR_SEVERITY()
    ,@Log_ErrorState        = ERROR_STATE()
    ,@Log_ErrorLine         = ERROR_LINE()
    ,@Log_Description       = COALESCE(@Log_Description,'Error occurred.')

    GOTO ERROR_HANDLING
END CATCH

RETURN 0;

ERROR_HANDLING:
EXECUTE [BeazleyIntelligence].[Control].[usp_Log]
 @LogType               = 'EVENT'
,@Status                = 'ERROR'
,@Description           = @Log_Description
,@ParentTaskLog         = @Log_TaskLog
,@EventDetail           = @Log_Description
,@ErrorMessage          = @Log_ErrorMessage
,@ErrorNumber           = @Log_ErrorNumber
,@ErrorSeverity         = @Log_ErrorSeverity
,@ErrorState            = @Log_ErrorState
,@ErrorLine             = @Log_ErrorLine

EXECUTE [BeazleyIntelligence].[Control].[usp_Log]
 @LogType               = 'TASK'
,@Status                = 'ERRORED'
,@Description           = @Task_Description
,@Process               = @Log_Process
,@Batch                 = @Log_Batch
,@ExecutableServer      = @Log_ExecutableServer
,@ExecutableDatabase    = @Log_ExecutableDatabase
,@ExecutableSchema      = @Log_ExecutableSchema
,@ExecutableObject      = @Log_ExecutableObject
,@TaskLog               = @Log_TaskLog

IF @p_ManualBatch = 1
BEGIN
    EXECUTE BeazleyIntelligence.Control.usp_Log @LogType  = 'BATCH',@Status  = 'ERRORED'    ,@ProcessName = 'BeazleyIntelligence_Load_ODS'
END

SELECT @Log_ErrorMessage = 'Errored proc: ' + @ExecutableObject + '. Error message: "' + @Log_ErrorMessage + '". Error line number: ' + convert(varchar,@Log_ErrorLine) ,@Log_ErrorSeverity = 18,@Log_ErrorState = 1
RAISERROR(@Log_ErrorMessage, @Log_ErrorSeverity, @Log_ErrorState)
RETURN 1;