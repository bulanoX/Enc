﻿

CREATE PROCEDURE [Utility].[usp_LoadSpecialPurposeSyndicateMultiplier]
AS

SET NOCOUNT ON

;WITH PKisYOA (RowNo, YOA, SpecialPurposeSyndicateMultiplier)
AS (SELECT 
  RowNo								= ROW_NUMBER() OVER(PARTITION BY sp.YOA ORDER BY SpecialPurposeSyndicateMultiplier ASC),
  YOA								= sp.YOA, 
  SpecialPurposeSyndicateMultiplier = sp.SpecialPurposeSyndicateMultiplier
FROM Staging_MDS.MDS_Staging.SpecialPurposeSyndicateMultiplier sp
)


MERGE Utility.SpecialPurposeSyndicateMultiplier target
USING
(
SELECT 
  YOA                               = sp.YOA
,SpecialPurposeSyndicateMultiplier  = sp.SpecialPurposeSyndicateMultiplier
FROM PKisYOA sp
WHERE sp.RowNo =1
) source
ON  target.YOA   = source.YOA

WHEN MATCHED THEN 
UPDATE 
SET 
target.SpecialPurposeSyndicateMultiplier     = source.SpecialPurposeSyndicateMultiplier
,target.AuditModifyDateTime                  = GETDATE()
,target.AuditModifyDetails                   = 'Merge in [Utility].[usp_LoadSpecialPurposeSyndicateMultiplier] proc' 
WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
  YOA
 ,SpecialPurposeSyndicateMultiplier
 ,AuditCreateDateTime   
 ,AuditModifyDetails 
 )
 VALUES
 (
   source.YOA
  ,source.SpecialPurposeSyndicateMultiplier
  ,GETDATE()
 ,'New add in [Utility].[usp_LoadSpecialPurposeSyndicateMultiplier] proc'
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE;