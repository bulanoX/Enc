﻿CREATE PROCEDURE [utility].[usp_DropSectionFK]
AS

SET NOCOUNT ON

DECLARE @RowString NVARCHAR(MAX)  

--drop all contraints in order to create a CLUSTERED COLUMNSTORE INDEX
SELECT @RowString = COALESCE(@RowString + '  ', '') + 
'  BEGIN '
 + 'ALTER TABLE [ODS].[SECTION] DROP CONSTRAINT [' + C.CONSTRAINT_NAME + '] END;
 '
--select *
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS C
where c.table_name = 'Section'
and c.TABLE_SCHEMA = 'ODS'
and c.CONSTRAINT_TYPE = 'FOREIGN KEY'

EXEC (@RowString)

CREATE CLUSTERED COLUMNSTORE INDEX [IDX_Section_023] ON [ODS].[Section] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]