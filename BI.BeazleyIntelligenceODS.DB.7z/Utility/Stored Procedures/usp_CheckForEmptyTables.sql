
CREATE PROC [Utility].[usp_CheckForEmptyTables]
@SchemaName NVARCHAR(255)
,@TableName NVARCHAR(255) 

	AS 

	BEGIN

			DECLARE					@sql	NVARCHAR(MAX)
			SELECT					@sql =	CASE 
												WHEN @SchemaName = 'ODS' AND @TableName = 'DataAsAt' 
												THEN	
														'IF NOT EXISTS	(	
																		SELECT COUNT(*) 
																		FROM ' + @SchemaName + '.' + @TableName + ' 
																		HAVING COUNT(*) >= 1
																		) 
														RAISERROR(''Fatal error: The table ' + @SchemaName + '.' + @TableName + ' is empty or contains only default or inactive records!'',16,1 )'
												ELSE	
														'IF NOT EXISTS	(	
																		SELECT COUNT(*) 
																		FROM ' + @SchemaName + '.' + @TableName + ' 
																		HAVING COUNT(*) >= 2
																		) 
														RAISERROR(''Fatal error: The table ' + @SchemaName + '.' + @TableName + ' is empty or contains only default or inactive records!'',16,1 )'
											END
			EXEC sys.sp_executesql	@sql

	END