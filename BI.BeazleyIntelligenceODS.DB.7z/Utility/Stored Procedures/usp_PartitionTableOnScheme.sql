﻿
CREATE PROC [utility].[usp_PartitionTableOnScheme]
(@SchemaName		VARCHAR(100) =  NULL
,@TableName			VARCHAR(100) =  NULL
,@PartitionScheme	VARCHAR(100) =  NULL
,@debug				BIT			 = 0
)

AS

/*
This proc creates a clustered index on the fact table to be partitioned to the partition scheme.
The clustered index is then immediately dropped while the table remains partitioned.
*/

DECLARE @SQL VARCHAR(MAX)

-----------------------------------------------------------------------------
-- Validate parameter values
-----------------------------------------------------------------------------
IF @SchemaName IS NULL OR @TableName IS NULL OR @PartitionScheme IS NULL 
BEGIN
	RAISERROR('One or more of the parameteres are NULL. Assign value to parameter',18,1)
    GOTO ERROR_HANDLING
END

IF @SchemaName  NOT IN (SELECT name FROM sys.schemas)
BEGIN
	RAISERROR('Schema name does not exist',18,1)
    GOTO ERROR_HANDLING
END

IF @TableName  NOT IN (SELECT name FROM sys.tables)
BEGIN
	RAISERROR('Table name does not exist',18,1)
    GOTO ERROR_HANDLING
END

IF @PartitionScheme  NOT IN (SELECT name FROM sys.partition_schemes)
BEGIN
	RAISERROR('Partition Scheme name does not exist',18,1)
    GOTO ERROR_HANDLING
END


SELECT @SQL = 


'-- create temp clustered index on table on partition scheme
IF NOT EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		   WHERE object_schema_name(object_id) = ''' + @SchemaName + ''' AND object_name(object_id) = ''' + @TableName + ''' AND name = ''IDX_PartitionID'')
BEGIN
CREATE CLUSTERED INDEX IDX_PartitionID ON ' + @SchemaName + '.' + @TableName + '(PartitionId) ON ' + @PartitionScheme + '(PartitionId) ;
END
 
-- then drop it
IF EXISTS (SELECT OBJECT_SCHEMA_NAME(object_id), object_name(object_id), name FROM sys.indexes 
		   WHERE object_schema_name(object_id) = ''' + @SchemaName + ''' AND object_name(object_id) = ''' + @TableName + ''' AND name = ''IDX_PartitionID'')
BEGIN
DROP INDEX IDX_PartitionID ON ' + @SchemaName + '.' + @TableName  + '
END
'

IF @debug = 1 
BEGIN 
	PRINT @SQL
END

EXEC (@SQL)
 
RETURN 0;

ERROR_HANDLING:
 
RAISERROR('Fix errors', 18, 1)
RETURN 1;