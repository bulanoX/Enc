﻿
CREATE PROC Utility.usp_PopulateProcQueue
(
@ODSSource   NVARCHAR(10)
)
AS
 
 
	-- RESTART LOAD FROM POINT OF FAILURE ONLY IF SWITCH IS ON

	IF EXISTS (
		SELECT 1 FROM BeazleyIntelligence.control.sourceparameter WHERE TokenName = 'ODS_SSIS_RestartFromPointOfFailure' AND NumericValue = 1
		)

		BEGIN
			IF EXISTS  ( 
				SELECT 1 FROM [Utility].[OperationalDataStoreLog] WHERE EndDateTime IS NULL or ErrorFlag = 1
				)

			BEGIN
				SET IDENTITY_INSERT [Utility].[ODSStoredProcedureQueue] ON 
	
				INSERT [Utility].[ODSStoredProcedureQueue] ([PK_StoredProcedureQueue], [FK_ODSProcId], StoredProcName, DependencyLevel)
				SELECT DISTINCT FK_StoredProcedureList, FK_StoredProcedureList, Procname, DependencyLevel 
				FROM [Utility].[OperationalDataStoreLog]
				WHERE EndDateTime IS NULL or ErrorFlag = 1
	
				SET IDENTITY_INSERT [Utility].[ODSStoredProcedureQueue] OFF

				UPDATE [Utility].[OperationalDataStoreLog] SET EndDateTime = GETDATE(), ErrorFlag = 1 WHERE EndDateTime IS NULL
			
				TRUNCATE TABLE [Utility].[OperationalDataStoreLog]
			END
		END

	-- RESTART LOAD FROM BEGINNING

	ELSE 

		BEGIN 


			TRUNCATE TABLE [Utility].[OperationalDataStoreLog]

			TRUNCATE TABLE  [Utility].[ODSStoredProcedureQueue] -- select * from [staging].[ProcQueue] 

			INSERT INTO  [Utility].[ODSStoredProcedureQueue]
				(
				[FK_ODSProcId]
				,[StoredProcName]		
				,[PartitionId]	
				,[DependencyLevel]
				)
  
			SELECT
				 FK_ODSProcId		= pl.PK_ODSStoredProcedureList
				,StoredProcName			= pl.StoredProcName
				,PartitionId		= 0
				,pl.DependencyLevel
			FROM  [Utility].[ODSStoredProcedureList] pl
			WHERE pl.ActiveFlag = 1
			      AND pl.ODSSource = @ODSSource
			ORDER BY pl.DependencyLevel  , pl.PK_ODSStoredProcedureList
		END
 
	/*

	SELECT * FROM [Utility].[ODSStoredProcedureQueue]
	SELECT * FROM [Utility].[OperationalDataStoreLog]

	*/