﻿
 
 
CREATE PROC [Utility].[usp_LogOperationalDataStore]
(@BatchId			VARCHAR(100)	= NULL
,@ErrorFlag			SMALLINT		= NULL
,@Procname			VARCHAR(100)	= NULL
,@ErrorDescription	VARCHAR(MAX)	= ''
)
AS

/*  
	This proc is used within the SSIS load ODS package.
	It simply updates the utility.OperationalDataStoreLog table
*/

SET NOCOUNT ON 

IF @ErrorFlag = 0
BEGIN
	 UPDATE  
		[Utility].[OperationalDataStoreLog]
	SET   
		EndDateTime = GETDATE()
	WHERE  
		[ProcName] = @Procname 
		AND BatchId = @BatchId 
		AND EndDateTime IS NULL
END	
 
IF @ErrorFlag = 1
BEGIN
	UPDATE  
		[Utility].[OperationalDataStoreLog]
	SET  
		ErrorFlag		= 1,
		EndDateTime			= GETDATE(),
		ErrorDescription= @ErrorDescription 
	WHERE	
		ProcName = @Procname
		AND BatchID = @BatchId  
END