﻿CREATE PROCEDURE [Utility].[usp_LoadCurrencyRate]
AS

SET NOCOUNT ON

DROP TABLE IF EXISTS #CurrencyRate

CREATE TABLE #CurrencyRate
(
	[RateType] [varchar](255) NOT NULL,
	[Currency] [varchar](255) NOT NULL,
	[ExchangeRate] [numeric](38, 12) NOT NULL
)


/*Current rates and Latest spot rates from Eurobase*/
INSERT INTO #CurrencyRate
(   
    RateType
    ,Currency
    ,ExchangeRate
)
SELECT
RateType			= RateType	
,Currency			= Currency	
,ExchangeRate		= ExchangeRate
FROM
Staging_MDS.dbo.vw_currency_rates


/*Marine RI Rates*/
INSERT INTO #CurrencyRate
(
    RateType
    ,Currency
    ,ExchangeRate
)
VALUES
('Marine Reinsurance', 'USD', 2)
,('Marine Reinsurance', 'EUR', 2)
,('Marine Reinsurance', 'CAD', 2)
,('Marine Reinsurance', 'GBP' , 1)


/*Claim Authority Limit Rates*/
INSERT INTO #CurrencyRate
(   
     RateType
    ,Currency
    ,ExchangeRate
)
SELECT
 RateType            = 'Claim Authority Limit'
,Currency            = curr.[Name]
,ExchangeRate        = curr.ExchangeRate

FROM Staging_MDS.MDS_Staging.ClaimAuthorityLimitCurrencyRate curr

WHERE curr.ExchangeRate > 0


;MERGE [Utility].[CurrencyRate]  AS Target
USING #CurrencyRate as Source
ON  Source.RateType = Target.RateType
AND Source.Currency = Target.Currency

WHEN MATCHED THEN UPDATE
SET Target.ExchangeRate               = Source.ExchangeRate,
    Target.AuditModifyDateTime	      = GETDATE(),						
    Target.AuditModifyDetails	      = 'Merge in [Utility].[usp_LoadCurrencyRate] proc'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT 
( RateType,
  Currency,
  ExchangeRate,
  AuditCreateDateTime,	 
  AuditModifyDetails	
)
VALUES
(Source.RateType,
 Source.Currency,
 Source.ExchangeRate,
 GETDATE(),
 'New add in [Utility].[usp_LoadCurrencyRate] proc'
);


/*PIM Rates*/

;MERGE [Utility].[CurrencyRateYOA]  AS Target
USING (
			SELECT
			RateType            = 'PIM'
			,Currency           = pr.Currency
			,YOA                = pr.YOA
			,ExchangeRate       = pr.[£ROE]
			FROM
			Staging_Datamart.Datamart_Staging.PIMROE pr
			UNION ALL
			SELECT
			RateType            = 'Lloyds'
			,Currency           = l.CCY
			,YOA                = l.YOA
			,ExchangeRate       = l.RoeToGBP
			FROM
			Staging_Datamart.Datamart_Staging.PMD_Lloyds_ROE l
)AS Source
ON  Source.RateType = Target.RateType
AND Source.Currency = Target.Currency
AND Source.YOA      = Target.YOA


WHEN MATCHED THEN UPDATE
SET Target.ExchangeRate               = Source.ExchangeRate,
    Target.AuditModifyDateTime	      = GETDATE(),						
    Target.AuditModifyDetails	      = 'Merge in [Utility].[usp_LoadCurrencyRate] proc'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT 
(    RateType,
     Currency,
     YOA,
     ExchangeRate,
	 AuditCreateDateTime,	 
     AuditModifyDetails	
)
VALUES
( Source.RateType,
  Source.Currency,
  Source.YOA,
  Source.ExchangeRate,
  GETDATE(),
 'New add in [Utility].[usp_LoadCurrencyRate] proc'
);


/*Currency rate history*/

;MERGE [Utility].[CurrencyRateHistory]  AS Target
USING (SELECT
		RateType                        = 'Current'
		,Currency                       = c1.Currency
		,StartDate                      = c1.EffectiveDate
		,EndDate                        = DATEADD(DAY, - 1, c2.EffectiveDate)
		,ExchangeRate                   = c1.ExchangeRate
		FROM
		Staging_MDS.dbo.vw_currency_rates_hist c1
		LEFT OUTER JOIN
		Staging_MDS.dbo.vw_currency_rates_hist c2 ON
		c1.Currency = c2.Currency
		AND c1.SequenceId + 1 = c2.SequenceId
) AS Source

ON  Source.RateType  = Target.RateType
AND Source.Currency  = Target.Currency
AND Source.StartDate = Target.StartDate

WHEN MATCHED THEN UPDATE
SET TARGET.EndDate                    = Source.EndDate,
    Target.ExchangeRate               = Source.ExchangeRate,
    Target.AuditModifyDateTime	      = GETDATE(),						
    Target.AuditModifyDetails	      = 'Merge in [Utility].[usp_LoadCurrencyRate] proc'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(    RateType,
     Currency,
     StartDate,
     EndDate,
     ExchangeRate,
	 AuditCreateDateTime,	 
     AuditModifyDetails	
)
VALUES
(
   Source.RateType,
   Source.Currency,
   Source.StartDate,
   Source.EndDate,
   Source.ExchangeRate,
   GETDATE(),
   'New add in [Utility].[usp_LoadCurrencyRate] proc'
);


/*Melded rates*/
DROP TABLE IF EXISTS #SectionMeldedRate

CREATE TABLE #SectionMeldedRate
(
	[Currency] [varchar](255) NOT NULL,
	[SectionReference] [varchar](255) NOT NULL,
	[RateIdentifier] [varchar](255) NOT NULL,
	[MeldedRate] [numeric](38, 12) NOT NULL
)

INSERT INTO #SectionMeldedRate
(
    Currency
    ,RateIdentifier
    ,SectionReference
    ,MeldedRate
)
SELECT 	Currency               
		,RateIdentifier        
		,SectionReference      
		,MeldedRate            
FROM
Staging_MDS.dbo.vw_melded_rate m 
WHERE
m.RateIdentifier IN ('MEL', 'MEC', 'MRL', 'MRC')

/*Delete 'MEC' WHERE 'MEL' exists*/
DELETE sm
FROM #SectionMeldedRate sm
WHERE sm.RateIdentifier = 'MEC'
AND EXISTS
(
    SELECT 1
    FROM #SectionMeldedRate sm1 
	WHERE sm.SectionReference = sm1.SectionReference
    AND sm.Currency = sm1.Currency
    AND sm1.RateIdentifier = 'MEL'
)

/*Delete 'MRC' WHERE 'MRL' Exists*/
DELETE sm
FROM #SectionMeldedRate sm
WHERE sm.RateIdentifier = 'MRC'
AND EXISTS
(
    SELECT 1
    FROM #SectionMeldedRate sm1 
	WHERE sm.SectionReference = sm1.SectionReference
    AND sm.Currency = sm1.Currency
    AND sm1.RateIdentifier = 'MRL'
)

;MERGE [Utility].[SectionMeldedRate]  AS Target
USING #SectionMeldedRate as Source
ON  Source.Currency         = Target.Currency
AND Source.SectionReference = Target.SectionReference
AND Source.RateIdentifier   = Target.RateIdentifier

WHEN MATCHED THEN UPDATE
SET Target.MeldedRate                 = Source.MeldedRate,
    Target.AuditModifyDateTime	      = GETDATE(),						
    Target.AuditModifyDetails	      = 'Merge in [Utility].[usp_LoadCurrencyRate] proc'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
 Currency,
 SectionReference,
 RateIdentifier,
 MeldedRate,
 AuditCreateDateTime,
 AuditModifyDetails
)
VALUES
(
 SOURCE.Currency,
 SOURCE.SectionReference,
 SOURCE.RateIdentifier,
 SOURCE.MeldedRate,
 GETDATE(),
 'New add in [Utility].[usp_LoadCurrencyRate] proc'
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'Utility', @TableName = 'CurrencyRate';