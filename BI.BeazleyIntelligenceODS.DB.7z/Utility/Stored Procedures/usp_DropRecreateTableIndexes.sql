﻿
CREATE PROC Utility.usp_DropRecreateTableIndexes
(@TableName VARCHAR(255)
,@Action	VARCHAR (20)
,@SchemaName VARCHAR(255) = NULL
)

AS
-- Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'CREATE'

DECLARE @SQL1 VARCHAR(MAX)

--drop index and recreate it in the last usp in ODS
IF @Action = 'DROP' AND @TableName = 'Section' AND @SchemaName = 'ODS'
DROP INDEX IF EXISTS [IDX_Section_023] ON [ODS].[Section]

--1. get all indexes from current db, table

INSERT   Utility.ODSIndexes
   (
     SchemaName		
	,TableName		
	,TableId		
	,IndexId		
	,IndexName		
	,IsUnique		
	,IsClustered	
	,IndexFillFactor
	)
SELECT
	schemaName	= s.name,
	tablename	= object_name(i.id),
	tableid		= i.id,
	indexid		= i.indid,
	indexname	= i.name,
	isunique	= indexproperty (i.id,i.name,'isunique'),
	isclustered = indexproperty (i.id,i.name,'isclustered'),
	indexfillfactor = indexproperty (i.id,i.name,'indexfillfactor')

FROM sysindexes i
INNER JOIN	sys.tables t ON i.id = t.object_id
INNER JOIN	sys.schemas s ON t.schema_id = s.schema_id
WHERE 
(i.status & 64) = 0                                 --existing indexes
and  object_name(i.id) = @TableName
and i.name is not null
AND NOT EXISTS (SELECT * FROM Utility.ODSIndexes a WHERE a.TableName = @TableName and a.Indexname = i.name 
					AND ISNULL(@schemaname, 'ODS') = a.SchemaName
				)
AND ISNULL(@schemaname, 'ODS') = s.Name
--add additional columns to store include and key column lists
 
 
--################################################################################################
--2. loop through table indexes, put include and index columns into variables
DECLARE @isql_key VARCHAR(4000), @isql_incl VARCHAR(4000), @tableid int, @indexname VARCHAR(4000)

DECLARE index_cursor CURSOR FOR

SELECT tableid, indexname FROM Utility.ODSIndexes  o
INNER JOIN sys.indexes i ON i.name =o.IndexName and i.object_id = o.TableId

OPEN index_cursor

FETCH NEXT FROM index_cursor INTO @tableid, @indexname

WHILE @@fetch_status <> -1

BEGIN
    
	SELECT @isql_key = '', @isql_incl = ''
  
	SELECT --i.name, sc.colid, sc.name, ic.index_id, ic.object_id, *
	--key column
	@isql_key = CASE ic.is_included_column 
				WHEN 0 THEN
						case ic.is_descending_key 
							WHEN 1 THEN @isql_key + coalesce(sc.name,'') + ' DESC, '
							ELSE        @isql_key + coalesce(sc.name,'') + ' ASC, '
						end
				ELSE @isql_key 
				END,
        
	--include column
	@isql_incl = case ic.is_included_column 
				WHEN 1 THEN
				CASE ic.is_descending_key 
				WHEN 1 THEN @isql_incl + coalesce(sc.name,'') + ', '
				ELSE @isql_incl + coalesce(sc.name,'') + ', '
				END
				ELSE @isql_incl 
				END
	FROM sysindexes i
	INNER JOIN sys.index_columns AS ic ON (ic.column_id > 0 and (ic.key_ordinal > 0 or ic.partition_ordinal = 0 or ic.is_included_column != 0)) AND (ic.index_id=CAST(i.indid AS int) AND ic.object_id=i.id)
	INNER JOIN sys.columns AS sc ON sc.object_id = ic.object_id and sc.column_id = ic.column_id
	WHERE -- i.indid > 0 and i.indid < 255 and
			(i.status & 64) = 0
			and i.id = @tableid and i.name = @indexname
			order by i.name, case ic.is_included_column WHEN 1 THEN ic.index_column_id ELSE ic.key_ordinal end
   
	IF len(@isql_key) > 1    set @isql_key   = left(@isql_key,  len(@isql_key) -1)
	IF len(@isql_incl) > 1   set @isql_incl  = left(@isql_incl, len(@isql_incl) -1)
  
	UPDATE Utility.ODSIndexes 
	SET  keycolumns = @isql_key
		,includes = @isql_incl
	WHERE tableid = @tableid and IndexName = @indexname 
		  
 
	UPDATE Utility.ODSIndexes
	SET  
		 DropSQL = 
		
				'IF EXISTS ('+
				'SELECT * FROM sys.indexes i ' +
				'INNER JOIN sys.objects o ON o.object_id = i.object_id ' +
				'WHERE OBJECT_NAME(i.object_id) = ''' + TABLENAME + ''' AND i.name = ''' + INDEXNAME + ''''+
				' AND SCHEMA_NAME(o.schema_id) = ''' + ISNULL(@schemaname, 'ODS') +
				''')' + 
				' BEGIN ' +  
				'	DROP INDEX [' + SchemaName + '].[' + TABLENAME + '].[' + INDEXNAME + ']' +
				' END; '

		,CreateSQL = 

				'IF NOT EXISTS ('+
				'SELECT * FROM sys.indexes i ' +
				'INNER JOIN sys.objects o ON o.object_id = i.object_id ' +
				'WHERE OBJECT_NAME(i.object_id) = ''' + TABLENAME + ''' AND i.name = ''' + INDEXNAME + ''''+
				' AND SCHEMA_NAME(o.schema_id) = ''' + ISNULL(@schemaname, 'ODS') +
				''')' + 
				' BEGIN ' +  
				' CREATE ' 
					+ CASE WHEN ISUNIQUE    = 1 THEN 'UNIQUE ' ELSE '' END 
					+ CASE WHEN ISCLUSTERED = 1 THEN 'CLUSTERED ' ELSE '' END 
					+ 'INDEX [' + INDEXNAME + ']' 
					+' ON [' + schemaName + '].[' + TABLENAME + '] '
					+ '(' + keycolumns + ')' 
					+ CASE 
						WHEN INDEXFILLFACTOR = 0 AND ISCLUSTERED = 1 AND INCLUDES = '' THEN '' 
						WHEN INDEXFILLFACTOR = 0 AND ISCLUSTERED = 0 AND INCLUDES = '' THEN ' WITH (ONLINE = ON)' 
						WHEN INDEXFILLFACTOR <> 0 AND ISCLUSTERED = 0 AND INCLUDES = '' THEN ' WITH (ONLINE = ON)'
						WHEN INDEXFILLFACTOR = 0 AND ISCLUSTERED = 0 AND INCLUDES <> '' THEN ' INCLUDE (' + INCLUDES + ') WITH (ONLINE = ON)'
						ELSE ' INCLUDE (' + INCLUDES + ')  WITH (ONLINE = ON)'
	
						END +
				' END; '
	FROM Utility.ODSIndexes
	WHERE left(tablename,3) not in ('sys', 'dt_') --exclude system tables
	AND isunique = 0 
	and isclustered = 0
	AND tableid = @tableid and IndexName = @indexname 




	FETCH NEXT FROM index_cursor into @tableid,@indexname

END

CLOSE index_cursor
DEALLOCATE index_cursor

--remove invalid indexes,ie ones without key columns
--DELETE FROM Utility.ODSIndexes WHERE keycolumns = ''
--################################################################################################
  
  
SET NOCOUNT OFF
 
--SELECT * FROM Utility.ODSIndexes



	IF @Action = 'DROP'
	BEGIN 
		--SELECT @SQL1 = DropSQL FROM Utility.ODSIndexes WHERE tableid = @tableid and indexid = @indexid
		--PRINT @SQL1
		--EXEC (@SQL1)

		SELECT @SQL1 = COALESCE(@SQL1 + '  ', '') + 
		DropSQL 
		FROM Utility.ODSIndexes 
		WHERE tablename = @TableName
			AND ISNULL(@schemaname, 'ODS') = SchemaName
		--PRINT (@SQL1)
		EXEC (@SQL1)

	END

	IF @Action = 'CREATE'
	BEGIN 
		--SELECT @SQL1 = CreateSQL FROM Utility.ODSIndexes WHERE tableid = @tableid and indexid = @indexid
		--PRINT @SQL1
		--EXEC (@SQL1)
	
	
		SELECT @SQL1 = COALESCE(@SQL1 + '  ', '') + 
		CreateSQL 
		FROM Utility.ODSIndexes 
		WHERE tablename = @TableName
			AND ISNULL(@schemaname, 'ODS') = SchemaName
		--PRINT (@SQL1)
		EXEC (@SQL1)
	END


-- drop table Utility.ODSIndexes