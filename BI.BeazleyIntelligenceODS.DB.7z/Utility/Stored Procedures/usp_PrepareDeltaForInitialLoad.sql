﻿
CREATE PROCEDURE [Utility].[usp_PrepareDeltaForInitialLoad]
AS


BEGIN


IF (
		SELECT NumericValue 
		FROM BeazleyIntelligence.[Control].[SourceParameter] 
		WHERE TokenName = 'ODS_SSIS_RestartFromPointOfFailure') <> 1 BEGIN


-- DROP CONSTRAINTS  
EXEC Utility.DropConstraints


--TRUNCATE TABLES
DECLARE		@TruncateTables nvarchar(max) = ''

SELECT		@TruncateTables = @TruncateTables + char(13) + 
								CONCAT('TRUNCATE TABLE ', TABLE_SCHEMA, '.', TABLE_NAME, ';')
FROM		INFORMATION_SCHEMA.TABLES
WHERE       (
				(
					TABLE_SCHEMA = 'ODS' 
					--REMOVE STATIC DATA
					AND TABLE_NAME NOT IN (
											'AccountingCalendar', 
											'ClaimIncurredBand', 
											'ClaimQuantifiedStatus',
											'ControlQuestionType',
											'DimDate',
											'DurationBand',
											'EntityPerspective',
											'HiddenStatusFilter',
											'InternalWrittenBinderStatus',
											'LocalCurrency',
											'QuoteFilter',
											'SettlementCurrency',
											'WorkflowCycle'
											) 
					)
				OR 
				( 
					TABLE_SCHEMA = 'RED' 
					AND TABLE_NAME NOT IN (
											'AcquisitionCostBasis', 
											'RateType', 
											'ReportingCurrencyOverride',
											'ShareType',
											'SpecialPurposeSyndicateBasis'
											)
					)
				OR 
				( 
					TABLE_SCHEMA = 'Staging' 
					AND TABLE_NAME NOT IN (
											'BeazleyOfficeLocationCountry', 
											'BeazleyOfficeLocationRegion', 
											'BinderBeazleyOfficeLocation',
											'PartitionMap',
											'SectionBeazleyOfficeLocation',
											'SourceSystemBeazleyOfficeLocation',
											'UnderwriterBeazleyOfficeLocation',
											'PartitionMap'
											)
					)
				OR 
				( 
					TABLE_SCHEMA = 'Utility' 
					AND TABLE_NAME NOT IN (
											'ClaimExposureSection_Legacy', 
											'ClaimMovementline_Legacy', 
											'ClientClassificationBase',
											'Constraints',
											'ListOfColumnsToTrim',
											'ODSIndexes',
											'ODSStoredProcedureDependency',
											'ODSStoredProcedureList',
											'ODSStoredProcedureQueue',
											'OperationalDataStoreLog',
											'YearBuiltBand'

											)
					)
            )    
			AND TABLE_TYPE = 'BASE TABLE'
ORDER BY    TABLE_SCHEMA, TABLE_NAME

--print @TruncateTables
EXEC        sp_executesql @TruncateTables


-- CREATE CONSTRAINTS 
EXEC Utility.CreateConstraints


END

END