﻿
 
CREATE PROCEDURE [Utility].[usp_WaitForSeconds] (@NumberOfSeconds INT = NULL ) 
AS

SET NOCOUNT ON;

DECLARE @HHMMSS varchar(20)

IF @NumberOfSeconds IS NULL
BEGIN

	WAITFOR DELAY '00:00:05.000'

END

ELSE 
BEGIN

	SELECT @HHMMSS =   CONVERT(varchar, DATEADD(ss, @NumberOfSeconds, 0), 108)
	WAITFOR DELAY @HHMMSS

END