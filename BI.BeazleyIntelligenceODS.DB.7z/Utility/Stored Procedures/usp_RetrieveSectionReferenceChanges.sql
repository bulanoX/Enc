﻿

CREATE PROCEDURE [Utility].[usp_RetrieveSectionReferenceChanges]
AS

SELECT
OldReference                = x.OldReference
,NewReference               = x.NewReference
,DateChanged                = x.DateChanged
FROM
(
    SELECT
    OldReference            = rl.ref_old_reference
    ,NewReference           = rl.ref_new_reference
    ,DateChanged            = rl.ref_update_date
    ,SequenceId             = ROW_NUMBER() OVER (
                                            PARTITION BY rl.ref_old_reference
                                            ORDER BY rl.ref_update_date DESC, rl.ref_new_reference)
    FROM
    Staging_Eurobase.Eurobase_Staging.reference_log rl
    WHERE
    rl.ref_type = 'POL'
) x
WHERE
x.SequenceId = 1