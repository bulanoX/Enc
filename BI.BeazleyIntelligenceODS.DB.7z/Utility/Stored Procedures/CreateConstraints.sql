﻿
CREATE PROC Utility.CreateConstraints
AS

--EXEC sp_MSforeachtable @command1="ALTER TABLE ? NOCHECK CONSTRAINT ALL"
 

-- CREATE CONSTRAINTS WHERE NOT EXISTS 
DECLARE @RowString VARCHAR(MAX)  SELECT @RowString = COALESCE(@RowString + '  ', '') + 
'
 ' + CreateSql  
 
FROM Utility.Constraints C
LEFT OUTER JOIN Utility.vw_ForeignKey vfk
ON  vfk.ForeignKeyName = c.ForeignKeyName AND 
	vfk.ReferencingTableSchema = c.ReferencingTableSchema AND
	vfk.ReferencingTableName = c.ReferencingTableName 
WHERE vfk.ForeignKeyName is NULL
--PRINT (@RowString)
EXEC (@RowString)