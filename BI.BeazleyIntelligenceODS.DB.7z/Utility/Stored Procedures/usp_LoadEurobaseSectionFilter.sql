﻿


CREATE PROC [Utility].[usp_LoadEurobaseSectionFilter]
AS

SET NOCOUNT ON

/*
Filtering rules - we bring into the ODS all records:
 - Which are quotes
 OR
 - Which have statuses of 'L', 'R', 'C', 'B', 'T', 'U', 'Z' or 'P'
        AND 
            - Where the inception date is on or after 1/1/1993
            OR 
            - There is an LPSO transaction with a YOA on or after 1993
            OR 
            - There is a claim with a YOA on or after 1993
*/


MERGE Utility.EurobaseSectionFilter target
USING
(SELECT
SectionReference            = SectionReference
FROM Staging_MDS.dbo.vw_SectionFilter
) source
ON  target.SectionReference   = source.SectionReference

WHEN MATCHED THEN 
UPDATE 
SET 
target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails         = 'Merge in [Utility].[usp_LoadEurobaseSectionFilter] proc' 
WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
  SectionReference
 ,AuditCreateDateTime   
 ,AuditModifyDetails 
 )
 VALUES
 (
  source.SectionReference
  ,GETDATE()
 ,'New add in [Utility].[usp_LoadEurobaseSectionFilter] proc'
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE;