﻿CREATE PROCEDURE Utility.usp_PreLoadODSValidation
AS BEGIN
	--check prerequisites of the ODS Load
	exec Utility.usp_PrePostLoadODSValidation @PreOrPost='PRE';
END;