﻿
CREATE FUNCTION [Utility].[udf_ConvertTitleCase]
(
    @StringIn               varchar(8000)
    ,@AlwaysUpper           varchar(8000) --Tilde separated list of values which should always be in caps
    ,@AlwaysLower           varchar(8000) --Tilde separated list of values which should alwyas be lower case
)

RETURNS varchar(8000)

WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

    DECLARE @NumChars int
    DECLARE @Counter int
    DECLARE @Result varchar(8000)
    
    
    DECLARE @CurrentChar char(1)
    DECLARE @PreviousChar char(1)
    DECLARE @Holder varchar(8000)
    
    SET @NumChars = LEN(@StringIn)
    SET @Counter = 1
    SET @Result = ''
    
    --Convert to title case
    WHILE (@Counter < @NumChars + 1)
    BEGIN
    
        SET @PreviousChar = @CurrentChar
        SET @CurrentChar = SUBSTRING(@StringIn, @Counter, 1)
        
        IF (@PreviousChar IS NULL OR @PreviousChar IN (' ', '.', '-', '&','(', '/'))
        BEGIN
            SET @CurrentChar = UPPER(@CurrentChar)
        END
        ELSE
        BEGIN
            SET @CurrentChar = LOWER(@CurrentChar)
        END
            
        SET @Result = @Result + @CurrentChar
        SET @Counter = @Counter + 1
        
    END
    
    --Loop through "AlwaysUpper" values and convert to upper case
    SET @Counter = 1
    SET @NumChars = LEN(@AlwaysUpper)
    
    SET @Holder = ''
    
    WHILE (@Counter < @NumChars + 1)
    BEGIN
        SET @CurrentChar = SUBSTRING(@AlwaysUpper, @Counter, 1)
        
        IF (@CurrentChar <> '~')
        BEGIN
            SET @Holder = @Holder + @CurrentChar
        END
        IF (@CurrentChar = '~' OR @Counter = @NumChars)
        BEGIN
            SET @Result = REPLACE(@Result, @Holder, UPPER(@Holder))
            SET @Holder = ''
        END
        
        SET @Counter = @Counter + 1
    END
    
        --Loop through "AlwaysLower" values and convert to lower case
    SET @Counter = 1
    SET @NumChars = LEN(@AlwaysLower)
    
    SET @Holder = ''
    
    WHILE (@Counter < @NumChars + 1)
    BEGIN
        SET @CurrentChar = SUBSTRING(@AlwaysLower, @Counter, 1)
        
        IF (@CurrentChar <> '~')
        BEGIN
            SET @Holder = @Holder + @CurrentChar
        END
        IF (@CurrentChar = '~' OR @Counter = @NumChars)
        BEGIN
            SET @Result = REPLACE(@Result, @Holder, LOWER(@Holder))
            SET @Holder = ''
        END
        
        SET @Counter = @Counter + 1
    END
    
    RETURN @Result
    
END