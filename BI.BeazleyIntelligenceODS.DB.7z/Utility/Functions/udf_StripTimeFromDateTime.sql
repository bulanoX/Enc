﻿
CREATE FUNCTION [Utility].[udf_StripTimeFromDateTime]
(
    @DateValue       datetime
)

RETURNS datetime

WITH RETURNS NULL ON NULL INPUT 


BEGIN

    RETURN DATEADD(dd, DATEDIFF(dd, 0, @DateValue), 0)  
        
END