﻿CREATE FUNCTION [Utility].[udf_ComputeIdentity]
(@Input NVARCHAR (MAX) NULL, @IsUnknownMember BIT NULL)
RETURNS BIGINT
AS
 EXTERNAL NAME [BeazleyIntelligenceODSCLR].[Functions].[ComputeIdentity]

