﻿
CREATE FUNCTION [Utility].[udf_GenerateDateKey]
(
    @DateValue       datetime
)

RETURNS datetime

/*Required for SQL to label the 
UDF deterministic so it can be used in a persisted computed column*/
WITH SCHEMABINDING 


BEGIN

    /*SQL treats 'cast' and 'convert' as nondetermenistic when the target is a datetime type
    so we need to avoid using these functions here in order to be able to call this function from
    a persisted computed column*/
    

    --Return N/A key ('1/1/1753') on NULL or out of range
    IF (@DateValue IS NULL OR YEAR(@DateValue) < 1990 OR YEAR(@DateValue) > 2050)
    BEGIN
        RETURN DATEADD(DAY, -53690, 0)
    END
    
    --Otherwise, return date element stripped of time element
    RETURN DATEADD(DAY, DATEDIFF(DAY, 0, @DateValue), 0)
    
END