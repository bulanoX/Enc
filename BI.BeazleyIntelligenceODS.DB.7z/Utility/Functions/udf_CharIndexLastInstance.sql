﻿
CREATE FUNCTION [Utility].[udf_CharIndexLastInstance]
(
    @StringToFind       varchar(8000)
    ,@StringToSearch    varchar(MAX)
)

RETURNS VARCHAR(8000)

WITH RETURNS NULL ON NULL INPUT

BEGIN

    IF CHARINDEX(@StringToFind, @StringToSearch) = 0
    BEGIN
        RETURN 0
    END

    DECLARE @r1 varchar(8000)
    DECLARE @r2 varchar(8000)
    
    SET @r1 = REVERSE(@StringToFind)
    SET @r2 = REVERSE(@StringToSearch)
    
    DECLARE @Index int
    
    SET @Index = CHARINDEX(@r1, @r2)
    
    RETURN LEN(@StringToSearch) - LEN(@StringToFind) - @Index + 2
    
END