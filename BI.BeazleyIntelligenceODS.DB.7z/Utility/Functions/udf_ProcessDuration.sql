﻿
CREATE FUNCTION [Utility].[udf_ProcessDuration]
(
     @StartDateTime         datetime
    ,@EndDateTime           datetime
)

RETURNS NVARCHAR(50)

WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

DECLARE @MinDateTime datetime
DECLARE @MaxDateTime datetime

--Change date format to yyyy-mmm-dd so there is not confusion between yyyy-mm-dd and yyyy-dd-mm
-- Removed, we do not think this is doing anything as the input params are already datetime
-- SET @StartDateTime = (SELECT CONVERT(NVARCHAR(50),@StartDateTime,113)) 
-- SET @EndDateTime   = (SELECT CONVERT(NVARCHAR(50),@EndDateTime,113))

-- Reverse the dates if the start date is greater than the enddate
    SET @MinDateTime = (SELECT CASE WHEN @StartDateTime <= @EndDateTime   THEN @StartDateTime ELSE @EndDateTime   END)
    SET @MaxDateTime = (SELECT CASE WHEN @EndDateTime   >= @StartDateTime THEN @EndDateTime   ELSE @StartDateTime END)

RETURN 

-- If the difference is greater than 99h return just +99 
       CASE WHEN DATEDIFF(HOUR,@MinDateTime,@MaxDateTime)>99 THEN '+ 99h'
            ELSE
                     RIGHT('00' + CAST((DATEDIFF(SECOND,@MinDateTime,@MaxDateTime)) / 3600 AS NVARCHAR(255)),2) + ':' 
                   + RIGHT('00' + CAST((DATEDIFF(SECOND,@MinDateTime,@MaxDateTime)) % 3600 / 60 AS NVARCHAR(255)),2) + ':'  
                   + RIGHT('00' + CAST((DATEDIFF(SECOND,@MinDateTime,@MaxDateTime)) % 60 AS NVARCHAR(255)),2)
       END
       
END