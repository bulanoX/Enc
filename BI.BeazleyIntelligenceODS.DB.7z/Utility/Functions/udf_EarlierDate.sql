﻿
CREATE FUNCTION [Utility].[udf_EarlierDate]
(
    @Date1                  datetime
    ,@Date2                 datetime
)

RETURNS datetime

BEGIN

    RETURN CASE 
        WHEN @Date1 < @Date2 THEN @Date1
        WHEN @Date2 < @Date1 THEN @Date2
        ELSE ISNULL(@Date1, @Date2)
    END

END