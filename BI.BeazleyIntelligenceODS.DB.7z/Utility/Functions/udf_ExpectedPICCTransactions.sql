﻿
CREATE FUNCTION [Utility].[udf_ExpectedPICCTransactions]
(
    @InceptionDate      datetime
    ,@DurationInMonths  int
    ,@AsAtDate          datetime
)
RETURNS int

WITH RETURNS NULL ON NULL INPUT 

AS
BEGIN

/*
 - The first PICC transaction is expected 3 months from the 1st of the month of the inception date.
 - Another PICC transaction is expected every month thereafter
 - The minimum number of expected PICC transactions is 0 (i.e. cannot be negative)
 - The maximum number of expected PICC transactions is the duration of section in months
*/

DECLARE @FirstOfInceptionMonth datetime
SET @FirstOfInceptionMonth =  DATEADD(DAY, -DAY(@InceptionDate) + 1, @InceptionDate)

DECLARE @FirstExpectedTransaction datetime
SET @FirstExpectedTransaction = DATEADD(MONTH, 3, @FirstOfInceptionMonth)

IF (@FirstExpectedTransaction > @AsAtDate)
BEGIN
    RETURN 0
END

DECLARE @ExpectedTransactions int
SET @ExpectedTransactions = DATEDIFF(MONTH, @FirstExpectedTransaction, @AsAtDate) + 1

RETURN Utility.udf_LesserOf(@ExpectedTransactions, @DurationInMonths)

END