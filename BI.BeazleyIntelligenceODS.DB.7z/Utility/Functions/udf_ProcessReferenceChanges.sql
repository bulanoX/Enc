﻿CREATE FUNCTION [Utility].[udf_ProcessReferenceChanges]
( )
RETURNS 
     TABLE (
        [OldReference]         NVARCHAR (4000) NULL,
        [UltimateNewReference] NVARCHAR (4000) NULL,
        [UltimateDepth]        INT             NULL,
        [CyclesDetected]       BIT             NULL)
AS
 EXTERNAL NAME [BeazleyIntelligenceODSCLR].[Functions].[ProcessReferenceChanges]



