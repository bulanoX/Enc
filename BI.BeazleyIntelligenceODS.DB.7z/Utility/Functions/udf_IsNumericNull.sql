﻿
CREATE FUNCTION [Utility].[udf_IsNumericNull]
(
    @ValueIn       NVARCHAR(255)
)

RETURNS NVARCHAR(255)

WITH RETURNS NULL ON NULL INPUT

BEGIN

    RETURN 
    CASE WHEN ISNUMERIC(@ValueIn) = 1
        THEN @ValueIn 
        ELSE NULL        
    END
        
END