﻿
CREATE FUNCTION [Utility].[udf_ProcessString]
(
    @StringIn               varchar(8000)
    ,@ReturnNullOnEmpty     bit
)

RETURNS varchar(8000)

WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

    DECLARE @Result varchar(8000)
    SET @Result = LTRIM(RTRIM(REPLACE(REPLACE(@StringIn, CHAR(9), ' '), CHAR(13), '')))
    
    RETURN 
    CASE @ReturnNullOnEmpty
        WHEN 1 THEN NULLIF(@Result, '')
        ELSE @Result
    END     
END