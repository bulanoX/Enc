﻿
CREATE FUNCTION [Utility].[udf_ProcessPercentage]
(
    @Percentage                 numeric(19,12)
    ,@ZeroIsValid               bit
    ,@NegativeIsValid           bit
    ,@OverOneHundredIsValid     bit
)

RETURNS numeric(19,12)

BEGIN

    RETURN 
    CASE
        WHEN @Percentage = 0 AND @ZeroIsValid = 0 THEN NULL
        WHEN @Percentage < 0 AND @NegativeIsValid = 0 THEN NULL
        WHEN @Percentage > 100 AND @OverOneHundredIsValid = 0 THEN NULL
        ELSE @Percentage / 100
    END              
END