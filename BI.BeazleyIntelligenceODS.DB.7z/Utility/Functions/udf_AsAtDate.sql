﻿
CREATE FUNCTION [Utility].[udf_AsAtDate]
(
)

RETURNS datetime

AS
BEGIN

DECLARE @Result datetime
SELECT @Result = d.AsAtDate FROM Utility.AsAtDate d

RETURN ISNULL(@Result, GETDATE())

END