﻿CREATE AGGREGATE [Utility].[udf_StringJoin](@Value NVARCHAR (MAX) NULL, @Delimiter NVARCHAR (4000) NULL)
    RETURNS NVARCHAR (MAX)
    EXTERNAL NAME [BeazleyIntelligenceODSCLR].[StringJoin];

