﻿
CREATE FUNCTION [Utility].[udf_ProcessEurobaseDate]
(
    @EurobaseDate       datetime
)

RETURNS datetime

WITH RETURNS NULL ON NULL INPUT

BEGIN

    RETURN 
    CASE
        WHEN YEAR(@EurobaseDate) = 9999
        THEN NULL
        ELSE @EurobaseDate
    END
        
END