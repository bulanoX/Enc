﻿
CREATE FUNCTION [Utility].[udf_ProcessClaimCenterAccountingPeriod]
(
    @AccountingPeriod       varchar(6)
)

RETURNS datetime

WITH RETURNS NULL ON NULL INPUT

BEGIN

    IF (LEN(@AccountingPeriod) <> 6)
    BEGIN
        RETURN NULL
    END
    
    DECLARE @Year       char(4) 
    DECLARE @Month      char(2)
    
    SET @Year   = LEFT(@AccountingPeriod, 4)
    SET @Month  = RIGHT(@AccountingPeriod, 2)
    
    IF (ISNUMERIC(@Year) = 1 AND ISNUMERIC(@Month) = 1)
    BEGIN
    
        IF (CAST(@Year AS int) BETWEEN 2000 AND 2100 AND CAST(@Month AS int) BETWEEN 1 AND 12)
        BEGIN
            RETURN CONVERT(datetime, @AccountingPeriod + '01', 112)
        END
        
    END
    
    RETURN NULL

END