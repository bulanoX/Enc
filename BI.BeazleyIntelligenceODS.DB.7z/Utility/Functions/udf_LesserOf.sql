﻿
CREATE FUNCTION [Utility].[udf_LesserOf]
(
    @Value1                 int
    ,@Value2                int
)

RETURNS int

BEGIN

    RETURN CASE 
        WHEN @Value1 < @Value2 THEN @Value1
        WHEN @Value2 < @Value1 THEN @Value2
        ELSE ISNULL(@Value1, @Value2)
    END

END