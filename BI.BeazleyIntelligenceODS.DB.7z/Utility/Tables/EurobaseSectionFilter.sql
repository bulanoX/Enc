﻿CREATE TABLE [Utility].[EurobaseSectionFilter] (
    [SectionReference] VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]               datetime2(7)  NULL,
	[AuditCreateDateTime]               datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]                nvarchar(255) NULL,
    CONSTRAINT [PK_EurobaseSectionFilter] PRIMARY KEY NONCLUSTERED ([SectionReference] ASC) WITH (FILLFACTOR = 90)
);

