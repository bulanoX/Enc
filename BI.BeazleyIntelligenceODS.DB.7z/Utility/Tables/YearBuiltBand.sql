﻿CREATE TABLE [Utility].[YearBuiltBand] (
    [BandMin]  INT           NOT NULL,
    [BandMax]  INT           NOT NULL,
    [BandName] VARCHAR (255) NOT NULL,
    CONSTRAINT [CHK_YearBuiltBand] CHECK ([BandMin]<[BandMax]),
    CONSTRAINT [UQ_YearBuiltPand_LogicalKey] UNIQUE NONCLUSTERED ([BandMin] ASC) WITH (FILLFACTOR = 90)
);

