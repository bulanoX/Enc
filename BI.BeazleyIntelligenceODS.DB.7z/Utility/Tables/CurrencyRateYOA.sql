﻿CREATE TABLE [Utility].[CurrencyRateYOA] (
    [RateType]     VARCHAR (255)    NOT NULL,
    [YOA]          INT              NOT NULL,
    [Currency]     VARCHAR (255)    NOT NULL,
    [ExchangeRate] NUMERIC (38, 12) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_CurrencyRateYOA] PRIMARY KEY CLUSTERED ([RateType] ASC, [YOA] ASC, [Currency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_CurrencyRateYOA_ExchangeRate] CHECK ([ExchangeRate]>(0))
);

