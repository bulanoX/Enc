﻿CREATE TABLE [Utility].[CurrencyRateHistory] (
    [RateType]     VARCHAR (255)    NOT NULL,
    [Currency]     VARCHAR (255)    NOT NULL,
    [StartDate]    DATETIME         NOT NULL,
    [EndDate]      DATETIME         NULL,
    [ExchangeRate] NUMERIC (38, 12) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_CurrencyRateHistory] PRIMARY KEY CLUSTERED ([RateType] ASC, [Currency] ASC, [StartDate] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_CurrencyRateHistory_ExchangeRate] CHECK ([ExchangeRate]>(0))
);

