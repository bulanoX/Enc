﻿CREATE TABLE [Utility].[ODSStoredProcedureDependency] (
    [PK_ODSProcId] INT NOT NULL,
    [FK_ODSProcId] INT NOT NULL,
    CONSTRAINT [PK_ODSProcDependency] PRIMARY KEY CLUSTERED ([PK_ODSProcId] ASC, [FK_ODSProcId] ASC) WITH (FILLFACTOR = 90)
);

