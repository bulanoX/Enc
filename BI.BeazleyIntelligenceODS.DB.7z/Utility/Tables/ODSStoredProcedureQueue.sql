﻿CREATE TABLE [Utility].[ODSStoredProcedureQueue] (
    [PK_StoredProcedureQueue] INT            IDENTITY (1, 1) NOT NULL,
    [FK_ODSProcId]            INT            NOT NULL,
    [StoredProcName]          VARCHAR (4000) NULL,
    [PartitionId]             VARCHAR (255)  NULL,
    [DependencyLevel]         INT            NOT NULL
);

