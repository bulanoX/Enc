﻿CREATE TABLE [Utility].[ListOfColumnsToTrim] (
    [ID]         INT       IDENTITY (1, 1) NOT NULL,
    [TableName]  [sysname] NOT NULL,
    [ColumnName] [sysname] NOT NULL,
    [NewLength]  INT       NULL,
    [Active]     BIT       NULL,
    CONSTRAINT [PK_ListOfColumnsToTrim_TableName\ColumnName] PRIMARY KEY CLUSTERED ([TableName] ASC, [ColumnName] ASC) WITH (FILLFACTOR = 90)
);

