﻿CREATE TABLE [Utility].[SpecialPurposeSyndicateMultiplier] (
    [YOA]                               INT              NOT NULL,
    [SpecialPurposeSyndicateMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]               datetime2(7)  NULL,
	[AuditCreateDateTime]               datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]                nvarchar(255) NULL,
    CONSTRAINT [PK_SpecialPurposeSyndicateMultiplier] PRIMARY KEY CLUSTERED ([YOA] ASC) WITH (FILLFACTOR = 90)
);

