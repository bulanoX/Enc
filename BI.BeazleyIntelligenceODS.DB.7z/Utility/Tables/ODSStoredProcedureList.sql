﻿CREATE TABLE [Utility].[ODSStoredProcedureList] (
    [PK_ODSStoredProcedureList] INT            IDENTITY (1, 1) NOT NULL,
    [ProcId]                    INT            NOT NULL,
    [StoredProcName]            VARCHAR (4000) NULL,
    [PartitionId]               INT            CONSTRAINT [DF__ODSStored__Parti__42CCE065] DEFAULT ((1)) NOT NULL,
    [PriorityOrder]             INT            NOT NULL,
    [DependencyLevel]           INT            NULL,
    [ActiveFlag]                BIT            NULL,
    [ODSSource]                 NVARCHAR (10)  NULL,
    CONSTRAINT [PK_ODSSPList_PartitionId] PRIMARY KEY CLUSTERED ([PK_ODSStoredProcedureList] ASC, [PartitionId] ASC) WITH (FILLFACTOR = 90)
);

