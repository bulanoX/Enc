﻿CREATE TABLE [Utility].[ODSIndexes] (
    [SchemaName]      VARCHAR (255)  NULL,
    [TableName]       VARCHAR (255)  NULL,
    [TableId]         INT            NULL,
    [IndexId]         INT            NULL,
    [IndexName]       VARCHAR (255)  NULL,
    [IsUnique]        BIT            NULL,
    [IsClustered]     BIT            NULL,
    [IndexFillFactor] INT            NULL,
    [KeyColumns]      VARCHAR (4000) NULL,
    [Includes]        VARCHAR (4000) NULL,
    [DropSql]         VARCHAR (4000) NULL,
    [CreateSql]       VARCHAR (4000) NULL
);

