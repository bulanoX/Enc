﻿CREATE TABLE [Utility].[CoveragePerilMapping] (
    [LineOfBusiness]              VARCHAR (255)    NOT NULL,
    [RedistributedMajorClassCode] INT              NOT NULL,
    [RedistributedMajorClass]     VARCHAR (255)    NOT NULL,
    [RedistributionMultiplier]    NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]         datetime2(7)     NULL,
	[AuditCreateDateTime]         datetime2(7)     NOT NULL DEFAULT(GETDATE()),
	[AuditModifyDetails]          nvarchar(255)    NULL,
    CONSTRAINT [PK_CoveragePerilMaping] PRIMARY KEY NONCLUSTERED ([LineOfBusiness] ASC, [RedistributedMajorClassCode] ASC) WITH (FILLFACTOR = 90)
);

