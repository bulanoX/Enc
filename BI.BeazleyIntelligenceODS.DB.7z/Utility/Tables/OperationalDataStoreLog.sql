﻿CREATE TABLE [Utility].[OperationalDataStoreLog] (
    [PK_DataStoreLog]        INT            IDENTITY (1, 1) NOT NULL,
    [BatchId]                INT            NULL,
    [ProcName]               VARCHAR (4000) NULL,
    [FK_StoredProcedureList] INT            NULL,
    [PartitionNo]            INT            NULL,
    [StartDateTime]          DATETIME       NULL,
    [EndDateTime]            DATETIME       NULL,
    [Duration]               AS             ([utility].[udf_ProcessDuration]([StartDateTime],[EndDateTime])),
    [ThreadNo]               SMALLINT       NULL,
    [DependencyLevel]        INT            NULL,
    [ErrorFlag]              BIT            CONSTRAINT [DF__Operation__Error__45A94D10] DEFAULT ((0)) NULL,
    [ErrorDescription]       VARCHAR (4000) NULL,
    [AuditUser]              VARCHAR (255)  CONSTRAINT [DF_ODSAuditUser] DEFAULT (suser_sname()) NULL,
    CONSTRAINT [PK_OperationalDataStoreLog] PRIMARY KEY CLUSTERED ([PK_DataStoreLog] ASC) WITH (FILLFACTOR = 90)
);

