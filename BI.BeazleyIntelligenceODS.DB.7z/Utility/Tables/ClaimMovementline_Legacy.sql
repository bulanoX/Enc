﻿CREATE TABLE [Utility].[ClaimMovementline_Legacy] (
    [FK_ClaimMovement]  BIGINT           NOT NULL,
    [FK_Section]        BIGINT           NOT NULL,
    [FK_Syndicate]      BIGINT           NOT NULL,
    [FK_SlipLineNumber] BIGINT           NOT NULL,
    [LineMultiplier]    NUMERIC (19, 12) NOT NULL,
    [keyColumn]         NVARCHAR (255)   NULL
);


