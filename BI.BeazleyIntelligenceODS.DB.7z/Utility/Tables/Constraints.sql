﻿CREATE TABLE [Utility].[Constraints] (
    [ForeignKeyName]         VARCHAR (256) NOT NULL,
    [ReferencedTableSchema]  VARCHAR (256) NOT NULL,
    [ReferencedTableName]    VARCHAR (256) NOT NULL,
    [ReferencingTableSchema] VARCHAR (256) NOT NULL,
    [ReferencingTableName]   VARCHAR (256) NOT NULL,
    [DropSql]                VARCHAR (MAX) NULL,
    [CreateSql]              VARCHAR (MAX) NULL
);

