﻿CREATE TABLE [Utility].[SectionMeldedRate] (
    [Currency]         VARCHAR (255)    NOT NULL,
    [SectionReference] VARCHAR (255)    NOT NULL,
    [RateIdentifier]   VARCHAR (255)    NOT NULL,
    [MeldedRate]       NUMERIC (38, 12) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_SectionMeldedRate] PRIMARY KEY CLUSTERED ([Currency] ASC, [SectionReference] ASC, [RateIdentifier] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_SectionMeldedRate_ExchangeRate] CHECK ([MeldedRate]>(0))
);

