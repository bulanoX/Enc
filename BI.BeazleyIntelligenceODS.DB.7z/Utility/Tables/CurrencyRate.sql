﻿CREATE TABLE [Utility].[CurrencyRate] (
    [RateType]                   VARCHAR (255)    NOT NULL,
    [Currency]                   VARCHAR (255)    NOT NULL,
    [ExchangeRate]               NUMERIC (38, 12) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_CurrencyRate] PRIMARY KEY CLUSTERED ([RateType] ASC, [Currency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_CurrencyRate_ExchangeRate] CHECK ([ExchangeRate]>(0))
);

