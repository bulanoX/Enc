﻿CREATE TABLE [Utility].[AsAtDate] (
    [AsAtDate] DATETIME NOT NULL
);

