﻿CREATE VIEW [ODS].[vw_TPI_SectionDetails]

	AS 

SELECT s.sectionreference
	  ,tf.TriFocusName
	  , p.MethodOfPlacement
	  , s.InceptionDate
	  , s.UnderwriterName
	  , s.RiskClassCode
	  , cb.ClassOfBusinessCode
	  , p.InsuredParty
	  , s.BenchmarkMultiplier
	  , s.WrittenOrEstimatedPremiumInOriginalCCY


FROM ODS.Section s 

INNER JOIN  ODS.TriFocus tf 
ON s.FK_TriFocus = tf.PK_TriFocus 

INNER JOIN  ODS.ClassOfBusiness cb 
ON s.FK_ClassOfBusiness = cb.PK_ClassOfBusiness

INNER JOIN  ODS.Policy p 

ON p.PK_Policy = s.FK_Policy

