﻿

CREATE VIEW [ODS].[vw_BIDTransaction]

AS

SELECT
 PolicyReference						= td.PolicyReference
,SettlementDate							= td.SettlementDate
,TransactionCategory					= td.TransactionCategory
,TransactionType						= td.TransactionType
,OriginalCurrency						= td.OriginalCurrency
,SettlementCurrency						= td.SettlementCurrency
,OriginalCCYToSettlementCCYRate			= td.OriginalCCYToSettlementCCYRate
,AcquisitionCostPercentage 	            = td.AcquisitionCostPercentage 
,TransactionAmtInOriginalCCY			= td.TransactionAmtInOriginalCCY
,RiskLocation							= td.RiskLocation
,InvoiceReference						= td.InvoiceReference
							 
FROM

[$(Staging_BeazleyCentralStageIn)].[Eurobase_Staging].[vw_transactions_details] td