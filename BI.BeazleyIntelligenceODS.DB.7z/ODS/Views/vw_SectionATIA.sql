﻿

CREATE VIEW [ODS].[vw_SectionATIA]

AS

SELECT 
     SectionReference           = Atia.SectionReference                                          
    ,TerrorismReference         = Atia.TerrorismReference
    ,ATIAClassOfBusinessCode    = cob.ClassOfBusinessCode
    ,AustraliaState             = AtiaDetail.AustraliaState
    ,InsuranceType              = AtiaDetail.InsuranceType
    ,TierCode                   = AtiaDetail.TierCode
    ,WrittenOrEstimatedPremium  = AtiaDetail.WrittenOrEstimatedPremium
    ,LimitAmount                = AtiaDetail.LimitAmount
    ,OriginalCCY                = oc.CurrencyCode
    ,LimitCCY                   = oc_lim.CurrencyCode

FROM ODS.Section Atia

INNER JOIN ODS.SectionATIA AtiaDetail
ON Atia.PK_Section = AtiaDetail.FK_Section

INNER JOIN ODS.OriginalCurrency oc 
ON AtiaDetail.FK_OriginalCurrency = oc.PK_OriginalCurrency

INNER JOIN ODS.OriginalCurrency oc_lim
ON AtiaDetail.FK_LimitCurrency = oc_lim.PK_OriginalCurrency

INNER JOIN ODS.ClassOfBusiness cob
ON Atia.FK_ATIAClassOfBusiness = cob.PK_ClassOfBusiness

WHERE Atia.TerrorismReference IS NOT NULL