﻿
CREATE VIEW [ODS].[vw_risk_class_codes]

AS

SELECT
Extract_UniqueKey                      = rcc.Extract_UniqueKey
,Extract_Datetime                      = rcc.Extract_Datetime
,Extract_Login                         = rcc.Extract_Login
,Extract_DataSetLog                    = rcc.Extract_DataSetLog
,risk_class							   = rcc.risk_class
,risk_class_desc                       = rcc.risk_class_desc
,risk_class_desc2                      = rcc.risk_class_desc2
,risk_class_group                      = rcc.risk_class_group
,risk_class_oedc_group                 = rcc.risk_class_oedc_group
,risk_class_expiry                     = rcc.risk_class_expiry
,risk_class_solvency                   = rcc.risk_class_solvency
,risk_class_new_terr_code              = rcc.risk_class_new_terr_code
,risk_class_inception                  = rcc.risk_class_inception
							 
FROM

[$(Staging_Eurobase)].[Eurobase_Staging].[risk_class_codes] rcc