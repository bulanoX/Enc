﻿CREATE VIEW ODS.vw_DateSince
AS 
SELECT		PK_ClaimExposure,
			
			x.DateSincePessimistic,
			x.DateSinceMostLikely,
			x.DateSinceBlend,
			FK_DateSincePessimistic		=	IIF(YEAR(DateSincePessimistic) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DateSincePessimistic),DATEADD(DAY, -53690, 0)), --([Utility].[udf_GenerateDateKey](DateSincePessimistic)),
			FK_DateSinceMostLikely		=	IIF(YEAR(DateSinceMostLikely) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DateSinceMostLikely),DATEADD(DAY, -53690, 0)), --([Utility].[udf_GenerateDateKey]([DateSinceMostLikely])),
			FK_DateSinceBlend			=	IIF(YEAR(DateSinceBlend) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DateSinceBlend),DATEADD(DAY, -53690, 0)) --([Utility].[udf_GenerateDateKey]([DateSinceBlend]))
FROM		Ods.ClaimExposure ce 
LEFT JOIN	(
			SELECT			es.FK_ClaimExposure, DateSincePessimistic, DateSinceMostLikely, DateSinceBlend
			FROM 			Ods.ClaimEstimate es 
			INNER JOIN	(
						SELECT		FK_ClaimExposure, ROW_NUMBER() OVER(PARTITION BY FK_ClaimExposure ORDER BY es.PK_ClaimEstimate) AS RowID
						FROM		Ods.ClaimEstimate es 
			) dummy on	es.FK_ClaimExposure = dummy.FK_ClaimExposure AND dummy.RowID=1
) x	ON		ce.PK_ClaimExposure = x.FK_ClaimExposure