﻿CREATE VIEW [ODS].[vw_DataRetention_Binder]
AS

SELECT DISTINCT
	PK_Binder = cast(s.SourceSystem + '-' + s.PolicyReference + '-' + b.SectionReference + '-' + b.SourceSystem as nvarchar(1024))
	,SourceSystem = s.SourceSystem
	,PolicyReference = CASE 
						WHEN s.SourceSystem = 'Eurobase' then LEFT(s.PolicyReference, 8)
						ELSE s.PolicyReference
					   END
	,BinderReference = CASE 
						WHEN b.SourceSystem = 'Eurobase' then LEFT(b.SectionReference, 8)
						ELSE b.SectionReference
					   END
	,BinderSourceSystem = b.SourceSystem
FROM 
(
    SELECT 
        SectionReference = s.SectionReference
		,FK_Facility = s.FK_Facility
		,SourceSystem = s.SourceSystem
		,PolicyReference = p.PolicyReference
    FROM ODS.Section s
	INNER JOIN ODS.Policy p 
	ON p.PK_Policy = s.FK_Policy
) as s
LEFT OUTER JOIN ODS.Section b 
ON b.PK_Section = s.FK_Facility
WHERE b.SectionReference <> 'N/A'
AND b.SectionReference <>  s.SectionReference