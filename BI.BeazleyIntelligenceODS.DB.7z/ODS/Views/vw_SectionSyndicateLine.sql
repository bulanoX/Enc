﻿

CREATE VIEW [ODS].[vw_SectionSyndicateLine]

AS

SELECT 
     SectionReference                       = Pol.SectionReference                                    
    ,SectionStatus                          = Pol.SectionStatusCode                                   
    ,IsSigned                               = Pol.IsSigned                                            
    ,SyndicateNumber                        = S.SyndicateNumber                                       
    ,TotalWrittenIfNotSignedLineMultiplier  = CASE Pol.IsSigned
                                              WHEN 0 THEN Pol.WrittenOrderMultiplier * Pl.WrittenLineMultiplier * Pol.EstimatedSigningMultiplier
                                              WHEN 1 THEN    ISNULL(Pol.SignedOrderMultiplier, 1) * Pl.SignedLineMultiplier  
                                              END                                                    
    ,WrittenOrderMultiplier                 = Pol.WrittenOrderMultiplier                         
    ,WrittenLineMultiplier                  = Pl.WrittenLineMultiplier        
    ,EstimatedSigningMultiplier             = Pol.EstimatedSigningMultiplier    
    ,SignedOrderMultiplier                  = Pol.SignedOrderMultiplier                        
    ,SignedLineMultiplier                   = Pl.SignedLineMultiplier                 
    
FROM ODS.Section Pol

INNER JOIN ODS.SectionLine Pl ON
Pol.PK_Section = Pl.FK_Section

INNER JOIN ODS.Syndicate S ON
Pl.FK_Syndicate = S.PK_Syndicate