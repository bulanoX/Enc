﻿CREATE VIEW [ODS].[vw_DataRetention_ClaimExposureSection]
AS
	SELECT    PK_ClaimExposureSection = cast(s.SourceSystem + '-' + p.PolicyReference + '-' + isnull(c.ClaimReference, 'NoClaim') AS NVARCHAR(1024))
			  ,p.PolicyReference
			  ,s.SourceSystem
			  ,c.ClaimReference
			  ,c.ClaimClosedDate
			  ,PolicyExpiryDate = MAX(s.ExpiryDate) OVER (PARTITION BY p.PolicyReference, s.SourceSystem ) 
	FROM [ODS].[Policy] p

	INNER JOIN [ODS].[Section] s 
	ON p.pk_policy = s.fk_policy

	LEFT JOIN [ODS].[ClaimExposureSection] ces
	ON s.pk_section = ces.fk_section

	LEFT JOIN [ODS].[ClaimExposure] ce 
	ON ces.fk_claimexposure = ce.pk_claimexposure

	LEFT JOIN [ODS].[Claim] c 
	ON ce.fk_claim = c.pk_claim

	WHERE p.SourceSystem NOT IN ('Eurobase', 'BeazleyPro', 'ClaimCenter', 'Source')
	AND p.IsQuote=0