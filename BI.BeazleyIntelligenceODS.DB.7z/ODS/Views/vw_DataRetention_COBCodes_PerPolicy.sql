﻿CREATE   VIEW [ODS].[vw_DataRetention_COBCodes_PerPolicy] AS
WITH PolicyClaimMatch AS (
    SELECT DISTINCT
        c.ClaimReference, 
        p.Policyreference
    FROM [ODS].[Policy] p
    INNER JOIN [ODS].[Section] s ON p.pk_policy = s.fk_policy
    INNER JOIN [ODS].[ClaimExposureSection] ces ON s.pk_section = ces.fk_section
    INNER JOIN [ODS].[ClaimExposure] ce ON ces.fk_claimexposure = ce.pk_claimexposure
    INNER JOIN [ODS].[Claim] c ON ce.fk_claim = c.pk_claim
    WHERE p.IsQuote = 0
),
MultilineClaims AS (
    SELECT
        ClaimReference, 
        COUNT(DISTINCT Policyreference) AS PolicyCount
    FROM PolicyClaimMatch
    GROUP BY ClaimReference
    HAVING COUNT(DISTINCT Policyreference) > 1
),
PoliciesOnMultilineClaims AS (
    SELECT DISTINCT
        pcm.Policyreference
    FROM MultilineClaims mc
    INNER JOIN PolicyClaimMatch pcm ON mc.ClaimReference = pcm.ClaimReference
)

SELECT 
    c.* ,
    HasMultilineClaims = CASE 
                                WHEN p.Policyreference IS NULL THEN 0 
                                WHEN p.Policyreference IS NOT NULL THEN 1 
                                ELSE NULL 
                                       END
FROM (
    SELECT
        PK_CobCodesPerPolicy = CAST(SourceSystem + '-' + PolicyReference AS NVARCHAR(1024)),
        SourceSystem,
        PolicyReference,
        IsCobCodeExcluded = MAX(IsCobCodeExcluded),
        IsExtendedTo22Years = CASE WHEN MAX(IsExtendedTo22Years) = 1 AND MAX(IsCobCodeExcluded) = 1 THEN 0 ELSE MAX(IsExtendedTo22Years) END
    FROM (
        SELECT  
            s.SourceSystem,
            p.PolicyReference,
            cb.ClassOfBusinessCode,
            tr.TrifocusName,
             CASE 
                WHEN cb.ClassOfBusinessCode IN ('AH', 'BG', 'BH', 'HC', 'HF', 'HH', 'HO', 'HS',' NE', 'PT', 'TL'
                                               ,'WL', 'VE', 'WG', 'AR', 'CE', 'CH', 'CM', 'CR', 'CT', 'CX', 'FS', 'NC' 
                                               ) THEN 1
                ELSE 0 
            END AS IsCobCodeExcluded,
            CASE 
                WHEN cb.ClassOfBusinessCode IN ('AJ','DA','DM','DZ','HA','HB','HD','HE','HG','HI','HJ','HK','HL', 'HM','HN','HP','HR','HT','HU','HV','HW','HY','HZ','KO','NJ','PH','PM','TE','YW') THEN 1
                WHEN tr.TriFocusName IN ('BUSA Healthcare MM','Healthcare Large Risk Int','Intl Life Sciences','Healthcare-Misc Med','BUSA Life Sciences','BICI HEALTHCARE MM','HML UK','BZD Int Healthcare',
                    'Healthcare','BICI BEAZLEY HEALTHCARE','PE Intl Healthcare','BICI Healthcare ML','BUSA Healthcare ML','Healthcare-Hospitals','BUSA Misc Med PE','Chicago Healthcare',
                    'BICI HEALTHCARE MM') THEN 1
                WHEN cb.ClassOfBusinessCode IN ('WG','WH','WI','WL','WW','MV','VE','VZ','WA','VN','VK','PA','TF','BI','YH','PS','FT','FE','EP','BE','YA','LR','FF','LC',
                    'LN','LP','ZV','PL','TS','PJ','BR','TG','LT','VX') THEN 1
                WHEN tr.TriFocusName IN ('Upstream Casualty','Hull All Risks/Voyage & Tow','Hull Total Loss','Marine Liabs','War / Political / Terrorism','BICI Hull','Marine Logistics Liability',
                    'Subsea','Upstream Property','Aviation Liab','BICI A&E MM','BICI A&E PE','BICI BBR Services MM','BICI Environmental FS','BICI Lawyers MM',
                    'BICI Misc Med PE','BICI TMB US Info Sec','BUSA A&E MM','BUSA A&E PE','BUSA BBR Services PE','BUSA BPS BBR','BUSA Environmental','BUSA Environmental CM',
                    'BUSA Environmental FS','BUSA Environmental Occ','BUSA Homeowners','BUSA Lawyers MM','BUSA MM Health Occurrence','BUSA Safeguard','BUSA TMB PE US Info Sec',
                    'BUSA TMB US Info Sec','BUSA US InfoSec MM BBR','Covers US','Engineering','Environmental Claims Made','Environmental Fixed Site','Environmental Occurrence',
                    'FS Core - Atlanta','Hull','Life Reinsurance','Marine Libs','Open Market','PA Direct London','PA RI Cat','PA RI Prop and CH','Package','PE Media US',
                    'Safeguard UK','TMB UK Info Sec','TMB UK Tech','Tracker SL','Trucking Liab') THEN 1
                WHEN tr.TriFocusName IN ('BBR Services Int PE','BICI CommercialCrime','BICI D&O MM','BICI EPL MM','BICI EPL PE','BICI TMB PE','BICI TMB US E&O','BICI US PROGRAMMES',
                    'BUSA Beazley Healthcare','BUSA CommercialCrime','BUSA D&O MM','BUSA EPL MM','BUSA EPL PE','BUSA TMB PE','BUSA TMB US E&O','BZD Int Media','Contingency',
                    'D&O','D&O Large Risk Int','DIN US Lawyers','EPL','Financial Institutions','International','International ML','Intl A&E Large','Intl Lawyers','Intl Misc Med PE',
                    'Intl PE Regions','Intl PI A&E Small','Intl Specialty (PT)','Intl US PE London','Legacy','PE Media Intl','PI A&E Small','PI-A&E exBLPT','PI-BI exBLPT',
                    'PI-Lawyers exBLPT','PI-Other exBLPT','Specialty (PT)','Specialty Embedded','Specialty exPT','TMB INT InfoSec MM BBR','TMB Large Risk Int',
                    'TMB LargeRisk Int InfoSec','TMB PE Int','UK','US Life Sciences','US PE London') THEN 1
                ELSE 0
            END AS IsExtendedTo22Years
        FROM ODS.Section AS s 
        INNER JOIN ODS.Policy AS p ON p.PK_Policy = s.FK_Policy 
        INNER JOIN ODS.ClassOfBusiness AS cb ON cb.PK_ClassOfBusiness = s.FK_ClassOfBusiness
        INNER JOIN ODS.TriFocus AS tr ON tr.PK_TriFocus = s.FK_TriFocus
        WHERE (s.IsQuote = 0) AND (p.SourceSystem <> 'ClaimCenter')
    ) AS g
    GROUP BY SourceSystem, PolicyReference
) AS c
LEFT JOIN PoliciesOnMultilineClaims p ON c.PolicyReference = p.PolicyReference;