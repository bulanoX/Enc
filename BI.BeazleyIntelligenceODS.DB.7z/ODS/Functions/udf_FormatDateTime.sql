﻿

/*ODS Functions*/
CREATE FUNCTION [ODS].[udf_FormatDateTime]
(
	@DateToFormat datetime
)

RETURNS varchar(50)

WITH RETURNS NULL ON NULL INPUT

BEGIN

    SELECT @DateToFormat = Utility.udf_GenerateDateKey(@DateToFormat)

    IF YEAR(@DateToFormat) = 1753 
    BEGIN
        RETURN NULL
    END

    RETURN ODS.udf_FormatDateTimeNoRangeCheck(@DateToFormat)

END