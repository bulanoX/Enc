﻿
CREATE FUNCTION [ODS].[udf_FormatHoursAsTime]
(
	@TotalHours numeric(19,12)
)

RETURNS varchar(50)

WITH RETURNS NULL ON NULL INPUT

BEGIN

DECLARE @ReturnValue        varchar(50)
DECLARE @TotalSeconds       numeric(38,12)
DECLARE @RemainderSeconds   numeric(19,12)
DECLARE @Hours              int
DECLARE @Minutes            int
DECLARE @Seconds            int

SET @TotalSeconds = @TotalHours * 3600

SET @Hours = FLOOR(@TotalHours)
SET @RemainderSeconds = @TotalSeconds - (@Hours * 3600)

SET @Minutes = FLOOR(@RemainderSeconds / 60)
SET @Seconds = ROUND(@RemainderSeconds % 60, 0)

IF (@Seconds = 60)
BEGIN

    SET @Minutes = @Minutes + 1
    SET @Seconds = 0
END

DECLARE @HoursString varchar(50)
DECLARE @MinutesString varchar(2)
DECLARE @SecondsString varchar(2)

SET @HoursString = ISNULL(REPLICATE('0', 2-LEN(@Hours)), '') + CAST(@Hours AS varchar(50))
SET @MinutesString = REPLICATE ('0', 2-LEN(@Minutes)) + CAST(@Minutes AS varchar(2))
SET @SecondsString = REPLICATE('0', 2-LEN(@Seconds)) + CAST(@Seconds AS varchar(2))

SET @ReturnValue = @HoursString + ':' + @MinutesString + ':' + @SecondsString

RETURN @ReturnValue

END