﻿

CREATE FUNCTION [ODS].[udf_FormatDateTimeWithTime]
(
	@DateToFormat datetime
)

RETURNS varchar(50)

WITH RETURNS NULL ON NULL INPUT

BEGIN

DECLARE @ReturnValue varchar(50)

SET @ReturnValue = ODS.udf_FormatDateTimeNoRangeCheck(@DateToFormat)
                    + ' ' + REPLICATE('0', 2 - LEN(DATENAME(HOUR, @DateToFormat))) 
                    + DATENAME(HOUR,@DateToFormat)
                    + ':' + REPLICATE('0', 2 - LEN(DATENAME(MINUTE, @DateToFormat)))
                    + DATENAME(MINUTE, @DateToFormat)
                    
RETURN @ReturnValue

END