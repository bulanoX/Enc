﻿

CREATE FUNCTION [ODS].[udf_FormatDateTimeNoRangeCheck]
(
	@DateToFormat datetime
)

RETURNS varchar(50)

WITH RETURNS NULL ON NULL INPUT

BEGIN

DECLARE @ReturnValue varchar(50)

SET @ReturnValue = 
    REPLICATE('0', 2 - LEN(DATENAME(DAY, @DateToFormat))) + --Prefix day with '0' if it's one digit
    DATENAME(DAY, @DateToFormat) + '-' + 
    LEFT(DATENAME(MONTH, @DateToFormat), 3) + '-' +
    DATENAME(YEAR, @DateToFormat)
RETURN @ReturnValue

END