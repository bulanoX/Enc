﻿
CREATE FUNCTION [ODS].[udf_FormatInt]
(
	@IntToFormat int
)

RETURNS varchar(100)
WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

DECLARE @Sign varchar(1)
SET @Sign = CASE WHEN @IntToFormat < 0 THEN '-' ELSE '' END
SET @IntToFormat = ABS(@IntToFormat)

DECLARE @StringOut varchar(100)

DECLARE @StringIn varchar(100)
DECLARE @WorkingString varchar(100)

SET @StringIn = CAST(@IntToFormat as varchar)

DECLARE @Length int
DECLARE @Position int

SET @Length = LEN(@StringIn)
SET @Position = @Length - 2

SET @StringOut = ''

WHILE(@Position > -2)
BEGIN
	SET @WorkingString = SUBSTRING(@StringIn, @Position, 3)
	SET @StringOut = @WorkingString + ',' + @StringOut

	SET @Position = @Position - 3
END

SET @StringOut = LEFT(@StringOut, LEN(@StringOut) -1)
SET @StringOut = @Sign + @StringOut

RETURN @StringOut

END