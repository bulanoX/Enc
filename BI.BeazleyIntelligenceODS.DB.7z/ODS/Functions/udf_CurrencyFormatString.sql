﻿
CREATE FUNCTION [ODS].[udf_CurrencyFormatString]
(
	@CurrencyCode varchar(255) 
)

RETURNS varchar (255)

WITH RETURNS NULL ON NULL INPUT

BEGIN

    RETURN
    '#,##0 ' + '"' + @CurrencyCode + '"'
    +';'
    +'-#,##0 ' + '"' + @CurrencyCode + '"'
    +';'
    +'0 ' + '"' + @CurrencyCode + '"'
    +';'
END