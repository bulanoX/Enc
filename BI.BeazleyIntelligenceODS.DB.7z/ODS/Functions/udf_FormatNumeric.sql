﻿
CREATE FUNCTION [ODS].[udf_FormatNumeric]
(
	@NumericToFormat numeric(38,10)
	,@MaxDecimalPlaces int
)

RETURNS varchar(100)
WITH RETURNS NULL ON NULL INPUT

AS

BEGIN

IF (@MaxDecimalPlaces) < 0
BEGIN
    SET @MaxDecimalPlaces = 0
END

DECLARE @Sign varchar(1)
SET @Sign = CASE WHEN @NumericToFormat < 0 THEN '-' ELSE '' END
SET @NumericToFormat = ABS(@NumericToFormat)

DECLARE @StringIn varchar(100)
DECLARE @WorkingString varchar(100)
DECLARE @Position int

SET @StringIn = CAST(ROUND(@NumericToFormat, @MaxDecimalPlaces) as varchar(100))

SET @WorkingString = @StringIn

DECLARE @IndexOfDecimalSeparator int
SET @IndexOfDecimalSeparator = CHARINDEX('.', @WorkingString)

IF (@IndexOfDecimalSeparator = 0)
BEGIN
    SET @Position = LEN(@WorkingString) - 2
END
ELSE
BEGIN
    SET @Position = @IndexOfDecimalSeparator - 3
    
    DECLARE @Offset int
    
    SET @Offset = @MaxDecimalPlaces
    IF (@MaxDecimalPlaces = 0) SET @Offset = -1
    
    SET @WorkingString = LEFT(@WorkingString, @IndexOfDecimalSeparator + @Offset)
END

WHILE (@Position > 1)
BEGIN
    SET @WorkingString = STUFF(@WorkingString, @Position, 0, ',') 
    SET @Position = @Position - 3
END

RETURN @Sign + @WorkingString

END