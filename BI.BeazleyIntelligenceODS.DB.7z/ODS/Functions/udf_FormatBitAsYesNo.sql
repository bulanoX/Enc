﻿
CREATE FUNCTION [ODS].[udf_FormatBitAsYesNo]
(
	@BitToFormat    bit
)

RETURNS varchar(100)

AS

BEGIN

DECLARE @Result varchar(100)

SELECT @Result = ODS.udf_FormatBit(@BitToFormat, 'Yes', 'No', 'No')

RETURN @Result
    
END