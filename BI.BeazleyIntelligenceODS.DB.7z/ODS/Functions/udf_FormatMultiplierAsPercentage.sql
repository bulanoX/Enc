﻿
CREATE FUNCTION [ODS].[udf_FormatMultiplierAsPercentage]
(
    @Multiplier float
    ,@MaxDecimalPlaces int
)

RETURNS varchar(50)

WITH RETURNS NULL ON NULL INPUT

AS

BEGIN
    
    DECLARE @ReturnValue varchar(50)
    SET @ReturnValue = 
    CAST(ROUND(@Multiplier * 100, @MaxDecimalPlaces) as varchar(50)) + '%'
    
    RETURN @ReturnValue
END