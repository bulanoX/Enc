﻿

CREATE FUNCTION [ODS].[udf_FormatBit]
(
	@BitToFormat    bit
	,@ValueIfTrue   varchar(100)
	,@ValueIfFalse  varchar(100)
	,@ValueIfNull   varchar(100)
)

RETURNS varchar(100)

AS

BEGIN

RETURN 
CASE
    WHEN @BitToFormat = 1 THEN @ValueIfTrue
    WHEN @BitToFormat = 0 THEN @ValueIfFalse
    WHEN @BitToFormat IS NULL THEN @ValueIfNull
END
    
END