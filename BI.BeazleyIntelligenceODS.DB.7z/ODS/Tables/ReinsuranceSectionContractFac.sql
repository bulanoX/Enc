﻿CREATE TABLE [ODS].[ReinsuranceSectionContractFac] (
    [FK_Section]             BIGINT           NOT NULL,
    [FK_Syndicate]           BIGINT           NOT NULL,
    [FK_ReinsuranceContract] BIGINT           NOT NULL,
    [SequenceNumber]         INT              NOT NULL,
    [CededPercentage]        NUMERIC (19, 12) NOT NULL,
    [Proportion]             NUMERIC (19, 12) NULL,
    CONSTRAINT [PK_ReinsuranceSectionContractFac] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_Syndicate] ASC, [FK_ReinsuranceContract] ASC, [SequenceNumber] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ReinsuranceSectionContractFac_ReinsuranceContractFac] FOREIGN KEY ([FK_ReinsuranceContract]) REFERENCES [ODS].[ReinsuranceContractFac] ([PK_ReinsuranceContract]),
    CONSTRAINT [FK_ReinsuranceSectionContractFac_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_ReinsuranceSectionContractFac_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate])
);





