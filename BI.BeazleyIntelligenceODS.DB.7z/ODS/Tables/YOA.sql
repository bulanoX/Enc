﻿CREATE TABLE [ODS].[YOA] (
    [PK_YOA]                BIGINT         NOT NULL,
    [FirstDate]             DATETIME       NOT NULL,
    [YOAName]               VARCHAR (255)  NOT NULL,
    [MaxDevelopmentMonth]   INT            NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512) NULL,
    CONSTRAINT [PK_YOA] PRIMARY KEY NONCLUSTERED ([PK_YOA] ASC) WITH (FILLFACTOR = 90)
);

