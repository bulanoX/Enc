﻿CREATE TABLE [ODS].[Syndicate] (
    [PK_Syndicate]       AS            ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([varchar](255),[SyndicateNumber])))),(0))PERSISTED NOT NULL,
    [SyndicateNumber]    INT           NOT NULL,
    [SyndicateName]      VARCHAR (255) NULL,
    [SyndicateGroupName] VARCHAR (255) NULL,
    [AuditModifyDateTime]           DATETIME2 (7)  NULL,
    [AuditCreateDateTime]           DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]            NVARCHAR (255) NULL,
    CONSTRAINT [PK_Syndicate] PRIMARY KEY NONCLUSTERED ([PK_Syndicate] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Syndicate_LogicalKey] UNIQUE NONCLUSTERED ([SyndicateNumber] ASC) WITH (FILLFACTOR = 90)
);







































