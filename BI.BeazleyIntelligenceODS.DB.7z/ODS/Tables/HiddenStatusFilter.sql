﻿CREATE TABLE [ODS].[HiddenStatusFilter] (
    [PK_HiddenStatusFilter] BIGINT        NOT NULL,
    [HiddenStatusFilter]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_HiddenStatusFilter] PRIMARY KEY NONCLUSTERED ([PK_HiddenStatusFilter] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_HiddenStatusFilter_LogicalKey] UNIQUE NONCLUSTERED ([HiddenStatusFilter] ASC) WITH (FILLFACTOR = 90)
);

