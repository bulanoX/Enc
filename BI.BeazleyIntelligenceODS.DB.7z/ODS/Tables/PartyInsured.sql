﻿CREATE TABLE [ODS].[PartyInsured] (
    [PK_PartyInsured]            AS                  IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((upper([SourceSystem])+'|~|')+upper([SourceSystemId])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]            BIT                CONSTRAINT [DEF_PartyInsured_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SourceSystem]               VARCHAR (255)      NOT NULL,
    [SourceSystemId]             VARCHAR (255)      NOT NULL,
    [InsuredSourceID]            VARCHAR (255)      NULL,
    [InsuredName]                VARCHAR (350)      NOT NULL,
    [InsuredCity]                VARCHAR (255)      NULL,
    [InsuredState]               VARCHAR (255)      NULL,
    [InsuredCountry]             VARCHAR (255)      NULL,
    [NAICCode]                   INT                NULL,
    [NAIC]                       VARCHAR (255)      NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_PartyInsured] PRIMARY KEY CLUSTERED ([PK_PartyInsured] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_PartyInsured_LogicalKey] UNIQUE NONCLUSTERED ([SourceSystem] ASC, [SourceSystemId] ASC) WITH (FILLFACTOR = 90)
);

