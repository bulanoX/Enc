﻿CREATE TABLE [ODS].[Submission] (
    [PK_Submission]             AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([SubmissionSourceId])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]           BIT           CONSTRAINT [DEF_Submission_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SubmissionSourceId]        VARCHAR (255) NOT NULL,
    [SubmissionStatus]          VARCHAR (255) NOT NULL,
    [SubmissionDate]            DATETIME      NOT NULL,
    [ClearedDate]               DATETIME      NULL,
    [WasMigrated]               BIT           NOT NULL,
    [MarketSegment]             VARCHAR (255) NULL,
    [MarketSegmentCode]         VARCHAR (255) NULL,
    [RiskStatus]                VARCHAR (255) NULL,
    [ClearedProductName]        VARCHAR (255) NULL,
    [FK_CRMBroker]              BIGINT        NOT NULL,
    [FK_PartyInsured]           BIGINT        NOT NULL,
    [FK_Underwriter]            BIGINT        NOT NULL,
    [FK_ClearedClassOfBusiness] BIGINT        NOT NULL,
    [FK_ExpiringSubmission]     BIGINT        NULL,
    [SourceSystemName]          VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]       datetime2(7)  NULL,
	[AuditCreateDateTime]       datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]        nvarchar(255) NULL,
    CONSTRAINT [PK_Submission] PRIMARY KEY CLUSTERED ([PK_Submission] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Submission_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_Submission_ExpiringSubmission] FOREIGN KEY ([FK_ExpiringSubmission]) REFERENCES [ODS].[Submission] ([PK_Submission]),
    CONSTRAINT [FK_Submission_PartyInsured] FOREIGN KEY ([FK_PartyInsured]) REFERENCES [ODS].[PartyInsured] ([PK_PartyInsured]),
    CONSTRAINT [FK_Submission_Underwriter] FOREIGN KEY ([FK_Underwriter]) REFERENCES [ODS].[Underwriter] ([PK_Underwriter]),
    CONSTRAINT [UQ_Submission_LogicalKey] UNIQUE NONCLUSTERED ([SubmissionSourceId] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IX_Submission_SubmissionSourceId]
    ON [ODS].[Submission]([SubmissionSourceId] ASC) WITH (FILLFACTOR = 90);

