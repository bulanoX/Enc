﻿CREATE TABLE [ODS].[DiaryEntry] (
    [PK_DiaryEntry]                  AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((CONVERT([varchar](255),[FK_Section])+'|~|')+[EntryTypeCode]))),(0)) PERSISTED NOT NULL,
    [EntryTypeCode]                  VARCHAR (255)   NOT NULL,
    [EntryType]                      VARCHAR (255)   NULL,
    [EntryDate]                      DATETIME        NULL,
    [EntryValue]                     NUMERIC (38, 6) NULL,
    [EntryReference]                 VARCHAR (255)   NULL,
    [FK_Section]                     BIGINT          NOT NULL,
    [FK_Date]                        DATETIME        NOT NULL,
    [FK_EntryDate]                   AS              IIF(YEAR(EntryDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EntryDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EntryDate])) PERSISTED,
    [FK_YOA]                         BIGINT          NOT NULL,
    [FK_SettlementCurrency]          BIGINT          NOT NULL,
    [FK_OriginalCurrency]            BIGINT          NOT NULL,
    [FK_TriFocus]                    BIGINT          NOT NULL,
    [FK_HiddenStatusFilter]          BIGINT          NOT NULL,
    [FK_QuoteFilter]                 BIGINT          NOT NULL,
    [FK_Policy]                      BIGINT          NOT NULL,
    [FK_CRMBroker]                   BIGINT          NOT NULL,
    [SpecialPurposeSyndicateApplies] BIT             NOT NULL,
    [EntryDateName]                  AS              IIF(YEAR(EntryDate)< 1990 OR YEAR(EntryDate)>2050,NULL,FORMAT(EntryDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EntryDate])),
    [NumberOfROEEntries]             AS              (case when [EntryTypeCode]='ROE' then (1) else (0) end),
    [ROEValue]                       AS              (case when [EntryTypeCode]='ROE' then [EntryValue]  end),
    [FK_UnderwritingPlatform]        BIGINT          NOT NULL,
    [FK_InternalWrittenBinderStatus] BIGINT          NOT NULL,
    [FK_ServiceCompany]              BIGINT          NOT NULL,
    [AuditModifyDateTime]            DATETIME2 (7)   NULL,
    [AuditCreateDateTime]            DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]             NVARCHAR (512)  NULL,
    CONSTRAINT [PK_DiaryEntry] PRIMARY KEY NONCLUSTERED ([PK_DiaryEntry] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_DiaryEntry_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_DiaryEntry_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_DiaryEntry_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_DiaryEntry_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_DiaryEntry_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_DiaryEntry_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_DiaryEntry_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_DiaryEntry_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_DiaryEntry_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_DiaryEntry_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_DiaryEntry_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform]),
    CONSTRAINT [FK_DiaryEntry_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_DiaryEntry_LogicalKey] UNIQUE NONCLUSTERED ([FK_Section] ASC, [EntryTypeCode] ASC) WITH (FILLFACTOR = 90)
);
GO

CREATE NONCLUSTERED INDEX [IDX_DiaryEntry_001]
    ON [ODS].[DiaryEntry]([EntryTypeCode] ASC)
    INCLUDE([EntryDate], [FK_Section]) WITH (FILLFACTOR = 90);
GO












