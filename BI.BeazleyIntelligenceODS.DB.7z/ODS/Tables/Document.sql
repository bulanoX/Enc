﻿CREATE TABLE [ODS].[Document] (
    [PK_Document]              AS             ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((((CONVERT([varchar](255),[FK_DocumentType])+'|~|')+CONVERT([varchar](255),[SequenceId]))+'|~|')+CONVERT([varchar](255),[FK_Section])))),(0)) PERSISTED NOT NULL,
    [SequenceId]               INT           NOT NULL,
    [CreatedBy]                VARCHAR (255) NULL,
    [ModifiedBy]               VARCHAR (255) NULL,
    [DocumentCreateDate]       DATETIME      NULL,
    [DocumentModifyDate]       DATETIME      NULL,
    [DaysSinceQuoteOrBindDate] INT           NULL,
    [FK_DocumentType]          BIGINT        NOT NULL,
    [FK_Section]               BIGINT        NOT NULL,
    [FK_DocumentCreateDate]    AS            IIF(YEAR(DocumentCreateDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DocumentCreateDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([DocumentCreateDate])) PERSISTED,
    [FK_DocumentModifyDate]    AS            IIF(YEAR(DocumentModifyDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DocumentModifyDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([DocumentModifyDate])) PERSISTED,
    [UploadedDateTime]         DATETIME      NULL,
    [AuditModifyDateTime]                      DATETIME2 (7)      NULL,
    [AuditCreateDateTime]                      DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                       NVARCHAR (255)     NULL,
    CONSTRAINT [PK_Document] PRIMARY KEY NONCLUSTERED ([PK_Document] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Document_DocumentType] FOREIGN KEY ([FK_DocumentType]) REFERENCES [ODS].[DocumentType] ([PK_DocumentType]),
    CONSTRAINT [FK_Document_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [UQ_Document_LogicalKey] UNIQUE NONCLUSTERED ([FK_DocumentType] ASC, [SequenceId] ASC, [FK_Section] ASC) WITH (FILLFACTOR = 90)
);
GO

CREATE NONCLUSTERED INDEX [IDX_Document_001]
    ON [ODS].[Document]([FK_DocumentType] ASC)
    INCLUDE([DocumentCreateDate], [FK_Section]) WITH (FILLFACTOR = 90);
GO






