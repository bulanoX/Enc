﻿CREATE TABLE [ODS].[ClaimIncurredBand] (
    [PK_ClaimIncurredBand] AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',CONVERT(VARCHAR(50),([BandMin])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]      BIT           CONSTRAINT [DEF_ClaimIncurredBand_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [BandMin]              NUMERIC (38)  NOT NULL,
    [BandMax]              NUMERIC (38)  NOT NULL,
    [BandName]             VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_ClaimIncurredBand] PRIMARY KEY NONCLUSTERED ([PK_ClaimIncurredBand] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClaimIncurredBand_LogicalKey] UNIQUE NONCLUSTERED ([BandMin] ASC) WITH (FILLFACTOR = 90)
);

