﻿CREATE TABLE [ODS].[TriFocusYOA] (
    [FK_TriFocus]               BIGINT           NOT NULL,
    [FK_YOA]                    BIGINT           NOT NULL,
    [LloydsClassCode]           VARCHAR (255)    NULL,
    [LloydsClass]               VARCHAR (255)    NULL,
    [BusinessPlanULRMultiplier] NUMERIC (19, 12) NULL,
    [AuditModifyDateTime]       DATETIME2 (7)    NULL,
    [AuditCreateDateTime]       DATETIME2 (7)    DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]        NVARCHAR (255)   NULL,
    CONSTRAINT [PK_TriFocusYOA] PRIMARY KEY NONCLUSTERED ([FK_TriFocus] ASC, [FK_YOA] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_TriFocusYOA_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_TriFocusYOA_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA])
);





