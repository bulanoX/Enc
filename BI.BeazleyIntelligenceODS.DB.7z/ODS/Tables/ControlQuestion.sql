﻿CREATE TABLE [ODS].[ControlQuestion] (
    [PK_ControlQuestion]     AS           ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((CONVERT([varchar](255),[FK_ControlQuestionType])+'|~|')+CONVERT([varchar](255),[QuestionNumber])))),(0))  PERSISTED NOT NULL,
    [QuestionNumber]         INT           NOT NULL,
    [ControlQuestion]        VARCHAR (MAX) NOT NULL,
    [QuestionShortName]      VARCHAR (255) NULL,
    [FK_ControlQuestionType] BIGINT        NOT NULL,
    [AuditModifyDateTime]    DATETIME2 (7)   NULL,
    [AuditCreateDateTime]    DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]     NVARCHAR (255)  NULL,
    CONSTRAINT [PK_ControlQuestion] PRIMARY KEY NONCLUSTERED ([PK_ControlQuestion] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ControlQuestion_ControlQuestionType] FOREIGN KEY ([FK_ControlQuestionType]) REFERENCES [ODS].[ControlQuestionType] ([PK_ControlQuestionType]),
    CONSTRAINT [UQ_ControlQuestion_LogicalKey] UNIQUE NONCLUSTERED ([FK_ControlQuestionType] ASC, [QuestionNumber] ASC) WITH (FILLFACTOR = 90)
);

