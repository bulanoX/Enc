﻿CREATE TABLE [ODS].[ReinsuranceLPSOTransactionLine] (
    [FK_LPSOTransaction]             BIGINT           NOT NULL,
    [FK_Syndicate]                   BIGINT           NOT NULL,
    [PositiveLineMultiplier]         NUMERIC (19, 12) NOT NULL,
    [NegativeLineMultiplier]         NUMERIC (19, 12) NOT NULL,
    [PositiveVATLineMultiplier]      NUMERIC (19, 12) NOT NULL,
    [NegativeVATLineMultiplier]      NUMERIC (19, 12) NOT NULL,
    [PositiveDelinkedLineMultiplier] NUMERIC (19, 12) NOT NULL,
    [NegativeDelinkedLineMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]            DATETIME2 (7)    NULL,
    [AuditCreateDateTime]            DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]             NVARCHAR (255)   NULL,
    CONSTRAINT [PK_ReinsuranceLPSOTransactionLine] PRIMARY KEY NONCLUSTERED ([FK_LPSOTransaction] ASC, [FK_Syndicate] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ReinsuranceLPSOTransactionLine_LPSOTransaction] FOREIGN KEY ([FK_LPSOTransaction]) REFERENCES [ODS].[ReinsuranceLPSOTransaction] ([PK_LPSOTransaction]),
    CONSTRAINT [FK_ReinsuranceLPSOTransactionLine_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate])
);





