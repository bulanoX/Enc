﻿CREATE TABLE [ODS].[SlipLineNumber] (
    [PK_SlipLineNumber]     BIGINT          NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)   NULL,
	[AuditCreateDateTime]   DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512)  NULL,
    CONSTRAINT [PK_SlipLineNumber] PRIMARY KEY NONCLUSTERED ([PK_SlipLineNumber] ASC) WITH (FILLFACTOR = 90)
);

