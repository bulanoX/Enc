﻿CREATE TABLE [ODS].[WorkflowCycle] (
    [PK_WorkflowCycle]         BIGINT        NOT NULL,
    [WorkflowCycleName]        VARCHAR (255) NOT NULL,
    [WorkflowCycleDescription] VARCHAR (255) NOT NULL,
    [WorkflowCycleStartStatus] VARCHAR (255) NOT NULL,
    [WorkflowCycleEndStatus]   VARCHAR (255) NULL,
    [WorkflowCycleType]        VARCHAR (255) NOT NULL,
    [IsActivation]             BIT           NOT NULL,
    [WorkflowCycleFullName]    AS            (([WorkflowCycleDescription]+': ')+[WorkflowCycleName]),
    CONSTRAINT [PK_WorkflowCycle] PRIMARY KEY NONCLUSTERED ([PK_WorkflowCycle] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_WorkflowCycle_LogicalKey] UNIQUE NONCLUSTERED ([WorkflowCycleName] ASC) WITH (FILLFACTOR = 90)
);

