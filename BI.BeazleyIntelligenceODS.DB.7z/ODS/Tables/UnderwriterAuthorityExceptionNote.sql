﻿CREATE TABLE [ODS].[UnderwriterAuthorityExceptionNote] (
    [PK_UnderwriterAuthorityExceptionNote] AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',CONVERT([varchar](255),([NoteID])))),(0))PERSISTED NOT NULL,
    [FK_UnderwriterAuthorityException]     BIGINT         NOT NULL,
    [NoteID]                               INT            NOT NULL,
    [NoteText]                             NVARCHAR (MAX) NOT NULL,
    [NoteAddedDate]                        DATETIME       NULL,
    [NoteAddedBy]                          VARCHAR (255)  NULL,
    [NoteAddedDateName]                    AS              IIF(YEAR(NoteAddedDate)< 1990 OR YEAR(NoteAddedDate)>2050,NULL,FORMAT(NoteAddedDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([NoteAddedDate])),
    [AuditModifyDateTime]                  DATETIME2 (7)  NULL,
    [AuditCreateDateTime]                  DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]                   NVARCHAR (255) NULL,
    CONSTRAINT [PK_UnderwriterAuthorityExceptionNote] PRIMARY KEY NONCLUSTERED ([PK_UnderwriterAuthorityExceptionNote] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_UnderwriterAuthorityExceptionNote_UnderwriterAuthorityException] FOREIGN KEY ([FK_UnderwriterAuthorityException]) REFERENCES [ODS].[UnderwriterAuthorityException] ([PK_UnderwriterAuthorityException]),
    CONSTRAINT [UQ_UnderwriterAuthorityExceptionNote_LogicalKey] UNIQUE NONCLUSTERED ([NoteID] ASC) WITH (FILLFACTOR = 90)
);



