﻿CREATE TABLE [ODS].[QuoteFilter] (
    [PK_QuoteFilter] BIGINT        NOT NULL,
    [IsQuote]        BIT           NOT NULL,
    [QuoteFilter]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_QuoteFilter] PRIMARY KEY NONCLUSTERED ([PK_QuoteFilter] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_QuoteFilter_LogicalKey] UNIQUE NONCLUSTERED ([QuoteFilter] ASC) WITH (FILLFACTOR = 90)
);

