﻿CREATE TABLE [ODS].[ClaimDeductibleTracking] (
    [PK_ClaimDeductibleTracking] AS              	ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((((((((((CONVERT([varchar](255),[FK_Claim])+'|~|')+[DeductiblePaymentType])+'|~|')+CONVERT([varchar](255),[BeazleyPaid]))+'|~|')+CONVERT([varchar](255),[Recoverable]))+'|~|')+isnull(CONVERT([varchar],[PaymentDate],(120)),''))+'|~|')+CONVERT([varchar](255),[FK_ClaimCostCategory])))),(0))  PERSISTED NOT NULL,
    [FK_Claim]                   BIGINT          NOT NULL,
    [DeductiblePaymentType]      VARCHAR (255)   NOT NULL,
    [BeazleyPaid]                BIT             NOT NULL,
    [Recoverable]                BIT             NOT NULL,
    [PaymentDate]                DATETIME        NULL,
    [DeductibleAmount]           NUMERIC (19, 2) NOT NULL,
    [FK_ClaimCostCategory]       BIGINT          NOT NULL,
    [FK_PaymentDate]             AS              IIF(YEAR(PaymentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, PaymentDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([PaymentDate])) PERSISTED,
    [AuditModifyDateTime]        DATETIME2 (7)   NULL,
    [AuditCreateDateTime]        DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]         NVARCHAR (255)  NULL,
    CONSTRAINT [PK_ClaimDeductibleTracking] PRIMARY KEY CLUSTERED ([PK_ClaimDeductibleTracking] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimDeductibleTracking_Claim] FOREIGN KEY ([FK_Claim]) REFERENCES [ODS].[Claim] ([PK_Claim]),
    CONSTRAINT [FK_ClaimDeductibleTracking_ClaimCostCategory] FOREIGN KEY ([FK_ClaimCostCategory]) REFERENCES [ODS].[ClaimCostCategory] ([PK_ClaimCostCategory]),
    CONSTRAINT [UQ_ClaimDeductibleTracking_LogicalKey] UNIQUE NONCLUSTERED ([FK_Claim] ASC, [DeductiblePaymentType] ASC, [BeazleyPaid] ASC, [Recoverable] ASC, [PaymentDate] ASC, [FK_ClaimCostCategory] ASC) WITH (FILLFACTOR = 90)
);

