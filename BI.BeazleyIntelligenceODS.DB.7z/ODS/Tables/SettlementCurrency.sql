﻿CREATE TABLE [ODS].[SettlementCurrency] (
    [PK_SettlementCurrency]  BIGINT        NOT NULL,
    [CurrencyCode]           VARCHAR (255) NOT NULL,
    [CurrencyName]           VARCHAR (255) NOT NULL,
    [AllowReportingCurrency] BIT           NOT NULL,
    [CurrencyFormatString]   AS            ([ODS].[udf_CurrencyFormatString]([CurrencyCode])),
    CONSTRAINT [PK_SettlementCurrency] PRIMARY KEY CLUSTERED ([PK_SettlementCurrency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_SettlementCurrency_LogicalKey] UNIQUE NONCLUSTERED ([CurrencyCode] ASC) WITH (FILLFACTOR = 90)
);








































GO
CREATE NONCLUSTERED INDEX [IDX_SettlementCurrency_001]
    ON [ODS].[SettlementCurrency]([CurrencyCode] ASC) WITH (FILLFACTOR = 90);

