﻿CREATE TABLE [ODS].[ClassOfBusiness] (
    [PK_ClassOfBusiness]   AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([ClassOfBusinessCode])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]      BIT           CONSTRAINT [DEF_ClassOfBusiness_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ClassOfBusinessCode]  VARCHAR (255) NOT NULL,
    [ClassOfBusiness]      VARCHAR (255) NOT NULL,
    [ClassOfBusinessGroup] VARCHAR (255) NULL,
    [EffectiveFrom]        DATETIME      NULL,
    [EffectiveTo]          DATETIME      NULL,
    [TerrorismClass]       BIT           NOT NULL,
    [FK_EffectiveFrom]     AS            IIF(YEAR(EffectiveFrom) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EffectiveFrom),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EffectiveFrom])) PERSISTED,
    [FK_EffectiveTo]       AS            IIF(YEAR(EffectiveTo) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EffectiveTo),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EffectiveTo])) PERSISTED,
    [TerrorismClassName]   AS            (IIF(TerrorismClass = 1, 'Terrorism','Non-Terrorism')), --([ODS].[udf_FormatBit]([TerrorismClass],'Terrorism','Non-Terrorism','Non-Terrorism')),
    [AuditModifyDateTime]                      DATETIME2 (7)      NULL,
    [AuditCreateDateTime]                      DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                       NVARCHAR (255)     NULL,
    CONSTRAINT [PK_ClassOfBusiness] PRIMARY KEY CLUSTERED ([PK_ClassOfBusiness] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClassOfBusiness_LogicalKey] UNIQUE NONCLUSTERED ([ClassOfBusinessCode] ASC) WITH (FILLFACTOR = 90)
);

