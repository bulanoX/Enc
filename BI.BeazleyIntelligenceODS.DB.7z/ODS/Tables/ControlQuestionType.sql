﻿CREATE TABLE [ODS].[ControlQuestionType] (
    [PK_ControlQuestionType] BIGINT        NOT NULL,
    [ControlQuestionType]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_ControlQuestionType] PRIMARY KEY NONCLUSTERED ([PK_ControlQuestionType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ControlQuestionType_LogicalKey] UNIQUE NONCLUSTERED ([ControlQuestionType] ASC) WITH (FILLFACTOR = 90)
);

