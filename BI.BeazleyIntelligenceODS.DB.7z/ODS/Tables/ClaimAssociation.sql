﻿CREATE TABLE [ODS].[ClaimAssociation] (
	[PK_ClaimAssociation]  AS       IIF([IsUnknownMember] = 1, 0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(([AssociationReason]+'|~|')+[AssociationName]))),(0))) PERSISTED NOT NULL,
    [AssociationReason]      VARCHAR (255) NOT NULL,
    [AssociationName]        VARCHAR (255) NOT NULL,
    [IsUnknownMember]        BIT           CONSTRAINT [DEF_ClaimAssociation_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [AuditModifyDateTime]    datetime2(7)  NULL,
	[AuditCreateDateTime]    datetime2(7)  DEFAULT (getdate()) NULL,
	[AuditModifyDetails]     nvarchar(255) NULL,
	CONSTRAINT [PK_ClaimAssociation] PRIMARY KEY NONCLUSTERED ([PK_ClaimAssociation] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClaimAssociation_LogicalKey] UNIQUE NONCLUSTERED ([AssociationReason] ASC, [AssociationName] ASC) WITH (FILLFACTOR = 90)
);


