﻿CREATE TABLE [ODS].[TriFocus] (
    [PK_TriFocus]                 AS             IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([TriFocusCode])))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]             BIT            CONSTRAINT [DEF_TriFocus_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [TriFocusCode]                VARCHAR (255)  NOT NULL,
    [TriFocusName]                VARCHAR (255)  NOT NULL,
    [DepartmentName]              VARCHAR (255)  NOT NULL,
    [EurobaseDepartmentName]      VARCHAR (255)  NULL,
    [LongTermBenchmarkMultiplier] AS             (0.7),
    [Division]                    VARCHAR (255)  NULL,
    [AuditModifyDateTime]         DATETIME2 (7)  NULL,
    [AuditCreateDateTime]         DATETIME2 (7)  NULL,
    [AuditModifyDetails]          NVARCHAR (255) NULL,
    CONSTRAINT [PK_TriFocus] PRIMARY KEY CLUSTERED ([PK_TriFocus] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_TriFocus_LogicalKey] UNIQUE NONCLUSTERED ([TriFocusCode] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_TriFocus_Name] UNIQUE NONCLUSTERED ([TriFocusName] ASC) WITH (FILLFACTOR = 90)
);



