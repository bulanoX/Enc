﻿CREATE TABLE [ODS].[ClaimCostCategory] (
    [PK_ClaimCostCategory]     AS             ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([ClaimCostCategory]))),(0))  PERSISTED NOT NULL,
    [ClaimCostCategory]        VARCHAR (255)  NOT NULL,
    [ClaimCostCategoryGroup]   VARCHAR (255)  NOT NULL,
    [CCCostCategoryName]       VARCHAR (255)  NULL,
    [IsDeductibleCategory]     BIT            NOT NULL,
    [IsDeductibleCategoryName] AS             (IIF(IsDeductibleCategory = 1, 'Deductible','Non-Deductible')), --([ODS].[udf_FormatBit]([IsDeductibleCategory],'Deductible','Non-Deductible','Non-Deductible')),
    [AuditModifyDateTime]      DATETIME2 (7)  NULL,
    [AuditCreateDateTime]      DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]       NVARCHAR (255) NULL,
    CONSTRAINT [PK_ClaimCostCategory] PRIMARY KEY NONCLUSTERED ([PK_ClaimCostCategory] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClaimCostCategory_LogicalKey] UNIQUE NONCLUSTERED ([ClaimCostCategory] ASC) WITH (FILLFACTOR = 90)
);

