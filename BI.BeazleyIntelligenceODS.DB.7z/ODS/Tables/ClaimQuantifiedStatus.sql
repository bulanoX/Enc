﻿CREATE TABLE [ODS].[ClaimQuantifiedStatus] (
    [PK_ClaimQuantifiedStatus] AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([QuantifiedStatusCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]          BIT           NOT NULL,
    [QuantifiedStatusCode]     VARCHAR (255) NOT NULL,
    [QuantifiedStatus]         VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_ClaimQuantifiedStatus] PRIMARY KEY NONCLUSTERED ([PK_ClaimQuantifiedStatus] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClaimQuantifiedStatus_LogicalKey] UNIQUE NONCLUSTERED ([QuantifiedStatusCode] ASC) WITH (FILLFACTOR = 90)
);

