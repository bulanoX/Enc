﻿CREATE TABLE [ODS].[NonLloydsPremiumTransaction] (
    [PK_NonLloydsPremiumTransaction]       BIGINT           NOT NULL,
    [DateCreated]                          DATETIME         NULL,
    [EffectiveFromDate]                    DATETIME         NULL,
    [EffectiveToDate]                      DATETIME         NULL,
    [AccountingPeriod]                     DATETIME         NOT NULL,
    [SettlementDate]                       DATETIME         NULL,
    [TransactionTypeCode]                  VARCHAR (255)    NULL,
    [TransactionType]                      VARCHAR (255)    NULL,
    [GrossPremiumInOriginalCCY]            NUMERIC (19, 4)  NOT NULL,
    [ExternalAcquisitionCostInOriginalCCY] NUMERIC (19, 4)  NOT NULL,
    [OriginalCCYToSettlementCCYRate]       NUMERIC (19, 12) NOT NULL,
    [OriginalCCYToLocalCCYRate]            NUMERIC (19, 12) NOT NULL,
    [FK_Section]                           BIGINT           NOT NULL,
    [FK_OriginalCurrency]                  BIGINT           NOT NULL,
    [FK_SettlementCurrency]                BIGINT           NOT NULL,
    [FK_LocalCurrency]                     BIGINT           NOT NULL,
    [FK_DevelopmentPeriod]                 BIGINT           NOT NULL,
    [FK_DateCreated]                       AS               IIF(YEAR(DateCreated) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, DateCreated),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([DateCreated])) PERSISTED,
    [FK_AccountingPeriod]                  AS               IIF(YEAR(AccountingPeriod) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, AccountingPeriod),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([AccountingPeriod])) PERSISTED,
    [FK_EffectiveFromDate]                 AS               IIF(YEAR(EffectiveFromDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EffectiveFromDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EffectiveFromDate])) PERSISTED,
    [FK_EffectiveToDate]                   AS               IIF(YEAR(EffectiveToDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EffectiveToDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EffectiveToDate])) PERSISTED,
    [FK_SettlementDate]                    AS               IIF(YEAR(SettlementDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, SettlementDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([SettlementDate])) PERSISTED,
    [RiskLocation]                         NVARCHAR (255)   NULL,
    [InvoiceReference]                     VARCHAR (255)    NULL,
    [NumberOfInstalments]                  INT              NULL,
    [PaymentFrequency]                     VARCHAR (255)    NULL,
    [PaymentMethod]                        VARCHAR (255)    NULL,
    [PaymentReference]                     VARCHAR (255)    NULL,
    [Notes]								   NVARCHAR(1000)   NULL,
	[PolicyOrEndorsementReference]		   NVARCHAR(255)    NULL,
    [AuditModifyDateTime]                  datetime2(7)     NULL,
	[AuditCreateDateTime]                  datetime2(7)     CONSTRAINT [DEF_NonLloydsPremiumTransaction_AuditCreateDateTime] DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]                   nvarchar(255)    NULL,
    CONSTRAINT [PK_NonLloydsPremiumTransaction] PRIMARY KEY CLUSTERED ([PK_NonLloydsPremiumTransaction] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_NonLloydsPremiumTransaction_OriginalCCYToSettlementCCYRate] CHECK ([OriginalCCYToSettlementCCYRate]>(0)),
    CONSTRAINT [FK_NonLloydsPremiumTransaction_DevelopmentPeriod] FOREIGN KEY ([FK_DevelopmentPeriod]) REFERENCES [ODS].[DevelopmentPeriod] ([PK_DevelopmentPeriod]),
    CONSTRAINT [FK_NonLloydsPremiumTransaction_LocalCurrency] FOREIGN KEY ([FK_LocalCurrency]) REFERENCES [ODS].[LocalCurrency] ([PK_LocalCurrency]),
    CONSTRAINT [FK_NonLloydsPremiumTransaction_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_NonLloydsPremiumTransaction_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_NonLloydsPremiumTransaction_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency])
);










GO
CREATE NONCLUSTERED INDEX [IDX_001]
    ON [ODS].[NonLloydsPremiumTransaction]([FK_Section] ASC)
    INCLUDE([GrossPremiumInOriginalCCY], [ExternalAcquisitionCostInOriginalCCY]) WITH (FILLFACTOR = 90);

