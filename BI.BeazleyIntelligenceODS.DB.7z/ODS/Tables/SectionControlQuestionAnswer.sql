﻿CREATE TABLE [ODS].[SectionControlQuestionAnswer] (
    [PK_SectionControlQuestionAnswer]      AS               ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((CONVERT([varchar](255),[FK_Section])+'|~|')+CONVERT([varchar](255),[FK_ControlQuestion])))),(0)) PERSISTED NOT NULL,
    [StringAnswer]                         VARCHAR (MAX)    NULL,
    [IntAnswer]                            INT              NULL,
    [NumericAnswer]                        DECIMAL (38, 16) NULL,
    [DateAnswer]                           DATETIME         NULL,
    [AnswerCount]                          INT              NOT NULL,
    [FK_Section]                           BIGINT           NOT NULL,
    [FK_TriFocus]                          BIGINT           NOT NULL,
    [FK_ControlQuestion]                   BIGINT           NOT NULL,
    [FK_YOA]                               BIGINT           NOT NULL,
    [FK_SettlementCurrency]                BIGINT           NOT NULL,
    [FK_OriginalCurrency]                  BIGINT           NOT NULL,
    [FK_LocalCurrency]                     BIGINT           CONSTRAINT [DF__SectionCo__FK_Lo__62EF9734] DEFAULT ((0)) NOT NULL,
    [FK_HiddenStatusFilter]                BIGINT           NOT NULL,
    [FK_QuoteFilter]                       BIGINT           NOT NULL,
    [FK_Policy]                            BIGINT           NOT NULL,
    [FK_CRMBroker]                         BIGINT           NOT NULL,
    [SpecialPurposeSyndicateApplies]       BIT              NOT NULL,
    [SectionControlQuestionAnswerCombined] AS               (case when [StringAnswer] IS NOT NULL then [StringAnswer] when [IntAnswer] IS NOT NULL then format([IntAnswer], '###,###,###,###') when [NumericAnswer] IS NOT NULL then format([NumericAnswer], '###,###,###,###.##') when [DateAnswer] IS NOT NULL then [ODS].[udf_FormatDateTime]([DateAnswer])  end),
    [ContractCertaintyAnswerCode]          INT              NULL,
    [FK_UnderwritingPlatform]              BIGINT           NOT NULL,
    [FK_InternalWrittenBinderStatus]       BIGINT           NOT NULL,
    [FK_ServiceCompany]                    BIGINT           NOT NULL,
    [AuditModifyDateTime]                  DATETIME2(7)     NULL,
	[AuditCreateDateTime]                  DATETIME2 (7)    DEFAULT (getdate()) NULL,
	[AuditModifyDetails]                   NVARCHAR (255)   NULL,
    CONSTRAINT [PK_SectionControlQuestionAnswer] PRIMARY KEY NONCLUSTERED ([PK_SectionControlQuestionAnswer] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_SectionControlQuestionAnswer_HasAnswer] CHECK ([StringAnswer] IS NOT NULL OR [IntAnswer] IS NOT NULL OR [NumericAnswer] IS NOT NULL OR [DateAnswer] IS NOT NULL),
    CONSTRAINT [FK_SectionControlQuestionAnswer_ControlQuestion] FOREIGN KEY ([FK_ControlQuestion]) REFERENCES [ODS].[ControlQuestion] ([PK_ControlQuestion]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_LocalCurrency] FOREIGN KEY ([FK_LocalCurrency]) REFERENCES [ODS].[LocalCurrency] ([PK_LocalCurrency]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform]),
    CONSTRAINT [FK_SectionControlQuestionAnswer_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_SectionControlQuestionAnswer_LogicalKey] UNIQUE NONCLUSTERED ([FK_Section] ASC, [FK_ControlQuestion] ASC) WITH (FILLFACTOR = 90)
);
GO

CREATE NONCLUSTERED INDEX [IDX_SectionControlQuestionAnswer_001] 
       ON [ODS].[SectionControlQuestionAnswer] ([FK_ControlQuestion])
       INCLUDE ([AnswerCount],[FK_Section])
GO



