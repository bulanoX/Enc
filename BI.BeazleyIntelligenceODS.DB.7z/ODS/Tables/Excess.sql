﻿CREATE TABLE [ODS].[Excess] (
    [PK_Excess]             AS           IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([ExcessCode])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]       BIT           CONSTRAINT [DEF_Excess_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ExcessCode]            VARCHAR (255) NOT NULL,
    [ExcessName]            VARCHAR (255) NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512) NULL,
    CONSTRAINT [PK_Excess] PRIMARY KEY NONCLUSTERED ([PK_Excess] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Excess_LogicalKey] UNIQUE NONCLUSTERED ([ExcessCode] ASC) WITH (FILLFACTOR = 90)
);

