﻿CREATE TABLE [ODS].[UnderwriterWorkflow] (
    [PK_UnderwriterWorkflow]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((isnull(upper([UnderwriterUserInitials]),'')+'|~|')+isnull(upper([UnderwriterName]),'')))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]         BIT            CONSTRAINT [DEF_UnderwriterWorkflow_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [UnderwriterUserInitials] VARCHAR (255)  NULL,
    [UnderwriterInitials]     VARCHAR (255)  NULL,
    [UnderwriterName]         VARCHAR (255)  NULL,
    [AuditModifyDateTime]     DATETIME2 (7)  NULL,
    [AuditCreateDateTime]     DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]      NVARCHAR (255) NULL,
    CONSTRAINT [PK_UnderwriterWorkflow] PRIMARY KEY CLUSTERED ([PK_UnderwriterWorkflow] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_UnderwriterWorkflow_LogicalKey] UNIQUE NONCLUSTERED ([UnderwriterUserInitials] ASC, [UnderwriterName] ASC) WITH (FILLFACTOR = 90)
);

