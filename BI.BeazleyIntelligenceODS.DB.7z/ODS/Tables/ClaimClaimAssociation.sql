﻿CREATE TABLE [ODS].[ClaimClaimAssociation] (
   	[PK_ClaimClaimAssociation]  AS (IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(((CONVERT([varchar](255),[FK_Claim])+'|~|')+CONVERT([varchar](255),[FK_ClaimAssociation]))+CONVERT([varchar](255),[AssociationPrimary])))),(0)))) PERSISTED NOT NULL,
    [FK_Claim]              BIGINT NOT NULL,
    [FK_ClaimAssociation]   BIGINT NOT NULL,
    [AssociationSequenceId] INT    DEFAULT(0) NULL,  -- to be removed in the future if no problems will appear on production
    [AssociationPrimary]     BIT   NULL,
    [AssociationPrimaryName] AS    (IIF(AssociationPrimary = 1 , 'Yes' , 'No')), -- ([ODS].[udf_FormatBitAsYesNo]([AssociationPrimary])),
    [IsUnknownMember]        BIT   CONSTRAINT [DEF_ClaimClaimAssociation_IsUnknownMemer] DEFAULT ((0)) NOT NULL,
    [AuditModifyDateTime]    DATETIME2 (7)   NULL,
    [AuditCreateDateTime]    DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]     NVARCHAR (255)  NULL,
	CONSTRAINT [PK_ClaimClaimAssociation] PRIMARY KEY NONCLUSTERED ([PK_ClaimClaimAssociation] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimClaimAssociation_Claim] FOREIGN KEY ([FK_Claim]) REFERENCES [ODS].[Claim] ([PK_Claim]),
    CONSTRAINT [FK_ClaimClaimAssociation_ClaimAssociation] FOREIGN KEY ([FK_ClaimAssociation]) REFERENCES [ODS].[ClaimAssociation] ([PK_ClaimAssociation]),
   -- CONSTRAINT [UQ_ClaimClaimAssociation_SequenceId] UNIQUE NONCLUSTERED ([FK_Claim] ASC, [AssociationSequenceId] ASC) WITH (FILLFACTOR = 90)
);
