﻿CREATE TABLE [ODS].[SectionExcess] (
    [FK_Section]              BIGINT          NOT NULL,
    [FK_Excess]               BIGINT          NOT NULL,
    [FK_ExcessCurrency]       BIGINT          NOT NULL,
    [ExcessAmountInExcessCCY] NUMERIC (19, 4) NULL,
    [AuditModifyDateTime]     DATETIME2 (7)  NULL,
    [AuditCreateDateTime]     DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]      NVARCHAR (255) NULL,
    CONSTRAINT [PK_SectionExcess] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_Excess] ASC, [FK_ExcessCurrency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionExcess_Excess] FOREIGN KEY ([FK_Excess]) REFERENCES [ODS].[Excess] ([PK_Excess]),
    CONSTRAINT [FK_SectionExcess_OriginalCurrency_LimitCurrency] FOREIGN KEY ([FK_ExcessCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_SectionExcess_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

