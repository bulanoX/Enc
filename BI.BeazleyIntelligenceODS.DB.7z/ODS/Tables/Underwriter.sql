﻿CREATE TABLE [ODS].[Underwriter] (
    [PK_Underwriter]          AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((isnull(upper([UnderwriterUserInitials]),'')+'|~|')+isnull(upper([UnderwriterName]),'')))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]         BIT           CONSTRAINT [DEF_Underwriter_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [UnderwriterUserInitials] VARCHAR (255) NULL,
    [UnderwriterInitials]     VARCHAR (255) NULL,
    [UnderwriterName]         VARCHAR (255) NULL,
    [UnderwriterOffice]       VARCHAR (255) NULL,
    [UnderwriterCountry]      VARCHAR (255) NULL,
    [UnderwriterLogin]        VARCHAR (255) NULL,
    CONSTRAINT [PK_Underwriter] PRIMARY KEY CLUSTERED ([PK_Underwriter] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Underwriter_LogicalKey] UNIQUE NONCLUSTERED ([UnderwriterUserInitials] ASC, [UnderwriterName] ASC) WITH (FILLFACTOR = 90)
);

