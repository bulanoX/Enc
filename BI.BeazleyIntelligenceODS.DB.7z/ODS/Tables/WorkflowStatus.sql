﻿CREATE TABLE [ODS].[WorkflowStatus] (
    [PK_WorkflowStatus]     AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',upper([WorkflowStatusCode]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]       BIT           CONSTRAINT [DEF_WorkflowStatus_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [WorkflowStatusCode]    VARCHAR (255) NOT NULL,
    [WorkflowStatusName]    VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512) NULL,
    CONSTRAINT [PK_WorkflowStatus] PRIMARY KEY CLUSTERED ([PK_WorkflowStatus] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_WorkflowStatus_LogicalKey] UNIQUE NONCLUSTERED ([WorkflowStatusCode] ASC) WITH (FILLFACTOR = 90)
);

