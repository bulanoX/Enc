﻿CREATE TABLE [ODS].[SectionAcquisitionCost] (
    [FK_Section]                BIGINT           NOT NULL,
    [FK_EntityPerspective]      BIGINT           NOT NULL,
    [FK_AcquisitionCostType]    BIGINT           NOT NULL,
    [TaxDescription]            NVARCHAR (255)  CONSTRAINT [DEF_SectionAcquisitionCost_TaxDescription] DEFAULT ('N/A') NOT NULL,
    [AcquisitionCostMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]       DATETIME2(7)     NULL,
	[AuditCreateDateTime]       DATETIME2 (7)    DEFAULT (getdate()) NULL,
	[AuditModifyDetails]        NVARCHAR (255)   NULL,
    CONSTRAINT [PK_SectionAcquisitionCost] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_EntityPerspective] ASC, [FK_AcquisitionCostType] ASC, TaxDescription ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionAcquisitionCost_AcquisitionCostType] FOREIGN KEY ([FK_AcquisitionCostType]) REFERENCES [ODS].[AcquisitionCostType] ([PK_AcquisitionCostType]),
    CONSTRAINT [FK_SectionAcquisitionCost_EntityPerspective] FOREIGN KEY ([FK_EntityPerspective]) REFERENCES [ODS].[EntityPerspective] ([PK_EntityPerspective]),
    CONSTRAINT [FK_SectionAcquisitionCost_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);
