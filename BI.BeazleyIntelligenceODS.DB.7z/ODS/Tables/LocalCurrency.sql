﻿CREATE TABLE [ODS].[LocalCurrency] (
    [PK_LocalCurrency]       BIGINT        NOT NULL,
    [CurrencyCode]           VARCHAR (255) NOT NULL,
    [CurrencyName]           VARCHAR (255) NOT NULL,
    [AllowReportingCurrency] BIT           NOT NULL,
    [CurrencyFormatString]   AS            ([ODS].[udf_CurrencyFormatString]([CurrencyCode])),
    CONSTRAINT [PK_LocalCurrency] PRIMARY KEY CLUSTERED ([PK_LocalCurrency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_LocalCurrency_LogicalKey] UNIQUE NONCLUSTERED ([CurrencyCode] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IDX_LocalCurrency_001]
    ON [ODS].[LocalCurrency]([CurrencyCode] ASC) WITH (FILLFACTOR = 90);

