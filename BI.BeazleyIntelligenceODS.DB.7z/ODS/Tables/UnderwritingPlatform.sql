﻿CREATE TABLE [ODS].[UnderwritingPlatform] (
    [PK_UnderwritingPlatform]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([UnderwritingPlatformCode])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]          BIT           CONSTRAINT [DEF_UnderwritingPlatform_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [IsBID]                    BIT           NOT NULL,
    [IsBIDName]                AS            (IIF(IsBID = 1, 'BID','Non BID')), --([ODS].[udf_FormatBit]([IsBID],'BID','Non BID','Non BID')),
    [IsFiltered]               BIT           CONSTRAINT [DEF_UnderwritingPlatform_IsFiltered] DEFAULT ((0)) NOT NULL,
    [IsFilteredName]           AS            (IIF(IsFiltered = 1, 'No','Yes')), --([ODS].[udf_FormatBit]([IsFiltered],'No','Yes','Yes')),
    [UnderwritingPlatformCode] VARCHAR (255) NOT NULL,
    [UnderwritingPlatformName] VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_UnderwritingPlatform] PRIMARY KEY CLUSTERED ([PK_UnderwritingPlatform] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_UnderwritingPlatform_LogicalKey] UNIQUE NONCLUSTERED ([UnderwritingPlatformCode] ASC) WITH (FILLFACTOR = 90)
);

