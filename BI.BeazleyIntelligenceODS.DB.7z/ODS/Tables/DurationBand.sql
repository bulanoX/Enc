﻿CREATE TABLE [ODS].[DurationBand] (
    [PK_DurationBand]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([varchar](255),[BandMinMonths])))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]  BIT           CONSTRAINT [DEF_DurationBand_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [BandMinMonths]    INT           NOT NULL,
    [BandMaxMonths]    INT           NOT NULL,
    [BandQuarters]     INT           NOT NULL,
    [BandYears]        INT           NOT NULL,
    [BandMonthsName]   VARCHAR (255) NOT NULL,
    [BandQuartersName] VARCHAR (255) NOT NULL,
    [BandYearsName]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_DurationBand] PRIMARY KEY CLUSTERED ([PK_DurationBand] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_DurationBand_LogicalKey] UNIQUE NONCLUSTERED ([BandMinMonths] ASC) WITH (FILLFACTOR = 90)
);

