﻿CREATE TABLE [ODS].[ConditionType] (
    [PK_ConditionType]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([ConditionTypeCode])))),(0)))PERSISTED NOT NULL,
    [IsUnknownMember]   BIT           CONSTRAINT [DEF_ConditionType_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ConditionTypeCode] VARCHAR (255) NOT NULL,
    [ConditionTypeName] VARCHAR (255) NULL,
    [AuditModifyDateTime]         DATETIME2 (7)      NULL,
    [AuditCreateDateTime]         DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]          NVARCHAR (255)     NULL,
    CONSTRAINT [PK_ConditionType] PRIMARY KEY NONCLUSTERED ([PK_ConditionType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ConditionType_LogicalKey] UNIQUE NONCLUSTERED ([ConditionTypeCode] ASC) WITH (FILLFACTOR = 90)
);

