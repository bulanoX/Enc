﻿CREATE TABLE [ODS].[DimDate] (
    [PK_Date]             AS             IIF(YEAR([Date]) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, [Date]),DATEADD(DAY, -53690, 0)) PERSISTED NOT NULL,--(isnull([Utility].[udf_GenerateDateKey]([Date]),(0))) PERSISTED NOT NULL,
    [Date]                DATETIME      NOT NULL,
    [DateName]            VARCHAR (255) NOT NULL,
    [Year]                DATETIME      NOT NULL,
    [YearName]            VARCHAR (255) NOT NULL,
    [Quarter]             DATETIME      NOT NULL,
    [QuarterName]         VARCHAR (255) NOT NULL,
    [Month]               DATETIME      NOT NULL,
    [MonthName]           VARCHAR (255) NOT NULL,
    [Week]                DATETIME      NOT NULL,
    [WeekName]            VARCHAR (255) NOT NULL,
    [DayOfYear]           INT           NOT NULL,
    [DayOfYearName]       VARCHAR (255) NOT NULL,
    [DayOfQuarter]        INT           NOT NULL,
    [DayOfQuarterName]    VARCHAR (255) NOT NULL,
    [DayOfMonth]          INT           NOT NULL,
    [DayOfMonthName]      VARCHAR (255) NOT NULL,
    [DayOfWeek]           INT           NOT NULL,
    [DayOfWeekName]       VARCHAR (255) NOT NULL,
    [WeekOfYear]          INT           NOT NULL,
    [WeekOfYearName]      VARCHAR (255) NOT NULL,
    [MonthOfYear]         INT           NOT NULL,
    [MonthOfYearName]     VARCHAR (255) NOT NULL,
    [MonthOfQuarter]      INT           NOT NULL,
    [MonthOfQuarterName]  VARCHAR (255) NOT NULL,
    [QuarterOfYear]       INT           NOT NULL,
    [QuarterOfYearName]   VARCHAR (255) NOT NULL,
    [InLastFull12Months]  BIT           CONSTRAINT [DEF_DimDate_InLastFull12Months] DEFAULT ((0)) NOT NULL,
    [InLastFull24Months]  BIT           CONSTRAINT [DEF_DimDate_InLastFull24Months] DEFAULT ((0)) NOT NULL,
    [InRolling9Weeks]     BIT           CONSTRAINT [DEF_DimDate_InRolling9Weeks] DEFAULT ((0)) NOT NULL,
    [ControlsYear]        DATETIME      NOT NULL,
    [ControlsYearName]    VARCHAR (255) NOT NULL,
    [ControlsQuarter]     DATETIME      NOT NULL,
    [ControlsQuarterName] VARCHAR (255) NOT NULL,
    [ControlsMonth]       DATETIME      NOT NULL,
    [ControlsMonthName]   VARCHAR (255) NOT NULL,
    [RelativeDate]        INT           NULL,
    [RelativeDateName]    VARCHAR (255) NULL,
    [RelativeWeek]        INT           NULL,
    [RelativeWeekName]    VARCHAR (255) NULL,
    [RelativeMonth]       INT           NULL,
    [RelativeMonthName]   VARCHAR (255) NULL,
    [RelativeQuarter]     INT           NULL,
    [RelativeQuarterName] VARCHAR (255) NULL,
    [RelativeYear]        INT           NULL,
    [RelativeYearName]    VARCHAR (255) NULL,
    CONSTRAINT [PK_DimDate] PRIMARY KEY CLUSTERED ([PK_Date] ASC) WITH (FILLFACTOR = 90)
);

















































