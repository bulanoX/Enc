﻿CREATE TABLE [ODS].[SectionSPA] (
    [FK_Section]             BIGINT           NOT NULL,
    [SPASyndicateNumber]     BIGINT           NOT NULL,
    [SPASyndicateMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]           DATETIME2 (7)  NULL,
    [AuditCreateDateTime]           DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]            NVARCHAR (255) NULL,
    CONSTRAINT [PK_SectionSPA] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [SPASyndicateNumber] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionSPA_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

