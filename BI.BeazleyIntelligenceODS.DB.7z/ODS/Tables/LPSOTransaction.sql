﻿CREATE TABLE [ODS].[LPSOTransaction] (
    [PK_LPSOTransaction]                           BIGINT           NOT NULL,
    [SigningDate]                                  DATETIME         NOT NULL,
    [SigningNumber]                                INT              NOT NULL,
    [SigningBureauVersionNumber]                   INT              NULL,
    [BrokerSigningDate]                            DATETIME         NULL,
    [BrokerSigningNumber]                          INT              NULL,
    [ProcessingDate]                               DATETIME         NULL,
    [ProcessingPeriodDate]                         DATETIME         NULL,
    [SettlementDate]                               DATETIME         NULL,
    [ActualPaymentDate]                            DATETIME         NULL,
    [CategoryCode]                                 INT              NOT NULL,
    [Category]                                     VARCHAR (255)    NOT NULL,
    [BusinessCategoryCode]                         VARCHAR (15)     NULL,
    [BusinessCategory]                             VARCHAR (255)    NULL,
    [RiskClassCode]                                VARCHAR (15)     NULL,
    [RiskClass]                                    VARCHAR (255)    NULL,
    [FilCode]                                      VARCHAR (15)     NULL,
    [Fil]                                          VARCHAR (255)    NULL,
    [DTICode]                                      VARCHAR (15)     NULL,
    [QualCatCode]                                  VARCHAR (1)      NULL,
    [QualCat]                                      VARCHAR (255)    NULL,
    [LPSOBrokerReference]                          VARCHAR (255)    NULL,
    [OriginalCCYToSettlementCCYRate]               NUMERIC (19, 12) NOT NULL,
    [PositiveAmountInOriginalCCY]                  NUMERIC (38, 12) NOT NULL,
    [PositiveVATAmountInOriginalCCY]               NUMERIC (38, 12) NOT NULL,
    [PositiveDelinkedAmountInOriginalCCY]          NUMERIC (38, 12) NOT NULL,
    [PositiveIPTOverseasTaxAmountInOriginalCCY]    NUMERIC (38, 12) NOT NULL,
    [PositiveIPTUKTaxAmountInOriginalCCY]          NUMERIC (38, 12) NOT NULL,
    [PositiveAmountExcIPTOverseasTaxInOriginalCCY] NUMERIC (38, 12) NOT NULL,
    [NegativeAmountInOriginalCCY]                  NUMERIC (38, 12) NOT NULL,
    [NegativeVATAmountInOriginalCCY]               NUMERIC (38, 12) NOT NULL,
    [NegativeDelinkedAmountInOriginalCCY]          NUMERIC (38, 12) NOT NULL,
    [NegativeIPTOverseasTaxAmountInOriginalCCY]    NUMERIC (38, 12) NOT NULL,
    [NegativeIPTUKTaxAmountInOriginalCCY]          NUMERIC (38, 12) NOT NULL,
    [NegativeAmountExcIPTOverseasTaxInOriginalCCY] NUMERIC (38, 12) NOT NULL,
    [GQDDate]                                      DATETIME         NULL,
    [ExternalAcquisitionCostMultiplier]            NUMERIC (19, 12) NOT NULL,
    [InternalAcquisitionCostMultiplier]            NUMERIC (19, 12) NOT NULL,
    [FK_Section]                                   BIGINT           NOT NULL,
    [FK_OriginalCurrency]                          BIGINT           NOT NULL,
    [FK_SettlementCurrency]                        BIGINT           NOT NULL,
    [FK_YOA]                                       BIGINT           NOT NULL,
    [FK_GQDTransactionType]                        BIGINT           NOT NULL,
    [FK_DevelopmentPeriod]                         BIGINT           NOT NULL,
    [FK_ClaimExposure]                             BIGINT           NULL,
    [FK_ProcessingDate]                            AS                IIF(YEAR(ProcessingDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ProcessingDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([ProcessingDate])) PERSISTED,
    [FK_SigningDate]                               AS                IIF(YEAR(SigningDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, SigningDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([SigningDate])) PERSISTED,
    [FK_BrokerSigningDate]                         AS                IIF(YEAR(BrokerSigningDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, BrokerSigningDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([BrokerSigningDate])) PERSISTED,
    [FK_ProcessingPeriodDate]                      AS                IIF(YEAR(ProcessingPeriodDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ProcessingPeriodDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([ProcessingPeriodDate])) PERSISTED,
    [FK_SettlementDate]                            AS                IIF(YEAR(SettlementDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, SettlementDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([SettlementDate])) PERSISTED,
    [FK_ActualPaymentDate]                         AS                IIF(YEAR(ActualPaymentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ActualPaymentDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([ActualPaymentDate])) PERSISTED,
    [FK_GQDDate]                                   AS                IIF(YEAR(GQDDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, GQDDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([GQDDate])) PERSISTED,
    [HasVatAmount]                                 AS               (case when (abs([PositiveVatAmountInOriginalCCY])+abs([NegativeVatAmountInOriginalCCY]))<>(0) then 'Yes' else 'No' end),
    [SigningDateName]                              AS               IIF(YEAR(SigningDate)< 1990 OR YEAR(SigningDate)>2050,NULL,FORMAT(SigningDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([SigningDate])),
    [BrokerSigningDateName]                        AS               IIF(YEAR(BrokerSigningDate)< 1990 OR YEAR(BrokerSigningDate)>2050,NULL,FORMAT(BrokerSigningDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([BrokerSigningDate])),
    [SpecialPurposeSyndicateApplies]               BIT              NOT NULL,
    [AuditModifyDateTime]                          DATETIME2 (7)    NULL,
    [AuditCreateDateTime]                          DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                           NVARCHAR (255)   NULL,
    CONSTRAINT [PK_LPSOTransaction] PRIMARY KEY NONCLUSTERED ([PK_LPSOTransaction] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_LPSOTransaction_ClaimExposure] FOREIGN KEY ([FK_ClaimExposure]) REFERENCES [ODS].[ClaimExposure] ([PK_ClaimExposure]),
    CONSTRAINT [FK_LPSOTransaction_DevelopmentPeriod] FOREIGN KEY ([FK_DevelopmentPeriod]) REFERENCES [ODS].[DevelopmentPeriod] ([PK_DevelopmentPeriod]),
    CONSTRAINT [FK_LPSOTransaction_GQDTransactionType] FOREIGN KEY ([FK_GQDTransactionType]) REFERENCES [ODS].[GQDTransactionType] ([PK_GQDTransactionType]),
    CONSTRAINT [FK_LPSOTransaction_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_LPSOTransaction_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_LPSOTransaction_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_LPSOTransaction_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA])
);















