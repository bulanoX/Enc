﻿CREATE TABLE [ODS].[SectionRiskClass] (
    [FK_Section]                               BIGINT             NOT NULL,
    [FK_RiskClass]                             BIGINT             NOT NULL,
    [RiskPercentage]                           NUMERIC (19, 12)   NULL,
    [AuditModifyDateTime]                      DATETIME2 (7)      NULL,
    [AuditCreateDateTime]                      DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                       NVARCHAR (255)     NULL,
    CONSTRAINT [PK_SectionRiskClass] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_RiskClass] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionRiskClass_RiskClass] FOREIGN KEY ([FK_RiskClass]) REFERENCES [ODS].[RiskClass] ([PK_RiskClass]),
    CONSTRAINT [FK_SectionRiskClass_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

