﻿CREATE TABLE [ODS].[OriginalCurrency] (
    [PK_OriginalCurrency]  AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([CurrencyCode])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]      BIT           CONSTRAINT [DEF_OriginalCurrency_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [CurrencyCode]         VARCHAR (255) NOT NULL,
    [CurrencyName]         VARCHAR (255) NOT NULL,
    [CurrencyFormatString] AS            ([ODS].[udf_CurrencyFormatString]([CurrencyCode])),
    [AuditModifyDateTime]  DATETIME2 (7)  NULL,
    [AuditCreateDateTime]  DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]   NVARCHAR (512) NULL,
    CONSTRAINT [PK_OriginalCurrency] PRIMARY KEY CLUSTERED ([PK_OriginalCurrency] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_OriginalCurrency_LogicalKey] UNIQUE NONCLUSTERED ([CurrencyCode] ASC) WITH (FILLFACTOR = 90)
);


GO
CREATE NONCLUSTERED INDEX [IDX_OriginalCurrency_001]
    ON [ODS].[OriginalCurrency]([CurrencyCode] ASC) WITH (FILLFACTOR = 90);

