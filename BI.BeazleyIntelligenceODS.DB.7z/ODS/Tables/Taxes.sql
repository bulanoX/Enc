CREATE TABLE  [ODS].[Taxes] (
    [PK_Taxes]                                 AS                ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(((CONVERT([varchar](255),[FK_Section])+'|~|') +CONVERT([varchar](255),[TaxesID]))))),(0)) PERSISTED NOT NULL ,
    [FK_Section]                               BIGINT			  NOT NULL,
    [Fk_Policy]                                BIGINT			  NOT NULL,
    [TaxesId]                                  INT                NOT NULL,
	[TaxableAmount]                            NUMERIC (38, 12)    NULL,
    [TaxLocationOfRisk]                        NVARCHAR (255)    NULL,
    [Tax]                                      NUMERIC (19,4) NULL,
    [TaxRate]                                  NUMERIC (19,12) NULL,
    [VATNumber]                                NVARCHAR (255)    NULL,
    [OriginalCCYToSettlementCCYRate]           NUMERIC (38, 4) NULL,
    [OriginalCurrency]                         NVARCHAR (255)  NULL,
    [SettlementCurrency]                       NVARCHAR (255)  NULL,
    [AuditModifyDateTime]                      DATETIME2 (7)      NULL,
    [AuditCreateDateTime]                      DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                       NVARCHAR (255)     NULL,
    CONSTRAINT [PK_Taxes] PRIMARY KEY CLUSTERED ([PK_Taxes] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Taxes_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
    )