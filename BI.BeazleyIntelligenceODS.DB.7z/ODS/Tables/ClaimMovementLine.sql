﻿CREATE TABLE [ODS].[ClaimMovementLine] (
    [FK_ClaimMovement]  BIGINT           NOT NULL,
    [FK_Section]        BIGINT           NOT NULL,
    [FK_Syndicate]      BIGINT           NOT NULL,
    [FK_SlipLineNumber] BIGINT           NOT NULL,
    [LineMultiplier]    NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime] Datetime2 (7)      NULL,
	[AuditCreateDateTime] Datetime2 (7)      NULL,
	[AuditModifyDetails]  Nvarchar (255)     NULL
    CONSTRAINT [PK_ClaimMovementLine] PRIMARY KEY CLUSTERED ([FK_ClaimMovement] ASC, [FK_Section] ASC, [FK_Syndicate] ASC, [FK_SlipLineNumber] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimMovementLine_ClaimMovement] FOREIGN KEY ([FK_ClaimMovement]) REFERENCES [ODS].[ClaimMovement] ([PK_ClaimMovement]),
    CONSTRAINT [FK_ClaimMovementLine_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_ClaimMovementLine_SlipLineNumber] FOREIGN KEY ([FK_SlipLineNumber]) REFERENCES [ODS].[SlipLineNumber] ([PK_SlipLineNumber]),
    CONSTRAINT [FK_ClaimMovementLine_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate])
);













