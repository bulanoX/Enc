﻿CREATE TABLE [ODS].[DevelopmentPeriod] (
    [PK_DevelopmentPeriod]   AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([varchar](255),[DevelopmentMonth])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]        BIT           CONSTRAINT [DEF_DevelopmentPeriod_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [DevelopmentMonth]       INT           NOT NULL,
    [DevelopmentMonthName]   VARCHAR (255) NOT NULL,
    [DevelopmentQuarter]     INT           NOT NULL,
    [DevelopmentQuarterName] VARCHAR (255) NOT NULL,
    [DevelopmentYear]        INT           NOT NULL,
    [DevelopmentYearName]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_DevelopmentPeriod] PRIMARY KEY NONCLUSTERED ([PK_DevelopmentPeriod] ASC) WITH (FILLFACTOR = 90)
);

