﻿CREATE TABLE [ODS].[SectionLine] (
    [FK_Section]                       BIGINT           NOT NULL,
    [FK_Syndicate]                     BIGINT           NOT NULL,
    [WrittenLineMultiplier]            NUMERIC (19, 12) NOT NULL,
    [SignedLineMultiplier]             NUMERIC (19, 12) NULL,
    [WrittenIfNotSignedLineMultiplier] NUMERIC (19, 12) NOT NULL,
    [HashbytesId]                      BIGINT           NULL,
    [AuditModifyDateTime]              DATETIME2 (7)    NULL,
    [AuditCreateDateTime]              DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]               NVARCHAR (512)   NULL,
    CONSTRAINT [PK_SectionLine] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_Syndicate] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionLine_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_SectionLine_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate])
);



