﻿CREATE TABLE [ODS].[InternalWrittenBinderStatus] (
    [PK_InternalWrittenBinderStatus] BIGINT        NOT NULL,
    [InternalWrittenBinderStatus]    VARCHAR (255) NOT NULL,
    [InternalWrittenBinderFilter]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_InternalWrittenBinderStatus] PRIMARY KEY NONCLUSTERED ([PK_InternalWrittenBinderStatus] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_InternalWrittenBinderStatus_LogicalKey] UNIQUE NONCLUSTERED ([InternalWrittenBinderStatus] ASC) WITH (FILLFACTOR = 90)
);

