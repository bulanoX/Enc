﻿CREATE  TABLE [ODS].[AcquisitionCostType] (
   [PK_AcquisitionCostType]              AS           ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([AcquisitionCostTypeCode]+ '|~|' + UPPER([TaxDescription])))),(0))  PERSISTED NOT NULL,                                             
   [AcquisitionCostTypeCode]             VARCHAR (255) NOT NULL,
   [AcquisitionCostTypeDescription]      VARCHAR (255) NULL,
   [AcquisitionCostTypeInternalExternal] VARCHAR (255) NOT NULL,
   [TaxDescription]                      NVARCHAR (255)  NOT NULL,  
   [AuditModifyDateTime]				 DATETIME2 (7)  NULL,
   [AuditCreateDateTime]				 DATETIME2 (7)  DEFAULT (getdate()) NULL,
   [AuditModifyDetails]					 NVARCHAR (512) NULL,
   CONSTRAINT [PK_AcquisitionCostType] PRIMARY KEY NONCLUSTERED ([PK_AcquisitionCostType] ASC) WITH (FILLFACTOR = 90),
   CONSTRAINT [UQ_AcquisitionCostType_LogicalKey] UNIQUE NONCLUSTERED ([AcquisitionCostTypeCode] ASC, [TaxDescription] ASC) WITH (FILLFACTOR = 90)  
);