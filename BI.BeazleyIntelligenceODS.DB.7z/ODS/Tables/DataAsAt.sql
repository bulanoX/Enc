﻿CREATE TABLE [ODS].[DataAsAt] (
    [PK_DataAsAt]                 AS       ((1)) PERSISTED NOT NULL,
    [CoreSystemAsAtDate]          DATETIME NULL,
    [EurobaseAsAtDate]            DATETIME NULL,
    [BeazleyProAsAtDate]          DATETIME NULL,
    [ClaimCenterAsAtDate]         DATETIME NULL,
    --[KnowledgeCenterAsAtDate]     DATETIME NULL,
    [UnirisxAsAtDate]             DATETIME NULL,
    [CoreSystemAsAtDateName]      AS       ([ODS].[udf_FormatDateTimeWithTime]([CoreSystemAsAtDate])),
    [EurobaseAsAtDateName]        AS       ([ODS].[udf_FormatDateTimeWithTime]([EurobaseAsAtDate])),
    [BeazleyProAsAtDateName]      AS       ([ODS].[udf_FormatDateTimeWithTime]([BeazleyProAsAtDate])),
    [ClaimCenterAsAtDateName]     AS       ([ODS].[udf_FormatDateTimeWithTime]([ClaimCenterAsAtDate])),
    --[KnowledgeCenterAsAtDateName] AS       ([ODS].[udf_FormatDateTimeWithTime]([KnowledgeCenterAsAtDate])),
    [UnirisxAsAtDateName]         AS       ([ODS].[udf_FormatDateTimeWithTime]([UnirisxAsAtDate])),
    CONSTRAINT [PK_DataAsAt] PRIMARY KEY CLUSTERED ([PK_DataAsAt] ASC) WITH (FILLFACTOR = 90)
);

