﻿CREATE TABLE [ODS].[Sublimit] (
    [PK_Sublimit]           AS             IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([SublimitCode])))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]       BIT            CONSTRAINT [DEF_Sublimit_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SublimitCode]          VARCHAR (255)  NOT NULL,
    [SublimitName]          VARCHAR (255)  NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512) NULL,
    CONSTRAINT [PK_Sublimit] PRIMARY KEY NONCLUSTERED ([PK_Sublimit] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Sublimit_LogicalKey] UNIQUE NONCLUSTERED ([SublimitCode] ASC) WITH (FILLFACTOR = 90)
);

