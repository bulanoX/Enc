﻿CREATE TABLE [ODS].[PolicyHiddenStatusFilter] (
    [FK_Policy]             BIGINT NOT NULL,
    [FK_HiddenStatusFilter] BIGINT NOT NULL,
    [AuditModifyDateTime]   datetime2(7)  NULL,
	[AuditCreateDateTime]   datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]    nvarchar(255) NULL,
    CONSTRAINT [PK_PolicyHiddenStatusFilter] PRIMARY KEY NONCLUSTERED ([FK_Policy] ASC, [FK_HiddenStatusFilter] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_PolicyHiddenStatusFilter_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_PolicyHiddenStatusFilter_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy])
);











































