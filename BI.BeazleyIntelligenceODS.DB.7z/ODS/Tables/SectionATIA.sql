﻿CREATE TABLE [ODS].[SectionATIA] (
    [PK_SectionATIA]            AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((((((CONVERT([varchar](255),[FK_Section])+'|~|')+isnull([AustraliaState],''))+'|~|')+isnull([InsuranceType],''))+'|~|')+isnull([TierCode],'')))),(0)) PERSISTED NOT NULL,
    [FK_Section]                BIGINT          NOT NULL,
    [AustraliaState]            VARCHAR (255)   NULL,
    [InsuranceType]             VARCHAR (255)   NULL,
    [TierCode]                  VARCHAR (255)   NULL,
    [WrittenOrEstimatedPremium] NUMERIC (19, 4) NULL,
    [LimitAmount]               NUMERIC (19, 4) NULL,
    [FK_OriginalCurrency]       BIGINT          NOT NULL,
    [FK_LimitCurrency]          BIGINT          NOT NULL,
    [AuditModifyDateTime]       DATETIME2 (7)   NULL,
    [AuditCreateDateTime]       DATETIME2 (7)   DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]        NVARCHAR (255)  NULL,
    CONSTRAINT [PK_SectionATIA] PRIMARY KEY NONCLUSTERED ([PK_SectionATIA] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionATIA_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_SectionATIA_OriginalCurrency_LimitCurrency] FOREIGN KEY ([FK_LimitCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_SectionATIA_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [UQ_SectionATI_LogicalKey] UNIQUE NONCLUSTERED ([FK_Section] ASC, [AustraliaState] ASC, [InsuranceType] ASC, [TierCode] ASC) WITH (FILLFACTOR = 90)
);



