﻿ CREATE TABLE [ODS].[SectionLimit] (
     [FK_Section]            BIGINT          NOT NULL,
     [FK_Sublimit]           BIGINT          NOT NULL,
     [FK_LimitCurrency]      BIGINT          NOT NULL,
     [FK_SublimitType]       BIGINT          NOT NULL,
     [LimitAmountInLimitCCY] NUMERIC (19, 4) NULL,
     [AuditModifyDateTime]   DATETIME2 (7)  NULL,
     [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
     [AuditModifyDetails]    NVARCHAR (255) NULL,
     CONSTRAINT [PK_SectionLimit] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_Sublimit] ASC, [FK_LimitCurrency] ASC, [FK_SublimitType] ASC) WITH (FILLFACTOR = 90),
     CONSTRAINT [FK_SectionLimit_OriginalCurrency_LimitCurrency] FOREIGN KEY ([FK_LimitCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
     CONSTRAINT [FK_SectionLimit_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
     CONSTRAINT [FK_SectionLimit_Sublimit] FOREIGN KEY ([FK_Sublimit]) REFERENCES [ODS].[Sublimit] ([PK_Sublimit]),
     CONSTRAINT [FK_SectionLimit_SublimitType] FOREIGN KEY ([FK_SublimitType]) REFERENCES [ODS].[SublimitType] ([PK_SublimitType])
 );
 


