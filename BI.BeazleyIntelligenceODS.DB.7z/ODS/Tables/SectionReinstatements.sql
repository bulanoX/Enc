﻿CREATE TABLE [ODS].[SectionReinstatements] (
    [PK_SectionReinstatements]    BIGINT           NOT NULL,
    [FK_Section]                  BIGINT           NOT NULL,
    [ReinstatementNo]             INT              NOT NULL,
    [ReinstatementPercentage]     NUMERIC (19, 12) NULL,
    [ReinstatementPercentageName] VARCHAR (50)     NULL,
    [PolicySourceId]              VARCHAR (255)    NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (255) NULL,
    CONSTRAINT [PK_SectionReinstatements] PRIMARY KEY NONCLUSTERED ([PK_SectionReinstatements] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionReinstatements_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

