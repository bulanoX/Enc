﻿CREATE TABLE [ODS].[ExposureProfileBand] (
    [PK_ExposureProfileBand] AS            ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(((([BandType]+'|~|')+[Department])+'|~|')+CONVERT([varchar](50),[BandMin])))),(0)) PERSISTED NOT NULL,
    [BandType]               VARCHAR (255) NOT NULL,
    [Department]             VARCHAR (255) NOT NULL,
    [BandMin]                NUMERIC (38)  NOT NULL,
    [BandMax]                NUMERIC (38)  NOT NULL,
    [BandName]               VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]    DATETIME2 (7)     NULL,
    [AuditCreateDateTime]    DATETIME2 (7)     DEFAULT (getdate()) NULL,
    [AuditModifyDetails]     NVARCHAR (255)    NULL,
    CONSTRAINT [PK_ExposureProfileBand] PRIMARY KEY CLUSTERED ([PK_ExposureProfileBand] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ExposureProfileBand_LogicalKey] UNIQUE NONCLUSTERED ([BandType] ASC, [Department] ASC, [BandMin] ASC) WITH (FILLFACTOR = 90)
);

