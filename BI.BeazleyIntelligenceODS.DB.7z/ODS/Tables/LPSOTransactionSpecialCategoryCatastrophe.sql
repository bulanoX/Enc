﻿CREATE TABLE [ODS].[LPSOTransactionSpecialCategoryCatastrophe] (
    [FK_LPSOTransaction]            BIGINT         NOT NULL,
    [FK_SpecialCategoryCatastrophe] BIGINT         NOT NULL,
    [AuditModifyDateTime]           DATETIME2 (7)  NULL,
    [AuditCreateDateTime]           DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]            NVARCHAR (255) NULL,
    CONSTRAINT [PK_LPSOTransactionSpecialCategoryCatasrophe] PRIMARY KEY NONCLUSTERED ([FK_LPSOTransaction] ASC, [FK_SpecialCategoryCatastrophe] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_LPSOTransactionSpecialCategory_SpecialCategoryCatastrophe] FOREIGN KEY ([FK_SpecialCategoryCatastrophe]) REFERENCES [ODS].[SpecialCategoryCatastrophe] ([PK_SpecialCategoryCatastrophe]),
    CONSTRAINT [FK_LPSOTransactionSpecialCategoryCatastrophe_LPSOTransaction] FOREIGN KEY ([FK_LPSOTransaction]) REFERENCES [ODS].[LPSOTransaction] ([PK_LPSOTransaction])
);











