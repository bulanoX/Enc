﻿CREATE TABLE [ODS].[GQDTransactionType] (
    [PK_GQDTransactionType]      AS             IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([GQDTransactionTypeCode]))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]            BIT            CONSTRAINT [DEF_GQDTransactionType_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [GQDTransactionTypeCode]     VARCHAR (255)  NOT NULL,
    [GQDTransactionType]         VARCHAR (255)  NOT NULL,
    [GQDTransactionTypeFullName] AS             ((([GQDTransactionType]+' (')+[GQDTransactionTypeCode])+')'),
    [AuditModifyDateTime]        DATETIME2 (7)  NULL,
    [AuditCreateDateTime]        DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]         NVARCHAR (255) NULL,
    CONSTRAINT [PK_GQDTransactionType] PRIMARY KEY NONCLUSTERED ([PK_GQDTransactionType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_GQDTransactionType_LogicalKey] UNIQUE NONCLUSTERED ([GQDTransactionTypeCode] ASC) WITH (FILLFACTOR = 90)
);

