﻿CREATE TABLE [ODS].[EntityPerspective] (
    [PK_EntityPerspective] BIGINT        NOT NULL,
    [EntityPerspective]    VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_EntityPerspective] PRIMARY KEY CLUSTERED ([PK_EntityPerspective] ASC) WITH (FILLFACTOR = 90)
);

