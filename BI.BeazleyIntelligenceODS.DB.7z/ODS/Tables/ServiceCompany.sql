﻿CREATE TABLE [ODS].[ServiceCompany] (
    [PK_ServiceCompany]          AS             IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([ServiceCompanyCode])))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]            BIT           CONSTRAINT [DEF_ServiceCompany_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ServiceCompanyCode]         VARCHAR (255) NOT NULL,
    [ServiceCompanyName]         VARCHAR (255) NOT NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_ServiceCompany] PRIMARY KEY NONCLUSTERED ([PK_ServiceCompany] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ServiceCompany_LogicalKey] UNIQUE NONCLUSTERED ([ServiceCompanyCode] ASC) WITH (FILLFACTOR = 90)
);

