﻿CREATE TABLE [ODS].[RiskLocation] (
    [PK_RiskLocation]   AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(([RiskLocation]+'|~|')+[RiskLocationState]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]   BIT           CONSTRAINT [DEF_RiskLocation_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [RiskLocation]      VARCHAR (255) NOT NULL,
    [RiskLocationState] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_RiskLocation] PRIMARY KEY NONCLUSTERED ([PK_RiskLocation] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_RiskLocation_LogicalKey] UNIQUE NONCLUSTERED ([RiskLocation] ASC, [RiskLocationState] ASC) WITH (FILLFACTOR = 90)
);

