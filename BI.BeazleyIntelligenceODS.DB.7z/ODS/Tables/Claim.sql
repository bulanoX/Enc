﻿CREATE TABLE [ODS].[Claim] (
    [PK_Claim]                               AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(([ClaimReference]+'~')+[OriginatingBureau]))),(0)) PERSISTED NOT NULL,
    [ClaimReference]                         VARCHAR (255)   NOT NULL,
    [OriginatingBureau]                      VARCHAR (255)   NOT NULL,
    [AgreementPartyDetails]                  VARCHAR (255)   NULL,
    [AppianReference]                        VARCHAR (25)    NULL,
    [NotificationDate]                       DATETIME        NULL,
    [ClaimURL]                               VARCHAR (4000)  NULL,
    [ClaimOpenedDate]                        DATETIME        NULL,
    [ClaimClosedDate]                        DATETIME        NULL,
    [InHouseClaimIndicator]                  BIT             NOT NULL,
    [ClaimMadeFromDate]                      DATETIME        NULL,
    [AccidentYear]                           INT             NULL,
    [LossFromDate]                           DATETIME        NULL,
    [LossToDate]                             DATETIME        NULL,
    [ClaimDescription]                       VARCHAR (MAX)   NULL,
    [ClaimNarrative]                         VARCHAR (MAX)   NULL,
    [SlipPositionCode]                       VARCHAR (255)   NULL,
    [SlipPosition]                           VARCHAR (255)   NULL,
    [HasSCMData]                             BIT             NOT NULL,
    [HasDeductibleTrackingData]              BIT             CONSTRAINT [DEF_Claim_HasDeductibleTrackingData] DEFAULT ((0)) NOT NULL,
    [ClaimAssociationIndicator]              BIT             CONSTRAINT [DEF_ClaimExposure_ClaimAssociationIndicator] DEFAULT ((0)) NOT NULL,
    [LimitCCY]                               VARCHAR (255)   NULL,
    [LimitInLimitCCY]                        NUMERIC (19, 4) NULL,
    [EstimatedLossWithinTheRetentionCCY]     NVARCHAR (255)  NULL,
    [EstimatedLossWithinTheRetention]        NUMERIC (19, 4) NULL,
    [DeductibleCCY]                          VARCHAR (255)   NULL,
    [EachClaimDeductibleInDeductibleCCY]     NUMERIC (19, 4) NULL,
    [InsuranceFund]                          NVARCHAR (255)  NULL,
    [AggregateDeductibleInDeductibleCCY]     NUMERIC (19, 4) NULL,
    [HasRealExposures]                       BIT             NOT NULL,
    [SCMReadOnly]                            BIT             CONSTRAINT [DEF_Claim_SCMReadOnly] DEFAULT ((0)) NOT NULL,
    [ExternalClaimsService]                  VARCHAR (255)   NULL,
    [ClaimCreatedBy]                         VARCHAR (255)   NULL,
    [ClaimStatus]                            VARCHAR (255)   NULL,
    [ClaimStatusCode]                        VARCHAR (255)   NULL,
    [ClaimsUnderwritingPlatform]             NVARCHAR (255)  NULL,
    [InitiativeUS]                           VARCHAR (255)   NULL,
    [FK_PrimaryClaimAssociation]             BIGINT          NOT NULL,
    [FK_AccountingCalendar]                  BIGINT          NOT NULL,
    [FK_NotificationDate]                    AS              IIF(YEAR(NotificationDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, NotificationDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([NotificationDate])) PERSISTED,
    [FK_ClaimMadeFromDate]                   AS              IIF(YEAR(ClaimMadeFromDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ClaimMadeFromDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([ClaimMadeFromDate])) PERSISTED,
    [FK_LossFromDate]                        AS              IIF(YEAR(LossFromDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, LossFromDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([LossFromDate])) PERSISTED,
    [FK_LossToDate]                          AS              IIF(YEAR(LossToDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, LossToDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([LossToDate])) PERSISTED,
    [ClaimMadeFromDateName]                  AS              IIF(YEAR(ClaimMadeFromDate)< 1990 OR YEAR(ClaimMadeFromDate)>2050,NULL,FORMAT(ClaimMadeFromDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([ClaimMadeFromDate])),
    [LossFromDateName]                       AS              IIF(YEAR(LossFromDate)< 1990 OR YEAR(LossFromDate)>2050,NULL,FORMAT(LossFromDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([LossFromDate])),
    [LossToDateName]                         AS              IIF(YEAR(LossToDate)< 1990 OR YEAR(LossToDate)>2050,NULL,FORMAT(LossToDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([LossToDate])),
    [NotificationDateName]                   AS              IIF(YEAR(NotificationDate)< 1990 OR YEAR(NotificationDate)>2050,NULL,FORMAT(NotificationDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([NotificationDate])),
    [HasDeductibleTrackingDataName]          AS              (IIF(HasDeductibleTrackingData = 1, 'Deductible Tracked','Deductible Not Tracked')), --([ODS].[udf_FormatBit]([HasDeductibleTrackingData],'Deductible Tracked','Deductible Not Tracked','Deductible Not Tracked')),
    [InHouseClaimIndicatorName]              AS              (IIF([InHouseClaimIndicator] = 1 , 'Yes' , 'No')), --([ODS].[udf_FormatBitAsYesNo]([InHouseClaimIndicator])),
    [ClaimAssociationIndicatorName]          AS              (IIF(ClaimAssociationIndicator = 1 , 'Yes' , 'No')), --([ODS].[udf_FormatBitAsYesNo]([ClaimAssociationIndicator])),
    [LimitInLimitCCYName]                    AS              IIF(LimitInLimitCCY = 0,'0',(format(LimitInLimitCCY,'###,###,###,###'))),--([ODS].[udf_FormatNumeric]([LimitInLimitCCY],(0))),
    [EachClaimDeductibleInDeductibleCCYName] AS              IIF(EachClaimDeductibleInDeductibleCCY = 0,'0',(format(EachClaimDeductibleInDeductibleCCY,'###,###,###,###'))),--([ODS].[udf_FormatNumeric]([EachClaimDeductibleInDeductibleCCY],(0))),
    [AggregateDeductibleInDeductibleCCYName] AS              IIF(AggregateDeductibleInDeductibleCCY = 0,'0',(format(AggregateDeductibleInDeductibleCCY,'###,###,###,###'))),--([ODS].[udf_FormatNumeric]([AggregateDeductibleInDeductibleCCY],(0))),
    [ClaimSource]                            AS              (IIF(HasSCMData = 1, 'SCM','ClaimCenter')), --([ODS].[udf_FormatBit]([HasSCMData],'SCM','ClaimCenter','ClaimCenter')),
    [ClaimReopenedFlag]                      BIT             CONSTRAINT [DEF_Claim_ClaimReopenedFlag] DEFAULT ((0)) NOT NULL,
    [ClaimReopenedFlagName]                  AS              (IIF(ClaimReopenedFlag = 1 , 'Yes' , 'No')), -- ([ODS].[udf_FormatBitAsYesNo]([ClaimReopenedFlag])),
    [ClosedOutcome]                          NVARCHAR (255)  NULL,
    [BeazleyGroupPaper]                      NVARCHAR (255)  NULL,
    [ClaimType]                              NVARCHAR (255)  NULL,
    [LocationOfLossCountry]                  NVARCHAR (255)  NULL,
    [LocationOfLossState]                    NVARCHAR (255)  NULL,
    [UCR]                                    NVARCHAR (255)  NULL,
    [ConflictOfInterest]                     NVARCHAR (255)  CONSTRAINT [DEF_Claim_ConflictOfInterest] DEFAULT ('') NULL,
    [KeyColumn]                              NVARCHAR (255)  NULL,
    [ClaimGlobalProgrammeID]                 NVARCHAR (255)  NULL,
    [LineOfBusiness]                         NVARCHAR (255)  NULL,
    [LitigationHold]                         NVARCHAR (255)  NULL,
    [AnonymizationStatus]                    NVARCHAR (255)  NULL,
    [HashbytesId]                            BIGINT          NULL,
    [AuditModifyDateTime]                    DATETIME2 (7)   NULL,
    [AuditCreateDateTime]                    DATETIME2 (7)   CONSTRAINT [DF__Claim__AuditCrea__7032E4AD] DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                     NVARCHAR (255)  NULL,
    CONSTRAINT [PK_Claim] PRIMARY KEY CLUSTERED ([PK_Claim] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Claim_LogicalKey] UNIQUE NONCLUSTERED ([ClaimReference] ASC, [OriginatingBureau] ASC) WITH (FILLFACTOR = 90)
);



























































