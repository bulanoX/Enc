﻿CREATE TABLE [ODS].[PartyBroker] (
    [PK_PartyBroker]      AS             IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((isnull(CONVERT([varchar](255),ltrim(rtrim([BrokerNumber]))),'')+'|~|')+isnull(upper(ltrim(rtrim(upper([BrokerName])))),'')))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]     BIT            CONSTRAINT [DEF_PartyBroker_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [BrokerNumber]        INT            NULL,
    [OriginalBrokerNumber]  INT            NULL,
    [BrokerName]          VARCHAR (255)  NULL,
    [BrokerPseudonym]     VARCHAR (255)  NULL,
    [GroupNumber]         INT            NOT NULL,
    [GroupName]           VARCHAR (255)  NOT NULL,
    [BrokerCountry]        VARCHAR (255) NULL,
    [BrokerCity]           VARCHAR (255) NULL,
    [AuditModifyDateTime] DATETIME2 (7)  NULL,
    [AuditCreateDateTime] DATETIME2 (7)  NULL,
    [AuditModifyDetails]  NVARCHAR (255) NULL,
    CONSTRAINT [PK_PartyBroker] PRIMARY KEY CLUSTERED ([PK_PartyBroker] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [CHK_PartyBroker_HasNumberOrName] CHECK ([BrokerNumber] IS NOT NULL OR [BrokerName] IS NOT NULL),
    CONSTRAINT [UQ_PartyBroker_LogicalKey] UNIQUE NONCLUSTERED ([BrokerNumber] ASC, [BrokerName] ASC) WITH (FILLFACTOR = 90)
);



