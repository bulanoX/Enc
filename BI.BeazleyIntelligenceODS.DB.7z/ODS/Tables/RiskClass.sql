﻿CREATE TABLE [ODS].[RiskClass] (
    [PK_RiskClass]               AS            IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([RiskClassCode])))),(0)))PERSISTED NOT NULL,
    [IsUnknownMember]            BIT           CONSTRAINT [DEF_RiskClass_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [RiskClassCode]              VARCHAR (255) NOT NULL,
    [RiskClassName]              VARCHAR (255) NULL,
    [AuditModifyDateTime]        DATETIME2 (7)      NULL,
    [AuditCreateDateTime]        DATETIME2 (7)      DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]         NVARCHAR (255)     NULL,
    CONSTRAINT [PK_RiskClass] PRIMARY KEY NONCLUSTERED ([PK_RiskClass] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_RiskClass_LogicalKey] UNIQUE NONCLUSTERED ([RiskClassCode] ASC) WITH (FILLFACTOR = 90)
);

