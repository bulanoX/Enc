﻿CREATE TABLE [ODS].[SectionSpecialCategorySection] (
    [FK_Section]                BIGINT         NOT NULL,
    [FK_SpecialCategorySection] BIGINT         NOT NULL,
    [AuditModifyDateTime]       DATETIME2 (7)  NULL,
    [AuditCreateDateTime]       DATETIME2 (7)  DEFAULT (getdate()) NOT NULL,
    [AuditModifyDetails]        NVARCHAR (255) NULL,
    CONSTRAINT [PK_SectionSpecialCategorySection] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_SpecialCategorySection] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionSpecialCategorySection_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_SectionSpecialCategorySection_SpecialCategorySection] FOREIGN KEY ([FK_SpecialCategorySection]) REFERENCES [ODS].[SpecialCategorySection] ([PK_SpecialCategorySection])
);





