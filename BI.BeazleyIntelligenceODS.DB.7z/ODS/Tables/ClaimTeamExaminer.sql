﻿CREATE TABLE [ODS].[ClaimTeamExaminer] (
    [PK_ClaimTeamExaminer]       BIGINT        NOT NULL,
    [IsUnknownMember]            BIT           CONSTRAINT [DEF_ClaimTeamExaminer_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [TeamName]                   VARCHAR (255) NULL,
    [HierarchyLevel]             INT           NOT NULL,
    [FK_ClaimTeamExaminerParent] BIGINT        NULL,
    [ParentTeamName]             VARCHAR (255) NULL,
    [AuditModifyDateTime]                      DATETIME2 (7)      NULL,
    [AuditCreateDateTime]                      DATETIME2 (7)      DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                       NVARCHAR (255)     NULL,
    CONSTRAINT [PK_ClaimTeamExaminer] PRIMARY KEY CLUSTERED ([PK_ClaimTeamExaminer] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimTeamExaminer_ClaimTeamExaminerParent] FOREIGN KEY ([FK_ClaimTeamExaminerParent]) REFERENCES [ODS].[ClaimTeamExaminer] ([PK_ClaimTeamExaminer])
);

