﻿CREATE TABLE [ODS].[SpecialCategorySection] (
    [PK_SpecialCategorySection] AS              IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',([SpecialCategory]))),(0))) PERSISTED NOT NULL,
    [IsUnknownMember]           BIT             CONSTRAINT [DEF_SpecialCategorySection_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [SpecialCategory]           VARCHAR (255)   NOT NULL,
    [SpecialCategoryGroup]      VARCHAR (255)   NOT NULL,
    [AuditModifyDateTime]       DATETIME2 (7)   NULL,
    [AuditCreateDateTime]       DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]        NVARCHAR (512)  NULL,
    CONSTRAINT [PK_SpecialCategorySection] PRIMARY KEY NONCLUSTERED ([PK_SpecialCategorySection] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_SpecialCategorySection_LogicalKey] UNIQUE NONCLUSTERED ([SpecialCategory] ASC) WITH (FILLFACTOR = 90)
);

