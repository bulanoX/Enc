﻿CREATE TABLE [ODS].[AccountingCalendar] (
    [PK_AccountingCalendar]  AS             IIF([IsUnknownMember] = 1, 0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([AccountingCalendarName])))),0) ) PERSISTED NOT NULL,
    [IsUnknownMember]        BIT           CONSTRAINT [DEF_AccountingCalendar_IsUnknownMemer] DEFAULT ((0)) NOT NULL,
    [AccountingCalendarName] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_AccountingCalendar] PRIMARY KEY NONCLUSTERED ([PK_AccountingCalendar] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_AccountingCalendar_LogicalKey] UNIQUE NONCLUSTERED ([AccountingCalendarName] ASC) WITH (FILLFACTOR = 90)
);

