﻿CREATE TABLE [ODS].[SectionEntityPerspective] (
    [FK_Section]                        BIGINT           NOT NULL,
    [FK_EntityPerspective]              BIGINT           NOT NULL,
    [InternalAcquisitionCostMultiplier] NUMERIC (19, 12) CONSTRAINT [DEF_SectionEntityPerspective_InternalAcquisitionCostMultiplier] DEFAULT ((0)) NOT NULL,
    [PerspectiveMultiplier]             NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]               datetime2(7)  NULL,
	[AuditCreateDateTime]               datetime2(7)  DEFAULT (GETDATE()) NOT NULL,
	[AuditModifyDetails]                nvarchar(255) NULL,
    CONSTRAINT [PK_SectionEntityPerspective] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_EntityPerspective] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionEntityPerspective_EntityPerspective] FOREIGN KEY ([FK_EntityPerspective]) REFERENCES [ODS].[EntityPerspective] ([PK_EntityPerspective]),
    CONSTRAINT [FK_SectionEntityPerspective_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

