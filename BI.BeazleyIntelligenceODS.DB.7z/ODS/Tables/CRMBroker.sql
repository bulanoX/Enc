﻿CREATE TABLE [ODS].[CRMBroker] (
    [PK_CRMBroker]       BIGINT           NOT NULL,
    [IsUnknownMember]    BIT              CONSTRAINT [DEF_CRMBroker_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [CRMBrokerId]        UNIQUEIDENTIFIER NOT NULL,
    [AccountNumber]      VARCHAR (255)    NULL,
    [BrokerName]         VARCHAR (255)    NULL,
    [BrokerCountry]      VARCHAR (255)    NULL,
    [BrokerCity]         VARCHAR (255)    NULL,
    [StateOrProvince]    VARCHAR (255)    NULL,
    [CRMBrokerLinkId]    VARCHAR (255)    NULL,
    [HierarchyLevel]     INT              NOT NULL,
    [FK_CRMBrokerParent] BIGINT           NULL,
    [FirstCharacter]     AS               (left([BrokerName],(1))),
    [AuditModifyDateTime] DATETIME2 (7)    NULL,
    [AuditCreateDateTime] DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]  NVARCHAR (255)   NULL,
    CONSTRAINT [PK_CRMBroker] PRIMARY KEY CLUSTERED ([PK_CRMBroker] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_CRMBroker_CRMBrokerParent] FOREIGN KEY ([FK_CRMBrokerParent]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [UQ_CRMBroker_LogicalKey] UNIQUE NONCLUSTERED ([CRMBrokerId] ASC) WITH (FILLFACTOR = 90)
);

