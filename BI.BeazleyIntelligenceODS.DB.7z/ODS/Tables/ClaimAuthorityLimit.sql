﻿CREATE TABLE [ODS].[ClaimAuthorityLimit] (
    [PK_ClaimAuthorityLimit]        AS               IIF([IsUnknownMember] = 1, 0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((((CONVERT([varchar](255),[ClaimCenterUserId])+'|~|')+[AuthorityType])+'|~|')+[CoverageType]))),(0)))  PERSISTED NOT NULL,
    [IsUnknownMember]               BIT             CONSTRAINT [DEF_ClaimAuthorityLimit_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ClaimCenterUserId]             INT             NOT NULL,
    [ClaimCenterUser]               VARCHAR (255)   NOT NULL,
    [AuthorityType]                 NVARCHAR (255)  NOT NULL,
    [CoverageType]                  VARCHAR (255)   NOT NULL,
    [AuthorityLimitUSD]             NUMERIC (19, 4) CONSTRAINT [DEF_ClaimAuthorityLimit_AuthorityLimitUSD] DEFAULT ((0)) NOT NULL,
    [AuthorityLimitForApprovalsUSD] NUMERIC (19, 4) CONSTRAINT [DEF_ClaimAuthorityLimit_AuthorityLimitForApprovalsUSD] DEFAULT ((0)) NOT NULL,
    [AuditModifyDateTime]				 DATETIME2 (7)  NULL,
    [AuditCreateDateTime]				 DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]					 NVARCHAR (512) NULL,
    CONSTRAINT [PK_ClaimAuthorityLimit] PRIMARY KEY NONCLUSTERED ([PK_ClaimAuthorityLimit] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ClaimAuthorityLimit_LogicalKey] UNIQUE NONCLUSTERED ([ClaimCenterUserId] ASC, [AuthorityType] ASC, [CoverageType] ASC) WITH (FILLFACTOR = 90)
);

