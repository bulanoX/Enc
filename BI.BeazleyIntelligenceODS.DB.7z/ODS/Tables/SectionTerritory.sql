﻿CREATE TABLE [ODS].[SectionTerritory] (
    [FK_Section]                            BIGINT           NOT NULL,
    [FK_Area]                               BIGINT           NOT NULL,
    [AreaMultiplier]                        NUMERIC (19, 12) NULL,
    [AuditModifyDateTime]                   DATETIME2 (7)   NULL,
    [AuditCreateDateTime]                   DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                    NVARCHAR (255)  NULL,
    CONSTRAINT [UQ_SectionTerritory_LogicalKey] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_Area] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionTerritory_Area] FOREIGN KEY ([FK_Area]) REFERENCES [ODS].[Area] ([PK_Area]),
    CONSTRAINT [FK_SectionTerritory_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

