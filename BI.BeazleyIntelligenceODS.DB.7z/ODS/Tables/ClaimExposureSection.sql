﻿CREATE TABLE [ODS].[ClaimExposureSection] (
    [FK_ClaimExposure]               BIGINT         NOT NULL,
    [FK_Section]                     BIGINT         NOT NULL,
    [FK_TriFocus]                    BIGINT         NOT NULL,
    [FK_QuoteFilter]                 BIGINT         NOT NULL,
    [FK_HiddenStatusFilter]          BIGINT         NOT NULL,
    [FK_Policy]                      BIGINT         NOT NULL,
    [FK_CRMBroker]                   BIGINT         NOT NULL,
    [FK_UnderwritingPlatform]        BIGINT         NOT NULL,
    [FK_InternalWrittenBinderStatus] BIGINT         NOT NULL,
    [SpecialPurposeSyndicateApplies] BIGINT         NOT NULL,
    [FK_ServiceCompany]              BIGINT         NOT NULL,
    [SectionSequenceId]              INT            NULL,
    [AuditModifyDateTime]            DATETIME2 (7)  NULL,
    [AuditCreateDateTime]            DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]             NVARCHAR (255) NULL,
    CONSTRAINT [PK_ClaimExposureSection] PRIMARY KEY NONCLUSTERED ([FK_ClaimExposure] ASC, [FK_Section] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimEposureSection_ClaimExposure] FOREIGN KEY ([FK_ClaimExposure]) REFERENCES [ODS].[ClaimExposure] ([PK_ClaimExposure]),
    CONSTRAINT [FK_ClaimExposureSection_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_ClaimExposureSection_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_ClaimExposureSection_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_ClaimExposureSection_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_ClaimExposureSection_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_ClaimExposureSection_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_ClaimExposureSection_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_ClaimExposureSection_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_ClaimExposureSection_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform])
);

















