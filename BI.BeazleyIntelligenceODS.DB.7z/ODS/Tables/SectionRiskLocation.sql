﻿CREATE TABLE [ODS].[SectionRiskLocation] (
    [FK_Section]             BIGINT           NOT NULL,
    [FK_RiskLocation]        BIGINT           NOT NULL,
    [RiskLocationMultiplier] NUMERIC (19, 12) NULL,
    CONSTRAINT [PK_SectionRiskLocation] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_RiskLocation] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionRiskLocation_RiskLocation] FOREIGN KEY ([FK_RiskLocation]) REFERENCES [ODS].[RiskLocation] ([PK_RiskLocation]),
    CONSTRAINT [FK_SectionRiskLocation_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

