﻿CREATE TABLE [ODS].[Policy] (
    [PK_Policy]                              AS              IIF(IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([PolicyReference])))),(0))) PERSISTED NOT NULL,
    [SourceSystem]                           VARCHAR (255)   NOT NULL,
    [SourceSystemKey]                        VARCHAR (255)   NULL,
    [PolicyReference]                        VARCHAR (255)   NOT NULL,
    [IsUnknownMember]                        BIT             CONSTRAINT [DEF_Policy_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [ExpiringPolicy]                         VARCHAR (255)   NULL,
    [EndorsementNumber]                      VARCHAR (255)   NULL, 
    [IsQuote]                                BIT             CONSTRAINT [DEF_Policy_IsQuote] DEFAULT ((0)) NOT NULL,
    [IsBoundQuote]                           BIT             CONSTRAINT [DEF_Policy_IsBoundQuote] DEFAULT ((0)) NOT NULL,
    [IsRenewal]                              BIT             CONSTRAINT [DEF_Policy_IsRewnewal] DEFAULT ((0)) NOT NULL,
    [RenewingPolicy]                         VARCHAR (255)   NULL,
    [AdmittedNonAdmitted]                    VARCHAR (255)   NOT NULL,
    [PlacingBrokerContact]                   VARCHAR (255)   NULL,
    [ProducingBrokerContact]                 VARCHAR (255)   NULL,
    [BrokerNetworkName]                      VARCHAR (255)   NULL,
    [SourceSystemInsuredId]                  INT             NULL,
    [InsuredParty]                           VARCHAR (255)   NULL,
     [InsuredLegalTradingName]                VARCHAR (255)   NULL, 
    [AdditionalInsuredParty]                 VARCHAR (255)   NULL,
    [ReinsuredParty]                         VARCHAR (255)   NULL,
    [MarketSegmentCode]                      VARCHAR (255)   NULL,
    [MarketSegment]                          VARCHAR (255)   NULL,
    [MethodOfPlacementCode]                  VARCHAR (255)   NULL,
    [MethodOfPlacement]                      VARCHAR (255)   NULL,
    [IsBrokerAccessReferral]                 BIT             CONSTRAINT [DEF_Policy_IsBrokerAccessReferral] DEFAULT ((0)) NOT NULL,
    [BrokerAccessPolicyNumber]               VARCHAR (255)   NULL,
    [CoverholderName]                        VARCHAR (255)   NULL,
    [Address1]                               VARCHAR (255)   NULL,
    [Address2]                               VARCHAR (255)   NULL,
    [Address3]                               VARCHAR (255)   NULL,
    [Address4]                               VARCHAR (255)   NULL,
    [PolicyType]                             NVARCHAR (255) NULL,
    [PolicyURL]                              VARCHAR (4000)  NULL,
    [PolicyURLLabel]                         VARCHAR (255)   NULL,
    [PolicyReferenceMOPCode]                 VARCHAR (255)   NULL,
    [PolicyReferenceMOPCodeRiskNumber]       VARCHAR (255)   NULL,
    [PolicyReferenceRiskNumber]              VARCHAR (255)   NULL,
    [PolicyReferenceYOA]                     VARCHAR (255)   NULL,
    [FACEvidenced]                           BIT             CONSTRAINT [DEF_Policy_FACEvidenced] DEFAULT ((0)) NOT NULL,
    [EarliestFirstLiveDate]                  DATETIME        NULL,
    [LatestFirstLiveDate]                    DATETIME        NULL,
    [EarliestRationaleDocumentDate]          DATETIME        NULL,
    [EarliestRationaleQuestionnaireDate]     DATETIME        NULL,
    [EarliestRationaleDate]                  DATETIME        NULL,
    [EarliestExceptionDocumentDate]          DATETIME        NULL,
    [RationaleCompletionMethod]              VARCHAR (255)   NULL,
    [PrimarySectionBinderType]               VARCHAR (255)   NULL,
    [AnySectionIsBreachResponseDummy]        BIT             CONSTRAINT [DEF_Policy_AnySectionIsBreachResponseDummy] DEFAULT ((0)) NOT NULL,
    [AnySectionHasExceptionDocument]         BIT             CONSTRAINT [DEF_Policy_AnySectionHasExceptionDocument] DEFAULT ((0)) NOT NULL,
    [AnySectionIsSynergy]                    BIT             CONSTRAINT [DEF_Policy_AnySectionIsSynergy] DEFAULT ((0)) NOT NULL,
    [NetworkStartDate]                       DATETIME        NULL,
    [NetworkEndDate]                         DATETIME        NULL,
    [IsRunOff]                               BIT             NULL,
    [RiskType]                               NVARCHAR (255)  NULL,
    [RunOffDate]                             DATETIME        NULL,
    [ServiceCompanyLocation]                 NVARCHAR (255) NULL,
    [AgressoBrokerID]                        VARCHAR (255)   NULL,
    [CapitaBrokerID]                         VARCHAR (255)   NULL,
    [AttachmentPoint]                        NUMERIC (19, 4) NULL,
    [Cedant]                                 VARCHAR (255)   NULL,
    [ContractBasis]                          VARCHAR (255)   NULL,
    [DomicileCountry]                        VARCHAR (255)   NULL,
    [FundType]                               VARCHAR (255)   NULL,
    [InsuranceType]                          VARCHAR (255)   NULL,
    [IsNewYorkFreeTradeZone]                 BIT             CONSTRAINT [DEF_Policy_NewYorkFreeTradeZone] DEFAULT ((0)) NOT NULL,
    [UniqueMarketReference]                  VARCHAR (255)   NULL,
    [UPIFlag]                                BIT             CONSTRAINT [DEF_Policy_UPIFlag] DEFAULT ((0)) NOT NULL,
    [FK_AccountingCalendar]                  BIGINT          NOT NULL,
    [FK_CRMBroker]                           BIGINT          NOT NULL,
    [FK_CRMProducingBroker]                  BIGINT          NOT NULL,
    [FK_ExpiringPolicy]                      BIGINT          NULL,
    [FK_PartyBrokerPlacing]                  BIGINT          NOT NULL,
    [FK_PartyBrokerProducing]                BIGINT          NOT NULL,
    [FK_PartyBrokerServiceOfSuit]            BIGINT          NOT NULL,
    [FK_PartyBrokerNoticeOfClaim]            BIGINT          NOT NULL,
    [FK_PartyInsured]                        BIGINT          NOT NULL,
    [FK_QuoteFilter]                         BIGINT          NOT NULL,
    [FK_RenewingPolicy]                      BIGINT          NULL,
    [FK_Submission]                          BIGINT          NOT NULL,
    [FK_UnderwritingPlatform]                BIGINT          NOT NULL,
    [FK_YOA]                                 BIGINT          NOT NULL,
    [FK_EarliestExceptionDocumentDate]       AS              IIF(YEAR(EarliestExceptionDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EarliestExceptionDocumentDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EarliestExceptionDocumentDate])) PERSISTED,
    [FK_EarliestFirstLiveDate]               AS              IIF(YEAR(EarliestFirstLiveDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EarliestFirstLiveDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EarliestFirstLiveDate])) PERSISTED,
    [FK_EarliestRationaleDate]               AS              IIF(YEAR(EarliestRationaleDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EarliestRationaleDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EarliestRationaleDate])) PERSISTED,
    [FK_EarliestRationaleDocumentDate]       AS              IIF(YEAR(EarliestRationaleDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EarliestRationaleDocumentDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EarliestRationaleDocumentDate])) PERSISTED,
    [FK_EarliestRationaleQuestionnaireDate]  AS              IIF(YEAR(EarliestRationaleQuestionnaireDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, EarliestRationaleQuestionnaireDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([EarliestRationaleQuestionnaireDate])) PERSISTED,
    [FK_LatestFirstLiveDate]                 AS              IIF(YEAR(LatestFirstLiveDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, LatestFirstLiveDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([LatestFirstLiveDate])) PERSISTED,
    [FK_NetworkEndDate]                      AS              IIF(YEAR(NetworkEndDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, NetworkEndDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([NetworkEndDate])) PERSISTED,
    [FK_NetworkStartDate]                    AS              IIF(YEAR(NetworkStartDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, NetworkStartDate),DATEADD(DAY, -53690, 0)) PERSISTED,--([Utility].[udf_GenerateDateKey]([NetworkStartDate])) PERSISTED,
    [Address0]                               VARCHAR (255)   NULL,
    [AffinityIdentifier]                     VARCHAR (255)   NULL,
    [AnnualRevenues]                         NUMERIC (19, 4) NULL,
    [AnnualRevenuesName]                     AS              IIF(AnnualRevenues = 0,'0',(format(AnnualRevenues,'###,###,###,###'))),--([ODS].[udf_FormatNumeric]([AnnualRevenues],(0))),
    [Coinsurance]                            VARCHAR (255)   NULL,
    [ErpExpirationDate]                      DATETIME        NULL,
    [McareAssessment]                        VARCHAR (255)   NULL,
    [InitiativeUS]                           VARCHAR (255)   NULL,
    [IsBID]                                  BIT             NOT NULL,
    [NotifiedIndividualsMaximum]             INT             NULL,
    [PatientCompensationFund]                VARCHAR (255)   NULL,
    [PolicyLastModifiedDate]                 DATETIME        NULL,
    [TaxPercentage]                          NUMERIC (19, 4) NULL,
    [TriaPercentage]                         NUMERIC (19, 4) NULL,
    [AnySectionHasExceptionDocumentName]     AS              (IIF(AnySectionHasExceptionDocument = 1 , 'Yes' , 'No')), --(([ODS].[udf_FormatBitAsYesNo]([AnySectionHasExceptionDocument])),
    [AnySectionIsBreachResponseDummyName]    AS              (IIF(AnySectionIsBreachResponseDummy = 1 , 'Yes' , 'No')), --(([ODS].[udf_FormatBitAsYesNo]([AnySectionIsBreachResponseDummy])),
    [AnySectionIsSynergyName]                AS              (IIF(AnySectionIsSynergy = 1 , 'Yes' , 'No')), --(([ODS].[udf_FormatBitAsYesNo]([AnySectionIsSynergy])),
    [EarliestExceptionDocumentDateName]      AS              IIF(YEAR(EarliestExceptionDocumentDate)< 1990 OR YEAR(EarliestExceptionDocumentDate)>2050,NULL,FORMAT(EarliestExceptionDocumentDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EarliestExceptionDocumentDate])),
    [EarliestFirstLiveDateName]              AS              IIF(YEAR(EarliestFirstLiveDate)< 1990 OR YEAR(EarliestFirstLiveDate)>2050,NULL,FORMAT(EarliestFirstLiveDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EarliestFirstLiveDate])),
    [EarliestRationaleDateName]              AS              IIF(YEAR(EarliestRationaleDate)< 1990 OR YEAR(EarliestRationaleDate)>2050,NULL,FORMAT(EarliestRationaleDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EarliestRationaleDate])),
    [EarliestRationaleDocumentDateName]      AS              IIF(YEAR(EarliestRationaleDocumentDate)< 1990 OR YEAR(EarliestRationaleDocumentDate)>2050,NULL,FORMAT(EarliestRationaleDocumentDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EarliestRationaleDocumentDate])),
    [EarliestRationaleQuestionnaireDateName] AS              IIF(YEAR(EarliestRationaleQuestionnaireDate)< 1990 OR YEAR(EarliestRationaleQuestionnaireDate)>2050,NULL,FORMAT(EarliestRationaleQuestionnaireDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([EarliestRationaleQuestionnaireDate])),
    [FACEvidencedName]                       AS              (IIF(FACEvidenced = 1, 'FAC Evidenced','FAC Not Evidenced')), --([ODS].[udf_FormatBit]([FACEvidenced],'FAC Evidenced','FAC Not Evidenced','FAC Not Evidenced')),
    [InsuredPartyFirstCharacter]             AS              (left([InsuredParty],(1))),
    [InsuredPartyFirst3Characters]           AS              (left([InsuredParty],(3))),
    [IsBrokerAccessReferralName]             AS              (IIF(IsBrokerAccessReferral = 1 , 'Yes' , 'No')), --([ODS].[udf_FormatBitAsYesNo]([IsBrokerAccessReferral])),
    [IsNewYorkFreeTradeZoneName]             AS              (IIF(IsNewYorkFreeTradeZone = 1 , 'Yes' , 'No')), --([ODS].[udf_FormatBitAsYesNo]([IsNewYorkFreeTradeZone])),
    [IsRenewalName]                          AS              (IIF(IsRenewal = 1, 'Renewal','New')), --([ODS].[udf_FormatBit]([IsRenewal],'Renewal','New','New')),
    [LatestFirstLiveDateName]                AS              IIF(YEAR(LatestFirstLiveDate)< 1990 OR YEAR(LatestFirstLiveDate)>2050,NULL,FORMAT(LatestFirstLiveDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([LatestFirstLiveDate])),
    [NetworkEndDateName]                     AS              IIF(YEAR(NetworkEndDate)< 1990 OR YEAR(NetworkEndDate)>2050,NULL,FORMAT(NetworkEndDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([NetworkEndDate])),
    [NetworkStartDateName]                   AS              IIF(YEAR(NetworkStartDate)< 1990 OR YEAR(NetworkStartDate)>2050,NULL,FORMAT(NetworkStartDate, 'dd-MMM-yyyy')),--([ODS].[udf_FormatDateTime]([NetworkStartDate])),
    [NumberOfBoundQuotes]                    AS              (case when [IsUnknownMember]=(1) OR [IsBoundQuote]=(0) then NULL else (1) end),
    [NumberOfNew]                            AS              (case when [IsUnknownMember]=(1) then (0) else CONVERT([int],~[IsRenewal]) end),
    [NumberOfPolicies]                       AS              (case when [IsUnknownMember]=(1) OR [IsQuote]=(1) then NULL else (1) end),
    [NumberOfQuotes]                         AS              (case when [IsUnknownMember]=(1) OR [IsQuote]=(0) then NULL else (1) end),
    [NumberOfRenewals]                       AS              (case when [IsUnknownMember]=(1) then (0) else CONVERT([int],[IsRenewal]) end),
    [ConsecutiveNumberOfPolicyRenewals]      INT             CONSTRAINT [DEF_Policy_ConsecutiveNumberOfPolicyRenewals] DEFAULT ((0)) NOT NULL,
    [UPIFlagName]                            AS              (IIF(UPIFlag = 1 , 'Yes' , 'No')), --([ODS].[udf_FormatBitAsYesNo]([UPIFlag])),
    [BrokerContactName]                      NVARCHAR (255)  NULL,
    [SubmittingBrokerContactName]            NVARCHAR (255)  NULL,
    [USMiscMedLifeSciencesPolicyCOBCode]     NVARCHAR (255)  NULL,
    [USMiscMedLifeSciencesPolicyCOB]         NVARCHAR (255)  NULL,
    [FK_ServiceCompany]                      BIGINT          NOT NULL,
    [LargeRiskExemption]                     NVARCHAR (255)  NULL,
    [LeadFeesPercentage]                     NUMERIC (20, 4) NULL,
    [HashbytesId]                            BIGINT          NULL,
    [AuditModifyDateTime]                    DATETIME2 (7)   NULL,
	[AuditCreateDateTime]                    DATETIME2 (7)   DEFAULT (getdate()) NULL,
    [AuditModifyDetails]                     NVARCHAR (512)  NULL,
    CONSTRAINT [PK_Policy] PRIMARY KEY CLUSTERED ([PK_Policy] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_Policy_LogicalKey] UNIQUE NONCLUSTERED ([PolicyReference] ASC) WITH (FILLFACTOR = 90)
);














































GO
CREATE NONCLUSTERED INDEX [IDX_003]
    ON [ODS].[Policy]([SourceSystem] ASC, [IsQuote] ASC)
    INCLUDE([PK_Policy]) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_Policy_002]
    ON [ODS].[Policy]([PK_Policy] ASC, [SourceSystem] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_Policy_001]
    ON [ODS].[Policy]([FK_YOA] ASC, [SourceSystem] ASC) WITH (FILLFACTOR = 90);

GO

CREATE NONCLUSTERED INDEX [Policy_BrokerAccessPolicyNumber] ON [ODS].[Policy]
(
	[BrokerAccessPolicyNumber] ASC
)
INCLUDE([PolicyReference]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY];

GO

CREATE NONCLUSTERED INDEX [Policy_IsQuote]
    ON [ODS].[Policy] ([IsQuote])
    INCLUDE ([PK_Policy],[PolicyReference],[ExpiringPolicy])


