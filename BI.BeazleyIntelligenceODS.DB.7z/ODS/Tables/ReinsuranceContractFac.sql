﻿CREATE TABLE [ODS].[ReinsuranceContractFac] (
    [PK_ReinsuranceContract] AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([varchar](255),[ContractReference])))),(0)) PERSISTED NOT NULL,
    [ContractReference]      VARCHAR (255)   NOT NULL,
    [ContractShortName]      VARCHAR (255)   NOT NULL,
    [ContractDescription]    VARCHAR (255)   NOT NULL,
    [ContractType]           VARCHAR (255)   NOT NULL,
    [ContractPolicyType]     VARCHAR (255)   NOT NULL,
    [PeriodFromDate]         DATETIME        NOT NULL,
    [PeriodToDate]           DATETIME        NOT NULL,
    [SignedOrderMultiplier]  NUMERIC (19, 2) NULL,
    [OverriderCommission]    NUMERIC (19, 2) NULL,
    [AuditModifyDateTime]    DATETIME2 (7)    NULL,
    [AuditCreateDateTime]    DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]     NVARCHAR (255)   NULL,
    CONSTRAINT [PK_ReinsuranceContractFac] PRIMARY KEY NONCLUSTERED ([PK_ReinsuranceContract] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [UQ_ReinsuranceContractFac_LogicalKey] UNIQUE NONCLUSTERED ([ContractReference] ASC) WITH (FILLFACTOR = 90)
);

