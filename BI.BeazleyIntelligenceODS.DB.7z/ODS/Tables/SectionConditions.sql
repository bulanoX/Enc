﻿CREATE TABLE [ODS].[SectionConditions] (
    [FK_Section]       BIGINT NOT NULL,
    [FK_ConditionType] BIGINT NOT NULL,
    CONSTRAINT [PK_SectionConditions] PRIMARY KEY NONCLUSTERED ([FK_Section] ASC, [FK_ConditionType] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SectionConditions_ConditionType] FOREIGN KEY ([FK_ConditionType]) REFERENCES [ODS].[ConditionType] ([PK_ConditionType]),
    CONSTRAINT [FK_SectionConditions_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section])
);

