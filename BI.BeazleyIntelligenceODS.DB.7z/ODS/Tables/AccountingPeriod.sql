﻿CREATE TABLE [ODS].[AccountingPeriod] (
    [FK_AccountingCalendar] BIGINT         NOT NULL,
    [AccountingPeriodName]  VARCHAR (255)  NOT NULL,
    [PeriodStart]           DATETIME       NOT NULL,
    [PeriodEnd]             DATETIME       NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)  NULL,
    [AuditCreateDateTime]   DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512) NULL,
    CONSTRAINT [PK_AccountingPeriod] PRIMARY KEY NONCLUSTERED ([FK_AccountingCalendar] ASC, [AccountingPeriodName] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_AccountingPeriod_AccountingCalendar] FOREIGN KEY ([FK_AccountingCalendar]) REFERENCES [ODS].[AccountingCalendar] ([PK_AccountingCalendar])
);

