﻿CREATE TABLE [ODS].[UltimateLossRatio] (
    [PK_UltimateLossRatio]          AS              		 ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((((((((((((((CONVERT([varchar](255),[FK_YOA])+'|~|')+CONVERT([varchar](255),[FK_YOA]))+'|~|')+CONVERT([varchar](255),[FK_Syndicate]))+'|~|')+CONVERT([varchar](255),[FK_TriFocus]))+'|~|')+CONVERT([varchar](255),[FK_DevelopmentPeriod]))+'|~|')+CONVERT([varchar](255),[FK_SettlementCurrency]))+'|~|')+CONVERT([varchar](255),[FK_SpecialCategoryCatastrophe]))+'|~|')+CONVERT([varchar](255),[FK_SpecialCategorySection])))),(0)) PERSISTED NOT NULL,
    [GroupId]                       BIGINT          NOT NULL,
    [FK_YOA]                        BIGINT          NOT NULL,
    [FK_Syndicate]                  BIGINT          NOT NULL,
    [FK_TriFocus]                   BIGINT          NOT NULL,
    [FK_DevelopmentPeriod]          BIGINT          NOT NULL,
    [FK_SettlementCurrency]         BIGINT          NOT NULL,
    [FK_SpecialCategoryCatastrophe] BIGINT          NOT NULL,
    [FK_SpecialCategorySection]     BIGINT          NOT NULL,
    [GrossUltimatePremiumPosition]  NUMERIC (19, 4) NOT NULL,
    [GrossUltimateIncurredPosition] NUMERIC (19, 4) NOT NULL,
    [AuditCreateDateTime]           DATETIME2 (7)  DEFAULT (GETDATE()) NOT NULL,
    [AuditModifyDateTime]           DATETIME2 (7)  NULL,
    [AuditModifyDetails]            NVARCHAR (255) NULL,
    CONSTRAINT [PK_UltimateLossRatio] PRIMARY KEY NONCLUSTERED ([PK_UltimateLossRatio] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_UltimateLossRatio_DevelopmentPeriod] FOREIGN KEY ([FK_DevelopmentPeriod]) REFERENCES [ODS].[DevelopmentPeriod] ([PK_DevelopmentPeriod]),
    CONSTRAINT [FK_UltimateLossRatio_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_UltimateLossRatio_SpecialCategoryCatastrophe] FOREIGN KEY ([FK_SpecialCategoryCatastrophe]) REFERENCES [ODS].[SpecialCategoryCatastrophe] ([PK_SpecialCategoryCatastrophe]),
    CONSTRAINT [FK_UltimateLossRatio_SpecialCategorySection] FOREIGN KEY ([FK_SpecialCategorySection]) REFERENCES [ODS].[SpecialCategorySection] ([PK_SpecialCategorySection]),
    CONSTRAINT [FK_UltimateLossRatio_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate]),
    CONSTRAINT [FK_UltimateLossRatio_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_UltimateLossRatio_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_UltimateLossRatio_LogicalKey] UNIQUE NONCLUSTERED ([FK_YOA] ASC, [FK_Syndicate] ASC, [FK_TriFocus] ASC, [FK_DevelopmentPeriod] ASC, [FK_SettlementCurrency] ASC, [FK_SpecialCategoryCatastrophe] ASC, [FK_SpecialCategorySection] ASC) WITH (FILLFACTOR = 90)
);



