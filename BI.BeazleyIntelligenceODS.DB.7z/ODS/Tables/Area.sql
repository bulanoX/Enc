﻿CREATE TABLE [ODS].[Area] (
    [PK_Area]               AS                  IIF([IsUnknownMember] = 1, 0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper([AreaCode])))),0) ) PERSISTED NOT NULL,
    [IsUnknownMember]       BIT                 CONSTRAINT [DEF_Area_IsUnknownMember] DEFAULT ((0)) NOT NULL,
    [AreaCode]              VARCHAR (255)       NOT NULL,
    [Area]                  VARCHAR (255)       NULL,
    [ContinentCode]         VARCHAR (255)       NULL,
    [Continent]             VARCHAR (255)       NULL,
    [AreaCountryCode]       VARCHAR (255)       NULL,
    [ESICategory]           VARCHAR (255)       NULL,
    [FK_ParentArea]         BIGINT              NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)       NULL,
    [AuditCreateDateTime]   DATETIME2 (7)       DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (512)      NULL,
    CONSTRAINT [PK_Area] PRIMARY KEY CLUSTERED ([PK_Area] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_Area_ParentArea] FOREIGN KEY ([FK_ParentArea]) REFERENCES [ODS].[Area] ([PK_Area]),
    CONSTRAINT [UQ_Area_LogicalKey] UNIQUE NONCLUSTERED ([AreaCode] ASC) WITH (FILLFACTOR = 90)
);

