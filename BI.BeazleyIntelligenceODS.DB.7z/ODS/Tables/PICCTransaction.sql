﻿CREATE TABLE [ODS].[PICCTransaction] (
    [PK_PICCTransaction]             AS              ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((CONVERT([varchar](255),[PICCPeriodId])+'|~|')+CONVERT([varchar](255),[FK_Section])))),(0)) PERSISTED NOT NULL,
    [PICCPeriodId]                   INT             NOT NULL,
    [PICCPeriod]                     VARCHAR (255)   NOT NULL,
    [PICCAmountInOriginalCCY]        NUMERIC (19, 4) NOT NULL,
    [SortOrder]                      INT             CONSTRAINT [DEF_PICCTransaction_SortOrder] DEFAULT ((0)) NOT NULL,
    [FK_Section]                     BIGINT          NOT NULL,
    [FK_Date]                        DATETIME        NOT NULL,
    [FK_YOA]                         BIGINT          NOT NULL,
    [FK_SettlementCurrency]          BIGINT          NOT NULL,
    [FK_OriginalCurrency]            BIGINT          NOT NULL,
    [FK_LocalCurrency]               BIGINT          NOT NULL,
    [FK_TriFocus]                    BIGINT          NOT NULL,
    [FK_Policy]                      BIGINT          NOT NULL,
    [FK_HiddenStatusFilter]          BIGINT          NOT NULL,
    [FK_QuoteFilter]                 BIGINT          NOT NULL,
    [FK_CRMBroker]                   BIGINT          NOT NULL,
    [SpecialPurposeSyndicateApplies] BIT             NOT NULL,
    [FK_UnderwritingPlatform]        BIGINT          NOT NULL,
    [FK_InternalWrittenBinderStatus] BIGINT          NOT NULL,
    [FK_ServiceCompany]              BIGINT          NOT NULL,
    [AuditModifyDateTime]            DATETIME2(7)    NULL,
	[AuditCreateDateTime]            DATETIME2 (7)    DEFAULT (getdate()) NULL,
	[AuditModifyDetails]             NVARCHAR (255)  NULL,
    CONSTRAINT [PK_PICCTransaction] PRIMARY KEY NONCLUSTERED ([PK_PICCTransaction] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_PICCTransaction_CRMBroker] FOREIGN KEY ([FK_CRMBroker]) REFERENCES [ODS].[CRMBroker] ([PK_CRMBroker]),
    CONSTRAINT [FK_PICCTransaction_HiddenStatusFilter] FOREIGN KEY ([FK_HiddenStatusFilter]) REFERENCES [ODS].[HiddenStatusFilter] ([PK_HiddenStatusFilter]),
    CONSTRAINT [FK_PICCTransaction_InternalWrittenBinderStatus] FOREIGN KEY ([FK_InternalWrittenBinderStatus]) REFERENCES [ODS].[InternalWrittenBinderStatus] ([PK_InternalWrittenBinderStatus]),
    CONSTRAINT [FK_PICCTransaction_LocalCurrency] FOREIGN KEY ([FK_LocalCurrency]) REFERENCES [ODS].[LocalCurrency] ([PK_LocalCurrency]),
    CONSTRAINT [FK_PICCTransaction_OriginalCurrency] FOREIGN KEY ([FK_OriginalCurrency]) REFERENCES [ODS].[OriginalCurrency] ([PK_OriginalCurrency]),
    CONSTRAINT [FK_PICCTransaction_Policy] FOREIGN KEY ([FK_Policy]) REFERENCES [ODS].[Policy] ([PK_Policy]),
    CONSTRAINT [FK_PICCTransaction_QuoteFilter] FOREIGN KEY ([FK_QuoteFilter]) REFERENCES [ODS].[QuoteFilter] ([PK_QuoteFilter]),
    CONSTRAINT [FK_PICCTransaction_Section] FOREIGN KEY ([FK_Section]) REFERENCES [ODS].[Section] ([PK_Section]),
    CONSTRAINT [FK_PICCTransaction_ServiceCompany] FOREIGN KEY ([FK_ServiceCompany]) REFERENCES [ODS].[ServiceCompany] ([PK_ServiceCompany]),
    CONSTRAINT [FK_PICCTransaction_SettlementCurrency] FOREIGN KEY ([FK_SettlementCurrency]) REFERENCES [ODS].[SettlementCurrency] ([PK_SettlementCurrency]),
    CONSTRAINT [FK_PICCTransaction_TriFocus] FOREIGN KEY ([FK_TriFocus]) REFERENCES [ODS].[TriFocus] ([PK_TriFocus]),
    CONSTRAINT [FK_PICCTransaction_UnderwritingPlatform] FOREIGN KEY ([FK_UnderwritingPlatform]) REFERENCES [ODS].[UnderwritingPlatform] ([PK_UnderwritingPlatform]),
    CONSTRAINT [FK_PICCTransaction_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_PICCTransaction_LogicalKey] UNIQUE NONCLUSTERED ([FK_Section] ASC, [PICCPeriodId] ASC) WITH (FILLFACTOR = 90)
);











