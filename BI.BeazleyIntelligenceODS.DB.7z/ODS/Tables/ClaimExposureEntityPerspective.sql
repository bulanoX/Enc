﻿CREATE TABLE [ODS].[ClaimExposureEntityPerspective] (
    [FK_ClaimExposure]      BIGINT           NOT NULL,
    [FK_EntityPerspective]  BIGINT           NOT NULL,
    [PerspectiveMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]   DATETIME2 (7)    NULL,
    [AuditCreateDateTime]   DATETIME2 (7)    DEFAULT (getdate()) NULL,
    [AuditModifyDetails]    NVARCHAR (255)   NULL,
    CONSTRAINT [PK_ClaimExposureEntityPerspective] PRIMARY KEY CLUSTERED ([FK_ClaimExposure] ASC, [FK_EntityPerspective] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_ClaimExposureEntityPerspective_ClaimExposure] FOREIGN KEY ([FK_ClaimExposure]) REFERENCES [ODS].[ClaimExposure] ([PK_ClaimExposure]),
    CONSTRAINT [FK_ClaimExposureEntityPerspective_EntityPerspective] FOREIGN KEY ([FK_EntityPerspective]) REFERENCES [ODS].[EntityPerspective] ([PK_EntityPerspective])
);





