﻿CREATE TABLE [ODS].[SyndicateSplit] (
    [PK_SyndicateSplit]   AS               ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',((CONVERT([varchar](255),[FK_Syndicate])+'|~|')+CONVERT([varchar](255),[FK_YOA])))),(0)) PERSISTED NOT NULL,
    [FK_Syndicate]        BIGINT           NOT NULL,
    [FK_YOA]              BIGINT           NOT NULL,
    [SyndicateMultiplier] NUMERIC (19, 12) NOT NULL,
    [AuditModifyDateTime]           DATETIME2 (7)  NULL,
    [AuditCreateDateTime]           DATETIME2 (7)  DEFAULT (getdate()) NULL,
    [AuditModifyDetails]            NVARCHAR (255) NULL,
    CONSTRAINT [PK_SyndicateSplit] PRIMARY KEY CLUSTERED ([PK_SyndicateSplit] ASC) WITH (FILLFACTOR = 90),
    CONSTRAINT [FK_SyndicateSplit_Syndicate] FOREIGN KEY ([FK_Syndicate]) REFERENCES [ODS].[Syndicate] ([PK_Syndicate]),
    CONSTRAINT [FK_SyndicateSplit_YOA] FOREIGN KEY ([FK_YOA]) REFERENCES [ODS].[YOA] ([PK_YOA]),
    CONSTRAINT [UQ_SyndicateSplit_LogicalKey] UNIQUE NONCLUSTERED ([FK_Syndicate] ASC, [FK_YOA] ASC) WITH (FILLFACTOR = 90)
);



