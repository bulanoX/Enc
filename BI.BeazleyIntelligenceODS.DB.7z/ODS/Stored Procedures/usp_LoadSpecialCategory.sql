﻿

CREATE PROCEDURE [ODS].[usp_LoadSpecialCategory]
AS

SET NOCOUNT ON


	;MERGE	ODS.SpecialCategoryCatastrophe	AS TARGET
			USING		
				(
				SELECT 
						IsUnknownMember				= 0
						,SpecialCategory            = sc.[Special Category]
						,SpecialCategoryGroup       = sc.[Special Category Group]
				FROM	Staging_MDS.MDS_Staging.SpecialCategory sc
				WHERE	sc.[Is Catastrophe Special] = 'True'

				UNION

				SELECT
						IsUnkownMember              = 1
						,SpecialCategory            = 'N/A'
						,SpecialCategoryGroup       = 'N/A'
				)
			AS SOURCE

			ON	SOURCE.SpecialCategory = TARGET.SpecialCategory

	WHEN	MATCHED THEN
			UPDATE	
			SET	TARGET.SpecialCategoryGroup			= SOURCE.SpecialCategoryGroup
				,TARGET.AuditModifyDateTime	        = GETDATE()						
				,TARGET.AuditModifyDetails	        = 'Merge in ODS.usp_LoadSpecialCategory' 

	WHEN	NOT MATCHED BY TARGET THEN
			INSERT
			(
				IsUnknownMember
				,SpecialCategory
				,SpecialCategoryGroup
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				SOURCE.IsUnknownMember
				,SOURCE.SpecialCategory
				,SOURCE.SpecialCategoryGroup
				,GETDATE()
				,'New add in ODS.usp_LoadSpecialCategory'	
			)

	WHEN	NOT MATCHED BY SOURCE THEN 
			DELETE
	;


	IF OBJECT_ID('tempdb..#SpecialCategorySection') IS NOT NULL
	DROP TABLE #SpecialCategorySection

	CREATE TABLE #SpecialCategorySection
				(
					[IsUnknownMember]		    BIT NOT NULL,
					[SpecialCategory]		    VARCHAR(255) NOT NULL,
					[SpecialCategoryGroup]	    VARCHAR(255) NOT NULL
				)

			
	/*Unknown member SpecialCategorySection*/
	INSERT INTO #SpecialCategorySection
				(
					IsUnknownMember
					,SpecialCategory
					,SpecialCategoryGroup
				)
	SELECT
					IsUnkownMember              = 1
					,SpecialCategory            = 'N/A'
					,SpecialCategoryGroup       = 'N/A'


	INSERT INTO #SpecialCategorySection
				(
					IsUnknownMember
					,SpecialCategory
					,SpecialCategoryGroup
				)
	SELECT DISTINCT
					IsUnknownMember				= 0 
					,SpecialCategory            = Utility.udf_ProcessString(sp.[Description], 1)
					,SpecialCategoryGroup       = sc.[Special Category Group]
	FROM			Staging_MDS.dbo.vw_special_policy sp

	INNER JOIN		Staging_MDS.MDS_Staging.SpecialCategory sc 
				ON	Utility.udf_ProcessString(sp.[Description], 1) = Utility.udf_ProcessString(sc.[Special Category], 1)

	WHERE			sp.[Include]  = 'Y'
				AND	sc.[Is Catastrophe Special] = 'False'

	/*Load policy specials from ULR which don't exist in EB*/
	INSERT INTO #SpecialCategorySection
				(	
					IsUnknownMember
					,SpecialCategory
					,SpecialCategoryGroup
				)
	SELECT DISTINCT
					IsUnknownMember				= 0
					,SpecialCategory            = ulr.Special
					,SpecialCategoryGroup       = 'Other'
	FROM			Staging_ULR.ULR_Staging.vwUwerEst ulr

	LEFT OUTER JOIN	ODS.SpecialCategoryCatastrophe spec_cat 
				ON	ulr.Special COLLATE Latin1_General_CI_AS = spec_cat.SpecialCategory

	LEFT OUTER JOIN	#SpecialCategorySection spec_sec 
				ON	ulr.Special COLLATE Latin1_General_CI_AS = spec_sec.SpecialCategory

	WHERE			spec_cat.PK_SpecialCategoryCatastrophe IS NULL
				AND	spec_sec.SpecialCategory IS NULL
				AND	ISNULL(ulr.Special, '') <> ''
				AND	(ulr.Gross_Prem <> 0 OR ulr.Gross_ULI <> 0)



	MERGE	ODS.SpecialCategorySection		AS TARGET
			USING	#SpecialCategorySection	AS SOURCE
			ON		SOURCE.SpecialCategory = TARGET.SpecialCategory

	WHEN	MATCHED THEN
			UPDATE	
			SET	TARGET.SpecialCategoryGroup			= SOURCE.SpecialCategoryGroup
				,TARGET.AuditModifyDateTime	        = GETDATE()						
				,TARGET.AuditModifyDetails	        = 'Merge in ODS.usp_LoadSpecialCategory' 

	WHEN	NOT MATCHED BY TARGET THEN
			INSERT
			(
				IsUnknownMember
				,SpecialCategory
				,SpecialCategoryGroup
				,AuditCreateDateTime
				,AuditModifyDetails
			)
				VALUES
			(
				SOURCE.IsUnknownMember
				,SOURCE.SpecialCategory
				,SOURCE.SpecialCategoryGroup
				,GETDATE()
				,'New add in ODS.usp_LoadSpecialCategory'	
			)

	WHEN	NOT MATCHED BY SOURCE THEN 
			DELETE
	;