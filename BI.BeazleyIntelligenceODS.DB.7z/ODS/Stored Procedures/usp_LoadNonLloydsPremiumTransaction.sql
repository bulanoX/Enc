﻿CREATE PROCEDURE [ODS].[usp_LoadNonLloydsPremiumTransaction]
AS BEGIN
	SET NOCOUNT ON;

	DECLARE			@LastAuditDate DATETIME2(7)

	SELECT			@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM			ODS.NonLloydsPremiumTransaction

	SET				@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

	DECLARE			@currentdate AS   DATETIME2 (7) 
	SET				@currentdate =  GETDATE() 

	DROP TABLE IF EXISTS #NonLloydsPremiumTransaction

	CREATE TABLE #NonLloydsPremiumTransaction(
					 PK_Transaction										  BIGINT              NOT NULL
					,SourceSystem										  VARCHAR(255)        NULL
					,DateCreated                                          DATETIME            NULL
					,EffectiveFromDate                                    DATETIME            NULL
					,EffectiveToDate                                      DATETIME            NULL
					,AccountingPeriod                                     DATETIME            NOT NULL
					,SettlementDate								          DATETIME		      NULL
					,TransactionTypeCode                                  VARCHAR(255)        NULL
					,TransactionType                                      VARCHAR(255)        NULL
					,GrossPremiumInOriginalCCY                            NUMERIC(19,4)       NOT NULL
					,ExternalAcquisitionCostInOriginalCCY                 NUMERIC(19,4)       NOT NULL
					,OriginalCCYToSettlementCCYRate                       NUMERIC(19,12)      NOT NULL
					,FK_Section                                           BIGINT              NOT NULL
					,FK_SettlementCurrency                                BIGINT              NOT NULL 
					,FK_OriginalCurrency                                  BIGINT              NOT NULL
					,FK_DevelopmentPeriod                                 BIGINT              NOT NULL
					,OriginalCCYToLocalCCYRate							  NUMERIC(19,12)      NULL
					,FK_LocalCurrency								      BIGINT              NULL
					,RiskLocation										  VARCHAR(255)        NULL
					,InvoiceReference                                     VARCHAR(255)        NULL  	  
					,NumberOfInstalments				   				  INT				  NULL
					,PaymentFrequency					   				  VARCHAR(255)		  NULL
					,PaymentMethod						   				  VARCHAR(255)		  NULL
					,PaymentReference					   				  VARCHAR(255)		  NULL
					,Notes												  NVARCHAR(1000) NULL
					,PolicyOrEndorsementReference						  NVARCHAR(255)  NULL

	)

	INSERT INTO #NonLloydsPremiumTransaction(
					 PK_Transaction
					 ,SourceSystem	
					,DateCreated
					,EffectiveFromDate                                 
					,EffectiveToDate                                 
					,AccountingPeriod
					,TransactionTypeCode
					,TransactionType
					,SettlementDate
					,OriginalCCYToSettlementCCYRate
					,GrossPremiumInOriginalCCY
					,ExternalAcquisitionCostInOriginalCCY
					,FK_Section
					,FK_SettlementCurrency
					,FK_OriginalCurrency
					,FK_DevelopmentPeriod
					,OriginalCCYToLocalCCYRate	
					,FK_LocalCurrency	
					,NumberOfInstalments
					,PaymentFrequency		
					,PaymentMethod			
					,PaymentReference	
					,Notes						
					,PolicyOrEndorsementReference
	)
	SELECT			PK_Transaction										= CASE 
																				WHEN t.SourceSystem = 'Unirisx' THEN t.TransactionSourceId 
																				--WHEN t.SourceSystem IN ('BeazleyPro','StagingDataContract')
																				--THEN (isnull([Utility].[udf_ComputeIdentity](CONVERT([VARCHAR](255),t.TransactionSourceId) + '|~|' + CONVERT([VARCHAR](255),t.SectionSourceId), 0),(0)))
																				ELSE  ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([VARCHAR](255),t.TransactionSourceId)))),(0))
																			END
					,SourceSystem										 = ods_p.SourceSystem
					,DateCreated                                         = t.TransactionCreatedDate
					,EffectiveFromDate                                   = t.TransactionEffectiveFromDate
					,EffectiveToDate                                     = t.TransactionEffectiveToDate
					,AccountingPeriod                                    = t.AccountingPeriod
					,TransactionTypeCode                                 = t.TransactionClass
					,TransactionType                                     = CASE
																				WHEN t.SourceSystem = 'StagingDataContract' THEN NULL -- Todo: Map through MDS
																				ELSE t.TransactionClassDescription --Todo: Map through MDS
																			END
					,SettlementDate										 = CASE
																				WHEN t.SourceSystem IN ('StagingDataContract') THEN NULL
																				ELSE t.SettlementDate
																			END 
					,OriginalCCYToSettlementCCYRate                      = CASE
																				WHEN t.SourceSystem = 'StagingDataContract' THEN TRY_CAST(t.OriginalCCYToSettlementCCYRate AS NUMERIC(19,12))
																				WHEN t.SourceSystem = 'BeazleyPro' THEN t.OriginalCCYToSettlementCCYRate
																				ELSE ISNULL(t.OriginalCCYToSettlementCCYRate,0)
																			END
					,GrossPremiumInOriginalCCY                           = CASE 
																				WHEN t.SourceSystem = 'Unirisx'  THEN ISNULL(te.GrossPremiumAmountInOriginalCCY,0) 
																				WHEN t.SourceSystem = 'BeazleyPro' THEN t.TransactionPremiumAmountInOriginalCCY
																				WHEN t.SourceSystem = 'StagingDataContract' THEN ISNULL(t.TransactionPremiumAmountInOriginalCCY, 0)
																				ELSE ISNULL(t.TransactionPremiumAmountInOriginalCCY,0) 
																			END	
					,ExternalAcquisitionCostInOriginalCCY                = CASE 
																				WHEN t.SourceSystem = 'BeazleyPro' THEN t.ExternalAcquisitionCostAmountInOriginalCCY

																				WHEN t.SourceSystem = 'CIPS' AND ods_s.InceptionDate <= CONVERT(DATETIME, '05/02/2022',105) THEN ISNULL(t.ExternalAcquisitionCostAmountInOriginalCCY,0) + 0.05 * ISNULL(t.TransactionPremiumAmountInOriginalCCY,0) 

																				ELSE ISNULL(t.ExternalAcquisitionCostAmountInOriginalCCY,0)
																			END	
					,FK_Section                                          = ods_s.PK_Section                         
					,FK_SettlementCurrency                               = sc.PK_SettlementCurrency
					,FK_OriginalCurrency                                 = oc.PK_OriginalCurrency
					,FK_DevelopmentPeriod                                = ISNULL(ods_dp.PK_DevelopmentPeriod, 0)
					,OriginalCCYToLocalCCYRate							 = CASE WHEN t.SourceSystem = 'Unirisx' AND uap.PolicyReference IS NOT NULL THEN 1 ELSE ods_s.OriginalCCYToLocalCCYRate END
					,FK_LocalCurrency									 = CASE WHEN t.SourceSystem = 'Unirisx' AND uap.PolicyReference IS NOT NULL THEN 0 ELSE ods_s.FK_LocalCurrency END
					,NumberOfInstalments								 = te.NumberOfInstalments
					,PaymentFrequency									 = te.PaymentFrequency
					,PaymentMethod										 = te.PaymentMethod
					,PaymentReference									 = te.PaymentReference
					,Notes												 = te.Notes
					,PolicyOrEndorsementReference						 = te.PolicyOrEndorsementReference
	FROM		BeazleyIntelligenceDataContract.Outbound.vw_FinancialTransaction t			  
	INNER JOIN	ODS.Section ods_s 
			ON	t.SectionReference = ods_s.SectionReference
	INNER JOIN	ODS.OriginalCurrency oc 
			ON	t.OriginalCurrency = oc.CurrencyCode
	INNER JOIN	ODS.SettlementCurrency sc 
			ON	t.SettlementCurrency = sc.CurrencyCode
	INNER JOIN	ODS.Policy ods_p 
			ON	ods_s.FK_Policy = ods_p.PK_Policy AND ods_p.SourceSystem = ods_p.SourceSystem
	INNER JOIN	ODS.YOA yoa 
			ON	ods_p.FK_YOA = yoa.PK_YOA
	LEFT JOIN	BeazleyIntelligenceDataContract.Outbound.vw_FinancialTransactionExtension te
			ON	te.SourceSystem = t.SourceSystem AND te.TransactionSourceId = t.TransactionSourceId
	LEFT JOIN	(
					SELECT DISTINCT PolicyReference 
					FROM	Staging_MDS.MDS_Staging.UnirisxAccountedPremium
	) uap	ON	ods_p.PolicyReference = uap.PolicyReference
	LEFT JOIN	ODS.DevelopmentPeriod ods_dp 
			ON	ods_dp.DevelopmentMonth = DATEDIFF(MONTH, yoa.FirstDate, t.AccountingPeriod) + 1
	WHERE		t.SourceSystem IN ('Unirisx', 'Gamechanger', 'FDR', 'CIPS' ,'myBeazley', 'USHVH', 'US High Value Homeowners', 'BeazleyPro','RulebookUS','Acturis')
			--AND t.IsActive = 1
			AND CASE WHEN t.SourceSystem = 'myBeazley' THEN t.SettlementDate  ELSE @currentdate END <= @currentdate
			OR	t.SourceSystem = 'StagingDataContract'
			AND ods_p.SourceSystem NOT IN ('BeazleyPro', 'Eurobase','Unirisx', 'Gamechanger' , 'FDR', 'CIPS', 'USHVH', 'US High Value Homeowners','RulebookUS','Acturis')

	/*BeazleyCentralStageIn*/
	INSERT INTO #NonLloydsPremiumTransaction(
				 PK_Transaction
				 ,SourceSystem	
				,DateCreated
				,EffectiveFromDate
				,EffectiveToDate
				,AccountingPeriod
				,TransactionType
				,TransactionTypeCode
				,SettlementDate
				,OriginalCCYToSettlementCCYRate
				,GrossPremiumInOriginalCCY
				,ExternalAcquisitionCostInOriginalCCY
				,FK_Section
				,FK_SettlementCurrency
				,FK_OriginalCurrency
				,FK_DevelopmentPeriod
				,OriginalCCYToLocalCCYRate
				,FK_LocalCurrency
				,RiskLocation
				,InvoiceReference
	)
	SELECT		PK_Transaction										 = ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([VARCHAR](255),tp.Extract_UniqueKey) + '|~|' + tp.PolicyReference))),(0))
				,SourceSystem										 = ods_p.SourceSystem
				,DateCreated                                         = tp.DateCreated
				,EffectiveFromDate									 = tp.TransactionEffectiveFromDate
				,EffectiveToDate									 = tp.TransactionEffectiveToDate	
				,AccountingPeriod                                    = tp.DateCreated
				,TransactionType                                     = tp.TransactionDescription
				,TransactionTypeCode								 = CASE 
																		   WHEN tp.TransactionDescription LIKE 'Additional premium'    THEN 'AP'
																		   WHEN tp.TransactionDescription LIKE 'ER Error correction'   THEN 'ER'
																		   WHEN tp.TransactionDescription LIKE 'New business'          THEN 'NB'
																		   WHEN tp.TransactionDescription LIKE 'Return premium'        THEN 'RP'
																		   ELSE	tp.PremiumType  
																	   END
				,SettlementDate										 = tp.SettlementDate
				,OriginalCCYToSettlementCCYRate                      = tp.OriginalCCYToSettlementCCYRate
				,GrossPremiumInOriginalCCY                           = ISNULL(tp.GrossPremiumInOriginalCCY,0)              
				,ExternalAcquisitionCostInOriginalCCY                = ISNULL(tp.ExternalAcquisitionCostInOriginalCCY,0)  
				,FK_Section                                          = s.PK_Section                         
				,FK_SettlementCurrency                               = sc.PK_SettlementCurrency
				,FK_OriginalCurrency                                 = oc.PK_OriginalCurrency
				,FK_DevelopmentPeriod                                = ISNULL(ods_dp.PK_DevelopmentPeriod, 0)
				,OriginalCCYToLocalCCYRate							 = s.OriginalCCYToLocalCCYRate
				,FK_LocalCurrency									 = s.FK_LocalCurrency
				,RiskLocation										 = tp.RiskLocation
				,InvoiceReference								     = tp.InvoiceReference
	FROM		[Staging_BeazleyCentralStageIn].[Eurobase_Staging].[vw_transactions_premium] tp
	INNER JOIN  ODS.Section s
			ON	tp.PolicyReference=s.sectionreference
	INNER JOIN	ODS.SettlementCurrency sc 
			ON	tp.SettlementCurrency = sc.CurrencyCode
	INNER JOIN	ODS.OriginalCurrency oc 
			ON	tp.OriginalCurrency = oc.CurrencyCode
	INNER JOIN	ODS.Policy ods_p 
			ON	s.FK_Policy = ods_p.PK_Policy
	INNER JOIN	ODS.YOA yoa 
			ON	ods_p.FK_YOA = yoa.PK_YOA
	LEFT JOIN	ODS.DevelopmentPeriod ods_dp 
			ON	ods_dp.DevelopmentMonth = DATEDIFF(MONTH, yoa.FirstDate, tp.DateCreated) + 1
	WHERE		tp.SettlementDate <= @currentdate 

	/*Dummy BBR sections*/
 
	INSERT INTO #NonLloydsPremiumTransaction(    
				PK_Transaction	
				,SourceSystem									
				,DateCreated
				,EffectiveFromDate
				,EffectiveToDate
				,AccountingPeriod
				,SettlementDate
				,TransactionTypeCode
				,TransactionType
				,GrossPremiumInOriginalCCY
				,ExternalAcquisitionCostInOriginalCCY
				,OriginalCCYToSettlementCCYRate
				,FK_Section
				,FK_SettlementCurrency
				,FK_OriginalCurrency
				,FK_DevelopmentPeriod
				,OriginalCCYToLocalCCYRate
				,FK_LocalCurrency
				,RiskLocation
				,InvoiceReference
	)
	SELECT		PK_Transaction							= ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([VARCHAR](255),nlpt.PK_Transaction) + '|~|' + CONVERT([VARCHAR](255),s_bbr.pK_Section)))),(0))
				,SourceSystem                           = nlpt.SourceSystem
				,DateCreated                            = nlpt.DateCreated
				,EffectiveFromDate                      = nlpt.EffectiveFromDate
				,EffectiveToDate                        = nlpt.EffectiveToDate
				,AccountingPeriod                       = nlpt.AccountingPeriod
				,SettlementDate					        = nlpt.SettlementDate
				,TransactionTypeCode                    = nlpt.TransactionTypeCode
				,TransactionType                        = nlpt.TransactionType
				,GrossPremiumInOriginalCCY              = nlpt.GrossPremiumInOriginalCCY
				,ExternalAcquisitionCostInOriginalCCY   = nlpt.ExternalAcquisitionCostInOriginalCCY
				,OriginalCCYToSettlementCCYRate         = nlpt.OriginalCCYToSettlementCCYRate
				,FK_Section                             = s_bbr.PK_Section
				,FK_SettlementCurrency                  = nlpt.FK_SettlementCurrency
				,FK_OriginalCurrency                    = nlpt.FK_OriginalCurrency
				,FK_DevelopmentPeriod                   = ISNULL(nlpt.FK_DevelopmentPeriod, 0)
				,OriginalCCYToLocalCCYRate				= nlpt.OriginalCCYToLocalCCYRate
				,FK_LocalCurrency						= nlpt.FK_LocalCurrency
				,RiskLocation							= nlpt.RiskLocation
				,InvoiceReference						= nlpt.InvoiceReference
	FROM		#NonLloydsPremiumTransaction nlpt
	INNER JOIN	ODS.Section s 
			ON	nlpt.FK_Section = s.PK_Section
	INNER JOIN	ODS.Section s_bbr 
			ON	s_bbr.FK_BreachResponseParentSection = s.PK_Section

	/*Apply the BBR multipliers*/
	UPDATE		nlpt 
			SET	GrossPremiumInOriginalCCY				= nlpt.GrossPremiumInOriginalCCY * s.BreachResponseMultiplier
				,ExternalAcquisitionCostInOriginalCCY   = nlpt.ExternalAcquisitionCostInOriginalCCY * s.BreachResponseMultiplier
	FROM		#NonLloydsPremiumTransaction nlpt
	INNER JOIN	ODS.Section s 
			ON	nlpt.FK_Section = s.PK_Section
	WHERE		s.BreachResponseMultiplier IS NOT NULL;

	DELETE FROM #NonLloydsPremiumTransaction
	WHERE PK_Transaction IN (   SELECT PK_Transaction
								FROM #NonLloydsPremiumTransaction
								GROUP BY PK_Transaction
								HAVING COUNT(*) > 1 );


	
INSERT INTO ODS.NonLloydsPremiumTransaction
(
     PK_NonLloydsPremiumTransaction			
	,DateCreated                            
	,EffectiveFromDate                      
	,EffectiveToDate                        
	,AccountingPeriod                       
	,SettlementDate							
	,TransactionTypeCode                    
	,TransactionType                        
	,OriginalCCYToSettlementCCYRate         
	,GrossPremiumInOriginalCCY              
	,ExternalAcquisitionCostInOriginalCCY   
	,FK_Section                             
	,FK_SettlementCurrency                  
	,FK_OriginalCurrency                    
	,FK_DevelopmentPeriod                   
	,OriginalCCYToLocalCCYRate				
	,FK_LocalCurrency						
	,RiskLocation							
	,InvoiceReference                       
	,NumberOfInstalments					
	,PaymentFrequency						
	,PaymentMethod							
	,PaymentReference		
	,Notes							
	,PolicyOrEndorsementReference	
)
SELECT		                 PK_NonLloydsPremiumTransaction					  = ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(CONVERT([VARCHAR](255),nlpt.PK_Transaction) + '|~|' + nlpt.SourceSystem))),(0))
							,DateCreated                                      = nlpt.DateCreated
							,EffectiveFromDate                                = nlpt.EffectiveFromDate
							,EffectiveToDate                                  = nlpt.EffectiveToDate
							,AccountingPeriod                                 = nlpt.AccountingPeriod
							,SettlementDate							          = nlpt.SettlementDate
							,TransactionTypeCode                              = nlpt.TransactionTypeCode
							,TransactionType                                  = nlpt.TransactionType
							,OriginalCCYToSettlementCCYRate                   = nlpt.OriginalCCYToSettlementCCYRate
							,GrossPremiumInOriginalCCY                        = nlpt.GrossPremiumInOriginalCCY
							,ExternalAcquisitionCostInOriginalCCY             = nlpt.ExternalAcquisitionCostInOriginalCCY
							,FK_Section                                       = nlpt.FK_Section
							,FK_SettlementCurrency                            = nlpt.FK_SettlementCurrency
							,FK_OriginalCurrency                              = nlpt.FK_OriginalCurrency
							,FK_DevelopmentPeriod                             = nlpt.FK_DevelopmentPeriod
							,OriginalCCYToLocalCCYRate						  = ISNULL(nlpt.OriginalCCYToLocalCCYRate,1)
							,FK_LocalCurrency								  = ISNULL(nlpt.FK_LocalCurrency,0)
							,RiskLocation									  = nlpt.RiskLocation	
							,InvoiceReference                                 = nlpt.InvoiceReference
							,NumberOfInstalments							  = nlpt.NumberOfInstalments
							,PaymentFrequency								  = nlpt.PaymentFrequency	
							,PaymentMethod									  = nlpt.PaymentMethod
							,PaymentReference								  = nlpt.PaymentReference
							,Notes											  = nlpt.Notes		
							,PolicyOrEndorsementReference					  = nlpt.PolicyOrEndorsementReference	

FROM
#NonLloydsPremiumTransaction nlpt
WHERE
nlpt.GrossPremiumInOriginalCCY <> 0
OR nlpt.ExternalAcquisitionCostInOriginalCCY <> 0

	
	
	--MERGE ODS.NonLloydsPremiumTransaction AS TARGET
	--USING	(
	--			SELECT		PK_NonLloydsPremiumTransaction					  = (isnull([Utility].[udf_ComputeIdentity](CONVERT([VARCHAR](255),nlpt.PK_Transaction) + '|~|' + nlpt.SourceSystem, 0),(0)))
	--						,DateCreated                                      = nlpt.DateCreated
	--						,EffectiveFromDate                                = nlpt.EffectiveFromDate
	--						,EffectiveToDate                                  = nlpt.EffectiveToDate
	--						,AccountingPeriod                                 = nlpt.AccountingPeriod
	--						,SettlementDate							          = nlpt.SettlementDate
	--						,TransactionTypeCode                              = nlpt.TransactionTypeCode
	--						,TransactionType                                  = nlpt.TransactionType
	--						,OriginalCCYToSettlementCCYRate                   = nlpt.OriginalCCYToSettlementCCYRate
	--						,GrossPremiumInOriginalCCY                        = nlpt.GrossPremiumInOriginalCCY
	--						,ExternalAcquisitionCostInOriginalCCY             = nlpt.ExternalAcquisitionCostInOriginalCCY
	--						,FK_Section                                       = nlpt.FK_Section
	--						,FK_SettlementCurrency                            = nlpt.FK_SettlementCurrency
	--						,FK_OriginalCurrency                              = nlpt.FK_OriginalCurrency
	--						,FK_DevelopmentPeriod                             = nlpt.FK_DevelopmentPeriod
	--						,OriginalCCYToLocalCCYRate						  = ISNULL(nlpt.OriginalCCYToLocalCCYRate,1)
	--						,FK_LocalCurrency								  = ISNULL(nlpt.FK_LocalCurrency,0)
	--						,RiskLocation									  = nlpt.RiskLocation	
	--						,InvoiceReference                                 = nlpt.InvoiceReference
	--						,NumberOfInstalments							  = nlpt.NumberOfInstalments
	--						,PaymentFrequency								  = nlpt.PaymentFrequency	
	--						,PaymentMethod									  = nlpt.PaymentMethod
	--						,PaymentReference								  = nlpt.PaymentReference
	--						,Notes											  = nlpt.Notes		
	--						,PolicyOrEndorsementReference					  = nlpt.PolicyOrEndorsementReference	
	--			FROM		#NonLloydsPremiumTransaction nlpt
	--			WHERE		nlpt.GrossPremiumInOriginalCCY <> 0
	--					OR	nlpt.ExternalAcquisitionCostInOriginalCCY <> 0
	--) SOURCE ON TARGET.PK_NonLloydsPremiumTransaction = SOURCE.PK_NonLloydsPremiumTransaction
	--WHEN MATCHED AND (
	--						ISNULL(TARGET.DateCreated, '1900-01-01')				<> ISNULL(SOURCE.DateCreated, '1900-01-01') 
	--						OR ISNULL(TARGET.EffectiveFromDate, '1900-01-01')		<> ISNULL(SOURCE.EffectiveFromDate, '1900-01-01') 
	--						OR ISNULL(TARGET.EffectiveToDate, '1900-01-01')			<> ISNULL(SOURCE.EffectiveToDate, '1900-01-01') 
	--						OR TARGET.AccountingPeriod								<> SOURCE.AccountingPeriod
	--						OR ISNULL(TARGET.SettlementDate, '1900-01-01')			<> ISNULL(SOURCE.SettlementDate, '1900-01-01')
	--						OR ISNULL(TARGET.TransactionTypeCode, '')				<> ISNULL(SOURCE.TransactionTypeCode, '')
	--						OR ISNULL(TARGET.TransactionType, '')					<> ISNULL(SOURCE.TransactionType, '')
	--						OR ISNULL(TARGET.GrossPremiumInOriginalCCY, 0)			<> ISNULL(SOURCE.GrossPremiumInOriginalCCY, 0)
	--						OR ISNULL(TARGET.ExternalAcquisitionCostInOriginalCCY, 0) <> ISNULL(SOURCE.ExternalAcquisitionCostInOriginalCCY, 0)
	--						OR ISNULL(TARGET.OriginalCCYToSettlementCCYRate, 0)		<> ISNULL(SOURCE.OriginalCCYToSettlementCCYRate, 0)
	--						OR ISNULL(TARGET.OriginalCCYToLocalCCYRate, 0)			<> ISNULL(SOURCE.OriginalCCYToLocalCCYRate, 0)
	--						OR ISNULL(TARGET.FK_Section, 0)							<> ISNULL(SOURCE.FK_Section, 0)
	--						OR ISNULL(TARGET.FK_OriginalCurrency, 0)				<> ISNULL(SOURCE.FK_OriginalCurrency, 0)
	--						OR ISNULL(TARGET.FK_SettlementCurrency, 0)				<> ISNULL(SOURCE.FK_SettlementCurrency, 0)
	--						OR ISNULL(TARGET.FK_LocalCurrency, 0)					<> ISNULL(SOURCE.FK_LocalCurrency, 0)
	--						OR ISNULL(TARGET.FK_DevelopmentPeriod, 0)				<> ISNULL(SOURCE.FK_DevelopmentPeriod, 0)
	--						OR ISNULL(TARGET.RiskLocation, '')						<> ISNULL(SOURCE.RiskLocation, '') 
	--						OR ISNULL(TARGET.InvoiceReference, '')					<> ISNULL(SOURCE.InvoiceReference, '') 
	--						OR ISNULL(TARGET.NumberOfInstalments, 0)				<> ISNULL(SOURCE.NumberOfInstalments, 0)
	--						OR ISNULL(TARGET.PaymentFrequency, '')					<> ISNULL(SOURCE.PaymentFrequency, '')	
	--						OR ISNULL(TARGET.PaymentMethod, '')						<> ISNULL(SOURCE.PaymentMethod, '') 
	--						OR ISNULL(TARGET.PaymentReference, '')					<> ISNULL(SOURCE.PaymentReference, '') 
	--				)
	--THEN
	--	UPDATE SET			TARGET.DateCreated								= SOURCE.DateCreated
	--						,TARGET.EffectiveFromDate                       = SOURCE.EffectiveFromDate
	--						,TARGET.EffectiveToDate                         = SOURCE.EffectiveToDate
	--						,TARGET.AccountingPeriod                        = SOURCE.AccountingPeriod
	--						,TARGET.SettlementDate                          = SOURCE.SettlementDate
	--						,TARGET.TransactionTypeCode                     = SOURCE.TransactionTypeCode
	--						,TARGET.TransactionType                         = SOURCE.TransactionType
	--						,TARGET.OriginalCCYToSettlementCCYRate          = SOURCE.OriginalCCYToSettlementCCYRate
	--						,TARGET.GrossPremiumInOriginalCCY               = SOURCE.GrossPremiumInOriginalCCY
	--						,TARGET.ExternalAcquisitionCostInOriginalCCY    = SOURCE.ExternalAcquisitionCostInOriginalCCY
	--						,TARGET.FK_Section                              = SOURCE.FK_Section
	--						,TARGET.FK_SettlementCurrency                   = SOURCE.FK_SettlementCurrency
	--						,TARGET.FK_OriginalCurrency                     = SOURCE.FK_OriginalCurrency
	--						,TARGET.FK_DevelopmentPeriod                    = SOURCE.FK_DevelopmentPeriod
	--						,TARGET.OriginalCCYToLocalCCYRate               = SOURCE.OriginalCCYToLocalCCYRate
	--						,TARGET.FK_LocalCurrency                        = SOURCE.FK_LocalCurrency
	--						,TARGET.RiskLocation                            = SOURCE.RiskLocation
	--						,TARGET.InvoiceReference		                = SOURCE.InvoiceReference
	--						,TARGET.NumberOfInstalments                     = SOURCE.NumberOfInstalments
	--						,TARGET.PaymentFrequency                        = SOURCE.PaymentFrequency
	--						,TARGET.PaymentMethod                           = SOURCE.PaymentMethod
	--						,TARGET.PaymentReference                        = SOURCE.PaymentReference
	--						,TARGET.AuditModifyDateTime						= GETDATE()						
	--						,TARGET.AuditModifyDetails						= 'Merge in ODS.usp_LoadNonLloydsPremiumTransaction proc' 
	--WHEN NOT MATCHED BY TARGET THEN
	--INSERT					( 
	--						PK_NonLloydsPremiumTransaction
	--						,DateCreated
	--						,EffectiveFromDate
	--						,EffectiveToDate
	--						,AccountingPeriod
	--						,SettlementDate
	--						,TransactionTypeCode
	--						,TransactionType
	--						,OriginalCCYToSettlementCCYRate
	--						,GrossPremiumInOriginalCCY
	--						,ExternalAcquisitionCostInOriginalCCY
	--						,FK_Section
	--						,FK_SettlementCurrency
	--						,FK_OriginalCurrency
	--						,FK_DevelopmentPeriod
	--						,OriginalCCYToLocalCCYRate
	--						,FK_LocalCurrency
	--						,RiskLocation
	--						,InvoiceReference		
	--						,NumberOfInstalments
	--						,PaymentFrequency
	--						,PaymentMethod
	--						,PaymentReference
	--						,AuditCreateDateTime
	--						,AuditModifyDetails
	--) 
	--VALUES (
	--						SOURCE.PK_NonLloydsPremiumTransaction
	--						,SOURCE.DateCreated
	--						,SOURCE.EffectiveFromDate
	--						,SOURCE.EffectiveToDate
	--						,SOURCE.AccountingPeriod
	--						,SOURCE.SettlementDate
	--						,SOURCE.TransactionTypeCode
	--						,SOURCE.TransactionType
	--						,SOURCE.OriginalCCYToSettlementCCYRate
	--						,SOURCE.GrossPremiumInOriginalCCY
	--						,SOURCE.ExternalAcquisitionCostInOriginalCCY
	--						,SOURCE.FK_Section
	--						,SOURCE.FK_SettlementCurrency
	--						,SOURCE.FK_OriginalCurrency
	--						,SOURCE.FK_DevelopmentPeriod
	--						,SOURCE.OriginalCCYToLocalCCYRate
	--						,SOURCE.FK_LocalCurrency
	--						,SOURCE.RiskLocation
	--						,SOURCE.InvoiceReference		
	--						,SOURCE.NumberOfInstalments
	--						,SOURCE.PaymentFrequency
	--						,SOURCE.PaymentMethod
	--						,SOURCE.PaymentReference
	--						,GETDATE()
	--						,'New add in ODS.usp_LoadNonLloydsPremiumTransaction proc'
	--)
	--WHEN NOT MATCHED BY SOURCE THEN 
	--						DELETE;

	DROP TABLE IF EXISTS #NonLloydsPremiumTransaction;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'NonLloydsPremiumTransaction';

END