﻿CREATE PROC [ODS].[usp_LoadDocument]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Document

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


DELETE d
FROM ODS.Document d
WHERE d.FK_Section NOT IN (SELECT DISTINCT PK_Section FROM ODS.Section)

DELETE d 
FROM ODS.Document d
WHERE d.FK_DocumentType NOT IN (SELECT DISTINCT PK_DocumentType FROM ODS.DocumentType)

;WITH CTEDocuments AS
(
    SELECT
    SectionOrQuoteReference                 = dm.TokenValue
    ,DocumentType                           = d.ContentType 
    ,SequenceId                             = ROW_NUMBER() OVER
                                                (PARTITION BY dm.TokenValue, d.ContentType
                                                ORDER BY d.CreatedOn ASC) 
    ,CreatedOn                              = d.CreatedOn
    ,ModifiedOn                             = d.ModifiedOn
    ,CreatedBy                              = d.CreatedBy
    ,ModifiedBy                             = d.ModifiedBy
    ,Deleted                                = d.Deleted
    FROM
    Staging_BeazleyDocumentsReporting.BeazleyDocumentsReporting_Staging.Documents d 
    INNER JOIN
    Staging_BeazleyDocumentsReporting.BeazleyDocumentsReporting_Staging.DocumentsMetadata dm ON
    d.ID = dm.DocID /*BI-8136*/ and d.SourceLocation = dm.SourceLocation /*BI-8136*/

    WHERE
    dm.TokenName = 'BeazleyDocumentsRiskReference'
    AND d.Deleted = 0
) 

,CTECIPSDeduplication AS
(
SELECT 
  doc.SourceSystem
 ,doc.DocumentType
 ,doc.SectionSourceID
 ,doc.DocumentSequenceID 
 ,doc.DocumentUserCreate
 ,doc.DocumentUserModify
 ,doc.DocumentCreateDate
 ,doc.UploadedDateTime
 ,doc.DocumentModifyDate
 ,rnk= ROW_NUMBER() OVER (PARTITION BY  doc.DocumentType, doc.SectionSourceID, doc.DocumentSequenceID 
                         ORDER BY doc.AuditCreateDateTime  DESC                                
                         )        
FROM BeazleyIntelligenceDataContract.Outbound.vw_Document doc
WHERE doc.SourceSystem = 'CIPS'
)

MERGE ODS.Document AS target
USING (		
SELECT
 FK_DocumentType                    = dt.PK_DocumentType
,FK_Section                         = s.PK_Section
,SequenceId                         = x.SequenceId
,CreatedBy                          = x.CreatedBy
,ModifiedBy                         = x.ModifiedBy
,DocumentCreateDate                 = x.CreatedOn 
,UploadedDateTime					= NULL
,DocumentModifyDate                 = x.ModifiedOn
,DaysSinceQuoteOrBindDate           = DATEDIFF(DAY, s.QuoteOrBindDate, x.CreatedOn)
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN CTEDocuments x ON
x.SectionOrQuoteReference = s.SectionDisplayReference
INNER JOIN
ODS.DocumentType dt ON
x.DocumentType = dt.DocumentTypeName
WHERE 
p.SourceSystem = 'Eurobase'
AND ((dt.AuditCreateDatetime > @LastAuditDate OR dt.AuditModifyDatetime > @LastAuditDate)
OR  (s.AuditCreateDatetime > @LastAuditDate OR s.AuditModifyDatetime > @LastAuditDate)	
OR  (p.AuditCreateDatetime > @LastAuditDate OR p.AuditModifyDatetime > @LastAuditDate))	
UNION ALL

/* Insert Unirisx documents */
SELECT DISTINCT
 FK_DocumentType                    = docty.PK_DocumentType
,FK_Section                         = sec.PK_Section
,SequenceId                         = doc.DocumentSequenceID
,CreatedBy                          = doc.DocumentUserCreate
,ModifiedBy                         = doc.DocumentUserModify
,DocumentCreateDate                 = doc.DocumentCreateDate
,UploadedDateTime					= doc.UploadedDateTime
,DocumentModifyDate                 = doc.DocumentModifyDate
,DaysSinceQuoteOrBindDate           = DATEDIFF(DAY, sec.QuoteOrBindDate, doc.DocumentCreateDate)

FROM BeazleyIntelligenceDataContract.Outbound.vw_Document doc

INNER JOIN ODS.DocumentType docty ON
doc.DocumentType = docty.DocumentTypeName

INNER JOIN ODS.Section sec
ON doc.SectionSourceId  = sec.SectionReference

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension unisecx
ON  sec.SectionReference = unisecx.SectionReference
AND unisecx.IsPrimarySection = 1

WHERE doc.SourceSystem = 'Unirisx'
AND unisecx.SourceSystem = 'Unirisx'
AND ((doc.AuditCreateDatetime > @LastAuditDate OR doc.AuditModifyDatetime > @LastAuditDate)
	 OR (unisecx.AuditCreateDatetime > @LastAuditDate OR unisecx.AuditModifyDatetime > @LastAuditDate)
     OR (docty.AuditCreateDatetime > @LastAuditDate OR docty.AuditModifyDatetime > @LastAuditDate)
     OR (sec.AuditCreateDatetime > @LastAuditDate OR sec.AuditModifyDatetime > @LastAuditDate)
	 )

UNION ALL

/* Insert CIPS documents */
SELECT DISTINCT
 FK_DocumentType                    = docty.PK_DocumentType
,FK_Section                         = s.PK_Section
,SequenceId                         = doc.DocumentSequenceID
,CreatedBy                          = doc.DocumentUserCreate
,ModifiedBy                         = doc.DocumentUserModify
,DocumentCreateDate                 = doc.DocumentCreateDate
,UploadedDateTime					= doc.UploadedDateTime
,DocumentModifyDate                 = doc.DocumentModifyDate
,DaysSinceQuoteOrBindDate           = DATEDIFF(DAY, sec.QuoteOrBindDate, doc.DocumentCreateDate)

FROM CTECIPSDeduplication doc

INNER JOIN ODS.DocumentType docty ON
doc.DocumentType = docty.DocumentTypeName

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section sec
ON  doc.SectionSourceId = sec.SectionSourceId AND  doc.SourceSystem = sec.SourceSystem

INNER JOIN ODS.Section s
ON s.SectionReference  = sec.SectionReference

WHERE doc.rnk = 1
AND((sec.AuditCreateDatetime > @LastAuditDate OR sec.AuditModifyDatetime > @LastAuditDate)
    OR (docty.AuditCreateDatetime > @LastAuditDate OR docty.AuditModifyDatetime > @LastAuditDate)	
    OR (s.AuditCreateDatetime > @LastAuditDate OR s.AuditModifyDatetime > @LastAuditDate)	
    )
	
) source 
ON target.FK_DocumentType = source.FK_DocumentType
AND target.SequenceId = source.SequenceId
AND target.FK_Section = source.FK_Section

WHEN MATCHED THEN
UPDATE SET
target. CreatedBy                 = source.CreatedBy               
,target.ModifiedBy                = source.ModifiedBy              
,target.DocumentCreateDate        = source.DocumentCreateDate   
,target.UploadedDateTime		  = source.UploadedDateTime
,target.DocumentModifyDate        = source.DocumentModifyDate      
,target.DaysSinceQuoteOrBindDate  = source.DaysSinceQuoteOrBindDate
,target.AuditModifyDateTime	      = GETDATE()						
,target.AuditModifyDetails	      = 'Merge in ODS.usp_LoadDocument proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
 FK_DocumentType         
,FK_Section              
,SequenceId              
,CreatedBy               
,ModifiedBy              
,DocumentCreateDate      
,UploadedDateTime
,DocumentModifyDate      
,DaysSinceQuoteOrBindDate
,AuditCreateDateTime
,AuditModifyDetails
	)
VALUES
(
 source.FK_DocumentType         
,source.FK_Section              
,source.SequenceId              
,source.CreatedBy               
,source.ModifiedBy              
,source.DocumentCreateDate    
,source.UploadedDateTime
,source.DocumentModifyDate      
,source.DaysSinceQuoteOrBindDate
,GETDATE()
,'New add in ODS.usp_LoadDocument proc'	
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Document';
