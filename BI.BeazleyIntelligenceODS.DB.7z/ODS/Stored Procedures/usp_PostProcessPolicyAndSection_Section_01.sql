﻿
CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_Section_01]
AS

SET NOCOUNT ON

/*Originally from [usp_LoadDiaryEntry]*/
/*Update "Engineering Construction Expiry Date" on section table*/

/*Update "Engineering Construction Expiry Date" on section table*/
UPDATE s SET
EngineeringConstructionExpiryDate = de.EntryDate
,EngineeringConstructionExpiryDateName      = [ODS].[udf_FormatDateTime](de.EntryDate)
FROM
ODS.Section s
INNER JOIN
ODS.DiaryEntry de ON
de.FK_Section = s.PK_Section
WHERE
de.EntryTypeCode = 'RCOMDT'

/*Update Cat/Non Cat premium percentages*/

UPDATE s SET
USQuakeMultiplier           = y.USQuakeMultiplier
,USWindMultiplier           = y.USWindMultiplier
,USNonCatMultiplier         = y.USNonCatMultiplier
,NonUSCatMultiplier         = y.NonUSCatMultiplier
,NonUSNonCatMultiplier      = y.NonUSNonCatMultiplier
FROM
ODS.Section s
INNER JOIN
(
    SELECT
    FK_Section                  = pvt.FK_Section
    ,USQuakeMultiplier          = pvt.XUSQUA
    ,USWindMultiplier           = pvt.XUSWIN
    ,USNonCatMultiplier         = pvt.XUSOTH
    ,NonUSCatMultiplier         = pvt.XINCAT
    ,NonUSNonCatMultiplier      = pvt.XINOTH
    FROM
    (
        SELECT
        FK_Section              = de.FK_Section
        ,EntryTypeCode          = de.EntryTypeCode
        ,EntryValue             = Utility.udf_ProcessPercentage(de.EntryValue, 0, 0, 0)
        FROM  
        ODS.DiaryEntry de
    ) x
    PIVOT
    (
        SUM(x.EntryValue)
        FOR
        x.EntryTypeCode IN
        (
            [XUSQUA]
            ,[XUSWIN]
            ,[XUSOTH]
            ,[XINCAT]
            ,[XINOTH]
        )
    ) pvt
) y ON
s.PK_Section = y.FK_Section

/*Update hours clauses*/
UPDATE s SET
OccurrenceTerrorism         = x.OccurrenceTerrorism
,OccurrenceSabotage         = x.OccurrenceSabotage
,OccurrenceRsccmd           = x.OccurrenceRsccmd
,OccurrenceInsurrection     = x.OccurrenceInsurrection
,OccurrenceRevolution       = x.OccurrenceRevolution
,OccurrenceRebellion        = x.OccurrenceRebellion
,OccurrenceMutiny           = x.OccurrenceMutiny
,OccurrenceCoupDEtat        = x.OccurrenceCoupDEtat
,OccurrenceWar              = x.OccurrenceWar
,OccurrenceCivilWar         = x.OccurrenceCivilWar
,HoursClause                = x.HoursClause
,OccurrenceTerrorismName    = [ODS].[udf_FormatInt](x.OccurrenceTerrorism)
,OccurrenceSabotageName     = [ODS].[udf_FormatInt](x.OccurrenceSabotage)
,OccurrenceRSCCMDName       = [ODS].[udf_FormatInt](x.OccurrenceRSCCMD)
,OccurrenceInsurrectionName = [ODS].[udf_FormatInt](x.OccurrenceInsurrection)
,OccurrenceRevolutionName   = [ODS].[udf_FormatInt](x.OccurrenceRevolution)
,OccurrenceRebellionName    = [ODS].[udf_FormatInt](x.OccurrenceRebellion)
,OccurrenceMutinyName       = [ODS].[udf_FormatInt](x.OccurrenceMutiny)
,OccurrenceCoupDEtatName    = [ODS].[udf_FormatInt](x.OccurrenceCoupDEtat)
,OccurrenceWarName          = [ODS].[udf_FormatInt](x.OccurrenceWar)
,OccurrenceCivilWarName     = [ODS].[udf_FormatInt](x.OccurrenceCivilWar)
,HoursClauseName            = [ODS].[udf_FormatInt](x.HoursClause)
FROM
ODS.Section s
INNER JOIN
(
    SELECT
    FK_Section                  = pvt.FK_Section
    ,OccurrenceTerrorism        = pvt.[OTERR]            
    ,OccurrenceSabotage         = pvt.[OSABOT]
    ,OccurrenceRSCCMD           = pvt.[ORSCCM]
    ,OccurrenceInsurrection     = pvt.[OINSUR]
    ,OccurrenceRevolution       = pvt.[OREVOL]
    ,OccurrenceRebellion        = pvt.[OREBEL]
    ,OccurrenceMutiny           = pvt.[OMUTIN]
    ,OccurrenceCoupDEtat        = pvt.[OCOUP]
    ,OccurrenceWar              = pvt.[OWAR]
    ,OccurrenceCivilWar         = pvt.[OCIVW]
    ,HoursClause                = pvt.[HC]
    FROM
    (
        SELECT
        FK_Section              = de.FK_Section
        ,EntryTypeCode          = de.EntryTypeCode
        ,EntryValue             = de.EntryValue
        FROM  
        ODS.DiaryEntry de
    ) x
    PIVOT
    (
        SUM(x.EntryValue)
        FOR
        x.EntryTypeCode IN
        (
            [OTERR]
            ,[OSABOT]
            ,[ORSCCM]
            ,[OINSUR]
            ,[OREVOL]
            ,[OREBEL]
            ,[OMUTIN]
            ,[OCOUP]
            ,[OWAR]
            ,[OCIVW]
            ,[HC]
        )
    ) pvt
) x ON
s.PK_Section = x.FK_Section
          

/*Originally from [usp_LoadDocument]*/
-- Update Rationale document fields in section table
UPDATE s SET  
HasRationaleDocument        = x.HasRationaleDocument
,RationaleDocumentDate      = x.RationaleDocumentDate
,HasRationaleDocumentName	= [ODS].[udf_FormatBitAsYesNo](x.HasRationaleDocument)
,RationaleDocumentDateName	= [ODS].[udf_FormatDateTime](x.RationaleDocumentDate)
,RationaleDateName			= [ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,x.RationaleDocumentDate))
FROM 
ODS.Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasRationaleDocument               = 1
    ,RationaleDocumentDate              = MIN(d.DocumentCreateDate)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
    WHERE
    UPPER(dt.DocumentTypeName) LIKE '%UW%RATIONALE%'
    OR UPPER(dt.DocumentTypeName) LIKE '%UNDERWRITER%RATIONALE%'
    GROUP BY 
    s.PK_Section
            
) x
ON s.PK_Section = x.FK_Section

-- Reset Rational document fields for Unirisx non primary sections

UPDATE s SET  
 HasRationaleDocument       = 0
,RationaleDocumentDate      = NULL
,HasRationaleDocumentName	= [ODS].[udf_FormatBitAsYesNo](0)
,RationaleDocumentDateName	= [ODS].[udf_FormatDateTime](NULL)
,RationaleDateName			= [ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,NULL))

FROM ODS.Section s

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension unisecex
ON s.SectionReference = unisecex.SectionReference
AND unisecex.IsPrimarySection <> 1

WHERE unisecex.SourceSystem = 'Unirisx'
--AND unisecex.IsActive = 1

-- Update exception document fields in section table
UPDATE s SET  
HasExceptionDocument        = x.HasExceptionDocument
,ExceptionDocumentDate      = x.ExceptionDocumentDate
,FK_ExceptionDocumentDate   = [Utility].[udf_GenerateDateKey](x.ExceptionDocumentDate)
,HasExceptionDocumentName	= [ODS].[udf_FormatBitAsYesNo](x.HasExceptionDocument)
,ExceptionDocumentDateName  = [ODS].[udf_FormatDateTime](x.ExceptionDocumentDate)
FROM 
ODS.Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasExceptionDocument               = 1
    ,ExceptionDocumentDate              = MIN(d.DocumentCreateDate)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
    WHERE
    UPPER(dt.DocumentTypeName) LIKE 'EXCEPTION%SIGN%OFF'
    GROUP BY 
    s.PK_Section
            
) x
ON s.PK_Section = x.FK_Section

UPDATE s SET
RationaleCompletionMethod       = CASE 
                                    WHEN p.SourceSystem NOT IN ('Eurobase','Unirisx') OR p.IsQuote = 1 THEN 'N/A'
                                    WHEN s.HasRationaleDocument = 1 THEN 'Document'
                                    ELSE 'Incomplete'
                                  END
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE
s.PK_Section <> 0



-- Update contract certainty document fields in section table
UPDATE s SET  
HasContractCertaintyDocument        = x.HasContractCertaintyDocument
,ContractCertaintyDocumentDate      = x.ContractCertaintyDocumentDate
,DaysBetweenQBAndCCDocumentDate     = DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate)
,FK_ContractCertaintyDocumentDate   = [Utility].[udf_GenerateDateKey](x.ContractCertaintyDocumentDate)
,ContractCertaintyDocumentDateName  = [ODS].[udf_FormatDateTime](x.ContractCertaintyDocumentDate)
,DaysBetweenQBAndCCDocumentDateName = [ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate))
,HasContractCertaintyDocumentName   = ([ODS].[udf_FormatBitAsYesNo](x.HasContractCertaintyDocument)) --BI-8376
FROM 
ODS.Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasContractCertaintyDocument       = 1
    ,ContractCertaintyDocumentDate      = MIN(d.DocumentCreateDate)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
	INNER JOIN ODS.Policy p ON
	s.FK_Policy = p.PK_Policy
    WHERE
    UPPER(dt.DocumentTypeName) = 'CONTRACT CERTAINTY'
	AND p.SourceSystem = 'Eurobase'
    GROUP BY 
    s.PK_Section, p.SourceSystem
            
) x
ON s.PK_Section = x.FK_Section 

-- Update contract certainty document fields in section table - for Unirisx sourcesystem - BI 676
UPDATE s SET  
HasContractCertaintyDocument        = x.HasContractCertaintyDocument
,ContractCertaintyDocumentDate      = x.ContractCertaintyDocumentDate
,DaysBetweenQBAndCCDocumentDate     = DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate)
,ContractCertaintyDocumentDateName  = [ODS].[udf_FormatDateTime](x.ContractCertaintyDocumentDate)
,DaysBetweenQBAndCCDocumentDateName = [ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate))
,HasContractCertaintyDocumentName   = ([ODS].[udf_FormatBitAsYesNo](x.HasContractCertaintyDocument)) --BI-8376

FROM 
ODS.Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasContractCertaintyDocument       = 1
    ,ContractCertaintyDocumentDate      = MIN(d.UploadedDateTime)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
	INNER JOIN ODS.Policy p ON
	s.FK_Policy = p.PK_Policy
    WHERE
    dt.DocumentTypeName = 'CONTRACT CERTAINTY'
	AND p.SourceSystem = 'Unirisx'
	AND s.ContractCertaintyPrimaryCompleteDate IS NULL
    GROUP BY 
    s.PK_Section, p.SourceSystem
            
) x
ON s.PK_Section = x.FK_Section 


/*Originally from usp_LoadPICCTransaction*/
/*Update latest PICC period in section (latest by ID), missing tansactions, and flag*/
UPDATE s SET
LatestPICCPeriod                = picc.PICCPeriod
 --This is supposed to come out NULL if Expected is NULL. If we're not expecting any, we don't care if we
 --have any for the purposes of calculating the number of missing transactions
,MissingPICCTransactions        = ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0)
,HasMissingPICCTransactions     = CASE 
                                    WHEN ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0) > 0 THEN 1
                                    ELSE 0
                                   END
,MissingPICCTransactionsName    = [ODS].[udf_FormatInt](ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0))
,HasMissingPICCTransactionsName             = [ODS].[udf_FormatBitAsYesNo](CASE 
                                    WHEN ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0) > 0 THEN 1
                                    ELSE 0
                                   END)
FROM
ODS.Section s 
LEFT OUTER JOIN
(
    SELECT
    FK_Section                  = picc.FK_Section
    ,MaxPICCPeriodId            = MAX(picc.PICCPeriodId)
    ,NumberOfTransactions       = COUNT(1)
    FROM
    ODS.PICCTransaction picc
    GROUP BY
    picc.FK_Section
) AS m ON
s.PK_Section = m.FK_Section
LEFT OUTER JOIN
ODS.PICCTransaction picc ON
m.FK_Section = picc.FK_Section AND
m.MaxPICCPeriodId = picc.PICCPeriodId



/*Update "ExpiryDateInForce" on section table*/

UPDATE s SET
ExpiryDateInForce = CASE 
						WHEN p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger')
                        OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
						OR p.SourceSystem = 'CIPS' 
						THEN DATEADD(DAY, -1, ExpiryDate) 
						ELSE ExpiryDate
					END
,FK_ExpiryDateInForce  = [Utility].[udf_GenerateDateKey](CASE 
						WHEN  p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger')
                        OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
						OR p.SourceSystem = 'CIPS'  
						THEN DATEADD(DAY, -1, ExpiryDate) 
						ELSE ExpiryDate
					END)
FROM
ODS.Section s
INNER JOIN
ODS.Policy p
ON p.PK_Policy = s.FK_policy
INNER JOIN
ODS.Trifocus t
ON t.PK_Trifocus = s.FK_Trifocus




/*Originally from usp_LoadSectionAcquisitionCost*/
UPDATE s SET
ExternalAcquisitionCostMultiplier				= x.ExternalAcquisitionCostMultiplier
,ExternalAcquisitionCostMultiplierName			= ([ODS].[udf_FormatMultiplierAsPercentage](x.ExternalAcquisitionCostMultiplier,(2))) --BI-8376
FROM
ODS.Section s
INNER JOIN
(
    SELECT
    FK_Section                              = actp.FK_Section
    ,FK_EntityPerspective                   = actp.FK_EntityPerspective
    ,ExternalAcquisitionCostMultiplier      = SUM(actp.AcquisitionCostMultiplier)
    FROM
    ODS.AcquisitionCostType act
    INNER JOIN
    ODS.SectionAcquisitionCost actp ON
    actp.FK_AcquisitionCostType = act.PK_AcquisitionCostType
	AND actp.TaxDescription = act.TaxDescription
    WHERE
    act.AcquisitionCostTypeInternalExternal = 'External'
    GROUP BY
    actp.FK_Section
    ,actp.FK_EntityPerspective
) x ON
s.PK_Section = x.FK_Section /*We don't need to (and can't) join on EntityPerspective here, 
as for *external* costs the value for every EP that exists for the section is the same*/
WHERE isnull(s.Product,'N/A') NOT IN ('Surety Quota Share', 'Universal Product Incubator-BPS Embedded') --for these 2 products, we let the value from Outbound.vw_Section


/*Update internal acquisition costs*/
UPDATE sep SET
InternalAcquisitionCostMultiplier       = x.InternalAcquisitionCostMultiplier
FROM
ODS.SectionEntityPerspective sep
INNER JOIN
(
    SELECT
    FK_Section                              = s.PK_Section
    ,FK_EntityPerspective                   = sac.FK_EntityPerspective
    ,InternalAcquisitionCostMultiplier      = SUM(sac.AcquisitionCostMultiplier)
    FROM
    ODS.AcquisitionCostType act
    INNER JOIN
    ODS.SectionAcquisitionCost sac ON
    sac.FK_AcquisitionCostType = act.PK_AcquisitionCostType
	AND sac.TaxDescription = act.TaxDescription
    INNER JOIN
    ODS.Section s ON
    sac.FK_Section = s.PK_Section
    WHERE
    act.AcquisitionCostTypeInternalExternal = 'Internal'
    GROUP BY
    s.PK_Section
    ,sac.FK_EntityPerspective
) x ON
sep.FK_Section = x.FK_Section
AND sep.FK_EntityPerspective = x.FK_EntityPerspective

-- For Unirisx Marine Oslo the users manually update the OriginalNetEPI, 
-- this logic allows us to display both gross and net OriginalEPI amounts 
-- AS they are on the UI screen
-- Update OriginalEPITotalAcquisitionCostMultiplier with the ExternalAcquisitionCostMultiplier value
-- in the section table where this value is not populated already 
UPDATE s SET
OriginalEPITotalAcquisitionCostMultiplier   = s.ExternalAcquisitionCostMultiplier
FROM
ODS.Section s
WHERE OriginalEPITotalAcquisitionCostMultiplier IS NULL

  

/*Originally from usp_LoadSectionControlQuestionAnswer*/
IF (OBJECT_ID('tempdb..#ControlQuestionsComplete')) IS NOT NULL
DROP TABLE #ControlQuestionsComplete

CREATE TABLE #ControlQuestionsComplete
(
    FK_Section                  bigint          NOT NULL
    ,ControlQuestionType        varchar(255)    NOT NULL
    ,NumberOfQuestions          int             NOT NULL
    ,NumberOfAnswers            int             NOT NULL
    PRIMARY KEY (FK_Section, ControlQuestionType)
)


TRUNCATE TABLE #ControlQuestionsComplete

INSERT INTO #ControlQuestionsComplete
(
    FK_Section
    ,ControlQuestionType
    ,NumberOfQuestions
    ,NumberOfAnswers
)
SELECT
FK_Section                      = s.PK_Section
,ControlQuestionType            = x.ControlQuestionType
,NumberOfQuestions              = x.NumberOfQuestions
,NumberOfAnswers                = ISNULL(y.NumberOfAnswers,0) 
FROM
ODS.Section s
CROSS JOIN
(
    SELECT
    ControlQuestionType     = cqt.ControlQuestionType 
    ,NumberOfQuestions      = COUNT(1)
    FROM
    ODS.ControlQuestion cq
    INNER JOIN
    ODS.ControlQuestionType cqt ON
    cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
    GROUP BY
    cqt.ControlQuestionType
) x
LEFT OUTER JOIN
(
    SELECT
    FK_Section              = scqa.FK_Section
    ,ControlQuestionType    = cqt.ControlQuestionType
    ,NumberOfAnswers        = SUM(scqa.AnswerCount)
    FROM
    ODS.ControlQuestionType cqt 
    INNER JOIN
    ODS.ControlQuestion cq ON
    cqt.PK_ControlQuestionType = cq.FK_ControlQuestionType
    INNER JOIN
    ODS.SectionControlQuestionAnswer scqa ON
    cq.PK_ControlQuestion = scqa.FK_ControlQuestion
    GROUP BY
    scqa.FK_Section
    ,cqt.ControlQuestionType
) y ON
s.PK_Section = y.FK_Section
AND x.ControlQuestionType = y.ControlQuestionType

UPDATE s SET
RateChangeControlComplete               = CASE WHEN cqc_rc.NumberOfAnswers = cqc_rc.NumberOfQuestions THEN 1 ELSE s.RateChangeControlComplete END
,RationaleQuestionnaireComplete         = CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN 1 ELSE 0 END
,RationaleQuestionnaireDate             = CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END
,RationaleDate							= [Utility].[udf_EarlierDate]((CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END),s.RationaleDocumentDate)
,RationaleQuestionnaireCompleteName		= ([ODS].[udf_FormatBitAsYesNo](CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN 1 ELSE 0 END)) --BI-8376
,RateChangeControlCompleteName          = ([ODS].[udf_FormatBitAsYesNo](CASE WHEN cqc_rc.NumberOfAnswers = cqc_rc.NumberOfQuestions THEN 1 ELSE s.RateChangeControlComplete END)) --BI-8376
,RationaleQuestionnaireDateName         = ([ODS].[udf_FormatDateTime](CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END)) --BI-8376
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_rc ON
s.PK_Section = cqc_rc.FK_Section
AND cqc_rc.ControlQuestionType = 'Rate Change'
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_r ON
s.PK_Section = cqc_r.FK_Section
AND cqc_r.ControlQuestionType = 'Rationale'
WHERE s.PK_Section <> 0
  AND p.SourceSystem <> 'Unirisx'

/* Update RateChangeControlComplete field for Unirisx     */
UPDATE s SET
RateChangeControlComplete               = s.RateChangeControlComplete 
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_rc ON
s.PK_Section = cqc_rc.FK_Section
AND cqc_rc.ControlQuestionType = 'Rate Change'
WHERE s.PK_Section <> 0
  AND p.SourceSystem = 'Unirisx'
  
/*Update rate change*/
UPDATE s SET
RateChangeExposureMultiplier                    = rc.RateChangeExposureMultiplier
,RateChangeRiskMultiplier                       = rc.RateChangeRiskMultiplier
,RateChangeDeductibleMultiplier                 = rc.RateChangeDeductibleMultiplier
,RateChangeLimitMultiplier                      = rc.RateChangeLimitMultiplier
,RateChangeTermsAndConditionsMultiplier         = rc.RateChangeTermsAndConditionsMultiplier
,RateChangeOtherMultiplier                      = rc.RateChangeOtherMultiplier
FROM
ODS.Section s
INNER JOIN
(
    SELECT
    FK_Section                                  = scqa.FK_Section
    ,RateChangeExposureMultiplier               = SUM(CASE WHEN cq.ControlQuestion LIKE 'Exposure%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeRiskMultiplier                   = SUM(CASE WHEN cq.ControlQuestion LIKE 'Risk%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeDeductibleMultiplier             = SUM(CASE WHEN cq.ControlQuestion LIKE 'Deductible%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeLimitMultiplier                  = SUM(CASE WHEN cq.ControlQuestion LIKE 'Limit%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeTermsAndConditionsMultiplier     = SUM(CASE WHEN cq.ControlQuestion LIKE 'Terms%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeOtherMultiplier                  = SUM(CASE WHEN cq.ControlQuestion LIKE 'Other%' THEN scqa.NumericAnswer ELSE NULL END)
    FROM
    ODS.SectionControlQuestionAnswer scqa
    INNER JOIN
    ODS.ControlQuestion cq ON
    scqa.FK_ControlQuestion = cq.PK_ControlQuestion
    INNER JOIN
    ODS.ControlQuestionType cqt ON
    cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
    WHERE
    cqt.ControlQuestionType = 'Rate Change'
    GROUP BY
    scqa.FK_Section
) rc ON
s.PK_Section = rc.FK_Section

IF (OBJECT_ID('tempdb..#ControlQuestionsComplete')) IS NOT NULL
DROP TABLE #ControlQuestionsComplete



/*Originally from usp_LoadSectionTerritory*/
UPDATE s SET
HasTreatyAggsTerritory = 1
,HasTreatyAggsTerritoryName					= [ODS].[udf_FormatBitAsYesNo](1)
FROM
ODS.Section s
INNER JOIN
ODS.SectionTerritory st ON
s.PK_Section = st.FK_Section



/*Originally from usp_LoadSectionWorkFlow*/
/*Update first live date on Section.
For pre-Synergy, we take the earlier of the first live date and the date entered (which has already
been written to the "First Live Date" field for non-Synergy policies in usp_LoadSection*/
UPDATE s SET
FirstLiveDate               = CASE s.IsSynergySection
                                WHEN 1 THEN x.StatusFromDate
                                ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
                              END
,FK_FirstLiveDate			= ([Utility].[udf_GenerateDateKey](
																CASE s.IsSynergySection
																	WHEN 1 THEN x.StatusFromDate
																	ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
																END)) --BI-8376
,FirstLiveDateName                         = ([ODS].[udf_FormatDateTime](
																			CASE s.IsSynergySection
																				WHEN 1 THEN x.StatusFromDate
																				ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
																			END)) --BI-8376
FROM
ODS.Section s
INNER JOIN
(
    SELECT
    FK_Section          = swc.FK_Section
    ,StatusFromDate     = sw.StatusFromDate
    ,SequenceId         = ROW_NUMBER() OVER
                            (PARTITION BY swc.FK_Section
                             ORDER BY sw.StatusFromDate ASC) 
    FROM
    ODS.SectionWorkflow sw
    INNER JOIN
    ODS.WorkflowStatus ws ON
    sw.FK_WorkflowStatus = ws.PK_WorkflowStatus
    INNER JOIN
    ODS.SectionWorkflowCycle swc ON
    sw.FK_SectionWorkflowCycle = swc.PK_SectionWorkflowCycle
    WHERE
    ws.WorkflowStatusCode = 'L'
) x ON
s.PK_Section = x.FK_Section
AND x.SequenceId = 1



/*Originally from usp_LoadUnderwriterAuthorityException*/
-- Update policy related fields
UPDATE s SET
HasUnderwriterAuthorityException = 1
,HasUnderwriterAuthorityExceptionName		= [ODS].[udf_FormatBitAsYesNo](1)
FROM
ODS.Section s
INNER JOIN ODS.UnderwriterAuthorityException uae ON
s.PK_Section = uae.FK_section



/*Contract certainty

1. If the status is "Primary Complete - Document to be loaded" and the status was 
never "Primary Complete" and no document has been loaded, the status should report "Incomplete".

2. If the status was never "Primary Complete" and the "Days Between QB And CC Document Date" > 21, 
the "Pre-Bind On Time" field should report "Not On Time".

*/

UPDATE s SET
ContractCertaintyStatus                 = 'Incomplete'
,ContractCertaintyStatusSortOrder       = 5
,ContractCertaintyPreBindComplete       = 0
,ContractCertaintyPreBindOnTime         = 0
,ContractCertaintyPreBindCompleteName   = 'Incomplete' --BI-8376
FROM
ODS.Section s
WHERE
ContractCertaintyStatus = 'Primary Complete - Document to be loaded'
AND HasContractCertaintyDocument = 0
AND ContractCertaintyPrimaryCompleteDate IS NULL

UPDATE s SET
ContractCertaintyPreBindOnTime			= 0
FROM
ODS.Section s
INNER JOIN
ODS.Policy  p ON
s.FK_Policy = p.PK_Policy
WHERE  p.SourceSystem NOT IN ('Eurobase', 'Unirisx')
AND s.ContractCertaintyPrimaryCompleteDate IS NULL
AND s.DaysBetweenQBAndCCDocumentDate > 21
AND s.ContractCertaintyStatus <> 'No Status'


UPDATE s SET
ContractCertaintyPreBindOnTime = 0
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE  p.SourceSystem IN ('Eurobase', 'Unirisx')
AND (
	DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPrimaryCompleteDate ) IS NULL
	OR DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPrimaryCompleteDate  ) > 1
	)
AND (
	 DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPreBindSignatureDate  ) IS NULL
     OR DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPreBindSignatureDate  ) > 1
	 OR HasContractCertaintyDocument = 0
	 OR s.DaysBetweenQBAndCCDocumentDate > 21
	 )



	 
UPDATE s SET
ContractCertaintyRequired				= CASE
										    WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 1 --Open market
										    WHEN s.IsFacility = 1 AND ISNULL(f.BinderType, '0') <> '4' THEN 1
										    WHEN s.IsDeclaration = 1 AND f.BinderType = '4' THEN 1
										    ELSE 0
										  END
,ContractCertaintyRequiredName          = ([ODS].[udf_FormatBit](
																	CASE
																		WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 1 --Open market
																		WHEN s.IsFacility = 1 AND ISNULL(f.BinderType, '0') <> '4' THEN 1
																		WHEN s.IsDeclaration = 1 AND f.BinderType = '4' THEN 1
																		ELSE 0
																	END,
																'Contract Certainty Required','Contract Certainty Not Required','Contract Certainty Not Required')) --BI-8376
FROM
ODS.Section s 
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
ODS.Section f ON
s.FK_Facility = f.PK_Section
WHERE
s.PK_Section <> 0
AND s.IsBreachResponseDummy = 0
AND p.SourceSystem = 'Eurobase'
AND s.SectionReferenceSectionIdentifier IN ('A', 'J')
AND NOT EXISTS
(
    SELECT
    1
    FROM
    ODS.Section s1
    WHERE
    s1.SectionReferenceSectionIdentifier = 'A'
    AND s1.ContractCertaintyStatus IN
    (
        'Primary Complete'
        ,'Primary Complete - Document to be loaded'
        ,'Controls Compliant'
        ,'Fully Compliant'
    )
    AND
    s.SectionReferenceSectionIdentifier = 'A'
    AND s.ContractCertaintyStatus IN ('Incomplete', 'No Status')
    AND s.FK_Policy = s1.FK_Policy
)

/* Update IsBeazleyLead with 1 for the claims that have SourceSystem ='ClaimCenter' in ODS.Section  BI-6313*/
UPDATE s
SET IsBeazleyLead = 1
FROM ODS.Section s 
WHERE SourceSystem ='ClaimCenter'

UPDATE ODS.Section
SET [IsBeazleyLeadName]					= ([ODS].[udf_FormatBitAsYesNo]([IsBeazleyLead]))
	,[NumberOfBeazleyLed]               = (case when [IsUnknownMember]=(1) then (0) else CONVERT([int],[IsBeazleyLead]) end)
WHERE SourceSystem ='ClaimCenter'  --BI-8376

--/* BI-9254 */

--UPDATE s 
--SET IsGblPgm = 'Yes'  
--FROM ODS.Section s 
--INNER JOIN 
--ODS.GlobalProgrammeRisk gpr 
--ON s.PK_Section = gpr.FK_Section 

--/*BI-9254*/

