﻿CREATE PROCEDURE [ODS].[usp_LoadSubmission]
AS
BEGIN

SET NOCOUNT ON 
-- Last modified by Bogdan Irimia @ 28.04.2017 for ticket #683

/*** The area for helper tables ***/


IF OBJECT_ID('tempdb..#tmp_Broker') IS NOT NULL
	DROP TABLE #tmp_Broker

SELECT 
	 CRMBrokerLinkId = T.CRMBrokerLinkId
	,PK_CRMBroker	 = T.PK_CRMBroker
INTO #tmp_Broker 
FROM
	(
		SELECT
			 PK_CRMBroker		= b.PK_CRMBroker
			,CRMBrokerLinkId	= b.CRMBrokerLinkId
			,SequenceId			= ROW_NUMBER() OVER(PARTITION BY b.CRMBrokerLinkId ORDER BY b.HierarchyLevel DESC, b.PK_CRMBroker ASC) --Tie breaker
		FROM 
			ODS.CRMBroker b
		WHERE
			b.CRMBrokerLinkId IS NOT NULL
	) AS T
WHERE
	T.SequenceId = 1;


IF OBJECT_ID('tempdb..#tmp_Underwriter') IS NOT NULL
	DROP TABLE #tmp_Underwriter

SELECT
	MatlockKey		= unw.MatlockKey, 
	PK_Underwriter	= ods_unw.PK_Underwriter
INTO #tmp_Underwriter
FROM
	Staging_Matlock.Matlock_Staging.vw_Underwriter unw
	LEFT OUTER JOIN 
	(
		SELECT
			 PK_Underwriter	 = MAX(u.PK_Underwriter) 
			,UnderwriterName = u.UnderwriterName
		FROM 
			ODS.Underwriter u
		GROUP BY	
			u.UnderwriterName
	) 
	AS ods_unw
	ON ods_unw.UnderwriterName = unw.Name;


IF OBJECT_ID('tempdb..#tmp_PartyInsured') IS NOT NULL
	DROP TABLE #tmp_PartyInsured

SELECT 					 
	 SourceSystemId	 = CONVERT(int, pins.SourceSystemId)
	,PK_PartyInsured = pins.PK_PartyInsured
INTO #tmp_PartyInsured
FROM 
	ODS.PartyInsured as pins
WHERE 
	pins.SourceSystem = 'BeazleyPro';


IF OBJECT_ID('tempdb..#tmp_ExtensionColumns') IS NOT NULL
	DROP TABLE #tmp_ExtensionColumns

;WITH 
tria AS
(	
	SELECT
		 RiskId					= qws.RiskId
		,QuoteId				= qws.Id			
		,TRIA					= qws.TriaSelected		
		,BenchmarkPremium		= qo.BenchmarkPremium
		,BenchmarkPriceIndex	= qo.BenchmarkPriceIndex 
		,UnityPremium			= qo.UnityPremium
		,UnityRateChange		= qo.UnityRateChange			
		,ExpiringPremium		= qws.ExpiringPremium											  
		,ExpiringUnityPremium	= qws.ExpiringUnityPremium
		,SequenceId				= ROW_NUMBER() OVER (PARTITION BY qws.RiskId
													 ORDER BY
														CASE qor.[Status]
															WHEN 'Bound'	THEN 1 
															WHEN 'PreBind'	THEN 2
															WHEN 'Quoting'	THEN 3
															WHEN 'Indicated' THEN 4
															WHEN 'NTU'		THEN 5
															WHEN 'Unquoted' THEN 6
															WHEN 'Rating'	THEN 7
															WHEN 'Created'  THEN 8
															ELSE 9                                                                      
														END ASC,

														qws.Id DESC,

														CASE qoor.[Status]
															WHEN 'Bound'  THEN 1 
															WHEN 'PreBind'THEN 2
															WHEN 'Quoted' THEN 3
															WHEN 'NTU'    THEN 4
															WHEN 'Unset'  THEN 5
															ELSE 6 
														END ASC,

														qo.Premium DESC,
														qo.ID DESC)
	FROM 
		Staging_Matlock.Matlock_Staging.vw_QuoteWorksheet qws
		INNER JOIN 
		Staging_Matlock.Matlock_Staging.vw_QuoteWorksheetOnRisk qor
		ON qws.[Id] = qor.QuoteWorksheetId
		LEFT OUTER JOIN 
		Staging_Matlock.Matlock_Staging.vw_QuoteOption qo
		ON qo.QuoteWorksheetKey = qws.MatlockKey
		LEFT OUTER JOIN 
		Staging_Matlock.Matlock_Staging.vw_QuoteOptionOnRisk qoor
		ON qo.[Id] = qoor.QuoteOptionId
),
poi AS
(	
	SELECT 
		 RiskID					= qws.RiskId
		,QuoteId				= qws.Id			
		,PeriodOfInsuranceFrom	= qws.PeriodOfInsuranceFrom
		,SequenceId				= ROW_NUMBER() OVER (PARTITION BY qws.RiskId 
													 ORDER BY
														CASE qor.[Status]
															WHEN 'Bound'		THEN 1 
															WHEN 'PreBind'		THEN 2
															WHEN 'Quoting'		THEN 3
															WHEN 'Indicated'	THEN 4
															WHEN 'NTU'			THEN 5
															WHEN 'Unquoted'		THEN 6
															WHEN 'Rating'		THEN 7
															WHEN 'Created'		THEN 8
															ELSE 9 
														END ASC 
														, qor.QuoteWorksheetId DESC)
	FROM 
		Staging_Matlock.Matlock_Staging.vw_QuoteWorksheetOnRisk qor
		INNER JOIN 
		Staging_Matlock.Matlock_Staging.vw_QuoteWorksheet qws
		ON qws.[Id] = qor.QuoteWorksheetId
	WHERE
		qws.PeriodOfInsuranceFrom IS NOT NULL
)
SELECT 
	 RiskID					= ISNULL(T1.RiskId, T2.RiskID)
	,QuoteId				= ISNULL(T1.QuoteId, T2.QuoteId)
	,TRIA					= T1.TRIA		
	,BenchmarkPremium		= T1.BenchmarkPremium
	,BenchmarkPriceIndex	= T1.BenchmarkPriceIndex
	,UnityPremium			= T1.UnityPremium
	,UnityRateChange		= T1.UnityRateChange
	,ExpiringPremium		= T1.ExpiringPremium
	,ExpiringUnityPremium	= T1.ExpiringUnityPremium
	,PeriodOfInsuranceFrom	= T2.PeriodOfInsuranceFrom

INTO #tmp_ExtensionColumns
FROM (
		SELECT
			 RiskId					= x.RiskId	
			,QuoteId				= x.QuoteId			
			,TRIA					= x.TRIA
			,BenchmarkPremium		= x.BenchmarkPremium
			,BenchmarkPriceIndex	= x.BenchmarkPriceIndex
			,UnityPremium			= x.UnityPremium
			,UnityRateChange		= x.UnityRateChange
			,ExpiringPremium		= x.ExpiringPremium
			,ExpiringUnityPremium	= x.ExpiringUnityPremium
		FROM
			 tria AS x
		WHERE
			x.SequenceId = 1
	) T1
	FULL JOIN 
	(
		SELECT
			 RiskID					= y.RiskID
			,QuoteId				= y.QuoteId			
			,PeriodOfInsuranceFrom	= y.PeriodOfInsuranceFrom
		FROM
			poi AS y
		WHERE
			y.SequenceId = 1
	) T2 
	ON T2.RiskID = T1.RiskId;


IF OBJECT_ID('tempdb..#tmp_Submission') IS NOT NULL
	DROP TABLE #tmp_Submission

CREATE TABLE #tmp_Submission
(
	[SubmissionSourceId] [varchar](255) NULL,
	[IsUnknownMember] [bit] DEFAULT ((0)) NULL,
	[SubmissionStatus] [nvarchar](255) NULL,
	[SubmissionDate] [datetime] NULL,
	[ClearedDate] [datetime] NULL,
	[WasMigrated] [bit] NULL,
	[RiskStatus] [nvarchar](255) NULL,
	[ClearedProductName] [nvarchar](255) NULL,
	[MarketSegment] [nvarchar](255) NULL,
	[MarketSegmentCode] [nvarchar](255) NULL,
	[FK_CRMBroker] [bigint]  NULL,
	[FK_PartyInsured] [bigint] NULL,
	[FK_Underwriter] [bigint] NULL,
	[FK_ClearedClassOfBusiness] [bigint] NULL,
	[ExpiringSubmissionId] [int] NULL,
	[PolicyNumber] [nvarchar](255) NULL,
	[MatlockKey] [nvarchar](255) NULL,
	[LineOfBusiness] [nvarchar](255) NULL,
	[ClearedInsuranceStructure] [nvarchar](255) NULL,
	[ParentAccountNumber] [nvarchar](255) NULL,
    [ParentAccountName] [nvarchar](350) NULL,
	[AccountNumber] [nvarchar](255) NULL,
	[AccountName] [nvarchar](350) NULL,
	[AccountAddress] [nvarchar](255) NULL,
	[AccountCity] [nvarchar](255) NULL,
	[AccountState] [nvarchar](255) NULL,
	[AccountZipCode] [nvarchar](255) NULL,
	[BrokerGroupName] [nvarchar](255) NULL,
	[BrokerName] [nvarchar](255) NULL,
	[BrokerCity] [nvarchar](255) NULL,
	[BrokerState] [nvarchar](255) NULL,
	[BrokerZipCode] [nvarchar](255) NULL,
	[BrokerContactName] [nvarchar](255) NULL,
	[BrokerContactEmail] [nvarchar](255) NULL,
	[BrokerLinkId] [nvarchar](255) NULL,
	[BrokerLicenseNumber] [nvarchar](255) NULL,
	[NewJerseyTransactionCode] [nvarchar](255) NULL,
	[SubmittingBrokerSnapshotKeyFlag] [bit] NULL,
	[SubmittingBrokerGroupName] [nvarchar](255) NULL,
	[SubmittingBrokerName] [nvarchar](255) NULL,
	[SubmittingBrokerCity] [nvarchar](255) NULL,
	[SubmittingBrokerState] [nvarchar](255) NULL,
	[SubmittingBrokerZipCode] [nvarchar](255) NULL,
	[SubmittingBrokerContactName] [nvarchar](255) NULL,
	[SubmittingBrokerContactEmail] [nvarchar](255) NULL,
	[SubmittingBrokerLinkId] [nvarchar](255) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedUser] [nvarchar](255) NULL,
	[RatedDate] [datetime] NULL,
	[RatedUser] [nvarchar](255) NULL,
	[QuotedDate] [datetime] NULL,
	[QuotedUser] [nvarchar](255) NULL,
	[BindDate] [datetime] NULL,
	[BindUser] [nvarchar](255) NULL,
	[IssuedDate] [datetime] NULL,
	[IssuedUser] [nvarchar](255) NULL,
	[CancellationDate] [datetime] NULL,
	[CancellationUser] [nvarchar](255) NULL,
	[DeclinationDate] [datetime] NULL,
	[DeclinationUser] [nvarchar](255) NULL,
	[NTUDate] [datetime] NULL,
	[NTUUser] [nvarchar](255) NULL,
	[RunOffDate] [datetime] NULL,
	[LastModifiedDate] [datetime] NULL,
	[LastModifiedUser] [nvarchar](255) NULL,
	[ClearedCoverages] [nvarchar](255) NULL,
	[UnderwriterProductCode] [nvarchar](255) NULL,
	[RiskCode] [nvarchar](255) NULL,
	[TRIA] [bit] NULL,
	[BenchmarkPremium] [decimal](38,4) NULL,
	[BenchmarkPriceIndex] [decimal](19, 12) NULL,
	[UnderwriterRateChange] [decimal](19,12) NULL,
	[UnityPremium] [decimal](19, 4) NULL,
	[UnityRateChange] [decimal](19, 12) NULL,
	[ExpiringPremium] [decimal](19, 4) NULL,
	[ExpiringUnityPremium] [decimal](19, 4) NULL,
	[RateChangeMethodToUse] [nvarchar](255) NULL,
	[EffectiveDate] [datetime] NULL,
	[SourceSystemName] [nvarchar] (255) NULL
)

INSERT INTO #tmp_Submission
(
	[SubmissionSourceId]
	,[SubmissionStatus]
	,[SubmissionDate]
	,[ClearedDate]
	,[WasMigrated]
	,[RiskStatus]
	,[ClearedProductName]
	,[MarketSegment]
	,[MarketSegmentCode]
	,[FK_CRMBroker]
	,[FK_PartyInsured]
	,[FK_Underwriter]
	,[FK_ClearedClassOfBusiness]
	,[ExpiringSubmissionId]
	,[PolicyNumber]
	,[MatlockKey]
	,[LineOfBusiness]
	,[ClearedInsuranceStructure]
	,[ParentAccountNumber]
    ,[ParentAccountName]
	,[AccountNumber]
	,[AccountName]
	,[AccountAddress]
	,[AccountCity]
	,[AccountState]
	,[AccountZipCode]
	,[BrokerGroupName]
	,[BrokerName]
	,[BrokerCity]
	,[BrokerState]
	,[BrokerZipCode]
	,[BrokerContactName]
	,[BrokerContactEmail]
	,[BrokerLinkId]
	,[BrokerLicenseNumber]
	,[NewJerseyTransactionCode]
	,[SubmittingBrokerSnapshotKeyFlag]
	,[SubmittingBrokerGroupName]
	,[SubmittingBrokerName]
	,[SubmittingBrokerCity]
	,[SubmittingBrokerState]
	,[SubmittingBrokerZipCode]
	,[SubmittingBrokerContactName]
	,[SubmittingBrokerContactEmail]
	,[SubmittingBrokerLinkId]
	,[CreatedDate]
	,[CreatedUser]
	,[RatedDate]
	,[RatedUser]
	,[QuotedDate]
	,[QuotedUser]
	,[BindDate]
	,[BindUser]
	,[IssuedDate]
	,[IssuedUser]
	,[CancellationDate]
	,[CancellationUser]
	,[DeclinationDate]
	,[DeclinationUser]
	,[NTUDate]
	,[NTUUser]
	,[RunOffDate]
	,[LastModifiedDate]
	,[LastModifiedUser]
	,[ClearedCoverages]
	,[UnderwriterProductCode]
	,[RiskCode]
	,[TRIA]
	,[BenchmarkPremium]
	,[BenchmarkPriceIndex]
	,[UnderwriterRateChange]
	,[UnityPremium]
	,[UnityRateChange]
	,[ExpiringPremium]
	,[ExpiringUnityPremium]
	,[RateChangeMethodToUse]
	,[EffectiveDate]
	,[SourceSystemName]
)
SELECT
	SubmissionSourceId					= r.Id
	-- Submission only
	,SubmissionStatus					= s.[Status]		
	,SubmissionDate						= s.SubmissionDate
	,ClearedDate						= s.PowerSearchClearedDate
	,WasMigrated						= ISNULL(s.WasMigrated,0)	
	,RiskStatus							= r.State_Name
	,ClearedProductName					= r.ClearedProductName
	,MarketSegment						= m.[Description]
	,MarketSegmentCode					= m.[Name]
	,FK_CRMBroker						= ISNULL(ods_b.PK_CRMBroker,0)
	,FK_PartyInsured					= ISNULL(ods_a.PK_PartyInsured,0)
	,FK_Underwriter						= ISNULL(unw.PK_Underwriter,0)
	,FK_ClearedClassOfBusiness			= ISNULL(ods_c.PK_ClassOfBusiness, 0)
	,ExpiringSubmissionId				= res.Id
	-- SubmissionExtension only
	-- #BeazleyProAccount
	,PolicyNumber						= ISNULL(p.PolicyNumber, exc.QuoteId) --p.PolicyNumber --
	,MatlockKey							= r.MatlockKey
	,LineOfBusiness						= COALESCE(p.ProductLineOfBusiness,r.ClearedProductLineOfBusiness)
	,ClearedInsuranceStructure			= CASE WHEN r.IsPrimary = 1 THEN 'Primary' ELSE 'Excess' END
	,ParentAccountNumber                = ISNULL(a2.AccountId,a.AccountId)
    ,ParentAccountName                  = ISNULL(a2.Name,a.Name)
	,AccountNumber						= a.AccountId
	,AccountName						= a.Name
	,AccountAddress						= LEFT(ISNULL(a.Line1,'') + ' ' + ISNULL(a.Line2,'') + ' ' + ISNULL(a.Line3,''), 255)
	,AccountCity						= a.City
	,AccountState						= a.[State]
	,AccountZipCode						= a.ZipCode   
	 -- #BeazleyProBroker	
	,BrokerGroupName					= COALESCE(bror.BrokerName, pr.BrokerName) --COALESCE(pr.BrokerName,bror.BrokerName)
	,BrokerName							= COALESCE(bror.BranchName, pr.BranchName) --COALESCE(pr.BranchName,bror.BranchName)
	,BrokerCity							= COALESCE(bror.City, pr.City) --COALESCE(pr.City,bror.City)
	,BrokerState						= COALESCE(bror.[State], pr.[State]) --COALESCE(pr.[State],bror.[State])
	,BrokerZipCode						= COALESCE(bror.ZipCode, pr.ZipCode) --COALESCE(pr.ZipCode,bror.ZipCode)
	,BrokerContactName					= COALESCE(bror.ContactName, pr.ContactName) --COALESCE(pr.ContactName,bror.ContactName)
	,BrokerContactEmail					= bror.ContactEmail
	,BrokerLinkId						= COALESCE(bror.BrokerBeazleyTradeId, pr.BrokerBeazleyTradeId) --COALESCE(pr.BrokerBeazleyTradeId,bror.BrokerBeazleyTradeId) --?
	,BrokerLicenseNumber				= pr.LicenseNumber
	,NewJerseyTransactionCode			= ISNULL(CAST(r.NewJerseyTransactionCode as [nvarchar](255)),'')
	-- #BeazleyProSubmittingBroker
	,SubmittingBrokerSnapshotKeyFlag	= CASE WHEN r.SubmittingBrokerSnapshotKey IS NULL THEN 0 ELSE 1 END
	,SubmittingBrokerGroupName			= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.BrokerName, pr.BrokerName) --COALESCE(pr.BrokerName,bror.BrokerName)
											ELSE COALESCE(bs.BrokerName, pr.Submitting_BrokerName) --COALESCE(pr.Submitting_BrokerName,bs.BrokerName)
										  END
	,SubmittingBrokerName				= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.BranchName, pr.BranchName) --COALESCE(pr.BranchName,bror.BranchName)
											ELSE COALESCE(bs.BranchName, pr.Submitting_BranchName) --COALESCE(pr.Submitting_BranchName, bs.BranchName) 
										  END

	,SubmittingBrokerCity				= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.City, pr.City) --COALESCE(pr.City, bror.City)
											ELSE COALESCE(bs.City, pr.Submitting_City) --COALESCE(pr.Submitting_City, bs.City) 
										  END
									  
	,SubmittingBrokerState				= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.[State], pr.[State]) --COALESCE(pr.[State], bror.[State])
											ELSE COALESCE(bs.[State], pr.Submitting_State) --COALESCE(pr.Submitting_State, bs.[State])
										  END
									 
	,SubmittingBrokerZipCode			= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.ZipCode, pr.ZipCode) --COALESCE(pr.ZipCode, bror.ZipCode)
											ELSE COALESCE(bs.ZipCode, pr.Submitting_ZipCode) --COALESCE(pr.Submitting_ZipCode, bs.ZipCode)
										  END										

	,SubmittingBrokerContactName		= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.ContactName, pr.ContactName) --COALESCE(pr.ContactName, bror.ContactName)
											ELSE COALESCE(bs.ContactName, pr.Submitting_ContactName) --COALESCE(pr.Submitting_ContactName, bs.ContactName) 
										  END
	,SubmittingBrokerContactEmail		= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN bror.ContactEmail
											ELSE bs.ContactEmail
										  END
	,SubmittingBrokerLinkId  			= CASE 
											WHEN (r.SubmittingBrokerSnapshotKey IS NULL)
											THEN COALESCE(bror.BrokerBeazleyTradeId, pr.BrokerBeazleyTradeId) --COALESCE(pr.BrokerBeazleyTradeId, bror.BrokerBeazleyTradeId)
											ELSE COALESCE(bs.BrokerBeazleyTradeId, pr.Submitting_BrokerBeazleyTradeId) --COALESCE(pr.Submitting_BrokerBeazleyTradeId, bs.BrokerBeazleyTradeId)
										  END
	-- vw_RiskHistory
	,CreatedDate						= rh.CreatedDate
	,CreatedUser						= rh.CreatedUser
	,RatedDate							= rh.RatedDate
	,RatedUser							= rh.RatedUser
	,QuotedDate							= rh.QuotedDate
	,QuotedUser							= rh.QuotedUser
	,BindDate							= rh.BindDate
	,BindUser							= rh.BindUser
	,IssuedDate							= rh.IssuedDate
	,IssuedUser							= rh.IssuedUser
	,CancellationDate					= rh.CancellationDate
	,CancellationUser					= rh.CancellationUser
	,DeclinationDate					= rh.DeclinationDate
	,DeclinationUser					= rh.DeclinationUser
	,NTUDate							= rh.NTUDate
	,NTUUser							= rh.NTUUser
	,RunOffDate							= rh.RunoffDate
	,LastModifiedDate					= rh.LastModifiedDate
	,LastModifiedUser					= rh.LastModifiedUser
	,ClearedCoverages					= rh.ClearedCoverages
	-- TRIA and BeazleyPro Premiums
	,UnderwriterProductCode				= p.UnderwriterProductCode
	,RiskCode							= p.LloydsRiskCode
	,TRIA								= COALESCE(pr.TriaSelected, exc.TRIA)
	,BenchmarkPremium					= COALESCE(pr.BenchmarkPremium,exc.BenchmarkPremium)
	,BenchmarkPriceIndex				= COALESCE(pr.BenchmarkPriceIndex,exc.BenchmarkPriceIndex)
	,UnderwriterRateChange				= pr.UnderwriterRateChange_RateChange
	,UnityPremium						= COALESCE(pr.UnityPremium,exc.UnityPremium)
	,UnityRateChange					= COALESCE(pr.UnityRateChange,exc.UnityRateChange)			
	,ExpiringPremium					= COALESCE(pr.ExpiringPremium,exc.ExpiringPremium)
	,ExpiringUnityPremium				= COALESCE(pr.ExpiringUnityPremium,exc.ExpiringUnityPremium)
	,RateChangeMethodToUse				= pr.RateChangeMethodToUse
	-- Effective Date
	,EffectiveDate						= COALESCE(pr.PeriodOfInsuranceFrom, exc.PeriodOfInsuranceFrom, r.PeriodOfInsuranceFrom)
	-- General
	,SourceSystemName					= 'BeazleyPro'
FROM
	Staging_Matlock.Matlock_Staging.vw_Submission s
	INNER JOIN
	Staging_Matlock.Matlock_Staging.vw_Account a ON
	s.AccountId = a.MatlockKey
	LEFT JOIN
    Staging_Matlock.Matlock_Staging.vw_Account a2 ON
    a.ParentAccount = a2.MatlockKey
	INNER JOIN
	#tmp_PartyInsured ods_a ON
	a.AccountId = ods_a.SourceSystemId 
	INNER JOIN  Staging_Matlock.Matlock_Staging.vw_Risk r ON  
	s.MatlockKey = r.SubmissionId
	INNER JOIN 
	#tmp_Underwriter unw ON 
	R.UnderwriterId = unw.MatlockKey	
	INNER JOIN 
	Staging_Matlock.Matlock_Staging.vw_Market m ON 
	m.MatlockKey = r.MarketId
	--------------------------------------------------------------
	-- #BeazleyProAccount
	LEFT OUTER JOIN Staging_Matlock.Matlock_Staging.vw_Policy p
	ON r.MatlockKey = p.RiskId
	--------------------------------------------------------------
	-- #BeazleyProBroker & #BeazleyProSubmittingBroker
	LEFT OUTER JOIN Staging_Matlock.Matlock_Staging.vw_BrokerSnapshot bror
	ON r.BrokerSnapshotKey = bror.MatlockKey
	LEFT OUTER JOIN Staging_Matlock.Matlock_Staging.vw_PolicyRecord pr
	ON pr.MatlockKey = p.CurrentPolicyRecordId
	LEFT JOIN 
	Staging_Matlock.Matlock_Staging.vw_BrokerSnapshot bs 
	ON r.SubmittingBrokerSnapshotKey = bs.MatlockKey
	--------------------------------------------------------------
	-- vw_RiskHistory
	LEFT OUTER JOIN Staging_Matlock.Matlock_Staging.vw_RiskHistory rh
	ON r.Id = rh.RiskId	
	--------------------------------------------------------------
	/*Use the Hierarchy Level field to find the lowest level in the hierarchy of the broker id*/
	LEFT OUTER JOIN
	#tmp_Broker ods_b ON
	cast(bs.BranchBeazleyTradeId as nvarchar(255)) = ods_b.CRMBrokerLinkId
	LEFT OUTER JOIN  
	Staging_Matlock.Matlock_Staging.vw_Product prd ON 
	prd.Id = r.ClearedProductId
	LEFT OUTER JOIN 
	Staging_Matlock.Matlock_Staging.vw_CobCode cob ON 
	cob.MatlockKey = prd.CobCodeId
	LEFT OUTER JOIN
	ODS.ClassOfBusiness ods_c ON
	cob.Code= ods_c.ClassOfBusinessCode
	--------------------------------------------------------------
	-- TRIA and BeazleyPro Premiums
	-- EffectiveDate
	LEFT OUTER JOIN 
	#tmp_ExtensionColumns as exc
	ON exc.RiskID = r.Id
	--------------------------------------------------------------
	-- ExpiringSubmissionId
	LEFT JOIN
	Staging_Matlock.Matlock_Staging.vw_Risk res 
	ON res.MatlockKey = ISNULL(r.RenewalOfRisk_RenewalOfRiskId, r.RetentionOfRisk_RetentionOfRiskId)
	WHERE TRY_CAST(ISNULL([UnderwriterRateChange_RateChange], 0) AS DECIMAL(19,12)) IS NOT NULL;


-- Insight
INSERT INTO #tmp_Submission
(
	SourceSystemName
	,SubmissionSourceId
	,ClearedDate
	,FK_ClearedClassOfBusiness
	,FK_CRMBroker
	,FK_PartyInsured
	,FK_Underwriter
	,ClearedProductName
	,LineOfBusiness
	,MarketSegmentCode
	,SubmissionStatus	
	,SubmissionDate
	,WasMigrated
)
SELECT
	SourceSystemName					= s.SourceSystem
	,SubmissionSourceId					= s.SubmissionSourceId
	,ClearedDate						= se.ClearedDate
	,FK_ClearedClassOfBusiness			= ISNULL(ods_c.PK_ClassOfBusiness, 0)
	,FK_CRMBroker						= ISNULL(ods_crm.PK_CRMBroker,0)
	,FK_PartyInsured					= ISNULL(ods_p.PK_PartyInsured,0)
	,FK_Underwriter						= ISNULL(ods_u.PK_Underwriter,0)
	,ClearedProductName					= se.ClearedProductName
	,LineOfBusiness						= se.ClearedClassOfBusiness
	,MarketSegmentCode					= s.MarketSegmentCode
	,SubmissionStatus					= s.SubmissionStatus		
	,SubmissionDate						= s.SubmissionDate		
	,WasMigrated						= ISNULL(se.WasMigrated,0)								
FROM BeazleyIntelligenceDataContract.Outbound.vw_Submission s
JOIN BeazleyIntelligenceDataContract.Outbound.vw_SubmissionExtension se
	ON s.SourceSystem = se.SourceSystem
	AND s.SubmissionSourceId = se.SubmissionSourceId
LEFT JOIN ODS.ClassOfBusiness ods_c 
	ON se.ClearedClassOfBusiness = ods_c.ClassOfBusinessCode
LEFT JOIN ODS.CRMBroker ods_crm
	ON s.BrokerName = ods_crm.BrokerName AND ISNULL(se.BrokerCity, '') = ISNULL(ods_crm.BrokerCity,'')
LEFT JOIN 
(	SELECT
		PK_PartyInsured	 = MAX(PK_PartyInsured) 
		,InsuredName = InsuredName
	FROM 
		ODS.PartyInsured
	GROUP BY	
		InsuredName
)
 ods_p
	ON s.InsuredName = ods_p.InsuredName
LEFT JOIN 
(
	SELECT
		PK_Underwriter	 = MAX(u.PK_Underwriter) 
		,UnderwriterName = u.UnderwriterName
	FROM 
		ODS.Underwriter u
	GROUP BY	
		u.UnderwriterName
) AS ods_u
	ON s.UnderwriterName = ods_u.UnderwriterName
WHERE (
	   s.SourceSystem = 'Insight' 
       AND LTRIM(RTRIM(s.SourceSystemLocation)) = 'UK'    
	   --OR s.SourceSystem = 'CIPS'
	   )
	--AND s.IsActive = 1

/*** END of the area for helper tables ***/

DELETE s
FROM  ODS.Submission s
WHERE 
   FK_Underwriter  NOT IN (SELECT DISTINCT PK_Underwriter FROM ODS.Underwriter )
OR FK_PartyInsured NOT IN (SELECT DISTINCT PK_PartyInsured FROM ODS.PartyInsured )
OR FK_CRMBroker    NOT IN (SELECT DISTINCT PK_CRMBroker FROM ODS.CRMBroker )

MERGE [ODS].[Submission] target
USING
(
SELECT
	 IsUnknownMember			= t.IsUnknownMember			
	,SubmissionSourceId			= t.SubmissionSourceId
	,SubmissionStatus			= t.SubmissionStatus
	,SubmissionDate				= t.SubmissionDate			
	,ClearedDate				= t.ClearedDate	
	,WasMigrated				= t.WasMigrated
	,RiskStatus					= t.RiskStatus
	,ClearedProductName			= t.ClearedProductName
	,MarketSegment				= t.MarketSegment
	,MarketSegmentCode			= t.MarketSegmentCode
	,FK_CRMBroker				= t.FK_CRMBroker
	,FK_PartyInsured			= t.FK_PartyInsured
	,FK_Underwriter				= t.FK_Underwriter
	,FK_ClearedClassOfBusiness	= t.FK_ClearedClassOfBusiness
	--,FK_ExpiringSubmission		= t.FK_ExpiringSubmission
	,SourceSystemName			= t.SourceSystemName
FROM
	(
		SELECT
		     IsUnknownMember			= tmp.IsUnknownMember
			,SubmissionSourceId			= tmp.SubmissionSourceId
			,SubmissionStatus			= tmp.SubmissionStatus
			,SubmissionDate				= tmp.SubmissionDate			
			,ClearedDate				= tmp.ClearedDate	
			,WasMigrated				= tmp.WasMigrated
			,RiskStatus					= tmp.RiskStatus
			,ClearedProductName			= tmp.ClearedProductName
			,MarketSegment				= tmp.MarketSegment
			,MarketSegmentCode			= tmp.MarketSegmentCode
			,FK_CRMBroker				= tmp.FK_CRMBroker
			,FK_PartyInsured			= tmp.FK_PartyInsured
			,FK_Underwriter				= tmp.FK_Underwriter
			,FK_ClearedClassOfBusiness	= tmp.FK_ClearedClassOfBusiness
			-- Eyes wide open on this trick, below we will actually set the real FK value; 
			-- I am doing this to avoid using the [Utility].[udf_ComputeIdentity] function and also because this column is empty at this moment
		--	,FK_ExpiringSubmission		= tmp.ExpiringSubmissionId
			,SourceSystemName			= tmp.SourceSystemName
			,RowId = ROW_NUMBER() OVER (PARTITION BY tmp.SubmissionSourceId order by SubmissionDate, tmp.SourceSystemName, tmp.ExpiringSubmissionId, tmp.ClearedDate)
		FROM #tmp_Submission as tmp
	) as t
	where t.RowId= 1

	UNION ALL
		-- Unknown member Submission
	SELECT
		 IsUnknownMember			= 1
		,SubmissionSourceId         = '0'
		,SubmissionStatus		    = 'N/A'
		,SubmissionDate			    = '1753-01-01'
		,ClearedDate				= '1753-01-01'
		,WasMigrated			    = 0   
		,RiskStatus				    = NULL	
		,ClearedProductName			= NULL
		,MarketSegment				= NULL
		,MarketSegmentCode			= NULL
		,FK_CRMBroker               = 0
		,FK_PartyInsured            = 0
		,FK_Underwriter             = 0
		,FK_ClearedClassOfBusiness  = 0
		--,FK_ExpiringSubmission	    = NULL
		,SourceSystemName			= 'N/A'		
) source
ON  target.SubmissionSourceId   = source.SubmissionSourceId
AND target.IsUnknownMember      = source.IsUnknownMember

WHEN MATCHED THEN 
UPDATE 
SET 
 target.SubmissionStatus			= source.SubmissionStatus
,target.SubmissionDate				= source.SubmissionDate			
,target.ClearedDate				    = source.ClearedDate	
,target.WasMigrated				    = source.WasMigrated
,target.RiskStatus					= source.RiskStatus
,target.ClearedProductName			= source.ClearedProductName
,target.MarketSegment				= source.MarketSegment
,target.MarketSegmentCode			= source.MarketSegmentCode
,target.FK_CRMBroker				= source.FK_CRMBroker
,target.FK_PartyInsured			    = source.FK_PartyInsured
,target.FK_Underwriter				= source.FK_Underwriter
,target.FK_ClearedClassOfBusiness	= source.FK_ClearedClassOfBusiness
--,target.FK_ExpiringSubmission		= source.FK_ExpiringSubmission
,target.SourceSystemName			= source.SourceSystemName
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadSubmission] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
 IsUnknownMember
,SubmissionSourceId			
,SubmissionStatus			
,SubmissionDate				
,ClearedDate				
,WasMigrated				
,RiskStatus					
,ClearedProductName			
,MarketSegment				
,MarketSegmentCode			
,FK_CRMBroker				
,FK_PartyInsured			
,FK_Underwriter				
,FK_ClearedClassOfBusiness	
--,FK_ExpiringSubmission		
,SourceSystemName			
,AuditCreateDateTime   
,AuditModifyDetails 
)
VALUES
(
 source.IsUnknownMember
,source.SubmissionSourceId			
,source.SubmissionStatus			
,source.SubmissionDate				
,source.ClearedDate				
,source.WasMigrated				
,source.RiskStatus					
,source.ClearedProductName			
,source.MarketSegment				
,source.MarketSegmentCode			
,source.FK_CRMBroker				
,source.FK_PartyInsured			
,source.FK_Underwriter				
,source.FK_ClearedClassOfBusiness	
--,source.FK_ExpiringSubmission		
,source.SourceSystemName			
,GETDATE()
,'New add in [ODS].[usp_LoadSubmission] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;


	
-- Set expiring key 
----

UPDATE [ODS].[Submission] 
SET
 
	FK_ExpiringSubmission = IIF(se.IsUnknownMember = 1,0,ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(upper(se.[SubmissionSourceId])))),(0))) 
FROM
	(
SELECT
	 SubmissionSourceId			= t.SubmissionSourceId
	,FK_ExpiringSubmission		= t.FK_ExpiringSubmission
	,SourceSystemName			= t.SourceSystemName

FROM
	(
		SELECT
			 SubmissionSourceId			= tmp.SubmissionSourceId
			 
			,FK_ExpiringSubmission		= tmp.ExpiringSubmissionId
			,SourceSystemName			= tmp.SourceSystemName
			,RowId = ROW_NUMBER() OVER (PARTITION BY tmp.SubmissionSourceId order by SubmissionDate, tmp.SourceSystemName, tmp.ExpiringSubmissionId, tmp.ClearedDate)
		FROM #tmp_Submission as tmp
	) as t
	where t.RowId = 1) s	
	
	INNER JOIN
	(SELECT
	 SubmissionSourceId			= t.SubmissionSourceId
	 ,IsUnknownMember
	,FK_ExpiringSubmission		= t.FK_ExpiringSubmission
	,SourceSystemName			= t.SourceSystemName

FROM
	(
		SELECT
			 SubmissionSourceId			= tmp.SubmissionSourceId
			,IsUnknownMember
			,FK_ExpiringSubmission		= tmp.ExpiringSubmissionId
			,SourceSystemName			= tmp.SourceSystemName
			,RowId = ROW_NUMBER() OVER (PARTITION BY tmp.SubmissionSourceId order by SubmissionDate, tmp.SourceSystemName, tmp.ExpiringSubmissionId, tmp.ClearedDate)
		FROM #tmp_Submission as tmp
	) as t
	where t.RowId = 1) se 
	ON 
	-- remember the trick above, in the insert, where we set FK_ExpiringSubmission = ExpiringSubmissionId, so that we can use this column in the join condition
	s.FK_ExpiringSubmission = se.SubmissionSourceId
	AND s.SourceSystemName = se.SourceSystemName
	AND s.SourceSystemName = 'BeazleyPro'
	
	INNER JOIN ODS.Submission ods
	ON  ods.SubmissionSourceId   = se.SubmissionSourceId
	AND ods.IsUnknownMember      = se.IsUnknownMember

--

--START DQM:  saving bad data for DQM to handle

--TRUNCATE TABLE Staging.DQ_Submission
--INSERT INTO Staging.DQ_Submission
MERGE [Staging].[DQ_Submission] target
USING
(
SELECT
	 SubmissionSourceId			= t.SubmissionSourceId
	,SubmissionStatus			= t.SubmissionStatus
	,SubmissionDate				= t.SubmissionDate			
	,ClearedDate				= t.ClearedDate	
	,WasMigrated				= t.WasMigrated
	,RiskStatus					= t.RiskStatus
	,ClearedProductName			= t.ClearedProductName
	,MarketSegment				= t.MarketSegment
	,MarketSegmentCode			= t.MarketSegmentCode
	,FK_CRMBroker				= t.FK_CRMBroker
	,FK_PartyInsured			= t.FK_PartyInsured
	,FK_Underwriter				= t.FK_Underwriter
	,FK_ClearedClassOfBusiness	= t.FK_ClearedClassOfBusiness
	,FK_ExpiringSubmission		= t.FK_ExpiringSubmission
	,SourceSystemName			= t.SourceSystemName

FROM
	(
		SELECT
			 SubmissionSourceId			= tmp.SubmissionSourceId
			,SubmissionStatus			= tmp.SubmissionStatus
			,SubmissionDate				= tmp.SubmissionDate			
			,ClearedDate				= tmp.ClearedDate	
			,WasMigrated				= tmp.WasMigrated
			,RiskStatus					= tmp.RiskStatus
			,ClearedProductName			= tmp.ClearedProductName
			,MarketSegment				= tmp.MarketSegment
			,MarketSegmentCode			= tmp.MarketSegmentCode
			,FK_CRMBroker				= tmp.FK_CRMBroker
			,FK_PartyInsured			= tmp.FK_PartyInsured
			,FK_Underwriter				= tmp.FK_Underwriter
			,FK_ClearedClassOfBusiness	= tmp.FK_ClearedClassOfBusiness
			,FK_ExpiringSubmission		= tmp.ExpiringSubmissionId
			,SourceSystemName			= tmp.SourceSystemName
			,RowId = ROW_NUMBER() OVER (PARTITION BY tmp.SubmissionSourceId order by SubmissionDate, tmp.SourceSystemName, tmp.ExpiringSubmissionId, tmp.ClearedDate)
		FROM #tmp_Submission as tmp
	) as t
	where t.RowId > 1
) source
ON  target.SubmissionSourceId   = source.SubmissionSourceId
WHEN MATCHED THEN 
UPDATE 
SET 
 target.SubmissionStatus			= source.SubmissionStatus
,target.SubmissionDate				= source.SubmissionDate			
,target.ClearedDate				    = source.ClearedDate	
,target.WasMigrated				    = source.WasMigrated
,target.RiskStatus					= source.RiskStatus
,target.ClearedProductName			= source.ClearedProductName
,target.MarketSegment				= source.MarketSegment
,target.MarketSegmentCode			= source.MarketSegmentCode
,target.FK_CRMBroker				= source.FK_CRMBroker
,target.FK_PartyInsured			    = source.FK_PartyInsured
,target.FK_Underwriter				= source.FK_Underwriter
,target.FK_ClearedClassOfBusiness	= source.FK_ClearedClassOfBusiness
,target.FK_ExpiringSubmission		= source.FK_ExpiringSubmission
,target.SourceSystemName			= source.SourceSystemName
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadSubmission] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
SubmissionSourceId			
,SubmissionStatus			
,SubmissionDate				
,ClearedDate				
,WasMigrated				
,RiskStatus					
,ClearedProductName			
,MarketSegment				
,MarketSegmentCode			
,FK_CRMBroker				
,FK_PartyInsured			
,FK_Underwriter				
,FK_ClearedClassOfBusiness	
,FK_ExpiringSubmission		
,SourceSystemName			
,AuditCreateDateTime   
,AuditModifyDetails 
)
VALUES
(
source.SubmissionSourceId			
,source.SubmissionStatus			
,source.SubmissionDate				
,source.ClearedDate				
,source.WasMigrated				
,source.RiskStatus					
,source.ClearedProductName			
,source.MarketSegment				
,source.MarketSegmentCode			
,source.FK_CRMBroker				
,source.FK_PartyInsured			
,source.FK_Underwriter				
,source.FK_ClearedClassOfBusiness	
,source.FK_ExpiringSubmission		
,source.SourceSystemName			
,GETDATE()
,'New add in [ODS].[usp_LoadSubmission] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;






--END DQM


----
IF NOT EXISTS (SELECT * from sys.indexes where OBJECT_NAME(object_id) = 'Submission' and name = 'IX_Submission_SubmissionSourceId' )
BEGIN
	CREATE INDEX IX_Submission_SubmissionSourceId ON ODS.Submission(SubmissionSourceId)
END

/*** END OF POPULATING [ODS].[SUBMISSION] **/


DELETE se 
FROM ODS.SubmissionExtension se
WHERE FK_Submission NOT IN (SELECT DISTINCT PK_Submission FROM ODS.Submission)

MERGE [ODS].[SubmissionExtension] target
USING
(
SELECT
	FK_Submission
	,IsUnknownMember
	,SubmissionSourceId			
	,PolicyNumber				
	,MatlockKey					
	,LineOfBusiness				
	,ClearedInsuranceStructure	
	,ParentAccountNumber
    ,ParentAccountName
	,AccountNumber				
	,AccountName				
	,AccountAddress				
	,AccountCity				
	,AccountState				
	,AccountZipCode				
	,BrokerGroupName			
	,BrokerName					
	,BrokerCity					
	,BrokerState				
	,BrokerZipCode				
	,BrokerContactName
	,BrokerContactEmail	
	,BrokerLinkId	
	,BrokerLicenseNumber	
	,NewJerseyTransactionCode			
	,SubmittingBrokerSnapshotKeyFlag	
	,SubmittingBrokerGroupName	
	,SubmittingBrokerName		
	,SubmittingBrokerCity		
	,SubmittingBrokerState		
	,SubmittingBrokerZipCode	
	,SubmittingBrokerContactName
	,SubmittingBrokerContactEmail
	,SubmittingBrokerLinkId	
	,CreatedDate
	,CreatedUser				
	,RatedDate					
	,RatedUser					
	,QuotedDate					
	,QuotedUser					
	,BindDate					
	,BindUser					
	,IssuedDate					
	,IssuedUser					
	,CancellationDate			
	,CancellationUser			
	,DeclinationDate			
	,DeclinationUser			
	,NTUDate					
	,NTUUser					
	,RunOffDate					
	,LastModifiedDate			
	,LastModifiedUser			
	,ClearedCoverages			
	,UnderwriterProductCode		
	,RiskCode					
	,TRIA						
	,BenchmarkPremium			
	,BenchmarkPriceIndex		
	,UnderwriterRateChange		
	,UnityPremium				
	,UnityRateChange			
	,ExpiringPremium			
	,ExpiringUnityPremium		
	,RateChangeMethodToUse		
	,EffectiveDate				
	,SourceSystemName
FROM
	(
		SELECT
			 FK_Submission							= sub.PK_Submission
			,IsUnknownMember						= 0
			,SubmissionSourceId						= tmp.SubmissionSourceId			
			,PolicyNumber							= tmp.PolicyNumber				
			,MatlockKey								= tmp.MatlockKey					
			,LineOfBusiness							= tmp.LineOfBusiness				
			,ClearedInsuranceStructure				= tmp.ClearedInsuranceStructure	
			,ParentAccountNumber                    = tmp.ParentAccountNumber
            ,ParentAccountName                      = tmp.ParentAccountName
			,AccountNumber							= tmp.AccountNumber				
			,AccountName							= tmp.AccountName				
			,AccountAddress							= tmp.AccountAddress				
			,AccountCity							= tmp.AccountCity				
			,AccountState							= tmp.AccountState				
			,AccountZipCode							= tmp.AccountZipCode				
			,BrokerGroupName						= tmp.BrokerGroupName			
			,BrokerName								= tmp.BrokerName					
			,BrokerCity								= tmp.BrokerCity					
			,BrokerState							= tmp.BrokerState				
			,BrokerZipCode							= tmp.BrokerZipCode				
			,BrokerContactName						= tmp.BrokerContactName			
			,BrokerContactEmail						= tmp.BrokerContactEmail		
			,BrokerLinkId							= tmp.BrokerLinkId
			,BrokerLicenseNumber					= tmp.BrokerLicenseNumber
			,NewJerseyTransactionCode				= tmp.NewJerseyTransactionCode
			,SubmittingBrokerSnapshotKeyFlag		= tmp.SubmittingBrokerSnapshotKeyFlag		
			,SubmittingBrokerGroupName				= tmp.SubmittingBrokerGroupName	
			,SubmittingBrokerName					= tmp.SubmittingBrokerName		
			,SubmittingBrokerCity					= tmp.SubmittingBrokerCity		
			,SubmittingBrokerState					= tmp.SubmittingBrokerState		
			,SubmittingBrokerZipCode				= tmp.SubmittingBrokerZipCode	
			,SubmittingBrokerContactName			= tmp.SubmittingBrokerContactName
			,SubmittingBrokerContactEmail			= tmp.SubmittingBrokerContactEmail
			,SubmittingBrokerLinkId					= tmp.SubmittingBrokerLinkId
			,CreatedDate							= tmp.CreatedDate
			,CreatedUser							= tmp.CreatedUser				
			,RatedDate								= tmp.RatedDate					
			,RatedUser								= tmp.RatedUser					
			,QuotedDate								= tmp.QuotedDate					
			,QuotedUser								= tmp.QuotedUser					
			,BindDate								= tmp.BindDate					
			,BindUser								= tmp.BindUser					
			,IssuedDate								= tmp.IssuedDate					
			,IssuedUser								= tmp.IssuedUser					
			,CancellationDate						= tmp.CancellationDate			
			,CancellationUser						= tmp.CancellationUser			
			,DeclinationDate						= tmp.DeclinationDate			
			,DeclinationUser						= tmp.DeclinationUser			
			,NTUDate								= tmp.NTUDate					
			,NTUUser								= tmp.NTUUser					
			,RunOffDate								= tmp.RunOffDate					
			,LastModifiedDate						= tmp.LastModifiedDate			
			,LastModifiedUser						= tmp.LastModifiedUser			
			,ClearedCoverages						= tmp.ClearedCoverages			
			,UnderwriterProductCode					= tmp.UnderwriterProductCode		
			,RiskCode								= tmp.RiskCode					
			,TRIA									= tmp.TRIA						
			,BenchmarkPremium						= tmp.BenchmarkPremium			
			,BenchmarkPriceIndex					= tmp.BenchmarkPriceIndex		
			,UnderwriterRateChange					= tmp.UnderwriterRateChange		
			,UnityPremium							= tmp.UnityPremium				
			,UnityRateChange						= tmp.UnityRateChange			
			,ExpiringPremium						= tmp.ExpiringPremium			
			,ExpiringUnityPremium					= tmp.ExpiringUnityPremium		
			,RateChangeMethodToUse					= tmp.RateChangeMethodToUse		
			,EffectiveDate							= tmp.EffectiveDate				
			,SourceSystemName						= tmp.SourceSystemName
			,RowId = ROW_NUMBER() OVER (PARTITION BY tmp.SubmissionSourceId order by tmp.SubmissionDate, tmp.SourceSystemName, tmp.ExpiringSubmissionId, tmp.ClearedDate)
		FROM
			#tmp_Submission tmp
			INNER JOIN
			ODS.Submission sub
			ON
			tmp.SubmissionSourceId = sub.SubmissionSourceId
			AND
			tmp.SourceSystemName = sub.SourceSystemName
	) as t
	WHERE t.RowId = 1

	UNION ALL

		SELECT
		 FK_Submission						= 0
		,IsUnknownMember					= 1
		,SubmissionSourceId					= '0'
		,PolicyNumber						= NULL	
		,MatlockKey							= NULL	
		,LineOfBusiness						= NULL	
		,ClearedInsuranceStructure			= NULL
		,ParentAccountNumber                = NULL
        ,ParentAccountName                  = NULL
		,AccountNumber						= NULL	
		,AccountName						= NULL	
		,AccountAddress						= NULL	
		,AccountCity						= NULL	
		,AccountState						= NULL	
		,AccountZipCode						= NULL	
		,BrokerGroupName					= NULL	
		,BrokerName							= NULL	
		,BrokerCity							= NULL	
		,BrokerState						= NULL	
		,BrokerZipCode						= NULL	
		,BrokerContactName					= NULL
		,BrokerContactEmail					= NULL	
		,BrokerLinkId						= NULL	
		,BrokerLicenseNumber				= NULL	
		,NewJerseyTransactionCode			= NULL	
		,SubmittingBrokerSnapshotKeyFlag	= NULL	
		,SubmittingBrokerGroupName			= NULL	
		,SubmittingBrokerName				= NULL	
		,SubmittingBrokerCity				= NULL	
		,SubmittingBrokerState				= NULL	
		,SubmittingBrokerZipCode			= NULL	
		,SubmittingBrokerContactName		= NULL
		,SubmittingBrokerContactEmail		= NULL	
		,SubmittingBrokerLinkId				= NULL
		,CreatedDate						= NULL
		,CreatedUser						= NULL	
		,RatedDate							= NULL	
		,RatedUser							= NULL	
		,QuotedDate							= NULL	
		,QuotedUser							= NULL	
		,BindDate							= NULL	
		,BindUser							= NULL	
		,IssuedDate							= NULL	
		,IssuedUser							= NULL	
		,CancellationDate					= NULL	
		,CancellationUser					= NULL	
		,DeclinationDate					= NULL	
		,DeclinationUser					= NULL	
		,NTUDate							= NULL	
		,NTUUser							= NULL	
		,RunOffDate							= NULL	
		,LastModifiedDate					= NULL	
		,LastModifiedUser					= NULL	
		,ClearedCoverages					= NULL	
		,UnderwriterProductCode				= NULL	
		,RiskCode							= NULL	
		,TRIA								= NULL	
		,BenchmarkPremium					= NULL	
		,BenchmarkPriceIndex				= NULL	
		,UnderwriterRateChange				= NULL	
		,UnityPremium						= NULL	
		,UnityRateChange					= NULL	
		,ExpiringPremium					= NULL	
		,ExpiringUnityPremium				= NULL	
		,RateChangeMethodToUse				= NULL	
		,EffectiveDate						= NULL	
		,SourceSystemName					= 'N/A'
	)source 
	ON  target.FK_Submission   = source.FK_Submission
	WHEN MATCHED THEN 
	UPDATE 
	SET 
	 target.IsUnknownMember							= source.IsUnknownMember
	,target.SubmissionSourceId						= source.SubmissionSourceId			
	,target.PolicyNumber							= source.PolicyNumber				
	,target.MatlockKey								= source.MatlockKey					
	,target.LineOfBusiness							= source.LineOfBusiness				
	,target.ClearedInsuranceStructure				= source.ClearedInsuranceStructure
	,target.ParentAccountNumber                     = source.ParentAccountNumber
    ,target.ParentAccountName                       = source.ParentAccountName
	,target.AccountNumber							= source.AccountNumber				
	,target.AccountName								= source.AccountName				
	,target.AccountAddress							= source.AccountAddress				
	,target.AccountCity								= source.AccountCity				
	,target.AccountState							= source.AccountState				
	,target.AccountZipCode							= source.AccountZipCode				
	,target.BrokerGroupName							= source.BrokerGroupName			
	,target.BrokerName								= source.BrokerName					
	,target.BrokerCity								= source.BrokerCity					
	,target.BrokerState								= source.BrokerState				
	,target.BrokerZipCode							= source.BrokerZipCode				
	,target.BrokerContactName						= source.BrokerContactName
	,target.BrokerContactEmail						= source.BrokerContactEmail			
	,target.BrokerLinkId							= source.BrokerLinkId
	,target.BrokerLicenseNumber						= source.BrokerLicenseNumber
	,target.NewJerseyTransactionCode				= source.NewJerseyTransactionCode
	,target.SubmittingBrokerSnapshotKeyFlag			= source.SubmittingBrokerSnapshotKeyFlag		
	,target.SubmittingBrokerGroupName				= source.SubmittingBrokerGroupName	
	,target.SubmittingBrokerName					= source.SubmittingBrokerName		
	,target.SubmittingBrokerCity					= source.SubmittingBrokerCity		
	,target.SubmittingBrokerState					= source.SubmittingBrokerState		
	,target.SubmittingBrokerZipCode					= source.SubmittingBrokerZipCode	
	,target.SubmittingBrokerContactName				= source.SubmittingBrokerContactName
	,target.SubmittingBrokerContactEmail			= source.SubmittingBrokerContactEmail
	,target.SubmittingBrokerLinkId					= source.SubmittingBrokerLinkId	
	,target.CreatedDate								= source.CreatedDate
	,target.CreatedUser								= source.CreatedUser				
	,target.RatedDate								= source.RatedDate					
	,target.RatedUser								= source.RatedUser					
	,target.QuotedDate								= source.QuotedDate					
	,target.QuotedUser								= source.QuotedUser					
	,target.BindDate								= source.BindDate					
	,target.BindUser								= source.BindUser					
	,target.IssuedDate								= source.IssuedDate					
	,target.IssuedUser								= source.IssuedUser					
	,target.CancellationDate						= source.CancellationDate			
	,target.CancellationUser						= source.CancellationUser			
	,target.DeclinationDate							= source.DeclinationDate			
	,target.DeclinationUser							= source.DeclinationUser			
	,target.NTUDate									= source.NTUDate					
	,target.NTUUser									= source.NTUUser					
	,target.RunOffDate								= source.RunOffDate					
	,target.LastModifiedDate						= source.LastModifiedDate			
	,target.LastModifiedUser						= source.LastModifiedUser			
	,target.ClearedCoverages						= source.ClearedCoverages			
	,target.UnderwriterProductCode					= source.UnderwriterProductCode		
	,target.RiskCode								= source.RiskCode					
	,target.TRIA									= source.TRIA						
	,target.BenchmarkPremium						= source.BenchmarkPremium			
	,target.BenchmarkPriceIndex						= source.BenchmarkPriceIndex		
	,target.UnderwriterRateChange					= source.UnderwriterRateChange		
	,target.UnityPremium							= source.UnityPremium				
	,target.UnityRateChange						    = source.UnityRateChange			
	,target.ExpiringPremium							= source.ExpiringPremium			
	,target.ExpiringUnityPremium					= source.ExpiringUnityPremium		
	,target.RateChangeMethodToUse					= source.RateChangeMethodToUse		
	,target.EffectiveDate							= source.EffectiveDate				
	,target.SourceSystemName						= source.SourceSystemName
	,target.AuditModifyDateTime						= GETDATE()
	,target.AuditModifyDetails						= 'Merge in [ODS].[usp_LoadSubmission] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
	FK_Submission
	,IsUnknownMember
	,SubmissionSourceId			
	,PolicyNumber				
	,MatlockKey					
	,LineOfBusiness				
	,ClearedInsuranceStructure	
	,ParentAccountNumber
    ,ParentAccountName
	,AccountNumber				
	,AccountName				
	,AccountAddress				
	,AccountCity				
	,AccountState				
	,AccountZipCode				
	,BrokerGroupName			
	,BrokerName					
	,BrokerCity					
	,BrokerState				
	,BrokerZipCode				
	,BrokerContactName
	,BrokerContactEmail			
	,BrokerLinkId	
	,BrokerLicenseNumber	
	,NewJerseyTransactionCode			
	,SubmittingBrokerSnapshotKeyFlag	
	,SubmittingBrokerGroupName	
	,SubmittingBrokerName		
	,SubmittingBrokerCity		
	,SubmittingBrokerState		
	,SubmittingBrokerZipCode	
	,SubmittingBrokerContactName
	,SubmittingBrokerContactEmail
	,SubmittingBrokerLinkId	
	,CreatedDate
	,CreatedUser				
	,RatedDate					
	,RatedUser					
	,QuotedDate					
	,QuotedUser					
	,BindDate					
	,BindUser					
	,IssuedDate					
	,IssuedUser					
	,CancellationDate			
	,CancellationUser			
	,DeclinationDate			
	,DeclinationUser			
	,NTUDate					
	,NTUUser					
	,RunOffDate					
	,LastModifiedDate			
	,LastModifiedUser			
	,ClearedCoverages			
	,UnderwriterProductCode		
	,RiskCode					
	,TRIA						
	,BenchmarkPremium			
	,BenchmarkPriceIndex		
	,UnderwriterRateChange		
	,UnityPremium				
	,UnityRateChange			
	,ExpiringPremium			
	,ExpiringUnityPremium		
	,RateChangeMethodToUse		
	,EffectiveDate				
	,SourceSystemName
	,AuditCreateDateTime   
	,AuditModifyDetails 
	)
VALUES
(
	 source.FK_Submission
	,source.IsUnknownMember
	,source.SubmissionSourceId			
	,source.PolicyNumber				
	,source.MatlockKey					
	,source.LineOfBusiness				
	,source.ClearedInsuranceStructure
    ,source.ParentAccountNumber
    ,source.ParentAccountName
	,source.AccountNumber				
	,source.AccountName				
	,source.AccountAddress				
	,source.AccountCity				
	,source.AccountState				
	,source.AccountZipCode				
	,source.BrokerGroupName			
	,source.BrokerName					
	,source.BrokerCity					
	,source.BrokerState				
	,source.BrokerZipCode				
	,source.BrokerContactName			
	,source.BrokerContactEmail			
	,source.BrokerLinkId	
	,source.BrokerLicenseNumber	
	,source.NewJerseyTransactionCode			
	,source.SubmittingBrokerSnapshotKeyFlag	
	,source.SubmittingBrokerGroupName	
	,source.SubmittingBrokerName		
	,source.SubmittingBrokerCity		
	,source.SubmittingBrokerState		
	,source.SubmittingBrokerZipCode	
	,source.SubmittingBrokerContactName
	,source.SubmittingBrokerContactEmail
	,source.SubmittingBrokerLinkId	
	,source.CreatedDate
	,source.CreatedUser				
	,source.RatedDate					
	,source.RatedUser					
	,source.QuotedDate					
	,source.QuotedUser					
	,source.BindDate					
	,source.BindUser					
	,source.IssuedDate					
	,source.IssuedUser					
	,source.CancellationDate			
	,source.CancellationUser			
	,source.DeclinationDate			
	,source.DeclinationUser			
	,source.NTUDate					
	,source.NTUUser					
	,source.RunOffDate					
	,source.LastModifiedDate			
	,source.LastModifiedUser			
	,source.ClearedCoverages			
	,source.UnderwriterProductCode		
	,source.RiskCode					
	,source.TRIA						
	,source.BenchmarkPremium			
	,source.BenchmarkPriceIndex		
	,source.UnderwriterRateChange		
	,source.UnityPremium				
	,source.UnityRateChange			
	,source.ExpiringPremium			
	,source.ExpiringUnityPremium		
	,source.RateChangeMethodToUse		
	,source.EffectiveDate				
	,source.SourceSystemName
	,GETDATE()
	,'New add in [ODS].[usp_LoadSubmission] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

/*** END of populating [ODS].[SubmissionExtension] **/

-- letting go of the temporary tables
----
IF OBJECT_ID('#tmp_Broker') IS NOT NULL
	DROP TABLE #tmp_Broker

IF OBJECT_ID('#tmp_Underwriter') IS NOT NULL
	DROP TABLE #tmp_Underwriter

IF OBJECT_ID('#tmp_PartyInsured') IS NOT NULL
	DROP TABLE #tmp_PartyInsured

IF OBJECT_ID('#tmp_ExtensionColumns') IS NOT NULL
	DROP TABLE #tmp_ExtensionColumns

IF OBJECT_ID('#tmp_Submission') IS NOT NULL
	DROP TABLE #tmp_Submission

END