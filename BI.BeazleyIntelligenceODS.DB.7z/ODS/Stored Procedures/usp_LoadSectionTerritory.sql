﻿CREATE PROCEDURE [ODS].[usp_LoadSectionTerritory]
AS BEGIN

	SET NOCOUNT ON

	DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM		ODS.SectionTerritory

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');
	--select @LastAuditDate



	--delete rows where the parent Section or Area were deleted
	DELETE		st
	FROM		ods.SectionTerritory st
	LEFT JOIN	ods.Section s 
			ON	st.fk_Section = s.PK_Section
	LEFT JOIN	ods.Area a
			ON	st.FK_Area = a.PK_Area
	WHERE		s.PK_Section is NULL
			OR	a.PK_Area is NULL

	--delete rows where the correspondent row in DataContract was deactivated
	DELETE		st
	FROM		ODS.SectionTerritory st 
	INNER JOIN	(
				SELECT		FK_Section              = s.PK_Section
							,FK_Area                = a.PK_Area
				FROM		BeazleyIntelligenceDataContract.Outbound.SectionTerritory st
				INNER JOIN	ODS.Section s 
						ON	st.SectionSourceId = s.SectionReference
				INNER JOIN	ODS.Area a 
						ON	st.AreaCode = a.AreaCode
				WHERE		st.SourceSystem IN ('Eurobase', 'Unirisx')
						AND st.IsActive = 0
						AND (st.AuditCreateDatetime > @LastAuditDate OR st.AuditModifyDatetime > @LastAuditDate)
	) deactivated
			ON	st.FK_Section = deactivated.FK_Section
			AND	st.FK_Area = deactivated.FK_Area;

	WITH st AS (
				SELECT		FK_Section              = s.PK_Section
							,FK_Area                = a.PK_Area
							,AreaMultiplier         = st.AreaMultiplier
				FROM		BeazleyIntelligenceDataContract.Outbound.vw_SectionTerritory st
				INNER JOIN	ODS.Section s 
						ON	st.SectionSourceId = s.SectionReference
				INNER JOIN	ODS.Area a 
						ON	st.AreaCode = a.AreaCode
				WHERE		st.SourceSystem IN ('Eurobase', 'Unirisx')
						AND (st.AuditCreateDatetime > @LastAuditDate OR st.AuditModifyDatetime > @LastAuditDate)
	),

	SectionTeritory AS (
				SELECT		FK_Section							= st.FK_Section
							, FK_Area							= st.FK_Area
							,AreaMultiplier						= st.AreaMultiplier
				FROM		st 

				UNION ALL

				SELECT		FK_Section							= s_bbr.PK_Section
							,FK_Area							= st.FK_Area
							,AreaMultiplier						= NULL
				FROM		st 
				INNER JOIN	ODS.Section s 
						ON	st.FK_Section = s.PK_Section
				INNER JOIN	ODS.Section s_bbr 
						ON	s_bbr.FK_BreachResponseParentSection = s.PK_Section
	) 


	MERGE		ods.SectionTerritory	TARGET
	USING		SectionTeritory		SOURCE
			ON	target.FK_Section = SOURCE.FK_Section
			AND target.FK_Area = source.FK_Area
	WHEN MATCHED --AND ISNULL(target.AreaMultiplier, 0) <> ISNULL(source.AreaMultiplier, 0)
		THEN UPDATE 
				SET		TARGET.AreaMultiplier					= source.AreaMultiplier
						,TARGET.AuditModifyDateTime	            = GETDATE()						
						,TARGET.AuditModifyDetails	            = 'Merge in ODS.usp_LoadSectionTerritory proc' 
	WHEN NOT MATCHED BY TARGET
		THEN INSERT (FK_Section, FK_Area, AreaMultiplier, AuditCreateDateTime, AuditModifyDetails)
			VALUES	(source.FK_Section, source.FK_Area, source.AreaMultiplier, GETDATE(), 'New add in ODS.usp_LoadSectionTerritory proc');

END