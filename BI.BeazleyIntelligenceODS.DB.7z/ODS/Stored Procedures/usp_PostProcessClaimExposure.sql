﻿CREATE PROC  [ODS].[usp_PostProcessClaimExposure]
AS

DECLARE @AsAtDate datetime
SELECT @AsAtDate = GETDATE() --Load into variable for performance reasons

SET NOCOUNT ON
 
    
/*Multi-original currency indicator*/
UPDATE ce SET    
MultipleOriginalCCYIndicator     = 1
FROM  ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    FK_ClaimExposure    = cm.FK_ClaimExposure
    ,OriginalCCYCount   = COUNT(DISTINCT cm.FK_OriginalCurrency)  
    FROM     
    ODS.ClaimMovement cm
    GROUP BY 
    cm.FK_ClaimExposure
    HAVING
    COUNT(DISTINCT cm.FK_OriginalCurrency)  > 1
)  c_ccy 
ON ce.PK_ClaimExposure = c_ccy.FK_ClaimExposure


/*First movement fields*/   
UPDATE ce 
SET
	FirstMovementDate                   = cm_fm.MovementDate
	,MonthsSinceFirstMovement           = CAST(DATEDIFF(d, cm_fm.MovementDate, @AsAtDate) as numeric(19,12)) / 30.5
FROM ODS.ClaimExposure ce 

INNER JOIN
(
    SELECT
		PK_ClaimMovement                = cm.PK_ClaimMovement
		,FK_ClaimExposure               = cm.FK_ClaimExposure
		,MovementDate                   = cm.MovementDate
		,SequenceNumber                 = ROW_NUMBER() OVER(
																PARTITION BY FK_ClaimExposure
																ORDER BY cm.MovementDate ASC, cm.MovementGroupSequenceId ASC
															)
    FROM ODS.ClaimMovement cm
) cm_fm 
ON ce.PK_ClaimExposure = cm_fm.FK_ClaimExposure
AND cm_fm.SequenceNumber = 1
        
		        
/*First movement creation date*/
UPDATE ce
SET
MovementCreationDate = cm_fm.MovementCreationDate
FROM ODS.ClaimExposure ce

INNER JOIN
(
	SELECT
	PK_ClaimMovement = cm.PK_ClaimMovement
	,FK_ClaimExposure = cm.FK_ClaimExposure
	,MovementCreationDate = cm.MovementCreationDate
	,SequenceNumber = ROW_NUMBER() OVER(
	PARTITION BY FK_ClaimExposure
	ORDER BY cm.MovementCreationDate ASC, cm.MovementDate ASC, cm.MovementGroupSequenceId ASC
)
FROM ODS.ClaimMovement cm
WHERE MovementReference <> 'DUMMY MOVEMENT'
) cm_fm
ON cm_fm.FK_ClaimExposure = ce.PK_ClaimExposure
AND cm_fm.SequenceNumber = 1


/*Last movement banding*/
 UPDATE ce 
 SET
		LastMovementBandingDate             = lmb.FK_LastMovementBandingDate
		,MonthsSinceLastMovement            = CAST(DATEDIFF(d, lmb.FK_LastMovementBandingDate, @AsAtDate) as numeric(19,12)) / 30.5
FROM ODS.ClaimExposure ce 

INNER JOIN  
(    
    SELECT   
		FK_ClaimExposure                = m.FK_ClaimExposure
		,FK_LastMovementBandingDate     = MAX(
												CASE 
													WHEN m.UseForLastMovementBanding = 1 THEN m.FK_MovementDate
													ELSE NULL
												END
											)
    FROM ODS.ClaimMovement m
    GROUP BY  m.FK_ClaimExposure
) lmb 
ON ce.PK_ClaimExposure = lmb.FK_ClaimExposure

/*Last narrative containing IBNR*/
UPDATE ce 
SET LastMovementNarrativeContainingIBNR = cm_lm_inbr.MovementNarrative
FROM  ODS.ClaimExposure ce 
INNER JOIN  
(    
    SELECT   
		FK_ClaimExposure                    = m.FK_ClaimExposure
		,LastMovementGroupSequenceIdIBNR    = MAX(
												CASE WHEN m.MovementNarrative LIKE '%IBNR%' 
													 THEN m.MovementGroupSequenceId
													 ELSE NULL
												END
											)
    FROM ODS.ClaimMovement m
    GROUP BY m.FK_ClaimExposure
) inbr 
ON ce.PK_ClaimExposure = inbr.FK_ClaimExposure

LEFT OUTER JOIN ODS.ClaimMovement cm_lm_inbr 
ON inbr.FK_ClaimExposure = cm_lm_inbr.FK_ClaimExposure 
AND inbr.LastMovementGroupSequenceIdIBNR = cm_lm_inbr.MovementGroupSequenceId
/* DateClaimPaid */

update ce
set DateClaimPaid = cm_fm.MovementDate
FROM ODS.ClaimExposure ce 

INNER JOIN
(
    SELECT
		PK_ClaimMovement                = cm.PK_ClaimMovement
		,FK_ClaimExposure               = cm.FK_ClaimExposure
		,MovementDate                   = cm.MovementDate
		,SequenceNumber                 = ROW_NUMBER() OVER(
																PARTITION BY FK_ClaimExposure
																ORDER BY cm.MovementDate ASC, cm.MovementGroupSequenceId ASC
															)
    FROM ODS.ClaimMovement cm
	where cm.MovementType = 'SCM'
	and MovementPaidIndemnityInSettlementCCY>0
) cm_fm 
ON ce.PK_ClaimExposure = cm_fm.FK_ClaimExposure
AND cm_fm.SequenceNumber = 1

update ce
set DateClaimPaid = cm_fm.MovementDate
FROM [ODS].ClaimExposure ce 

INNER JOIN
(
    SELECT
		PK_ClaimMovement                = cm.PK_ClaimMovement
		,FK_ClaimExposure               = cm.FK_ClaimExposure
		,MovementDate                   = cm.MovementDate
		,SequenceNumber                 = ROW_NUMBER() OVER(
																PARTITION BY FK_ClaimExposure
																ORDER BY cm.MovementDate ASC, cm.MovementGroupSequenceId ASC
															)
    FROM ODS.ClaimMovement cm
	where actualoriginalamounttype  like '%ind%' 
	and MovementType = 'Payment'
) cm_fm 
ON ce.PK_ClaimExposure = cm_fm.FK_ClaimExposure
AND cm_fm.SequenceNumber = 1


/*
TBAs are a bit more complex. Rules are as follows:
    1. Look at the TBA on the latest movement.
    2. Look back until the most recent movement where it was a different value (NULL counts as a different value)
    3. The date we're interested in is when it has changed, so it will be the date of the next movement from step 2
    4. If it has never changed, we want the date from the first movement
    5. Calculate the difference in months between the current date and the last movement where the TBA indicator was a different value
    6. Work out the banding
    
LI June 20th 2013: This statement has started epxeriencing poor performance. Loading data into a temp table first and then joining
back to do the update fixes it.
*/

IF (OBJECT_ID('tempdb..#TBA') IS NOT NULL) 
DROP TABLE #TBA

CREATE TABLE #TBA
(
    FK_ClaimExposure                        bigint          NOT NULL
    ,LastMovementTBAIndicator               varchar(255)    NULL
    ,LastMovementTBAFlag                    bit             NOT NULL
    ,MonthsSinceLastTBAIndicatorChange      numeric(19,12)  NULL
    ,MonthsSinceLastTBAFlagChange           numeric(19,12)  NULL
    ,PRIMARY KEY (FK_ClaimExposure)
)

INSERT INTO #TBA
(
    FK_ClaimExposure
    ,LastMovementTBAIndicator
    ,LastMovementTBAFlag
    ,MonthsSinceLastTBAIndicatorChange
    ,MonthsSinceLastTBAFlagChange
)
SELECT
	FK_ClaimExposure                        = ce.PK_ClaimExposure
	,LastMovementTBAIndicator               = cm_lm.TBAIndicator  -- marked as Removed from ClaimMovement
	,LastMovementTBAFlag                    = cm_lm.TBAFlag		-- marked as Removed from ClaimMovement
	,MonthsSinceLastTBAIndicatorChange      = CAST(DATEDIFF(d, 
													 ISNULL(cm_tba_indicator_chg.FK_MovementDate ,earliest.FK_MovementDate)
													,@AsAtDate) as numeric(19,12)) / 30.5
	,MonthsSinceLastTBAFlagChange           = CAST(DATEDIFF(d, 
													 ISNULL(cm_tba_flag_chg.FK_MovementDate ,earliest.FK_MovementDate)
													,@AsAtDate) as numeric(19,12)) / 30.5
FROM  ODS.ClaimExposure ce
INNER JOIN  ODS.ClaimMovement cm_lm 
ON  ce.FK_LastMovement = cm_lm.PK_ClaimMovement
LEFT OUTER JOIN  (
                    SELECT   
                            MovementGroupId                         = latest_indicator.MovementGroupId 
                            ,LastTBAIndicatorChangeSequenceId       = MAX(cm.MovementGroupSequenceId) + 1 
                    FROM ODS.ClaimMovement cm
                    INNER JOIN   (
                                    SELECT
                                             FK_ClaimExposure           = ce.PK_ClaimExposure
                                            ,MovementGroupId            = cm.MovementGroupId 
                                            ,MovementGroupSequenceId    = cm.MovementGroupSequenceId 
                                            ,TBAIndicator               = cm.TBAIndicator 
                                    FROM ODS.ClaimMovement cm
                                    INNER JOIN  ODS.ClaimExposure ce 
                                    ON  ce.FK_LastMovement = cm.PK_ClaimMovement
                                  ) latest_indicator 
                            ON  cm.MovementGroupId = latest_indicator.MovementGroupId               AND 
                                ISNULL(cm.TBAIndicator, '') <> ISNULL(latest_indicator.TBAIndicator, '')
                    GROUP BY   latest_indicator.MovementGroupId
                    ) tba_indicator_change 
ON   cm_lm.MovementGroupId = tba_indicator_change.MovementGroupId

LEFT OUTER JOIN  ODS.ClaimMovement AS cm_tba_indicator_chg 
ON       cm_lm.MovementGroupId = cm_tba_indicator_chg.MovementGroupId   AND 
                 tba_indicator_change.LastTBAIndicatorChangeSequenceId = cm_tba_indicator_chg.MovementGroupSequenceId

LEFT OUTER JOIN
                (
                    SELECT
                             MovementGroupId              = latest_flag.MovementGroupId             
                            ,LastTBAFlagChangeSequenceId  = MAX(cm.MovementGroupSequenceId) + 1    
                    FROM     ODS.ClaimMovement cm
                    INNER JOIN
                                (
                                    SELECT
                                             FK_ClaimExposure           = ce.PK_ClaimExposure               
                                            ,MovementGroupId            = cm.MovementGroupId         
                                            ,MovementGroupSequenceId    = cm.MovementGroupSequenceId 
                                            ,TBAFlag                    = cm.TBAFlag                 
                                    FROM    ODS.ClaimMovement AS cm
                                    INNER JOIN  ODS.ClaimExposure ce 
                                     ON   ce.FK_LastMovement = cm.PK_ClaimMovement
                                ) latest_flag 
                           ON
                                cm.MovementGroupId = latest_flag.MovementGroupId AND 
                                cm.TBAFlag <> latest_flag.TBAFlag
                    GROUP BY
                    latest_flag.MovementGroupId
                ) tba_flag_change 
 ON   cm_lm.MovementGroupId = tba_flag_change.MovementGroupId

LEFT OUTER JOIN  ODS.ClaimMovement cm_tba_flag_chg 
ON   cm_lm.MovementGroupId = cm_tba_flag_chg.MovementGroupId AND 
                 tba_flag_change.LastTBAFlagChangeSequenceId = cm_tba_flag_chg.MovementGroupSequenceId

INNER JOIN       ODS.ClaimMovement earliest 
 ON       cm_lm.MovementGroupId = earliest.MovementGroupId AND 
                 earliest.MovementGroupSequenceId = 1
                 
UPDATE ce SET
	LastMovementTBAIndicator                = tba.LastMovementTBAIndicator
	,LastMovementTBAFlag                    = tba.LastMovementTBAFlag
	,MonthsSinceLastTBAIndicatorChange      = tba.MonthsSinceLastTBAIndicatorChange
	,MonthsSinceLastTBAFlagChange           = tba.MonthsSinceLastTBAFlagChange
FROM ODS.ClaimExposure ce
INNER JOIN #TBA tba 
ON ce.PK_ClaimExposure = tba.FK_ClaimExposure

/*Anything over 50 years is a data issue or a dummy movement*/
UPDATE ce SET
     MonthsSinceLastMovement            = CASE WHEN ce.MonthsSinceLastMovement > 600 THEN NULL ELSE ce.MonthsSinceLastMovement END
    ,MonthsSinceLastTBAIndicatorChange  = CASE WHEN ce.MonthsSinceLastTBAIndicatorChange > 600 THEN NULL ELSE ce.MonthsSinceLastTBAIndicatorChange END
    ,MonthsSinceLastTBAFlagChange       = CASE WHEN ce.MonthsSinceLastTBAFlagChange > 600 THEN NULL ELSE ce.MonthsSinceLastTBAFlagChange END
FROM ODS.ClaimExposure ce
    
UPDATE ce SET
     MonthsSinceLastMovementBandKey                 = md.BandMin
    ,MonthsSinceLastMovementBand                    = ISNULL(md.BandName, 'N/A')
    ,MonthsSinceFirstMovementBandKey                = mf.BandMin
    ,MonthsSinceFirstMovementBand                   = ISNULL(mf.BandName, 'N/A')
    ,MonthsSinceLastTBAIndicatorChangeBandKey       = tba_i_d.BandMin
    ,MonthsSinceLastTBAIndicatorChangeBand          = ISNULL(tba_i_d.BandName, 'N/A')
    ,MonthsSinceLastTBAFlagChangeBandKey            = tba_f_d.BandMin
    ,MonthsSinceLastTBAFlagChangeBand               = ISNULL(tba_f_d.BandName, 'N/A')
FROM ODS.ClaimExposure ce
LEFT OUTER JOIN  Staging_MDS.MDS_Staging.MovementDurationBand md 
             ON  ce.MonthsSinceLastMovement >= md.BandMin  AND 
                 ce.MonthsSinceLastMovement < md.BandMax
LEFT OUTER JOIN  Staging_MDS.MDS_Staging.MovementDurationBand mf 
             ON  ce.MonthsSinceFirstMovement >= mf.BandMin AND 
                 ce.MonthsSinceFirstMovement < mf.BandMax
LEFT OUTER JOIN  Staging_MDS.MDS_Staging.MovementDurationBand tba_i_d 
             ON  ce.MonthsSinceLastTBAIndicatorChange >= tba_i_d.BandMin AND 
                 ce.MonthsSinceLastTBAIndicatorChange < tba_i_d.BandMax
LEFT OUTER JOIN  Staging_MDS.MDS_Staging.MovementDurationBand tba_f_d 
             ON  ce.MonthsSinceLastTBAFlagChange >= tba_f_d.BandMin  AND 
                 ce.MonthsSinceLastTBAFlagChange < tba_f_d.BandMax


/*Update section-level fields*/  

-- Temp table with claim and policies partitioned by claim and order by movement grop seq id and the minimun slip line number.
-- We use this to determine the order of the sections for multi-section claims. This is the same logic that ClaimCenter uses
-- (take the first slip number of the first movement of the claim)
IF (OBJECT_ID('tempdb..#ClaimExposureSectionPartition') IS NOT NULL) 
DROP TABLE #ClaimExposureSectionPartition


CREATE TABLE #ClaimExposureSectionPartition 
(
     FK_ClaimExposure               bigint          NOT NULL
    ,MovementGroupSequenceId        int             NOT NULL 
    ,FK_Section                     bigint          NOT NULL
    ,SequenceId                     int             NOT NULL
	,SplitLinesSequenceId           int             NULL
	,ExposureReference                varchar(255)    NOT NULL
)

INSERT INTO #ClaimExposureSectionPartition
(
     FK_ClaimExposure
    ,MovementGroupSequenceId
    ,FK_Section   
    ,SequenceId  
	,SplitLinesSequenceId
	,ExposureReference
)

SELECT 
       
       FK_ClaimExposure                         = ce.PK_ClaimExposure
      ,MovementGroupSequenceId                  = claimmov.MovementGroupSequenceId                        
      ,FK_Section                               = ces.FK_Section
      ,SequenceId                               = ROW_NUMBER() 
	                                              OVER(PARTITION BY ce.PK_ClaimExposure
                                                   ORDER BY claimmov.MovementGroupSequenceId ASC) 
		,SplitLinesSequenceId                   = ces.SectionSequenceId 	
		,ExposureReference                          = ce.ExposureReference
FROM ODS.ClaimExposure ce

INNER JOIN ODS.ClaimMovement claimmov
ON ce.PK_ClaimExposure = claimmov.FK_ClaimExposure

LEFT JOIN ODS.ClaimMovementLine claimmovline
ON claimmov.PK_ClaimMovement = claimmovline.FK_ClaimMovement

INNER join ODS.ClaimExposureSection ces 
ON ces.fk_claimExposure = ce.Pk_ClaimExposure

INNER JOIN ODS.Section s
ON s.PK_Section=claimmovline.FK_Section

LEFT OUTER JOIN  ODS.Section f 
ON s.FK_Facility = f.PK_Section
    
WHERE claimmov.MovementGroupSequenceId = 1    

GROUP BY 
	ce.PK_ClaimExposure
	,claimmov.MovementGroupSequenceId        
	,ces.FK_Section
	,ces.SectionSequenceId
	,ce.ExposureReference

ORDER BY claimmov.MovementGroupSequenceId   ASC


-- Retrieve section fields before we update ODS.ClaimExposure
IF (OBJECT_ID('tempdb..#ClaimExposureSection') IS NOT NULL) 
DROP TABLE   #ClaimExposureSection
  

CREATE TABLE #ClaimExposureSection 
(
     FK_ClaimExposure                           bigint	        NOT NULL
	 ,ExposureReference                         VARCHAR(255)     NOT NULL
	 ,SplitLinesSequenceId                       int NULL
    ,SequenceId                                 bigint	        NOT NULL
    ,SectionReference                           varchar(255)    NOT NULL
    ,SectionURL                                 varchar(255)    NULL
    ,SectionURLLabel                            varchar(255)    NULL    
    ,FacilityReference                          varchar(255)    NULL
    ,FK_TriFocus                                bigint	        NOT NULL
    ,FK_ClassOfBusiness                         bigint          NOT NULL
    ,LeaderPseudonym                            varchar(255)    NULL
    ,InceptionDate                              datetime        NULL
    ,ExpiryDate                                 datetime        NULL
    ,WrittenIfNotSignedLineMultiplier           numeric(19,12)  NULL
    ,EarliestLPSOPremiumSigningDate             datetime        NULL
    ,EarliestLPSOPremiumSigningNumber           int	            NULL
    ,FacilityEarliestLPSOPremiumSigningDate     datetime        NULL
    ,FacilityEarliestLPSOPremiumSigningNumber   int	            NULL
    ,YOA                                        int             NOT NULL
    ,IsBeazleyLead                              bit             NOT NULL     
    ,PolicyReference                            varchar(255)    NOT NULL
    --,AgressoReference                           varchar(255)    NULL
    ,CoverageName                               varchar(255)    NULL
    ,FK_Underwriter                             bigint          NOT NULL
    --,USUnderwritingCoverageCode                 varchar(255)    NULL
    ,InsuredState                               varchar(255)    NULL
    ,IsNewYorkFreeTradeZone                     bit             NOT NULL
    ,LinkedSynergySection                       varchar(255)    NULL
)

INSERT #ClaimExposureSection 
(
    FK_ClaimExposure
	,ExposureReference
	,SplitLinesSequenceId
    ,SequenceId
    ,SectionReference
    ,SectionURL
    ,SectionURLLabel
    ,FacilityReference
    ,FK_TriFocus
    ,FK_ClassOfBusiness
    ,LeaderPseudonym
    ,InceptionDate
    ,ExpiryDate
    ,WrittenIfNotSignedLineMultiplier
    ,EarliestLPSOPremiumSigningDate
    ,EarliestLPSOPremiumSigningNumber
    ,FacilityEarliestLPSOPremiumSigningDate
    ,FacilityEarliestLPSOPremiumSigningNumber
    ,YOA
    ,IsBeazleyLead
    ,PolicyReference
    --,AgressoReference
    ,CoverageName
    ,FK_Underwriter
    --,USUnderwritingCoverageCode
    ,InsuredState
    ,IsNewYorkFreeTradeZone
    ,LinkedSynergySection
)
SELECT
FK_ClaimExposure                            = cesp.FK_ClaimExposure
,ExposureReference                          = cesp.ExposureReference
,SplitLinesSequenceId                       = cesp.SplitLinesSequenceId
,SequenceId                                 = cesp.SequenceId
,SectionReference                           = s.SectionReference
,SectionURL                                 = s.PrimarySectionURL
,SectionURLLabel                            = s.PrimarySectionURLLabel
,FacilityReference                          = f.SectionReference
,FK_TriFocus                                = s.FK_TriFocus                              
,FK_ClassOfBusiness                         = s.FK_ClassOfBusiness   
,LeaderPseudonym                            = ISNULL(s.LeaderPseudonym, '')              
,InceptionDate                              = s.InceptionDate                            
,ExpiryDate                                 = s.ExpiryDate                               
,WrittenIfNotSignedLineMultiplier           = s.WrittenIfNotSignedLineMultiplier         
,EarliestLPSOPremiumSigningDate             = s.EarliestLPSOPremiumSigningDate           
,EarliestLPSOPremiumSigningNumber           = s.EarliestLPSOPremiumSigningNumber         
,FacilityEarliestLPSOPremiumSigningDate     = f.EarliestLPSOPremiumSigningDate           
,FacilityEarliestLPSOPremiumSigningNumber   = f.EarliestLPSOPremiumSigningNumber         
,YOA                                        = p.FK_YOA
,IsBeazleyLead                              = ISNULL(s.IsBeazleyLead, 0)
,PolicyReference                            = p.PolicyReference
--,AgressoReference                           = s.AgressoReference
,CoverageName                               = s.CoverageName
,FK_Underwriter                             = s.FK_Underwriter
--,USUnderwritingCoverageCode                 = s.USUnderwritingCoverageCode
,InsuredState                               = p.Address2
,IsNewYorkFreeTradeZone                     = ISNULL(p.IsNewYorkFreeTradeZone, 0)
,LinkedSynergySection                       = s.LinkedSynergySection
FROM #ClaimExposureSectionPartition cesp

INNER JOIN ODS.Section s 
ON cesp.FK_Section = s.PK_Section

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

LEFT OUTER JOIN  ODS.Section f 
ON  s.FK_Facility = f.PK_Section

LEFT OUTER JOIN ODS.Section s_r 
ON s.FK_BreachResponseParentSection = s_r.PK_Section


UPDATE ce SET 
	PrimaryPolicyReference              = ces1.PolicyReference
	,PrimarySectionReference            = ces1.SectionReference
	,PrimarySectionURL                  = ces1.SectionURL
	,PrimarySectionURLLabel             = ces1.SectionURLLabel
	,SecondaryPolicyReference           = ces2.PolicyReference
	,SecondarySectionReference          = CASE WHEN ce.SecondarySectionReference IS NULL THEN ces2.SectionReference ELSE ce.SecondarySectionReference END
	,SecondarySectionURL                = ces2.SectionURL
	,SecondarySectionURLLabel           = ces2.SectionURLLabel
	,PrimaryFacilityReference           = ces1.FacilityReference
	,PrimarySectionInceptionDate        = ces1.InceptionDate
	,PrimarySectionExpiryDate           = ces1.ExpiryDate
	,OriginalSigningDate                = CASE WHEN c.HasSCMData = 1 THEN ce.OriginalSigningDate ELSE COALESCE(ce.OriginalSigningDate, ces1.FacilityEarliestLPSOPremiumSigningDate, ces1.EarliestLPSOPremiumSigningDate) END
	,OriginalSigningNumber              = CASE WHEN c.HasSCMData = 1 THEN ce.OriginalSigningNumber ELSE CAST(COALESCE(ce.OriginalSigningNumber, CAST(ces1.FacilityEarliestLPSOPremiumSigningNumber as NVARCHAR(255)), CAST(ces1.EarliestLPSOPremiumSigningNumber AS NVARCHAR(255))) AS NVARCHAR(255)) END
	,IsMultiSection                     = CASE WHEN ces2.FK_ClaimExposure IS NOT NULL THEN 1 ELSE 0 END
	,PolicyLeaderPseudonym              = ces1.LeaderPseudonym     
	,FK_PrimaryTriFocus                 = COALESCE(ces1.FK_TriFocus,0) 
	,PrimaryPolicyYOA                   = ces1.YOA
	,FK_PrimaryClassOfBusiness          = COALESCE(ces1.FK_ClassOfBusiness,0)
	,PrimaryCoverageName                = ces1.CoverageName
	,SecondaryCoverageName              = ces2.CoverageName
	--,PrimarySectionAgressoReference     = ces1.AgressoReference
	,FK_PrimaryUnderwriter              = COALESCE(ces1.FK_Underwriter, 0)
	,IsBeazleyLead                      = ISNULL(ces1.IsBeazleyLead, 0)
	--,USUnderwritingCoverageCode         = ces1.USUnderwritingCoverageCode
	,PrimaryInsuredState                = ces1.InsuredState
	,IsNewYorkFreeTradeZone             = ISNULL(ces1.IsNewYorkFreeTradeZone, 0)
	,LinkedSynergySection               = ces1.LinkedSynergySection
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
LEFT OUTER JOIN #ClaimExposureSection ces1 ON
ce.PK_ClaimExposure = ces1.FK_ClaimExposure 
AND ces1.SequenceId = 1
LEFT OUTER JOIN #ClaimExposureSection ces2 ON
ce.PK_ClaimExposure = ces2.FK_ClaimExposure 
AND ces2.SequenceId = 2


-- BI-7030
UPDATE ce SET
	PrimaryPolicyReference              = ces1.PolicyReference
	,PrimarySectionReference            = ces1.SectionReference 
	,PrimarySectionURL                  = ces1.SectionURL 
	,PrimarySectionURLLabel             = ces1.SectionURLLabel 
	,SecondaryPolicyReference           = ces2.PolicyReference
	,SecondarySectionReference          = CASE WHEN ce.SecondarySectionReference IS NULL THEN ces2.SectionReference ELSE ce.SecondarySectionReference END
	,SecondarySectionURL                = CASE WHEN ce.SecondarySectionURL IS NULL THEN ces2.SectionURL  ELSE ces2.SectionURL END
	,SecondarySectionURLLabel           = CASE WHEN ce.SecondarySectionURLLabel IS NULL THEN ces2.SectionURLLabel ELSE ces2.SectionURLLabel END
	,PrimaryFacilityReference           = ces1.FacilityReference 
	,PrimarySectionInceptionDate        = ces1.InceptionDate
	,PrimarySectionExpiryDate           = ces1.ExpiryDate
	,IsMultiSection                     = CASE WHEN ces2.FK_ClaimExposure IS NOT NULL THEN 1 ELSE 0 END
	,FK_PrimaryTriFocus                 = COALESCE(ces1.FK_TriFocus,0)
	,PrimaryPolicyYOA                   = ces1.YOA 
	,FK_PrimaryClassOfBusiness          = COALESCE(ces1.FK_ClassOfBusiness,0)
	,PrimaryCoverageName                = ces1.CoverageName
	,SecondaryCoverageName              = CASE WHEN ce.SecondaryCoverageName IS NULL THEN ces2.CoverageName ELSE ce.SecondaryCoverageName END
	,FK_PrimaryUnderwriter              = COALESCE(ces1.FK_Underwriter, 0)
	,PrimaryInsuredState                = ces1.InsuredState
	,LinkedSynergySection               = ces1.LinkedSynergySection
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
LEFT OUTER JOIN #ClaimExposureSection ces1 ON
ce.PK_ClaimExposure = ces1.FK_ClaimExposure 
AND ces1.SplitLinesSequenceId = 1
LEFT OUTER JOIN #ClaimExposureSection ces2 ON
ce.PK_ClaimExposure = ces2.FK_ClaimExposure 
AND ces2.SequenceId = 2
WHERE ces1.SplitLinesSequenceId is not null


/*For closed SCM claims, set the closed date to the movement banding date (and to NULL for open exposures)*/
UPDATE ce SET
ExposureClosedDate        = CASE WHEN ce.ExposureStatus = 'Closed'		
								 THEN COALESCE(ce.ExposureClosedDate,ce.LastMovementBandingDate)
                            ELSE NULL
                            END
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
WHERE c.HasSCMData = 1

UPDATE c SET
ClaimClosedDate          = CASE WHEN ce.ExposureStatus = 'Closed'
							    THEN COALESCE(c.ClaimClosedDate, ce.LastMovementBandingDate)
                            ELSE NULL  
                            END
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Claim c ON 
ce.FK_Claim = c.PK_Claim
WHERE c.HasSCMData = 1 
AND c.HasRealExposures = 0

 /*For closed manual exposures, set the closed date to the existing closed date from CC if it exists, otherwise to the last movement for banding date.*/
UPDATE ce SET
ExposureClosedDate        = CASE WHEN ce.ExposureStatus = 'Closed'
                                 THEN COALESCE(ce.ExposureClosedDate,ce.LastMovementBandingDate) 
                            ELSE NULL
                           END
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
WHERE 
c.HasSCMData = 0

                     
/*For closed manual claims, set the closed date to the existing closed date from CC if it exists, otherwise to the last movement for banding date.*/
UPDATE c SET
ClaimClosedDate         = CASE WHEN ce.ExposureStatus = 'Closed'
                               THEN COALESCE(ce.ExposureClosedDate,ce.LastMovementBandingDate) 
                           ELSE NULL
                          END
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
WHERE
c.HasSCMData = 0
AND c.HasRealExposures = 0


 /*Medicare indicator*/
 /*Criteria agreed by Leo Imrie with Dara Mason on 26/5/2011 as follows:
 
    Add a field called 'Medicare Indicator', which is set to 'Yes' if the following conditions are met:
    
    The claim has a payment transaction on or after January 1st 2010
    AND
    (
        (MediPay indicator is set)
        OR
        (The Beazley CAT Code OR the Market CAT Code is 'MEDI')
        OR
        (
            Bodily Death Emotional Indicator = 'Yes'
            AND Indemnity Or Defense = 'Defence'
            AND Claim Or Circumstance = 'Claim'
            AND Loss Country = 'United States'
        )
    )
*/

UPDATE ce SET
MedicareIndicator   =   CASE
                           -- WHEN ce.MedipayIndicator = 1 THEN 1   --- maybe for phase 2
                            WHEN ce.MarketCatCode = 'MEDI' THEN 1
                            WHEN ce.BeazleyCatCode = 'MEDI' THEN 1
                            WHEN ce.BodilyDeathEmotionalIndicator = 1
                                AND ce.ClaimOrCircumstance = 'Claim'
                                AND ce.LossLocationCountry = 'United States'
                            THEN 1
                            ELSE 0
                        END
FROM ODS.ClaimExposure ce
WHERE EXISTS
			(
				SELECT 
				 1 
				FROM ODS.ClaimMovement cm 
				WHERE cm.FK_ClaimExposure = ce.PK_ClaimExposure
					AND cm.MovementDate >= '1/1/2010'
					AND
					(
						cm.MovementPaidDefenceInOriginalCCY <> 0
						OR cm.MovementPaidFeesInOriginalCCY <> 0
						OR cm.MovementPaidIndemnityInOriginalCCY <> 0
					)
			)
    

-- Update ClaimMovementEstimateAsAtCloseDate column in the Claim table, this is the closest estimate movement when the claim closed
UPDATE ce
SET ce.FK_ClaimEstimateAsAtCloseDate = claimes.PK_ClaimEstimate  
   
FROM   ODS.ClaimExposure ce

CROSS APPLY (
             SELECT TOP 1 claimes.PK_ClaimEstimate
             FROM ODS.ClaimEstimate claimes
             WHERE     claimes.FK_ClaimExposure = ce.PK_ClaimExposure
                   AND claimes.FK_CreateDate <= ce.FK_ExposureClosedDate --Use the keys to pick up everything on the same day, regardless of time
             ORDER BY claimes.CreateDate DESC
                     
             ) claimes
             
WHERE ce.ExposureClosedDate IS NOT NULL   

/*Has paid/incurred/os/estimates flags, quantified status and most likely vs. incurred*/
UPDATE ce 
SET
	HasOutstanding                  = x.HasOutStanding
	,HasPaid                        = x.HasPaid
	,HasIncurred                    = x.HasIncurred
	,HasMostLikely                  = x.HasMostLikely
	,HasPessimistic                 = x.HasPessimistic
	,HasBlendWeightingMultiplier    = x.HasBlendWeightingMultiplier
 -- ,FK_QuantifiedStatus            = qs.PK_ClaimQuantifiedStatus    -- marked as removed in V9

FROM ODS.ClaimExposure ce

INNER JOIN
(
    SELECT
		PK_ClaimExposure                = ce.PK_ClaimExposure
		,HasOutStanding                 = CASE WHEN ABS(os.TotalOutstandingInSettlementCCY) > 1  THEN 1 ELSE 0 END
		,HasPaid                        = CASE WHEN ABS(p.TotalPaidInSettlementCCY) > 1          THEN 1 ELSE 0 END
		,HasIncurred                    = CASE WHEN ABS(os.TotalOutstandingInSettlementCCY + p.TotalPaidInSettlementCCY) > 1   
																									THEN 1 ELSE 0 END                   
		,HasMostLikely                  = CASE WHEN e.MostLikelyOriginalCCY IS NOT NULL             THEN 1 ELSE 0 END
		,HasPessimistic                 = CASE WHEN e.PessimisticOriginalCCY IS NOT NULL            THEN 1 ELSE 0 END
		,HasBlendWeightingMultiplier    = CASE WHEN ISNULL(e.BlendWeightingMultiplier, 0) <> 0      THEN 1 ELSE 0 END
		--,QuantifiedStatusCode           = CASE
		--									WHEN ce.Reviewed <> 'Quantified' THEN 'N/A' --Not quantified
		--									WHEN ce.MultipleOriginalCCYIndicator = 1 THEN 'N/A' --Multi orig ccy
		--									WHEN e.PessimisticOriginalCCY IS NULL --Pessimistic IS NULL 
		--										 AND (e.MostLikelyOriginalCCY IS NOT NULL AND 
		--										 ABS(p.TotalPaidInOriginalCCY + os.TotalOutstandingInOriginalCCY - e.MostLikelyOriginalCCY) > 1) -- Pre Peer Most likely <> Incurred
		--									THEN 'D'
		--									WHEN e.PessimisticOriginalCCY IS NOT NULL
		--										 AND (e.MostLikelyOriginalCCY IS NOT NULL AND
		--										 ABS(p.TotalPaidInOriginalCCY + os.TotalOutstandingInOriginalCCY - e.MostLikelyOriginalCCY) > 1) -- Pre Peer Most likely <> Incurred
		--									THEN 'C'
		--									WHEN e.PessimisticOriginalCCY IS NULL
		--									THEN 'B'
		--									ELSE 'A'
		--								  END
    FROM ODS.ClaimExposure ce
    -- PAID
    INNER JOIN
    (   
        SELECT   
        FK_ClaimExposure            = cm.FK_ClaimExposure
        ,TotalPaidInOriginalCCY     = SUM(cm.MovementPaidDefenceInOriginalCCY)
                                        + SUM(cm.MovementPaidIndemnityInOriginalCCY)
                                        + SUM(cm.MovementPaidFeesInOriginalCCY)
        ,TotalPaidInSettlementCCY   = SUM(CASE 
											WHEN cm.PaidOriginalCCYToSettlementCCYRate= 0 then 0 
											ELSE cm.MovementPaidDefenceInOriginalCCY/cm.PaidOriginalCCYToSettlementCCYRate
										 END)
                                        + SUM(CASE 
											WHEN cm.PaidOriginalCCYToSettlementCCYRate= 0 then 0 
											ELSE cm.MovementPaidIndemnityInOriginalCCY/cm.PaidOriginalCCYToSettlementCCYRate
										 END)
                                        + SUM(CASE 
											WHEN cm.PaidOriginalCCYToSettlementCCYRate= 0 then 0 
											ELSE cm.MovementPaidFeesInOriginalCCY/cm.PaidOriginalCCYToSettlementCCYRate
										 END)
        FROM
        ODS.ClaimMovement cm
        GROUP BY 
        cm.FK_ClaimExposure
    )  p
    ON ce.PK_ClaimExposure = p.FK_ClaimExposure
    -- OUTSTANDING          
    INNER JOIN 
    (

        SELECT   
        FK_ClaimExposure                    =    ce.PK_ClaimExposure
         ,TotalOutstandingInOriginalCCY     =    (cm.ToDateOutstandingDefenceInOriginalCCY)
                                                        + (ToDateOutstandingFeesInOriginalCCY)
                                                        + (ToDateOutstandingIndemnityInOriginalCCY)

        ,TotalOutstandingInSettlementCCY    =    (cm.ToDateOutstandingDefenceInOriginalCCY/cm.OutstandingOriginalCCYToSettlementCCYRate)
                                                        + (ToDateOutstandingFeesInOriginalCCY/cm.OutstandingOriginalCCYToSettlementCCYRate)
                                                        + (ToDateOutstandingIndemnityInOriginalCCY/cm.OutstandingOriginalCCYToSettlementCCYRate)
        FROM     
        ODS.ClaimExposure ce
        INNER JOIN 
        ODS.ClaimMovement cm
        ON ce.FK_LastMovement = cm.PK_ClaimMovement
    ) os
    ON ce.PK_ClaimExposure = os.FK_ClaimExposure
    LEFT OUTER JOIN
    ODS.ClaimEstimate e ON
    ce.PK_ClaimExposure = e.FK_ClaimExposure
    AND e.ReverseSequenceID = 1
) x 
ON ce.PK_ClaimExposure = x.PK_ClaimExposure

--INNER JOIN ODS.ClaimQuantifiedStatus qs 
--ON x.QuantifiedStatusCode = qs.QuantifiedStatusCode

/*ExposureFeesOnlyEntry*/
UPDATE ce 
SET     
	FeesOnlyEntry          =   CASE 
									WHEN ce.LastMovementFeesOnlyEntry = 1 OR c.ClaimNarrative LIKE '%fee%only%entry%' THEN 1 
                                    ELSE 0 
                                END
FROM ODS.ClaimExposure ce

INNER JOIN ODS.Claim c
ON ce.FK_Claim = c.PK_Claim

/*FK_GQDTransactionType*/

/*OSN&D where LPSO transaction doesn't exist*/
UPDATE ce 
SET         OriginalSigningDate     = ISNULL(ces1.FacilityEarliestLPSOPremiumSigningDate, ces1.EarliestLPSOPremiumSigningDate)
           ,OriginalSigningNumber   = CAST(ISNULL(ces1.FacilityEarliestLPSOPremiumSigningNumber, ces1.EarliestLPSOPremiumSigningNumber) AS NVARCHAR(255))

FROM ODS.ClaimExposure ce

INNER JOIN ODS.Claim c 
ON ce.FK_Claim = c.PK_Claim

INNER JOIN #ClaimExposureSection ces1 
ON ce.PK_ClaimExposure = ces1.FK_ClaimExposure
	AND ces1.SequenceId = 1

WHERE c.HasSCMData = 1 
AND
	(
		ce.OriginalSigningDate IS NULL 
		OR ce.OriginalSigningNumber IS NULL 
		OR NOT EXISTS (
							SELECT 1 
							FROM   ODS.LPSOTransaction lt 
							WHERE  ce.OriginalSigningDate = lt.SigningDate 
								   AND ce.OriginalSigningNumber = CAST(lt.SigningNumber as nvarchar(255))
						)
	)

-- Update key from LPSO transaction
UPDATE      ce 
SET         FK_GQDTransactionType          = lt.FK_GQDTransactionType
FROM        ODS.ClaimExposure ce

INNER JOIN  ODS.LPSOTransaction lt 
ON  ce.OriginalSigningDate = lt.SigningDate
    AND ce.OriginalSigningNumber =  CAST(lt.SigningNumber as nvarchar(255))

WHERE       lt.FK_GQDTransactionType <> 0

/* Commented block as there is no need anymore the link between movements and limits. For V9 all the reports will be rebuilded
--Update claim authority limit key in claim mov table
UPDATE claimmov 

SET claimmov.FK_ClaimAuthorityLimit = ISNULL(claimauth.PK_ClaimAuthorityLimit,0)

FROM ODS.ClaimMovement claimmov

INNER JOIN ODS.ClaimExposure ce
ON claimmov.FK_ClaimExposure=ce.PK_ClaimExposure   

LEFT OUTER JOIN ODS.ClaimAuthorityLimit claimauth 
ON  claimmov.PrimaryExaminerOrCreateUserId = claimauth.ClaimCenterUserId
AND ce.FK_PrimaryClassOfBusiness=claimauth.FK_ClassOfBusiness
*/

-- Update ClaimMovementAsAtCloseDate column in the ClaimExposure table, this is the closest movement when the claim closed
UPDATE ce

SET FK_ClaimMovementAsAtCloseDate = claimmov.PK_ClaimMovement  
   
FROM   ODS.ClaimExposure ce

CROSS APPLY (
             SELECT TOP 1 claimov.PK_ClaimMovement
             FROM ODS.ClaimMovement claimov
             WHERE     claimov.FK_ClaimExposure = ce.PK_ClaimExposure
                   AND claimov.FK_MovementPeriod <= ce.ExposureClosedDate
             ORDER BY  claimov.FK_MovementPeriod DESC, claimov.MovementGroupSequenceId DESC, claimov.PK_ClaimMovement
             ) claimmov
             
WHERE ce.ExposureClosedDate IS NOT NULL


/*Update first most likely date*/
UPDATE ce 
SET
	FirstMostLikelyEnteredDate  = x.FirstDate
FROM ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
		FK_ClaimExposure        = e.FK_ClaimExposure
		,FirstDate              = MIN(e.CreateDate)
    FROM ODS.ClaimEstimate e

    WHERE e.MostLikelyOriginalCCY IS NOT NULL

    GROUP BY e.FK_ClaimExposure
) x ON
ce.PK_ClaimExposure = x.FK_ClaimExposure

/*Update first pessimistic date*/
UPDATE ce 
SET
	FirstPessimisticEnteredDate  = x.FirstDate
FROM ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
		FK_ClaimExposure        = e.FK_ClaimExposure
		,FirstDate              = MIN(e.CreateDate)
    FROM ODS.ClaimEstimate e

    WHERE e.PessimisticOriginalCCY IS NOT NULL

    GROUP BY e.FK_ClaimExposure
) x ON
ce.PK_ClaimExposure = x.FK_ClaimExposure

/*Update first blend weighting date*/
UPDATE ce 
SET
	FirstBlendWeightingMultiplierEnteredDate  = x.FirstDate
FROM ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
		FK_ClaimExposure        = e.FK_ClaimExposure
		,FirstDate              = MIN(e.CreateDate)
    FROM ODS.ClaimEstimate e

    WHERE e.PessimisticOriginalCCY IS NOT NULL

    GROUP BY e.FK_ClaimExposure
) x ON
ce.PK_ClaimExposure = x.FK_ClaimExposure

/*Update "months since" fields*/
UPDATE ce SET
--MonthsSinceMostLikelyEntered                    = CASE 
--                                                    WHEN DATEDIFF(DAY, ce.FirstMostLikelyEnteredDate, Utility.udf_AsAtDate()) < 0 THEN NULL
--                                                    ELSE CAST(DATEDIFF(DAY, ce.FirstMostLikelyEnteredDate, Utility.udf_AsAtDate()) AS numeric(19,4)) / 30.5
--                                                  END
--,MonthsSincePessimisticEntered                  = CASE 
--                                                    WHEN DATEDIFF(DAY, ce.FirstPessimisticEnteredDate, Utility.udf_AsAtDate()) < 0 THEN NULL
--                                                    ELSE CAST(DATEDIFF(DAY, ce.FirstPessimisticEnteredDate, Utility.udf_AsAtDate()) AS numeric(19,4)) / 30.5
--                                                  END
--,MonthsSinceBlendWeightingMultiplierEntered     = CASE 
--                                                    WHEN DATEDIFF(DAY, ce.FirstBlendWeightingMultiplierEnteredDate, Utility.udf_AsAtDate()) < 0 THEN NULL
--                                                    ELSE CAST(DATEDIFF(DAY, ce.FirstBlendWeightingMultiplierEnteredDate, Utility.udf_AsAtDate()) AS numeric(19,4)) / 30.5
--                                                  END
--,
MonthsSinceExposureOpened                      = CASE 
                                                    WHEN DATEDIFF(DAY, ce.ExposureOpenedDate, GETDATE()) < 0 THEN NULL
                                                    ELSE CAST(DATEDIFF(DAY, ce.ExposureOpenedDate, GETDATE()) AS numeric(19,4)) / 30.5
                                                  END
FROM ODS.ClaimExposure ce



/*Update bandings*/
UPDATE ce SET
	--MonthsSinceMostLikelyEnteredBandKey                     = b_ml.BandMin
	--,MonthsSinceMostLikelyEnteredBand                       = ISNULL(b_ml.BandName, 'N/A')
	--,MonthsSincePessimisticEnteredBandKey                   = b_pess.BandMin
	--,MonthsSincePessimisticEnteredBand                      = ISNULL(b_pess.BandName, 'N/A')
	--,MonthsSinceBlendWeightingMultiplierEnteredBandKey      = b_bw.BandMin
	--,MonthsSinceBlendWeightingMultiplierEnteredBand         = ISNULL(b_bw.BandName, 'N/A')
	--,MonthsInNotReviewedBandKey                             = b_nr.BandMin
	--,MonthsInNotReviewedBand                                = ISNULL(b_nr.BandName, 'N/A')
	--,MonthsInInitialEstimateBandKey                         = b_ie.BandMin
	--,MonthsInInitialEstimateBand                            = ISNULL(b_ie.BandName, 'N/A')
	--,MonthsInQuantifiedBandKey                              = b_q.BandMin
	--,MonthsInQuantifiedBand                                 = ISNULL(b_q.BandName, 'N/A')
	--,
	MonthsSinceExposureOpenedBandKey                       = b_eo.BandMin
	,MonthsSinceExposureOpenedBand                          = ISNULL(b_eo.BandName, 'N/A')
FROM ODS.ClaimExposure ce

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_ml 
--ON ce.MonthsSinceMostLikelyEntered >= b_ml.BandMin
--	AND ce.MonthsSinceMostLikelyEntered < b_ml.BandMax

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_pess 
--ON ce.MonthsSincePessimisticEntered >= b_pess.BandMin
--	AND ce.MonthsSincePessimisticEntered < b_pess.BandMax

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_bw 
--ON ce.MonthsSinceBlendWeightingMultiplierEntered >= b_bw.BandMin
--	AND ce.MonthsSinceBlendWeightingMultiplierEntered < b_bw.BandMax

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_nr 
--ON ce.MonthsInNotReviewed >= b_nr.BandMin
--	AND ce.MonthsInNotReviewed < b_nr.BandMax

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_ie 
--ON ce.MonthsInInitialEstimate >= b_ie.BandMin
--	AND ce.MonthsInInitialEstimate < b_ie.BandMax

--LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_q 
--ON ce.MonthsInQuantified >= b_q.BandMin
--	AND ce.MonthsInQuantified < b_q.BandMax

LEFT OUTER JOIN Staging_MDS.MDS_Staging.MovementDurationBand b_eo 
ON ce.MonthsSinceExposureOpened >= b_eo.BandMin
	AND ce.MonthsSinceExposureOpened < b_eo.BandMax


/*
Update underlying insured - take the following values in order:

SCM Insured for binders and lineslips
Exposure Insured
Insured Party from section reference
Original insured from SCM narrative for Treaty SCMs

*/
UPDATE ce SET
UnderlyingInsured       = LEFT(CASE
                            WHEN p.MethodOfPlacementCode IN ('B', 'L') THEN COALESCE(ce.InsuredSCMName, ce.InsuredName, p.InsuredParty)
                            ELSE ISNULL(ce.InsuredName, p.InsuredParty)
                          END, 255)
,ce.RiskClass = s.RiskClass
,ce.RiskClassCode = s.RiskClassCode
FROM
ODS.ClaimExposure ce
INNER JOIN 
ODS.ClaimExposureSection ces ON 
ce.PK_ClaimExposure = ces.FK_ClaimExposure

INNER JOIN
ODS.Section s ON
ces.FK_Section = s.PK_Section  --ce.PrimarySectionReference = s.SectionReference
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
 

UPDATE ce 
SET
	UnderlyingInsured = LEFT(LTRIM(RIGHT(c.ClaimNarrative, LEN(c.ClaimNarrative) - Utility.udf_CharIndexLastInstance('O/I', c.ClaimNarrative) - 2)), 255)
FROM ODS.ClaimExposure ce

INNER JOIN ODS.Claim c 
ON ce.FK_Claim = c.PK_Claim

INNER JOIN ODS.TriFocus tf 
ON ce.FK_PrimaryTriFocus = tf.PK_TriFocus

WHERE  c.HasSCMData = 1
	AND tf.DepartmentName = 'Treaty'
	AND c.ClaimNarrative LIKE ('%O/I%')

--BI-3366 Reactivate StackingAggregate as it was in v5
/*Stack claims*/

/*
Set the grouping types.
There are 4 different types:
    1 - Program link + AGG qualifier
    2 - Agg qualifier and no program link
    3 - Prog link and no AGG qualifier
    4 - All others
*/

UPDATE ce SET
StackingAggregateType           = 1
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NOT NULL
AND (s.LimitQualifier = 'AGG' OR s.EventLimitQualifier = 'AGG')

UPDATE ce SET
StackingAggregateType           = 2
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NULL
AND (s.LimitQualifier = 'AGG' OR s.EventLimitQualifier = 'AGG')
AND ce.StackingAggregateType IS NULL

UPDATE ce SET
StackingAggregateType           = 3
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NOT NULL
AND ISNULL(s.LimitQualifier, '') <> 'AGG'
AND ce.StackingAggregateType IS NULL

UPDATE ce SET
StackingAggregateType           = 4
FROM 
ODS.ClaimExposure ce
WHERE 
ce.StackingAggregateType IS NULL

/*Create the aggregate groupings*/

/*Group 1 - group by program number, TriFocus and YOA, and underlying insured*/
UPDATE ce SET
StackingAggregateReference = '1_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                    (
                                        ORDER BY
                                        s.ProgramNumber
                                        ,tf.TriFocusName
                                        ,s.FK_YOA
                                        ,ce.UnderlyingInsured
                                    )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    INNER JOIN
    ODS.TriFocus tf ON
    s.FK_TriFocus = tf.PK_TriFocus
    WHERE
    ce.StackingAggregateType = 1
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 2 - group by section ref and underlying insured
UPDATE ce SET
StackingAggregateReference = '2_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                        (
                                            ORDER BY
                                            s.SectionReference
                                            ,ce.UnderlyingInsured
                                        )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    WHERE
    ce.StackingAggregateType = 2
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 3 - group by program number, TriFocus, YOA and claimant, and underlying insured
--Do not group NULL/empty claimants
UPDATE ce SET
StackingAggregateReference = '3_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                        (
                                            ORDER BY
                                            s.ProgramNumber
                                            ,tf.TriFocusName
                                            ,s.FK_YOA
                                            ,CASE 
                                                WHEN ISNULL(ce.ClaimantName, '') = '' THEN CAST(ce.PK_ClaimExposure as varchar(50))
                                                ELSE ce.ClaimantName 
                                            END
                                            ,ce.UnderlyingInsured
                                        )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    INNER JOIN
    ODS.TriFocus tf ON
    s.FK_TriFocus = tf.PK_TriFocus
    WHERE
    ce.StackingAggregateType = 3
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 4 - by exposure
UPDATE ce SET
StackingAggregateReference = '4_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER (ORDER BY ce.ExposureReference)
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    WHERE
    ce.StackingAggregateType = 4
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure
	
--BI-3366 Reactivate StackingAggregate as it was in v5
/*Stack claims*/

/*
Set the grouping types.
There are 4 different types:
    1 - Program link + AGG qualifier
    2 - Agg qualifier and no program link
    3 - Prog link and no AGG qualifier
    4 - All others
*/

UPDATE ce SET
StackingAggregateType           = 1
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NOT NULL
AND (s.LimitQualifier = 'AGG' OR s.EventLimitQualifier = 'AGG')

UPDATE ce SET
StackingAggregateType           = 2
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NULL
AND (s.LimitQualifier = 'AGG' OR s.EventLimitQualifier = 'AGG')
AND ce.StackingAggregateType IS NULL

UPDATE ce SET
StackingAggregateType           = 3
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
WHERE
s.ProgramNumber IS NOT NULL
AND ISNULL(s.LimitQualifier, '') <> 'AGG'
AND ce.StackingAggregateType IS NULL

UPDATE ce SET
StackingAggregateType           = 4
FROM 
ODS.ClaimExposure ce
WHERE 
ce.StackingAggregateType IS NULL

/*Create the aggregate groupings*/

/*Group 1 - group by program number, TriFocus and YOA, and underlying insured*/
UPDATE ce SET
StackingAggregateReference = '1_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                    (
                                        ORDER BY
                                        s.ProgramNumber
                                        ,tf.TriFocusName
                                        ,s.FK_YOA
                                        ,ce.UnderlyingInsured
                                    )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    INNER JOIN
    ODS.TriFocus tf ON
    s.FK_TriFocus = tf.PK_TriFocus
    WHERE
    ce.StackingAggregateType = 1
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 2 - group by section ref and underlying insured
UPDATE ce SET
StackingAggregateReference = '2_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                        (
                                            ORDER BY
                                            s.SectionReference
                                            ,ce.UnderlyingInsured
                                        )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    WHERE
    ce.StackingAggregateType = 2
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 3 - group by program number, TriFocus, YOA and claimant, and underlying insured
--Do not group NULL/empty claimants
UPDATE ce SET
StackingAggregateReference = '3_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER
                                        (
                                            ORDER BY
                                            s.ProgramNumber
                                            ,tf.TriFocusName
                                            ,s.FK_YOA
                                            ,CASE 
                                                WHEN ISNULL(ce.ClaimantName, '') = '' THEN CAST(ce.PK_ClaimExposure as varchar(50))
                                                ELSE ce.ClaimantName 
                                            END
                                            ,ce.UnderlyingInsured
                                        )
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    INNER JOIN
    ODS.TriFocus tf ON
    s.FK_TriFocus = tf.PK_TriFocus
    WHERE
    ce.StackingAggregateType = 3
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

--Group 4 - by exposure
UPDATE ce SET
StackingAggregateReference = '4_' + REPLICATE('0', 6 - LEN(x.AggrefInt)) + CAST(x.AggRefInt AS varchar(6))
FROM
ODS.ClaimExposure ce
INNER JOIN
(
    SELECT
    PK_ClaimExposure            = ce.PK_ClaimExposure
    ,AggRefInt                  = DENSE_RANK() OVER (ORDER BY ce.ExposureReference)
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.Section s ON
    ce.PrimarySectionReference = s.SectionReference
    WHERE
    ce.StackingAggregateType = 4
) x ON
ce.PK_ClaimExposure = x.PK_ClaimExposure

/*
Linked SCM
For manual exposures for BUSA policies, we need to set a linked SCM ref. The SCM blocks are
against the binder/linked dec and split by US state. We try to locate the corresponding SCM against the 
binder/linked dec by checking against the "TrustFundStateCode" field and comparing it to the US state of the
broker against the underlying policy to which the claim attaches
*/

UPDATE ce SET
LinkedSCMReference              = ce_scm.SCMReference
,LinkedSCMOriginatingBureau     = ce_scm.OriginatingBureau
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
INNER JOIN
ODS.Section s ON 
ce.PrimarySectionReference = s.SectionReference
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
(
    SELECT
    SectionReference            = s.SectionReference
    ,StateCode                  = ce.LossLocationStateCode   -- ce.PrimaryInsuredState
    ,FK_ClaimExposure           = ce.PK_ClaimExposure
    ,SequenceId                 = ROW_NUMBER() OVER (PARTITION BY s.SectionReference, ce.LossLocationStateCode
                                                    ORDER BY ce.ExposureOpenedDate ASC, ce.SCMReference ASC)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.ClaimExposureSection ces ON
    s.PK_Section = ces.FK_Section
    INNER JOIN
    ODS.ClaimExposure ce ON
    ces.FK_ClaimExposure = ce.PK_ClaimExposure
    INNER JOIN
    ODS.Claim c ON
    ce.FK_Claim = c.PK_Claim
    WHERE
    ce.LossLocationStateCode IS NOT NULL
    AND c.HasSCMData = 1
) x ON
COALESCE(ce.LinkedSynergySection,ce.PrimaryFacilityReference) = x.SectionReference
AND p.Address2 = x.StateCode --Insured address = trust fund state code
AND x.SequenceId = 1
INNER JOIN
ODS.ClaimExposure ce_scm ON
x.FK_ClaimExposure = ce_scm.PK_ClaimExposure
WHERE
p.SourceSystem = 'BeazleyPro'
AND c.HasSCMData = 0
AND s.CarrierIndicator IN ('BUSA', 'BUSB')


UPDATE ce SET
LinkedSCMReference              = scm.LinkedSCMReference
,LinkedSCMOriginatingBureau     = 'N' --Always N, "A" originating bureau references don't get in-housed
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
INNER JOIN 
Staging_MDS.MDS_Staging.linkedSCMReference scm on 
ce.ExposureReference = scm.ExposureReference
INNER JOIN 
ODS.Section s ON 
ce.PrimarySectionReference = s.SectionReference
WHERE
c.HasSCMData = 0
AND s.CarrierIndicator NOT IN ( 'BUSA', 'BUSB' )


UPDATE ce SET
LinkedSCMOriginalSigningDate        = ce_scm.OriginalSigningDate
,LinkedSCMOriginalSigningNumber     = ce_scm.OriginalSigningNumber
,LinkedSCMTrustFundStateCode        = ce_scm.TrustFundStateCode
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.ClaimExposure ce_scm ON
ce.LinkedSCMReference = ce_scm.SCMReference
AND ce.LinkedSCMOriginatingBureau = ce_scm.OriginatingBureau


/*If we still don't have an OSN&D, try the binder, then the policy*/
UPDATE ce SET
LinkedSCMOriginalSigningDate        = COALESCE(f.EarliestLPSOPremiumSigningDate, s.EarliestLPSOPremiumSigningDate)
,LinkedSCMOriginalSigningNumber     = CAST(COALESCE(f.EarliestLPSOPremiumSigningNumber, s.EarliestLPSOPremiumSigningNumber) AS NVARCHAR(255))
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
INNER JOIN
ODS.Section s ON
ce.PrimarySectionReference = s.SectionReference
LEFT OUTER JOIN
ODS.Section f ON
s.FK_Facility = f.PK_Section
WHERE
c.InHouseClaimIndicator = 1
AND s.CarrierIndicator = 'Non US carrier'
AND c.HasSCMData = 0
AND ce.LinkedSCMOriginalSigningDate IS NULL
AND ce.LinkedSCMOriginalSigningNumber IS NULL


/*Update ExposureHasMovements with 0 if the exposure has only Dummy movements and 1 if at least one not Dummy movement exists*/
UPDATE ce
SET ExposureHasMovements = CASE WHEN NoNotDummy is null THEN 0 ELSE 1 END

FROM ODS.ClaimExposure ce
LEFT JOIN
(SELECT FK_ClaimExposure, count(*) NoNotDummy
FROM ODS.ClaimMovement cm 
WHERE MovementReference != 'DUMMY MOVEMENT'
GROUP BY FK_ClaimExposure) D
ON ce.PK_ClaimExposure = d.FK_ClaimExposure


/* Update ECFEntryWithoutSCM with 1 when the following criteria are met:  
    Payment Channel (Or AccountingCalendar in SQL) = Lloyd’s Finance; 
    UCR is not null or blank
	SCM is null or blank */
--UPDATE ce
--SET [ECFEntryWithoutSCM] = CASE WHEN (LEN(RTRIM(ISNULL(c.UCR, ''))) > 0 OR LEN(RTRIM(ISNULL(ce.UniqueClaimReference, ''))) > 0) 
--                                 AND LEN(RTRIM(ISNULL(ce.SCMReference, ''))) = 0 
--		   					  	 AND ac.AccountingCalendarName  = 'Lloyd’s Finance' THEN 1 ELSE 0 END
--FROM ODS.ClaimExposure ce
--INNER JOIN ODS.Claim c ON c.PK_Claim=ce.FK_Claim
--INNER JOIN ODS.AccountingCalendar ac ON ac.PK_AccountingCalendar=c.FK_AccountingCalendar


/* Update IsBeazleyLead with 1 for the claims that have SourceSystem ='ClaimCenter' in ODS.Section  BI-6313*/
UPDATE ce
SET IsBeazleyLead = 1
FROM ODS.ClaimExposure ce
INNER JOIN ODS.Section s ON s.SectionReference = ce.PrimarySectionReference
WHERE SourceSystem ='ClaimCenter' 

/*Update last movement line multiplier BI-6321*/
UPDATE ce SET
LastBureauShare = ISNULL(cmov.BureauShare/100, 1)
FROM
ODS.ClaimExposure ce
LEFT OUTER JOIN
(
	SELECT
	cm.PK_ClaimMovement                                    AS PK_ClaimMovement
	,ISNULL(NULLIF(SUM(cm.BureauShare),0),1)               AS BureauShare
	FROM
	ODS.ClaimMovement cm
	GROUP BY
	PK_ClaimMovement
) cmov ON
ce.FK_LastMovement = cmov.PK_ClaimMovement

                                                      
/***********************************************************************************************************/
/*                               Drop temp tables used in this stored procedure                          */
/***********************************************************************************************************/
IF (OBJECT_ID('tempdb..#ClaimExposureSection')) IS NOT NULL  DROP TABLE #ClaimExposureSection
IF (OBJECT_ID('tempdb..#ClaimExposureSectionPartition'))  IS NOT NULL DROP TABLE #ClaimExposureSectionPartition    
IF (OBJECT_ID('tempdb..#TBA'))  IS NOT NULL DROP TABLE #TBA