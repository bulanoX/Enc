﻿
CREATE PROCEDURE [ODS].[usp_LoadPartyBroker]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.PartyBroker
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


DROP TABLE IF EXISTS #PartyBroker

CREATE TABLE #PartyBroker(
	[IsUnknownMember] [bit] NOT NULL DEFAULT (0),
	[BrokerNumber] [int] NULL,
	[OriginalBrokerNumber] [int] NULL,
	[BrokerName] [varchar](255) NULL,
	[BrokerPseudonym] [varchar](255) NULL,
	[GroupNumber] [int] NOT NULL,
	[GroupName] [varchar](255) NOT NULL,
	[BrokerCountry] [varchar](255)  NULL,
	[BrokerCity] [varchar](255)  NULL)


INSERT INTO #PartyBroker
(
    BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupName
    ,GroupNumber
	,BrokerCountry
)
SELECT 
BrokerNumber            = BrokerNumber  
,OriginalBrokerNumber	= BrokerNumber  
,BrokerName             = UPPER(BrokerName)    
,BrokerPseudonym        = BrokerPseudonym
,GroupName              = ISNULL(GroupName, 'NO GROUP') 
,GroupNumber            = ISNULL(GroupNumber, 0)
,BrokerCountry			= NULLIF(BrokerCountry ,'')
FROM Staging_MDS.dbo.vw_PartyBroker
WHERE ISNULL(BrokerName, '') <> ''


--Placing Broker data

INSERT INTO #PartyBroker
(
     IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
)
SELECT 
	 IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
FROM (
 SELECT 
		IsUnknownMember			= 0
		,BrokerNumber			= PlacingBrokerNumber			
		,OriginalBrokerNumber   = PlacingBrokerNumber
		,BrokerName				= PlacingBrokerBranchName
		,BrokerPseudonym		= PlacingBrokerPseudonym
		,GroupNumber			= CASE WHEN ISNUMERIC(PlacingBrokerGroup) = 0 THEN 0 ELSE ISNULL(PlacingBrokerGroup, 0) END 
		,GroupName				= ISNULL(PlacingBrokerGroupName, 'NO GROUP') 
		,BrokerCountry			= NULLIF(PlacingBrokerCountry, '')
		,BrokerCity				= NULLIF(PlacingBrokerCity, '')
		,RowNumber				= row_number () over (partition by PlacingBrokerNumber, PlacingBrokerBranchName order by coalesce(AuditModifyDateTime, AuditCreateDateTime) desc) 
FROM 
	BeazleyIntelligenceDataContract.Outbound.vw_Policy pol
	WHERE 
	ISNULL(pol.PlacingBrokerBranchName, '') <> ''
	AND pol.PlacingBrokerBranchName <> 'N/A'
	AND PlacingBrokerNumber IS NOT NULL
	AND NOT EXISTS 
	(SELECT 1 FROM #PartyBroker PB WHERE PB.BrokerName = UPPER(pol.PlacingBrokerBranchName) AND pb.OriginalBrokerNumber= PlacingBrokerNumber)
   )p
WHERE RowNumber = 1



INSERT INTO #PartyBroker
(
     IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
)
SELECT 
	 IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
FROM (
 SELECT 
		IsUnknownMember     = 0
		,BrokerNumber       = CHECKSUM(PlacingBrokerBranchName)					
		,OriginalBrokerNumber  =0
		,BrokerName         = PlacingBrokerBranchName
		,BrokerPseudonym    = PlacingBrokerPseudonym
		,GroupNumber        = CASE WHEN ISNUMERIC(PlacingBrokerGroup) = 0 THEN 0 ELSE ISNULL(PlacingBrokerGroup, 0) END 
		,GroupName          = ISNULL(PlacingBrokerGroupName, 'NO GROUP') 
		,BrokerCountry		= NULLIF(PlacingBrokerCountry,'')
		,BrokerCity		    = NULLIF(PlacingBrokerCity,'')
		,RowNumber			= row_number () over (partition by PlacingBrokerBranchName order by coalesce(AuditModifyDateTime, AuditCreateDateTime) desc) 
FROM 
	BeazleyIntelligenceDataContract.Outbound.vw_Policy pol
	WHERE 
	ISNULL(pol.PlacingBrokerBranchName, '') <> ''
	AND pol.PlacingBrokerBranchName <> 'N/A'
	AND PlacingBrokerNumber IS  NULL
	AND NOT EXISTS 
	(SELECT 1 FROM #PartyBroker PB WHERE PB.BrokerName = UPPER(pol.PlacingBrokerBranchName))
   )p
WHERE RowNumber = 1

-- Producing Broker data 

INSERT INTO #PartyBroker
(
    IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
)
SELECT 
	IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
FROM (
	SELECT DISTINCT 
			 IsUnknownMember      = 0
			,BrokerNumber         = ProducingBrokerNumber
      		,OriginalBrokerNumber = ProducingBrokerNumber
			,BrokerName           = ProducingBrokerBranchName
			,BrokerPseudonym      = ProducingBrokerPseudonym
			,GroupNumber          = CASE WHEN ISNUMERIC(ProducingBrokerGroup) = 0 THEN 0 ELSE ISNULL(ProducingBrokerGroup, 0) END 
			,GroupName            = ISNULL(ProducingBrokerGroupName, 'NO GROUP') 
			,BrokerCountry		  = NULLIF(ProducingBrokerCountry,'')
			,BrokerCity			  = NULLIF(ProducingBrokerCity,'')
			,RowNumber			  = row_number () over (partition by ProducingBrokerNumber, ProducingBrokerBranchName order by coalesce(AuditModifyDateTime, AuditCreateDateTime) desc) 
	 FROM 
		BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension pol
		WHERE 
		ISNULL(pol.ProducingBrokerBranchName, '') <> ''
		AND pol.ProducingBrokerBranchName <> 'N/A'
		AND ProducingBrokerNumber IS NOT NULL
		AND NOT EXISTS 
		(SELECT 1 FROM #PartyBroker PB WHERE PB.BrokerName = UPPER(pol.ProducingBrokerBranchName) AND pb.OriginalBrokerNumber =ProducingBrokerNumber)
	)p
WHERE RowNumber = 1


INSERT INTO #PartyBroker
(
    IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
)
SELECT 
	IsUnknownMember
    ,BrokerNumber
	,OriginalBrokerNumber
    ,BrokerName
    ,BrokerPseudonym
    ,GroupNumber
    ,GroupName
	,BrokerCountry
	,BrokerCity
FROM (
	SELECT DISTINCT 
			 IsUnknownMember      = 0
			,BrokerNumber         = CHECKSUM(ProducingBrokerBranchName)
      		,OriginalBrokerNumber = 0
			,BrokerName           = ProducingBrokerBranchName
			,BrokerPseudonym      = ProducingBrokerPseudonym
			,GroupNumber          = CASE WHEN ISNUMERIC(ProducingBrokerGroup) = 0 THEN 0 ELSE ISNULL(ProducingBrokerGroup, 0) END 
			,GroupName            = ISNULL(ProducingBrokerGroupName, 'NO GROUP') 
			,BrokerCountry		  = NULLIF(ProducingBrokerCountry,'')
			,BrokerCity			  = NULLIF(ProducingBrokerCity,'')
			,RowNumber			  = row_number () over (partition by  ProducingBrokerBranchName order by coalesce(AuditModifyDateTime, AuditCreateDateTime) desc) 
	 FROM 
		BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension pol
		WHERE 
		ISNULL(pol.ProducingBrokerBranchName, '') <> ''
		AND pol.ProducingBrokerBranchName <> 'N/A'
		AND ProducingBrokerNumber IS NULL
		AND NOT EXISTS 
		(SELECT 1 FROM #PartyBroker PB WHERE PB.BrokerName = UPPER(pol.ProducingBrokerBranchName) )
	)p
WHERE RowNumber = 1

-- Unknown member PartyBroker
	INSERT INTO #PartyBroker
	(
		IsUnknownMember
		,BrokerNumber
		,OriginalBrokerNumber
		,BrokerPseudonym
		,BrokerName
		,GroupNumber
		,GroupName
		,BrokerCountry
		,BrokerCity
	)
	SELECT
	IsUnknownMember       = 1
	,BrokerNumber         = 0
	,OriginalBrokerNumber = 0
	,BrokerPseudonym      = 'N/A' 
	,BrokerName           = 'N/A' 
	,GroupNumber          = 0 
	,GroupName            = 'N/A' 
	,BrokerCountry		  = 'N/A'
	,BrokerCity			  = 'N/A'

MERGE ODS.PartyBroker target
USING 
#PartyBroker source
ON  target.BrokerNumber = source.BrokerNumber
AND target.[BrokerName]   = source.[BrokerName]


WHEN MATCHED THEN
UPDATE SET
target.[IsUnknownMember]    = source.[IsUnknownMember],
target.[OriginalBrokerNumber]= source.[OriginalBrokerNumber],
target.[BrokerPseudonym]    = source.[BrokerPseudonym] ,
target.[GroupNumber]        = source.[GroupNumber],
target.[GroupName]          = source.[GroupName],
target.[BrokerCountry]      = source.[BrokerCountry],
target.[BrokerCity]         = source.[BrokerCity],
target.AuditModifyDateTime	= GETDATE(),						
target.AuditModifyDetails	= 'Merge in ODS.usp_LoadPartyBroker sp'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
([IsUnknownMember],
 [BrokerNumber],
 [OriginalBrokerNumber],
 [BrokerName],
 [BrokerPseudonym],
 [GroupNumber],
 [GroupName],
 [BrokerCountry],
 [BrokerCity],
 [AuditCreateDateTime],
 [AuditModifyDetails]
)

VALUES
(source.[IsUnknownMember],
 source.[BrokerNumber],
 source.[OriginalBrokerNumber],
 source.[BrokerName],
 source.[BrokerPseudonym],
 source.[GroupNumber],
 source.[GroupName],
 source.[BrokerCountry],
 source.[BrokerCity],
 GETDATE(),
 'New add in ODS.usp_LoadPartyBroker'	
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'PartyBroker';
GO

