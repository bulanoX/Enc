﻿

CREATE PROCEDURE [ODS].[usp_LoadSectionATIA]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#SectionATIA') IS NOT NULL)
DROP TABLE #SectionATIA

CREATE TABLE #SectionATIA
(
    [FK_Section] [bigint] NOT NULL,
	[AustraliaState] [varchar](255) NULL,
	[InsuranceType] [varchar](255) NULL,
	[TierCode] [varchar](255) NULL,
	[WrittenOrEstimatedPremium] [numeric](19, 4) NULL,
	[LimitAmount] [numeric](19, 4) NULL,
	[FK_OriginalCurrency] [bigint] NOT NULL,
	[FK_LimitCurrency] [bigint] NOT NULL
)

INSERT INTO #SectionATIA
(
    FK_Section
	,AustraliaState
	,InsuranceType
	,TierCode
	,WrittenOrEstimatedPremium
	,LimitAmount
	,FK_OriginalCurrency
	,FK_LimitCurrency
	)
 

SELECT 
     FK_Section                     = s.PK_Section
    ,AustraliaState                 = atia.AustraliaState
    ,InsuranceType                  = atia.InsuranceType
    ,TierCode                       = atia.TierCode
    ,WrittenOrEstimatedPremium      = SUM(atia.WrittenOrEstimatedPremium  / ( 1 - s.ExternalAcquisitionCostMultiplier)) 
    ,LimitAmount                    = SUM(atia.LimitAmount )
    ,FK_OriginalCurrency            = oc.PK_OriginalCurrency
    ,FK_LimitCurrency               = oc_lim.PK_OriginalCurrency
    
FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionATIA atia

INNER JOIN ODS.Section s
ON atia.SectionSourceId = s.SectionReference 

INNER JOIN ODS.OriginalCurrency oc
ON oc.CurrencyCode = 'AUD'

INNER JOIN ODS.OriginalCurrency oc_lim
ON oc_lim.CurrencyCode = 'AUD'

WHERE atia.SourceSystem = 'Eurobase'
--AND atia.IsActive = 1

GROUP BY  s.PK_Section
         ,atia.AustraliaState
         ,atia.InsuranceType
         ,atia.TierCode
         ,oc.PK_OriginalCurrency
         ,oc_lim.PK_OriginalCurrency


MERGE ODS.SectionATIA AS TARGET

USING #SectionATIA AS SOURCE

 ON TARGET.FK_Section       = SOURCE.FK_Section
AND TARGET.AustraliaState   = SOURCE.AustraliaState
AND TARGET.InsuranceType    = SOURCE.InsuranceType
AND TARGET.TierCode         = SOURCE.TierCode

 WHEN MATCHED THEN
 
 UPDATE SET

 TARGET.FK_Section                  = SOURCE.FK_Section                             
,TARGET.AustraliaState              = SOURCE.AustraliaState                             
,TARGET.InsuranceType               = SOURCE.InsuranceType                             
,TARGET.TierCode                    = SOURCE.TierCode                             
,TARGET.WrittenOrEstimatedPremium   = SOURCE.WrittenOrEstimatedPremium                             
,TARGET.LimitAmount                 = SOURCE.LimitAmount                             
,TARGET.FK_OriginalCurrency         = SOURCE.FK_OriginalCurrency                             
,TARGET.FK_LimitCurrency            = SOURCE.FK_LimitCurrency                             
,TARGET.AuditModifyDateTime         = GETDATE()
,TARGET.AuditModifyDetails          = 'Merge in [ODS].[SectionATIA] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT 
(
 FK_Section
,AustraliaState
,InsuranceType
,TierCode
,WrittenOrEstimatedPremium
,LimitAmount
,FK_OriginalCurrency
,FK_LimitCurrency
,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_Section                             
,SOURCE.AustraliaState                             
,SOURCE.InsuranceType                             
,SOURCE.TierCode                             
,SOURCE.WrittenOrEstimatedPremium                             
,SOURCE.LimitAmount                             
,SOURCE.FK_OriginalCurrency                             
,SOURCE.FK_LimitCurrency           
,'New in [ODS].[SectionATIA] table'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#SectionATIA') IS NOT NULL)
DROP TABLE #SectionATIA;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'SectionATIA';