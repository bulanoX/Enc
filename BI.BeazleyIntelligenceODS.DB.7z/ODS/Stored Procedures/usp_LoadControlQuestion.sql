﻿

CREATE PROCEDURE [ODS].[usp_LoadControlQuestion]
AS

SET NOCOUNT ON


MERGE ODS.ControlQuestion AS t
USING (
		SELECT
			FK_ControlQuestionType		=	qt.PK_ControlQuestionType
			,QuestionNumber				=   cqa.QuestionNumber	
			,ControlQuestion			=   cqa.ControlQuestion
			,QuestionShortName			=   cqa.QuestionShortName
		FROM
		Staging_MDS.dbo.vw_ControlQuestionAnswer cqa

		INNER JOIN ODS.ControlQuestionType qt 
		ON qt.ControlQuestionType = cqa.ControlQuestionType

		LEFT JOIN ODS.ControlQuestion cq ON  cq.FK_ControlQuestionType = qt.PK_ControlQuestionType
											 AND cq.QuestionNumber	   = cqa.QuestionNumber
        WHERE cq.FK_ControlQuestionType IS NULL
		      OR ( cq.ControlQuestion		<> cqa.ControlQuestion
				   OR cq.QuestionShortName	<> cqa.QuestionShortName
				   )

		)s 
		(
		 FK_ControlQuestionType
		,QuestionNumber 
		,ControlQuestion
		,QuestionShortName
		)
		ON 	   s.FK_ControlQuestionType = t.FK_ControlQuestionType
		   AND s.QuestionNumber		  = t.QuestionNumber
		   
WHEN MATCHED THEN
UPDATE
SET   t.ControlQuestion			= s.ControlQuestion
	 ,t.QuestionShortName		= s.QuestionShortName
	 ,t.AuditModifyDateTime		= GETDATE()						
	 ,t.AuditModifyDetails		= 'Merge in [ODS].[usp_LoadControlQuestion] proc' 

WHEN NOT MATCHED BY TARGET THEN 
INSERT 
(
     FK_ControlQuestionType
    ,QuestionNumber
    ,ControlQuestion
    ,QuestionShortName
	,AuditModifyDetails
)
VALUES (
		 s.FK_ControlQuestionType
		,s.QuestionNumber
		,s.ControlQuestion
		,s.QuestionShortName
		,'New add in [ODS].[usp_LoadControlQuestion] proc'
		);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ControlQuestion';