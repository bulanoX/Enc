﻿


CREATE PROCEDURE [ODS].[usp_LoadSectionUnderwrittingCommittee]

AS

SET NOCOUNT ON


DECLARE @SLSnapshotGroup      BIGINT
DECLARE @SLSnapshotSubGroup   BIGINT

DECLARE @LineOfBusiness       BIGINT

---------------------------------------BEGIN SNAPSHOT -----------------------------------------------------------

----------------------------------Rule 2----------------------------------------

DROP TABLE IF EXISTS #Section
CREATE TABLE #Section
(
PK_Section					BIGINT 
,FK_Policy					BIGINT NULL
,FK_SLSnapshotGroup			BIGINT NULL
,FK_SLSnapshotSubGroup		BIGINT NULL
,FK_TriFocus				BIGINT NULL
,FK_ClassOfBusiness			BIGINT NULL
,FK_LineOfBusiness			BIGINT NULL
,TriFocusFocusSubGroup		VARCHAR (255)    NULL	
,TriFocusFocusGroup   		VARCHAR (255)    NULL
,TriFocusTeam         		VARCHAR (255)    NULL
,TriFocusRegion       		VARCHAR (255)    NULL
)

INSERT INTO #Section
(
PK_Section					
,FK_Policy					
,FK_SLSnapshotGroup			
,FK_SLSnapshotSubGroup		
,FK_TriFocus				
,FK_ClassOfBusiness			
,FK_LineOfBusiness			
,TriFocusFocusSubGroup		
,TriFocusFocusGroup   		
,TriFocusTeam         		
,TriFocusRegion       		
)
SELECT
PK_Section					
,FK_Policy					
,FK_SLSnapshotGroup			
,FK_SLSnapshotSubGroup		
,FK_TriFocus				
,FK_ClassOfBusiness			
,FK_LineOfBusiness			
,TriFocusFocusSubGroup		
,TriFocusFocusGroup   		
,TriFocusTeam         		
,TriFocusRegion       		
FROM ODS.Section



CREATE NONCLUSTERED INDEX [IDX_#StagingSectionSLSnapshot] ON #Section ([FK_SLSnapshotGroup],[FK_SLSnapshotSubGroup]) Include ([FK_TriFocus],[FK_ClassOfBusiness])  WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#Staging_fk_trifocus] ON #Section ([FK_TriFocus],[FK_ClassOfBusiness])  WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#StagingSection_Fk_LineOfBusiness] ON #Section ([FK_LineOfBusiness])
INCLUDE ([FK_TriFocus])  WITH (FILLFACTOR = 90)


---------------------------------------BEGIN SNAPSHOT -----------------------------------------------------------

----------------------------------Rule 2----------------------------------------
UPDATE s
SET  FK_SLSnapshotGroup    = 0, -- nsg.PK_SLSnapshotGroup, 
	 FK_SLSnapshotSubGroup = 0  -- nssg.PK_SLSnapshotSubGroup
FROM #Section s

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus 

--INNER JOIN ODS.ClassOfBusiness cob
--ON cob.PK_ClassOfBusiness = s.FK_ClassOfBusiness

--INNER JOIN ODS.Underwriter uw 
--ON s.FK_Underwriter = uw.PK_Underwriter

--INNER JOIN Staging_MDS.MDS_Staging.UCSLSnapshotGroupRule snu 
--ON uw.UnderwriterName = snu.Underwriter
--AND cob.ClassOfBusinessCode = snu.ClassOfBusinessCode

--INNER  JOIN UC.SLSnapshotGroup nsg
--ON nsg.SLSnapshotGroupCode = snu.SLSnapshotGroup_Code

--INNER JOIN UC.SLSnapshotSubGroup nssg
--ON nssg.SLSnapshotSubGroupCode = snu.SLSnapshotSubGroup_Code

WHERE t.DepartmentName = 'Specialty Lines' --Rule 1	

----------------------------Rule 3---------------------------------------
--SET @SLSnapshotGroup    = (SELECT [PK_SLSnapshotGroup]   FROM UC.SLSnapshotGroup      WHERE SLSnapshotGroupCode    = 'N/A')
--SET @SLSnapshotSubGroup = (SELECT [PK_SLSnapshotSubGroup] FROM UC.SLSnapshotSubGroup  WHERE SLSnapshotSubGroupCode = 'N/A')

UPDATE s
SET  FK_SLSnapshotGroup    = 0, -- @SLSnapshotGroup, 
	 FK_SLSnapshotSubGroup = 0  -- @SLSnapshotSubGroup

FROM #Section s

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus 

INNER JOIN Staging_MDS.MDS_Staging.UCSLSnapshotGroupRule snt 
ON t.TrifocusName = snt.Trifocus_Name

WHERE   s.FK_SLSnapshotGroup		   IS NULL 
		AND s.FK_SLSnapshotSubGroup    IS NULL
		AND t.DepartmentName            = 'Specialty Lines' --Rule 1
		AND snt.TrifocusException_Name  = '_OTHER' 
--14710

-------------------------------Rule 4---------------------------------------

UPDATE s
SET  FK_SLSnapshotGroup    = 0, -- nsg.PK_SLSnapshotGroup, 
	 FK_SLSnapshotSubGroup = 0 -- nssg.PK_SLSnapshotSubGroup	
FROM #Section s

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus 

INNER JOIN ODS.ClassOfBusiness cob 
ON s.FK_ClassOfBusiness = cob.PK_ClassOfBusiness 

INNER JOIN Staging_MDS.MDS_Staging.UCSLSnapshotGroupRule sncob 
ON sncob.ClassOfBusinessCode = cob.ClassOfBusinessCode  
AND sncob.Trifocus_Name = t.TriFocusName   ---SI ASTA???

--INNER JOIN UC.SLSnapshotGroup nsg
--ON nsg.SLSnapshotGroupCode = sncob.SLSnapshotGroup_Code

--INNER JOIN UC.SLSnapshotSubGroup nssg
--ON nssg.SLSnapshotSubGroupCode = sncob.SLSnapshotSubGroup_Code

WHERE  s.FK_SLSnapshotGroup         IS NULL 
	AND s.FK_SLSnapshotSubGroup     IS NULL
	AND t.DepartmentName            = 'Specialty Lines' 
	AND sncob.TrifocusException_Name  = '_TODO'
--with left   234.327, 9 s select
--with inner 234.327,   1 s select / 18 s update

---------------------------------------Rule 5---------------------------

UPDATE s
SET  FK_SLSnapshotGroup    = 0, -- nsg.PK_SLSnapshotGroup, 
	 FK_SLSnapshotSubGroup = 0  -- nssg.PK_SLSnapshotSubGroup	
	 
FROM #Section s
      
INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus

INNER JOIN Staging_MDS.MDS_Staging.UCSLSnapshotGroupRule snt 
ON t.TrifocusName = snt.Trifocus_Name 

--INNER  JOIN UC.SLSnapshotGroup nsg
--ON nsg.SLSnapshotGroupCode = snt.SLSnapshotGroup_Code

--INNER JOIN UC.SLSnapshotSubGroup nssg
--ON nssg.SLSnapshotSubGroupCode = snt.SLSnapshotSubGroup_Code   

WHERE  s.FK_SLSnapshotGroup         IS NULL 
	AND s.FK_SLSnapshotSubGroup     IS NULL
	AND t.DepartmentName            = 'Specialty Lines' --Rule 1 
	AND snt.TrifocusException_Name  IS NULL

--493.374 CU LEFT JOIN, 438005 CU INNER JOIN,  CARE?


---------------------------------------RULE 6 -----------------------------------------------
UPDATE s

SET FK_SLSnapshotGroup    = 0, -- @SLSnapshotGroup, 
	FK_SLSnapshotSubGroup = 0  -- @SLSnapshotSubGroup
 
FROM #Section s 

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus

WHERE s.FK_SLSnapshotGroup   IS NULL 
 AND s.FK_SLSnapshotSubGroup IS NULL 
 AND t.DepartmentName         = 'Specialty Lines' --Rule 1


---------------------------------------END SNAPSHOT -----------------------------------------------------------

---------------------------------------BEGIN PHASING-----------------------------------------------------------
--------------------------------Rule 2---------------------------------------------------
-------------------- If COBCode is null join only on Trifocus  --------------------------  
   
UPDATE S 
SET 
	TriFocusFocusSubGroup = tm.TriFocusFocusSubGroup_Name,
	TriFocusFocusGroup    = tm.TriFocusFocusGroup_Name,
	TriFocusTeam          = tm.TriFocusTeam_Name,
	TriFocusRegion        = tm.TriFocusRegion_Name
 
FROM #Section s

--INNER JOIN ODS.Policy p 
--ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.TriFocus t 
ON  s.FK_TriFocus = t.PK_TriFocus

INNER JOIN Staging_MDS.MDS_Staging.TrifocusMapping tm
ON tm.Trifocus_Name = t.TrifocusName

WHERE ISNULL(tm.COBCode,'')= ''

--------------------------------Rule 1---------------------------------------------------
-------------------- If COBCode is not null join on Trifocus and COBCode ----------------
	
UPDATE S 
SET 

    TriFocusFocusSubGroup = tm.TriFocusFocusSubGroup_Name,
	TriFocusFocusGroup    = tm.TriFocusFocusGroup_Name,
	TriFocusTeam          = tm.TriFocusTeam_Name,
	TriFocusRegion        = tm.TriFocusRegion_Name
	
FROM #Section s

--INNER JOIN ODS.Policy p 
--ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.TriFocus t 
ON  s.FK_TriFocus = t.PK_TriFocus

INNER JOIN ODS.ClassOfBusiness cob 
ON  s.FK_ClassOfBusiness = cob.PK_ClassOfBusiness

INNER JOIN Staging_MDS.MDS_Staging.TrifocusMapping tm
ON tm.Trifocus_Name = t.TrifocusName
   AND tm.COBCode = cob.ClassOfBusinessCode
   

----------------------------------END PHASING--------------------------------------------------------------------------

---------------------------------------BEGIN LineOfBusiness -----------------------------------------------------------
--------------------------------------Rule 2----------------------------------

UPDATE s 
SET FK_LineOfBusiness = 0 -- nsg.PK_LineOfBusiness
     
FROM #Section s

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus 

--INNER JOIN UC.SLSnapshotGroup sn
--ON s.FK_SLSnapshotGroup = sn.PK_SLSnapshotGroup

--INNER JOIN Staging_MDS.MDS_Staging.UCLineOfBusinessRule  lob
--ON sn.SLSnapshotGroupCode = lob.SLSnapshotGroup_Code
	   
--INNER JOIN UC.LineOfBusiness nsg
--ON nsg.LineOfBusinessCode = lob.LineOfBusiness_Code 

WHERE s.FK_LineOfBusiness IS NULL
	AND t.DepartmentName = 'Specialty Lines' --Rule 1
--300.531

------------------------------Rule 3------------------------------

UPDATE s 
SET FK_LineOfBusiness = 0 -- nsg.PK_LineOfBusiness
    
FROM #Section s
	   
--INNER JOIN ODS.TriFocus t
--ON s.FK_TriFocus = t.PK_TriFocus    

--INNER JOIN Staging_MDS.MDS_Staging.UCLineOfBusinessRule lobt
--ON lobt.TrifocusName_Name = t.TrifocusName   

--INNER JOIN UC.LineOfBusiness nsg
--ON nsg.LineOfBusinessCode = lobt.LineOfBusiness_Code
	   
WHERE s.FK_LineOfBusiness IS NULL
---0
--------------------------------Rule 4-----------------------------

--SET @LineOfBusiness = (SELECT nsg.PK_LineOfBusiness  FROM UC.LineOfBusiness nsg WHERE nsg.LineOfBusinessCode = 'N/A')

UPDATE s

SET FK_LineOfBusiness = 0 -- @LineOfBusiness
 
FROM #Section s 

INNER JOIN ODS.TriFocus t 
ON s.FK_TriFocus = t.PK_TriFocus

WHERE s.FK_LineOfBusiness IS NULL


---------------------------------------END LineOfBusiness -----------------------------------------------------------





--EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'DROP', @SchemaName = 'ODS'

--	ALTER TABLE ODS.Section NOCHECK CONSTRAINT ALL

	UPDATE target
SET
 TARGET.FK_SLSnapshotGroup        = SOURCE.FK_SLSnapshotGroup
 ,TARGET.FK_SLSnapshotSubGroup	  = SOURCE.FK_SLSnapshotSubGroup
 ,TARGET.TriFocusFocusSubGroup 	  = SOURCE.TriFocusFocusSubGroup
 ,TARGET.TriFocusFocusGroup    	  = SOURCE.TriFocusFocusGroup
 ,TARGET.TriFocusTeam          	  = SOURCE.TriFocusTeam
 ,TARGET.TriFocusRegion			  = SOURCE.TriFocusRegion
 ,TARGET.FK_LineOfBusiness		  = SOURCE.FK_LineOfBusiness
 FROM
ODS.Section target
INNER JOIN #Section source
ON target.PK_Section = source.PK_Section

DROP TABLE IF EXISTS #Section


	--ALTER TABLE ODS.Section CHECK CONSTRAINT ALL

	--EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'CREATE', @SchemaName = 'ODS'
