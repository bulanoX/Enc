﻿CREATE procedure [ODS].[usp_LoadSection]
as

begin 
	----------------------------------------------------------------------------------------------------------------------------------------------
	-- final insert into ODS.Section
	----------------------------------------------------------------------------------------------------------------------------------------------
	
	EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'DROP', @SchemaName = 'ODS'

	ALTER TABLE ODS.Section NOCHECK CONSTRAINT ALL


	INSERT INTO ODS.Section WITH (TABLOCK)
	(
		 PK_Section
		,SectionReference
		,SectionDisplayReference
		,SectionDescription
		,CoverageName
		,SectionSequenceId
		,AccountHandler
		,AdditionalExposures
		,AdjustmentBaseAmountInOriginalCCY
		,AdjustmentMultiplier
		,AdjustmentPremiumInOriginalCCY
		,AdminPurposesFlag
		,AggregateAmount
		,AggregateQualifier
		,AggregatesRequired
		,AgressoReference
		,ProductIsMultiTransactional
		,BICICessionMultiplier
		,BICIProgramName
		,BIDeductible
		,BeazleyIsAgreementParty
		,BeazleyOfficeLocation
		,BenchmarkApplies
		,BenchmarkDate
		,BenchmarkMultiplier		
        ,BenchmarkMultiplierName
		,Billings
		,BinderType
		,BreachResponseMultiplier
		,BreachResponseParentSection
		,CancelledDate
		,CancelledReason
		,CapitaEntryTimeHours
		,CapitaQCTimeHours
		,CapitaTotalTimeHours
		,CargoOrFreight
		,CarrierIndicator
		,CheckStatusCode
		,CIPsRiskCode
		,ClaimBasis
		,ClaimBasisCode
		,ClaimDelegatedTo
		,ClassifiedAsTechnology					
		,ClientClassificationCode
		,Comments
		,Conditions
		,ConditionsCode
		,ConstructionPeriodFrom 
		,ConstructionPeriodTo
		,ConstructionTitle
		,ConstructionDays	  
		,ConstructionMonths 
		,ContractCertaintyControlsCompliantDate
		,ContractCertaintyEnteredDate
		,ContractCertaintyFullyCompliantDate
		,ContractCertaintyModifiedDate
		,ContractCertaintyPostBindComplete
		,ContractCertaintyPostBindOnTime
		,ContractCertaintyPreBindComplete
		,ContractCertaintyPreBindOnTime
		,ContractCertaintyPreBindSignatureDate
		,ContractCertaintyPrimaryCompleteDate
		,ContractCertaintyQuestionNote
		,ContractCertaintyRequired
		,ContractCertaintyStatus
		,ContractCertaintyStatusSortOrder
		,CoreAccountType
		,CoreAccountTypeCode
		,Country
		,CountryCode
		,CoverType
		,CoverageForm
		,CoverageSolution
		,CrossSelling
		,CrossSellingInitiator
		,DateModified
		,DaysBetweenConstructionPhaseToandFrom
		,DaysBetweenMaintenanceFromAndTo
		,DaysBetweenQBAndBenchmarkDate
		,DaysBetweenQBAndCCCCDateOrToday
		,DaysBetweenQBAndCCFCDateOrToday
		,DaysBetweenQBAndCCPCDateOrToday
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday
		,DaysBetweenQBAndRateChangeDate
		,DaysBetweenTestingFromAndTo
		,DaysSinceQuoteOrBindDate
		,DeclarationWEPInOriginalCCY
		,DeductibleAmountInLimitCCY
		,DeductibleQualifier
		,DelegatedClaimsAuthority
		,DelegatedClaimsAuthorityName
		,DepositPremiumInOriginalCCY
		,DurationMonths
		,EngineeringProjectName
		,EngineeringSumInsuredInLimitCCY
		,EntityGrouping
		,EntitySplit
		,Entity
		,MarketPlatform
		,EquipmentBreakdownContactName
		,EquipmentBreakdownContactNumber
		,EquipmentBreakdownReferral
		,ESGPolicyFlag
		,ESGPolicyFlagName
		,EstimatedSigningMultiplier
		,EventLimitAmountInLimitCCY
		,EventLimitDescription
		,EventLimitQualifier
		,ExcessAmountInLimitCCY
		,ExcessQualifier
		,ExpectedLossRatioMultiplier
		,ExpectedPICCTransactions
		,ExpensesMultiplier
        ,ExpensesMultiplierName
		,ExpiringSection
		,ExpiryDate
		,ExternalAcquisitionCostMultiplier
		,FACRIIndicator
		,Facility
		,Fees
		,FirstLiveDate
		,FullQuoteReference
		,FullTimeEquivalents
		,GulfOfMexicoRiskPremiumMultiplier
		,GulfOfMexicoWindstormMultiplier
		,HasConsortiumLink
		,HasGulfOfMexicoExposure
		,HasMultiYearLink
		,HasParentLink
		,HasRateChange
		,HasReinstatementPremium
		,HazardClass
		,ITVPerSQFT
		,InceptionDate
		,IncludeInMunichStacking
		,IncludePML
		,Industry
		,IndustryCode
		,IndustryCodeQualifier
		,InnovationCampaign
		,InnovationPremiumMultiplier
		,InsuredItem
		,Interest
		,InterestCode
		,InwardQuotaShareMultiplier
		,IsBID
		,IsBeazleyLead
		,IsBreachResponseDummy
		,IsPolicyholderAPrivateIndividual
		,IsQuote
		,IsRapidRenewal
		,IsRenewal
		,IsRenewed
		,IsSigned
		,IsSynergySection
		,KeyLocationAddress1
		,KeyLocationAddress2
		,KeyLocationCity
		,KeyLocationCountry
		,KeyLocationState
		,KeyLocationStreetNumber
		,KeyLocationZipCode
		,LatestEPIInOriginalCCY
		,LeaderName
		,LeaderPseudonym
		,LimitAmountInLimitCCY
		,LimitCCYToSettlementCCYRate
		,LimitDescription
		,LimitQualifier
		,LimitTypeCode
		,LimitTypeDescription
		,LineMultiplierBand
		,LineMultiplierBandKey
		,LinkedConsortiumReference
		,LinkedESGBinderReference
		,LinkedESGSectionReference
		,LinkedNonSynergyReference
		,LinkedParentReference
		,LinkedSynergySection
		,LiveStatus
		,LloydsClassOfBusiness
		,LloydsClassOfBusinessCode
		,LocalCurrency
		,MASTerritory
		,MailingAddress1
		,MailingAddress2
		,MailingCity
		,MailingState
		,MailingZipCode
		,MaintenancePeriodFrom
		,MaintenancePeriodTo
		,MaintenanceMonths
		,MarketCapitalisation
		,MigratedPolicy
		,MinimumPremiumInOriginalCCY
		,MonthsSinceInception
		,MonthsSinceInceptionBand
		,MonthsSinceInceptionBandKey
		,MonthsSinceTOT
		,MultiYearGroupDurationMonths
		,MultiYearGroupReference
		,MultiYearIndicator
		,NewConditionsExpiryDate
		,NewConditionsExpiryDateName
		,NotifiedIndividuals
		,NotifiedIndividualsName
		,NumberOfEmployees
		,NumberOfLawyers
		,NumberOfLives
		,NumberOfLocations
		,NumberOfReinstatements
		,Obligor
		,ObligorOccupation
		,ObligorOccupationCode
		,Occupation
		,OccupationCode
		,OriginalCCYToLocalCCYRate
		,OriginalCCYToSettlementCCYRate
		,OriginalCoverageName
		,OriginalEPIInOriginalCCY
		,OriginalEPITotalAcquisitionCostMultiplier
		,OriginalGrossPremiumInOriginalCCY
		,OriginalInsured
		,OriginalInsuredArea
		,OriginalInsuredAreaCode
		,OriginalLimitInOriginalCCY
		,OriginatingSourceSystem
		,PDDeductible
		,PDSI
		,PMLExposure
		,PMLExposureOurShareUSD			
		,PMLExposure100PerctShareUSD	   
		,PMLExposure100PerctShareOrigCcy 
		,PMLPercentage          
		,TSI100PercForPMLOrigCcy
        ,PolicyRate                                           
		,Peril
		,PerilCode
		,PremiumIncomeLimitInOriginalCCY
		,PremiumRates
		,PrimaryLegacyReference
		,PrimaryOrExcess
		,PrimarySectionURL
		,PrimarySectionURLLabel
		,Product
		,ProfitCommissionMultiplier
		,ProgramName
		,ProgramNumber
		,ProgramPeriod
		,ProgramType 
		,ProgramYear 
		,QuoteBoundSectionReference
		,QuoteDaysValid
		,QuoteLapsedDate
		,QuoteOrBindDate
		,RatingAdequacyMultiplier
		,RateChangeControlComplete
		,RateChangeDate
		,RateChangeDeductibleMultiplier
		,RateChangeExposureMultiplier
		,RateChangeLimitMultiplier
		,RateChangeMethod
		,RateChangeMultiplier
		,RateChangeOtherMultiplier
		,RateChangeRiskMultiplier
		,RateChangeTermsAndConditionsMultiplier
		,RateOnLineBandKey
		,RateOnLineBandName
		,RateOnLineMultiplier
		,RateOnLineMultiplierEntered
		,RateOnLinePremiumEnteredInOriginalCCY
		,RationaleQuestionnaireComplete
		,RationaleQuestionnaireDate
		,ReSigningIndicator
		,ReactivationReason
		,ReactivationReasonCode
		,ReinstatementMultiplier
		,ReinstatementPremiumInOriginalCCY
		,ReinsuranceIndicator
		,RenewalDueDate
		,RenewingSection
		,RetroInceptionDate
		,Revenues
		,RiskClass
		,RiskClassCode
		,SICCode
		,SigningNumberDate                            
		,SLSpecificCoverage
		,ReKeyReference 
		,ReKeySource
		,SecondarySectionURL
		,SecondarySectionURLLabel
		,SectionReferenceCOBCode
		,SectionReferenceReinsuranceIndicator
		,SectionReferenceSectionIdentifier
		,SectionStatus
		,SectionStatusCode
		,SignedLineMultiplier
		,SignedOrderMultiplier
		,SimpleProduct
		,SpecialPurposeSyndicateApplies
		,StatsCode
		,StatsDescription
		,SubmissionDate
		,SwordTreatyCoverage
		,Team
		,TechnicalPremium
		,TechnicalMultiplierName
		,TechnologyCoverageName					
		,TermsOfTradeDate
		,TermsOfTradeExpired
		,TerritorialFocusGroup 
		,TerrorismReference
		,TestingPeriodFrom
		,TestingPeriodTo
		,TestingMonths	
		,TimeExcess
		,TimeExcessAmount
		,TopLocationTSI
		,TotalSignedMultiplier
		,TotalSumInsured
		,TotalWrittenIfNotSignedMultiplier
		,TotalWrittenMultiplier
		,TotalSIExposureOurShare
		,TransactionLiabilityProject
		,TransactionLiabilitySectionType
		,TransactionType
		,TransactionTypeCode
		,TransactionValue
		,USUnderwritingCoverageCode
		,UltimateLossRatioMultiplier
		,VATNumber
		,WEPLastUpdatedDate
		,WrittenIfNotSignedLineMultiplier
		,WrittenIfNotSignedOrderMultiplier
		,WrittenLineMultiplier
		,WrittenOrEstimatedPremiumInOriginalCCY
		,WEPBasis
		,WrittenOrderMultiplier
	--	,TotalSumInsured
		/*DQ fields*/
		,DQ_AdditionalInsuredParty
		,DQ_Address1
		,DQ_Address2
		,DQ_Address3
		,DQ_FK_PartyBrokerNoticeOfClaim
		,DQ_FK_PartyBrokerPlacing
		,DQ_FK_PartyBrokerProducing
		,DQ_FK_PartyBrokerServiceOfSuit
		,DQ_FK_YOA
		,DQ_InsuredParty
		,DQ_MethodOfPlacementCode
		,DQ_PlacingBrokerContact
		,DQ_ProducingBrokerContact
		,DQ_ReinsuredParty
		,DQ_UniqueMarketReference
		,FK_ATIAClassOfBusiness
		,FK_Area
		,FK_CRMBroker
		,FK_ClassOfBusiness
		,FK_ClientClassificationCode
		,FK_CurrentWorkflowStatus
		,FK_DurationBand
		,FK_EnteredBy
		,FK_HiddenStatusFilter
		,FK_LimitCurrency
		,FK_LocalCurrency
		,FK_MultiYearGroupDurationBand
		,FK_OriginalCurrency
		,FK_Policy
		,FK_QuoteFilter
		,FK_ServiceCompany
		,FK_SettlementCurrency
		,FK_TriFocus
		,FK_Underwriter
		,FK_UnderwriterAssistantContractCertainty
		,FK_UnderwriterContractCertainty
		,FK_UnderwriterLargeRiskReviewer
		,FK_UnderwritingPlatform
		,FK_YOA
		,FK_LinkedESGBinder	
		,FK_LinkedESGSection
		,FK_LinkedESGTrifocus
		,FK_Facility						
		,IsDeclaration					
		,IsFacility						
		,BinderTypeInternalExternal		
		,FK_ExpiringSection				
		,FK_RenewingSection				
		,FK_BreachResponseParentSection	
		,HasDataContractSections			
		,HasNonEurobaseSections			
		,FacilityFilter					
		,FacilityType					
		,FK_InternalWrittenBinderStatus	
		,FK_ATIAChildSection	
		,SourceOfBusiness						
		,SourceSystem
		,FK_LinkedSynergySection							
		,HashBytesId
		,NoticeDate											
		,NotificationThreshold								
		,TacitRenewal
		------- Section perfomance issue									
		,FK_DateModified                            
		,FK_QuoteLapsedDate                         
		,FK_InceptionDate                           
		,FK_ExpiryDate                             
		--,FK_ExpiryDateInForce                      
		,FK_RenewalDueDate                          
		,FK_BenchmarkDate                          
		,FK_QuoteOrBindDate                        
		,FK_CurrentWorkflowStatusFromDate           
		,FK_FirstLiveDate                           
		,FK_WEPLastUpdatedDate 
		,FK_NewConditionsExpiryDate
		--,FK_ExceptionDocumentDate                   
		,FK_SubmissionDate                          
		,FK_ContractCertaintyControlsCompliantDate  
		,FK_ContractCertaintyFullyCompliantDate     
		,FK_ContractCertaintyPrimaryCompleteDate    
		--,FK_ContractCertaintyDocumentDate           
		,FK_ContractCertaintyPreBindSignatureDate   
		,FK_ContractCertaintyEnteredDate            
		,FK_ContractCertaintyModifiedDate           
		--,RationaleDate								
		,ExternalAcquisitionCostMultiplierName		
		,BenchmarkDivisor							
		,BenchmarkDivisorName						
		,ExpectedLossRatioMultiplierName			
		,BenchmarkAppliesName						
		--,EarliestLPSOPremiumSigningDateName			
		--,EarliestLPSOPremiumSigningNumberName	
		,HasConsortiumLinkName
		,HasGulfOfMexicoExposureName				
		,HasMultiYearLinkName			
		,HasParentLinkName
		,HasRateChangeName							
		--,HasRationaleDocumentName					
		,HasReinstatementPremiumName				
		--,HasTreatyAggsTerritoryName				
		--,HasUnderwriterAuthorityExceptionName		
		,IsRenewalName								
		,IsRenewedName								
		,IsRapidRenewalName							
		,IsSignedName								
		,IsSynergySectionName							
		--,LatestLPSOPremiumSigningDateName			
		--,LatestLPSOPremiumSigningNumberName		
		,MultiYearIndicatorName						
		,ProgramNumberName							
		,ProgramPeriodName							
		,QuoteOrBindDateName						
		,RateChangeDivisor							
		,RateChangeDivisorName						
		,RationaleQuestionnaireCompleteName			
		,RateChangeControlCompleteName				
		,RateOnLineMultiplierEnteredName			
		,AdjustmentMultiplierName					
		,RationaleQuestionnaireDateName				
		--,RationaleDocumentDateName				
		,ReinstatementMultiplierName				
		,RetroInceptionDateName						
		,TermsOfTradeDateName						
		,SpecialPurposeSyndicateAppliesName			
		,SignedLineMultiplierName					
		,SignedOrderEqualsWrittenOrderName			
		,SignedOrderMultiplierName					
		,SwordTreatyCoverageName					
		,TotalSignedMultiplierName					
		,TotalWrittenIfNotSignedMultiplierName		
		,TotalWrittenMultiplierName					
		,WrittenIfNotSignedLineMultiplierName		
		,WrittenIfNotSignedOrderMultiplierName		
		,WrittenLineMultiplierName					
		,WrittenOrderMultiplierName					
		,EstimatedSigningMultiplierName				
		--,HasExceptionDocumentName					
		--,ExceptionDocumentDateName				
		--,RationaleDateName						
		,FirstLiveDateName							
		,CapitaEntryTimeName						
		,CapitaQCTimeName							
		,CapitaTotalTimeName						
		,BenchmarkDateName							
		--,CurrentWorkflowStatusFromDateName		
		,DateModifiedName							
		--,DaysBetweenQBAndPERDateName				
		,DaysSinceQuoteOrBindDateName				
		,ExpiryDateName								
		,RenewalDueDateName							
		,SignedOrderEqualsWrittenOrder				
		,MonthsSinceInceptionName					
		,MonthsSinceTOTName							
		,DurationMonthsName							
		,MultiYearGroupDurationMonthsName			
		,GulfOfMexicoWindstormMultiplierName		
		,GulfOfMexicoRiskPremiumMultiplierName		
		,InceptionDateName                         
		,QuoteDaysValidName                         
		,QuoteLapsedDateName                        
		,RateChangeDateName                         
		,DaysBetweenQBAndRateChangeDateName         
		,DaysBetweenQBAndBenchmarkDateName          
		,WEPLastUpdatedDateName                     
		,IsRenewalForBordereauxName               
		,HasMarketCapitalisation                    
		,MultiYearGroupReferenceName     
		,IsBeazleyLeadName
		--,NumberOfSections                         
		--,NumberOfDeclarations						
		--,NumberOfFacilities						
		--,NumberOfRenewals                         
		--,NumberOfRenewed                          
		--,NumberOfNew                             
		--,NumberOfBeazleyLed                       
		,HasProgramLink                            
		,HasProgramLinkName                         
		,FACRIIndicatorName                         
		,BreachResponseMultiplierName               
		,IsBreachResponseDummyName                  
		,ProfitCommissionMultiplierName             
		,HasProfitCommission                        
		,TermsOfTradeExpiredName                    
		,ContractCertaintyControlsCompliantDateName 
		,ContractCertaintyFullyCompliantDateName    
		,ContractCertaintyPrimaryCompleteDateName   
		,ContractCertaintyPreBindSignatureDateName  
		--,ContractCertaintyDocumentDateName        
		,ContractCertaintyEnteredDateName           
		,ContractCertaintyModifiedDateName          
		--,HasContractCertaintyDocumentName         
		--,EngineeringConstructionExpiryDateName     
		,OriginalCurrencyEqualsLimitCurrency       
		,DaysBetweenQBAndCCCCDateOrTodayName       
		,DaysBetweenQBAndCCFCDateOrTodayName        
		,DaysBetweenQBAndCCPCDateOrTodayName        
		,DaysBetweenQBAndCCPCOrCCPBSDateOrTodayName 
		--,DaysBetweenQBAndCCDocumentDateName       
		,ContractCertaintyPreBindCompleteName       
		,ContractCertaintyPreBindOnTimeName         
		,ContractCertaintyPostBindCompleteName      
		,ContractCertaintyPostBindOnTimeName        
	    ,ExpectedPICCTransactionsName              
		--,MissingPICCTransactionsName             
		--,HasMissingPICCTransactionsName          
		,BICICessionMultiplierName                  
		,ContractCertaintyRequiredName              
		,HasDataContractSectionsName               
		--,OccurrenceTerrorismName                   
		--,OccurrenceSabotageName                     
		--,OccurrenceRSCCMDName                       
		--,OccurrenceInsurrectionName                 
		--,OccurrenceRevolutionName                   
		--,OccurrenceRebellionName                   
		--,OccurrenceMutinyName                      
		--,OccurrenceCoupDEtatName                   
		--,OccurrenceWarName                         
		--,OccurrenceCivilWarName                    
		--,HoursClauseName                          
		,HasLinkedSynergySection                   
		,BillingsName                               
		,NumberOfEmployeesName                      
		,FeesName                                   
		,NumberOfLawyersName                       
		,RevenuesName                               
		,AdditionalExposuresName                   
		,NumberOfLivesName                         
		,NumberOfLocationsName						
		,TotalSumInsuredName                        
		,FullTimeEquivalentsName                    
		,MarketCapitalisationName                   
		,TransactionValueName                       
		,InnovationPremiumMultiplierName			
		,FK_NoticeDate                              
		,NoticeDateName                            
		,SyndicateViewMultiplier		
		,UnderwriterRiskEnteredBy
		,UnderwriterName	
		,UnderwriterAssistant
		,KeyBrokerName
		,KeyBrokerSubGroup
		,KeyBrokerGroup
		,KeyBrokerCity
		,KeyBrokerCountry
		,KeyBrokerSourceId
		,AuditModifyDateTime
		,AuditCreateDateTime
		,AuditModifyDetails

	)
	SELECT
		 PK_Section									= isnull(CONVERT(BIGINT,HASHBYTES('SHA2_256',(UPPER(SectionReference)))),(0))
		,SectionReference							= s.SectionReference
		,SectionDisplayReference					= s.SectionDisplayReference
		,SectionDescription							= s.SectionDescription
		,CoverageName								= s.CoverageName
		,SectionSequenceId							= s.SectionSequenceId
		,AccountHandler								= s.AccountHandler
		,AdditionalExposures						= s.AdditionalExposures
		,AdjustmentBaseAmountInOriginalCCY			= s.AdjustmentBaseAmountInOriginalCCY
		,AdjustmentMultiplier						= s.AdjustmentMultiplier
		,AdjustmentPremiumInOriginalCCY				= s.AdjustmentPremiumInOriginalCCY
		,AdminPurposesFlag							= s.AdminPurposesFlag
		,AggregateAmount							= s.AggregateAmount
		,AggregateQualifier							= s.AggregateQualifier
		,AggregatesRequired							= s.AggregatesRequired
		,AgressoReference							= s.AgressoReference
		,ProductIsMultiTransactional				= s.ProductIsMultiTransactional
		,BICICessionMultiplier						= s.BICICessionMultiplier
		,BICIProgramName							= CASE
															WHEN s.BinderType = '5' THEN s.DQ_InsuredParty
															ELSE s.BICIProgramName
														END
		,BIDeductible								= s.BIDeductible
		,BeazleyIsAgreementParty					= s.BeazleyIsAgreementParty
		,BeazleyOfficeLocation						= s.BeazleyOfficeLocation
		,BenchmarkApplies							= s.BenchmarkApplies
		,BenchmarkDate								= s.BenchmarkDate
		,BenchmarkMultiplier						= s.BenchmarkMultiplier
		,BenchmarkMultiplierName                    = CAST(ROUND(CAST(s.BenchmarkMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.BenchmarkMultiplier,(2))
		,Billings									= s.Billings
		,BinderType									= s.BinderType
		,BreachResponseMultiplier					= s.BreachResponseMultiplier
		,BreachResponseParentSection				= s.BreachResponseParentSection
		,CancelledDate								= s.CancelledDate
		,CancelledReason							= s.CancelledReason
		,CapitaEntryTimeHours						= s.CapitaEntryTimeHours
		,CapitaQCTimeHours							= s.CapitaQCTimeHours
		,CapitaTotalTimeHours						= s.CapitaTotalTimeHours
		,CargoOrFreight								= s.CargoOrFreight
		,CarrierIndicator							= s.CarrierIndicator
		,CheckStatusCode							= s.CheckStatusCode
		,CIPsRiskCode								= s.CIPsRiskCode
		,ClaimBasis									= s.ClaimBasis
		,ClaimBasisCode								= s.ClaimBasisCode
		,ClaimDelegatedTo							= S.ClaimDelegatedTo
		,ClassifiedAsTechnology						= s.ClassifiedAsTechnology													   
		,ClientClassificationCode					= CASE
															WHEN ISNULL(s.ClientClassificationCode, '') = '' THEN 'N/A'
															ELSE s.ClientClassificationCode
														END
		,Comments									= s.Comments
		,Conditions									= s.Conditions
		,ConditionsCode								= s.ConditionsCode
		,ConstructionPeriodFrom						= s.ConstructionPeriodFrom 
		,ConstructionPeriodTo						= s.ConstructionPeriodTo
		,ConstructionTitle							= s.ConstructionTitle
		,ConstructionDays							= s.ConstructionDays
		,ConstructionMonths							= s.ConstructionMonths
		,ContractCertaintyControlsCompliantDate		= s.ContractCertaintyControlsCompliantDate
		,ContractCertaintyEnteredDate				= s.ContractCertaintyEnteredDate
		,ContractCertaintyFullyCompliantDate		= s.ContractCertaintyFullyCompliantDate
		,ContractCertaintyModifiedDate				= s.ContractCertaintyModifiedDate
		,ContractCertaintyPostBindComplete			= ISNULL(s.ContractCertaintyPostBindComplete	  , 0)
		,ContractCertaintyPostBindOnTime			= ISNULL(s.ContractCertaintyPostBindOnTime		  , 0)
		,ContractCertaintyPreBindComplete			= ISNULL(s.ContractCertaintyPreBindComplete		  , 0)
		,ContractCertaintyPreBindOnTime				= ISNULL(s.ContractCertaintyPreBindOnTime		  , 0)
		,ContractCertaintyPreBindSignatureDate		= s.ContractCertaintyPreBindSignatureDate  
		,ContractCertaintyPrimaryCompleteDate		= s.ContractCertaintyPrimaryCompleteDate
		,ContractCertaintyQuestionNote				= s.ContractCertaintyQuestionNote
		,ContractCertaintyRequired					= s.ContractCertaintyRequired
		,ContractCertaintyStatus					= s.ContractCertaintyStatus
		,ContractCertaintyStatusSortOrder			= s.ContractCertaintyStatusSortOrder
		,CoreAccountType							= s.CoreAccountType
		,CoreAccountTypeCode						= s.CoreAccountTypeCode
		,Country									= s.Country
		,CountryCode								= s.CountryCode
		,CoverType									= s.CoverType
		,CoverageForm								= s.CoverageForm
		,CoverageSolution							= s.CoverageSolution
		,CrossSelling								= s.CrossSelling
		,CrossSellingInitiator						= s.CrossSellingInitiator 
		,DateModified								= s.DateModified
		,DaysBetweenConstructionPhaseToandFrom		= s.DaysBetweenConstructionPhaseToandFrom
		,DaysBetweenMaintenanceFromAndTo			= s.DaysBetweenMaintenanceFromAndTo	
		,DaysBetweenQBAndBenchmarkDate				= DATEDIFF(DAY, QuoteOrBindDate, BenchmarkDate)--s.DaysBetweenQBAndBenchmarkDate --BI-8376
		,DaysBetweenQBAndCCCCDateOrToday			= s.DaysBetweenQBAndCCCCDateOrToday
		,DaysBetweenQBAndCCFCDateOrToday			= s.DaysBetweenQBAndCCFCDateOrToday
		,DaysBetweenQBAndCCPCDateOrToday			= s.DaysBetweenQBAndCCPCDateOrToday
		,DaysBetweenQBAndCCPCOrCCPBSDateOrToday		= s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday
		,DaysBetweenQBAndRateChangeDate				= DATEDIFF(DAY, QuoteOrBindDate, RateChangeDate)---s.DaysBetweenQBAndRateChangeDate --BI-8376
		,DaysBetweenTestingFromAndTo				= s.DaysBetweenTestingFromAndTo	
		,DaysSinceQuoteOrBindDate					= DATEDIFF(DAY, QuoteOrBindDate, GETDATE()) --s.DaysSinceQuoteOrBindDate --BI-8376
		,DeclarationWEPInOriginalCCY				= s.DeclarationWEPInOriginalCCY
		,DeductibleAmountInLimitCCY					= s.DeductibleAmountInLimitCCY
		,DeductibleQualifier						= s.DeductibleQualifier
		,DelegatedClaimsAuthority					= ISNULL(s.DelegatedClaimsAuthority, 0)
		,DelegatedClaimsAuthorityName				= IIF(DelegatedClaimsAuthority = 1 , 'Yes' , 'No')--[ODS].[udf_FormatBitAsYesNo](ISNULL(DelegatedClaimsAuthority,0))
		,DepositPremiumInOriginalCCY				= s.DepositPremiumInOriginalCCY
		,DurationMonths								= s.DurationMonths
		,EngineeringProjectName						= s.EngineeringProjectName
		,EngineeringSumInsuredInLimitCCY			= s.EngineeringSumInsuredInLimitCCY
		,EntityGrouping								= s.EntityGrouping
		,EntitySplit								= s.EntitySplit
		,Entity										= s.Entity
		,MarketPlatform								= s.MarketPlatform
		,EquipmentBreakdownContactName				= s.EquipmentBreakdownContactName
		,EquipmentBreakdownContactNumber			= s.EquipmentBreakdownContactNumber
		,EquipmentBreakdownReferral					= s.EquipmentBreakdownReferral
		,ESGPolicyFlag								= ISNULL(s.ESGPolicyFlag, 0)
		,ESGPolicyFlagName							= IIF(ESGPolicyFlag = 1 , 'Yes' , 'No') --[ODS].[udf_FormatBitAsYesNo](s.ESGPolicyFlag)
		,EstimatedSigningMultiplier					= s.EstimatedSigningMultiplier
		,EventLimitAmountInLimitCCY					= s.EventLimitAmountInLimitCCY
		,EventLimitDescription						= s.EventLimitDescription
		,EventLimitQualifier						= s.EventLimitQualifier
		,ExcessAmountInLimitCCY						= s.ExcessAmountInLimitCCY
		,ExcessQualifier							= s.ExcessQualifier
		,ExpectedLossRatioMultiplier				= s.ExpectedLossRatioMultiplier
		,ExpectedPICCTransactions					= s.ExpectedPICCTransactions
		,ExpensesMultiplier                         = s.ExpensesMultiplier     
        ,ExpensesMultiplierName                     = CAST(ROUND(CAST(s.ExpensesMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.ExpensesMultiplier,(2))
		,ExpiringSection							= s.ExpiringSection
		,ExpiryDate									= s.ExpiryDate
		,ExternalAcquisitionCostMultiplier			= s.ExternalAcquisitionCostMultiplier
		,FACRIIndicator								= s.FACRIIndicator
		,Facility									= s.Facility
		,Fees										= s.Fees
		,FirstLiveDate								= s.FirstLiveDate
		,FullQuoteReference							= s.FullQuoteReference
		,FullTimeEquivalents						= s.FullTimeEquivalents
		,GulfOfMexicoRiskPremiumMultiplier			= s.GulfOfMexicoRiskPremiumMultiplier
		,GulfOfMexicoWindstormMultiplier			= s.GulfOfMexicoWindstormMultiplier
		,HasConsortiumLink                          = s.HasConsortiumLink
		,HasGulfOfMexicoExposure					= s.HasGulfOfMexicoExposure
		,HasMultiYearLink							= s.HasMultiYearLink
		,HasParentLink                              = s.HasParentLink
		,HasRateChange								= CASE	
															WHEN s.RateChangeMultiplier > 0 THEN 1 
															ELSE 0 
														END
		,HasReinstatementPremium					= CASE 
															WHEN s.ReinstatementPremiumInOriginalCCY > 0 THEN 1 
															ELSE 0 
														END
		,HazardClass								= s.HazardClass
		,ITVPerSQFT									= s.ITVPerSQFT
		,InceptionDate								= s.InceptionDate
		,IncludeInMunichStacking					= s.IncludeInMunichStacking
		,IncludePML									= s.IncludePML
		,Industry									= s.Industry
		,IndustryCode								= s.IndustryCode
		,IndustryCodeQualifier						= s.IndustryCodeQualifier
		,InnovationCampaign							= s.InnovationCampaign
		,InnovationPremiumMultiplier				= s.InnovationPremiumMultiplier
		,InsuredItem								= s.InsuredItem
		,Interest									= s.Interest
		,InterestCode								= s.InterestCode
		,InwardQuotaShareMultiplier					= s.InwardQuotaShareMultiplier
		,IsBID										= s.IsBID
		,IsBeazleyLead								= s.IsBeazleyLead
		,IsBreachResponseDummy						= s.IsBreachResponseDummy
		,IsPolicyholderAPrivateIndividual			= s.IsPolicyholderAPrivateIndividual
		,IsQuote									= s.IsQuote
		,IsRapidRenewal								= s.IsRapidRenewal
		,IsRenewal									= s.IsRenewal
		,IsRenewed									= s.IsRenewed
		,IsSigned									= s.IsSigned
		,IsSynergySection							= s.IsSynergySection
		,KeyLocationAddress1						= s.KeyLocationAddress1
		,KeyLocationAddress2						= s.KeyLocationAddress2
		,KeyLocationCity							= s.KeyLocationCity
		,KeyLocationCountry							= s.KeyLocationCountry
		,KeyLocationState							= s.KeyLocationState
		,KeyLocationStreetNumber					= s.KeyLocationStreetNumber
		,KeyLocationZipCode							= s.KeyLocationZipCode
		,LatestEPIInOriginalCCY						= s.LatestEPIInOriginalCCY
		,LeaderName									= s.LeaderName
		,LeaderPseudonym							= s.LeaderPseudonym
		,LimitAmountInLimitCCY						= s.LimitAmountInLimitCCY
		,LimitCCYToSettlementCCYRateCurrent			= CASE WHEN ISNULL(s.LimitCCYToSettlementCCYRateCurrent,0) = 0 then 1 ELSE s.LimitCCYToSettlementCCYRateCurrent END
		,LimitDescription							= s.LimitDescription
		,LimitQualifier								= s.LimitQualifier
		,LimitTypeCode								= s.LimitTypeCode
		,LimitTypeDescription						= s.LimitTypeDescription
		,LineMultiplierBand							= s.LineMultiplierBand
		,LineMultiplierBandKey						= ISNULL(s.LineMultiplierBandKey, 0)
		,LinkedConsortiumReference					= s.LinkedConsortiumReference
		,LinkedESGBinderReference					= s.LinkedESGBinderReference
		,LinkedESGSectionReference					= s.LinkedESGSectionReference
		,LinkedNonSynergyReference					= s.LinkedNonSynergyReference
		,LinkedParentReference                      = s.LinkedParentReference
		,LinkedSynergySection						= s.LinkedSynergySection
		,LiveStatus									= ISNULL(s.LiveStatus, '')
		,LloydsClassOfBusiness						= s.LloydsClassOfBusiness
		,LloydsClassOfBusinessCode					= s.LloydsClassOfBusinessCode
		,LocalCurrency								= s.LocalCurrency
		,MASTerritory								= s.MASTerritory
		,MailingAddress1							= s.MailingAddress1
		,MailingAddress2							= s.MailingAddress2
		,MailingCity								= s.MailingCity
		,MailingState								= s.MailingState
		,MailingZipCode								= s.MailingZipCode
		,MaintenancePeriodFrom						= s.MaintenancePeriodFrom
		,MaintenancePeriodTo						= s.MaintenancePeriodTo	
		,MaintenanceMonths							= s.MaintenanceMonths
		,MarketCapitalisation						= s.MarketCapitalisation
		,MigratedPolicy								= s.MigratedPolicy
		,MinimumPremiumInOriginalCCY				= s.MinimumPremiumInOriginalCCY
		,MonthsSinceInception						= s.MonthsSinceInception
		,MonthsSinceInceptionBand					= s.MonthsSinceInceptionBand
		,MonthsSinceInceptionBandKey				= s.MonthsSinceInceptionBandKey
		,MonthsSinceTOT								= s.MonthsSinceTOT
		,MultiYearGroupDurationMonths				= s.MultiYearGroupDurationMonths
		,MultiYearGroupReference					= s.MultiYearGroupReference
		,MultiYearIndicator							= s.MultiYearIndicator
		,NewConditionsExpiryDate					= s.NewConditionsExpiryDate
		,NewConditionsExpiryDateName                = IIF(YEAR(s.NewConditionsExpiryDate )< 1990 OR YEAR(s.NewConditionsExpiryDate)>2050,NULL,FORMAT(s.NewConditionsExpiryDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.NewConditionsExpiryDate)
		,NotifiedIndividuals						= s.NotifiedIndividuals
		,NotifiedIndividualsName					= s.NotifiedIndividualsName
		,NumberOfEmployees							= s.NumberOfEmployees
		,NumberOfLawyers							= s.NumberOfLawyers
		,NumberOfLives								= s.NumberOfLives
		,NumberOfLocations							= s.NumberOfLocations
		,NumberOfReinstatements						= s.NumberOfReinstatements
		,Obligor									= s.Obligor
		,ObligorOccupation							= s.ObligorOccupation
		,ObligorOccupationCode						= s.ObligorOccupationCode
		,Occupation									= s.Occupation
		,OccupationCode								= s.OccupationCode
		,OriginalCCYToLocalCCYRate					= CASE WHEN ISNULL(s.OriginalCCYToLocalCCYRate,0) = 0 then 1 ELSE s.OriginalCCYToLocalCCYRate END --s.OriginalCCYToLocalCCYRate
		,OriginalCCYToSettlementCCYRate				= CASE WHEN ISNULL(s.OriginalCCYToSettlementCCYRate,0) = 0 then 1 ELSE s.OriginalCCYToSettlementCCYRate END--s.OriginalCCYToSettlementCCYRate
		,OriginalCoverageName						= s.OriginalCoverageName
		,OriginalEPIInOriginalCCY					= s.OriginalEPIInOriginalCCY
		,OriginalEPITotalAcquisitionCostMultiplier	= s.OriginalEPITotalAcquisitionCostMultiplier
		,OriginalGrossPremiumInOriginalCCY			= s.OriginalGrossPremiumInOriginalCCY	
		,OriginalInsured							= s.OriginalInsured
		,OriginalInsuredArea						= s.OriginalInsuredArea
		,OriginalInsuredAreaCode					= s.OriginalInsuredAreaCode	
		,OriginalLimitInOriginalCCY					= s.OriginalLimitInOriginalCCY
		,OriginatingSourceSystem					= s.OriginatingSourceSystem
		,PDDeductible								= s.PDDeductible
		,PDSI										= s.PDSI
		,PMLExposure								= s.PMLExposure
		,PMLExposureOurShareUSD						= s.PMLExposureOurShareUSD
		,PMLExposure100PerctShareUSD	   			= s.PMLExposure100PerctShareUSD
		,PMLExposure100PerctShareOrigCcy 			= s.PMLExposure100PerctShareOrigCcy
		,PMLPercentage								= s.PMLPercentage
		,TSI100PercForPMLOrigCcy					= s.TSI100PercForPMLOrigCcy
        ,PolicyRate                                 = s.PolicyRate
		,Peril										= s.Peril
		,PerilCode									= s.PerilCode
		,PremiumIncomeLimitInOriginalCCY			= s.PremiumIncomeLimitInOriginalCCY
		,PremiumRates								= s.PremiumRates
		,PrimaryLegacyReference						= s.PrimaryLegacyReference
		,PrimaryOrExcess							= s.PrimaryOrExcess
		,PrimarySectionURL							= s.PrimarySectionURL
		,PrimarySectionURLLabel						= s.PrimarySectionURLLabel
		,Product									= s.Product
		,ProfitCommissionMultiplier					= s.ProfitCommissionMultiplier
		,ProgramName								= s.ProgramName
		,ProgramNumber								= s.ProgramNumber
		,ProgramPeriod								= s.ProgramPeriod
		,ProgramType								= s.ProgramType 
		,ProgramYear								= s.ProgramYear 
		,QuoteBoundSectionReference					= s.QuoteBoundSectionReference
		,QuoteDaysValid								= s.QuoteDaysValid
		,QuoteLapsedDate							= s.QuoteLapsedDate
		,QuoteOrBindDate							= s.QuoteOrBindDate
		,RatingAdequacyMultiplier					= s.RatingAdequacyMultiplier
		,RateChangeControlComplete					= s.RateChangeControlComplete
		,RateChangeDate								= s.RateChangeDate
		,RateChangeDeductibleMultiplier				= s.RateChangeDeductibleMultiplier
		,RateChangeExposureMultiplier				= s.RateChangeExposureMultiplier
		,RateChangeLimitMultiplier					= s.RateChangeLimitMultiplier
		,RateChangeMethod							= s.RateChangeMethod
		,RateChangeMultiplier						= s.RateChangeMultiplier
		,RateChangeOtherMultiplier					= s.RateChangeOtherMultiplier
		,RateChangeRiskMultiplier					= s.RateChangeRiskMultiplier
		,RateChangeTermsAndConditionsMultiplier		= s.RateChangeTermsAndConditionsMultiplier
		,RateOnLineBandKey							= ISNULL(s.RateOnLineBandKey, 0)
		,RateOnLineBandName							= ISNULL(s.RateOnLineBandName, '')
		,RateOnLineMultiplier						= NULLIF((s.WrittenOrEstimatedPremiumInOriginalCCY / s.OriginalCCYToSettlementCCYRate), 0)
														/
													  NULLIF((s.LimitAmountInLimitCCY / s.LimitCCYToSettlementCCYRateCurrent), 0)--s.RateOnLineMultiplier
		,RateOnLineMultiplierEntered				= s.RateOnLineMultiplierEntered
		,RateOnLinePremiumEnteredInOriginalCCY		= s.RateOnLinePremiumEnteredInOriginalCCY
		,RationaleQuestionnaireComplete				= s.RationaleQuestionnaireComplete
		,RationaleQuestionnaireDate					= s.RationaleQuestionnaireDate
		,ReSigningIndicator							= s.ReSigningIndicator
		,ReactivationReason							= s.ReactivationReason
		,ReactivationReasonCode						= s.ReactivationReasonCode
		,ReinstatementMultiplier					= s.ReinstatementMultiplier
		,ReinstatementPremiumInOriginalCCY			= s.ReinstatementPremiumInOriginalCCY
		,ReinsuranceIndicator						= s.ReinsuranceIndicator
		,RenewalDueDate								= s.RenewalDueDate
		,RenewingSection							= s.RenewingSection
		,RetroInceptionDate							= s.RetroInceptionDate
		,Revenues									= s.Revenues
		,RiskClass									= s.RiskClass
		,RiskClassCode								= s.RiskClassCode
		,SICCode									= s.SICCode
		,SigningNumberDate                          = s.SigningNumberDate
		,SLSpecificCoverage							= s.SLSpecificCoverage
		,ReKeyReference 							= s.ReKeyReference 
		,ReKeySource								= s.ReKeySource
		,SecondarySectionURL						= s.SecondarySectionURL
		,SecondarySectionURLLabel					= s.SecondarySectionURLLabel
		,SectionReferenceCOBCode					= s.SectionReferenceCOBCode
		,SectionReferenceReinsuranceIndicator		= s.SectionReferenceReinsuranceIndicator
		,SectionReferenceSectionIdentifier			= s.SectionReferenceSectionIdentifier
		,SectionStatus								= s.SectionStatus
		,SectionStatusCode							= s.SectionStatusCode
		,SignedLineMultiplier						= s.SignedLineMultiplier
		,SignedOrderMultiplier						= s.SignedOrderMultiplier
		,SimpleProduct								= s.SimpleProduct
		,SpecialPurposeSyndicateApplies				= s.SpecialPurposeSyndicateApplies
		,StatsCode									= s.StatsCode
		,StatsDescription							= s.StatsDescription
		,SubmissionDate								= s.SubmissionDate
		,SwordTreatyCoverage						= s.SwordTreatyCoverage
		,Team										= s.Team
		,TechnicalPremium							= s.TechnicalPremium
		,TechnicalMultiplierName					= CAST(ROUND(CAST(s.TechnicalPremium AS FLOAT) * 100, 2 ) as varchar(50)) + '%'
		,TechnologyCoverageName						= s.TechnologyCoverageName													   
		,TermsOfTradeDate							= s.TermsOfTradeDate
		,TermsOfTradeExpired						= s.TermsOfTradeExpired
		,TerritorialFocusGroup						= s.TerritorialFocusGroup 
		,TerrorismReference							= s.TerrorismReference
		,TestingPeriodFrom							= s.TestingPeriodFrom
		,TestingPeriodTo							= s.TestingPeriodTo
		,TestingMonths								= s.TestingMonths
		,TimeExcess									= s.TimeExcess
		,TimeExcessAmount							= s.TimeExcessAmount
		,TopLocationTSI								= s.TopLocationTSI
		,TotalSignedMultiplier						= s.TotalSignedMultiplier
		,TotalSumInsured							= s.TotalSumInsured
		,TotalWrittenIfNotSignedMultiplier			= ISNULL(s.TotalWrittenIfNotSignedMultiplier, 0)
		,TotalWrittenMultiplier						= ISNULL(s.TotalWrittenMultiplier, 0)
		,TotalSIExposureOurShare					= s.TotalSIExposureOurShare
		,TransactionLiabilityProject				= s.TransactionLiabilityProject
		,TransactionLiabilitySectionType			= s.TransactionLiabilitySectionType
		,TransactionType							= s.TransactionType
		,TransactionTypeCode						= s.TransactionTypeCode
		,TransactionValue							= s.TransactionValue
		,USUnderwritingCoverageCode					= s.USUnderwritingCoverageCode
		,UltimateLossRatioMultiplier				= s.UltimateLossRatioMultiplier
		,VATNumber                                  = s.VATNumber
		,WEPLastUpdatedDate							= s.WEPLastUpdatedDate
		,WrittenIfNotSignedLineMultiplier			= ISNULL(s.WrittenIfNotSignedLineMultiplier, 1)
		,WrittenIfNotSignedOrderMultiplier			= ISNULL(s.WrittenIfNotSignedOrderMultiplier, 0)
		,WrittenLineMultiplier						= ISNULL(s.WrittenLineMultiplier, 0)
		,WrittenOrEstimatedPremiumInOriginalCCY		= s.WrittenOrEstimatedPremiumInOriginalCCY
		,WEPBasis
		,WrittenOrderMultiplier						= s.WrittenOrderMultiplier
		--,TotalSumInsured							= s.TotalSumInsured
		/*DQ fields*/
		,DQ_AdditionalInsuredParty					= s.DQ_AdditionalInsuredParty
		,DQ_Address1								= s.DQ_Address1
		,DQ_Address2								= s.DQ_Address2
		,DQ_Address3								= s.DQ_Address3
		,DQ_FK_PartyBrokerNoticeOfClaim				= ISNULL(s.DQ_FK_PartyBrokerNoticeOfClaim, 0)
		,DQ_FK_PartyBrokerPlacing					= ISNULL(s.DQ_FK_PartyBrokerPlacing, 0)
		,DQ_FK_PartyBrokerProducing					= ISNULL(s.DQ_FK_PartyBrokerProducing, 0)
		,DQ_FK_PartyBrokerServiceOfSuit				= ISNULL(s.DQ_FK_PartyBrokerServiceOfSuit, 0)
		,DQ_FK_YOA									= s.DQ_FK_YOA
		,DQ_InsuredParty							= s.DQ_InsuredParty
		,DQ_MethodOfPlacementCode					= s.DQ_MethodOfPlacementCode
		,DQ_PlacingBrokerContact					= s.DQ_PlacingBrokerContact
		,DQ_ProducingBrokerContact					= s.DQ_ProducingBrokerContact
		,DQ_ReinsuredParty							= s.DQ_ReinsuredParty
		,DQ_UniqueMarketReference					= s.DQ_UniqueMarketReference
		,FK_ATIAClassOfBusiness						= ISNULL(s.FK_ATIAClassOfBusiness, 0)
		,FK_Area									= ISNULL(s.FK_Area, 0)
		,FK_CRMBroker								= ISNULL(s.FK_CRMBroker, 0)
		,FK_ClassOfBusiness							= ISNULL(s.FK_ClassOfBusiness, 0)
		,FK_ClientClassificationCode				= ISNULL(s.FK_ClientClassificationCode, 0)  --???????????  nu pare sa vina de  undeva
		,FK_CurrentWorkflowStatus					= ISNULL(s.FK_CurrentWorkflowStatus						, 0)
		,FK_DurationBand							= ISNULL(s.FK_DurationBand								, 0)
		,FK_EnteredBy								= ISNULL(s.FK_EnteredBy  								, 0)
		,FK_HiddenStatusFilter						= ISNULL(s.FK_HiddenStatusFilter						, 0)
		,FK_LimitCurrency							= ISNULL(s.FK_LimitCurrency								, 0)
		,FK_LocalCurrency							= ISNULL(s.FK_LocalCurrency								, 0)
		,FK_MultiYearGroupDurationBand				= ISNULL(s.FK_MultiYearGroupDurationBand				, 0)
		,FK_OriginalCurrency						= ISNULL(s.FK_OriginalCurrency							, 0)
		,FK_Policy									= ISNULL(s.FK_Policy									, 0)
		,FK_QuoteFilter								= ISNULL(s.FK_QuoteFilter								, 0)
		,FK_ServiceCompany							= ISNULL(s.FK_ServiceCompany							, 0)
		,FK_SettlementCurrency						= ISNULL(s.FK_SettlementCurrency						, 0)
		,FK_TriFocus								= ISNULL(s.FK_TriFocus									, 0)
		,FK_Underwriter								= ISNULL(s.FK_Underwriter								, 0)
		,FK_UnderwriterAssistantContractCertainty	= ISNULL(s.FK_UnderwriterAssistantContractCertainty		, 0)
		,FK_UnderwriterContractCertainty			= ISNULL(s.FK_UnderwriterContractCertainty				, 0)
		,FK_UnderwriterLargeRiskReviewer			= ISNULL(s.FK_UnderwriterLargeRiskReviewer				, 0)
		,FK_UnderwritingPlatform					= ISNULL(s.FK_UnderwritingPlatform						, 0)
		,FK_YOA										= ISNULL(s.FK_YOA										, 0)
		,FK_LinkedESGBinder							= ISNULL(s.FK_LinkedESGBinder							, 0)
		,FK_LinkedESGSection						= ISNULL(s.FK_LinkedESGSection							, 0)
		,FK_LinkedESGTrifocus						= ISNULL(s.FK_LinkedESGTrifocus							, 0)
		,FK_Facility								= s.FK_Facility						
		,IsDeclaration								= s.IsDeclaration					
		,IsFacility									= s.IsFacility						
		,BinderTypeInternalExternal					= s.BinderTypeInternalExternal		
		,FK_ExpiringSection							= s.FK_ExpiringSection				
		,FK_RenewingSection							= s.FK_RenewingSection				
		,FK_BreachResponseParentSection				= s.FK_BreachResponseParentSection	
		,HasDataContractSections					= s.HasDataContractSections			
		,HasNonEurobaseSections						= s.HasNonEurobaseSections			
		,FacilityFilter								= s.FacilityFilter					
		,FacilityType								= s.FacilityType					
		,FK_InternalWrittenBinderStatus				= s.FK_InternalWrittenBinderStatus	
		,FK_ATIAChildSection						= s.FK_ATIAChildSection				
		,SourceOfBusiness							= s.SourceOfBusiness
		,SourceSystem								= s.SourceSystem
		,FK_LinkedSynergySection					= s.FK_LinkedSynergySection
		,HashbytesId								= s.HashbytesId
		,NoticeDate									= s.NoticeDate
		,NotificationThreshold						= s.NotificationThreshold
		,TacitRenewal								= s.TacitRenewal
		-------
		,FK_DateModified                            = IIF(YEAR(s.DateModified) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.DateModified),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.DateModified)
		,FK_QuoteLapsedDate                         = IIF(YEAR(s.QuoteLapsedDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.QuoteLapsedDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.QuoteLapsedDate)
		,FK_InceptionDate                           = IIF(YEAR(s.InceptionDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.InceptionDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.InceptionDate)
		,FK_ExpiryDate                              = IIF(YEAR(s.ExpiryDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ExpiryDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ExpiryDate)
		--,FK_ExpiryDateInForce                       = [Utility].[udf_GenerateDateKey](s.ExpiryDateInForce)-> [ODS].[usp_PostProcessPolicyAndSection]
		,FK_RenewalDueDate                          = IIF(YEAR(s.RenewalDueDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.RenewalDueDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.RenewalDueDate)
		,FK_BenchmarkDate                           = IIF(YEAR(s.BenchmarkDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.BenchmarkDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.BenchmarkDate)
		,FK_QuoteOrBindDate                         = IIF(YEAR(s.QuoteOrBindDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.QuoteOrBindDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.QuoteOrBindDate)
		,FK_CurrentWorkflowStatusFromDate           = '1753-01-01 00:00:00.000' --[Utility].[udf_GenerateDateKey](s.CurrentWorkflowStatusFromDate)-> [ODS].[usp_LoadSectionWorkflow]
		,FK_FirstLiveDate                           = IIF(YEAR(s.FirstLiveDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.FirstLiveDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.FirstLiveDate)
		,FK_WEPLastUpdatedDate                      = IIF(YEAR(s.WEPLastUpdatedDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.WEPLastUpdatedDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.WEPLastUpdatedDate)
		,FK_NewConditionsExpiryDate                 = IIF(YEAR(s.NewConditionsExpiryDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.NewConditionsExpiryDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.NewConditionsExpiryDate)
		--,FK_ExceptionDocumentDate                   = [Utility].[udf_GenerateDateKey](s.ExceptionDocumentDate)-> [ODS].[usp_PostProcessPolicyAndSection]
		,FK_SubmissionDate                          = IIF(YEAR(s.SubmissionDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.SubmissionDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.SubmissionDate)
		,FK_ContractCertaintyControlsCompliantDate  = IIF(YEAR(s.ContractCertaintyControlsCompliantDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyControlsCompliantDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyControlsCompliantDate)
		,FK_ContractCertaintyFullyCompliantDate     = IIF(YEAR(s.ContractCertaintyFullyCompliantDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyFullyCompliantDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyFullyCompliantDate)
		,FK_ContractCertaintyPrimaryCompleteDate    = IIF(YEAR(s.ContractCertaintyPrimaryCompleteDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyPrimaryCompleteDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyPrimaryCompleteDate)
		--,FK_ContractCertaintyDocumentDate           = [Utility].[udf_GenerateDateKey](s.ContractCertaintyDocumentDate)->[ODS].[usp_PostProcessPolicyAndSection]
		,FK_ContractCertaintyPreBindSignatureDate   = IIF(YEAR(s.ContractCertaintyPreBindSignatureDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyPreBindSignatureDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyPreBindSignatureDate)
		,FK_ContractCertaintyEnteredDate            = IIF(YEAR(s.ContractCertaintyEnteredDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyEnteredDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyEnteredDate)
		,FK_ContractCertaintyModifiedDate           = IIF(YEAR(s.ContractCertaintyModifiedDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.ContractCertaintyModifiedDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.ContractCertaintyModifiedDate)
		--,RationaleDate								= [Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,s.RationaleDocumentDate)->[ODS].[usp_PostProcessPolicyAndSection]
		,ExternalAcquisitionCostMultiplierName		= CAST(ROUND(CAST(s.ExternalAcquisitionCostMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.ExternalAcquisitionCostMultiplier,(2))
		,BenchmarkDivisor							= (1)/s.BenchmarkMultiplier
		,BenchmarkDivisorName						= CAST(ROUND(CAST((1)/s.BenchmarkMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage]((1)/s.BenchmarkMultiplier,(2))
		,ExpectedLossRatioMultiplierName			= CAST(ROUND(CAST(s.ExpectedLossRatioMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.ExpectedLossRatioMultiplier,(2))
		,BenchmarkAppliesName						= IIF(BenchmarkApplies = 1 , 'Yes' , 'No') --[ODS].[udf_FormatBitAsYesNo](s.BenchmarkApplies)
		--,EarliestLPSOPremiumSigningDateName			= [ODS].[udf_FormatDateTime](s.EarliestLPSOPremiumSigningDate) -> [ODS].[usp_LoadLPSOTransaction], [ODS].[usp_LoadReinsuranceLPSOTransaction]
		--,EarliestLPSOPremiumSigningNumberName		= isnull(CONVERT([varchar](255),s.EarliestLPSOPremiumSigningNumber),'') -> [ODS].[usp_LoadLPSOTransaction], [ODS].[usp_LoadReinsuranceLPSOTransaction]
		,HasConsortiumLinkName						= IIF(HasConsortiumLink = 1, 'Has Consortium Link', 'No Consortium Link') --[ODS].[udf_FormatBit](s.HasConsortiumLink, 'Has Consortium Link', 'No Consortium Link','No Consortium Link')
		,HasGulfOfMexicoExposureName				= IIF(HasGulfOfMexicoExposure = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.HasGulfOfMexicoExposure)
		,HasMultiYearLinkName						= IIF(HasMultiYearLink = 1, 'Multi-Year Link', 'No Multi-Year Link') --[ODS].[udf_FormatBit](s.HasMultiYearLink,'Multi-Year Link','No Multi-Year Link','No Multi-Year Link')
		,HasParentLinkName                          = IIF(HasParentLink = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.HasParentLink)
		,HasRateChangeName							= IIF((CASE	WHEN RateChangeMultiplier > 0 THEN 1 ELSE 0 END)=1 , 'Yes' , 'No')
														--[ODS].[udf_FormatBitAsYesNo](CASE	
														--								WHEN s.RateChangeMultiplier > 0 THEN 1 
														--								ELSE 0 
														--							END)
		--,HasRationaleDocumentName					= [ODS].[udf_FormatBitAsYesNo](s.HasRationaleDocument) -> [ODS].[usp_PostProcessPolicyAndSection]
		,HasReinstatementPremiumName				=  IIF((CASE	WHEN ReinstatementPremiumInOriginalCCY > 0 THEN 1 ELSE 0 END)=1 , 'Yes' , 'No')
														--[ODS].[udf_FormatBitAsYesNo](CASE 
														--								WHEN s.ReinstatementPremiumInOriginalCCY > 0 THEN 1 
														--								ELSE 0 
														--							END)
		--,HasTreatyAggsTerritoryName					= [ODS].[udf_FormatBitAsYesNo](s.HasTreatyAggsTerritory) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,HasUnderwriterAuthorityExceptionName		= [ODS].[udf_FormatBitAsYesNo](s.HasUnderwriterAuthorityException) -> [ODS].[usp_PostProcessPolicyAndSection]
		,IsRenewalName								= IIF(IsRenewal = 1, 'Renewal','New') --[ODS].[udf_FormatBit](s.IsRenewal,'Renewal','New','New')
		,IsRenewedName								= IIF(IsRenewed = 1, 'Renewed','Not Renewed') --[ODS].[udf_FormatBit](s.IsRenewed,'Renewed','Not Renewed','Not Renewed')
		,IsRapidRenewalName							= IIF(IsRapidRenewal = 1, 'Rapid Renewal','Not Rapid Renewal') --[ODS].[udf_FormatBit](s.IsRapidRenewal,'Rapid Renewal','Not Rapid Renewal','Not Rapid Renewal')
		,IsSignedName								= IIF(IsSigned = 1, 'Signed','Unsigned') --[ODS].[udf_FormatBit](s.IsSigned,'Signed','Unsigned','Unsigned')	
		,IsSynergySectionName						= IIF(IsSynergySection = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](S.IsSynergySection)	
		--,LatestLPSOPremiumSigningDateName			= [ODS].[udf_FormatDateTime](s.LatestLPSOPremiumSigningDate) -> [ODS].[usp_LoadLPSOTransaction], [ODS].[usp_LoadReinsuranceLPSOTransaction]
		--,LatestLPSOPremiumSigningNumberName		= isnull(CONVERT([varchar](255),s.LatestLPSOPremiumSigningNumber),'') -> [ODS].[usp_LoadLPSOTransaction], [ODS].[usp_LoadReinsuranceLPSOTransaction]
		,MultiYearIndicatorName						= IIF(MultiYearIndicator = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.MultiYearIndicator)
		,ProgramNumberName							= isnull(CONVERT([varchar](255),s.ProgramNumber),'')
		,ProgramPeriodName							= isnull(CONVERT([varchar](255),s.ProgramPeriod),'')
		,QuoteOrBindDateName						= IIF(YEAR(s.QuoteOrBindDate )< 1990 OR YEAR(s.QuoteOrBindDate)>2050,NULL,FORMAT(s.QuoteOrBindDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.QuoteOrBindDate)
		,RateChangeDivisor							= (1)/s.RateChangeMultiplier
		,RateChangeDivisorName						= CAST(ROUND(CAST((1)/s.RateChangeMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage]((1)/s.RateChangeMultiplier,(2))
		,RationaleQuestionnaireCompleteName			= IIF(RationaleQuestionnaireComplete = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.RationaleQuestionnaireComplete)
		,RateChangeControlCompleteName				= IIF(RateChangeControlComplete = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.RateChangeControlComplete)
		,RateOnLineMultiplierEnteredName			= CAST(ROUND(CAST(s.RateOnLineMultiplierEntered AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.RateOnLineMultiplierEntered,(2))
		,AdjustmentMultiplierName					= CAST(ROUND(CAST(s.AdjustmentMultiplier AS FLOAT) * 100, 4 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.AdjustmentMultiplier,(4))
		,RationaleQuestionnaireDateName				= IIF(YEAR(s.RationaleQuestionnaireDate )< 1990 OR YEAR(s.RationaleQuestionnaireDate)>2050,NULL,FORMAT(s.RationaleQuestionnaireDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.RationaleQuestionnaireDate)
		--,RationaleDocumentDateName					= [ODS].[udf_FormatDateTime](s.RationaleDocumentDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,ReinstatementMultiplierName				= CAST(ROUND(CAST(s.ReinstatementMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.ReinstatementMultiplier,(2))
		,RetroInceptionDateName						= FORMAT(s.RetroInceptionDate, 'dd-MMM-yyyy')--[ODS].[udf_FormatDateTimeNoRangeCheck](s.RetroInceptionDate)
		,TermsOfTradeDateName						= FORMAT(s.TermsOfTradeDate, 'dd-MMM-yyyy')--[ODS].[udf_FormatDateTimeNoRangeCheck](s.TermsOfTradeDate)
		,SpecialPurposeSyndicateAppliesName			= IIF(SpecialPurposeSyndicateApplies = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.SpecialPurposeSyndicateApplies)
		,SignedLineMultiplierName					= CAST(ROUND(CAST(s.SignedLineMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[[ODS].[udf_FormatMultiplierAsPercentage](s.SignedLineMultiplier,(2))
		,SignedOrderEqualsWrittenOrderName			= case when s.SignedOrderMultiplier=s.WrittenOrderMultiplier then 'Signed Order = Written Order' else 'Signed Order <> Written Order' end
		,SignedOrderMultiplierName					= CAST(ROUND(CAST(s.SignedOrderMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.SignedOrderMultiplier,(2))
		,SwordTreatyCoverageName					= IIF(SwordTreatyCoverage = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.SwordTreatyCoverage)
		,TotalSignedMultiplierName					= CAST(ROUND(CAST(s.TotalSignedMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.TotalSignedMultiplier,(2))
		,TotalWrittenIfNotSignedMultiplierName		= CAST(ROUND(CAST(ISNULL(s.TotalWrittenIfNotSignedMultiplier, 0) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](ISNULL(s.TotalWrittenIfNotSignedMultiplier, 0),(2))
		,TotalWrittenMultiplierName					= CAST(ROUND(CAST(ISNULL(s.TotalWrittenMultiplier, 0) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](ISNULL(s.TotalWrittenMultiplier, 0),(2))
		,WrittenIfNotSignedLineMultiplierName		= CAST(ROUND(CAST(ISNULL(s.WrittenIfNotSignedLineMultiplier, 1) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](ISNULL(s.WrittenIfNotSignedLineMultiplier, 1),(2))
		,WrittenIfNotSignedOrderMultiplierName		= CAST(ROUND(CAST(ISNULL(s.WrittenIfNotSignedOrderMultiplier, 0) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](ISNULL(s.WrittenIfNotSignedOrderMultiplier, 0),(2))
		,WrittenLineMultiplierName					= CAST(ROUND(CAST(ISNULL(s.WrittenLineMultiplier, 0) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](ISNULL(s.WrittenLineMultiplier, 0),(2))
		,WrittenOrderMultiplierName					= CAST(ROUND(CAST(s.WrittenOrderMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.WrittenOrderMultiplier,(2))
		,EstimatedSigningMultiplierName				= CAST(ROUND(CAST(s.EstimatedSigningMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.EstimatedSigningMultiplier,(2))
		--,HasExceptionDocumentName					= [ODS].[udf_FormatBitAsYesNo](s.HasExceptionDocument) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,ExceptionDocumentDateName				= [ODS].[udf_FormatDateTime](s.ExceptionDocumentDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,RationaleDateName							= [ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,s.RationaleDocumentDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,FirstLiveDateName							= IIF(YEAR(s.FirstLiveDate )< 1990 OR YEAR(s.FirstLiveDate)>2050,NULL,FORMAT(s.FirstLiveDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.FirstLiveDate)
		,CapitaEntryTimeName						= FORMAT(CAST(s.CapitaEntryTimeHours/24.000 AS datetime), 'HH:mm:ss')--[ODS].[udf_FormatHoursAsTime](s.CapitaEntryTimeHours)
		,CapitaQCTimeName							= FORMAT(CAST(s.CapitaQCTimeHours/24.000 AS datetime), 'HH:mm:ss')--[ODS].[udf_FormatHoursAsTime](s.CapitaQCTimeHours)
		,CapitaTotalTimeName						= FORMAT(CAST(s.CapitaTotalTimeHours/24.000 AS datetime), 'HH:mm:ss')--[ODS].[udf_FormatHoursAsTime](s.CapitaTotalTimeHours)
		,BenchmarkDateName							= IIF(YEAR(s.BenchmarkDate )< 1990 OR YEAR(s.BenchmarkDate)>2050,NULL,FORMAT(s.BenchmarkDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.BenchmarkDate)
		--,CurrentWorkflowStatusFromDateName			= [ODS].[udf_FormatDateTime](s.CurrentWorkflowStatusFromDate) -> [ODS].[usp_LoadSectionWorkflow]
		,DateModifiedName							= IIF(YEAR(s.DateModified )< 1990 OR YEAR(s.DateModified)>2050,NULL,FORMAT(s.DateModified, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.DateModified)
		--,DaysBetweenQBAndPERDateName				= [ODS].[udf_FormatInt](s.DaysBetweenQBAndPERDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,DaysSinceQuoteOrBindDateName				= format(DATEDIFF(DAY, QuoteOrBindDate,GETDATE()), '###,###,###,###')--([ODS].[udf_FormatInt](DATEDIFF(DAY, QuoteOrBindDate,GETDATE()))) --[ODS].[udf_FormatInt](s.DaysSinceQuoteOrBindDate) --BI-8376
		,ExpiryDateName								= IIF(YEAR(s.ExpiryDate )< 1990 OR YEAR(s.ExpiryDate)>2050,NULL,FORMAT(s.ExpiryDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ExpiryDate)
		,RenewalDueDateName							= IIF(YEAR(s.RenewalDueDate )< 1990 OR YEAR(s.RenewalDueDate)>2050,NULL,FORMAT(s.RenewalDueDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.RenewalDueDate)
		,SignedOrderEqualsWrittenOrder				= case when s.SignedOrderMultiplier=s.WrittenOrderMultiplier then 'Signed Order = Written Order' else 'Signed Order <> Written Order' end
		,MonthsSinceInceptionName					= format(s.MonthsSinceInception, '###,###,###,###')--[ODS].[udf_FormatInt](s.MonthsSinceInception)
		,MonthsSinceTOTName							= format(s.MonthsSinceTOT, '###,###,###,###')--[ODS].[udf_FormatInt](s.MonthsSinceTOT)
		,DurationMonthsName							= format(s.DurationMonths, '###,###,###,###')--[ODS].[udf_FormatInt](s.DurationMonths)
		,MultiYearGroupDurationMonthsName			= format(s.MultiYearGroupDurationMonths, '###,###,###,###')--[ODS].[udf_FormatInt](s.MultiYearGroupDurationMonths)
		,GulfOfMexicoWindstormMultiplierName		= CAST(ROUND(CAST(s.GulfOfMexicoWindstormMultiplier AS FLOAT) * 100, 0 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.GulfOfMexicoWindstormMultiplier,(0))
		,GulfOfMexicoRiskPremiumMultiplierName		= CAST(ROUND(CAST(s.GulfOfMexicoRiskPremiumMultiplier AS FLOAT) * 100, 0 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.GulfOfMexicoRiskPremiumMultiplier,(0))
		,InceptionDateName                          = IIF(YEAR(s.InceptionDate )< 1990 OR YEAR(s.InceptionDate)>2050,NULL,FORMAT(s.InceptionDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.InceptionDate)
		,QuoteDaysValidName                         = format(s.QuoteDaysValid, '###,###,###,###')--[ODS].[udf_FormatInt](s.QuoteDaysValid)
		,QuoteLapsedDateName                        = IIF(YEAR(s.QuoteLapsedDate )< 1990 OR YEAR(s.QuoteLapsedDate)>2050,NULL,FORMAT(s.QuoteLapsedDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.QuoteLapsedDate)
		,RateChangeDateName                         = IIF(YEAR(s.RateChangeDate )< 1990 OR YEAR(s.RateChangeDate)>2050,NULL,FORMAT(s.RateChangeDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.RateChangeDate)
		,DaysBetweenQBAndRateChangeDateName         = format(DATEDIFF(DAY, QuoteOrBindDate, RateChangeDate), '###,###,###,###')--([ODS].[udf_FormatInt](DATEDIFF(DAY, QuoteOrBindDate, RateChangeDate))) --[ODS].[udf_FormatInt](s.DaysBetweenQBAndRateChangeDate) --BI-8376
		,DaysBetweenQBAndBenchmarkDateName          = format(DATEDIFF(DAY, QuoteOrBindDate, BenchmarkDate), '###,###,###,###')--([ODS].[udf_FormatInt](DATEDIFF(DAY, QuoteOrBindDate, BenchmarkDate))) --[ODS].[udf_FormatInt](s.DaysBetweenQBAndBenchmarkDate) --BI-8376
		,WEPLastUpdatedDateName                     = IIF(YEAR(s.WEPLastUpdatedDate )< 1990 OR YEAR(s.WEPLastUpdatedDate)>2050,NULL,FORMAT(s.WEPLastUpdatedDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.WEPLastUpdatedDate)
		,IsRenewalForBordereauxName                 = 'New'
		,HasMarketCapitalisation                    = (case when [MarketCapitalisation] = 0 then 'No' when [MarketCapitalisation] IS NOT NULL  then 'Yes'  else 'No' end) --case when s.MarketCapitalisation IS NOT NULL then 'Yes' else 'No' end --BI-8376
		,MultiYearGroupReferenceName                = CONVERT([varchar](20),s.MultiYearGroupReference)
		,IsBeazleyLeadName                          = IIF(IsBeazleyLead = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.IsBeazleyLead)
		--,NumberOfSections                           =  case when [IsUnknownMember]=(1) then (0) else (1) end
		--,NumberOfDeclarations						= case when s.IsUnknownMember=(1) then (0) else CONVERT([int],s.IsDeclaration) end
		--,NumberOfFacilities							= case when s.IsUnknownMember=(1) then (0) else CONVERT([int],s.IsFacility) end
		--,NumberOfRenewals                           = case when s.IsUnknownMember=(1) then (0) else CONVERT([int],s.IsRenewal) end
		--,NumberOfRenewed                            = case when s.IsUnknownMember=(1) then (0) else CONVERT([int],s.IsRenewed) end
		--,NumberOfNew                                = case when s.IsUnknownMember=(1) then (0) else CONVERT([int],~s.IsRenewal) end
		--,NumberOfBeazleyLed                         = case when s.IsUnknownMember=(1) then (0) else CONVERT([int],s.IsBeazleyLead) end
		,HasProgramLink                             = case when s.ProgramNumber IS NULL then (0) else (1) end
		,HasProgramLinkName                         = case when s.ProgramNumber IS NULL then 'No Program Link' else 'Has Program Link' end
		,FACRIIndicatorName                         = IIF(FACRIIndicator = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.FACRIIndicator)
		,BreachResponseMultiplierName               = CAST(ROUND(CAST(s.BreachResponseMultiplier AS FLOAT) * 100, 1 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.BreachResponseMultiplier,(1))
		,IsBreachResponseDummyName                  = IIF(IsBreachResponseDummy = 1, 'Breach Response Dummy Section','Regular Section') --[ODS].[udf_FormatBit](s.IsBreachResponseDummy,'Breach Response Dummy Section','Regular Section','Regular Section')
		,ProfitCommissionMultiplierName             = CAST(ROUND(CAST(s.ProfitCommissionMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.ProfitCommissionMultiplier,(2))
		,HasProfitCommission                        = case when s.ProfitCommissionMultiplier IS NOT NULL then 'Yes' else 'No' end
		,TermsOfTradeExpiredName                    = IIF(TermsOfTradeExpired = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](TermsOfTradeExpired)
		,ContractCertaintyControlsCompliantDateName = IIF(YEAR(s.ContractCertaintyControlsCompliantDate )< 1990 OR YEAR(s.ContractCertaintyControlsCompliantDate)>2050,NULL,FORMAT(s.ContractCertaintyControlsCompliantDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyControlsCompliantDate)
		,ContractCertaintyFullyCompliantDateName    = IIF(YEAR(s.ContractCertaintyFullyCompliantDate )< 1990 OR YEAR(s.ContractCertaintyFullyCompliantDate)>2050,NULL,FORMAT(s.ContractCertaintyFullyCompliantDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyFullyCompliantDate)
		,ContractCertaintyPrimaryCompleteDateName   = IIF(YEAR(s.ContractCertaintyPrimaryCompleteDate )< 1990 OR YEAR(s.ContractCertaintyPrimaryCompleteDate)>2050,NULL,FORMAT(s.ContractCertaintyPrimaryCompleteDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyPrimaryCompleteDate)
		,ContractCertaintyPreBindSignatureDateName  = IIF(YEAR(s.ContractCertaintyPreBindSignatureDate )< 1990 OR YEAR(s.ContractCertaintyPreBindSignatureDate)>2050,NULL,FORMAT(s.ContractCertaintyPreBindSignatureDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyPreBindSignatureDate)
		--,ContractCertaintyDocumentDateName          = [ODS].[udf_FormatDateTime](s.ContractCertaintyDocumentDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,ContractCertaintyEnteredDateName           = IIF(YEAR(s.ContractCertaintyEnteredDate )< 1990 OR YEAR(s.ContractCertaintyEnteredDate)>2050,NULL,FORMAT(s.ContractCertaintyEnteredDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyEnteredDate)
		,ContractCertaintyModifiedDateName          = IIF(YEAR(s.ContractCertaintyModifiedDate )< 1990 OR YEAR(s.ContractCertaintyModifiedDate)>2050,NULL,FORMAT(s.ContractCertaintyModifiedDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.ContractCertaintyModifiedDate)
		--,HasContractCertaintyDocumentName           = [ODS].[udf_FormatBitAsYesN](s.HasContractCertaintyDocument) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,EngineeringConstructionExpiryDateName      = [ODS].[udf_FormatDateTime](s.EngineeringConstructionExpiryDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,OriginalCurrencyEqualsLimitCurrency        = case when ISNULL(s.FK_OriginalCurrency, 0)=ISNULL(s.FK_LimitCurrency, 0) then 'Original And Limit Currency Same' else 'Original And Limit Currency Different' end
		,DaysBetweenQBAndCCCCDateOrTodayName        = format(s.DaysBetweenQBAndCCCCDateOrToday, '###,###,###,###')--[ODS].[udf_FormatInt](s.DaysBetweenQBAndCCCCDateOrToday)
		,DaysBetweenQBAndCCFCDateOrTodayName        = format(s.DaysBetweenQBAndCCFCDateOrToday, '###,###,###,###')--[ODS].[udf_FormatInt](s.DaysBetweenQBAndCCFCDateOrToday)
		,DaysBetweenQBAndCCPCDateOrTodayName        = format(s.DaysBetweenQBAndCCPCDateOrToday, '###,###,###,###')--[ODS].[udf_FormatInt](s.DaysBetweenQBAndCCPCDateOrToday)
		,DaysBetweenQBAndCCPCOrCCPBSDateOrTodayName = format(s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday, '###,###,###,###')--[ODS].[udf_FormatInt](s.DaysBetweenQBAndCCPCOrCCPBSDateOrToday)
		--,DaysBetweenQBAndCCDocumentDateName         = [ODS].[udf_FormatInt](s.DaysBetweenQBAndCCDocumentDate) -> [ODS].[usp_PostProcessPolicyAndSection]
		,ContractCertaintyPreBindCompleteName       = IIF(ContractCertaintyPreBindComplete = 1, 'Complete','Incomplete') --[ODS].[udf_FormatBit](ISNULL(s.ContractCertaintyPreBindComplete, 0),'Complete','Incomplete','Incomplete')
		,ContractCertaintyPreBindOnTimeName         = IIF(ContractCertaintyPreBindOnTime = 1, 'On Time','Not On Time') --[ODS].[udf_FormatBit](ISNULL(s.ContractCertaintyPreBindOnTime, 0),'On Time','Not On Time','Not On Time')
		,ContractCertaintyPostBindCompleteName      = IIF(ContractCertaintyPostBindComplete = 1, 'Complete','Incomplete') --[ODS].[udf_FormatBit](ISNULL(s.ContractCertaintyPostBindComplete, 0),'Complete','Incomplete','Incomplete')
		,ContractCertaintyPostBindOnTimeName        = IIF(ContractCertaintyPostBindOnTime = 1, 'On Time','Not On Time') --[ODS].[udf_FormatBit](ISNULL(s.ContractCertaintyPostBindOnTime, 0),'On Time','Not On Time','Not On Time')
	    ,ExpectedPICCTransactionsName               = format(s.ExpectedPICCTransactions, '###,###,###,###')--[ODS].[udf_FormatInt](s.ExpectedPICCTransactions)
		--,MissingPICCTransactionsName                = [ODS].[udf_FormatInt](s.MissingPICCTransactions) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,HasMissingPICCTransactionsName             = [ODS].[udf_FormatBitAsYesNo](s.HasMissingPICCTransactions) -> [ODS].[usp_PostProcessPolicyAndSection]
		,BICICessionMultiplierName                  = CAST(ROUND(CAST(s.BICICessionMultiplier AS FLOAT) * 100, 1 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.BICICessionMultiplier,(1))
		,ContractCertaintyRequiredName              = IIF(ContractCertaintyRequired = 1, 'Contract Certainty Required','Contract Certainty Not Required') --[ODS].[udf_FormatBit](s.ContractCertaintyRequired,'Contract Certainty Required','Contract Certainty Not Required','Contract Certainty Not Required')
		,HasDataContractSectionsName                = IIF(HasDataContractSections = 1 , 'Yes' , 'No')  --[ODS].[udf_FormatBitAsYesNo](s.HasDataContractSections)
		--,OccurrenceTerrorismName                    = [ODS].[udf_FormatInt](s.OccurrenceTerrorism) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceSabotageName                     = [ODS].[udf_FormatInt](s.OccurrenceSabotage) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceRSCCMDName                       = [ODS].[udf_FormatInt](s.OccurrenceRSCCMD) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceInsurrectionName                 = [ODS].[udf_FormatInt](s.OccurrenceInsurrection) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceRevolutionName                   = [ODS].[udf_FormatInt](s.OccurrenceRevolution) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceRebellionName                    = [ODS].[udf_FormatInt](s.OccurrenceRebellion) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceMutinyName                       = [ODS].[udf_FormatInt](s.OccurrenceMutiny) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceCoupDEtatName                    = [ODS].[udf_FormatInt](s.OccurrenceCoupDEtat) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceWarName                          = [ODS].[udf_FormatInt](s.OccurrenceWar) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,OccurrenceCivilWarName                     = [ODS].[udf_FormatInt](s.OccurrenceCivilWar) -> [ODS].[usp_PostProcessPolicyAndSection]
		--,HoursClauseName                            = [ODS].[udf_FormatInt](s.HoursClause) -> [ODS].[usp_PostProcessPolicyAndSection]
		,HasLinkedSynergySection                    = case when s.LinkedSynergySection IS NOT NULL then 'Yes' else 'No' end
		,BillingsName                               = format(s.Billings, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.Billings,(0))
		,NumberOfEmployeesName                      = format(s.NumberOfEmployees, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.NumberOfEmployees,(0))
		,FeesName                                   = format(s.Fees, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.Fees,(0))
		,NumberOfLawyersName                        = format(s.NumberOfLawyers, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.NumberOfLawyers,(0))
		,RevenuesName                               = format(s.Revenues, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.Revenues,(0))
		,AdditionalExposuresName                    = format(s.AdditionalExposures, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.AdditionalExposures,(0))
		,NumberOfLivesName                          = format(s.NumberOfLives, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.NumberOfLives,(0))
		,NumberOfLocationsName						= format(s.NumberOfLocations, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.NumberOfLocations,(0))
		,TotalSumInsuredName                        = format(s.TotalSumInsured, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.TotalSumInsured,(0))
		,FullTimeEquivalentsName                    = format(s.FullTimeEquivalents, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.FullTimeEquivalents,(0))
		,MarketCapitalisationName                   = format(s.MarketCapitalisation, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.MarketCapitalisation,(0))
		,TransactionValueName                       = format(s.TransactionValue, '###,###,###,###')--[ODS].[udf_FormatNumeric](s.TransactionValue,(0))
		,InnovationPremiumMultiplierName			= CAST(ROUND(CAST(s.InnovationPremiumMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](s.InnovationPremiumMultiplier,(2))
		,FK_NoticeDate                              = IIF(YEAR(s.NoticeDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, s.NoticeDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](s.NoticeDate)
		,NoticeDateName                             = IIF(YEAR(s.NoticeDate )< 1990 OR YEAR(s.NoticeDate)>2050,NULL,FORMAT(s.NoticeDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](s.NoticeDate)
		,SyndicateViewMultiplier					= CASE 
														WHEN s.CarrierIndicator IN ('BICI', 'BAIC') 
																	AND s.SourceSystem <> 'Eurobase' THEN ISNULL(s.BICICessionMultiplier, 0) 
														ELSE 1 
													End
		,UnderwriterRiskEnteredBy					= s.UnderwriterRiskEnteredBy
		,UnderwriterName							= s.UnderwriterName		
		,UnderwriterAssistant						= s.UnderwriterAssistant
		,KeyBrokerName								= s.KeyBrokerName
		,KeyBrokerSubGroup							= s.KeyBrokerSubGroup
		,KeyBrokerGroup								= s.KeyBrokerGroup
		,KeyBrokerCity								= s.KeyBrokerCity
		,KeyBrokerCountry							= s.KeyBrokerCountry
		,KeyBrokerSourceId							= s.KeyBrokerSourceId
		,AuditModifyDateTime						= s.AuditModifyDateTime
		,AuditCreateDateTime						= s.AuditCreateDateTime
		,AuditModifyDetails							= s.AuditModifyDetails
	FROM Staging.Section s with (nolock)
	WHERE TRY_CAST(ISNULL( (1)/s.RateChangeMultiplier, 0) AS decimal(19,12)) IS NOT NULL

	update s set
	 s.NumberOfSections                         =  case when s.IsUnknownMember=(1) then (0) else (1) end
	,s.NumberOfDeclarations						= case when s.IsUnknownMember=(1) then (0) else CONVERT(int,s.IsDeclaration) end
	,s.NumberOfFacilities						= case when s.IsUnknownMember=(1) then (0) else CONVERT(int,s.IsFacility) end
	,s.NumberOfRenewals                           = case when s.IsUnknownMember=(1) then (0) else CONVERT(int,s.IsRenewal) end
	,s.NumberOfRenewed                            = case when s.IsUnknownMember=(1) then (0) else CONVERT(int,s.IsRenewed) end
	,s.NumberOfNew                                = case when s.IsUnknownMember=(1) then (0) else CONVERT(int,~s.IsRenewal) end
	,s.NumberOfBeazleyLed                         = case when s.IsUnknownMember=(1) then (0) else CONVERT(int,s.IsBeazleyLead) end
	from ODS.Section s

	UPDATE s
	SET BBRServicesFlag = 'Yes'
	FROM ODS.Section s
	INNER JOIN 
	ODS.TriFocus tr ON 
	s.FK_TriFocus = tr.PK_TriFocus
	INNER JOIN 
	ODS.ClassOfBusiness c ON
	s.FK_ClassOfBusiness = c.PK_ClassOfBusiness
	WHERE c.ClassOfBusinessCode  IN ('B4','B5','B6','B7','B8','BK','BL','BQ','B9') 
	OR (tr.TriFocusName like '%BBR Services%' OR tr.TriFocusName like '%BBR Srv%')
	
	
	ALTER TABLE ODS.Section CHECK CONSTRAINT ALL

	EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'CREATE', @SchemaName = 'ODS'

	/*Insert PolicyHiddenStatusFilter records. Policies should show up under all statuses where they have at least one section*/
	
	DELETE 
	FROM  ODS.PolicyHiddenStatusFilter 
	WHERE 
	   FK_Policy			 NOT IN (SELECT DISTINCT PK_Policy FROM ODS.Policy )
	OR FK_HiddenStatusFilter NOT IN (SELECT DISTINCT PK_HiddenStatusFilter FROM ODS.HiddenStatusFilter )

	MERGE ODS.PolicyHiddenStatusFilter target
	USING
	(
	SELECT DISTINCT
		FK_Policy               = s.FK_Policy
		,FK_HiddenStatusFilter  = s.FK_HiddenStatusFilter
	FROM ODS.Section s
	) source
	ON  target.FK_Policy			   = source.FK_Policy
	AND target.FK_HiddenStatusFilter   = source.FK_HiddenStatusFilter

	WHEN MATCHED THEN 
	UPDATE 
	SET 
	target.AuditModifyDateTime         = GETDATE()
	,target.AuditModifyDetails         = 'Merge in ODS.PolicyHiddenStatusFilter table' 

	WHEN NOT MATCHED BY TARGET THEN
	INSERT
	(
		FK_Policy
		,FK_HiddenStatusFilter
		,AuditCreateDateTime   
		,AuditModifyDetails 
	)
	VALUES
	(
		source.FK_Policy
		,source.FK_HiddenStatusFilter
		,GETDATE()
		,'New add in ODS.PolicyHiddenStatusFilter table'
	)
	WHEN NOT MATCHED BY SOURCE THEN DELETE;

	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'PolicyHiddenStatusFilter';
	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Section';

end