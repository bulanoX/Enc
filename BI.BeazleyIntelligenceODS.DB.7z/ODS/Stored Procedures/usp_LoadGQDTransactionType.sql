﻿

CREATE PROC [ODS].[usp_LoadGQDTransactionType]
AS

SET NOCOUNT ON

MERGE [ODS].[GQDTransactionType] target
USING
(

SELECT
IsUnknownMember             = 0
,GQDTransactionTypeCode      = t.Code
,GQDTransactionType         = t.Name
FROM
Staging_MDS.MDS_Staging.GQDTransactionType t

UNION ALL

SELECT
IsUnknownMember             = 1
,GQDTransactionTypeCode     = 'N/A'
,GQDTransactionType         = 'N/A'
) source
ON  target.GQDTransactionTypeCode   = source.GQDTransactionTypeCode
AND target.IsUnknownMember	        = source.IsUnknownMember

WHEN MATCHED THEN 
UPDATE 
SET 
target.GQDTransactionType	        = source.GQDTransactionType
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadGQDTransactionType] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
GQDTransactionTypeCode
,IsUnknownMember	     
,GQDTransactionType
,AuditCreateDateTime   
,AuditModifyDetails 
)
VALUES
(
source.GQDTransactionTypeCode
,source.IsUnknownMember
,source.GQDTransactionType
,GETDATE()
,'New add in [ODS].[usp_LoadGQDTransactionType] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'GQDTransactionType';