﻿

CREATE PROC [ODS].[usp_MaintainDimDate]
AS

SET NOCOUNT ON


IF (OBJECT_ID('tempdb..#RelativePeriodMapping')) IS NOT NULL
DROP TABLE #RelativePeriodMapping

CREATE TABLE #RelativePeriodMapping
(
    RelativePeriodKey           int             NOT NULL
    ,RelativePeriodName         varchar(255)    NOT NULL
    ,PRIMARY KEY (RelativePeriodKey)
)

/*Maximum number of relative periods to go back*/
DECLARE @DaysBack int
DECLARE @WeeksBack int
DECLARE @MonthsBack int
DECLARE @QuartersBack int
DECLARE @YearsBack int

/*Maximum number of relative periods to go forwards*/
DECLARE @DaysForward int
DECLARE @WeeksForward int
DECLARE @MonthsForward int
DECLARE @QuartersForward int
DECLARE @YearsForward int

SET @DaysForward  = 7
SET @WeeksForward = 1
SET @MonthsForward = 6
SET @QuartersForward = 2
SET @YearsForward = 1

SET @DaysBack = -31
SET @WeeksBack = -12
SET @MonthsBack = -12
SET @QuartersBack = -8
SET @YearsBack = -10

--Reset flags
UPDATE d SET 
InLastFull12Months      =   CASE 
                                WHEN DATEDIFF(MONTH, PK_Date, GETDATE()) BETWEEN 1 AND 12 
                                THEN 1 
                                ELSE 0 
                            END
,InLastFull24Months     =   CASE 
                                WHEN DATEDIFF(MONTH, PK_Date, GETDATE()) BETWEEN 1 AND 24 
                                THEN 1 
                                ELSE 0 
                            END
,InRolling9Weeks        =   CASE 
                                WHEN DATEDIFF(WEEK, PK_Date, GETDATE())  BETWEEN -4 AND 4 
                                THEN 1 
                                ELSE 0 
                            END
,RelativeDate           =   DATEDIFF(DAY, GETDATE(), PK_Date)
,RelativeWeek           =   DATEDIFF(WEEK, GETDATE(), PK_Date)
,RelativeMonth          =   DATEDIFF(MONTH, GETDATE(), PK_Date)
,RelativeQuarter        =   DATEDIFF(QUARTER, GETDATE(), PK_Date)
,RelativeYear           =   DATEDIFF(YEAR, GETDATE(), PK_Date)
FROM
ODS.DimDate d
WHERE 
YEAR(d.PK_Date) <> 1753

UPDATE d SET
RelativeDate            =   CASE 
                                WHEN d.RelativeDate < @DaysBack THEN @DaysBack - 1
                                WHEN d.RelativeDate > @DaysForward THEN @DaysForward + 1
                                ELSE d.RelativeDate
                            END
,RelativeWeek           =   CASE
                                WHEN d.RelativeWeek < @WeeksBack THEN @WeeksBack - 1
                                WHEN d.RelativeWeek > @WeeksForward THEN @WeeksForward + 1
                                ELSE d.RelativeWeek
                            END
,RelativeMonth          =   CASE
                                WHEN d.RelativeMonth < @MonthsBack THEN @MonthsBack - 1
                                WHEN d.RelativeMonth > @MonthsForward THEN @MonthsForward + 1
                                ELSE d.RelativeMonth
                            END
,RelativeQuarter        =   CASE
                                WHEN d.RelativeQuarter < @QuartersBack THEN @QuartersBack - 1
                                WHEN d.RelativeQuarter > @QuartersForward THEN @QuartersForward + 1
                                ELSE d.RelativeQuarter
                            END
,RelativeYear           =   CASE
                                WHEN d.RelativeYear < @YearsBack THEN @YearsBack - 1
                                WHEN d.RelativeYear > @YearsForward THEN @YearsForward + 1
                                ELSE d.RelativeYear
                            END
FROM
ODS.DimDate d
WHERE 
YEAR(d.PK_Date) <> 1753

;WITH CTEIntegers AS
(
    SELECT
    IDTY                = -10000
    UNION ALL
    SELECT
    IDTY                = IDTY + 1        
    FROM
    CTEIntegers cte
    WHERE
    IDTY < 10000
)
INSERT INTO #RelativePeriodMapping
(
    RelativePeriodKey
    ,RelativePeriodName
)
SELECT
i.IDTY                                                  AS RelativePeriodKey
,CASE i.IDTY
    WHEN 0 THEN 'Current ~Token~'
    WHEN -1 THEN 'Previous ~Token~'
    WHEN 1 THEN 'Next ~Token~'
    ELSE 'Current ~Token~ ' +
        CASE 
            WHEN i.IDTY < 0 THEN '-'
            WHEN i.IDTY > 0 THEN '+'
        END +
        CAST (ABS(i.IDTY) AS varchar(10))
END                                                     AS RelativePeriod
FROM
CTEIntegers i
OPTION (MAXRECURSION 0)

UPDATE d SET
RelativeDateName        = CASE
                            WHEN d.RelativeDate < @DaysBack THEN 'Prior Days'
                            WHEN d.RelativeDate > @DaysForward THEN 'Future Days'
                            ELSE REPLACE(r_day.RelativePeriodName, '~Token~', 'Day')
                          END
,RelativeWeekName       = CASE
                            WHEN d.RelativeWeek < @WeeksBack THEN 'Prior Weeks'
                            WHEN d.RelativeWeek > @WeeksForward THEN 'Future Weeks'
                            ELSE REPLACE(r_week.RelativePeriodName, '~Token~', 'Week')
                          END
,RelativeMonthName      = CASE
                            WHEN d.RelativeMonth < @MonthsBack THEN 'Prior Months'
                            WHEN d.RelativeMonth > @MonthsForward THEN 'Future Months'
                            ELSE REPLACE(r_month.RelativePeriodName, '~Token~', 'Month')
                          END
,RelativeQuarterName    = CASE
                            WHEN d.RelativeQuarter < @QuartersBack THEN 'Prior Quarters'
                            WHEN d.RelativeQuarter > @QuartersForward THEN 'Furure Quarters'
                            ELSE REPLACE(r_quarter.RelativePeriodName, '~Token~', 'Quarter')
                          END
,RelativeYearName       = CASE
                            WHEN d.RelativeYear < @YearsBack THEN 'Prior Years'
                            WHEN d.RelativeYear > @YearsForward THEN 'Future Years'
                            ELSE REPLACE(r_year.RelativePeriodName, '~Token~', 'Year')
                          END
FROM
ODS.DimDate d
LEFT OUTER JOIN
#RelativePeriodMapping r_day ON 
d.RelativeDate = r_day.RelativePeriodKey
LEFT OUTER JOIN
#RelativePeriodMapping r_week ON
d.RelativeWeek = r_week.RelativePeriodKey
LEFT OUTER JOIN
#RelativePeriodMapping r_month ON
d.RelativeMonth = r_month.RelativePeriodKey
LEFT OUTER JOIN
#RelativePeriodMapping r_quarter ON
d.RelativeQuarter = r_quarter.RelativePeriodKey
LEFT OUTER JOIN
#RelativePeriodMapping r_year ON
d.RelativeYear = r_year.RelativePeriodKey
WHERE
YEAR(d.PK_Date) <> 1753

UPDATE d SET
RelativeWeekName = d.RelativeWeekName   + ' (' + CAST(DAY(x.FirstDate) AS varchar(2)) + '/' + CAST(MONTH(x.FirstDate) AS varchar(2)) + '/' + CAST(YEAR(x.FirstDate) AS varchar(4))
                                        + ' - ' + CAST(DAY(x.LastDate) AS varchar(2)) + '/' + CAST(MONTH(x.LastDate) AS varchar(2)) + '/' + CAST(YEAR(x.LastDate) AS varchar(4)) + ')'
FROM
ODS.DimDate d
INNER JOIN
(
    SELECT
    RelativeWeek    = d.RelativeWeek
    ,FirstDate      = MIN(d.PK_Date)
    ,LastDate       = MAX(d.PK_Date) 
    FROM
    ODS.DimDate d
    WHERE
    YEAR(d.PK_Date) <> 1753
    GROUP BY
    d.RelativeWeek
) x ON
d.RelativeWeek = x.RelativeWeek
WHERE
YEAR(d.PK_Date) <> 1753
AND d.RelativeWeek BETWEEN @WeeksBack AND @WeeksForward

IF (OBJECT_ID('tempdb..#RelativePeriodMapping')) IS NOT NULL
DROP TABLE #RelativePeriodMapping