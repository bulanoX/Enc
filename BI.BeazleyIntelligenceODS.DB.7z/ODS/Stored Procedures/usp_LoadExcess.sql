﻿CREATE PROCEDURE [ODS].[usp_LoadExcess]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Excess

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


IF OBJECT_ID('tempdb..#ExcessTemp') IS NOT NULL
DROP TABLE #ExcessTemp

CREATE TABLE #ExcessTemp 
(
    [IsUnknownMember]		BIT NOT NULL,
	[ExcessCode]			VARCHAR(255) NOT NULL,
	[ExcessName]			VARCHAR(255) NULL
)

-- Insert Unknown member
INSERT INTO #ExcessTemp 
(
	IsUnknownMember
	,ExcessCode
	,ExcessName
) 
SELECT
	IsUnknownMember     = 1
	,ExcessCode			= 'N/A'
	,ExcessName         = 'N/A'

;WITH CTE_Excess (ExcessCode, ExcessName, RowNo)
AS
(
	SELECT DISTINCT
		 ExcessCode	= REPLACE(LTRIM(RTRIM(se.ExcessCode)), Char(10),'')
		,ExcessName	= se.ExcessName
		,RowNo			= ROW_NUMBER() OVER (PARTITION BY REPLACE(LTRIM(RTRIM(se.ExcessCode)), Char(10),'') ORDER BY se.ExcessName)
	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionExcess se
	WHERE ISNULL(se.ExcessCode,'') <> ''
		--AND se.SourceSystem IN ('Eurobase','Unirisx','Gamechanger', 'myBeazley')  
	--	AND (se.AuditCreateDatetime > @LastAuditDate OR se.AuditModifyDatetime > @LastAuditDate)
) 

-- Eurobase, Unirisx and GameChanger deductibles
INSERT INTO #ExcessTemp
(
	IsUnknownMember
	,ExcessCode
	,ExcessName
)
SELECT 
	IsUnknownMember			= 0
	,ExcessCode				= se.ExcessCode
	,ExcessName				= se.ExcessName
FROM CTE_Excess se
WHERE se.RowNo = 1


-- BeazleyPro deductibles
INSERT INTO #ExcessTemp
(
	IsUnknownMember
	,ExcessCode
	,ExcessName
)
SELECT DISTINCT
	 IsUnknownMember	   = 0
	,DeductibleCode        = q.Prompt
	,DeductibleName        = q.Prompt
FROM 
Staging_Matlock.Matlock_Staging.vw_Policy p

INNER JOIN Staging_Matlock.Matlock_Staging.vw_PolicyRecord pr 
ON pr.matlockkey = p.CurrentPolicyRecordId

INNER JOIN Staging_Matlock.Matlock_Staging.vw_PolicyRecordAnswer pra 
ON pra.PolicyRecordId = pr.matlockkey

INNER JOIN Staging_Matlock.Matlock_Staging.vw_Question q 
ON q.matlockkey = pra.questionid

WHERE 
	NOT EXISTS
	(SELECT 1 FROM #ExcessTemp e WHERE e.ExcessCode = q.prompt)
	AND pra.subheading = 'deductibles'


MERGE ODS.Excess AS TARGET
USING 
#ExcessTemp AS SOURCE
ON (
		ISNULL(Source.ExcessCode, 'Not Available') = ISNULL(Target.ExcessCode, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
)
WHEN MATCHED THEN
UPDATE SET
   target.ExcessCode				= source.ExcessCode
   ,target.ExcessName				= source.ExcessName
   ,target.AuditModifyDateTime		= GETDATE()						
   ,target.AuditModifyDetails		= 'Merge in ODS.usp_LoadExcess proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    IsUnknownMember
    ,ExcessCode
    ,ExcessName
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.IsUnknownMember
    ,source.ExcessCode
    ,source.ExcessName
	,GETDATE()
	,'New add in ODS.usp_LoadExcess proc'	
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Excess';