﻿ CREATE PROCEDURE  [ODS].[usp_LoadSectionLimitDeductibles]
 AS
 
 SET NOCOUNT ON
 
 
 
 IF (OBJECT_ID('tempdb..#SectionLimit') IS NOT NULL) 
 DROP TABLE #SectionLimit
 
 CREATE TABLE #SectionLimit
 (
     SectionReference                        varchar(255)    NOT NULL
 	,SublimitCode						    varchar(255)    NULL
     ,LimitCurrency							varchar(255)    NULL
     ,LimitAmountInLimitCCY                  numeric(19,4)	NULL
 	,LimitTypeCode							varchar(255)    NULL
 )
 
 TRUNCATE TABLE #SectionLimit
 
 INSERT INTO #SectionLimit
 (
     SectionReference
     ,SublimitCode
     ,LimitCurrency
     ,LimitAmountInLimitCCY
 	,LimitTypeCode
 )
 SELECT 
 	 SectionReference			 = s.SectionReference
     ,SublimitCode                = LTRIM(RTRIM(sl.LimitCode))
     ,LimitCurrency               = sl.LimitCurrency
     ,LimitAmountInLimitCCY		 = sl.LimitAmountInLimitCCY 
 	,LimitTypeCode				 = sl.LimitTypeCode
 FROM 
 BeazleyIntelligenceDataContract.Outbound.vw_SectionLimit sl
 JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section s
 ON sl.SourceSystem = s.SourceSystem and sl.SectionSourceId = s.SectionSourceId
 --WHERE sl.LimitTypeCode <> ''
 
 -- Load Limits TO SectionLimit	
 
 ;MERGE ODS.SectionLimit
 AS TARGET
 USING  ( SELECT  FK_Section							= s.PK_Section
 				,FK_Sublimit						= ISNULL(lq.PK_Sublimit, 0)
 				,FK_LimitCurrency					= ISNULL(oc_lim.PK_OriginalCurrency, 0)
 				,FK_SublimitType					= ISNULL(lqt.PK_SublimitType, 0)
 				,LimitAmountInLimitCCY				= MAX(sl.LimitAmountInLimitCCY)
 
 				FROM
 				#SectionLimit sl
 
 				INNER JOIN
 				ODS.Section s ON
 				sl.SectionReference = s.SectionReference
 
 				LEFT JOIN
 				ODS.Sublimit lq ON
 				sl.SublimitCode = lq.SublimitCode
 
 				LEFT JOIN 
 				ODS.OriginalCurrency oc_lim ON
 				sl.LimitCurrency = oc_lim.CurrencyCode
 
 				LEFT JOIN
 				ODS.SublimitType lqt ON
 				sl.LimitTypeCode = lqt.LimitTypeCode
 
 				GROUP BY 	
 						 s.PK_Section
 						,ISNULL(lq.PK_Sublimit, 0)
 						,ISNULL(oc_lim.PK_OriginalCurrency, 0)
 						,ISNULL(lqt.PK_SublimitType, 0)
 
 ) AS SOURCE
 ON   SOURCE.FK_Section = TARGET.FK_SECTION
  AND SOURCE.FK_Sublimit = TARGET.FK_Sublimit
  AND SOURCE.FK_LimitCurrency = TARGET.FK_LimitCurrency
  AND SOURCE.FK_SublimitType = TARGET.FK_SublimitType
 
 WHEN MATCHED THEN
 UPDATE SET
  target.LimitAmountInLimitCCY   = source.LimitAmountInLimitCCY
 ,target.AuditModifyDateTime	    = GETDATE()						
 ,target.AuditModifyDetails	    = 'Merge in ODS.SectionLimit'
 
 
 WHEN NOT MATCHED BY TARGET THEN
 INSERT
 (  FK_Section 
   ,FK_Sublimit    
   ,FK_LimitCurrency
   ,FK_SublimitType
   ,LimitAmountInLimitCCY
   ,AuditCreateDateTime
   ,AuditModifyDetails
 )
 VALUES
 ( 
    source.FK_Section 
   ,source.FK_Sublimit       
   ,source.FK_LimitCurrency 
   ,source.FK_SublimitType
   ,source.LimitAmountInLimitCCY
   ,GETDATE()
   ,'New add in ODS.SectionLimit'	
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE;
 
 
 
 -- Deductibles
 
 -- Load Eurobase deductibles
 IF (OBJECT_ID('tempdb..#SectionExcess') IS NOT NULL) 
 DROP TABLE #SectionExcess
 
 CREATE TABLE #SectionExcess
 (
      SectionReference                   VARCHAR(255)    NOT NULL
 	,ExcessCode							VARCHAR(255)    NULL
     ,ExcessCurrency						VARCHAR(255)    NULL
     ,ExcessAmountInExcessCCY            NUMERIC(19,4)	NULL
 )
 
 TRUNCATE TABLE #SectionExcess
 
 INSERT INTO #SectionExcess
 (
      SectionReference
 	,ExcessCode
     ,ExcessCurrency
     ,ExcessAmountInExcessCCY
 )
 SELECT  
 	 SectionReference			= s.SectionReference
 	,ExcessCode					= LTRIM(RTRIM(se.ExcessCode))
 	,ExcessCurrency				= se.ExcessCurrency
 	,ExcessAmountInExcessCCY	= se.ExcessAmountInExcessCCY 
 
 FROM
 BeazleyIntelligenceDataContract.Outbound.vw_SectionExcess se
 JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section s
 ON se.SourceSystem = s.SourceSystem and se.SectionSourceId = s.SectionSourceId
 
 ;MERGE ODS.SectionExcess
 AS TARGET
 USING  (    SELECT
 			 FK_Section							= s.PK_Section
 			,FK_Excess						    = ISNULL(le.PK_Excess, 0)
 			,FK_ExcessCurrency					= ISNULL(oc_lim.PK_OriginalCurrency, 0)
 			,ExcessAmountInExcessCCY			= MAX(sl.ExcessAmountInExcessCCY)
 
 			FROM
 			#SectionExcess sl
 
 			INNER JOIN
 			ODS.Section s ON
 			sl.SectionReference = s.SectionReference
 
 			LEFT JOIN
 			ODS.Excess le ON
 			sl.ExcessCode = le.ExcessCode
 
 			LEFT JOIN 
 			ODS.OriginalCurrency oc_lim ON
 			sl.ExcessCurrency = oc_lim.CurrencyCode
 
 			GROUP BY 	
 					 s.PK_Section
 					,ISNULL(le.PK_Excess, 0)
 					,ISNULL(oc_lim.PK_OriginalCurrency, 0)	
 	) AS SOURCE
 ON   SOURCE.FK_Section = TARGET.FK_SECTION
  AND SOURCE.FK_Excess  = TARGET.FK_Excess
  AND SOURCE.FK_ExcessCurrency = TARGET.FK_ExcessCurrency
 
 
 WHEN MATCHED THEN
 UPDATE SET
  target.ExcessAmountInExcessCCY   = source.ExcessAmountInExcessCCY
 ,target.AuditModifyDateTime	    = GETDATE()						
 ,target.AuditModifyDetails	    = 'Merge in ODS.SectionExcess'
 
 WHEN NOT MATCHED BY TARGET THEN
 INSERT
 (  FK_Section 
   ,FK_Excess    
   ,FK_ExcessCurrency     
   ,ExcessAmountInExcessCCY
   ,AuditCreateDateTime
   ,AuditModifyDetails
 )
 VALUES
 ( 
    source.FK_Section 
   ,source.FK_Excess       
   ,source.FK_ExcessCurrency     
   ,source.ExcessAmountInExcessCCY
   ,GETDATE()
   ,'New add in ODS.SectionExcess'	
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE;
 
 
 
 IF OBJECT_ID('tempdb..#BMSublimit') IS NOT NULL
 DROP TABLE #BMSublimit
 
 IF OBJECT_ID('tempdb..#USBRSublimit') IS NOT NULL
 DROP TABLE #USBRSublimit
 
 IF OBJECT_ID('tempdb..#SectionLimit') IS NOT NULL
 DROP TABLE #SectionLimit
 
 IF OBJECT_ID('tempdb..#SectionExcess') IS NOT NULL
 DROP TABLE #SectionExcess
 GO
 
 
 