﻿CREATE PROCEDURE [ODS].[usp_LoadSyndicateSplit]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#SyndicateSplit') IS NOT NULL)
DROP TABLE #SyndicateSplit

CREATE TABLE #SyndicateSplit
(
    [FK_Syndicate] [bigint] NOT NULL,
	[FK_YOA] [bigint] NOT NULL,
	[SyndicateMultiplier] [numeric](19, 12) NOT NULL
)

INSERT INTO #SyndicateSplit
(
    FK_Syndicate
    ,FK_YOA
    ,SyndicateMultiplier
)
SELECT
FK_Syndicate            = s.PK_Syndicate
,FK_YOA                 = y.PK_YOA
,SyndicateMultiplier    = ISNULL(Utility.udf_ProcessPercentage(ss.SyndicateSplitPercent, 1, 0, 0), 0)
FROM
Staging_MDS.dbo.vw_syndicate_split ss
INNER JOIN
ODS.Syndicate s ON
ss.SyndicateSplitNumber = s.SyndicateNumber
INNER JOIN
ODS.YOA y ON
ss.SyndicateSplitYOA = y.PK_YOA

MERGE ODS.SyndicateSplit AS TARGET

USING #SyndicateSplit AS SOURCE

 ON TARGET.FK_Syndicate   = SOURCE.FK_Syndicate
AND TARGET.FK_YOA         = SOURCE.FK_YOA

WHEN MATCHED THEN

UPDATE SET 
 TARGET.FK_Syndicate          = SOURCE.FK_Syndicate
,TARGET.FK_YOA                = SOURCE.FK_YOA
,TARGET.SyndicateMultiplier   = SOURCE.SyndicateMultiplier
,TARGET.AuditModifyDateTime   = GETDATE()						
,TARGET.AuditModifyDetails	  = 'Merge in [ODS].[SyndicateSplit] table' 

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 FK_Syndicate
    ,FK_YOA
	,SyndicateMultiplier
	,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_Syndicate
,SOURCE.FK_YOA
,SOURCE.SyndicateMultiplier
,'New in [ODS].[SyndicateSplit] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

IF (OBJECT_ID('tempdb..#SyndicateSplit') IS NOT NULL)
DROP TABLE #SyndicateSplit