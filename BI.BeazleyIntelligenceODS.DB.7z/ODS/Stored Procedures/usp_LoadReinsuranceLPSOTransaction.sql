﻿CREATE PROCEDURE 
[ODS].[usp_LoadReinsuranceLPSOTransaction]
AS

SET NOCOUNT ON

--Truncate Tables
TRUNCATE TABLE ODS.ReinsuranceLPSOTransaction
TRUNCATE TABLE ODS.ReinsuranceLPSOTransactionLine

IF (OBJECT_ID('tempdb..#ReinsuranceLPSOTransactionWorking') IS NOT NULL)
DROP TABLE #ReinsuranceLPSOTransactionWorking

CREATE TABLE #ReinsuranceLPSOTransactionWorking
(
    GroupKey                                BIGINT          NOT NULL
    ,SigningDate                            DATETIME        NOT NULL
    ,SigningNumber                          INT             NOT NULL
    ,BrokerSigningDate                      DATETIME        NULL
    ,BrokerSigningNumber                    INT             NULL
    ,ProcessingDate                         DATETIME        NULL
    ,ProcessingPeriodDate                   DATETIME        NULL
    ,SettlementDate                         DATETIME        NULL
    ,ActualPaymentDate                      DATETIME        NULL
    ,CategoryCode                           INT             NOT NULL
	,Category                               VARCHAR(255)    NOT NULL 
    ,BusinessCategoryCode                   varchar(15)     NULL
	,BusinessCategory                       VARCHAR(255)    NULL
    ,RiskClassCode                          VARCHAR(15)     NULL
	,RiskClass                              VARCHAR(255)    NULL
    ,FilCode                                VARCHAR(15)     NULL
	,Fil                                    VARCHAR(255)    NULL
    ,DTICode                                VARCHAR(15)     NULL
    ,QualCatCode                            VARCHAR(1)      NULL
	,QualCat                                VARCHAR(255)    NULL
    ,GQDTransactionTypeCode                 VARCHAR(255)    NULL
    ,OriginalCCY                            VARCHAR(15)     NULL
    ,AmountInSettlementCCY                  NUMERIC(38,12)  NOT NULL
    ,VATAmountInSettlementCCY               NUMERIC(38,12)  NOT NULL
    ,DelinkedAmountInSettlementCCY          NUMERIC(38,12)  NOT NULL
    ,OriginalCCYToSettlementCCYRate         NUMERIC(19,12)  NOT NULL
    --Treat + and - as separate totals, because otherwise we lose information when the sum is 0
    ,PositiveAmountInOriginalCCY            NUMERIC(38,12)  NULL
    ,PositiveVATAmountInOriginalCCY         NUMERIC(38,12)  NULL
    ,PositiveDelinkedAmountInOriginalCCY    NUMERIC(38,12)  NULL
    ,NegativeAmountInOriginalCCY            NUMERIC(38,12)  NULL
    ,NegativeVATAmountInOriginalCCY         NUMERIC(38,12)  NULL
    ,NegativeDelinkedAmountInOriginalCCY    NUMERIC(38,12)  NULL
    ,SectionReference                       VARCHAR(255)    NOT NULL
    ,SyndicateNumber                        INT             NOT NULL
    ,SettlementCCY                          VARCHAR(255)    NOT NULL
    ,OriginalAcquisitionCostMultiplier      NUMERIC(19,12)  NULL
    ,ExternalAcquisitionCostMultiplier      NUMERIC(19,12)  NOT NULL
    ,InternalAcquisitionCostMultiplier      NUMERIC(19,12)  NOT NULL
    ,FK_YOA                                 BIGINT          NOT NULL
    ,FK_ClaimExposure                       BIGINT          NULL
)

/*Working table*/
INSERT INTO #ReinsuranceLPSOTransactionWorking
(
    GroupKey
    ,SigningDate
    ,SigningNumber
    ,BrokerSigningDate
    ,BrokerSigningNumber
    ,ProcessingDate
    ,ProcessingPeriodDate
    ,SettlementDate
    ,ActualPaymentDate
    ,CategoryCode
	,Category
    ,BusinessCategoryCode
	,BusinessCategory
    ,RiskClassCode
	,RiskClass
    ,FilCode
	,Fil
    ,DTICode
    ,QualCatCode
	,QualCat
	,GQDTransactionTypeCode 
    ,OriginalCCY
    ,OriginalCCYToSettlementCCYRate
    ,AmountInSettlementCCY
    ,VATAmountInSettlementCCY
    ,DelinkedAmountInSettlementCCY
    ,SectionReference
    ,SyndicateNumber
    ,SettlementCCY
    ,OriginalAcquisitionCostMultiplier
    ,ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier
    ,FK_YOA
    ,FK_ClaimExposure
)
SELECT 
GroupKey                                = 0
,SigningDate                            = rt.SigningDate
,SigningNumber                          = rt.SigningNumber
,BrokerSigningDate                      = rt.BrokerSigningDate
,BrokerSigningNumber                    = rt.BrokerSigningNumber
,ProcessingDate                         = rt.ProcessingDate
,ProcessingPeriodDate                   = rt.ProcessingPeriodDate
,SettlementDate                         = rt.SettlementDate
,ActualPaymentDate                      = rt.ActualPaymentDate
,CategoryCode                           = rt.CategoryCode
,Category                               = rt.Category
,BusinessCategoryCode                   = rt.BusinessCategoryCode
,BusinessCategory                       = rt.BusinessCategory
,RiskClassCode                          = rt.RiskClassCode
,RiskClass                              = rt.RiskClass
,FilCode                                = rt.FilCode
,Fil                                    = rt.Fil
,DTICode                                = rt.DTICode
,QualCatCode                            = rt.QualCatCode
,QualCat                                = rt.QualCat
,GQDTransactionTypeCode                 = rt.GQDTransactionTypeCode
,OriginalCCY                            = rt.OriginalCurrency
,OriginalCCYToSettlementCCYRate         = rt.OriginalCCYToSettlementCCYRate
,AmountInSettlementCCY                  = rt.AmountInSettlementCCY
,VATAmountInSettlementCCY               = rt.VATAmountInSettlementCCY
,DelinkedAmountInSettlementCCY          = rt.DelinkedAmountInSettlementCCY
,SectionReference                       = rt.SectionReference
,SyndicateNumber                        = rt.SyndicateNumber
,SettlementCCY                          = rt.SettlementCurrency
,OriginalAcquisitionCostMultiplier      = rt.OriginalAcquisitionCostMultiplier
                                          
,ExternalAcquisitionCostMultiplier      = 0 --Set later
,InternalAcquisitionCostMultiplier      = 0 --Set later
,FK_YOA                                 = ISNULL(yoa.PK_YOA, 0)
,FK_ClaimExposure                       = ce.PK_ClaimExposure
FROM
BeazleyIntelligenceDataContract.Outbound.vw_ReinsuranceFinancialTransaction rt with (nolock) 
LEFT OUTER JOIN
ODS.YOA yoa with (nolock) ON
rt.YearOfAccount = yoa.PK_YOA
/* This join does not bring any values but needs to stay here just in case at some point there might come a reinsurance transaction which is linked to a claim. 
This FK_ClaimExposure is used a filter in Red.usp_LoadFactReinsuranceCombinedFinancialTransaction where we take the data from ODS.ReinsuranceLPSOTransaction
but only for the rows that have FK_ClaimExposure = NULL */
LEFT OUTER JOIN
ODS.ClaimExposure ce with (nolock) ON
rt.ClaimExposureSourceId = ce.SCMReference
AND rt.OriginatingBureau = ce.OriginatingBureau
WHERE rt.SourceSystem = 'Eurobase'
--AND rt.IsActive = 1


CREATE NONCLUSTERED INDEX IX_TMP_ReinsuranceLPSOTransactionWorking_RI
ON #ReinsuranceLPSOTransactionWorking ([CategoryCode])
INCLUDE ([AmountInSettlementCCY],[VATAmountInSettlementCCY],[DelinkedAmountInSettlementCCY],[SectionReference])

CREATE NONCLUSTERED INDEX IX_TMP_ReinsuranceLPSOTransactionWorking_RI2
ON #ReinsuranceLPSOTransactionWorking ([SectionReference])



/*Convert settlement currency amounts to original currency and populate +/- fields*/
UPDATE lt SET
PositiveAmountInOriginalCCY                     = CASE WHEN lt.AmountInSettlementCCY > 0            THEN lt.AmountInSettlementCCY           * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveVATAmountInOriginalCCY                 = CASE WHEN lt.VATAmountInSettlementCCY > 0         THEN lt.VATAmountInSettlementCCY        * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveDelinkedAmountInOriginalCCY            = CASE WHEN lt.DelinkedAmountInSettlementCCY > 0    THEN lt.DelinkedAmountInSettlementCCY   * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeAmountInOriginalCCY                    = CASE WHEN lt.AmountInSettlementCCY < 0            THEN lt.AmountInSettlementCCY           * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeVATAmountInOriginalCCY                 = CASE WHEN lt.VATAmountInSettlementCCY < 0         THEN lt.VATAmountInSettlementCCY        * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeDelinkedAmountInOriginalCCY            = CASE WHEN lt.DelinkedAmountInSettlementCCY < 0    THEN lt.DelinkedAmountInSettlementCCY   * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
FROM
#ReinsuranceLPSOTransactionWorking lt

UPDATE lt SET
GroupKey        =       CONVERT(BIGINT,HASHBYTES('SHA2_256',--Utility.udf_ComputeIdentity
                        (
                            lt.SectionReference
                            + '|~|' + ISNULL(CONVERT(varchar, lt.SigningDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.SigningNumber AS varchar(50)), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.BrokerSigningDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.BrokerSigningNumber AS varchar(50)), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ProcessingDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ProcessingPeriodDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.SettlementDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ActualPaymentDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.CategoryCode AS varchar(50)), '')
                            + '|~|' + ISNULL(lt.BusinessCategoryCode, '')
                            + '|~|' + ISNULL(lt.RiskClassCode, '')
                            + '|~|' + ISNULL(lt.OriginalCCY, '')
                            + '|~|' + ISNULL(lt.FilCode, '')
                            + '|~|' + ISNULL(lt.DTICode, '')
                            + '|~|' + ISNULL(lt.QualCatCode, '')
                            + '|~|' + ISNULL(CAST(lt.OriginalCCYToSettlementCCYRate AS varchar(50)), '')
                            + '|~|' + ISNULL(lt.SettlementCCY, '')
                            + '|~|' + ISNULL(CAST(lt.FK_YOA AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.FK_ClaimExposure AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.ExternalAcquisitionCostMultiplier AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.InternalAcquisitionCostMultiplier AS varchar(255)), '')
                        )))--, 0)
FROM
#ReinsuranceLPSOTransactionWorking lt

CREATE INDEX IX_tmpReinsuranceLPSOTransactionWorking ON #ReinsuranceLPSOTransactionWorking (GroupKey)

ALTER TABLE ODS.ReinsuranceLPSOTransaction NOCHECK CONSTRAINT ALL
--Grouping on GroupKey guarantees unique values for all the fields due to the way that GroupKey is generated,
--so we use MAX() to take one of the values
INSERT INTO ODS.ReinsuranceLPSOTransaction WITH (TABLOCK)
(
     PK_LPSOTransaction
    ,SigningDate 
    ,SigningNumber
    ,BrokerSigningDate
    ,BrokerSigningNumber
    ,ProcessingDate
    ,ProcessingPeriodDate
    ,SettlementDate
    ,ActualPaymentDate
    ,CategoryCode 
    ,Category
    ,BusinessCategoryCode
    ,BusinessCategory
    ,RiskClassCode
    ,RiskClass
    ,FilCode
    ,Fil
    ,DTICode
    ,QualCatCode
    ,QualCat
    ,OriginalCCYToSettlementCCYRate
    ,PositiveAmountInOriginalCCY
    ,PositiveVATAmountInOriginalCCY
    ,PositiveDelinkedAmountInOriginalCCY
    ,NegativeAmountInOriginalCCY
    ,NegativeVATAmountInOriginalCCY
    ,NegativeDelinkedAmountInOriginalCCY
    ,GQDDate
    ,ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier
    ,FK_ReinsuranceContract
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_YOA
    ,FK_GQDTransactionType
    ,SpecialPurposeSyndicateApplies
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
)
SELECT 
    PK_LPSOTransaction                      = x.PK_LPSOTransaction
    ,SigningDate                            = MAX(x.SigningDate)
    ,SigningNumber                          = MAX(x.SigningNumber)
    ,BrokerSigningDate                      = MAX(x.BrokerSigningDate)
    ,BrokerSigningNumber                    = MAX(x.BrokerSigningNumber)
    ,ProcessingDate                         = MAX(x.ProcessingDate)
    ,ProcessingPeriodDate                   = MAX(x.ProcessingPeriodDate)
    ,SettlementDate                         = MAX(x.SettlementDate)
    ,ActualPaymentDate                      = MAX(x.ActualPaymentDate)
    ,CategoryCode                           = MAX(x.CategoryCode)
    ,Category                               = MAX(x.Category)
    ,BusinessCategoryCode                   = MAX(x.BusinessCategoryCode)
    ,BusinessCategory                       = MAX(x.BusinessCategory)
    ,RiskClassCode                          = MAX(x.RiskClassCode)
    ,RiskClass                              = MAX(x.RiskClass)
    ,FilCode                                = MAX(x.FilCode)
    ,Fil                                    = MAX(x.Fil)
    ,DTICode                                = MAX(x.DTICode)
    ,QualCatCode                            = MAX(x.QualCatCode)
    ,QualCat                                = MAX(x.QualCat)
    ,OriginalCCYToSettlementCCYRate         = MAX(x.OriginalCCYToSettlementCCYRate)
    ,PositiveAmountInOriginalCCY            = SUM(x.PositiveAmountInOriginalCCY)
    ,PositiveVATAmountInOriginalCCY         = SUM(x.PositiveVATAmountInOriginalCCY)
    ,PositiveDelinkedAmountInOriginalCCY    = SUM(x.PositiveDelinkedAmountInOriginalCCY) 
    ,NegativeAmountInOriginalCCY            = SUM(x.NegativeAmountInOriginalCCY) 
    ,NegativeVATAmountInOriginalCCY         = SUM(x.NegativeVATAmountInOriginalCCY) 
    ,NegativeDelinkedAmountInOriginalCCY    = SUM(x.NegativeDelinkedAmountInOriginalCCY)
    --,PositiveAmountInOriginalCCY            = SUM(x.PositiveAmountInOriginalCCY)            / MAX(s.TotalWrittenIfNotSignedMultiplier)
    --,PositiveVATAmountInOriginalCCY         = SUM(x.PositiveVATAmountInOriginalCCY)         / MAX(s.TotalWrittenIfNotSignedMultiplier)
    --,PositiveDelinkedAmountInOriginalCCY    = SUM(x.PositiveDelinkedAmountInOriginalCCY)    / MAX(s.TotalWrittenIfNotSignedMultiplier)
    --,NegativeAmountInOriginalCCY            = SUM(x.NegativeAmountInOriginalCCY)            / MAX(s.TotalWrittenIfNotSignedMultiplier)
    --,NegativeVATAmountInOriginalCCY         = SUM(x.NegativeVATAmountInOriginalCCY)         / MAX(s.TotalWrittenIfNotSignedMultiplier)
    --,NegativeDelinkedAmountInOriginalCCY    = SUM(x.NegativeDelinkedAmountInOriginalCCY)    / MAX(s.TotalWrittenIfNotSignedMultiplier)
    ,GQDDate                                = MAX(x.GQDDate)
    ,ExternalAcquisitionCostMultiplier      = MAX(x.ExternalAcquisitionCostMultiplier)
    ,InternalAcquisitionCostMultiplier      = MAX(x.InternalAcquisitionCostMultiplier)
    ,FK_ReinsuranceContract                 = MAX(x.FK_ReinsuranceContract)
    ,FK_SettlementCurrency                  = MAX(x.FK_SettlementCurrency)
    ,FK_OriginalCurrency                    = MAX(x.FK_OriginalCurrency)
    ,FK_YOA                                 = MAX(x.FK_YOA)
    ,FK_GQDTransactionType                  = MAX(x.FK_GQDTransactionType)
    --,SpecialPurposeSyndicateApplies         = CAST(MAX(CAST(s.SpecialPurposeSyndicateApplies AS int)) AS bit)
    ,SpecialPurposeSyndicateApplies         = 0
    ,FK_DevelopmentPeriod                   = MAX(x.FK_DevelopmentPeriod)
    ,FK_ClaimExposure                       = MAX(x.FK_ClaimExposure)
FROM
(
    SELECT
    /*Utility functions inlined in the interests of performance*/
    PK_LPSOTransaction                          = lw.GroupKey
    ,SigningDate                                = lw.SigningDate
    ,SigningNumber                              = lw.SigningNumber
    ,BrokerSigningDate                          = lw.BrokerSigningDate
    ,BrokerSigningNumber                        = lw.BrokerSigningNumber
    ,ProcessingDate                             = lw.ProcessingDate
    ,ProcessingPeriodDate                       = lw.ProcessingPeriodDate
    ,SettlementDate                             = lw.SettlementDate
    ,ActualPaymentDate                          = lw.ActualPaymentDate
    ,CategoryCode                               = lw.CategoryCode
    ,Category                                   = lw.Category
    ,BusinessCategoryCode                       = lw.BusinessCategoryCode
    ,BusinessCategory                           = lw.BusinessCategory
    ,RiskClassCode                              = lw.RiskClassCode
    ,RiskClass                                  = lw.RiskClass
    ,FilCode                                    = lw.FilCode
    ,Fil                                        = lw.Fil
    ,DTICode                                    = lw.DTICode
    ,QualCatCode                                = lw.QualCatCode
    ,QualCat                                    = lw.QualCat
    ,OriginalCCYToSettlementCCYRate             = lw.OriginalCCYToSettlementCCYRate
    ,PositiveAmountInOriginalCCY                = lw.PositiveAmountInOriginalCCY
    ,PositiveVATAmountInOriginalCCY             = lw.PositiveVATAmountInOriginalCCY
    ,PositiveDelinkedAmountInOriginalCCY        = lw.PositiveDelinkedAmountInOriginalCCY 
    ,NegativeAmountInOriginalCCY                = lw.NegativeAmountInOriginalCCY
    ,NegativeVATAmountInOriginalCCY             = lw.NegativeVATAmountInOriginalCCY
    ,NegativeDelinkedAmountInOriginalCCY        = lw.NegativeDelinkedAmountInOriginalCCY
    ,GQDDate                                    = COALESCE(lw.ActualPaymentDate, lw.ProcessingPeriodDate)
    --,GQDDate                                    = CASE  
    --                                                WHEN s.IsFacility = 0 THEN COALESCE(s.TermsOfTradeDate, lw.ActualPaymentDate, lw.ProcessingPeriodDate)
    --                                                ELSE COALESCE(lw.ActualPaymentDate, lw.ProcessingPeriodDate)
    --                                               END
    ,ExternalAcquisitionCostMultiplier          = lw.ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier          = lw.InternalAcquisitionCostMultiplier
    ,FK_ReinsuranceContract	                    = ri.PK_ReinsuranceContract
    ,FK_SettlementCurrency                      = sc.PK_SettlementCurrency
    ,FK_OriginalCurrency                        = oc.PK_OriginalCurrency
    ,FK_YOA                                     = lw.FK_YOA
    ,FK_GQDTransactionType                      = ISNULL(gqd.PK_GQDTransactionType, 0)
    ,FK_DevelopmentPeriod                       = ISNULL(dp.PK_DevelopmentPeriod, 0)
    ,FK_ClaimExposure                           = lw.FK_ClaimExposure
    FROM
    #ReinsuranceLPSOTransactionWorking lw
    INNER JOIN
    ODS.ReinsuranceContractNonFac ri with (nolock) ON
    lw.SectionReference = ri.ContractReference
    INNER JOIN
    ODS.SettlementCurrency sc with (nolock) ON
    lw.SettlementCCY = sc.CurrencyCode
    INNER JOIN
    ODS.OriginalCurrency oc with (nolock) ON
    lw.OriginalCCY = oc.CurrencyCode
    INNER JOIN
    ODS.YOA yoa with (nolock) ON
    lw.FK_YOA = yoa.PK_YOA
    LEFT OUTER JOIN
    ODS.GQDTransactionType gqd with (nolock) ON
    lw.GQDTransactionTypeCode = gqd.GQDTransactionTypeCode   
    LEFT OUTER JOIN
    ODS.DevelopmentPeriod dp with (nolock) ON
    DATEDIFF(MM, yoa.FirstDate, lw.ProcessingPeriodDate) + 1 = dp.DevelopmentMonth
	
) x
INNER JOIN
    ODS.ReinsuranceContractNonFac ri ON
    x.FK_ReinsuranceContract = ri.PK_ReinsuranceContract
GROUP BY
    x.PK_LPSOTransaction


ALTER TABLE ODS.ReinsuranceLPSOTransaction CHECK CONSTRAINT ALL

/* Transaction Line ******************************************************************************/
ALTER TABLE ODS.ReinsuranceLPSOTransactionLine NOCHECK CONSTRAINT ALL

--Work out each syndicate's contribution to the total - this becomes the line
INSERT INTO ODS.ReinsuranceLPSOTransactionLine WITH (TABLOCK)
(
    FK_LPSOTransaction
    ,FK_Syndicate
    ,PositiveLineMultiplier
    ,NegativeLineMultiplier
    ,PositiveVATLineMultiplier
    ,NegativeVATLineMultiplier
    ,PositiveDelinkedLineMultiplier
    ,NegativeDelinkedLineMultiplier
)
SELECT
FK_LPSOTransaction                      = l.PK_LPSOTransaction
,FK_Syndicate                           = syn.PK_Syndicate 
--Need to cast to floats here otherwise we lose accuracy after the 6th decimal place
,PositiveLineMultiplier                 = CASE
                                            WHEN MAX(l.PositiveAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveAmountInOriginalCCY) as float) 
--                                                 / CAST(MAX(l.PositiveAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                                 / CAST(MAX(l.PositiveAmountInOriginalCCY) as float)
                                          END
,NegativeLineMultiplier                 = CASE
                                            WHEN MAX(l.NegativeAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeAmountInOriginalCCY) AS float)
--                                                 / CAST(MAX(l.NegativeAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) AS float)
                                                 / CAST(MAX(l.NegativeAmountInOriginalCCY) AS float)
                                          END
,PositiveVATLineMultiplier              = CASE
                                            WHEN MAX(l.PositiveVATAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveVATAmountInOriginalCCY) as float) 
--                                                / CAST(MAX(l.PositiveVATAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                                / CAST(MAX(l.PositiveVATAmountInOriginalCCY) as float)
                                          END
,NegativeVATLineMultiplier              = CASE
                                            WHEN MAX(l.NegativeVATAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeVATAmountInOriginalCCY) as float) 
--                                                / CAST(MAX(l.PositiveVATAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                                / CAST(MAX(l.PositiveVATAmountInOriginalCCY) as float)
                                          END
,PositiveDelinkedLineMultiplier         = CASE
                                            WHEN MAX(l.PositiveDelinkedAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveDelinkedAmountInOriginalCCY) as float) 
--                                                / CAST(MAX(l.PositiveDelinkedAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                                / CAST(MAX(l.PositiveDelinkedAmountInOriginalCCY) as float)
                                          END
,NegativeDelinkedLineMultiplier         = CASE
                                            WHEN MAX(l.NegativeDelinkedAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeDelinkedAmountInOriginalCCY) as float) 
--                                                / CAST(MAX(l.NegativeDelinkedAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                                / CAST(MAX(l.NegativeDelinkedAmountInOriginalCCY) as float)
                                          END
FROM
#ReinsuranceLPSOTransactionWorking lw
INNER JOIN
ODS.ReinsuranceLPSOTransaction l with (nolock) ON
lw.GroupKey = l.PK_LPSOTransaction
INNER JOIN
ODS.ReinsuranceContractNonFac s with (nolock) ON
l.FK_ReinsuranceContract = s.PK_ReinsuranceContract
INNER JOIN
ODS.Syndicate syn with (nolock) ON
lw.SyndicateNumber = syn.SyndicateNumber
--INNER JOIN
--/*Only interested in creating lines where "real" lines exist for the section*/
--ODS.SectionLine sl ON
--s.PK_ReinsuranceContract = sl.FK_Section
--AND syn.PK_Syndicate = sl.FK_Syndicate
GROUP BY
l.PK_LPSOTransaction
,syn.PK_Syndicate

ALTER TABLE ODS.ReinsuranceLPSOTransactionLine CHECK CONSTRAINT ALL

/*Update earliest and latest LPSO signing date and number on section*/
;WITH CTELPSO 
AS
(
    SELECT
     FK_ReinsuranceContract         = l.FK_ReinsuranceContract
    ,SigningDate                    = l.SigningDate
    ,SigningNumber                  = l.SigningNumber
    ,SequenceId                     = ROW_NUMBER() OVER(
                                        PARTITION BY l.FK_ReinsuranceContract
                                        ORDER BY SigningDate ASC, SigningNumber ASC)
    ,ReverseSequenceId              = ROW_NUMBER() OVER(
                                        PARTITION BY l.FK_ReinsuranceContract
                                        ORDER BY SigningDate DESC, SigningNumber DESC)
    FROM
    ODS.ReinsuranceLPSOTransaction l with (nolock) 
    WHERE
    l.CategoryCode IN (1,2,3)
)
UPDATE s SET
EarliestLPSOPremiumSigningDate      = lpso_earliest.SigningDate
,EarliestLPSOPremiumSigningNumber   = lpso_earliest.SigningNumber
,LatestLPSOPremiumSigningDate       = lpso_latest.SigningDate
,LatestLPSOPremiumSigningNumber     = lpso_latest.SigningNumber
,EarliestLPSOPremiumSigningDateName = IIF(YEAR(lpso_earliest.SigningDate)< 1990 OR YEAR(lpso_earliest.SigningDate)>2050,NULL,FORMAT(lpso_earliest.SigningDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](lpso_earliest.SigningDate)
,EarliestLPSOPremiumSigningNumberName = isnull(CONVERT([varchar](255),lpso_earliest.SigningNumber),'')
,LatestLPSOPremiumSigningDateName	 =IIF(YEAR(lpso_latest.SigningDate )< 1990 OR YEAR(lpso_latest.SigningDate)>2050,NULL,FORMAT(lpso_latest.SigningDate, 'dd-MMM-yyyy'))-- [ODS].[udf_FormatDateTime](lpso_latest.SigningDate)
,LatestLPSOPremiumSigningNumberName		= isnull(CONVERT([varchar](255),lpso_latest.SigningNumber),'')
FROM
ODS.Section s
INNER JOIN
CTELPSO lpso_earliest ON
s.PK_Section = lpso_earliest.FK_ReinsuranceContract
AND lpso_earliest.SequenceId = 1
INNER JOIN
CTELPSO lpso_latest ON
s.PK_Section = lpso_latest.FK_ReinsuranceContract
AND lpso_latest.ReverseSequenceId = 1

IF (OBJECT_ID('tempdb..#ReinsuranceLPSOTransactionWorking') IS NOT NULL)
DROP TABLE #ReinsuranceLPSOTransactionWorking;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceLPSOTransaction';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceLPSOTransactionLine';