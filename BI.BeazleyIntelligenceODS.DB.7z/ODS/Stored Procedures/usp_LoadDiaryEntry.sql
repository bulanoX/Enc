﻿CREATE PROCEDURE [ODS].[usp_LoadDiaryEntry]
AS

SET NOCOUNT ON
DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.DiaryEntry

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


DELETE de 
FROM ODS.DiaryEntry de 
LEFT JOIN ODS.Section s 
ON	de.FK_Section = s.PK_Section
WHERE s.PK_Section IS NULL

DELETE FROM ODS.DiaryEntry WHERE FK_Policy NOt IN (SELECT PK_Policy FROM BeazleyIntelligenceODS.ODS.Policy)
DELETE FROM ODS.DiaryEntry WHERE FK_CRMBroker NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker)
DELETE FROM ODS.DiaryEntry WHERE FK_UnderwritingPlatform NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform)


MERGE ODS.DiaryEntry target
USING (
SELECT 
FK_Section                      = s.PK_Section
,EntryDate                      = de.DiaryEntryDate
,EntryValue                     = de.DiaryEntryValue
,EntryReference                 = de.DiaryEntryReference
,EntryTypeCode                  = de.DiaryEntryTypeCode
,EntryType                      = de.DiaryEntryType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Policy                      = s.FK_Policy
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
FROM
BeazleyIntelligenceDataContract.Outbound.vw_DiaryEntry de
INNER JOIN
ODS.Section s ON
de.SectionSourceId = s.SectionReference
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE de.SourceSystem = 'Eurobase'
AND  (de.AuditCreateDatetime > @LastAuditDate OR de.AuditModifyDatetime > @LastAuditDate)

UNION ALL

SELECT 
FK_Section                      = s.PK_Section
,EntryDate                      = de.DiaryEntryDate
,EntryValue                     = de.DiaryEntryValue
,EntryReference                 = de.DiaryEntryReference
,EntryTypeCode                  = de.DiaryEntryTypeCode
,EntryType                      = de.DiaryEntryType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Policy                      = s.FK_Policy
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
FROM
BeazleyIntelligenceDataContract.Outbound.vw_DiaryEntry de
JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section ds
	ON de.SourceSystem = ds.SourceSystem and de.SectionSourceId = ds.SectionSourceId
INNER JOIN ODS.Section s 
	ON ds.SectionReference = s.SectionReference
INNER JOIN ODS.Policy p 
	ON s.FK_Policy = p.PK_Policy
WHERE
de.SourceSystem = 'CIPS'
AND  ((de.AuditCreateDatetime > @LastAuditDate OR de.AuditModifyDatetime > @LastAuditDate)
	  OR  (ds.AuditCreateDatetime > @LastAuditDate OR ds.AuditModifyDatetime > @LastAuditDate))
UNION 

SELECT 
FK_Section                      = s.PK_Section
,EntryDate                      = de.DiaryEntryDate
,EntryValue                     = de.DiaryEntryValue
,EntryReference                 = de.DiaryEntryReference
,EntryTypeCode                  = de.DiaryEntryTypeCode
,EntryType                      = de.DiaryEntryType
,FK_Date                        = s.FK_InceptionDate
,FK_YOA                         = p.FK_YOA
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,FK_Policy                      = s.FK_Policy
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
FROM
BeazleyIntelligenceDataContract.Outbound.vw_DiaryEntry de
INNER JOIN
ODS.Section s ON
de.SectionSourceId = s.SectionReference
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE de.SourceSystem = 'Unirisx'
AND  (de.AuditCreateDatetime > @LastAuditDate OR de.AuditModifyDatetime > @LastAuditDate)
) source
ON target.FK_Section = source.FK_Section
AND target.EntryTypeCode = source.EntryTypeCode


WHEN MATCHED THEN
UPDATE SET

 target.EntryDate						= source.EntryDate
,target.EntryValue						= source.EntryValue
,target.EntryReference					= source.EntryReference
,target.EntryType						= source.EntryType
,target.FK_Date							= source.FK_Date
,target.FK_YOA							= source.FK_YOA
,target.FK_SettlementCurrency			= source.FK_SettlementCurrency
,target.FK_OriginalCurrency				= source.FK_OriginalCurrency
,target.FK_TriFocus						= source.FK_TriFocus
,target.FK_CRMBroker					= source.FK_CRMBroker
,target.FK_QuoteFilter					= source.FK_QuoteFilter
,target.FK_HiddenStatusFilter			= source.FK_HiddenStatusFilter
,target.FK_Policy						= source.FK_Policy
,target.SpecialPurposeSyndicateApplies 	= source.SpecialPurposeSyndicateApplies 
,target.FK_UnderwritingPlatform			= source.FK_UnderwritingPlatform
,target.FK_InternalWrittenBinderStatus  = source.FK_InternalWrittenBinderStatus   
,target.FK_ServiceCompany				= source.FK_ServiceCompany
,target.AuditModifyDateTime				= GETDATE()						
,target.AuditModifyDetails				= 'Merge in ODS.usp_LoadDiaryEntry proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
FK_Section
,EntryDate
,EntryValue
,EntryReference
,EntryTypeCode
,EntryType
,FK_Date
,FK_YOA
,FK_SettlementCurrency
,FK_OriginalCurrency
,FK_TriFocus
,FK_CRMBroker
,FK_QuoteFilter
,FK_HiddenStatusFilter
,FK_Policy
,SpecialPurposeSyndicateApplies 
,FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus
,FK_ServiceCompany
,AuditCreateDateTime
,AuditModifyDetails
)
VALUES
(
  source.FK_Section
 ,source.EntryDate
 ,source.EntryValue
 ,source.EntryReference
 ,source.EntryTypeCode
 ,source.EntryType
 ,source.FK_Date
 ,source.FK_YOA
 ,source.FK_SettlementCurrency
 ,source.FK_OriginalCurrency
 ,source.FK_TriFocus
 ,source.FK_CRMBroker
 ,source.FK_QuoteFilter
 ,source.FK_HiddenStatusFilter
 ,source.FK_Policy
 ,source.SpecialPurposeSyndicateApplies
 ,source.FK_UnderwritingPlatform
 ,source.FK_InternalWrittenBinderStatus
 ,source.FK_ServiceCompany
 ,GETDATE()
,'New add in ODS.usp_LoadDiaryEntry proc'	
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'DiaryEntry';
