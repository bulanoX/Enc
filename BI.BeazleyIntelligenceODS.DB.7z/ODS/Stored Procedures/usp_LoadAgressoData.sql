﻿CREATE PROCEDURE   [ODS].[usp_LoadAgressoData]
AS

SET NOCOUNT ON



IF (OBJECT_ID('tempdb..#SectionsInAgresso') IS NOT NULL) DROP TABLE #SectionsInAgresso


SELECT DISTINCT
		a.FK_Policy 
       ,a.PolicyReference
	   ,a.FK_Section
	   ,a.SectionReference
	   ,s.SourceSystem
	   ,SettlementCurrency = se.CurrencyCode
	   ,TotalToPayInSettlementCurrency 
	   ,OutstandingAmountInSettlementCurrency 	    
	   ,PayedInSettlementCurrency 
	   ,PayedRate = (TotalToPayInSettlementCurrency - OutstandingAmountInSettlementCurrency) /NULLIF(TotalToPayInSettlementCurrency,0)
	   ,Last_Paid_Date
	   ,UnderwritingPlatformName
			
INTO #SectionsInAgresso
FROM (
-- INSERT all SectionRefs received from Agresso
SELECT  s.FK_Policy 
       ,PolicyReference
	   ,FK_Section = s.PK_Section
	   ,SectionReference
	   ,TotalToPayInSettlementCurrency					= SUM(Cur_amount/s.OriginalCCYToSettlementCCYRate)
	   ,OutstandingAmountInSettlementCurrency			= SUM(Rest_Curr/s.OriginalCCYToSettlementCCYRate)
	   ,PayedInSettlementCurrency				        = SUM((Cur_amount - Rest_Curr)/s.OriginalCCYToSettlementCCYRate)
	   ,Last_Paid_Date								= MAX(Last_Paid_Date)   
FROM [Staging_MDS].[dbo].[uviarpolstatus] a
    INNER JOIN ODS.Section s on a.dim_5 = s.SectionReference
	INNER JOIN ODS.Policy p on s.FK_Policy = p.PK_Policy	  
GROUP BY   s.FK_Policy
		  ,p.PolicyReference
		  ,s.PK_Section
		  ,s.SectionReference
		  
UNION ALL
-- INSERT all PolicyRefs and their Sections from Agresso (on dim_5 we receive Policies and Sections as well)
SELECT
		FK_Policy = p.PK_Policy
	   ,PolicyReference
	   ,FK_Section = s.PK_Section
	   ,SectionReference
	   ,TotalToPayInSettlementCurrency					= SUM(Cur_amount/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,OutstandingAmountInSettlementCurrency			= SUM(Rest_Curr/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,PayedInSettlementCurrency				        = SUM((Cur_amount - Rest_Curr)/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,Last_Paid_Date  								= MAX(Last_Paid_Date)
FROM [Staging_MDS].[dbo].[uviarpolstatus] a
	 INNER JOIN ODS.Policy p ON a.dim_5 = p.PolicyReference
	 INNER JOIN ODS.Section s ON s.FK_Policy = p.PK_Policy
GROUP BY   p.PK_Policy
		  ,p.PolicyReference
		  ,s.PK_Section
		  ,s.SectionReference
		  )a
INNER JOIN ODS.Section s ON s.PK_Section = a.FK_Section
INNER JOIN ODS.SettlementCurrency se on s.FK_SettlementCurrency = se.PK_SettlementCurrency
INNER JOIN ODS.UnderwritingPlatform uw ON s.FK_UnderwritingPlatform = uw.PK_UnderwritingPlatform


INSERT  INTO #SectionsInAgresso
SELECT DISTINCT
		a.FK_Policy 
       ,a.PolicyReference
	   ,a.FK_Section
	   ,a.SectionReference
	   ,s.SourceSystem
	   ,SettlementCurrency = se.CurrencyCode
	   ,TotalToPayInSettlementCurrency 
	   ,OutstandingAmountInSettlementCurrency 	    
	   ,PayedInSettlementCurrency 
	   ,PayedRate = (TotalToPayInSettlementCurrency - OutstandingAmountInSettlementCurrency) /NULLIF(TotalToPayInSettlementCurrency,0)
	   ,Last_Paid_Date
	   ,UnderwritingPlatformName
			
FROM(
-- INSERT all SectionRefs received from Agresso for client PB - ZREFNO match
SELECT  s.FK_Policy 
       ,PolicyReference
	   ,FK_Section = s.PK_Section
	   ,SectionReference
	   ,TotalToPayInSettlementCurrency					= SUM(Cur_amount/s.OriginalCCYToSettlementCCYRate)
	   ,OutstandingAmountInSettlementCurrency			= SUM(Rest_Curr/s.OriginalCCYToSettlementCCYRate)
	   ,PayedInSettlementCurrency				        = SUM((Cur_amount - Rest_Curr)/s.OriginalCCYToSettlementCCYRate)
	   ,Last_Paid_Date									= MAX(Last_Paid_Date)   
FROM [Staging_MDS].[dbo].[uviarpolstatus] a
    INNER JOIN ODS.Section s on a.ZREFNO = s.SectionReference
	INNER JOIN ODS.Policy p on s.FK_Policy = p.PK_Policy	 
WHERE a.client = 'PB'	
	AND ISNULL(a.ZREFNO , '')<>''
	AND SectionReference NOT IN (SELECT SectionReference FROM #SectionsInAgresso)
GROUP BY   s.FK_Policy
		  ,p.PolicyReference
		  ,s.PK_Section
		  ,s.SectionReference

UNION ALL
-- INSERT all PolicyRefs and their Sections from Agresso for client PB - ZREFNO match
SELECT
		FK_Policy = p.PK_Policy
	   ,PolicyReference
	   ,FK_Section = s.PK_Section
	   ,SectionReference
	   ,TotalToPayInSettlementCurrency					= SUM(Cur_amount/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,OutstandingAmountInSettlementCurrency			= SUM(Rest_Curr/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,PayedInSettlementCurrency				        = SUM((Cur_amount - Rest_Curr)/s.OriginalCCYToSettlementCCYRate)/SUM(1) OVER(PARTITION BY p.PolicyReference)
	   ,Last_Paid_Date  								= MAX(Last_Paid_Date)
FROM [Staging_MDS].[dbo].[uviarpolstatus] a
	 INNER JOIN ODS.Policy p ON a.ZREFNO = p.PolicyReference
	 INNER JOIN ODS.Section s ON s.FK_Policy = p.PK_Policy
WHERE a.client = 'PB'	
	  AND ISNULL(a.ZREFNO , '')<>''
	  AND SectionReference NOT IN (SELECT SectionReference FROM #SectionsInAgresso)
GROUP BY   p.PK_Policy
		  ,p.PolicyReference
		  ,s.PK_Section
		  ,s.SectionReference
				 
	)a
INNER JOIN ODS.Section s ON s.PK_Section = a.FK_Section
INNER JOIN ODS.SettlementCurrency se on s.FK_SettlementCurrency = se.PK_SettlementCurrency
INNER JOIN ODS.UnderwritingPlatform uw ON s.FK_UnderwritingPlatform = uw.PK_UnderwritingPlatform


UPDATE #SectionsInAgresso
SET PayedRate = 0
WHERE PayedRate < 0

UPDATE #SectionsInAgresso
SET PayedRate = 1
WHERE PayedRate > 1


UPDATE s
SET   CashLastReceived     	= CASE WHEN s.SourceSystem <> 'Eurobase' OR ct.UnderwritingPlatformName = 'Beazley Insurance dac' THEN ISNULL(ct.Last_Paid_Date,lpso.SettlementDate)
								   ELSE lpso.SettlementDate 
							  END, 
       FK_CashLastReceived  = ([Utility].[udf_GenerateDateKey](
																 CASE WHEN s.SourceSystem <> 'Eurobase' OR ct.UnderwritingPlatformName = 'Beazley Insurance dac' THEN ISNULL(ct.Last_Paid_Date,lpso.SettlementDate)
																	   ELSE lpso.SettlementDate 
																  END
																 )
											  ),
	   CashLastReceivedName = ([ODS].[udf_FormatDateTime](
															CASE WHEN s.SourceSystem <> 'Eurobase' OR ct.UnderwritingPlatformName = 'Beazley Insurance dac' THEN ISNULL(ct.Last_Paid_Date,lpso.SettlementDate)
																ELSE lpso.SettlementDate 
															END
															)
											) ,
       AgressoPayedRate     	= ISNULL(ct.PayedRate,0)
FROM ODS.Section s
INNER JOIN (
		   SELECT FK_Section 
				 ,SettlementDate = MAX(SettlementDate)
		   FROM
				(	
					SELECT    FK_Section
							 ,SettlementDate = MAX(FK_SettlementDate)				
					FROM ODS.LPSOTransaction
					WHERE FK_SettlementDate <= GETDATE()
					GROUP BY FK_Section 

					UNION ALL

					SELECT    FK_Section
							 ,SettlementDate		= MAX(FK_SettlementDate)				
					FROM ODS.NonLloydsPremiumTransaction 
					WHERE FK_SettlementDate <= GETDATE()
					GROUP BY FK_Section 
					)t
		  GROUP BY FK_Section
		  )lpso on s.PK_Section = lpso.FK_Section	

LEFT JOIN #SectionsInAgresso ct on ct.FK_Section = s.PK_Section

IF (OBJECT_ID('tempdb..#SectionsInAgresso') IS NOT NULL) DROP TABLE #SectionsInAgresso
