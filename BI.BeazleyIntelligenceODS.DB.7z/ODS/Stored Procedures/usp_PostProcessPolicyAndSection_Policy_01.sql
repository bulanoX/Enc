﻿
CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_Policy_01]
AS

SET NOCOUNT ON


UPDATE p SET
FACEvidenced       = 1
FROM
ODS.Policy p
INNER JOIN
(
    SELECT
    FK_Policy                   = s.FK_Policy
    ,CountFACCoverNote          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Cover Note' THEN 1 ELSE 0 END)
    ,CountFACOrderForm          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Order Form' THEN 1 ELSE 0 END)
    ,CountFACRationale          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Rationale' THEN 1 ELSE 0 END)
    ,CountFACSecurity           = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Security Approval (Pre Bind)' THEN 1 ELSE 0 END)
    FROM
    ODS.Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
    GROUP BY
    s.FK_Policy
) x ON
p.PK_Policy = x.FK_Policy
WHERE
x.CountFACCoverNote > 0
AND x.CountFACOrderForm > 0
AND x.CountFACRationale > 0
AND x.CountFACSecurity > 0


-- Update BrokerContactName and SubmittingBrokerContactName in Policy table -- BI 121
UPDATE p SET
p.BrokerContactName				    = se.BrokerContactName  
,p.SubmittingBrokerContactName      = se.SubmittingBrokerContactName	 
FROM
ODS.Policy p
LEFT OUTER JOIN ODS.SubmissionExtension se
ON p.FK_Submission = se.FK_Submission  

/*Update SourceSystem = USHVH to US High Value Homeowners*/

UPDATE p SET
p.SourceSystem = 'US High Value Homeowners'
from ODS.Policy p
where p.SourceSystem = 'USHVH'

/* Update "NotifiedIndividualsMaxim" in Policy */
UPDATE p SET
NotifiedIndividualsMaximum = s.NotifiedIndividualsMaximum
						 
FROM
ODS.Policy p
INNER JOIN
(SELECT  FK_Policy , MAX(NotifiedIndividuals) as NotifiedIndividualsMaximum  FROM ODS.Section
GROUP BY FK_Policy ) s 
ON s.FK_Policy=p.PK_policy