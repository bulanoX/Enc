﻿CREATE PROCEDURE [ODS].[usp_LoadSectionReinstatements]
AS
SET NOCOUNT ON

BEGIN
	
--	TRUNCATE TABLE [ODS].[SectionReinstatements]

DECLARE @LastAuditDate DATETIME2(7)

SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.SectionReinstatements with (nolock)

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')
	

;MERGE ODS.SectionReinstatements
AS TARGET
USING  (	SELECT
					[PK_SectionReinstatements]	 = ISNULL(CONVERT(BIGINT,HASHBYTES('SHA2_256',(UPPER(s.SectionReference)+CAST(sr.ReinstatementsNo AS VARCHAR(5))+UPPER(sr.PolicySourceId)))),0)
					,FK_Section					 = s.PK_Section 
					,SectionReference            = s.SectionReference
					,ReinstatementNo			 = sr.ReinstatementsNo
					,ReinstatementPercentage	 = CAST(sr.ReinstatementPercentage AS NUMERIC(19,12))/CAST(100 AS NUMERIC(19,12))
					,ReinstatementPercentageName = CAST(ROUND(CAST(CAST(sr.ReinstatementPercentage AS NUMERIC(19,12))/CAST(100 AS NUMERIC(19,12)) AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--[ODS].[udf_FormatMultiplierAsPercentage](CAST(sr.ReinstatementPercentage AS NUMERIC(19,12))/CAST(100 AS NUMERIC(19,12)),(2))
					,PolicySourceId				 = sr.PolicySourceId
				FROM 

					BeazleyIntelligenceDataContract.Outbound.vw_SectionReinstatements sr with (nolock)

					INNER JOIN ODS.Section s with (nolock) ON sr.SectionSourceId = s.SectionReference
) AS SOURCE
ON  SOURCE.FK_Section      = TARGET.FK_SECTION
AND SOURCE.ReinstatementNo = TARGET.ReinstatementNo
AND SOURCE.PolicySourceId  = TARGET.PolicySourceId
 
WHEN MATCHED THEN
UPDATE SET
 target.[ReinstatementPercentage] = source.[ReinstatementPercentage]
,target.[ReinstatementPercentageName] = source.[ReinstatementPercentageName]
,target.AuditModifyDateTime	    = GETDATE()						
,target.AuditModifyDetails	    = 'Merge in ODS.usp_LoadSectionReinstatements'


WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT

(  PK_SectionReinstatements
  ,FK_Section 
  ,[ReinstatementNo]     
  ,[ReinstatementPercentage]
  ,[ReinstatementPercentageName]
  ,PolicySourceId
  ,AuditCreateDateTime
  ,AuditModifyDetails
)
VALUES
( 
   source.PK_SectionReinstatements 
  ,source.FK_Section 
  ,source.[ReinstatementNo]       
  ,source.[ReinstatementPercentage]     
  ,source.[ReinstatementPercentageName]
  ,source.PolicySourceId 
  ,GETDATE()
  ,'New add in ODS.usp_LoadSectionReinstatements'	
);


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'SectionReinstatements';


END