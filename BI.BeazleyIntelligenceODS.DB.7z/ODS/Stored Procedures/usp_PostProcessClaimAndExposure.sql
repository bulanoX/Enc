﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_PostProcessClaimAndExposure]
AS
BEGIN
	
	-- Update InitiativeUS column based on InitiativeUS from ODS.Policy
	UPDATE c
	SET c.InitiativeUS = p.InitiativeUS
	FROM [ODS].[Claim] c
	
	INNER JOIN [ODS].[ClaimExposure] ce 
	ON ce.FK_Claim = c.PK_Claim
	
	INNER JOIN [ODS].[ClaimExposureSection] sce 
	ON ce.PK_ClaimExposure = sce.FK_ClaimExposure
	
	INNER JOIN [ODS].[Policy] p 
	ON sce.FK_Policy = p.PK_Policy
	
	WHERE p.InitiativeUS IS NOT NULL

	--Update CargoOrFreight column
									-- CP 05/07/2017 - Ticket 386
	UPDATE ce
	SET ce.CargoOrFreight = s.CargoOrFreight 
	FROM [ODS].[ClaimExposure] ce 
	
	INNER JOIN [ODS].[ClaimExposureSection] sce 
	ON ce.PK_ClaimExposure = sce.FK_ClaimExposure
	
	INNER JOIN [ODS].[Section] s 
	ON sce.FK_Section = s.PK_Section
	
	WHERE s.CargoOrFreight IS NOT NULL
END