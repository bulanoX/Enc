﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_PostProcessDeleteClaimsAndExposures]
AS
BEGIN
	
	------/*delete dummy movements fro exposures created in the migration process*/

	------DELETE FROM ODS.ClaimMovement
	------WHERE FK_ClaimExposure IN
	------(
	------	SELECT 
	------		cm.FK_ClaimExposure 
	------	FROM ODS.ClaimMovement cm
	------	INNER JOIN 
	------		(
	------			SELECT FK_ClaimExposure
	------			FROM ods.ClaimMovement
	------			WHERE MovementType <> 'SCM'
	------			GROUP BY FK_ClaimExposure
	------			HAVING COUNT(*) = 1

	------		) ce
	------		ON ce.FK_ClaimExposure = cm.FK_ClaimExposure
	------		INNER JOIN ods.claimexposure cee ON cee.PK_ClaimExposure = ce.FK_ClaimExposure
	------		INNER JOIN ods.claim c ON c.PK_Claim = cee.FK_Claim
	------		WHERE c.claimreference NOT IN
	------		(
	------			SELECT 
	------				claimnumber 
	------			FROM Staging_ClaimCenter.ClaimCenter_Staging.cc_claim c
	------			INNER JOIN Staging_ClaimCenter.ClaimCenter_Staging.cc_exposure e 
	------			ON e.claimid = c.id

	------		)
	------		AND cee.ExposureReference NOT LIKE'BEAZL%'
	------		AND cee.ExposureReference NOT LIKE'BEAZG%'
	------		AND cee.ExposureReference NOT LIKE'W%'
	------)

	/* DELETE CLAIMS & EXPOSURES WHERE THERE ARE NO MOVEMENTS */
	DELETE ces -- select *
	FROM   ODS.ClaimExposureSection ces
	WHERE  NOT EXISTS (SELECT 1 FROM ODS.ClaimMovement cm WHERE cm.FK_ClaimExposure = ces.FK_ClaimExposure)

	DELETE ce -- select *
	FROM   ODS.ClaimExposure ce
	WHERE  NOT EXISTS (SELECT 1 FROM ODS.ClaimMovement cm WHERE cm.FK_ClaimExposure = ce.PK_ClaimExposure)

	DELETE ccas -- select *
	FROM   ODS.ClaimClaimAssociation ccas
	WHERE  NOT EXISTS (SELECT 1 FROM ODS.ClaimExposure ce WHERE ce.FK_Claim = ccas.FK_Claim)

	DELETE c -- select *
	FROM   ODS.Claim c
	WHERE  NOT EXISTS (SELECT 1 FROM ODS.ClaimExposure ce WHERE ce.FK_Claim = c.PK_Claim)

END