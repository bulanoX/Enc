﻿ CREATE PROCEDURE [ODS].[usp_LoadSublimitType]
 AS
 
 SET NOCOUNT ON
 
 DECLARE @LastAuditDate DATETIME2(7)
 
 SELECT 
 	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
 FROM ODS.SublimitType
 
 SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')
 
 
 IF OBJECT_ID('tempdb..#SublimitTypeTemp') IS NOT NULL
 DROP TABLE #SublimitTypeTemp
 
 CREATE TABLE #SublimitTypeTemp 
 (
     [IsUnknownMember]		BIT NOT NULL,
 	[LimitTypeCode]			VARCHAR(255) NULL,
 	[LimitTypeDescription]	VARCHAR(255) NULL
 )
 
 -- Insert Unknown member
 INSERT INTO #SublimitTypeTemp
 (
 	IsUnknownMember
 	,LimitTypeCode
 	,LimitTypeDescription
 ) 
 SELECT
 	IsUnknownMember       = 1
 	,LimitTypeCode		  = 'N/A'
 	,LimitTypeDescription = 'N/A'
 
 ;WITH CTE_SublimitType (LimitTypeCode, LimitTypeDescription, RowNo)
 AS
 (
 	SELECT DISTINCT
 		 LimitTypeCode			= sl.LimitTypeCode
 		,LimitTypeDescription	= sl.LimitTypeDescription
 		,RowNo					= ROW_NUMBER() OVER (PARTITION BY ISNULL(sl.LimitTypeCode,'') ORDER BY sl.LimitTypeDescription)
 	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionLimit sl
 	WHERE sl.LimitTypeCode <> '' AND sl.LimitTypeDescription <> ''
 ) 
 
 INSERT INTO #SublimitTypeTemp
 (
 	IsUnknownMember
 	,LimitTypeCode
 	,LimitTypeDescription
 )
 SELECT 
 	IsUnknownMember			= 0
 	,LimitTypeCode			= sl.LimitTypeCode
 	,LimitTypeDescription	= sl.LimitTypeDescription
 FROM CTE_SublimitType sl
 WHERE sl.RowNo = 1
 AND sl.LimitTypeCode <> '' AND sl.LimitTypeDescription <> ''
 
 
 
 MERGE ODS.SublimitType AS TARGET
 USING 
 #SublimitTypeTemp AS SOURCE
 ON (
 		ISNULL(Source.LimitTypeCode, 'Not Available') = ISNULL(Target.LimitTypeCode, 'Not Available')
 	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
 )
 WHEN MATCHED THEN
 UPDATE SET
    target.LimitTypeCode				= source.LimitTypeCode
    ,target.LimitTypeDescription     = source.LimitTypeDescription
    ,target.AuditModifyDateTime		= GETDATE()						
    ,target.AuditModifyDetails		= 'Merge in ODS.usp_LoadSublimitType proc' 
 
 WHEN NOT MATCHED BY TARGET THEN
 INSERT
 (
     IsUnknownMember
     ,LimitTypeCode
     ,LimitTypeDescription
 	,AuditCreateDateTime
 	,AuditModifyDetails
 )
 VALUES
 (
     source.IsUnknownMember
     ,source.LimitTypeCode
     ,source.LimitTypeDescription
 	,GETDATE()
 	,'New add in ODS.usp_LoadSublimitType proc'	
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE
 ;