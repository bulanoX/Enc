﻿CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_Policy_02]
AS

SET NOCOUNT ON


-- ORIGINAL POST PROCESS P&S CODE BELOW

/*Section checks for rationale completeness and earliest dates*/
UPDATE p SET
AnySectionHasExceptionDocument                  = CASE WHEN x.ExceptionDocumentCount > 0 THEN 1 ELSE 0 END
,EarliestRationaleQuestionnaireDate             = COALESCE(p.EarliestRationaleQuestionnaireDate,x.EarliestRationaleQuestionnaireDate) -- do not update it for unirisx, we update this value in the polciy proc
,EarliestRationaleDocumentDate                  = x.EarliestRationaleDocumentDate
,EarliestRationaleDate                          = COALESCE(p.EarliestRationaleDate,x.EarliestRationaleDate)
,RationaleCompletionMethod                      = CASE
                                                    WHEN x.SectionCount = x.RationaleNACount THEN 'N/A'
                                                    WHEN x.RationaleQuestionnaireCount > 0 AND x.RationaleDocumentCount > 0 THEN 'Questionnaire and Document'
                                                    WHEN x.RationaleQuestionnaireCount > 0 THEN 'Questionnaire'
                                                    WHEN x.RationaleDocumentCount > 0 THEN 'Document'
                                                    ELSE 'Incomplete'
                                                  END
,EarliestExceptionDocumentDate                  = x.EarliestExceptionDocumentDate
,EarliestFirstLiveDate                          = x.EarliestFirstLiveDate
,LatestFirstLiveDate                            = x.LatestFirstLiveDate
FROM
ODS.Policy p
INNER JOIN
(
    SELECT
    FK_Policy                           = s.FK_Policy
    ,RenewalCount                       = SUM(CAST(s.IsRenewal AS int))
    ,RationaleQuestionnaireCount        = SUM(CAST(s.RationaleQuestionnaireComplete AS int))
    ,RationaleDocumentCount             = SUM(CAST(s.HasRationaleDocument AS int))
    ,ExceptionDocumentCount             = SUM(CAST(s.HasExceptionDocument AS int))
    ,EarliestRationaleQuestionnaireDate = MIN(s.RationaleQuestionnaireDate)
    ,EarliestRationaleDocumentDate      = MIN(s.RationaleDocumentDate)
    ,EarliestRationaleDate              = MIN([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate]))
    ,EarliestExceptionDocumentDate      = MIN(s.ExceptionDocumentDate)
    ,SectionCount                       = COUNT(1)
    ,RationaleNACount                   = SUM(CASE WHEN s.RationaleCompletionMethod = 'N/A' THEN 1 ELSE 0 END)
    ,EarliestFirstLiveDate              = MIN(s.FirstLiveDate)
    ,LatestFirstLiveDate                = MAX(s.FirstLiveDate)
    FROM
    ODS.Section s 
    GROUP BY
    s.FK_Policy
) x ON
p.PK_Policy = x.FK_Policy
WHERE
p.PK_Policy <> 0


/*
Update ContractCertaintyRequired flag
Contract certainty is required for:
 - All open market policies (i.e. not a facility or a dec)
 - External facilities, not external decs (external is where binder type <> 4)
 - Internal decs, but not internal facilities  (internal is where binder type = 4)
 - Eurobase sections only
 - "Real" sections only
 - Sections A&J only
 - Not 'A' sections where another 'A' section has been completed
*/




--added for ticket: Categorisation of Admitted/Non-Admitted/Lloyds business across source systems (516)
UPDATE p SET
AdmittedNonAdmitted   
			      = CASE
                        WHEN s.CarrierIndicator in ('BICI', 'BAIC') THEN 'Admitted'
                        WHEN s.CarrierIndicator in ('BUSA', 'BESI', 'BUSB') THEN 'Non-Admitted'
						WHEN s.CarrierIndicator = 'Non US carrier' THEN 'Lloyds'
                    END
FROM
ODS.Policy p
INNER JOIN ODS.Section s on  p.PK_Policy = s.FK_Policy
INNER JOIN ODS.TriFocus tf ON s.FK_TriFocus = tf.PK_TriFocus
WHERE p.SourceSystem NOT IN ('BeazleyPro', 'Gamechanger', 'myBeazley')
OR (p.SourceSystem = 'myBeazley' AND s.Product = 'MyBeazley Broker Access PCG' )

UPDATE s
SET	s.KeyBrokerName			= 
								CASE WHEN s.CarrierIndicator = 'BICI' AND s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger')
										THEN crm.BrokerName
									 WHEN s.CarrierIndicator IN ('BUSA' ,'BAIC') AND s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH')
										THEN crm.BrokerName
                                     WHEN s.CarrierIndicator='Non BICI/BUSA/BAIC' AND s.sourcesystem='CIPS'
										THEN crm.BrokerName
								 END
	,s.KeyBrokerSourceId	= 
								CASE WHEN s.CarrierIndicator = 'BICI' AND s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger')
										THEN crm.AccountNumber
									 WHEN s.CarrierIndicator IN ('BUSA' ,'BAIC') AND s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH')
										THEN crm.AccountNumber
                                    WHEN s.CarrierIndicator='Non BICI/BUSA/BAIC' AND s.sourcesystem='CIPS'
										THEN crm.AccountNumber
								 END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.CRMBroker crm 
	ON crm.PK_CRMBroker = p.FK_CRMBroker
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND  k.SourceBrokerName = crm.BrokerName 
	   AND k.MappingRule_Name = 'CRM Broker'
WHERE s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH', 'CIPS')
																				
UPDATE s
SET	s.KeyBrokerName			= crm.BrokerName
	,s.KeyBrokerSourceId	= crm.AccountNumber
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.CRMBroker crm 
	ON crm.PK_CRMBroker = p.FK_CRMBroker
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND  k.SourceBrokerName = crm.BrokerName 
	   AND k.MappingRule_Name = 'CRM Broker'
WHERE s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH', 'CIPS')


UPDATE s
SET	 s.KeyBrokerName			= crm.BrokerName
	,s.KeyBrokerSourceId	= crm.AccountNumber
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.CRMBroker crm 
	ON crm.PK_CRMBroker = p.FK_CRMBroker
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND  k.SourceBrokerName = crm.BrokerName 
	   AND k.MappingRule_Name = 'CRM Broker'
WHERE s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH', 'CIPS')



update	ODS.Section
set		[FK_ExceptionDocumentDate]                   = ([Utility].[udf_GenerateDateKey]([ExceptionDocumentDate])) 
		,[FK_ContractCertaintyDocumentDate]          = ([Utility].[udf_GenerateDateKey]([ContractCertaintyDocumentDate]))  
		,[RationaleDate]                             = ([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate])) 
		,[EarliestLPSOPremiumSigningNumberName]      = (isnull(CONVERT([varchar](255),[EarliestLPSOPremiumSigningNumber]),''))
		,[HasRationaleDocumentName]                  = ([ODS].[udf_FormatBitAsYesNo]([HasRationaleDocument]))
		,[HasTreatyAggsTerritoryName]                = ([ODS].[udf_FormatBitAsYesNo]([HasTreatyAggsTerritory]))
		,[HasUnderwriterAuthorityExceptionName]      = ([ODS].[udf_FormatBitAsYesNo]([HasUnderwriterAuthorityException])) 
		,[LatestLPSOPremiumSigningNumberName]        = (isnull(CONVERT([varchar](255),[LatestLPSOPremiumSigningNumber]),''))
		,[HasExceptionDocumentName]                  = ([ODS].[udf_FormatBitAsYesNo]([HasExceptionDocument]))
		,[RationaleDateName]                         = ([ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate]))) 
		,[HasContractCertaintyDocumentName]          = ([ODS].[udf_FormatBitAsYesNo]([HasContractCertaintyDocument])) 
		,[ContractCertaintyPreBindOnTimeName]        = ([ODS].[udf_FormatBit]([ContractCertaintyPreBindOnTime],'On Time','Not On Time','Not On Time')) 

 

 /* BI-5937 Start*/
 
 -- Update ConsecutiveNumberOfPolicyRenewals in ODS.Policy
 
 
 ;WITH cte_exp_p AS (

    SELECT   p.PK_Policy
			,p.PolicyReference
			,p.ExpiringPolicy
			,ConsecutiveNumberOfPolicyRenewals = CASE WHEN p.ExpiringPolicy IS NULL THEN 0 ELSE 1 END
	FROM ODS.Policy p
	LEFT JOIN ODS.Policy e on p.ExpiringPolicy = e.PolicyReference
	WHERE p.IsQuote = 0
	and e.PolicyReference is null

	


    UNION ALL

    SELECT   p.PK_Policy
			,p.PolicyReference
			,p.ExpiringPolicy
			,ConsecutiveNumberOfPolicyRenewals = e.ConsecutiveNumberOfPolicyRenewals + 1
	FROM ODS.Policy p
	     INNER JOIN  cte_exp_p e on p.ExpiringPolicy = e.PolicyReference
    WHERE p.IsQuote = 0
)

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = c.ConsecutiveNumberOfPolicyRenewals
FROM cte_exp_p c
     INNER JOIN ODS.Policy p ON c.PK_Policy = p.PK_Policy
WHERE c.ConsecutiveNumberOfPolicyRenewals <> 0

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = REVERSE(SUBSTRING(REVERSE(PolicyReference),0,CHARINDEX('_',REVERSE(PolicyReference)))) - 1
FROM  ODS.Policy p
WHERE SourceSystem = 'CIPS'


UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = CASE WHEN ISNUMERIC(RIGHT(BrokerAccessPolicyNumber, 1)) = 1 AND BrokerAccessPolicyNumber LIKE ('%Renewal%') THEN RIGHT(BrokerAccessPolicyNumber, 1)
	                                                WHEN BrokerAccessPolicyNumber NOT LIKE ('%Renewal%') THEN 0 
													ELSE 1 END
FROM ODS.Policy p with (nolock)
WHERE BrokerAccessPolicyNumber IS NOT NULL
AND SourceSystem = 'Unirisx'


;with cte_bapn AS (
SELECT PolicyReference,
       ROW_NUMBER () OVER (PARTITION BY p.BrokerAccessPolicyNumber ORDER BY p.PolicyReference) as RowNo,
	   BrokerAccessPolicyNumber
FROM  ODS.Policy p with (nolock) 
WHERE p.BrokerAccessPolicyNumber IN (
										SELECT p.BrokerAccessPolicyNumber
										FROM ODS.Policy p with (nolock) 
												 INNER JOIN BeazleyIntelligenceLanding.Unirisx_FullSet.Policy up on p.PolicyReference = up.PolicyReference
										WHERE SourceSystem = 'unirisx'
											AND p.BrokerAccessPolicyNumber like 'BFR%'
											AND (up.UniquePolicyReference LIKE '%PCG' OR up.UniquePolicyReference LIKE '%Broker Access')
										GROUP BY   p.BrokerAccessPolicyNumber
										HAVING COUNT(p.BrokerAccessPolicyNumber) > 1
										--ORDER BY BrokerAccessPolicyNumber, PolicyReference									
									)
					)

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = t.RowNo - 1
FROM ODS.Policy p with (nolock) 
INNER JOIN cte_bapn t on p.PolicyReference = t.PolicyReference 
WHERE p.BrokerAccessPolicyNumber IS NOT NULL
AND p.SourceSystem = 'Unirisx'




 -- Update ConsecutiveNumberOfSectionRenewals in ODS.Section
/*
 ;WITH cte_exp_s AS (

    SELECT   s.PK_Section
			,s.SectionReference
			,s.SectionSequenceId
			,s.ExpiringSection
			,ConsecutiveNumberOfSectionRenewals = CASE WHEN s.ExpiringSection IS NULL THEN 0 ELSE 1 END
	FROM ODS.Section s
	LEFT JOIN ODS.Section e on s.ExpiringSection = e.SectionReference
	WHERE s.IsQuote = 0
	and e.SectionReference is null

	 


    UNION ALL

    SELECT   s.PK_Section
			,s.SectionReference
			,s.SectionSequenceId
			,s.ExpiringSection
			,ConsecutiveNumberOfSectionRenewals = CASE WHEN s.SectionSequenceId = e.SectionSequenceId THEN e.ConsecutiveNumberOfSectionRenewals + 1 ELSE 0 END			
	FROM ODS.Section s
	     INNER JOIN  cte_exp_s e on s.ExpiringSection = e.SectionReference
    WHERE s.IsQuote = 0
)

UPDATE s
SET ConsecutiveNumberOfSectionRenewals = c.ConsecutiveNumberOfSectionRenewals
FROM cte_exp_s c
     INNER JOIN ODS.Section s ON c.PK_Section = s.PK_Section
WHERE c.ConsecutiveNumberOfSectionRenewals <> 0

UPDATE s
SET ConsecutiveNumberOfSectionRenewals = SUBSTRING(SectionReference,CHARINDEX('_',SectionReference)+1,2)- 1
FROM  ODS.Section s
WHERE SourceSystem = 'CIPS'

*/
/* BI-5937 End*/