﻿

CREATE PROCEDURE [ODS].[usp_LoadLPSOTransactionSpecialCategoryCatastrophe]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#LPSOTransactionSpecialCategoryCatastrophe') IS NOT NULL)
DROP TABLE #LPSOTransactionSpecialCategoryCatastrophe

CREATE TABLE #LPSOTransactionSpecialCategoryCatastrophe
(
    [FK_LPSOTransaction]            [bigint] NOT NULL,
	[FK_SpecialCategoryCatastrophe] [bigint] NOT NULL
)

/*
The rules are as follows:
    All claim transactions where the transaction attaches to a claim which is allocated to the special also attach to the special
    All reinstatement premium (QualCatCode = 'H') transactions go against every cat code to which the policy attaches.
*/

/*Claim transactions*/
INSERT INTO #LPSOTransactionSpecialCategoryCatastrophe
(
    FK_LPSOTransaction
    ,FK_SpecialCategoryCatastrophe
)
SELECT
FK_LPSOTransaction                  = lt.PK_LPSOTransaction
,FK_SpecialCategoryCatastrophe      = spec.PK_SpecialCategoryCatastrophe
FROM
ODS.LPSOTransaction lt
INNER JOIN
ODS.ClaimExposure ce ON
lt.FK_ClaimExposure = ce.PK_ClaimExposure
INNER JOIN
ODS.SpecialCategoryCatastrophe spec ON
ce.FK_SpecialCategoryCatastrophe = spec.PK_SpecialCategoryCatastrophe
WHERE
lt.CategoryCode IN (4,5)
AND ce.FK_SpecialCategoryCatastrophe <> 0

/*Premium transactions*/
INSERT INTO #LPSOTransactionSpecialCategoryCatastrophe
(
    FK_LPSOTransaction
    ,FK_SpecialCategoryCatastrophe
)
SELECT
FK_LPSOTransaction                  = lt.PK_LPSOTransaction
,FK_SpecialCategoryCatastrophe      = x.FK_SpecialCategoryCatastrophe
FROM
ODS.LPSOTransaction lt
INNER JOIN
(
    SELECT
    FK_Section                          = ces.FK_Section
    ,FK_SpecialCategoryCatastrophe      = ce.FK_SpecialCategoryCatastrophe
    FROM
    ODS.ClaimExposure ce
    INNER JOIN
    ODS.ClaimExposureSection ces ON
    ce.PK_ClaimExposure = ces.FK_ClaimExposure
    WHERE
    ce.FK_SpecialCategoryCatastrophe <> 0
    GROUP BY
    ces.FK_Section
    ,ce.FK_SpecialCategoryCatastrophe
) x ON
lt.FK_Section = x.FK_Section
--AND lt.ProcessingPeriodDate >= x.FirstMovementDate
WHERE
lt.CategoryCode IN (1,2,3)
AND lt.QualCatCode = 'H'

/*All others*/
INSERT INTO #LPSOTransactionSpecialCategoryCatastrophe
(
    FK_LPSOTransaction
    ,FK_SpecialCategoryCatastrophe
)
SELECT
FK_LPSOTransaction              = lt.PK_LPSOTransaction
,FK_SpecialCategoryCatastrophe  = 0
FROM
ODS.LPSOTransaction lt
WHERE 
NOT EXISTS (SELECT 1 FROM #LPSOTransactionSpecialCategoryCatastrophe lspc WHERE lt.PK_LPSOTransaction = lspc.FK_LPSOTransaction)

MERGE ODS.LPSOTransactionSpecialCategoryCatastrophe AS TARGET

USING #LPSOTransactionSpecialCategoryCatastrophe AS SOURCE

 ON TARGET.FK_LPSOTransaction            = SOURCE.FK_LPSOTransaction
AND TARGET.FK_SpecialCategoryCatastrophe = SOURCE.FK_SpecialCategoryCatastrophe

WHEN MATCHED THEN

UPDATE SET 
 TARGET.FK_LPSOTransaction                    = SOURCE.FK_LPSOTransaction
,TARGET.FK_SpecialCategoryCatastrophe         = SOURCE.FK_SpecialCategoryCatastrophe
,TARGET.AuditModifyDateTime                   = GETDATE()						
,TARGET.AuditModifyDetails	                  = 'Merge in [ODS].[LPSOTransactionSpecialCategoryCatastrophe] table' 

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 FK_LPSOTransaction
    ,FK_SpecialCategoryCatastrophe
	,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_LPSOTransaction
,SOURCE.FK_SpecialCategoryCatastrophe
,'New in [ODS].[LPSOTransactionSpecialCategoryCatastrophe] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

IF (OBJECT_ID('tempdb..#LPSOTransactionSpecialCategoryCatastrophe') IS NOT NULL)
DROP TABLE #LPSOTransactionSpecialCategoryCatastrophe;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'LPSOTransactionSpecialCategoryCatastrophe';