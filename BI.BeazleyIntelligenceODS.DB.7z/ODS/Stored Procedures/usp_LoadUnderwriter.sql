﻿CREATE PROCEDURE [ODS].[usp_LoadUnderwriter]
AS

SET NOCOUNT ON

DECLARE @AlwaysUpper varchar(8000)
DECLARE @AlwaysLower varchar(8000)
/*The list below is of literals which should always appear in upper case in the "UnderwriterName" field
The spaces are important - for example we want " US " to be capitalised ,but not " US" as the latter may appear 
in "XXX USER".
We use "~" as a separator as it's less likely to appear in the data than a comma*/
SET @AlwaysUpper = 'BUSA~BICI~USM~ EPL~ US ~ TMB~ PE~ MM~ OPPI~ CM~ FS~ OCC~ ML ~II~ PI~ SL'
SET @AlwaysLower = 'earson~erkins~eters~lack~erez~lattery~ender~eacock~errin~eh~ettit~lot~eacey~earson~ink~ccur' 
--^"Pearson" comes out as "PEarson" otherwise, because of "PE" above, same for "Perkins"

IF (OBJECT_ID('tempdb..#Underwriter') IS NOT NULL)
DROP TABLE #Underwriter

CREATE TABLE #Underwriter (
	[IsUnknownMember]			bit NOT NULL DEFAULT(0),
	[UnderwriterUserInitials]	varchar(255) NULL,
	[UnderwriterInitials]		varchar(255) NULL,
	[UnderwriterName]			varchar(255) NULL,
	[UnderwriterOffice]			varchar(255) NULL,
	[UnderwriterCountry]		varchar(255) NULL,
	[UnderwriterLogin]			varchar(255) NULL
)

-- Unknown member Underwriter
INSERT INTO #Underwriter
	(
		IsUnknownMember
		,UnderwriterUserInitials
		,UnderwriterInitials
		,UnderwriterName
	)
	SELECT
	IsUnknownMember             = 1
	,UnderwriterUserInitials    = 'N/A' 
	,UnderwriterInitials        = 'N/A' 
	,UnderwriterName            = 'N/A'


INSERT INTO #Underwriter
(
     UnderwriterUserInitials
    ,UnderwriterInitials
    ,UnderwriterName
	,UnderwriterOffice
	,UnderwriterCountry
	,UnderwriterLogin
)
SELECT	DISTINCT
UnderwriterUserInitials         = ebu.UnderwriterUserInitials
,UnderwriterInitials            = Utility.udf_ProcessString(ebu.UnderwriterInitials, 1)
,UnderwriterName                =   /*In Eurobase the underwriter names are stored in upper case. We want
                                    to convert these to title case (first letter of each word capitalised). However,
                                    the names are sometimes those of TriFocus groups rather than people,
                                    so we need to be a little wary - i.e. keep some of the literal values in upper case*/
                                    Utility.udf_ConvertTitleCase
                                    (
                                        Utility.udf_ProcessString(ebu.Underwriter, 1)
                                        /*List of literals which should always be in upper case*/
                                        ,@AlwaysUpper
                                        /*List of literals which should always be in lower case*/
                                        ,@AlwaysLower
                                    ) 
                                    /*The function should probably also have a "retain case" parameter, but it's much more
                                    time consuming to write than "AlwaysUpper" and "AlwaysLower", so we'll add one at some
                                    point if required*/
,UnderwriterOffice                 = ul.UnderwriterOffice
,UnderwriterCountry                = ul.UnderwriterCountry
,UnderwriterLogin				   = ebu.Underwriter_login

FROM 
Staging_MDS.dbo.vw_user_details ebu
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on ebu.Underwriter = ul.UnderwriterName
WHERE
ISNULL(ebu.UnderwriterUserInitials, '') <> ''
AND ebu.UnderwriterInd = 'Y'

/*** Unirisx Section ***/ 
INSERT INTO #Underwriter
(
     UnderwriterName
	,UnderwriterOffice
	,UnderwriterCountry

)
SELECT DISTINCT
 UnderwriterName                    = Utility.udf_ConvertTitleCase(s.UnderwriterName, @AlwaysUpper, '')
,UnderwriterOffice                  = ul.UnderwriterOffice
,UnderwriterCountry           		= ul.UnderwriterCountry

FROM
BeazleyIntelligenceDataContract.Outbound.vw_Section s
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on s.UnderwriterName = ul.UnderwriterName
WHERE
NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE u.UnderwriterName = s.UnderwriterName)
AND ISNULL(s.UnderwriterName, '') <> ''
AND s.SourceSystem IN ('Unirisx', 'Gamechanger','CIPS' , 'FDR', 'myBeazley', 'USHVH','StagingDataContract')
--AND s.IsActive = 1


/*** Unirisx Contract Certainty***/ 
INSERT INTO #Underwriter
(
    UnderwriterName
   ,UnderwriterOffice
   ,UnderwriterCountry
)
SELECT DISTINCT
 UnderwriterName                    = Utility.udf_ConvertTitleCase(concer.UnderwriterContractCertainty, @AlwaysUpper, '')
,UnderwriterOffice                  = ul.UnderwriterOffice
,UnderwriterCountry           		= ul.UnderwriterCountry
FROM
BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension concer
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on concer.UnderwriterContractCertainty = ul.UnderwriterName
WHERE
NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE u.UnderwriterName = concer.UnderwriterContractCertainty)
AND ISNULL(concer.UnderwriterContractCertainty, '') <> ''
AND concer.SourceSystem IN ('Unirisx')
--AND concer.IsActive = 1

/*** Unirisx Risk Entered By***/ 
INSERT INTO #Underwriter
(
    UnderwriterName
   ,UnderwriterOffice
   ,UnderwriterCountry
)
SELECT DISTINCT
 UnderwriterName                      = Utility.udf_ConvertTitleCase(pol.UnderwriterRiskEnteredBy, @AlwaysUpper, '')
,UnderwriterOffice                    = ul.UnderwriterOffice
,UnderwriterCountry           	      = ul.UnderwriterCountry
FROM
BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension pol
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on pol.UnderwriterRiskEnteredBy = ul.UnderwriterName
WHERE
NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE u.UnderwriterName = pol.UnderwriterRiskEnteredBy)
AND ISNULL(pol.UnderwriterRiskEnteredBy, '') <> ''
AND pol.SourceSystem IN ('Unirisx')
--AND pol.IsActive = 1


/*BeazleyPro*/
INSERT INTO #Underwriter
(
    UnderwriterName
   ,UnderwriterOffice
   ,UnderwriterCountry
)

SELECT DISTINCT 
 UnderwriterName                      = unw.Name
,UnderwriterOffice                    = ul.UnderwriterOffice
,UnderwriterCountry           	      = ul.UnderwriterCountry

FROM 
Staging_Matlock.Matlock_Staging.vw_Risk risk
INNER JOIN 
Staging_Matlock.Matlock_Staging.vw_Underwriter unw
ON risk.UnderwriterId = unw.MatlockKey
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on unw.Name = ul.UnderwriterName
WHERE 
ISNULL(unw.Name, '') <> ''
AND NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE unw.Name = u.UnderwriterName)

/*ClaimCenter*/
--INSERT INTO ODS.Underwriter
--(
--    UnderwriterName
--   ,UnderwriterOffice
--   ,UnderwriterCountry
--)
--SELECT DISTINCT
--UnderwriterName                       = Utility.udf_ConvertTitleCase(ccp.UnderwriterName, @AlwaysUpper, @AlwaysLower)
--,UnderwriterOffice                    = ul.UnderwriterOffice
--,UnderwriterCountry           	      = ul.UnderwriterCountry
--FROM
--BeazleyIntelligenceDataContract.Outbound.Claim ccp
--LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on ccp.UnderwriterName = ul.UnderwriterName
--WHERE
--NOT EXISTS
--(SELECT 1 FROM ODS.Underwriter u WHERE u.UnderwriterName = ccp.UnderwriterName)
--AND ISNULL(ccp.UnderwriterName, '') <> ''
--AND ccp.SourceSystem = 'ClaimCenter' 
--AND ccp.IsActive = 1

/*Data Contract*/
INSERT INTO #Underwriter
(
    UnderwriterName
   ,UnderwriterOffice
   ,UnderwriterCountry
)
SELECT DISTINCT
UnderwriterName                       = Utility.udf_ConvertTitleCase(s.UnderwriterName, @AlwaysUpper, @AlwaysLower)
,UnderwriterOffice                    = ul.UnderwriterOffice
,UnderwriterCountry           	      = ul.UnderwriterCountry
FROM
Staging_DataContract.DataContract_Staging.Section s
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on s.UnderwriterName = ul.UnderwriterName
WHERE
NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE u.UnderwriterName = s.UnderwriterName)
AND ISNULL(s.UnderwriterName, '') <> ''
AND s.SourceSystemName NOT IN ( 'FDR', 'USHVH')

/*Insight*/
INSERT INTO #Underwriter
(
    UnderwriterName
   ,UnderwriterOffice
   ,UnderwriterCountry
)

SELECT DISTINCT 
 UnderwriterName                      = s.UnderwriterName
,UnderwriterOffice                    = ul.UnderwriterOffice
,UnderwriterCountry           	      = ul.UnderwriterCountry
FROM 
BeazleyIntelligenceDataContract.Outbound.vw_Submission s
LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on s.UnderwriterName = ul.UnderwriterName

WHERE 
ISNULL(s.UnderwriterName, '') <> ''
AND NOT EXISTS
(SELECT 1 FROM #Underwriter u WHERE s.UnderwriterName = u.UnderwriterName)
AND s.SourceSystem = 'Insight'
AND LTRIM(RTRIM(s.SourceSystemLocation)) = 'UK'
--AND s.IsActive = 1

-- Insert underwriter list from underwriter authority exception database if the are not in Eurobase
IF (OBJECT_ID('tempdb..#UnderwriterListAuthority') IS NOT NULL)
DROP TABLE #UnderwriterListAuthority

CREATE TABLE #UnderwriterListAuthority
 (
     UnderwriterUserInitials VARCHAR(255) NOT NULL
    ,UnderwriterInitials     VARCHAR(255) NULL 
    ,UnderwriterName         VARCHAR(255) NULL
    ,UnderwriterSequenceId   INT          NOT NULL -- Used to avoid cases where the same underwriter initial has been used for two or more different names by mistake
	,UnderwriterOffice       VARCHAR(255) NULL
    ,UnderwriterCountry      VARCHAR(255) NULL
 )

INSERT INTO #UnderwriterListAuthority
 (
      UnderwriterUserInitials
     ,UnderwriterInitials    
     ,UnderwriterName        
     ,UnderwriterSequenceId  
	 ,UnderwriterOffice 
	 ,UnderwriterCountry
 )
(
 SELECT  
  UnderwriterUserInitials     = auth.UnderwriterInitials
 ,UnderwriterInitials         = auth.UnderwriterInitials
 ,UnderwriterName             = auth.UnderwriterName
 ,UnderwriterSequenceId       = ROW_NUMBER() OVER (PARTITION BY auth.UnderwriterInitials ORDER BY auth.UnderwriterInitials)  
 ,UnderwriterOffice           = ul.UnderwriterOffice   
 ,UnderwriterCountry          = ul.UnderwriterCountry

 FROM
 Staging_BeazleyAuthorityExceptions.BeazleyAuthorityExceptions_Staging.AuthorityException auth
 LEFT JOIN Staging_MDS.MDS_Staging.UnderwriterLocation ul on auth.UnderwriterName = ul.UnderwriterName
 WHERE   COALESCE(auth.UnderwriterInitials,'')<>''
         AND NOT EXISTS (SELECT 1 FROM #Underwriter u WHERE auth.UnderwriterInitials = u.UnderwriterUserInitials)
)

INSERT INTO #Underwriter
 (
     UnderwriterUserInitials
    ,UnderwriterInitials
    ,UnderwriterName 
	,UnderwriterOffice 
	,UnderwriterCountry   
 )

 (
 SELECT 
        UnderwriterUserInitials			= UnderwriterUserInitials
       ,UnderwriterInitials             = Utility.udf_ProcessString(UnderwriterInitials,1)
       ,UnderwriterName                 = Utility.udf_ConvertTitleCase(
														    			 Utility.udf_ProcessString(UnderwriterName, 1)
																		,@AlwaysUpper
																		,@AlwaysLower
																	  ) 
	   ,UnderwriterOffice               = UnderwriterOffice
	   ,UnderwriterCountry              = UnderwriterCountry

 FROM #UnderwriterListAuthority
 WHERE UnderwriterSequenceId = 1
 )


;MERGE ods.Underwriter  AS Target
USING #Underwriter as Source 
	ON (
		ISNULL(Source.UnderwriterUserInitials, 'Not Available') = ISNULL(Target.UnderwriterUserInitials, 'Not Available')
	AND ISNULL(Source.UnderwriterName, 'Not Available') = ISNULL(Target.UnderwriterName, 'Not Available')
	)
WHEN MATCHED THEN UPDATE
	SET Target.[IsUnknownMember]		= Source.[IsUnknownMember],
		Target.[UnderwriterInitials]	= Source.[UnderwriterInitials] ,
		Target.[UnderwriterOffice]		= Source.[UnderwriterOffice],
		Target.[UnderwriterCountry]		= Source.[UnderwriterCountry],
		Target.[UnderwriterLogin]		= Source.[UnderwriterLogin]
WHEN NOT MATCHED THEN 
		INSERT([IsUnknownMember], [UnderwriterUserInitials], [UnderwriterInitials], [UnderwriterName], [UnderwriterOffice], [UnderwriterCountry], [UnderwriterLogin])
		VALUES(Source.[IsUnknownMember], Source.[UnderwriterUserInitials], Source.[UnderwriterInitials], Source.[UnderwriterName], Source.[UnderwriterOffice], Source.[UnderwriterCountry], Source.[UnderwriterLogin]);


--UnderwriterWorkflow

;MERGE ODS.UnderwriterWorkflow AS TARGET
	USING (
				SELECT
							IsUnknownMember					= 1
							,UnderwriterUserInitials		= 'N/A'
							,UnderwriterInitials			= 'N/A'
							,UnderwriterName				= 'N/A'

				UNION

				SELECT		IsUnknownMember					= 0
							,UnderwriterUserInitials		= UnderwriterUserInitials
							,UnderwriterInitials			= UnderwriterInitials
							,UnderwriterName				= UnderwriterName
				FROM		ODS.Underwriter u 
				WHERE		UnderwriterUserInitials IS NOT NULL 
				AND			IsunknownMember <> 1
	
				UNION 
	
				SELECT		IsUnknownMember					= 0
							,UnderwriterUserInitials		= ebu.UnderwriterUserInitials
							,UnderwriterInitials			= ebu.UnderwriterInitials
							,UnderwriterName                = ebu.Underwriter
				FROM		Staging_MDS.dbo.vw_user_details ebu
				LEFT JOIN	Staging_MDS.MDS_Staging.UnderwriterLocation ul
						ON	ebu.Underwriter = ul.UnderwriterName
				WHERE		NOT EXISTS (
										SELECT 		1 
										FROM		ODS.Underwriter u 
										WHERE		u.UnderwriterName = ebu.Underwriter 
												AND u.UnderwriterInitials = ebu.UnderwriterInitials
							)
						AND ebu.UnderwriterInitials IS NOT NULL
			) AS SOURCE

			ON	ISNULL(Source.UnderwriterUserInitials, 'Not Available') = ISNULL(Target.UnderwriterUserInitials, 'Not Available')
				AND ISNULL(Source.UnderwriterName, 'Not Available') = ISNULL(Target.UnderwriterName, 'Not Available')

	WHEN MATCHED THEN
		 UPDATE
		 SET TARGET.IsUnknownMember			= SOURCE.IsUnknownMember
			,TARGET.UnderwriterInitials		= SOURCE.UnderwriterInitials
			,TARGET.AuditModifyDateTime		= GETDATE()
			,TARGET.AuditModifyDetails		= 'Merge in ODS.usp_LoadUnderwriter'

	WHEN NOT MATCHED BY TARGET THEN
		INSERT
		(
				IsUnknownMember
				,UnderwriterUserInitials		
				,UnderwriterInitials			
				,UnderwriterName   
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				SOURCE.IsUnknownMember
				,SOURCE.UnderwriterUserInitials
				,SOURCE.UnderwriterInitials
				,SOURCE.UnderwriterName
				,GETDATE()
				,'New add in ODS.usp_LoadUnderwriter'	
			)

	WHEN NOT MATCHED BY SOURCE THEN
		DELETE;


IF (OBJECT_ID('tempdb..#UnderwriterListAuthority') IS NOT NULL)
DROP TABLE #UnderwriterListAuthority

IF (OBJECT_ID('tempdb..#Underwriter') IS NOT NULL)
DROP TABLE #Underwriter