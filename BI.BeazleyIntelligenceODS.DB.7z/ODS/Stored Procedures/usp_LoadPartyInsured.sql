﻿CREATE PROCEDURE [ODS].[usp_LoadPartyInsured]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.SectionRiskClass

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF OBJECT_ID('tempdb..#PartyInsured') IS NOT NULL
DROP TABLE #PartyInsured

CREATE TABLE #PartyInsured
(
    [IsUnknownMember]            [bit] DEFAULT ((0)) NULL,
    [SourceSystem]               [varchar] (255) NOT NULL,
    [SourceSystemId]             [varchar] (255) NOT NULL,
    [InsuredSourceID]            [varchar] (255) NULL,
    [InsuredName]                [varchar] (350) NOT NULL,
    [InsuredCity]                [varchar] (255) NULL,
    [InsuredState]               [varchar] (255) NULL,
    [InsuredCountry]             [varchar] (255) NULL,
    [NAICCode]                   [int]           NULL,
    [NAIC]                       [varchar] (255) NULL,
)

INSERT INTO #PartyInsured
(
     SourceSystem
    ,SourceSystemId
    ,InsuredName   
    ,InsuredCity   
    ,InsuredState  
    ,InsuredCountry
    ,NAICCode
    ,NAIC
)

	SELECT 
	SourceSystem
	,SourceSystemId
	,InsuredName
	,InsuredCity
	,InsuredState
	,InsuredCountry
	,NAICCode
	,NAIC 
	from
	(SELECT
			 SourceSystem            = 'BeazleyPro'
			,SourceSystemId         = ins.AccountId
			,InsuredName            = ins.Name     
			,InsuredCity            = Utility.udf_ProcessString(ins.City, 1)
			,InsuredState           = Utility.udf_ProcessString(ins.[State], 1)
			,InsuredCountry         = Utility.udf_ProcessString(ins.Country, 1)
			,NAICCode               = n.Id
			,NAIC                   = n.Name
			,SeqId = row_number() over (partition by ins.AccountId order by ins.extract_datetime desc)
		FROM
			Staging_Matlock.Matlock_Staging.vw_Account ins
		
			LEFT OUTER JOIN
			Staging_Matlock.Matlock_Staging.vw_Naics n 
			ON ins.NaicsId = n.Id
		
		WHERE 
			ISNULL(ins.Name, '') <> '') x
			where SeqId = 1


INSERT INTO #PartyInsured
(
     SourceSystem
    ,SourceSystemId
    ,InsuredName   
    ,InsuredCity   
    ,InsuredState  
    ,InsuredCountry
)
	SELECT	DISTINCT
		 SourceSystem           = sub.SourceSystem
		,SourceSystemId         = sub.InsuredSourceID 
        ,InsuredName   			= sub.InsuredName  
        ,InsuredCity   			= sub.InsuredCity  
        ,InsuredState  			= sub.InsuredState  
        ,InsuredCountry			= sub.InsuredCountry  
								 
	FROM 
	BeazleyIntelligenceDataContract.Outbound.vw_Submission sub
	WHERE 
	(
	   sub.SourceSystem = 'Insight' 
       AND LTRIM(RTRIM(sub.SourceSystemLocation)) = 'UK'   
	  -- OR sub.SourceSystem = 'CIPS'
	   )
	--AND sub.IsActive = 1
	AND sub.InsuredName IS NOT NULL
--	AND ISNULL(sub.AuditModifyDateTime, sub.AuditCreateDateTime) >= AuditModifyDateTime   --trebuia sa fie probabil @LastAuditDate
	AND NOT EXISTS 
	(SELECT 1 FROM #PartyInsured p WHERE p.InsuredName = sub.InsuredName)

MERGE [ODS].[PartyInsured] target
USING
(
SELECT
	IsUnknownMember
	,SourceSystem
	,SourceSystemId
	,InsuredName
	,InsuredCity
	,InsuredState
	,InsuredCountry
	,NAICCode
	,NAIC 
FROM #PartyInsured

UNION ALL 
-- Unknown member PartyInsured
SELECT
	 IsUnknownMember            = 1
	,SourceSystem               = 'N/A'
	,SourceSystemId             = 'N/A'
	,InsuredName                = 'N/A' 
	,InsuredCity				= NULL
	,InsuredState				= NULL
	,InsuredCountry				= NULL
	,NAICCode					= NULL
	,NAIC 						= NULL
) source
ON  target.SourceSystem		= source.SourceSystem
AND target.SourceSystemId   = source.SourceSystemId
AND target.IsUnknownMember	= source.IsUnknownMember

WHEN MATCHED THEN 
UPDATE 
SET 
 target.IsUnknownMember    			= source.IsUnknownMember
,target.SourceSystem       			= source.SourceSystem
,target.SourceSystemId     			= source.SourceSystemId
,target.InsuredName        			= source.InsuredName
,target.InsuredCity					= source.InsuredCity
,target.InsuredState				= source.InsuredState
,target.InsuredCountry				= source.InsuredCountry
,target.NAICCode					= source.NAICCode
,target.NAIC 						= source.NAIC
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadPartyInsured] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
	IsUnknownMember
	,SourceSystem
	,SourceSystemId
	,InsuredName
	,InsuredCity
	,InsuredState
	,InsuredCountry
	,NAICCode
	,NAIC 
	,AuditCreateDateTime   
	,AuditModifyDetails 
)
VALUES
(
	 source.IsUnknownMember
	,source.SourceSystem
	,source.SourceSystemId
	,source.InsuredName
	,source.InsuredCity
	,source.InsuredState
	,source.InsuredCountry
	,source.NAICCode
	,source.NAIC 
	,GETDATE()
	,'New add in [ODS].[usp_LoadPartyInsured] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'PartyInsured';