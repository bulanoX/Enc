﻿CREATE PROCEDURE [ODS].[usp_LoadClaimExposureEntityPerspective]
AS

SET NOCOUNT ON


--DECLARE @LastAuditDate DATETIME2(7)

--SELECT 
--	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
--FROM ODS.ClaimExposureEntityPerspective

--SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

--DELETE FROM ODS.ClaimExposureEntityPerspective WHERE FK_ClaimExposure NOT IN (SELECT PK_ClaimExposure FROM ODS.ClaimExposure)
--DELETE FROM ODS.ClaimExposureEntityPerspective WHERE FK_EntityPerspective NOT IN (SELECT PK_EntityPerspective FROM ODS.EntityPerspective)

;MERGE ODS.ClaimExposureEntityPerspective  AS Target
USING (
SELECT
FK_ClaimExposure            = ce.PK_ClaimExposure
,FK_EntityPerspective       = ep.PK_EntityPerspective
,PerspectiveMultiplier      = 1
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
INNER JOIN
ODS.EntityPerspective ep ON
ep.EntityPerspective = 'Eurobase View'
WHERE
c.HasSCMData = 1
--AND (ISNULL(ce.AuditModifyDateTime, ce.AuditCreateDateTime)>= @LastAuditDate
--OR ISNULL(c.AuditModifyDateTime, c.AuditCreateDateTime)>= @LastAuditDate)

/*
For the combined View, include everything other than:
    BICI/BUSA SCMs for SL and PCG
    SCMs with the read only indicator set
    External claims services claims
*/

UNION ALL

SELECT
FK_ClaimExposure            = ce.PK_ClaimExposure
,FK_EntityPerspective       = ep.PK_EntityPerspective
,PerspectiveMultiplier      = 1
FROM
ODS.ClaimExposure ce
INNER JOIN
ODS.Claim c ON
ce.FK_Claim = c.PK_Claim
INNER JOIN
ODS.ClaimExposureSection ces ON
ce.PK_ClaimExposure = ces.FK_ClaimExposure
INNER JOIN
ODS.Section s ON
ces.FK_Section = s.PK_Section
INNER JOIN
ODS.TriFocus tf ON
ce.FK_PrimaryTriFocus = tf.PK_TriFocus
INNER JOIN
ODS.EntityPerspective ep ON
ep.EntityPerspective = 'Combined View'
WHERE
(c.ClaimType IS NULL OR c.ClaimType <> 'Embedded Claim')
--(c.ExternalClaimsService IS NULL OR c.ExternalClaimsService LIKE '%Beazley%')
AND c.SCMReadOnly = 0 --Ticket 502 Q3
AND
(
    c.HasSCMData = 0
	
 OR (c.HasSCMData = 1 AND s.CarrierIndicator = 'Non US carrier' AND c.SCMReadOnly = 0)
 

 OR (c.HasSCMData = 1 AND s.CarrierIndicator  IN ('BICI', 'BUSA', 'BAIC', 'BESI', 'BUSB') 
     AND tf.DepartmentName NOT IN ('Specialty Lines', 'PCG')
	 AND tf.TriFocusName NOT IN ('BUSA E&S CP','BUSA E&S MM'))

 OR (c.HasSCMData = 1 AND s.CarrierIndicator  in ('BUSA', 'BUSB')
	 AND tf.TriFocusName like ('BUSA BPS%'))
	 
 OR (s.CarrierIndicator  in ('BUSA', 'BUSB') AND ce.SCMReference IS NULL 

     AND tf.TriFocusName IN ('BUSA E&S CP','BUSA E&S MM'))
)
--AND (ISNULL(ce.AuditModifyDateTime, ce.AuditCreateDateTime)>= @LastAuditDate
--OR ISNULL(c.AuditModifyDateTime, c.AuditCreateDateTime)>= @LastAuditDate
--OR ISNULL(s.AuditModifyDateTime, s.AuditCreateDateTime)>= @LastAuditDate)
GROUP BY ce.PK_ClaimExposure
		,ep.PK_EntityPerspective

--/*For the syndicate view, include everything in the combined view and 
--get the perspective multiplier from the primary section*/

--INSERT INTO ODS.ClaimExposureEntityPerspective
--(
--    FK_ClaimExposure
--    ,FK_EntityPerspective
--    ,PerspectiveMultiplier
--)
--SELECT DISTINCT
--FK_ClaimExposure                    = ce.PK_ClaimExposure
--,FK_EntityPerspective               = ep_syn.PK_EntityPerspective
--,PerspectiveMultiplier              = CASE WHEN S.CarrierIndicator IN ('BICI', 'BAIC') AND p.SourceSystem <> 'Eurobase' THEN ISNULL(s.BICICessionMultiplier, 0) ELSE 1 END
--FROM
--ODS.ClaimExposureEntityPerspective cep 
--INNER JOIN
--ODS.EntityPerspective ep ON
--cep.FK_EntityPerspective = ep.PK_EntityPerspective
--AND ep.EntityPerspective = 'Combined View'
--INNER JOIN
--ODS.ClaimExposure ce ON
--cep.FK_ClaimExposure = ce.PK_ClaimExposure
--INNER JOIN
--ODS.ClaimExposureSection ces ON
--ce.PK_ClaimExposure = ces.FK_ClaimExposure
--INNER JOIN
--ODS.Section s ON
--ces.FK_Section = s.PK_Section
--INNER JOIN
--ODS.TriFocus tf ON
--s.FK_TriFocus = tf.PK_TriFocus
--INNER JOIN
--ODS.Policy p ON
--s.FK_Policy = p.PK_Policy
--INNER JOIN
--ODS.EntityPerspective ep_syn ON
--ep_syn.EntityPerspective = 'Syndicate View'

/*For the external claims services view, include all external claims only*/

UNION ALL

SELECT
FK_ClaimExposure            = ce.PK_ClaimExposure
,FK_EntityPerspective       = ep.PK_EntityPerspective
,PerspectiveMultiplier      = 1
FROM
ODS.Claim c
INNER JOIN
ODS.ClaimExposure ce ON
c.PK_Claim = ce.FK_Claim
INNER JOIN
ODS.EntityPerspective ep ON
ep.EntityPerspective = 'External Claims View'
WHERE
c.ClaimType is not null
and c.ClaimType in ('Embedded Claim')
--AND (ISNULL(ce.AuditModifyDateTime, ce.AuditCreateDateTime)>= @LastAuditDate
--OR ISNULL(c.AuditModifyDateTime, c.AuditCreateDateTime)>= @LastAuditDate)
) as Source 
	ON (
		ISNULL(Source.FK_ClaimExposure, 'Not Available') = ISNULL(Target.FK_ClaimExposure, 'Not Available')
	AND ISNULL(Source.FK_EntityPerspective, 'Not Available') = ISNULL(Target.FK_EntityPerspective, 'Not Available')
	)
WHEN MATCHED THEN UPDATE
	SET Target.[FK_ClaimExposure]		= Source.[FK_ClaimExposure],
		Target.[FK_EntityPerspective]	= Source.[FK_EntityPerspective] ,
		Target.[PerspectiveMultiplier]	= Source.[PerspectiveMultiplier],
		Target.[AuditModifyDateTime]	= GETDATE(),						
		Target.[AuditModifyDetails]	    = 'Merge in ODS.usp_LoadClaimExposureEntityPerspective proc'
WHEN NOT MATCHED BY TARGET THEN 
INSERT
(	FK_ClaimExposure	
	,FK_EntityPerspective
	,PerspectiveMultiplier
    ,AuditCreateDateTime
	,AuditModifyDetails	
)
VALUES
(   source.FK_ClaimExposure                 
	,source.FK_EntityPerspective                  
	,source.PerspectiveMultiplier   
	,GETDATE()
	,'New add in ODS.usp_LoadClaimExposureEntityPerspective proc'	
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimExposureEntityPerspective';
