﻿
CREATE PROCEDURE [ODS].[usp_LoadOriginalCurrency]
AS

SET NOCOUNT ON

	;MERGE	ODS.OriginalCurrency	AS TARGET
			USING	
				(	
				SELECT
						IsUnknownMember			= 0
						,CurrencyCode			= cc.CurrencyCode
						,CurrencyName			= cc.CurrencyDescription
				FROM	Staging_MDS.dbo.vw_currency_codes cc

				UNION
				
				SELECT
						IsUnknownMember         = 1
						,CurrencyCode           = 'N/A'
						,CurrencyName           = 'N/A'
				)						
			AS SOURCE

			ON	SOURCE.CurrencyCode = TARGET.CurrencyCode

	WHEN	MATCHED THEN
			UPDATE	
			SET	TARGET.CurrencyName					= SOURCE.CurrencyName
				,TARGET.AuditModifyDateTime	        = GETDATE()						
				,TARGET.AuditModifyDetails	        = 'Merge in ODS.usp_LoadOriginalCurrency' 

	WHEN	NOT MATCHED BY TARGET THEN
			INSERT
			(
				IsUnknownMember
				,CurrencyCode
				,CurrencyName
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				SOURCE.IsUnknownMember
				,SOURCE.CurrencyCode
				,SOURCE.CurrencyName
				,GETDATE()
				,'New add in ODS.usp_LoadOriginalCurrency'	
			)

	WHEN	NOT MATCHED BY SOURCE THEN 
			DELETE
	;

	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'OriginalCurrency';