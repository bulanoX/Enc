﻿

CREATE PROCEDURE [ODS].[usp_LoadSectionEntityPerspective]
AS

SET NOCOUNT ON

IF OBJECT_ID('tempdb..#SectionEntityPerspective') IS NOT NULL
DROP TABLE #SectionEntityPerspective

CREATE TABLE #SectionEntityPerspective
(
    PK_Section                  bigint              NOT NULL
    ,EurobaseView               bit                 NOT NULL    DEFAULT(1)
    --,SyndicateView              bit                 NOT NULL    DEFAULT(1)
    ,CombinedView               bit                 NOT NULL    DEFAULT(1)
    ,SyndicateViewMultiplier    numeric(19,12)      NOT NULL    DEFAULT(1)
    ,PRIMARY KEY(PK_Section)
)

INSERT INTO #SectionEntityPerspective
(
    PK_Section
)
SELECT
PK_Section          = s.PK_Section
FROM
ODS.Section s

/*Eurobase view contains all Eurobase data*/
UPDATE sep SET
EurobaseView = 0
FROM
#SectionEntityPerspective sep
INNER JOIN
ODS.Section s ON
sep.PK_Section = s.PK_Section
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE
s.PK_Section <> 0
AND p.SourceSystem <> 'Eurobase'


/*
Syndciate/combined view contains all other data except:

    - 1. Eurobase BICI/BUSA data for SL, unless binder type = 5 (these are not accounted for in Pro)
    - 2. Binders and non-adjustment Eurobase decs where the binder has non-Eurobase decs
    - 3. Exclude Eurobase sections from the combined view if they have been rekeyed elsewhere
*/

--1
UPDATE sep SET
--SyndicateView       = 0
CombinedView       = 0
FROM
#SectionEntityPerspective sep
INNER JOIN
ODS.Section s ON
sep.PK_Section = s.PK_Section
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.TriFocus tf ON
s.FK_TriFocus = tf.PK_TriFocus
WHERE
s.PK_Section <> 0
AND p.SourceSystem = 'Eurobase'
AND tf.DepartmentName = 'Specialty Lines'
AND s.CarrierIndicator IN ('BICI', 'BUSA', 'BAIC', 'BESI', 'BUSB')
AND (s.BinderType IS NULL OR s.BinderType <> '5')

--2
UPDATE sep SET
--SyndicateView       = 0
CombinedView       = 0
FROM
#SectionEntityPerspective sep
INNER JOIN
ODS.Section s ON
sep.PK_Section = s.PK_Section
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.Section f ON
s.FK_Facility = f.PK_Section
WHERE
s.PK_Section <> 0
AND f.HasNonEurobaseSections = 1
AND p.SourceSystem = 'Eurobase'

-- 3 
UPDATE sep SET
--SyndicateView       = 0
CombinedView       = 0
FROM
#SectionEntityPerspective sep
INNER JOIN
ODS.Section s ON
sep.PK_Section = s.PK_Section
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.Section s_source ON
s.PK_Section = s_source.FK_LinkedSynergySection
WHERE
s.PK_Section <> 0
AND p.SourceSystem = 'Eurobase'

--/*Update syndicate view multiplier*/
--UPDATE sep SET
--SyndicateViewMultiplier     = ISNULL(s.BICICessionMultiplier, 0)
--FROM
--#SectionEntityPerspective sep
--INNER JOIN
--ODS.Section s ON
--sep.PK_Section = s.PK_Section
--INNER JOIN
--ODS.Policy p ON
--s.FK_Policy = p.PK_Policy
--INNER JOIN
--ODS.TriFocus tf ON
--s.FK_TriFocus = tf.PK_TriFocus
--WHERE
--p.SourceSystem <> 'Eurobase'
--AND s.CarrierIndicator IN ('BICI', 'BAIC')


--BI-3714 - BAU - Amend the WEP exc LBS premium field logic for BBR dummy sections only
UPDATE		sep 
		SET sep.CombinedView = 0
FROM		#SectionEntityPerspective sep 
INNER JOIN	ods.Section s 
		ON	sep.PK_Section = s.PK_Section
INNER JOIN	#SectionEntityPerspective parent 
		ON	s.FK_BreachResponseParentSection = parent.PK_Section
WHERE		sep.CombinedView = 1
		AND parent.CombinedView = 0
--end BI-3714--

--DELETE 
--FROM ODS.SectionEntityPerspective
--WHERE FK_EntityPerspective NOT IN (SELECT PK_EntityPerspective FROM ODS.EntityPerspective)
--OR FK_Section NOT IN (SELECT PK_Section FROM ODS.Section)

MERGE ODS.SectionEntityPerspective target
USING
(
    SELECT
    FK_Section              = sep.PK_Section
    ,FK_EntityPerspective    = ep.PK_EntityPerspective
    ,PerspectiveMultiplier  = 1
    FROM
    #SectionEntityPerspective sep
    INNER JOIN
    ODS.EntityPerspective ep ON
    ep.EntityPerspective = 'Eurobase View'
    WHERE
    sep.EurobaseView = 1
    --UNION ALL
    --SELECT
    --FK_Section              = sep.PK_Section
    --,FK_EntityPespective    = ep.PK_EntityPerspective
    --,PerspectiveMultiplier  = SyndicateViewMultiplier
    --FROM
    --#SectionEntityPerspective sep
    --INNER JOIN
    --ODS.EntityPerspective ep ON
    --ep.EntityPerspective = 'Syndicate View'
    --WHERE
    --sep.SyndicateView = 1
    UNION ALL
    SELECT
    FK_Section              = sep.PK_Section
    ,FK_EntityPerspective    = ep.PK_EntityPerspective
    ,PerspectiveMultiplier  = 1
    FROM
    #SectionEntityPerspective sep
    INNER JOIN
    ODS.EntityPerspective ep ON
    ep.EntityPerspective = 'Combined View'
    WHERE
    sep.CombinedView = 1
) source
ON  target.FK_Section   = source.FK_Section
AND target.FK_EntityPerspective   = source.FK_EntityPerspective

WHEN MATCHED THEN 
UPDATE 
SET 
target.PerspectiveMultiplier        = source.PerspectiveMultiplier
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadSectionEntityPerspective] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
 FK_Section            
 ,FK_EntityPerspective  
 ,PerspectiveMultiplier
 ,AuditCreateDateTime   
 ,AuditModifyDetails 
 )
 VALUES
 (
  FK_Section            
  ,FK_EntityPerspective  
  ,PerspectiveMultiplier
  ,GETDATE()
 ,'New add in [ODS].[usp_LoadSectionEntityPerspective] proc'
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE;
IF OBJECT_ID('tempdb..#SectionEntityPerspective') IS NOT NULL
DROP TABLE #SectionEntityPerspective