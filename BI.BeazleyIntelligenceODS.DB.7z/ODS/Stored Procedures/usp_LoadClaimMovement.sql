﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_LoadClaimMovement]   
AS
BEGIN
	--TRUNCATE TABLE ODS.ClaimMovement

	DECLARE @ExchangeRateUSDtoGBP Numeric(38,12) = (SELECT ExchangeRate FROM utility.CurrencyRate WHERE ratetype = 'current' AND currency = 'USD')

	
	/***********************************************************************************************************/
	/*  ClaimMovement  

		1. DUMMY MOVEMENTS are created  only for non-SCM
		2. LocalCurrency
			- Singapore financial team uses LocalCCY and  OriginalCCYToLocalCCYRate (taken from OriginalCCYtoGroupCCYRate)
			- PK for localCCY is taken by join on SettlementCurrency
			- we need to be aware is that this field (OriginalCCYtoGroupCCYRate) has only 4 digits after the comma.
			- ODS.LocalCurrency table has 2 more values  compared with ODS.SettlementCurrency:
					a. N\A (UNKNOWN)
					b. SGD (singapore dollar)
			- all SCM have Local Currency by default N\A

		3. Multi Currency Change

			- BI code populates 
						- ActualOriginalCurrency
						- ActualOriginalAmount
						- Actual OriginalAmountType
			- BI propagates to RedCube
						- ActualOriginalCurrency					 --> does not exist in DataCOntract - managed in ODS
						- ActualOriginalAmount						 --> does not exist in DataCOntract - managed in ODS
						- Actual OriginalAmountType					 --> does not exist in DataCOntract - managed in ODS
						- [ActualToSettlementExchangeRate]			 -> pushed in dataContract by CC V9 
						- [EstimatedSettlementAmount]				 -> pushed in dataContract by CC V9 
						
			- in ODS the BI code  will do these for each claim no matter if they are of multi-currency or not (because they may at some point become multi-currency):
                                  i.      copy the OriginalCCY in ActualOriginalCCY field
								 ii.      copy the OriginalAmount in ActualOriginalAmount field
								iii.      copy the SettlementCCY in OriginalCCY field
								 iv.      copy the SettlementAmount in OriginalAmount field
                                  v.      propagate ActualOriginalCCY and ActualOriginalAmount in fact tables
			- rates [OutstandingOriginalCCYToSettlementCCYRate] and [PaidOriginalCCYToSettlementCCYRate]	are defaulted to 1
			- added field ActualOriginalAmountType with possibel values:
								- Indemnity
								- Fees
								- Defence
			- amounts in Original CCY are  equal to the ones in Settlement CCY

		4. update rates which are 0 with 1 in order not to break in ODS.PostPorcessClaimExposure or in Red.FactClaimMovement 

		5. ToDateOutstanding... fields
			-- we calculate the ToDateOutstanding... fields for:
					-- non SCM movements from migration
					-- non SCM from UI (after go live)
					-- SCM  from UI (after go live)
			-- for SCM movements from migration we take the ToDateOutstanding... fields as pushed by CC V9

		6. MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM

		7. after go live this is the way to see if the movement is for SCM or not: go to Exposure level and  check if ISNULL(ce.SCMReference, '') = '' --> non SCM

		8. CC Team to send all states of the transactions as BI flow takes only the latest

		9. Read-only claims should be sent to BI: [SCMReadOnly] flag should be set to 1 in ODS.Claim for these cases

	   10. old claims (not starting with BEAZ) were migrated into V5 from other sources and is accepted that they have data quality issues -> impact on Sequence Number

	   11. there is an accepted 5 hours delay between Eurobase and ClaimCenter V5 due to flow between them -> impact on Date fields like MovementDate

	   12. payment marked as non erroding 
						-> in V5 reserve was not decreased by this payment. in V9 there is the assumption that every single payment is not erroding.
						- i have asked that for payments that should errode (substracted from reserve) to  receive from CC V9
											- 0 in the payment amount field 
											- information in the ClaimNarrative field about the payment amount and the fact that in V5 was marked as erroding

	   13. ODS V5 is filtering 
						- transactions on claim level 
						- transactions with claim cost category 
									- Beazley Fees 
									- Embeded...

	   14. Transactions on last Movement for each Exposure should reconcile

	   15. Incomplete transactions
			The agreed solution for incomplete transactions is this:
			-	all SCM will be perceived as complete transactions.
			-	The completed transactions have in DataContract.Outbound.ClaimExposureMovementExtension table the field  TransferStatus = ‘Transaction Complete’
			-	CC V9 pushes complete and also incomplete transactions in DataContract into ClaimExposureMovement and ClaimEpxosureMovementExtension entities.
			-	The same transaction can have in time different statuses , the last one being ‘Transaction Complete’ 
			-	Each time the status is changed, the transaction is pushed again with the new status and is merged in DataContract in Outbound Area
			-	So for each transaction (whether is complete or incomplete) we will find in DataContract only the latest status
			-	In ODS we need to apply some filtering in order to pass only Completed transactions
					o	Migration: 
						-	All SCM transactions go  to ODS
						-	All Non-SCM transactions go to ODS (TransferStatus is defaulted to ‘Migration’)
					o	Online transactions(after go live):
						-	All SCM transactions go to ODS
						-	Only Non-SCM transactions that have TransferStatus = ‘Transaction Complete’ (TransactionStatus is defaulted to NULL)  go to ODS

		16.	We can  use MovementType = ‘SCM’ to distinguish SCM transactions from non-SCM transactions even after go live 
			- because of BeazleyShare change they will send 100% beazley share in amounts and the multiplier separately
			- BI code will continue to do the splitting on ShareType
			- SCM after go live will continue to have MovementType = 'SCM' for all movements
			- SCM to date outstading and movement fields are taken directly from DataContract with no logic or calculation appplied also fro migrated claims and also for online claims

		17. LastMovementBandingDate  
			- is updated in postprocessing at Exposure level using the information from Movement level
			- basically is the maximum value  of MovementDate from ODS.ClaimMovement where UseForLastMovementBandingDate = 1
			- if there are different number of movements between V5 and V9 is normal to have different values at reconciliation

		18. TotalIncurred
			- is at Red.FactClaimExposure level and takes the value ToDateTotalIncurred from Red.FactClaimMovement (fcm)
			- is at Red.FactClaimEstimateFinancials and has this logic: ,TotalIncurred                  = CASE WHEN keys.UseMovementForIncurred = 1 THEN fcm.ToDateTotalIncurred ELSE 0 END

		19. INCURRED = PAID + OUTSTANDING (no matter what is the granularity level)

			ToDateTotalIncurred and other calculated fields in Red.FactClaimMovement table:
			
			- [MovementPaidIndemnity]          = cm.MovementPaidIndemnityInOriginalCCY             * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementPaidIndemnityInSettlementCCY           * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementPaidIndemnityInOriginalCCY			   * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate  -> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementPaidFees]               = cm.MovementPaidFeesInOriginalCCY                  * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementPaidFeesInSettlementCCY                * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementPaidFeesInOriginalCCY                  * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate	-> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementPaidDefence ]           = cm.MovementPaidDefenceInOriginalCCY               * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementPaidDefenceInSettlementCCY             * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementPaidFeesInOriginalCCY                  * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate	-> In localCCY
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementOutstandingIndemnity]   = cm.MovementOutstandingIndemnityInOriginalCCY      * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementOutstandingIndemnityInSettlementCCY    * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementOutstandingIndemnityInOriginalCCY	   * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate  -> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementOutstandingFees]        = cm.MovementOutstandingFeesInOriginalCCY           * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementOutstandingFeesInSettlementCCY         * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementOutstandingFeesInOriginalCCY           * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate  -> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementOutstandingDefence ]    = cm.MovementOutstandingDefenceInOriginalCCY        * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier									-> in OriginalCCY
											   = cm.MovementOutstandingDefenceInSettlementCCY      * 1									* cep.PerspectiveMultiplier									-> in Settlement CCY
											   = cm.MovementOutstandingDefenceInOriginalCCY        * x.OriginalCCYMovementMultiplier    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate  -> In localCCY
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementTotalPaid]  AS (([MovementPaidFees]+[MovementPaidIndemnity])+[MovementPaidDefence]),
			- [MovementTotalOutstanding]  AS (([MovementOutstandingFees]+[MovementOutstandingIndemnity])+[MovementOutstandingDefence]),
			- [MovementTotalIncurred]  AS ((((([MovementPaidFees]+[MovementPaidIndemnity])+[MovementPaidDefence])+[MovementOutstandingFees])+[MovementOutstandingIndemnity])+[MovementOutstandingDefence]),
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [MovementIncurredIndemnity]  AS ([MovementPaidIndemnity]+[MovementOutstandingIndemnity]),
			- [MovementIncurredFees]  AS ([MovementPaidFees]+[MovementOutstandingFees]),
			- [MovementIncurredDefence]  AS ([MovementPaidDefence]+[MovementOutstandingDefence]),
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			--=========================================================================================================================================================================================----------------------
			--=========================================================================================================================================================================================----------------------
			----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------            
			- [ToDatePaidIndemnity]            = cm.ToDatePaidIndemnityInOriginalCCY		* cep.PerspectiveMultiplier									   -> in OriginalCCY
											   = cm.ToDatePaidIndemnityInSettlementCCY		* cep.PerspectiveMultiplier									   -> in Settlement CCY
											   = cm.ToDatePaidIndemnityInOriginalCCY		* cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate	   -> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDatePaidFees]                 = cm.ToDatePaidFeesInOriginalCCY				* cep.PerspectiveMultiplier									   -> in OriginalCCY
											   = cm.ToDatePaidFeesInSettlementCCY			* cep.PerspectiveMultiplier									   -> in Settlement CCY
											   = cm.ToDatePaidFeesInOriginalCCY				* cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate	   -> In localCCY
											   --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDatePaidDefence]              = cm.ToDatePaidDefenceInOriginalCCY			* cep.PerspectiveMultiplier									   -> in OriginalCCY
											   = cm.ToDatePaidDefenceInSettlementCCY		* cep.PerspectiveMultiplier									   -> in Settlement CCY
											   = cm.ToDatePaidDefenceInOriginalCCY      * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate	   -> In localCCY
        	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDateOutstandingIndemnity]    = cm.ToDateOutstandingIndemnityInOriginalCCY    * cep.PerspectiveMultiplier								   -> in OriginalCCY
											  = cm.ToDateOutstandingIndemnityInSettlementCCY  * cep.PerspectiveMultiplier								   -> in Settlement CCY
											  = cm.ToDateOutstandingIndemnityInOriginalCCY    * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate   -> In localCCY
											  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDateOutstandingFees]         = cm.ToDateOutstandingFeesInOriginalCCY         * cep.PerspectiveMultiplier								   -> in OriginalCCY
											  = cm.ToDateOutstandingFeesInSettlementCCY       * cep.PerspectiveMultiplier								   -> in Settlement CCY
											  = cm.ToDateOutstandingFeesInOriginalCCY         * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate   -> In localCCY
											  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDateOutstandingDefence       = cm.ToDateOutstandingDefenceInOriginalCCY      * cep.PerspectiveMultiplier								   -> in OriginalCCY
											  = cm.ToDateOutstandingDefenceInSettlementCCY    * cep.PerspectiveMultiplier								   -> in Settlement CCY
											  = cm.ToDateOutstandingDefenceInOriginalCCY      * cep.PerspectiveMultiplier / cm.OriginalCCYtoLocalCCYRate   -> In localCCY
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDateTotalPaid]  AS (([ToDatePaidFees]+[ToDatePaidIndemnity])+[ToDatePaidDefence]),
			- [ToDateTotalOutstanding]  AS (([ToDateOutstandingFees]+[ToDateOutstandingIndemnity])+[ToDateOutstandingDefence]),
			- [ToDateTotalIncurred]  AS ((((([ToDatePaidFees]+[ToDatePaidIndemnity])+[ToDatePaidDefence])+[ToDateOutstandingFees])+[ToDateOutstandingIndemnity])+[ToDateOutstandingDefence]),
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			- [ToDateIncurredFees]  AS ([ToDatePaidFees]+[ToDateOutstandingFees]),
			- [ToDateIncurredIndemnity]  AS ([ToDatePaidIndemnity]+[ToDateOutstandingIndemnity]),
			- [ToDateIncurredDefence]  AS ([ToDatePaidDefence]+[ToDateOutstandingDefence]),

	   20.Embedded claims (farmers) - are sold by farmers so cc does not have the policy number - it takes data from bordereaux

	   21. HasIncurred

			- HasIncurred                    = CASE WHEN ABS(os.TotalOutstandingInSettlementCCY + p.TotalPaidInSettlementCCY) > 1   
			- where 
					- Paid is sum gorup by Exposure level
					- Outstanding is from last movement
			- is affected if the number of movements is different in V5 compared to V9 
			- is affected if the outstanding from last movement is different (may be from sequence numebr switching, doesnoterodereserves flag, ...)
			- is affected if some paid amounts are different or if tehre are paid amounts on new/missing transactions




	 */

	 /*
		Claim
		1. SCM claims with the same policy number and UniqueClaimRerference are grouped in V9 and all the exposures attached in V5 to them will be all attached to the new created Claim
			Example V5:
							C1  - E1
							    - E2
							C2  - E3
							C3  - E4
								- E5
								- E6

				V9:  new claim created: C23
						C23 - E1
						    - E2
						    - E3
						    - E4
						    - E5
						    - E6
			
		2. in V9 all grouped claims start with BEAZG
		3. PK_Claim  has changed because is calculated from ClaimReference
		4. in V5 
				ClaimReference = SCMrefernce for SCM/ ClaimNumber for non SCM
				BeazleyCLaimReference = ClaimNumber
				SCMReference = SCMrefernce for SCM/ blank for non SCM
		5. in V9 
				ClaimReference = ClaimNumber 
				BeazleyCLaimReference = NULL
				SCMReference = SCMrefernce for SCM/ blank for non SCM

	 */

	 /*
		ClaimExposure
		1. all non SCM exposures should have the same ExposureReference and PK_ClaimExposure in both V5 and v9
		2. all SCM exposurers have different Exposure reference 
					- in V5: SCMReference + '-' + SectionSequenceId				 
					- in V9: ClaimReference  + '-' + SectionSequenceId
		2. Exposures created automatically in the migration process (only non SCM)
				- (did not exist in V5 in cc_exposure and fo the dummuy exposures were created in V5 code) should have flag HasRealExposures set to 1
				-  exception in V5: ExposureReference = ClaimReference + '-00'
		3. Exposures from grouped SCM claims have in field ThirdPartyClaimReference the ClaimReference assocaited in V5

	 */

	 /*
		ClaimExposureSection

		1. in V5 one exposure can be associated with muultiple sections and one section can be associated with multiple exposures
		2. in V9 one section can be associated to multiple exposures
		3. in V9 so far Exposure appear only once in CES table
		4. policies and  Sections with SourceSystem = 'CLaimCEnter' were mandatory to be in ODS.Section and ODS.Policy in order to identify the policy from claim level
		5. for all exposures not associated with sections teh code searches the claim and gets the policy pushed at claim level; 
				it searches the policy in ODS.Policy and it takes the first Section from that policy
		6. is used for filling ODS.CLaimMovementLine
		7. is used to update fields in post processing at Exposure level from Section level
		8. If an exposure does not have a section associated, its movements will not appear in ClaimMovementLine table 
			-> this means taht they will not get to Red.FactClaimMovement table
			-> so they will not get to RedCube, even if he exposure has movements (even if is only DummyMovement)
	 */	

	 /*
		Deletes in V5:
		1. all Claims and Exposures without Movements are deleted
		2. all Claims and Exposures for which the Exposure is not associated with a Section are deleted


		Deletes in V9:
		1. all Claims and Exposures without Movements are deleted
	 */
	

	/***********************************************************************************************************/
	/*    Create temp table to stage claims movements. This table will get populated with SCM and CC movs      */
	/***********************************************************************************************************/
	IF (OBJECT_ID('tempdb..#ClaimMovement')) IS NOT NULL DROP TABLE #ClaimMovement

	CREATE TABLE #ClaimMovement
	(
		IDTY                                                    int             IDENTITY(1,1)
		,[FK_OriginalCurrency]                                  varchar(255)    NOT NULL
		,ChequeIssueDate                                        datetime        NULL
		,ChequeNumber                                           varchar(255)    NULL
		,ChequePayee                                            varchar(255)    NULL
		,ClaimTeamExaminer										varchar(255)    NULL
		,ExposureStatusCode                                     varchar(255)    NULL
		,FeesOnlyEntry                                          bit             NOT NULL    DEFAULT(0)
		,FK_ClaimCostCategory                                   bigint          NOT NULL
		,FK_ClaimExposure                                       bigint          NOT NULL
		,FK_DevelopmentPeriod                                   bigint          NULL
		,FK_LocalCurrency										bigint          NOT NULL
		,FK_SettlementCurrency                                  bigint          NOT NULL
		,InvoiceNumber                                          varchar(255)    NULL
		,LPSOSigningDate                                        datetime        NULL
		,LPSOSigningNumber                                      int             NULL        
		,MovementApprovalUser                                   varchar(255)    NULL
		,MovementCreateUser                                     varchar(255)    NULL
		,MovementCreationDate                                   datetime        NULL
		,MovementDate                                           datetime        NULL
		,MovementGroupId                                        int             NULL
		,MovementGroupSequenceId                                int             NULL
		,MovementNarrative                                      varchar(MAX)    NULL
		,MovementNarrativeFlag                                  bit             NULL
		,MovementPaidDefenceInOriginalCCY                       numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidDefenceInSettlementCCY                     numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidFeesInOriginalCCY                          numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidFeesInSettlementCCY                        numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidIndemnityInOriginalCCY                     numeric(19,4)   NOT NULL    DEFAULT(0) /* All movements - both SCM and CC paids are deltas */
		,MovementPaidIndemnityInSettlementCCY                   numeric(19,4)   NOT NULL    DEFAULT(0) /* All movements - both SCM and CC paids are deltas */
		,MovementOutstandingDefenceInOriginalCCY                numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingDefenceInSettlementCCY              numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingFeesInOriginalCCY                   numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingFeesInSettlementCCY                 numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingIndemnityInOriginalCCY              numeric(19,4)   NOT NULL    DEFAULT(0) /* CC only - CC outstandings are always a delta */
		,MovementOutstandingIndemnityInSettlementCCY            numeric(19,4)   NOT NULL    DEFAULT(0) /* CC only - CC outstandings are always a delta */
		,MovementPeriod                                         datetime        NULL
		,MovementReferenceSourceId                              varchar(255)    
		,MovementReference                                      varchar(255)    NOT NULL
		,MovementTaxAmountInOriginalCCY                         numeric(20,4) 
		,MovementTaxAmountInSettlementCCY                       numeric(20,4)
		,MovementType                                           varchar(255)    NOT NULL
		,MovementNetPaymentAmountInOriginalCCY                  numeric(20,4)
        ,MovementNetPaymentAmountInSettlementCCY                numeric(20,4)
		,OriginalCCYToLocalCCYRate								numeric(19,12)  NOT NULL
		,OutstandingOriginalCCYToSettlementCCYRate              numeric(19,12)  NOT NULL
		,PaidOriginalCCYToSettlementCCYRate                     numeric(19,12)  NOT NULL
		,PrimaryExaminerOrCreateUserId                          int             NULL
		,RecoveryCategory                                       varchar(255)    NULL
		,SequenceNumber                                         int             NOT NULL
		,SequenceNumberOrderId                                  int             NOT NULL    DEFAULT 0
		,TaxApplicable                                          varchar(255)
		,TaxPercent                                             numeric(19,12)
		,TBAFlag                                                bit             NULL
		,TBAIndicator                                           varchar(255)    NULL
		,ToDateOutstandingDefenceInOriginalCCY                  numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingDefenceInSettlementCCY                numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingFeesInOriginalCCY                     numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingFeesInSettlementCCY                   numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingIndemnityInOriginalCCY                numeric(19,4)   NOT NULL    DEFAULT(0) /* SCM only - SCM outstandings are always a position */
		,ToDateOutstandingIndemnityInSettlementCCY              numeric(19,4)   NOT NULL    DEFAULT(0) /* SCM only - SCM outstandings are always a position */
		,UseForLastMovementBanding                              bit             NOT NULL    DEFAULT(1)
		,XChangingChecker                                       varchar(255)    NULL
		,CCClaimCostCategory									nvarchar(255)	NULL
		,AuditCreateDateTime                                    datetime2       NULL
		,ActualOriginalCurrency 								VARCHAR(3)		NULL		   --MultiCCY change --
		,ActualOriginalAmount 									NUMERIC(19,4)	NULL		   --MultiCCY change --
		,EstimatedSettlementAmount 								NUMERIC(19,4)	NULL		   --MultiCCY change --
		,ActualToSettlementExchangeRate							NUMERIC(19,4)	NULL		   --MultiCCY change --
		,DoesNotErodeReserves                                   bit             null
		,ActualOriginalAmountType								varchar(255)    NULL
		,BeazleyShare											NUMERIC(19,4)	NULL
		,IndemnityReserveInSettlementCCY						NUMERIC(19,4)	NULL
		,FeesReserveInSettlementCCY								NUMERIC(19,4)	NULL
		,DefenceReserveInSettlementCCY							NUMERIC(19,4)	NULL
		,CheckDetailsDateOfService								datetime2(7)	NULL
		,CheckDetailsDueDate									datetime2(7)	NULL
		,CheckDetailsNetAmount									nvarchar(255)	NULL
		,CheckDetailsPaymentMethod								nvarchar(255)	NULL
		,CheckDetailsScheduledSendDate							datetime2(7)	NULL
		,CheckDetailsStatus										nvarchar(255)	NULL
		,PaymentId												nvarchar(255)	NULL
		,PaymentType                                            varchar(255)    NULL
		,SignedLine												numeric(20, 4)	NULL
		,TransactionTrackingStatus								nvarchar(255)	NULL
		,TransferStatus											nvarchar(255)	NULL
		,ActualMovementCreationDate                             datetime2(7)    NULL
		,InvoiceIssueDate                                       datetime2(7)    NULL
		,InvoiceReceivedDate                                    datetime2(7)    NULL
		,BureauShare                                            numeric(20, 4)  NULL
		,SettlementDate							                DATETIME2 (7)   NULL
		,HashbytesId											BIGINT			NULL		
	)			

	TRUNCATE TABLE #ClaimMovement
	
	INSERT INTO #ClaimMovement
	(
		[SequenceNumber]
		,[MovementReferenceSourceId]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]
		,[ToDateOutstandingFeesInOriginalCCY]
		,[ToDateOutstandingDefenceInOriginalCCY]
		,[MovementPaidIndemnityInOriginalCCY]
		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]
		,[ToDateOutstandingIndemnityInSettlementCCY]
		,[ToDateOutstandingFeesInSettlementCCY]
		,[ToDateOutstandingDefenceInSettlementCCY]
		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,MovementOutstandingIndemnityInOriginalCCY	
		,MovementOutstandingFeesInOriginalCCY		
		,MovementOutstandingDefenceInOriginalCCY	
		,MovementOutstandingIndemnityInSettlementCCY
		,MovementOutstandingFeesInSettlementCCY		
		,MovementOutstandingDefenceInSettlementCCY	
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[MovementNarrativeFlag]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		--,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]

		,[ClaimTeamExaminer]
		,[MovementCreationDate]
		,[CCClaimCostCategory]
		,[AuditCreateDateTime]               
		,ActualOriginalCurrency 								  --MultiCCY change --
		,ActualOriginalAmount 									  --MultiCCY change --
		,EstimatedSettlementAmount 								  --MultiCCY change --
		,ActualToSettlementExchangeRate							  --MultiCCY change --
		,DoesNotErodeReserves
		,ActualOriginalAmountType
		,BeazleyShare
		,IndemnityReserveInSettlementCCY	
		,FeesReserveInSettlementCCY			
		,DefenceReserveInSettlementCCY	
		,CheckDetailsDateOfService
		,CheckDetailsDueDate
		,CheckDetailsNetAmount
		,CheckDetailsPaymentMethod
		,CheckDetailsScheduledSendDate
		,CheckDetailsStatus
		,PaymentId
		,PaymentType
		,SignedLine
		,TransactionTrackingStatus
		,TransferStatus		
		,[MovementNetPaymentAmountInOriginalCCY]
		,[MovementNetPaymentAmountInSettlementCCY]
		,[MovementTaxAmountInOriginalCCY]
		,[MovementTaxAmountInSettlementCCY]
		,TaxApplicable
		,TaxPercent
		,ActualMovementCreationDate
		,InvoiceIssueDate
		,InvoiceReceivedDate
		,BureauShare
		,SettlementDate
		,HashbytesId
	)
	SELECT				
	 		 [SequenceNumber]								 	  =	 [SequenceNumber]	
			,[MovementReferenceSourceid]                          =  [MovementReferenceSourceid]							
			,[MovementReference]							 	  =	 [MovementReference]							
			,[MovementGroupId]									  = DENSE_RANK() OVER 
																		(ORDER BY 
																			T.FK_ClaimExposure
																			,T.FK_SettlementCurrency
																		)  
																					
			,[MovementGroupSequenceId]						   = ROW_NUMBER() OVER
																	(PARTITION BY 
																			T.FK_ClaimExposure
																			,T.FK_SettlementCurrency
																	ORDER BY  
																			CASE 
																				WHEN MovementType = 'SCM' THEN MovementDate	--isnull([MovementPeriod], movementdate)
																			END	
																			-- Specifically for claims which have YA, YB and YC movements, YC needs to come 
																			-- before YB. This only applies to multi-original currency claims, where these movements
																			-- indicate the change from the original CCY to EUR
																			,CASE 
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YA%' THEN 1
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YC%' THEN 2
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YB%' THEN 3
																			END
																			,T.SequenceNumber
																			,T.MovementReference
																			,T.FK_OriginalCurrency
																		) 
																								
			,[SequenceNumberOrderId]							  =  0 -- updated below (dependant on MovementSequenceNumberId)					
			,[OutstandingOriginalCCYToSettlementCCYRate]	 	  =	 [OutstandingOriginalCCYToSettlementCCYRate]	
			,[PaidOriginalCCYToSettlementCCYRate]			 	  =	 [PaidOriginalCCYToSettlementCCYRate]			
			,[MovementDate]									 	  =	 ISNULL([MovementDate], '1/1/1753')									
			,[MovementPeriod]								 	  =	 isnull([MovementPeriod]						, movementdate)
			,[ToDateOutstandingIndemnityInOriginalCCY]		 	  =	 ISNULL([ToDateOutstandingIndemnityInOriginalCCY]		,0)
			,[ToDateOutstandingFeesInOriginalCCY]			 	  =	 ISNULL([ToDateOutstandingFeesInOriginalCCY]			,0)
			,[ToDateOutstandingDefenceInOriginalCCY]		 	  =	 ISNULL([ToDateOutstandingDefenceInOriginalCCY]			,0)
			,[MovementPaidIndemnityInOriginalCCY]			 	  =	 ISNULL([MovementPaidIndemnityInOriginalCCY]			,0)
			,[MovementPaidFeesInOriginalCCY]				 	  =	 ISNULL([MovementPaidFeesInOriginalCCY]					,0)
			,[MovementPaidDefenceInOriginalCCY]				 	  =	 ISNULL([MovementPaidDefenceInOriginalCCY]				,0)
			,[ToDateOutstandingIndemnityInSettlementCCY]	 	  =	 ISNULL([ToDateOutstandingIndemnityInSettlementCCY]		,0) * [CalculatedSettlementToUSDRate]
			,[ToDateOutstandingFeesInSettlementCCY]			 	  =	 ISNULL([ToDateOutstandingFeesInSettlementCCY]			,0) * [CalculatedSettlementToUSDRate]
			,[ToDateOutstandingDefenceInSettlementCCY]		 	  =	 ISNULL([ToDateOutstandingDefenceInSettlementCCY]		,0) * [CalculatedSettlementToUSDRate]
			,[MovementPaidIndemnityInSettlementCCY]			 	  =	 ISNULL([MovementPaidIndemnityInSettlementCCY]			,0) * [CalculatedSettlementToUSDRate]
			,[MovementPaidFeesInSettlementCCY]				 	  =	 ISNULL([MovementPaidFeesInSettlementCCY]				,0) * [CalculatedSettlementToUSDRate]
			,[MovementPaidDefenceInSettlementCCY]			 	  =	 ISNULL([MovementPaidDefenceInSettlementCCY]			,0) * [CalculatedSettlementToUSDRate]
			,[MovementType]									 	  =	 ISNULL([MovementType]	,'')
			,MovementOutstandingIndemnityInOriginalCCY			  =	 ISNULL(MovementOutstandingIndemnityInOriginalCCY		,0)
			,MovementOutstandingFeesInOriginalCCY				  =	 ISNULL(MovementOutstandingFeesInOriginalCCY			,0)
			,MovementOutstandingDefenceInOriginalCCY			  =	 ISNULL(MovementOutstandingDefenceInOriginalCCY			,0)
			,MovementOutstandingIndemnityInSettlementCCY		  =	 ISNULL(MovementOutstandingIndemnityInSettlementCCY		,0) * [CalculatedSettlementToUSDRate]
			,MovementOutstandingFeesInSettlementCCY				  =	 ISNULL(MovementOutstandingFeesInSettlementCCY			,0) * [CalculatedSettlementToUSDRate]
			,MovementOutstandingDefenceInSettlementCCY		  	  =  ISNULL(MovementOutstandingDefenceInSettlementCCY		,0) * [CalculatedSettlementToUSDRate]
			,[MovementApprovalUser]							 	  =	 [MovementApprovalUser]							
			,[MovementCreateUser]							 	  =	 [MovementCreateUser]							
			,[MovementNarrative]							 	  =	 [MovementNarrative]							
			,[MovementNarrativeFlag]							  = CASE  WHEN UPPER(MovementNarrative)		LIKE 'RATE OF EXCHANGE REVISION AT%'
																	         OR UPPER(MovementNarrative)	LIKE 'EURO TRANSITION CLAIM CONVERSION MOVEMENT%'
																	         OR UPPER(MovementNarrative)	LIKE 'RE-DENOMINATION MOVEMENT CREATED BY ESL%'
																	         OR UPPER(MovementNarrative)    = 'N/A'
																	         OR UPPER(MovementNarrative)    = 'DUMMY MOVEMENT' 
																	 THEN 1 ELSE 0 END		
            ,[ChequeIssueDate]								 	  =	 [ChequeIssueDate]								
			,[ChequeNumber]									 	  =	 [ChequeNumber]									
			,[InvoiceNumber]								 	  =	 [InvoiceNumber]								
			,[ChequePayee]									 	  =	 [ChequePayee]									
			,[TBAIndicator]									 	  =	 [TBAIndicator]									
			,[TBAFlag]										 	  =	 [TBAFlag]										
			,[FeesOnlyEntry]									  =	 [FeesOnlyEntry]								
			,[LPSOSigningDate]								 	  =	 [LPSOSigningDate]								
			,[LPSOSigningNumber]							 	  =	 [LPSOSigningNumber]							
	
			,[XChangingChecker]								 	  =	 [XChangingChecker]				
			,[PrimaryExaminerOrCreateUserId]				 	  =	 [PrimaryExaminerOrCreateUserId]
			,[ExposureStatusCode]							 	  =	 [ExposureStatusCode]			
			,[RecoveryCategory]								 	  =	 [RecoveryCategory]				
			,[FK_ClaimCostCategory]							 	  =	 [FK_ClaimCostCategory]			
			,[FK_ClaimExposure]								 	  =	 [FK_ClaimExposure]				
			,[FK_SettlementCurrency]						 	  =	 [FK_SettlementCurrency]		
			,[FK_OriginalCurrency]							 	  =	 [FK_OriginalCurrency]			
			,[FK_LocalCurrency]								 	  =	 [FK_LocalCurrency]				
			,[FK_DevelopmentPeriod]							 	  =	 [FK_DevelopmentPeriod]			
			,[OriginalCCYToLocalCCYRate]						  =	 [OriginalCCYToLocalCCYRate]	
			,[ClaimTeamExaminer]							 	  =	 [ClaimTeamExaminer]			
			,[MovementCreationDate]								  =	 [MovementCreationDate]	
			,[CCClaimCostCategory]								  =  [ClaimCostCategory]	
			,[AuditCreateDateTime]								  =	 [AuditCreateDateTime]	            
			,ActualOriginalCurrency 							  =	 ActualOriginalCurrency 			   --MultiCCY change --
			,ActualOriginalAmount 								  =	 ActualOriginalAmount				   --MultiCCY change --
			,EstimatedSettlementAmount 							  =	 EstimatedSettlementAmount 			   --MultiCCY change --
			,ActualToSettlementExchangeRate						  =	 ActualToSettlementExchangeRate	   --MultiCCY change --
			,DoesNotErodeReserves                                 =  ISNULL(t.DoesNotErodeReserves, 0)
			,ActualOriginalAmountType							  =  ActualOriginalAmountType
			,BeazleyShare										  =  SignedLine
			,IndemnityReserveInSettlementCCY					  =  IndemnityReserveInSettlementCCY	
			,FeesReserveInSettlementCCY							  =  FeesReserveInSettlementCCY			
			,DefenceReserveInSettlementCCY						  =  DefenceReserveInSettlementCCY	
			,CheckDetailsDateOfService							  =  CheckDetailsDateOfService
			,CheckDetailsDueDate								  =  CheckDetailsDueDate
			,CheckDetailsNetAmount								  =  CheckDetailsNetAmount
			,CheckDetailsPaymentMethod							  =  CheckDetailsPaymentMethod
			,CheckDetailsScheduledSendDate						  =  CheckDetailsScheduledSendDate
			,CheckDetailsStatus									  =  CheckDetailsStatus
			,PaymentId											  =  PaymentId
			,PaymentType										  =  PaymentType
			,SignedLine											  =  SignedLine
			,TransactionTrackingStatus							  =  TransactionTrackingStatus
			,TransferStatus										  =  TransferStatus		
			,[MovementNetPaymentAmountInOriginalCCY]              =	 ISNULL([MovementNetPaymentAmountInOriginalCCY]			,0)
			,[MovementNetPaymentAmountInSettlementCCY]			  =	 ISNULL([MovementNetPaymentAmountInSettlementCCY]		,0)
			,[MovementTaxAmountInOriginalCCY]                     =	 ISNULL([MovementTaxAmountInOriginalCCY]		,0)
			,[MovementTaxAmountInSettlementCCY]					  =	 ISNULL([MovementTaxAmountInSettlementCCY]		,0)
            ,TaxApplicable                                        =  TaxApplicable
	        ,TaxPercent                                           =  ISNULL(TaxPercent                              ,0)																		 
            ,ActualMovementCreationDate                           =  ActualMovementCreationDate
			,InvoiceIssueDate                                     =  InvoiceIssueDate
			,InvoiceReceivedDate                                  =  InvoiceReceivedDate
			,BureauShare                                          =  BureauShare
			,SettlementDate										  =  SettlementDate
            ,HashbytesId										  =	 HashbytesId	

	FROM
	(						 
		SELECT
			 [SourceSystem]									   = cm.sourcesystem
			,[SequenceNumber]								   =  ROW_NUMBER() OVER (PARTITION BY [PK_ClaimExposure] order by isnull([MovementPeriod], movementdate), MovementDate)      --   cme.SequenceNumber						
			,[CalculatedSettlementToUSDRate]				   = CASE WHEN cm.SettlementCurrency IN ('EUR','USD','CAD','GBP') THEN 1 
			                                                          WHEN ISNULL(OriginalCCYtoGroupCCYRate, 0) = 0 THEN 1
																      ELSE (SELECT @ExchangeRateUSDtoGBP/ExchangeRate       --cm.OriginalCCYtoGroupCCYRate
																	        FROM Utility.CurrencyRate 
																	        WHERE ratetype = 'current' AND currency = cm.SettlementCurrency)																 	
																 END				
			,[MovementReferenceSourceId]                       = cm.MovementReferenceSourceId		
			,[MovementReference]							   = CASE 
																	WHEN ISNULL(cee.SCMReference, '') = '' THEN ISNULL(cm.MovementType, '') 
																	ELSE cm.MovementReferenceSourceId
																END-- according to  V5 code - in order to pass regression						

			,[OutstandingOriginalCCYToSettlementCCYRate]	   = CASE 	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.[OutstandingOriginalCCYToSettlementCCYRate], 1)		
																		ELSE 1
																	END -- MultiCCY change -- 
			,[PaidOriginalCCYToSettlementCCYRate]			   = CASE 	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.PaidOriginalCCYToSettlementCCYRate, 1)		
																		ELSE 1
																	END -- MultiCCY change -- 
			,[MovementDate]									   = cm.MovementDate								
			,[MovementPeriod]								   = cm.MovementPeriod							
			
			,[ToDateOutstandingIndemnityInOriginalCCY]		   =	CASE 	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)--MultiCCY change -- ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY  ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			,[ToDateOutstandingFeesInOriginalCCY]			   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY	 , 0)--MultiCCY change --ISNULL(cm.MovementReserveFeesAmountInOriginalCCY	    ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			,[ToDateOutstandingDefenceInOriginalCCY]		   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY  , 0)--MultiCCY change --ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			
			,[MovementPaidIndemnityInOriginalCCY]			   =  CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY  , 0)--MultiCCY change --ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)	
																		--WHEN MovementType = 'Recovery' THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY  , 0) * -1  -- added for Recovery to be as in V5
																		ELSE ISNULL(cm.ToDatePaidIndemnityInReservingCCY, 0)
																	END	--MultiCCY change --	ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)     
			,[MovementPaidFeesInOriginalCCY]				   =  CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementPaidFeesInOriginalCCY  , 0)--MultiCCY change --ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)	
																		ELSE ISNULL(cm.ToDatePaidFeesInReservingCCY	 , 0)	--MultiCCY change --	ISNULL(cm.MovementPaidFeesInOriginalCCY     , 0)     
																	END
            ,[MovementPaidDefenceInOriginalCCY]				   =  CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.MovementPaidDefenceInOriginalCCY  , 0)--MultiCCY change --ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)	
																		ELSE ISNULL(cm.ToDatePaidDefenceInReservingCCY  , 0)	--MultiCCY change --	ISNULL(cm.MovementPaidDefenceInOriginalCCY  ,	0) 
																	END										  
			,[ToDateOutstandingIndemnityInSettlementCCY]	   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)	 
																		ELSE 0 
																	END --0-- updated below
			,[ToDateOutstandingFeesInSettlementCCY]			   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)	 
																		ELSE 0 
																	END --0-- updated below
			,[ToDateOutstandingDefenceInSettlementCCY]		   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)	 
																		ELSE 0  
																	END --0-- updated below
			
			,[MovementPaidIndemnityInSettlementCCY]			   = ISNULL(cm.ToDatePaidIndemnityInReservingCCY, 0)			-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidIndemnityInSettlementCCY]
			,[MovementPaidFeesInSettlementCCY]				   = ISNULL(cm.ToDatePaidFeesInReservingCCY	 , 0)				-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidFeesInSettlementCCY]
			,[MovementPaidDefenceInSettlementCCY]			   = ISNULL(cm.ToDatePaidDefenceInReservingCCY  , 0)			-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidDefenceInSettlementCCY]
			,[MovementType]									   = ISNULL(cm.MovementType, '')
						
															    
			,MovementOutstandingIndemnityInOriginalCCY		   = ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)		--MultiCCY change -- ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY  ,0)
			,MovementOutstandingFeesInOriginalCCY			   = ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)		--MultiCCY change -- ISNULL(cm.MovementReserveFeesAmountInOriginalCCY	    ,0)
			,MovementOutstandingDefenceInOriginalCCY		   = ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)		--MultiCCY change -- ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)

			,MovementOutstandingIndemnityInSettlementCCY 	   =  ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)	-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingIndemnityInSettlementCCY]
			,MovementOutstandingFeesInSettlementCCY			   =  ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)		-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingFeesInSettlementCCY]
			,MovementOutstandingDefenceInSettlementCCY		   =  ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)	-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingDefenceInSettlementCCY]
						
			,[MovementApprovalUser]							   = cme.MovementApprovalUser						
			,[MovementCreateUser]							   = cme.MovementCreateUser						
			,[MovementNarrative]							   = cm.MovementNarrative						
			,[ChequeIssueDate]								   = cme.ChequeIssueDate							
			,[ChequeNumber]									   = cme.ChequeNumber								
			,[InvoiceNumber]								   = cme.InvoiceNumber							
			,[ChequePayee]									   = cme.ChequePayee								
			,[TBAIndicator]									   = cm.TBAIndicator								
			,[TBAFlag]										   = CASE WHEN cm.TBAIndicator IS NOT NULL THEN 1 ELSE 0 END						
			,[FeesOnlyEntry]								   = CASE 
																	  WHEN cm.MovementNarrative LIKE '%fee%only%entry%' THEN 1
																	  ELSE 0
																 END    						
			,[LPSOSigningDate]								   = NULL -- marked as REMOVED -- cme.LPSOSigningDate		-- getdate()--					
			,[LPSOSigningNumber]							   = NULL -- marked as REMOVED -- cme.LPSOSigningNumber						
			,[UseForLastMovementBanding]					   = NULL -- updated below (dependant on MovementGroupId and MovementSequenceNumberId)
			,[XChangingChecker]								   = NULL -- marked as REMOVED -- cme.XChangingChecker							
			,[PrimaryExaminerOrCreateUserId]				   = cee.PrimaryExaminerClaimCenterId		
			,[ExposureStatusCode]							   = CASE 
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Closed' THEN 'C'
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Open'   THEN 'O'
																	WHEN (ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Closed' 
																			AND ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Open') THEN 'C'
																 END -- ce.ExposureStatusCode						
			,[RecoveryCategory]								   = cme.RecoveryCategory							
			,[FK_ClaimCostCategory]							   = ISNULL(ccc.PK_ClaimCostCategory, -891617830217682624)				
			,[FK_ClaimExposure]								   = ISNULL(oce.PK_ClaimExposure, 0)
			,[FK_SettlementCurrency]						   = ISNULL(sc.PK_SettlementCurrency, (SELECT PK_SettlementCurrency FROM ODS.SettlementCurrency where CurrencyCode = 'USD'))			
			,[FK_OriginalCurrency]							   = ISNULL(oc.PK_OriginalCurrency, (SELECT PK_OriginalCurrency FROM ODS.OriginalCurrency where CurrencyCode = 'USD'))			
			,[FK_LocalCurrency]								   = CASE 
																	WHEN cm.MovementType = 'SCM' THEN 0
																	ELSE ISNULL(lc.PK_LocalCurrency, 0) 		 -- after regression of OriginalCCYToLocalCCYRate - Singapore financial team uses this		
																 END
			,[FK_DevelopmentPeriod]							   = ISNULL(dp.PK_DevelopmentPeriod, 0)							
			,[OriginalCCYToLocalCCYRate]					   = ISNULL(cm.OriginalCCYtoGroupCCYRate , 1) -- after regression of OriginalCCYToLocalCCYRate - Singapore financial team uses this --MultiCCY change -- ISNULL(cm.PaidOriginalCCYToSettlementCCYRate, 1) ---cem.[Outbound].[DiaryEntry]   --- to be provided  by CC V9 team !!!
			,[ClaimTeamExaminer]							   = NULL -- marked as REMOVED -- cee.ClaimTeamExaminer						
			,[MovementCreationDate]							   = ISNULL(cme.TransactionCreatedOn	, cm.MovementDate)--cm.MovementDate	
			,[ClaimCostCategory]							   = cme.ClaimCostCategory	
			,[AuditCreateDateTime]							   = cm.[AuditCreateDateTime]
			,ActualOriginalCurrency 						   = cm.OriginalCurrency    --MultiCCY change 
			,ActualOriginalAmount 							   = CASE					--MultiCCY change 
																	WHEN ISNULL(cm.MovementType, '') = 'Reserve' THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0		THEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0			THEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0		THEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0)		
																														ELSE 0
																													END
																	WHEN ISNULL(cm.MovementType, '') = 'Payment'  THEN
																													CASE 
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0				THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0					THEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0				THEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0)		
																														ELSE 0
																													END
																	WHEN ISNULL(cm.MovementType, '') = 'Recovery' THEN
																													CASE 
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0				THEN -ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0					THEN -ISNULL(cm.MovementPaidFeesInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0				THEN -ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0)		
																														ELSE 0
																													END
																	WHEN ISNULL(cm.MovementType, '') = 'SCM'	THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0		THEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0			THEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0		THEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0				THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0					THEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0				THEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0)
																														ELSE 0
																													END										
																	ELSE 0
																END													
																													
			,EstimatedSettlementAmount 						   = cm.EstimatedSettlementAmount		  --MultiCCY change -- 
			,ActualToSettlementExchangeRate					   = cm.ActualToSettlementExchangeRate	  --MultiCCY change -- 
			,DoesNotErodeReserves                              = CASE 
																	WHEN cm.Movementtype = 'SCM' THEN 1 
																	ELSE cm.DoesNotErodeReserves
																END
			,ActualOriginalAmountType						   = CASE 
																	WHEN ISNULL(cm.MovementType, '') = 'SCM'	THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0		THEN 'Indemnity-Reserve(SCM)'		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0			THEN 'Fees-Reserve(SCM)'	
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0		THEN 'Defence-Reserve(SCM)'		
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0				THEN 'Indemnity-Payment(SCM)'
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0					THEN 'Fees-Payment(SCM)'
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0				THEN 'Defence-Payment(SCM)'
																														ELSE NULL
																													END		
																	WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0 THEN 'Indemnity'
																	WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0		THEN 'Fees'	
																	WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0	THEN 'Defence'		
																	 
																	WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0			THEN 'Indemnity'
																	WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0				THEN 'Fees'	
																	WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0			THEN 'Defence'	
																	ELSE NULL
																END		
			,SignedLine										   = cme.SignedLine		
			,IndemnityReserveInSettlementCCY				   = ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)	
			,FeesReserveInSettlementCCY						   = ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)				
			,DefenceReserveInSettlementCCY					   = ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)						
			,CheckDetailsDateOfService						   = cme.CheckDetailsDateOfService
			,CheckDetailsDueDate							   = cme.CheckDetailsDueDate
			,CheckDetailsNetAmount							   = cme.CheckDetailsNetAmount
			,CheckDetailsPaymentMethod						   = cme.CheckDetailsPaymentMethod
			,CheckDetailsScheduledSendDate					   = cme.CheckDetailsScheduledSendDate
			,CheckDetailsStatus								   = cme.CheckDetailsStatus
			,PaymentId										   = cme.PaymentId
			,PaymentType                                       = cme.PaymentType
			--,SignedLine										  =  cme.SignedLine
			,TransactionTrackingStatus						   = cme.TransactionTrackingStatus
			,TransferStatus									   = cme.TransferStatus		
			,[MovementNetPaymentAmountInOriginalCCY]		   = cm.NetPaymentAmountInOriginalCCY
            ,[MovementNetPaymentAmountInSettlementCCY]         = cm.NetPaymentAmountInSettlementCCY
            ,[MovementTaxAmountInOriginalCCY]                  = cm.TaxAmountInOriginalCCY
            ,[MovementTaxAmountInSettlementCCY]                = cm.TaxAmountInSettlementCCY	
            ,TaxApplicable                                     = cm.TaxApplicable
		    ,TaxPercent                                        = cm.TaxPercent
			,ActualMovementCreationDate                        = NULL
			,InvoiceIssueDate                                  = cme.InvoiceIssueDate
			,InvoiceReceivedDate                               = cme.InvoiceReceivedDate
			,BureauShare                                       = ISNULL(cme.BureauShare, 100)
			,SettlementDate                                    = cme.SettlementDate
			,HashbytesId									   = cm.HashbytesId


		FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement cm 

		INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovementExtension cme
		ON	    cm.[SourceSystem]					= cme.[SourceSystem]
			AND cm.[ClaimExposureSourceId]			= cme.[ClaimExposureSourceId]		
			--AND cm.[IsActive]						= cme.[IsActive]			
			AND cm.[MovementReferenceSourceId]		= cme.[MovementReferenceSourceId]	
			AND cm.[SequenceNumber]					= cme.[SequenceNumber]				
			AND cm.[OriginalCurrency]				= cme.[OriginalCurrency]			
			AND cm.[SettlementCurrency]				= cme.[SettlementCurrency]			

		INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce
		ON	    ce.[SourceSystem]					= cme.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cme.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cme.[IsActive]			

		LEFT JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee
		ON	    ce.[SourceSystem]					= cee.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cee.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cee.[IsActive]	
		
		INNER JOIN 
			(
				select 
					ExposureReference --= OriginatingBureau + LEFT(ExposureReference, charindex('-', ExposureReference) - 1)
					,OriginatingBureau
					,ExposureSequenceId
					,PK_ClaimExposure
					,FK_ClaimTeamExaminer
					,FK_YOA
				from ODS.ClaimExposure
				) oce 
		ON oce.ExposureReference = ce.ClaimExposureSourceId
		AND oce.OriginatingBureau = ce.OriginatingBureau

		LEFT JOIN ODS.SettlementCurrency sc 
		ON cm.SettlementCurrency = sc.CurrencyCode

		
		LEFT JOIN ODS.OriginalCurrency oc 
		--ON cm.OriginalCurrency = oc.CurrencyCode
		ON ((cm.OriginalCurrency = oc.CurrencyCode and cm.MovementType = 'SCM') OR (cm.SettlementCurrency = oc.CurrencyCode and cm.MovementType <> 'SCM'))--MultiCCY change --

		LEFT JOIN ODS.LocalCurrency lc 
		ON cm.SettlementCurrency = lc.CurrencyCode
		
		
		LEFT JOIN ODS.ClaimCostCategory ccc 
		ON cme.ClaimCostCategory = ccc.CCCostCategoryName
		
		LEFT JOIN ODS.YOA yoa 
		ON oce.FK_YOA = yoa.PK_YOA

		LEFT OUTER JOIN ODS.DevelopmentPeriod dp 
		ON DATEDIFF(MM, yoa.FirstDate, cm.MovementPeriod) + 1 = dp.DevelopmentMonth

		WHERE cm.SourceSystem = 'ClaimCenter'
			--and cm.IsActive = 1
			and 
				(
					---All SCM transactions go  to ODS
					MovementType = 'SCM'    
					or 
					-- All Non-SCM transactions from Migration (TransferStatus = 'Migration') and only completed ones from online (have TransferStatus = 'Transaction Complete')
					MovementType <> 'SCM' and ISNULL(TransferStatus, '') in ('Migration', 'Transaction Complete') 
						 
				)
             
		UNION ALL
		
			SELECT
			--ce.ClaimExposureSourceId,
			 [SourceSystem]									   = ce.sourcesystem
			,[SequenceNumber]								   = 0 		
			,[CalculatedSettlementToUSDRate]                   = 1
			,[MovementReferenceSourceId]                       = cm.MovementReferenceSourceId
			,[MovementReference]							   = 'DUMMY MOVEMENT' 	
			,[OutstandingOriginalCCYToSettlementCCYRate]	   = 1
			,[PaidOriginalCCYToSettlementCCYRate]			   = 1	
			,[MovementDate]									   = ce.ExposureOpenedDate								
			,[MovementPeriod]								   = CASE 
																	WHEN ap.FK_accountingcalendar = 0 THEN DATEADD(day, 1-day(ap.PeriodEnd), ap.PeriodEnd) 
																	ELSE ISNULL(CAST('01 ' + ap.AccountingPeriodName AS datetime), ce.ExposureOpenedDate) 
																 END--1st of accounting period, as long as it exists in the accounting period table	
			,[ToDateOutstandingIndemnityInOriginalCCY]		   = NULL
			,[ToDateOutstandingFeesInOriginalCCY]			   = NULL    
			,[ToDateOutstandingDefenceInOriginalCCY]		   = NULL	         		
			,[MovementPaidIndemnityInOriginalCCY]			   = 0
			,[MovementPaidFeesInOriginalCCY]				   = 0	
			,[MovementPaidDefenceInOriginalCCY]				   = 0				  
			,[ToDateOutstandingIndemnityInSettlementCCY]	   = 0-- updated below
			,[ToDateOutstandingFeesInSettlementCCY]			   = 0-- updated below
			,[ToDateOutstandingDefenceInSettlementCCY]		   = 0-- updated below		
			,[MovementPaidIndemnityInSettlementCCY]			   = 0 -- seem to be updated in post processing cme.MovementPaidIndemnityInSettlementCCY		
			,[MovementPaidFeesInSettlementCCY]				   = 0 -- seem to be updated in post processing cme.MovementPaidFeesInSettlementCCY			
			,[MovementPaidDefenceInSettlementCCY]			   = 0 -- seem to be updated in post processing cme.MovementPaidDefenceInSettlementCCY		
			,[MovementType]									   = 'N/A'																					    
			,MovementOutstandingIndemnityInOriginalCCY		   = 0
			,MovementOutstandingFeesInOriginalCCY			   = 0
			,MovementOutstandingDefenceInOriginalCCY		   = 0
			,MovementOutstandingIndemnityInSettlementCCY 	   = 0
			,MovementOutstandingFeesInSettlementCCY			   = 0
			,MovementOutstandingDefenceInSettlementCCY		   = 0						
			,[MovementApprovalUser]							   = NULL					
			,[MovementCreateUser]							   = NULL				
			,[MovementNarrative]							   = 'DUMMY MOVEMENT'						
			,[ChequeIssueDate]								   = NULL							
			,[ChequeNumber]									   = NULL							
			,[InvoiceNumber]								   = NULL						
			,[ChequePayee]									   = NULL							
			,[TBAIndicator]									   = NULL 							
			,[TBAFlag]										   = 0					
			,[FeesOnlyEntry]								   = 0    						
			,[LPSOSigningDate]								   = NULL 			
			,[LPSOSigningNumber]							   = NULL 
			,[UseForLastMovementBanding]					   = NULL -- updated below (dependant on MovementGroupId and MovementSequenceNumberId)
			,[XChangingChecker]								   = NULL						
			,[PrimaryExaminerOrCreateUserId]				   = NULL	
			,[ExposureStatusCode]							   = CASE 
																	WHEN Utility.udf_ProcessString(ce.ExposureStatus,0) = 'Closed' THEN 'C'
																	WHEN Utility.udf_ProcessString(ce.ExposureStatus,0) = 'Open'   THEN 'O'
																	WHEN (ISNULL(Utility.udf_ProcessString(ce.ExposureStatus,0), '') <> 'Closed' 
																			AND ISNULL(Utility.udf_ProcessString(ce.ExposureStatus,0), '') <> 'Open') THEN 'C'
																 END					
			,[RecoveryCategory]								   = NULL							
			,[FK_ClaimCostCategory]							   = ISNULL(ccc.PK_ClaimCostCategory, -891617830217682624)				
			,[FK_ClaimExposure]								   = ISNULL(oce.PK_ClaimExposure, 0)
			,[FK_SettlementCurrency]						   = ISNULL(sc.PK_SettlementCurrency, (SELECT PK_SettlementCurrency FROM ODS.SettlementCurrency where CurrencyCode = 'USD'))					
			,[FK_OriginalCurrency]							   = ISNULL(oc.PK_OriginalCurrency, (SELECT PK_OriginalCurrency FROM ODS.OriginalCurrency where CurrencyCode = 'USD'))
			,[FK_LocalCurrency]								   = ISNULL(lc.PK_LocalCurrency,2) 				
			,[FK_DevelopmentPeriod]							   = ISNULL(dp.PK_DevelopmentPeriod, 0)							
			,[OriginalCCYToLocalCCYRate]					   = ISNULL(cm.OriginalCCYtoGroupCCYRate , 1)
			,[ClaimTeamExaminer]							   = NULL				
			,[MovementCreationDate]							   = ce.ExposureOpenedDate	
			,[ClaimCostCategory]							   = 'NO FINANCIALS'
			,[AuditCreateDateTime]							   = ISNULL(cm.[AuditCreateDateTime], ce.[AuditCreateDateTime])
			,ActualOriginalCurrency 						   = cm.OriginalCurrency    --MultiCCY change -- 
			,ActualOriginalAmount 							   = 0						--MultiCCY change -- 						
			,EstimatedSettlementAmount 						   = 0 --MultiCCY change -- cm.EstimatedSettlementAmount
			,ActualToSettlementExchangeRate					   = 1 --MultiCCY change -- cm.ActualToSettlementExchangeRate
			,DoesNotErodeReserves                              = 1
			,ActualOriginalAmountType						   = NULL
			,SignedLine										   = ce.Signed
			,IndemnityReserveInSettlementCCY				   = NULL
			,FeesReserveInSettlementCCY						   = NULL
			,DefenceReserveInSettlementCCY					   = NULL
			,CheckDetailsDateOfService						   = NULL
			,CheckDetailsDueDate							   = NULL
			,CheckDetailsNetAmount							   = NULL
			,CheckDetailsPaymentMethod						   = NULL
			,CheckDetailsScheduledSendDate					   = NULL
			,CheckDetailsStatus								   = NULL
			,PaymentId										   = NULL
			,PaymentType                                       = NULL
			--,SignedLine										   = NULL
			,TransactionTrackingStatus						   = NULL
			,TransferStatus									   = NULL
			,[MovementNetPaymentAmountInOriginalCCY]           = 0
            ,[MovementNetPaymentAmountInSettlementCCY]         = 0
            ,[MovementTaxAmountInOriginalCCY]                  = 0
            ,[MovementTaxAmountInSettlementCCY]                = 0
            ,TaxApplicable                                     = NULL
		    ,TaxPercent                                        = 0															
            ,ActualMovementCreationDate                        = NULL
			,InvoiceIssueDate                                  = NULL
			,InvoiceReceivedDate                               = NULL
			,BureauShare                                       = 100
			,SettlementDate									   = NULL
  		    ,HashbytesId									   = cm.HashbytesId

		FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce

		--INNER JOIN  BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension cee
		--ON	    ce.[SourceSystem]					= cee.[SourceSystem]
		--	AND ce.[ClaimExposureSourceId]			= cee.[ClaimExposureSourceId]		
		--	AND ce.[IsActive]						= cee.[IsActive]	
		
		LEFT JOIN 
			(
				SELECT
					[SourceSystem]
					,[ClaimExposureSourceId]	
					,[IsActive]		
					,OriginalCCYtoGroupCCYRate
					,[AuditCreateDateTime]
					,[MovementReferenceSourceId]	
					,[SequenceNumber]				
					,[OriginalCurrency]			
					,[SettlementCurrency]			
					,MovementPeriod
					,MovementDate
					,MovementType
					,HashbytesId
					,RowId = ROW_NUMBER() OVER (PARTITION BY [ClaimExposureSourceId] ORDER BY SourceSystemEventDatetime DESC)
								-- for exposures that have movements some information should be taken from  the first movement as in V9 are not pushed (marked as REMOVED)
								-- this is because the old condition to filter the first movement was WHERE cm.SequenceNumber = 1
								-- there are cases for which there are more than 1 line with SequenceNumber 1 which breaks ODS
				FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement 
				where SourceSystem = 'ClaimCenter'
					--AND IsActive = 1
					AND SequenceNumber= 1
			) cm 
		ON	    ce.[SourceSystem]					= cm.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cm.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cm.[IsActive]			
			
		
		LEFT JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovementExtension cme
		ON	    cm.[SourceSystem]					= cme.[SourceSystem]
			AND cm.[ClaimExposureSourceId]			= cme.[ClaimExposureSourceId]		
			--AND cm.[IsActive]						= cme.[IsActive]			
			AND cm.[MovementReferenceSourceId]		= cme.[MovementReferenceSourceId]	
			AND cm.[SequenceNumber]					= cme.[SequenceNumber]				
			AND cm.[OriginalCurrency]				= cme.[OriginalCurrency]			
			AND cm.[SettlementCurrency]				= cme.[SettlementCurrency]

		INNER JOIN 
			(
				SELECT 
					ExposureReference --= OriginatingBureau + LEFT(ExposureReference, charindex('-', ExposureReference) - 1)
					,OriginatingBureau
					,ExposureSequenceId
					,PK_ClaimExposure
					,FK_ClaimTeamExaminer
					,FK_YOA
					,FK_Claim
					,SCMReference
				FROM ODS.ClaimExposure
				--where ExposureReference = 'BEAZL190701073315-01'
				) oce 
		ON oce.ExposureReference = ce.ClaimExposureSourceId
		AND oce.OriginatingBureau = ce.OriginatingBureau

		LEFT JOIN ODS.SettlementCurrency sc 
		ON cm.SettlementCurrency = sc.CurrencyCode

		
		LEFT JOIN ODS.OriginalCurrency oc 
		--ON cm.OriginalCurrency = oc.CurrencyCode
		ON cm.SettlementCurrency = oc.CurrencyCode  --MultiCCY change --
		

		LEFT JOIN ODS.LocalCurrency lc 
		ON cm.SettlementCurrency = lc.CurrencyCode
		
		
		LEFT JOIN ODS.ClaimCostCategory ccc 
		ON ccc.ClaimCostCategory = 'NO FINANCIALS'	
		
		LEFT JOIN	ODS.Claim c 
		ON	oce.FK_Claim = c.PK_Claim

		LEFT JOIN	ODS.AccountingCalendar ac 
		ON	c.FK_AccountingCalendar = ac.PK_AccountingCalendar

		LEFT OUTER JOIN	ODS.AccountingPeriod ap 
		ON	ac.PK_AccountingCalendar = ap.FK_AccountingCalendar	AND
			ce.ExposureOpenedDate >= ap.PeriodStart	AND 
			ce.ExposureOpenedDate < ap.PeriodEnd --Make sure we put the dummy movement into the correct accounting period

		LEFT JOIN ODS.YOA yoa 
		ON oce.FK_YOA = yoa.PK_YOA 


		LEFT OUTER JOIN ODS.DevelopmentPeriod dp 
		ON DATEDIFF(MM, yoa.FirstDate, cm.MovementPeriod) + 1 = dp.DevelopmentMonth

		WHERE ce.SourceSystem = 'ClaimCenter'
			--and ce.IsActive = 1
			AND ISNULL(oce.SCMReference, '') = ''		-- we create DUMMY MOVEMENTS only for Non - SCM	
			and ISNULL(RowId, 1) = 1			-- for exposures that have movements some information should be taken from  the first movement as in V9 are not pushed (marked as REMOVED)
												-- this is because the old condition to filter the first movement was WHERE cm.SequenceNumber = 1
												-- there are cases for which there are more than 1 line with SequenceNumber 1 which breaks ODS
			-- All Non-SCM transactions from Migration (TransferStatus = 'Migration') and only completed ones from online (have TransferStatus = 'Transaction Complete')
			and
			(
				cm.MovementDate IS NULL  --- only exposures without movements -> for which the code should create DUMMY MOVEMENT
				OR
				(  -- exposures with movements -> only completed transactions
					cm.MovementDate IS NOT NULL
					AND	MovementType <> 'SCM' 
				 --	AND ISNULL(TransferStatus, '') in ('Migration', 'Transaction Complete')  --> Commented for ticket: BI-4635
				)
			)
						 


	) AS T

	--CREATE NONCLUSTERED INDEX [IDX_ClaimMov1] ON #ClaimMovement ([MovementType])
 --   INCLUDE ([MovementGroupId],[MovementGroupSequenceId],[MovementNarrativeFlag],[MovementReference])

	--CREATE NONCLUSTERED INDEX [IDX_#ClaimMovement_002] ON #ClaimMovement ([FK_ClaimExposure],[MovementReferenceSourceId],[SequenceNumber])


	UPDATE claimmovcurr
	SET claimmovcurr.UseForLastMovementBanding = CASE
												-- For SCMs, if the movement reference hasn't changed, then we don't use the movement for calculating bandings
												WHEN claimmovcurr.MovementType = 'SCM' AND claimmovcurr.MovementReference = claimmovprev.MovementReference 
													THEN 0
												-- If the movement narrative contains any of the following strings, then we don't use the movement for calculating bandings
												WHEN claimmovcurr.MovementNarrativeFlag = 1
													THEN 0 
												ELSE 1
												END
    
	FROM #ClaimMovement claimmovcurr

	INNER JOIN #ClaimMovement claimmovprev 
	ON  claimmovcurr.MovementGroupId         = claimmovprev.MovementGroupId
	AND claimmovcurr.MovementGroupSequenceId = claimmovprev.MovementGroupSequenceId + 1

	WHERE claimmovcurr.MovementType = 'SCM' 

	/*
	UPDATE claimmov SET
	/*Decrease reserves on manual payment records*/
	 claimmov.MovementOutstandingIndemnityInOriginalCCY  = claimmov.MovementPaidIndemnityInOriginalCCY    * -1
	,claimmov.MovementOutstandingFeesInOriginalCCY       = claimmov.MovementPaidFeesInOriginalCCY         * -1
	,claimmov.MovementOutstandingDefenceInOriginalCCY    = claimmov.MovementPaidDefenceInOriginalCCY      * -1

	/*Decrease reserves on manual payment records for Settlement*/
	,claimmov.MovementOutstandingIndemnityInSettlementCCY  = claimmov.MovementPaidIndemnityInSettlementCCY    * -1
	,claimmov.MovementOutstandingFeesInSettlementCCY       = claimmov.MovementPaidFeesInSettlementCCY         * -1
	,claimmov.MovementOutstandingDefenceInSettlementCCY    = claimmov.MovementPaidDefenceInSettlementCCY      * -1
	FROM 
	#ClaimMovement claimmov
	WHERE   
	claimmov.MovementType <> 'SCM' 
	AND claimmov.MovementType <> 'Reserve'
	---AND claimmov.DoesNotErodeReserves = 0;  -- commented due to field not existing in V9


	-- Outstandings to-date
	;WITH CTEOutstandingsToDate AS
	(
	 SELECT
		 MovementGroupId                               = claimmov.MovementGroupId                                                  
		,MovementGroupSequenceId                       = claimmov.MovementGroupSequenceId                                       
		,ToDateOutstandingIndemnityInOriginalCCY       = ISNULL(claimmov.MovementOutstandingIndemnityInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingIndemnityInOriginalCCY, 0))     
		,ToDateOutstandingFeesInOriginalCCY            = ISNULL(claimmov.MovementOutstandingFeesInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingFeesInOriginalCCY, 0))          
		,ToDateOutstandingDefenceInOriginalCCY         = ISNULL(claimmov.MovementOutstandingDefenceInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingDefenceInOriginalCCY, 0))
		,ToDateOutstandingIndemnityInSettlementCCY     = ISNULL(claimmov.MovementOutstandingIndemnityInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingIndemnityInSettlementCCY, 0))     
		,ToDateOutstandingFeesInSettlementlCCY         = ISNULL(claimmov.MovementOutstandingFeesInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingFeesInSettlementCCY, 0))          
		,ToDateOutstandingDefenceInSettlementCCY       = ISNULL(claimmov.MovementOutstandingDefenceInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingDefenceInSettlementCCY, 0))  
	 FROM #ClaimMovement claimmov

	 inner JOIN #ClaimMovement claimmov2 
	 ON claimmov.MovementGroupId          = claimmov2.MovementGroupId
	 AND claimmov.MovementGroupSequenceId > claimmov2.MovementGroupSequenceId

	-- WHERE claimmov.IsSCMMovement = 0
	 GROUP BY claimmov.MovementGroupId
			 ,claimmov.MovementGroupSequenceId
			 ,claimmov.MovementOutstandingIndemnityInOriginalCCY
			 ,claimmov.MovementOutstandingFeesInOriginalCCY
			 ,claimmov.MovementOutstandingDefenceInOriginalCCY
			 ,claimmov.MovementOutstandingIndemnityInSettlementCCY 
			 ,claimmov.MovementOutstandingFeesInSettlementCCY
			 ,claimmov.MovementOutstandingDefenceInSettlementCCY
	)


	UPDATE claimmov
	SET
	 claimmov.ToDateOutstandingIndemnityInOriginalCCY      = ISNULL(outstadingdt.ToDateOutstandingIndemnityInOriginalCCY, 0)
	,claimmov.ToDateOutstandingFeesInOriginalCCY           = ISNULL(outstadingdt.ToDateOutstandingFeesInOriginalCCY	  , 0)
	,claimmov.ToDateOutstandingDefenceInOriginalCCY        = ISNULL(outstadingdt.ToDateOutstandingDefenceInOriginalCCY  , 0)
	,claimmov.ToDateOutstandingIndemnityInSettlementCCY    = ISNULL(outstadingdt.ToDateOutstandingIndemnityInSettlementCCY	, 0)
	,claimmov.ToDateOutstandingFeesInSettlementCCY         = ISNULL(outstadingdt.ToDateOutstandingFeesInSettlementlCCY		, 0)
	,claimmov.ToDateOutstandingDefenceInSettlementCCY      = ISNULL(outstadingdt.ToDateOutstandingDefenceInSettlementCCY	, 0)
	FROM #ClaimMovement claimmov

	INNER JOIN CTEOutstandingsToDate outstadingdt 
	ON  claimmov.MovementGroupId         = outstadingdt.MovementGroupId
	AND claimmov.MovementGroupSequenceId = outstadingdt.MovementGroupSequenceId    

	*/
	/***********************************************************************************************************/
	/*   Update sequence order - movements need to be shown in reverse chronological order in the front-end    */
	/***********************************************************************************************************/
	UPDATE claimmov 
	SET
	   claimmov.SequenceNumberOrderId  = claimmov1.LastMovementGroupSequenceId + 1 - claimmov.MovementGroupSequenceId

	FROM #ClaimMovement claimmov

	INNER JOIN
		(
		 SELECT MovementGroupId          = claimmov.MovementGroupId                  
			,LastMovementGroupSequenceId = MAX(claimmov.MovementGroupSequenceId) 
		 FROM #ClaimMovement claimmov
		 GROUP BY claimmov.MovementGroupId
		) claimmov1 
	ON claimmov.MovementGroupId = claimmov1.MovementGroupId

	/*update rates which are 0 with 1 in order not to break in ODS.PostPorcessClaimExposure or in Red.FaclClaimMovement */
	UPDATE #ClaimMovement
	SET OriginalCCYToLocalCCYRate = 1
	WHERE OriginalCCYToLocalCCYRate = 0

	UPDATE #ClaimMovement
	SET OutstandingOriginalCCYToSettlementCCYRate = 1
	WHERE OutstandingOriginalCCYToSettlementCCYRate = 0

	UPDATE #ClaimMovement
	SET PaidOriginalCCYToSettlementCCYRate = 1
	WHERE PaidOriginalCCYToSettlementCCYRate = 0

	UPDATE #ClaimMovement
	SET  MovementPaidIndemnityInSettlementCCY = -MovementPaidIndemnityInSettlementCCY
		,MovementPaidFeesInSettlementCCY = -MovementPaidFeesInSettlementCCY
		,MovementPaidDefenceInSettlementCCY = -MovementPaidDefenceInSettlementCCY 
		,MovementPaidIndemnityInOriginalCCY = -MovementPaidIndemnityInOriginalCCY   --treated already when inserting into #ClaimMovement 
		,MovementPaidFeesInOriginalCCY = -MovementPaidFeesInOriginalCCY
		,MovementPaidDefenceInOriginalCCY = -MovementPaidDefenceInOriginalCCY
		,EstimatedSettlementAmount		= -EstimatedSettlementAmount -- Andreea Radu, 15/10/2019, BI-3640
		,MovementNetPaymentAmountInOriginalCCY = -MovementNetPaymentAmountInOriginalCCY
        ,MovementNetPaymentAmountInSettlementCCY = -MovementNetPaymentAmountInSettlementCCY
        ,MovementTaxAmountInOriginalCCY = -MovementTaxAmountInOriginalCCY
        ,MovementTaxAmountInSettlementCCY = -MovementTaxAmountInSettlementCCY

	WHERE MovementType = 'Recovery'


	IF (OBJECT_ID('tempdb..#cem_fm1')) IS NOT NULL DROP TABLE #cem_fm1
	CREATE TABLE #cem_fm1
		(
		 ClaimExposureSourceid			 VARCHAR (255)  NOT NULL
		,MovementReferenceSourceid		 VARCHAR (255)  NOT NULL
		,SourceSystemEventDateTime		 DATETIME2 (7)
		,SequenceNumber				     NVARCHAR (255) NOT NULL
		,rownum						     INT NOT NULL
		)
	INSERT INTO #cem_fm1  
		(
		 ClaimExposureSourceid			 
		,MovementReferenceSourceid		
		,SourceSystemEventDateTime		 
		,SequenceNumber				
		,rownum	
		)
	SELECT 
		ClaimExposureSourceid, 
		MovementReferenceSourceid, 
		sourcesystemeventDateTime, 
		SequenceNumber, 
		rownum 
	FROM (
		SELECT 
			 ClaimExposureSourceid      = ClaimExposureSourceid
			 ,MovementReferenceSourceid = MovementReferenceSourceid
			 ,sourcesystemeventDateTime = sourcesystemeventDateTime
			 ,SequenceNumber
			 ,rownum                    = ROW_NUMBER() OVER (
				                                             PARTITION BY ClaimExposureSourceid, MovementReferenceSourceid, SequenceNumber 
															 ORDER BY MovementReferenceSourceid, SequenceNumber,sourcesystemeventDateTime asc
															 ) 
			
		FROM (
					SELECT ClaimExposureSourceid 
						  ,MovementReferenceSourceid
						  ,sourcesystemeventDateTime 
						  ,SequenceNumber
					FROM BeazleyIntelligenceDataContract.archive.ClaimExposureMovement 
					WHERE isActive = 1 
					AND RowStatus = 'P' 
					AND SourceSystem ='ClaimCenter'
					UNION 
						
					SELECT ClaimExposureSourceid 
						  ,MovementReferenceSourceid
						  ,SourceSystemEventDateTime 
					      ,SequenceNumber
					FROM BeazleyIntelligenceArchive.DataContract_archive.ClaimExposureMovement 
					WHERE IsActive = 1 
					AND RowStatus = 'P' 
					AND SourceSystem ='ClaimCenter'
				) x
			)y
	WHERE rownum =1

	CREATE NONCLUSTERED INDEX [IDX_cem_fm1] ON #cem_fm1 (ClaimExposureSourceid, MovementReferenceSourceid) 
	INCLUDE ( SourceSystemEventDateTime, SequenceNumber)

	CREATE NONCLUSTERED INDEX [IDX_#ClaimMovement] ON #ClaimMovement (MovementReferenceSourceId, SequenceNumber) 

	CREATE NONCLUSTERED INDEX [IDX_#ClaimMovement_FK_ClaimExposure] ON #ClaimMovement (FK_ClaimExposure)
	INCLUDE(MovementReferenceSourceId, SequenceNumber) 
	--17:37 min
/*DE SCOS SI ADAUGAT IN CREATE PROCEDURE DIN BeazleyIntelligenceDataContract.Outbound.ClaimExposureMovement
	
	CREATE NONCLUSTERED INDEX [IDX_ClaimExposureMovement] ON BeazleyIntelligenceDataContract.Outbound.ClaimExposureMovement (ClaimExposureSourceid, isactive) 
	INCLUDE ( MovementReferenceSourceId, SequenceNumber)*/

	UPDATE cm
    SET ActualMovementCreationDate = cem_fm.sourcesystemeventDateTime
	FROM #ClaimMovement cm 
	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement cem 
	ON  cm.MovementReferenceSourceId = cem.MovementReferenceSourceId 
	AND cm.SequenceNumber = cem.SequenceNumber

	INNER JOIN ODS.ClaimExposure ce 
	ON  cm.FK_CLaimExposure = ce.PK_CLaimExposure  
	AND ce.ExposureReference = cem.ClaimExposureSourceId

	INNER JOIN #cem_fm1 cem_fm
	ON cem.ClaimExposureSourceid = cem_fm.ClaimExposureSourceid 
	AND cem.MovementReferenceSourceid = cem_fm.MovementReferenceSourceid
	AND cem.SequenceNumber = cem_fm.SequenceNumber

	-- 3:38 cu tab temp si 4 indexuri

	IF (OBJECT_ID('tempdb..#cem_fm2')) IS NOT NULL DROP TABLE #cem_fm2
	CREATE TABLE #cem_fm2
	(
	 ClaimExposureSourceid			 VARCHAR (255)  NOT NULL
	,MovementReferenceSourceid		 VARCHAR (255)  NOT NULL
	,SourceSystemEventDateTime		 DATETIME2 (7)
	,rownum						     INT NOT NULL
	)
	INSERT INTO #cem_fm2  
	(
	 ClaimExposureSourceid			 
	,MovementReferenceSourceid		
	,SourceSystemEventDateTime			
	,rownum						
	)
	SELECT 
		ClaimExposureSourceid, 
		MovementReferenceSourceid, 
		sourcesystemeventDateTime, 
		rownum 
	FROM(
		SELECT 
			 ClaimExposureSourceid      = ClaimExposureSourceid
			 ,MovementReferenceSourceid = MovementReferenceSourceid
			 ,sourcesystemeventDateTime = sourcesystemeventDateTime
			 ,rownum                    = ROW_NUMBER() OVER (
				                                             PARTITION BY ClaimExposureSourceid, MovementReferenceSourceid 
															 ORDER BY MovementReferenceSourceid, sourcesystemeventDateTime asc
															 ) 
		FROM (
			select ClaimExposureSourceid ,MovementReferenceSourceid,sourcesystemeventDateTime 
			from BeazleyIntelligenceDataContract.archive.ClaimExposureMovement 
			WHERE isActive = 1 
				AND rowstatus = 'P' 
				AND SourceSystem ='ClaimCenter'
			union all
			select ClaimExposureSourceid ,MovementReferenceSourceid,sourcesystemeventDateTime 
			from BeazleyIntelligenceArchive.DataContract_archive.ClaimExposureMovement 
			WHERE isActive = 1 
				AND rowstatus = 'P' 
				AND SourceSystem ='ClaimCenter' ) x
				)y
	WHERE rownum = 1

	-- 17 sec insert

	UPDATE cm
	SET ActualMovementCreationDate = cem_fm.sourcesystemeventDateTime
	from #ClaimMovement cm 
	INNER JOIN
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement cem
	ON  cm.MovementReferenceSourceId = cem.MovementReferenceSourceId

	INNER JOIN ODS.ClaimExposure ce
	ON  cm.FK_CLaimExposure = ce.PK_CLaimExposure 
	and ce.ExposureReference = cem.ClaimExposureSourceId

    INNER JOIN #cem_fm2 cem_fm
	ON cem.ClaimExposureSourceid = cem_fm.ClaimExposureSourceid 
	AND cem.MovementReferenceSourceid = cem_fm.MovementReferenceSourceid
	WHERE cm.ActualMovementCreationDate IS NULL 

	-- we calculate the ToDateOutstanding... fields for:
			-- non SCM movements from migration
			-- non SCM from UI (after go live)
			-- SCM  from UI (after go live)

	UPDATE #ClaimMovement
	SET 
	[ToDateOutstandingIndemnityInOriginalCCY]		= cm.[ToDateOutstandingIndemnityInOriginalCCY]
	,[ToDateOutstandingFeesInOriginalCCY]			= cm.[ToDateOutstandingFeesInOriginalCCY]
	,[ToDateOutstandingDefenceInOriginalCCY]		= cm.[ToDateOutstandingDefenceInOriginalCCY]
	,[ToDateOutstandingIndemnityInSettlementCCY]	= cm.[ToDateOutstandingIndemnityInSettlementCCY]
	,[ToDateOutstandingFeesInSettlementCCY]			= cm.[ToDateOutstandingFeesInSettlementCCY]
	,[ToDateOutstandingDefenceInSettlementCCY]		= cm.[ToDateOutstandingDefenceInSettlementCCY]
	FROM(
	SELECT  
		 FK_ClaimExposure
	    ,SequenceNumber			
		,FK_OriginalCurrency		
		,FK_SettlementCurrency	
		,MovementReference	    
	    ,[ToDateOutstandingIndemnityInOriginalCCY]	     = SUM([ToDateOutstandingIndemnityInOriginalCCY])		OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[ToDateOutstandingFeesInOriginalCCY]		     = SUM([ToDateOutstandingFeesInOriginalCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[ToDateOutstandingDefenceInOriginalCCY]	     = SUM([ToDateOutstandingDefenceInOriginalCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[ToDateOutstandingIndemnityInSettlementCCY]	  = SUM([ToDateOutstandingIndemnityInSettlementCCY])	OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 
		,[ToDateOutstandingFeesInSettlementCCY]			  = SUM([ToDateOutstandingFeesInSettlementCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 
		,[ToDateOutstandingDefenceInSettlementCCY]		  = SUM([ToDateOutstandingDefenceInSettlementCCY])		OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 
	FROM(

		SELECT
		     FK_ClaimExposure
			,MovementGroupId
			,MovementGroupSequenceId
			,SequenceNumber			
			,FK_OriginalCurrency		
			,FK_SettlementCurrency	
			,MovementReference	    
	        ,[ToDateOutstandingIndemnityInOriginalCCY]	     = (LAG(ToDateOutstandingIndemnityInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)	)		+ MovementOutstandingIndemnityInOriginalCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidIndemnityInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingFeesInOriginalCCY]		     = (LAG(ToDateOutstandingFeesInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingFeesInOriginalCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidFeesInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingDefenceInOriginalCCY]	     = (LAG(ToDateOutstandingDefenceInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingDefenceInOriginalCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidDefenceInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingIndemnityInSettlementCCY]	  = (LAG(ToDateOutstandingIndemnityInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid))		+ MovementOutstandingIndemnityInSettlementCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidIndemnityInSettlementCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingFeesInSettlementCCY]			  = (LAG(ToDateOutstandingFeesInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingFeesInSettlementCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidFeesInSettlementCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingDefenceInSettlementCCY]		  = (LAG(ToDateOutstandingDefenceInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)	)		+ MovementOutstandingDefenceInSettlementCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidDefenceInSettlementCCY
																																																							ELSE 0 
																																																						END
         
    FROM #ClaimMovement	
	WHERE MovementType <> 'SCM'
	)x )cm
	WHERE  #ClaimMovement.FK_ClaimExposure			= cm.FK_ClaimExposure
	   AND #ClaimMovement.SequenceNumber			= cm.SequenceNumber
	   AND #ClaimMovement.FK_OriginalCurrency		= cm.FK_OriginalCurrency
	   AND #ClaimMovement.FK_SettlementCurrency		= cm.FK_SettlementCurrency
	   AND #ClaimMovement.MovementReference			= cm.MovementReference

CREATE NONCLUSTERED INDEX [IDX_#ClaimMovement2] ON #ClaimMovement (FK_ClaimExposure, SequenceNumber, FK_OriginalCurrency, FK_SettlementCurrency, MovementReference)			

MERGE ODS.CLaimMovement target
USING 
#ClaimMovement source
ON  target.FK_ClaimExposure			= source.FK_ClaimExposure
AND target.SequenceNumber		   	= source.SequenceNumber
AND target.FK_OriginalCurrency		= source.FK_OriginalCurrency
AND target.FK_SettlementCurrency	= source.FK_SettlementCurrency
AND target.MovementReference		= source.MovementReference

WHEN MATCHED THEN
UPDATE SET 
 target.[MovementGroupId]								= source.[MovementGroupId]    
,target.[MovementGroupSequenceId]                       = source.[MovementGroupSequenceId] 
,target.[SequenceNumberOrderId]                         = source.[SequenceNumberOrderId] 
,target.[OutstandingOriginalCCYToSettlementCCYRate]     = source.[OutstandingOriginalCCYToSettlementCCYRate]
,target.[PaidOriginalCCYToSettlementCCYRate]            = source.[PaidOriginalCCYToSettlementCCYRate] 
,target.[MovementDate]                                  = source.[MovementDate]
,target.[MovementPeriod]                                = source.[MovementPeriod]
,target.[ToDateOutstandingIndemnityInOriginalCCY]       = source.[ToDateOutstandingIndemnityInOriginalCCY]
,target.[ToDateOutstandingFeesInOriginalCCY]            = source.[ToDateOutstandingFeesInOriginalCCY]  
,target.[ToDateOutstandingDefenceInOriginalCCY]         = source.[ToDateOutstandingDefenceInOriginalCCY]
,target.[MovementPaidIndemnityInOriginalCCY]            = source.[MovementPaidIndemnityInOriginalCCY]
,target.[MovementPaidFeesInOriginalCCY]                 = source.[MovementPaidFeesInOriginalCCY]
,target.[MovementPaidDefenceInOriginalCCY]              = source.[MovementPaidDefenceInOriginalCCY]
,target.[ToDateOutstandingIndemnityInSettlementCCY]     = source.[ToDateOutstandingIndemnityInSettlementCCY]
,target.[ToDateOutstandingFeesInSettlementCCY]          = source.[ToDateOutstandingFeesInSettlementCCY]
,target.[ToDateOutstandingDefenceInSettlementCCY]       = source.[ToDateOutstandingDefenceInSettlementCCY]
,target.[MovementPaidIndemnityInSettlementCCY]          = source.[MovementPaidIndemnityInSettlementCCY]
,target.[MovementPaidFeesInSettlementCCY]               = source.[MovementPaidFeesInSettlementCCY]
,target.[MovementPaidDefenceInSettlementCCY]            = source.[MovementPaidDefenceInSettlementCCY]
,target.[MovementType]                                  = source.[MovementType]
,target.[MovementApprovalUser]                          = source.[MovementApprovalUser]
,target.[MovementCreateUser]                            = source.[MovementCreateUser]
,target.[MovementNarrative]                             = source.[MovementNarrative]
,target.[ChequeIssueDate]                               = source.[ChequeIssueDate] 
,target.[ChequeNumber]                                  = source.[ChequeNumber]
,target.[InvoiceNumber]                                 = source.[InvoiceNumber]
,target.[ChequePayee]                                   = source.[ChequePayee]
,target.[TBAIndicator]                                  = source.[TBAIndicator]
,target.[TBAFlag]                                       = source.[TBAFlag]
,target.[FeesOnlyEntry]                                 = source.[FeesOnlyEntry]
,target.[LPSOSigningDate]                               = source.[LPSOSigningDate]
,target.[LPSOSigningNumber]                             = source.[LPSOSigningNumber]
,target.[UseForLastMovementBanding]                     = source.[UseForLastMovementBanding]
,target.[XChangingChecker]                              = source.[XChangingChecker]
,target.[PrimaryExaminerOrCreateUserId]                 = source.[PrimaryExaminerOrCreateUserId]
,target.[ExposureStatusCode]                            = source.[ExposureStatusCode]
,target.[RecoveryCategory]                              = source.[RecoveryCategory]
,target.[FK_ClaimCostCategory]                          = source.[FK_ClaimCostCategory]
,target.[FK_LocalCurrency]                              = source.[FK_LocalCurrency]
,target.[FK_DevelopmentPeriod]                          = source.[FK_DevelopmentPeriod]
,target.[OriginalCCYToLocalCCYRate]                     = source.[OriginalCCYToLocalCCYRate]
,target.[ClaimTeamExaminer]                             = source.[ClaimTeamExaminer]
,target.[MovementCreationDate]                          = source.[MovementCreationDate]  
,target.ActualOriginalCurrency 						    = source.ActualOriginalCurrency 			  
,target.ActualOriginalAmount 		                    = source.ActualOriginalAmount							
,target.EstimatedSettlementAmount 		                = source.EstimatedSettlementAmount 							
,target.ActualToSettlementExchangeRate				    = source.ActualToSettlementExchangeRate				
,target.ActualOriginalAmountType                        = source.ActualOriginalAmountType
,target.BeazleyShare                                    = source.BeazleyShare
,target.IndemnityReserveInSettlementCCY	                = source.IndemnityReserveInSettlementCCY
,target.FeesReserveInSettlementCCY			            = source.FeesReserveInSettlementCCY	
,target.DefenceReserveInSettlementCCY		            = source.DefenceReserveInSettlementCCY
,target.DoesNotErodeReserves                            = source.DoesNotErodeReserves
,target.CheckDetailsDateOfService                       = source.CheckDetailsDateOfService
,target.CheckDetailsDueDate                             = source.CheckDetailsDueDate
,target.CheckDetailsNetAmount                           = source.CheckDetailsNetAmount
,target.CheckDetailsPaymentMethod                       = source.CheckDetailsPaymentMethod
,target.CheckDetailsScheduledSendDate                   = source.CheckDetailsScheduledSendDate
,target.CheckDetailsStatus                              = source.CheckDetailsStatus
,target.PaymentId                                       = source.PaymentId
,target.PaymentType                                     = source.PaymentType
,target.SignedLine                                      = source.SignedLine
,target.TransactionTrackingStatus                       = source.TransactionTrackingStatus
,target.TransferStatus	                                = source.TransferStatus	
,target.MovementNetPaymentAmountInOriginalCCY           = source.MovementNetPaymentAmountInOriginalCCY
,target.MovementNetPaymentAmountInSettlementCCY         = source.MovementNetPaymentAmountInSettlementCCY
,target.MovementTaxAmountInOriginalCCY                  = source.MovementTaxAmountInOriginalCCY
,target.MovementTaxAmountInSettlementCCY	            = source.MovementTaxAmountInSettlementCCY
,target.TaxApplicable                                   = source.TaxApplicable
,target.TaxPercent                                      = source.TaxPercent
,target.ActualMovementCreationDate                      = source.ActualMovementCreationDate
,target.InvoiceIssueDate                                = source.InvoiceIssueDate
,target.InvoiceReceivedDate                             = source.InvoiceReceivedDate
,target.BureauShare                                     = source.BureauShare
,target.SettlementDate                                  = source.SettlementDate
,target.HashbytesId	                                    = source.HashbytesId	
,target.AuditModifyDateTime	                            = GETDATE()						
,target.AuditModifyDetails	                            = 'Merge in ODS.usp_LoadClaimMovement' 

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(        [SequenceNumber]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]
		,[ToDateOutstandingFeesInOriginalCCY]
		,[ToDateOutstandingDefenceInOriginalCCY]
		,[MovementPaidIndemnityInOriginalCCY]
		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]
		,[ToDateOutstandingIndemnityInSettlementCCY]
		,[ToDateOutstandingFeesInSettlementCCY]
		,[ToDateOutstandingDefenceInSettlementCCY]
		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]
		,[ClaimTeamExaminer]
		,[MovementCreationDate]           
		,ActualOriginalCurrency 								   
		,ActualOriginalAmount 									   
		,EstimatedSettlementAmount 								   
		,ActualToSettlementExchangeRate							   
		,ActualOriginalAmountType
		,BeazleyShare
		,IndemnityReserveInSettlementCCY	
		,FeesReserveInSettlementCCY			
		,DefenceReserveInSettlementCCY		
		,DoesNotErodeReserves
		,CheckDetailsDateOfService
		,CheckDetailsDueDate
		,CheckDetailsNetAmount
		,CheckDetailsPaymentMethod
		,CheckDetailsScheduledSendDate
		,CheckDetailsStatus
		,PaymentId
		,PaymentType
		,SignedLine
		,TransactionTrackingStatus
		,TransferStatus	
		,MovementNetPaymentAmountInOriginalCCY
        ,MovementNetPaymentAmountInSettlementCCY
        ,MovementTaxAmountInOriginalCCY
        ,MovementTaxAmountInSettlementCCY	
		,TaxApplicable
		,TaxPercent
		,ActualMovementCreationDate
		,InvoiceIssueDate
		,InvoiceReceivedDate
		,BureauShare
		,SettlementDate
		,HashbytesId
		,AuditCreateDateTime
		,AuditModifyDetails
)

VALUES
(    source.[SequenceNumber]
	,source.[MovementReference]
	,source.[MovementGroupId]
	,source.[MovementGroupSequenceId]
	,source.[SequenceNumberOrderId]
	,source.[OutstandingOriginalCCYToSettlementCCYRate]
	,source.[PaidOriginalCCYToSettlementCCYRate]
	,source.[MovementDate]
	,source.[MovementPeriod]
	,source.[ToDateOutstandingIndemnityInOriginalCCY]
	,source.[ToDateOutstandingFeesInOriginalCCY]
	,source.[ToDateOutstandingDefenceInOriginalCCY]
	,source.[MovementPaidIndemnityInOriginalCCY]
	,source.[MovementPaidFeesInOriginalCCY]
	,source.[MovementPaidDefenceInOriginalCCY]
	,source.[ToDateOutstandingIndemnityInSettlementCCY]
	,source.[ToDateOutstandingFeesInSettlementCCY]
	,source.[ToDateOutstandingDefenceInSettlementCCY]
	,source.[MovementPaidIndemnityInSettlementCCY]
	,source.[MovementPaidFeesInSettlementCCY]
	,source.[MovementPaidDefenceInSettlementCCY]
	,source.[MovementType]
	,source.[MovementApprovalUser]
	,source.[MovementCreateUser]
	,source.[MovementNarrative]
	,source.[ChequeIssueDate]
	,source.[ChequeNumber]
	,source.[InvoiceNumber]
	,source.[ChequePayee]
	,source.[TBAIndicator]
	,source.[TBAFlag]
	,source.[FeesOnlyEntry]
	,source.[LPSOSigningDate]
	,source.[LPSOSigningNumber]
	,source.[UseForLastMovementBanding]
	,source.[XChangingChecker]
	,source.[PrimaryExaminerOrCreateUserId]
	,source.[ExposureStatusCode]
	,source.[RecoveryCategory]
	,source.[FK_ClaimCostCategory]
	,source.[FK_ClaimExposure]
	,source.[FK_SettlementCurrency]
	,source.[FK_OriginalCurrency]
	,source.[FK_LocalCurrency]
	,source.[FK_DevelopmentPeriod]
	,source.[OriginalCCYToLocalCCYRate]
	,source.[ClaimTeamExaminer]
	,source.[MovementCreationDate]           
	,source.ActualOriginalCurrency 								  
	,source.ActualOriginalAmount 									
	,source.EstimatedSettlementAmount 								
	,source.ActualToSettlementExchangeRate							
	,source.ActualOriginalAmountType
	,source.BeazleyShare
	,source.IndemnityReserveInSettlementCCY	
	,source.FeesReserveInSettlementCCY			
	,source.DefenceReserveInSettlementCCY		
	,source.DoesNotErodeReserves
	,source.CheckDetailsDateOfService
	,source.CheckDetailsDueDate
	,source.CheckDetailsNetAmount
	,source.CheckDetailsPaymentMethod
	,source.CheckDetailsScheduledSendDate
	,source.CheckDetailsStatus
	,source.PaymentId
	,source.PaymentType
	,source.SignedLine
	,source.TransactionTrackingStatus
	,source.TransferStatus	
	,source.MovementNetPaymentAmountInOriginalCCY
    ,source.MovementNetPaymentAmountInSettlementCCY
    ,source.MovementTaxAmountInOriginalCCY
    ,source.MovementTaxAmountInSettlementCCY	
	,source.TaxApplicable
	,source.TaxPercent
	,source.ActualMovementCreationDate
	,source.InvoiceIssueDate
	,source.InvoiceReceivedDate
	,source.BureauShare
	,source.SettlementDate
	,source.HashbytesId
	,GETDATE()
	,'New add in ODS.usp_LoadClaimMovement'	
);

IF OBJECT_ID('tempdb..#ClaimMovement') IS NOT NULL DROP TABLE #ClaimMovement
IF OBJECT_ID('tempdb..#ClaimMovement2') IS NOT NULL DROP TABLE #ClaimMovement2
IF OBJECT_ID('tempdb..#cem_fm1') IS NOT NULL DROP TABLE #cem_fm1
IF OBJECT_ID('tempdb..#cem_fm2') IS NOT NULL DROP TABLE #cem_fm2
 
 EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimMovement';
END