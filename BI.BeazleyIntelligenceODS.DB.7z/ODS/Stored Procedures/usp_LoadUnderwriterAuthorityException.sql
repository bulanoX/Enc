﻿

CREATE PROCEDURE [ODS].[usp_LoadUnderwriterAuthorityException]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#UnderwriterAuthorityException') IS NOT NULL)
DROP TABLE #UnderwriterAuthorityException

CREATE TABLE #UnderwriterAuthorityException
 (
     FK_Section                                         BIGINT          NOT NULL
    ,FK_Underwriter                                     BIGINT          NOT NULL
    ,FK_TriFocus                                        BIGINT          NOT NULL
    ,FK_ClassOfBusiness                                 BIGINT          NOT NULL
    ,InsuredParty                                       VARCHAR(255)    NULL
    ,MOPCode                                            VARCHAR(255)    NULL
    ,RenewalIndicator                                   VARCHAR(50)     NULL
    ,ExceptionIdentifier                                INT             NULL
    ,ExceptionType                                      VARCHAR(255)    NULL
    ,ExceptionDescription                               NVARCHAR(MAX)   NULL
    ,ExceptionDate                                      DATETIME        NULL
    ,ExceptionStatus                                    VARCHAR(255)    NULL    
    ,ExceptionStatusDetail                              VARCHAR(255)    NULL    
    ,SectionValue                                       NUMERIC(19,4)   NULL
    ,SectionValueCurrency                               VARCHAR(255)    NULL
    ,AuthorityLimitValue                                NUMERIC(19,4)   NULL
    ,AuthorityLimitValueCurrency                        VARCHAR(255)    NULL
    ,SectionValueInAuthorityLimitCurrency               NUMERIC(19,4)   NULL
    ,SectionToAuthorityLimitConversionRate              NUMERIC(19,4)   NULL
    ,AuthorityLimitBreachedValue                        NUMERIC(19,4)   NULL
    ,AuthorityLimitBreachedValueCurrency                VARCHAR(255)    NULL 
    ,SectionPeriodValue                                 NUMERIC(19,4)   NULL
    ,AuthorityLimitPeriod                               NUMERIC(19,4)   NULL
    ,AuthorityLimitBreachedPeriod                       NUMERIC(19,4)   NULL
    ,ElapsedDaysSinceExceptionDate                      INT             NULL
    ,ExchangeRateSetName                                VARCHAR(255)    NULL  
    ,SourceSystem                                       VARCHAR(255)    NULL   
 )

TRUNCATE TABLE #UnderwriterAuthorityException

INSERT INTO #UnderwriterAuthorityException
(
     FK_Section                           
    ,FK_Underwriter                      
    ,FK_TriFocus
    ,FK_ClassOfBusiness
    ,InsuredParty                           
    ,MOPCode                             
    ,RenewalIndicator    
    ,ExceptionIdentifier                 
    ,ExceptionType                       
    ,ExceptionDescription                
    ,ExceptionDate                       
    ,ExceptionStatus                     
    ,ExceptionStatusDetail               
    ,SectionValue                         
    ,SectionValueCurrency                 
    ,AuthorityLimitValue                 
    ,AuthorityLimitValueCurrency         
    ,SectionValueInAuthorityLimitCurrency 
    ,SectionToAuthorityLimitConversionRate
    ,AuthorityLimitBreachedValue         
    ,AuthorityLimitBreachedValueCurrency
    ,SectionPeriodValue             
    ,AuthorityLimitPeriod          
    ,AuthorityLimitBreachedPeriod  
    ,ElapsedDaysSinceExceptionDate       
    ,ExchangeRateSetName                 
    ,SourceSystem                        
)

SELECT
     FK_Section                                = sec.PK_Section
    ,FK_Underwriter                            = ISNULL(und.PK_Underwriter, 0)
    ,FK_TriFocus                               = ISNULL(sec.FK_TriFocus, 0)
    ,FK_ClassOfBusiness                        = ISNULL(cob.PK_ClassOfBusiness, 0)      
    ,InsuredParty                              = exc.InsuredsName        
    ,MOPCode                                   = exc.MethodOfPlacement        
    ,RenewalIndicator                          = exc.NewOrRenewalIndicator        
    ,ExceptionIdentifier                       = exc.ID                                               
    ,ExceptionType                             = exc.ExceptionType                             
    ,ExceptionDescription                      = exc.[Description]             
    ,ExceptionDate                             = exc.ExceptionDate 
    ,ExceptionStatus                           = exc.ExceptionStatus 
    ,ExceptionStatusDetail                     = exc.ExceptionStatusDetail 
    ,SectionValue                              = exc.ValueInPolicyCurrency 
    ,SectionValueCurrency                      = exc.PolicyCurrency 
    ,AuthorityLimitValue                       = exc.UnderwritersAuthorityLimitInUnderwritersDefaultCurrency
    ,AuthorityLimitValueCurrency               = exc.UnderwritersDefaultCurrency 
    ,SectionValueInAuthorityLimitCurrency      = exc.ValueInUnderwritersDefaultCurrency  
    ,SectionToAuthorityLimitConversionRate     = exc.PolicyCurrencyToUnderwritersDefaultCurrencyExchangeRate 
    ,AuthorityLimitBreachedValue               = CASE WHEN exc.ValueInUnderwritersDefaultCurrency - exc.UnderwritersAuthorityLimitInUnderwritersDefaultCurrency < 0 THEN 0 
                                                 ELSE exc.ValueInUnderwritersDefaultCurrency - exc.UnderwritersAuthorityLimitInUnderwritersDefaultCurrency 
                                                 END     
    ,AuthorityLimitBreachedValueCurrency       = exc.UnderwritersDefaultCurrency  
    ,SectionPeriodValue                        = exc.PolicyPeriodValue
    ,AuthorityLimitPeriod                      = exc.PolicyPeriodLimit
    ,AuthorityLimitBreachedPeriod              = CASE WHEN exc.PolicyPeriodValue - exc.PolicyPeriodLimit < 0 THEN 0 
                                                 ELSE exc.PolicyPeriodValue - exc.PolicyPeriodLimit 
                                                 END
    ,ElapsedDaysSinceExceptionDate             = DATEDIFF(DAY, exc.ExceptionDate, GETDATE())
    ,ExchangeRateSetName                       = exc.ExchangeRateSet 
    ,SourceSystem                              = exc.SourceSystem 
 
FROM Staging_BeazleyAuthorityExceptions.BeazleyAuthorityExceptions_Staging.AuthorityException exc

INNER JOIN ODS.Section sec 
ON exc.RiskReference = sec.SectionReference

LEFT OUTER JOIN ODS.Underwriter und 
ON exc.UnderwriterInitials = und.UnderwriterUserInitials
and exc.UnderwriterName = und.UnderwriterName

LEFT OUTER JOIN ODS.ClassOfBusiness cob 
ON exc.CobCode = cob.ClassOfBusinessCode

MERGE ODS.UnderwriterAuthorityException AS TARGET

USING #UnderwriterAuthorityException AS SOURCE

 ON TARGET.ExceptionIdentifier  = SOURCE.ExceptionIdentifier

 WHEN MATCHED THEN
 
 UPDATE SET

 TARGET.FK_Section                                = SOURCE.FK_Section                           
,TARGET.FK_Underwriter                            = SOURCE.FK_Underwriter                      
,TARGET.FK_TriFocus                               = SOURCE.FK_TriFocus
,TARGET.FK_ClassOfBusiness                        = SOURCE.FK_ClassOfBusiness
,TARGET.InsuredParty                              = SOURCE.InsuredParty
,TARGET.MOPCode                                   = SOURCE.MOPCode
,TARGET.RenewalIndicator                          = SOURCE.RenewalIndicator
,TARGET.ExceptionIdentifier                       = SOURCE.ExceptionIdentifier                 
,TARGET.ExceptionType                             = SOURCE.ExceptionType                       
,TARGET.ExceptionDescription                      = SOURCE.ExceptionDescription                
,TARGET.ExceptionDate                             = SOURCE.ExceptionDate                       
,TARGET.ExceptionStatus                           = SOURCE.ExceptionStatus                     
,TARGET.ExceptionStatusDetail                     = SOURCE.ExceptionStatusDetail               
,TARGET.SectionValue                              = SOURCE.SectionValue                         
,TARGET.SectionValueCurrency                      = SOURCE.SectionValueCurrency                 
,TARGET.AuthorityLimitValue                       = SOURCE.AuthorityLimitValue                 
,TARGET.AuthorityLimitValueCurrency               = SOURCE.AuthorityLimitValueCurrency         
,TARGET.SectionValueInAuthorityLimitCurrency      = SOURCE.SectionValueInAuthorityLimitCurrency 
,TARGET.SectionToAuthorityLimitConversionRate     = SOURCE.SectionToAuthorityLimitConversionRate
,TARGET.AuthorityLimitBreachedValue               = SOURCE.AuthorityLimitBreachedValue         
,TARGET.AuthorityLimitBreachedValueCurrency       = SOURCE.AuthorityLimitBreachedValueCurrency
,TARGET.SectionPeriodValue                        = SOURCE.SectionPeriodValue            
,TARGET.AuthorityLimitPeriod                      = SOURCE.AuthorityLimitPeriod        
,TARGET.AuthorityLimitBreachedPeriod              = SOURCE.AuthorityLimitBreachedPeriod
,TARGET.ElapsedDaysSinceExceptionDate             = SOURCE.ElapsedDaysSinceExceptionDate       
,TARGET.ExchangeRateSetName                       = SOURCE.ExchangeRateSetName                 
,TARGET.SourceSystem                              = SOURCE.SourceSystem   
,TARGET.AuditModifyDateTime                       = GETDATE()
,TARGET.AuditModifyDetails                        = 'Merge in [ODS].[UnderwriterAuthorityException] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT 
(
  FK_Section                           
,FK_Underwriter                      
,FK_TriFocus
,FK_ClassOfBusiness
,InsuredParty
,MOPCode
,RenewalIndicator
,ExceptionIdentifier                 
,ExceptionType                       
,ExceptionDescription                
,ExceptionDate                       
,ExceptionStatus                     
,ExceptionStatusDetail               
,SectionValue                         
,SectionValueCurrency                 
,AuthorityLimitValue                 
,AuthorityLimitValueCurrency         
,SectionValueInAuthorityLimitCurrency 
,SectionToAuthorityLimitConversionRate
,AuthorityLimitBreachedValue         
,AuthorityLimitBreachedValueCurrency
,SectionPeriodValue            
,AuthorityLimitPeriod        
,AuthorityLimitBreachedPeriod
,ElapsedDaysSinceExceptionDate       
,ExchangeRateSetName                 
,SourceSystem   
,AuditModifyDetails
)
VALUES
(
  SOURCE.FK_Section                           
,SOURCE.FK_Underwriter                      
,SOURCE.FK_TriFocus
,SOURCE.FK_ClassOfBusiness
,SOURCE.InsuredParty
,SOURCE.MOPCode
,SOURCE.RenewalIndicator
,SOURCE.ExceptionIdentifier                 
,SOURCE.ExceptionType                       
,SOURCE.ExceptionDescription                
,SOURCE.ExceptionDate                       
,SOURCE.ExceptionStatus                     
,SOURCE.ExceptionStatusDetail               
,SOURCE.SectionValue                         
,SOURCE.SectionValueCurrency                 
,SOURCE.AuthorityLimitValue                 
,SOURCE.AuthorityLimitValueCurrency         
,SOURCE.SectionValueInAuthorityLimitCurrency 
,SOURCE.SectionToAuthorityLimitConversionRate
,SOURCE.AuthorityLimitBreachedValue         
,SOURCE.AuthorityLimitBreachedValueCurrency
,SOURCE.SectionPeriodValue            
,SOURCE.AuthorityLimitPeriod        
,SOURCE.AuthorityLimitBreachedPeriod
,SOURCE.ElapsedDaysSinceExceptionDate       
,SOURCE.ExchangeRateSetName                 
,SOURCE.SourceSystem   
,'New in [ODS].[UnderwriterAuthorityException] table'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;

MERGE ODS.UnderwriterAuthorityExceptionNote AS TARGET

USING 
(SELECT 

 FK_UnderwriterAuthorityException  = uae.PK_UnderwriterAuthorityException
,NoteID                            = notes.ID
,NoteText                          = notes.[Text]
,NoteAddedDate                     = notes.Added         
,NoteAddedBy                       = notes.AddedBy

FROM ODS.UnderwriterAuthorityException uae
    
INNER JOIN Staging_BeazleyAuthorityExceptions.BeazleyAuthorityExceptions_Staging.Annotation notes
ON uae.ExceptionIdentifier = notes.AuthorityExceptionId

WHERE COALESCE(notes.[Text],'')<>'') AS SOURCE

 ON TARGET.NoteID  = SOURCE.NoteID

 WHEN MATCHED THEN
 
 UPDATE SET

 TARGET.FK_UnderwriterAuthorityException  = SOURCE.FK_UnderwriterAuthorityException
,TARGET.NoteID                            = SOURCE.NoteID
,TARGET.NoteText                          = SOURCE.NoteText
,TARGET.NoteAddedDate                     = SOURCE.NoteAddedDate
,TARGET.NoteAddedBy                       = SOURCE.NoteAddedBy
,TARGET.AuditModifyDateTime               = GETDATE()
,TARGET.AuditModifyDetails                = 'Merge in [ODS].[UnderwriterAuthorityExceptionNote] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT 
(
 FK_UnderwriterAuthorityException
,NoteID                          
,NoteText                        
,NoteAddedDate                   
,NoteAddedBy 
,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_UnderwriterAuthorityException
,SOURCE.NoteID                          
,SOURCE.NoteText                        
,SOURCE.NoteAddedDate                   
,SOURCE.NoteAddedBy 
,'New in [ODS].[UnderwriterAuthorityExceptionNote] table'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#UnderwriterAuthorityException') IS NOT NULL)
DROP TABLE #UnderwriterAuthorityException