﻿

CREATE PROC ODS.usp_PostProcessLPSOTransaction

AS
--  Due to ODS.ClaimMovement and ODS.LPSOTransaction loads being run in parallel, ClaimExposure FKs that are deleted during ClaimMovement 
--  are not accounted for in LPSOTransaction.  This update removes the FK values from LPSOTransaction.
  
	UPDATE LPSO
	SET FK_ClaimExposure = NULL
	--SELECT FK_ClaimExposure,*
	FROM ODS.LPSOTransaction LPSO
	WHERE NOT EXISTS (SELECT 1 FROM  ODS.ClaimMovement cm WHERE LPSO.FK_ClaimExposure = cm.FK_ClaimExposure)
	AND FK_ClaimExposure IS NOT NULL