﻿CREATE PROCEDURE [ODS].[usp_LoadAccountingPeriod]
AS

SET NOCOUNT ON

SET NOCOUNT ON

TRUNCATE TABLE ODS.AccountingPeriod

CREATE TABLE #AccountingPeriod 
	(
    [FK_AccountingCalendar] BIGINT         NOT NULL,
    [AccountingPeriodName]  VARCHAR (255)  NOT NULL,
    [PeriodStart]           DATETIME       NOT NULL,
    [PeriodEnd]             DATETIME       NOT NULL,
    )

INSERT INTO #AccountingPeriod

(
FK_AccountingCalendar
,AccountingPeriodName
,PeriodStart
,PeriodEnd
)
SELECT 
	FK_AccountingCalendar           = ac.PK_AccountingCalendar
	,AccountingPeriodName           = cc.AccountingPeriod
	,PeriodStart                    = cc.PeriodStart
	,PeriodEnd                      =  ISNULL(DATEADD(DAY, 1 , cc.PeriodEnd), x.LastDay) --Set to midnight next day; assume last period is open until the end of the month
FROM
   BeazleyIntelligenceDataContract.Outbound.vw_ClaimCenterAccountingPeriod cc
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName = cc.AccountingCalendarName
INNER JOIN
(
    SELECT
    AccountingPeriod            = d.[MonthName]
    ,LastDay                    = MAX(d.PK_Date)
    FROM
    ODS.DimDate d
    GROUP BY
    d.[MonthName]
) x ON
cc.AccountingPeriod = x.AccountingPeriod

UNION 

/*Create an unknown members to highlight that the Claim has the unknown member set for the AccountingCalendar  */
SELECT 
	FK_AccountingCalendar           = ac.PK_AccountingCalendar
	,AccountingPeriodName           = cc.AccountingPeriod + ' <=> ' + ac.AccountingCalendarName
	,PeriodStart                    = cc.PeriodStart
	,PeriodEnd                      = ISNULL(DATEADD(DAY, 1 , cc.PeriodEnd), x.LastDay) --Set to midnight next day; assume last period is open until the end of the month
FROM
   BeazleyIntelligenceDataContract.Outbound.vw_ClaimCenterAccountingPeriod cc
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName = 'N/A' AND cc.AccountingCalendarName = 'US Finance'
INNER JOIN
(
    SELECT
    AccountingPeriod            = d.[MonthName]
    ,LastDay                    = MAX(d.PK_Date)
    FROM
    ODS.DimDate d
    GROUP BY
    d.[MonthName]
) x ON
cc.AccountingPeriod = x.AccountingPeriod

INSERT INTO #AccountingPeriod

(
FK_AccountingCalendar
,AccountingPeriodName
,PeriodStart
,PeriodEnd
)
/*Get the accounting calendar from ClaimCenter MDS table*/
SELECT
FK_AccountingCalendar         
	,AccountingPeriodName        
	,PeriodStart                 
	,PeriodEnd         
FROM	(
SELECT 
	FK_AccountingCalendar           = ac.PK_AccountingCalendar
	,AccountingPeriodName           = cc.AccountingPeriod
	,PeriodStart                    = cc.PeriodStart
	,PeriodEnd                      =  ISNULL(DATEADD(DAY, 1 , cc.PeriodEnd), x.LastDay) --Set to midnight next day; assume last period is open until the end of the month
FROM
   Staging_MDS.MDS_Staging.ClaimCenterAccountingPeriod cc
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName = cc.NAME
INNER JOIN
(
    SELECT
    AccountingPeriod            = d.[MonthName]
    ,LastDay                    = MAX(d.PK_Date)
    FROM
    ODS.DimDate d
    GROUP BY
    d.[MonthName]
) x ON
cc.AccountingPeriod = x.AccountingPeriod

UNION 

/*Create an unknown members to highlight that the Claim has the unknown member set for the AccountingCalendar  */
SELECT 
	FK_AccountingCalendar           = ac.PK_AccountingCalendar
	,AccountingPeriodName           = cc.AccountingPeriod + ' <=> ' + ac.AccountingCalendarName
	,PeriodStart                    = cc.PeriodStart
	,PeriodEnd                      = ISNULL(DATEADD(DAY, 1 , cc.PeriodEnd), x.LastDay) --Set to midnight next day; assume last period is open until the end of the month
FROM
   Staging_MDS.MDS_Staging.ClaimCenterAccountingPeriod cc
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName = 'N/A' AND cc.Name = 'US Finance'
INNER JOIN
(
    SELECT
    AccountingPeriod            = d.[MonthName]
    ,LastDay                    = MAX(d.PK_Date)
    FROM
    ODS.DimDate d
    GROUP BY
    d.[MonthName]
) x ON
cc.AccountingPeriod = x.AccountingPeriod
)x
WHERE NOT EXISTS (SELECT 1 from #AccountingPeriod a where x.FK_AccountingCalendar = a.FK_AccountingCalendar and x.AccountingPeriodName = a.AccountingPeriodName)


--END 

/*For US policy we get the accounting calendar from BeazleyPro*/
;WITH USPeriod
AS
(
    SELECT
       AccountingPeriod                = a.Name
       ,EffectiveDate                  = a.EffectiveDate
       ,SequenceId                     = ROW_NUMBER() OVER (ORDER BY a.EffectiveDate ASC)
    FROM
        Staging_Matlock.Matlock_Staging.vw_AccountingPeriod a
) 

	   	 
INSERT INTO ODS.AccountingPeriod
(
    FK_AccountingCalendar
    ,AccountingPeriodName
    ,PeriodStart
    ,PeriodEnd
)

SELECT
   FK_AccountingCalendar           = ac.PK_AccountingCalendar
   ,AccountingPeriodName           = a1.AccountingPeriod
   ,PeriodStart                    = a1.EffectiveDate
   ,PeriodEnd                      = a2.EffectiveDate
FROM
   USPeriod a1
INNER JOIN
   USPeriod a2 
ON a1.SequenceId + 1 = a2.SequenceId
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName = 'US Policy'

UNION 

/*Get the accounting calendar from ClaimCenter MDS table*/

 

/*Create an unknown members to highlight that the Claim has the unknown member set for the AccountingCalendar  */
SELECT 
	FK_AccountingCalendar           
	,AccountingPeriodName           
	,PeriodStart                    
	,PeriodEnd                     
FROM #AccountingPeriod
UNION
/*For UK policy and SCM claim we use calendar months*/
SELECT
   FK_AccountingCalendar           = ac.PK_AccountingCalendar
   ,AccountingPeriodName           = d.[MonthName]
   ,PeriodStart                    = MIN(d.PK_Date)
   ,PeriodEnd                      = DATEADD(DAY, 1, MAX(d.PK_Date))
FROM
   ODS.DimDate d
INNER JOIN
   ODS.AccountingCalendar ac 
ON ac.AccountingCalendarName IN ('UK Policy', 'Lloyd’s Finance')
LEFT JOIN 
   ODS.AccountingPeriod ap 
ON ac.PK_AccountingCalendar = ap.FK_AccountingCalendar 
AND ap.AccountingPeriodName = d.[MonthName]
WHERE d.[MonthName] <> 'N/A' AND  ap.FK_AccountingCalendar is null
GROUP BY
ac.PK_AccountingCalendar
,d.[MonthName]

;

IF (OBJECT_ID('tempdb..#AccountingPeriod')) IS NOT NULL DROP TABLE #AccountingPeriod

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'AccountingPeriod';
GO



