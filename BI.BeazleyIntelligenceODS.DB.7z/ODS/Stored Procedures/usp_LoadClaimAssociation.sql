﻿
CREATE PROCEDURE [ODS].[usp_LoadClaimAssociation]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ClaimAssociation

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE FROM ODS.ClaimAssociation WHERE AssociationName NOT IN (SELECT DISTINCT AssociationName FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimAssociation  ) 

;MERGE ODS.ClaimAssociation  AS Target
USING (
		SELECT DISTINCT
		  IsUnknownMember		= 0
		 ,AssociationName       = COALESCE(ca.AssociationName,'Unknown')
		 ,AssociationReason     = COALESCE(ca.AssociationReason,'Unknown')

		FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimAssociation ca

		WHERE ca.SourceSystem = 'ClaimCenter'
		AND ISNULL(ca.AuditModifyDateTime, ca.AuditCreateDateTime) >= @LastAuditDate
	

		UNION

		SELECT
			 IsUnknownMember = 1
			,AssociationName        = 'N/A' 
		    ,AssociationReason      = 'N/A' 
			
		) as Source 
	ON (
		ISNULL(Source.AssociationName, 'Not Available') = ISNULL(Target.AssociationName, 'Not Available')
  	AND ISNULL(Source.AssociationReason, 'Not Available') = ISNULL(Target.AssociationReason, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
	)

WHEN MATCHED THEN
UPDATE SET
 target.AuditModifyDateTime	      = GETDATE()						
,target.AuditModifyDetails	      = 'Merge in ODS.usp_LoadClaimAssociation proc' 

WHEN NOT MATCHED BY TARGET THEN 
		INSERT([IsUnknownMember], [AssociationName], [AssociationReason], [AuditCreateDateTime], [AuditModifyDetails])
		VALUES(Source.[IsUnknownMember], Source.[AssociationName], Source.[AssociationReason], GETDATE(), 'New add in ODS.usp_LoadClaimAssociation proc')
;

    EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimAssociation';
