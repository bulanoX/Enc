﻿CREATE  PROCEDURE [ODS].[usp_LoadSectionAcquisitionCost]
AS

SET NOCOUNT ON

IF OBJECT_ID('tempdb..#InternalAcquisitionCost') IS NOT NULL
DROP TABLE #InternalAcquisitionCost

CREATE TABLE #InternalAcquisitionCost
(
    FK_Section                              bigint          NOT NULL
    ,FK_EntityPerspective                   bigint          NOT NULL
    ,FK_AcquisitionCostType                 varchar(255)    NOT NULL 
    ,TaxDescription                         nvarchar(255)   NOT NULL DEFAULT('N/A')
    ,InternalAcquisitionCostMultiplier      numeric(19,12)  NOT NULL
    ,TotalAcquisitionCostCap                numeric(19,12)  NULL    
    PRIMARY KEY (FK_Section, FK_EntityPerspective, FK_AcquisitionCostType, TaxDescription)
)

IF OBJECT_ID('tempdb..#ExternalAcquisitionCost') IS NOT NULL
DROP TABLE #ExternalAcquisitionCost

CREATE TABLE #ExternalAcquisitionCost
(
    FK_Section                              bigint          NOT NULL
    ,FK_EntityPerspective                   bigint          NOT NULL
    ,FK_AcquisitionCostType                 varchar(255)    NOT NULL
    ,TaxDescription                         nvarchar(255)   NOT NULL DEFAULT('N/A')
    ,ExternalAcquisitionCostMultiplier      numeric(19,12)  NOT NULL
    ,SequenceId                             int             NOT NULL
	,IsBBRGeneratedSection					BIT				NOT NULL DEFAULT(0)
    PRIMARY KEY (FK_Section, FK_EntityPerspective, FK_AcquisitionCostType, TaxDescription)
)

--First populate all the internal commissions, caps & exceptions
INSERT INTO #InternalAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
 --   ,TaxDescription
    ,InternalAcquisitionCostMultiplier
    ,TotalAcquisitionCostCap
)
SELECT
FK_Section                                  = s.PK_Section
,FK_EntityPerspective                       = ep.PK_EntityPerspective
,FK_AcquisitionCostType                     = act.PK_AcquisitionCostType
,InternalAcquisitionCostMultiplier          = ISNULL(iace.AcquisitionCostMultiplier, iac.AcquisitionCostMultiplier)
,TotalAcquisitionCostCap                    = ISNULL(iace.TotalAcquisitionCostCap, iac.TotalAcquisitionCostCap)

FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
INNER JOIN
ODS.EntityPerspective ep ON
sep.FK_EntityPerspective = ep.PK_EntityPerspective
INNER JOIN
ODS.TriFocus tf ON
s.FK_TriFocus = tf.PK_TriFocus
INNER JOIN
Staging_MDS.MDS_Staging.InternalAcquisitionCost iac ON
p.FK_YOA = iac.YOA
AND ep.EntityPerspective = iac.EntityPerspective
AND tf.DepartmentName    = iac.Department
AND s.CarrierIndicator = iac.CarrierIndicator
AND p.SourceSystem = iac.SourceSystem_Name
INNER JOIN
ODS.AcquisitionCostType act ON
iac.AcquisitionCostTypeCode = act.AcquisitionCostTypeCode
LEFT OUTER JOIN
Staging_MDS.MDS_Staging.InternalAcquisitionCostException iace ON
p.FK_YOA = iace.YOA
AND ep.EntityPerspective = iace.EntityPerspective
AND iac.AcquisitionCostTypeCode = iace.AcquisitionCostTypeCode
AND tf.TriFocusName = iace.TriFocus
AND p.SourceSystem = iace.SourceSystem_Name


/*Populate the external acquisition costs. For Eurobase sections, we want the largest value
to be SequenceId=1. We're going to use this later when it comes to reducing it by the amount of the 
internal acquisition cost*/
INSERT INTO #ExternalAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
 --   ,TaxDescription
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT 
FK_Section                              = s.PK_Section
,FK_EntityPerspective                   = sep.FK_EntityPerspective
,FK_AcquisitionCostType                 = act.PK_AcquisitionCostType
--,TaxDescription                         = saqc.TaxDescription
,ExternalAcquisitionCostMultiplier      = saqc.AcquisitionCostMultiplier
,SequenceId                             = ROW_NUMBER() OVER 
                                        (PARTITION BY s.PK_Section, sep.FK_EntityPerspective 
                                        ORDER BY 
                                        saqc.AcquisitionCostMultiplier DESC
                                        ,act.PK_AcquisitionCostType) --Split ties to make order deterministic
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
INNER JOIN
BeazleyIntelligenceDataContract.Outbound.vw_SectionAcquisitionCost saqc ON
s.SectionReference = saqc.SectionSourceId
INNER JOIN
ODS.AcquisitionCostType act ON
saqc.AcquisitionCostTypeCode = act.AcquisitionCostTypeCode
AND saqc.TaxDescription = act.TaxDescription
WHERE
p.SourceSystem = 'Eurobase'
--AND saqc.IsActive = 1
--AND Utility.udf_ProcessPercentage(pd.ded_pcnt, 0, 0, 0) IS NOT NULL --It is in Extractor now

/*Unirisx Policies*/
INSERT INTO #ExternalAcquisitionCost
(
     FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
    ,TaxDescription
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT
 FK_Section                         = s.PK_Section
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostType             = act.PK_AcquisitionCostType
,TaxDescription                     = aqc.TaxDescription
,ExternalAcquisitionCostMultiplier  = aqc.AcquisitionCostMultiplier
,SequenceId                         = 0

FROM ODS.Section s

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionEntityPerspective sep
ON s.PK_Section = sep.FK_Section

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionAcquisitionCost aqc
ON s.SectionReference = aqc.SectionSourceId

INNER JOIN ODS.AcquisitionCostType act 
ON aqc.AcquisitionCostTypeCode = act.AcquisitionCostTypeCode 
AND COALESCE(aqc.TaxDescription, 'N/A') = act.TaxDescription   

WHERE
p.SourceSystem IN ('Unirisx')
--AND aqc.IsActive = 1

/*Gamechanger & myBeazley Policies*/
INSERT INTO #ExternalAcquisitionCost
(
     FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT
 FK_Section                         = s.PK_Section
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostType             = act.PK_AcquisitionCostType
,ExternalAcquisitionCostMultiplier  = aqc.AcquisitionCostMultiplier
,SequenceId                         = 0

FROM ODS.Section s

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.SectionEntityPerspective sep
ON s.PK_Section = sep.FK_Section

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section  ds
ON s.SectionReference = ds.SectionReference

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionAcquisitionCost aqc
ON ds.SectionSourceId = aqc.SectionSourceId

INNER JOIN ODS.AcquisitionCostType act 
ON aqc.AcquisitionCostTypeCode = act.AcquisitionCostTypeCode 
 AND aqc.TaxDescription = act.TaxDescription
WHERE
p.SourceSystem IN ('Gamechanger', 'myBeazley')
--AND aqc.IsActive = 1

/*BeazleyPro Policies*/
INSERT INTO #ExternalAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT
FK_Section                          = nlpt.FK_Section
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostType             = act.PK_AcquisitionCostType
,ExternalAcquisitionCostMultiplier  = CASE
										WHEN s.Product IN ('Surety Quota Share', 'Universal Product Incubator-BPS Embedded') then max(s.ExternalAcquisitionCostMultiplier)
										ELSE SUM(nlpt.ExternalAcquisitionCostInOriginalCCY) / SUM(nlpt.GrossPremiumInOriginalCCY)
									 END
,SequenceId                         = 0
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
INNER JOIN
ODS.NonLloydsPremiumTransaction nlpt ON 
s.PK_Section = nlpt.FK_Section
INNER JOIN
ODS.AcquisitionCostType act ON 
act.AcquisitionCostTypeCode = 'B'
WHERE
p.SourceSystem = 'BeazleyPro'
AND p.IsQuote = 0
--AND 1 = (CASE 
--			WHEN s.Product = 'Universal Product Incubator-BPS Embedded' 
--			THEN (
--					CASE 
--							WHEN CAST(CURRENT_TIMESTAMP as date) > DATEADD(day,90,ExpiryDate) THEN 0 ELSE 1 END
--				)
--			WHEN s.Product = 'Surety Quota Share' 
--			THEN (
--					CASE	WHEN CAST(CURRENT_TIMESTAMP as date) > DATEADD(day,180,ExpiryDate) THEN 0 ELSE 1 END
--					)
--			ELSE 1		
--		END
--		)
GROUP BY
nlpt.FK_Section
,sep.FK_EntityPerspective
,act.PK_AcquisitionCostType
,s.Product
HAVING
SUM(nlpt.GrossPremiumInOriginalCCY) <> 0
AND ISNULL(SUM(nlpt.ExternalAcquisitionCostInOriginalCCY), 0) <> 0

/*Populate the external acquisition costs for dummy BBR sections*/
INSERT INTO #ExternalAcquisitionCost
(
    FK_Section
    ,FK_AcquisitionCostType
    ,FK_EntityPerspective
	,TaxDescription
    ,SequenceId
    ,ExternalAcquisitionCostMultiplier
	,IsBBRGeneratedSection
)
SELECT
FK_Section                              = s_bbr.PK_Section
,FK_AcquisitionCostType                 = eac.FK_AcquisitionCostType
,FK_EntityPerspective                   = eac.FK_EntityPerspective
,TaxDescription                         = eac.TaxDescription
,SequenceId                             = eac.SequenceId
,ExternalAcquisitionCostMultiplier      = eac.ExternalAcquisitionCostMultiplier
,IsBBRGeneratedSection					= 1											--BBR Dummy Section only
--,s.SourceSystem
FROM
#ExternalAcquisitionCost eac
INNER JOIN
ODS.Section s ON
eac.FK_Section = s.PK_Section
INNER JOIN
ODS.Section s_bbr ON
s_bbr.FK_BreachResponseParentSection = s.PK_Section

/*For BBR dummy section only. Generate dummy Combined View perspective for those Sections without Combined View but do have Eurobase View*/

-- BI-3714 - BAU - Amend the WEP exc LBS premium field logic for BBR dummy sections only | Part 2

DECLARE		@FK_EntityPerspectiveEurobaseView	int, 
			@FK_EntityPerspectiveCombinedView	int 

SELECT		@FK_EntityPerspectiveEurobaseView = PK_EntityPerspective 
FROM		Ods.EntityPerspective
WHERE		EntityPerspective = 'Eurobase View'

SELECT		@FK_EntityPerspectiveCombinedView = PK_EntityPerspective 
FROM		Ods.EntityPerspective
WHERE		EntityPerspective = 'Combined View'

INSERT INTO #ExternalAcquisitionCost(FK_Section, FK_EntityPerspective, FK_AcquisitionCostType, ExternalAcquisitionCostMultiplier, SequenceId, IsBBRGeneratedSection)
SELECT		x.FK_Section, @FK_EntityPerspectiveCombinedView, e.FK_AcquisitionCostType, e.ExternalAcquisitionCostMultiplier, e.SequenceId, e.IsBBRGeneratedSection
FROM		(	
			SELECT		DISTINCT FK_Section
			FROM		#ExternalAcquisitionCost
			WHERE		IsBBRGeneratedSection = 1
					AND FK_EntityPerspective = @FK_EntityPerspectiveEurobaseView

			EXCEPT		

			SELECT		DISTINCT	FK_Section
			FROM		#ExternalAcquisitionCost
			WHERE		IsBBRGeneratedSection = 1
					AND FK_EntityPerspective = @FK_EntityPerspectiveCombinedView
) x 
LEFT JOIN	#ExternalAcquisitionCost e
		ON	x.FK_Section = e.FK_Section AND e.FK_EntityPerspective = @FK_EntityPerspectiveEurobaseView


/*All others*/
INSERT INTO #ExternalAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT
FK_Section                          = s.PK_Section
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostType             = act.PK_AcquisitionCostType
,ExternalAcquisitionCostMultiplier  = s.ExternalAcquisitionCostMultiplier
,SequenceId                         = 0
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
INNER JOIN
ODS.AcquisitionCostType act ON 
act.AcquisitionCostTypeCode = 'B'
WHERE
s.ExternalAcquisitionCostMultiplier IS NOT NULL
AND NOT EXISTS
(
    SELECT
    1
    FROM
    #ExternalAcquisitionCost ea 
    WHERE
    ea.FK_Section = s.PK_Section
)

/*CIPS Sections receive a 5% commision and the insert is mandatory after all other are already generated as B for CIPS won't be created because of existance of Y*/ --BI-2235
INSERT INTO #ExternalAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
    ,ExternalAcquisitionCostMultiplier
    ,SequenceId
)
SELECT
FK_Section                          = s.PK_Section
,FK_EntityPerspective               = sep.FK_EntityPerspective
,FK_AcquisitionCostType             = act.PK_AcquisitionCostType
,ExternalAcquisitionCostMultiplier  = 0.05 --5% commision on CIPS Sections
,SequenceId                         = 0
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
ODS.SectionEntityPerspective sep ON
s.PK_Section = sep.FK_Section
INNER JOIN
ODS.AcquisitionCostType act ON 
act.AcquisitionCostTypeCode = 'Y'
WHERE
p.SourceSystem = 'CIPS'
AND s.InceptionDate <= CONVERT(DATETIME, '31/12/2021',105)

/*Populate the internal acquisition costs for dummy BBR sections*/
INSERT INTO #InternalAcquisitionCost
(
     FK_Section
    ,FK_AcquisitionCostType
    ,FK_EntityPerspective
    ,TotalAcquisitionCostCap
    ,InternalAcquisitionCostMultiplier
)
SELECT
FK_Section                              = s_bbr.PK_Section
,FK_AcquisitionCostType                 = iac.FK_AcquisitionCostType
,FK_EntityPerspective                   = iac.FK_EntityPerspective
,TotalAcquisitionCostCap                = iac.TotalAcquisitionCostCap
,InternalAcquisitionCostMultiplier      = iac.InternalAcquisitionCostMultiplier
FROM
#InternalAcquisitionCost iac
INNER JOIN
ODS.Section s ON
iac.FK_Section = s.PK_Section
INNER JOIN
ODS.Section s_bbr ON
s_bbr.FK_BreachResponseParentSection = s.PK_Section

/*For Eurobase sections, check that the sum of the internal commissions does not exceed
the largest value in Eurobase under booked under any commission type (this is the value we are going to reduce by
the amount of the internal commission, and we don't want the result to come out negative).
If the test fails, get rid of the internal commissions records - ideally this won't be required if and when
the Eurobase commissions are booked with the correct splits*/
DELETE ic
FROM
#InternalAcquisitionCost ic
INNER JOIN
(
    SELECT
    FK_Section                              = s.PK_Section
    ,FK_EntityPerspective                   = ic.FK_EntityPerspective
    ,InternalAcquisitionCostMultiplier      = SUM(ic.InternalAcquisitionCostMultiplier)
    FROM
    #InternalAcquisitionCost ic
    INNER JOIN
    ODS.Section s ON
    ic.FK_Section = s.PK_Section
    INNER JOIN
    ODS.Policy p ON
    s.FK_Policy = p.PK_Policy
    WHERE
    p.SourceSystem = 'Eurobase'
    GROUP BY
    s.PK_Section
    ,ic.FK_EntityPerspective
) x ON
ic.FK_Section = x.FK_Section
AND ic.FK_EntityPerspective = x.FK_EntityPerspective
LEFT OUTER JOIN
#ExternalAcquisitionCost eac ON
ic.FK_Section = eac.FK_Section
AND ic.FK_EntityPerspective = eac.FK_EntityPerspective
AND eac.SequenceId = 1
WHERE
x.InternalAcquisitionCostMultiplier > ISNULL(eac.ExternalAcquisitionCostMultiplier, 0)

/*Reduce the "external" acquistion cost by the internal acquisition cost amount. The result should not ever come out negative
,based on the test above*/
UPDATE eac SET
ExternalAcquisitionCostMultiplier       = eac.ExternalAcquisitionCostMultiplier - x.InternalAcquisitionCostMultiplier
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
#ExternalAcquisitionCost eac ON
s.PK_Section = eac.FK_Section
INNER JOIN
(
    SELECT
    FK_Section                              = iac.FK_Section
    ,FK_EntityPerspective                   = iac.FK_EntityPerspective
    ,InternalAcquisitionCostMultiplier      = SUM(iac.InternalAcquisitionCostMultiplier)
    FROM
    #InternalAcquisitionCost iac
    GROUP BY
    iac.FK_Section
    ,iac.FK_EntityPerspective
) x ON
eac.FK_Section = x.FK_Section
AND eac.FK_EntityPerspective = x.FK_EntityPerspective
WHERE
p.SourceSystem = 'Eurobase'
AND eac.SequenceId = 1

/*Apply the cap- we're capping per section here whereas we should really be capping per policy, but if
we want to store all the acquisition costs (internal + external) at section level, there is no real way to 
do that. Might be a good idea to refactor this some time to store the external & internal acquisition costs
at different grains*/
UPDATE iac SET
InternalAcquisitionCostMultiplier           = iac.TotalAcquisitionCostCap - x.ExternalAcquisitionCostMultiplier
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
INNER JOIN
#InternalAcquisitionCost iac ON
s.PK_Section = iac.FK_Section
INNER JOIN
(
    SELECT DISTINCT
    FK_Section                              = eac.FK_Section
    ,FK_EntityPerspective                   = eac.FK_EntityPerspective
    ,ExternalAcquisitionCostMultiplier      = SUM(eac.ExternalAcquisitionCostMultiplier)
    FROM
    #ExternalAcquisitionCost eac
    GROUP BY
    eac.FK_Section
    ,eac.FK_EntityPerspective
) x ON
iac.FK_Section = x.FK_Section
AND iac.FK_EntityPerspective = x.FK_EntityPerspective
WHERE
p.SourceSystem <> 'Eurobase'
AND iac.TotalAcquisitionCostCap IS NOT NULL
AND iac.InternalAcquisitionCostMultiplier + x.ExternalAcquisitionCostMultiplier > iac.TotalAcquisitionCostCap


IF (OBJECT_ID('tempdb..#SectionAcquisitionCost') IS NOT NULL)
DROP TABLE #SectionAcquisitionCost

CREATE TABLE #SectionAcquisitionCost
(
    [FK_Section]                [bigint] NOT NULL,
	[FK_EntityPerspective]      [bigint] NOT NULL,
	[FK_AcquisitionCostType]    [bigint] NOT NULL,
	[TaxDescription]			[nvarchar](255) NOT NULL DEFAULT ('N/A'),
	[AcquisitionCostMultiplier] [numeric](19, 12) NOT NULL,
	
)

INSERT INTO #SectionAcquisitionCost
(
    FK_Section
    ,FK_EntityPerspective
    ,FK_AcquisitionCostType
	,TaxDescription
    ,AcquisitionCostMultiplier
)
SELECT
FK_Section                      = eac.FK_Section
,FK_EntityPerspective           = eac.FK_EntityPerspective
,FK_AcquisitionCostType         = eac.FK_AcquisitionCostType
,TaxDescription					= eac.TaxDescription
,AcquisitionCostMultiplier      = eac.ExternalAcquisitionCostMultiplier
FROM
#ExternalAcquisitionCost eac
UNION ALL
SELECT
 FK_Section                     = iac.FK_Section
,FK_EntityPerspective           = iac.FK_EntityPerspective
,FK_AcquisitionCostType         = iac.FK_AcquisitionCostType
,TaxDescription					='N/A'
,AcquisitionCostMultiplier      = iac.InternalAcquisitionCostMultiplier
FROM
#InternalAcquisitionCost iac


MERGE ODS.SectionAcquisitionCost AS TARGET

USING #SectionAcquisitionCost AS SOURCE

 ON TARGET.FK_Section                = SOURCE.FK_Section
AND TARGET.FK_EntityPerspective      = SOURCE.FK_EntityPerspective
AND TARGET.FK_AcquisitionCostType    = SOURCE.FK_AcquisitionCostType
AND TARGET.TaxDescription			 = SOURCE.TaxDescription

WHEN MATCHED THEN

UPDATE SET 

  TARGET.FK_Section                   = SOURCE.FK_Section
 ,TARGET.FK_EntityPerspective         = SOURCE.FK_EntityPerspective
 ,TARGET.FK_AcquisitionCostType       = SOURCE.FK_AcquisitionCostType
 ,TARGET.TaxDescription				  = SOURCE.TaxDescription
 ,TARGET.AcquisitionCostMultiplier    = SOURCE.AcquisitionCostMultiplier
 ,TARGET.AuditModifyDateTime          = GETDATE()
 ,TARGET.AuditModifyDetails           = 'Merge in [ODS].[SectionAcquisitionCost] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 FK_Section
	,FK_EntityPerspective
	,FK_AcquisitionCostType
	,TaxDescription			
	,AcquisitionCostMultiplier
	,AuditModifyDetails
)
VALUES
(
	 SOURCE.FK_Section
	,SOURCE.FK_EntityPerspective
	,SOURCE.FK_AcquisitionCostType
	,SOURCE.TaxDescription		
	,SOURCE.AcquisitionCostMultiplier
	,'New in [ODS].[SectionAcquisitionCost] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

--Set a flag for BBR dummy sections
UPDATE		s
SET			IsBBRGeneratedSection = 1
FROM		Ods.Section s 
WHERE		s.PK_Section IN (SELECT FK_Section FROM #ExternalAcquisitionCost GROUP BY FK_Section)


IF OBJECT_ID('tempdb..#InternalAcquisitionCost') IS NOT NULL
DROP TABLE #InternalAcquisitionCost

IF OBJECT_ID('tempdb..#ExternalAcquisitionCost') IS NOT NULL
DROP TABLE #ExternalAcquisitionCost

IF (OBJECT_ID('tempdb..#SectionAcquisitionCost') IS NOT NULL)
DROP TABLE #SectionAcquisitionCost;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'SectionAcquisitionCost';
GO

