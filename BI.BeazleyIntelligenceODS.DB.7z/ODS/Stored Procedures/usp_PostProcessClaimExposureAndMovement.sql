﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_PostProcessClaimExposureAndMovement]
AS
BEGIN
	/*Last movement fields on ODS.ClaimExposure*/ 
	-- Steph has confirmed to proceed with removal of logic and output what is sent from CCv9 for LastMovementNarrative
	UPDATE ce SET
	FK_LastMovement                     = cm_lm.PK_ClaimMovement
	--,LastMovementNarrative              = cm_lm.MovementNarrative
	,LastMovementDate                   = cm_lm.MovementDate
	,FK_LastMovementOriginalCurrency    = cm_lm.FK_OriginalCurrency
	,FK_LastMovementSettlementCurrency  = cm_lm.FK_SettlementCurrency
	,FK_LastMovementLocalCurrency       = cm_lm.FK_LocalCurrency
	,LastMovementFeesOnlyEntry          = cm_lm.FeesOnlyEntry
	FROM     
	ODS.ClaimExposure ce 
	INNER JOIN
	(
		SELECT
		PK_ClaimMovement                = cm.PK_ClaimMovement
		,FK_ClaimExposure               = cm.FK_ClaimExposure
		--,MovementNarrative              = cm.MovementNarrative
		,MovementDate                   = cm.MovementDate
		,FK_OriginalCurrency            = cm.FK_OriginalCurrency
		,FK_SettlementCurrency          = cm.FK_SettlementCurrency
		,FK_LocalCurrency               = cm.FK_LocalCurrency
		,FeesOnlyEntry                  = cm.FeesOnlyEntry
		,SequenceNumber                 = ROW_NUMBER() OVER(
											PARTITION BY FK_ClaimExposure
											ORDER BY cm.MovementDate DESC, cm.MovementGroupSequenceId DESC, cm.PK_ClaimMovement) -- the latter was added to have a "technical" tie braker
		FROM
		ODS.ClaimMovement cm
		INNER JOIN
		ODS.SettlementCurrency sc ON
		cm.FK_SettlementCurrency = sc.PK_SettlementCurrency
	) cm_lm ON
	ce.PK_ClaimExposure = cm_lm.FK_ClaimExposure
	AND cm_lm.SequenceNumber = 1

	/*Update last movement line multiplier*/
	UPDATE ce SET
	LastMovementLineMultiplier = ISNULL(cm_line.LineMultiplier, 1)
	FROM
	ODS.ClaimExposure ce
	LEFT OUTER JOIN
	(
		SELECT
		cml.FK_ClaimMovement                                    AS FK_ClaimMovement
		,ISNULL(NULLIF(SUM(cml.LineMultiplier),0),1)            AS LineMultiplier
		FROM
		ODS.ClaimMovementLine cml
		GROUP BY
		cml.FK_ClaimMovement
	) cm_line ON
	ce.FK_LastMovement = cm_line.FK_ClaimMovement

	/***************************************************************************************************************/
	-- Update FK_ClaimMovementEstimate with the closest claim estimate values related to each claim movement record
	/***************************************************************************************************************/
	--UPDATE claimov

	--SET claimov.FK_ClaimEstimate = claimes.PK_ClaimEstimate
   
	--FROM   ODS.ClaimMovement claimov

	--CROSS APPLY (
	--			 SELECT TOP 1 claimes.PK_ClaimEstimate
	--			 FROM ODS.ClaimEstimate claimes
	--			 WHERE     claimes.FK_ClaimExposure = claimov.FK_ClaimExposure
	--				   AND claimes.FK_CreateDate <= claimov.FK_MovementPeriod --Use the keys to pick up everything on the same day, regardless of time
	--			 ORDER BY claimes.CreateDate DESC                    
	--			 ) claimes  

END