﻿							
CREATE PROCEDURE [ODS].[usp_LoadConditionType]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ConditionType
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE FROM ODS.ConditionType WHERE ConditionTypeCode NOT IN (SELECT  LTRIM(RTRIM(ConditionCode)) FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionConditions) AND IsUnknownMember  = 0

;MERGE ODS.ConditionType  AS Target
USING (
	  
		SELECT 
		 IsUnknownMember                 = 0
		,ConditionTypeCode	= LTRIM(RTRIM(r.ConditionCode))
		,ConditionTypeName	= r.ConditionDescription
		FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionConditions r
		WHERE ISNULL(ConditionCode,'') <> '' 
		AND ISNULL(r.AuditModifyDateTime,r.AuditCreateDateTime) >= @LastAuditDate
		GROUP BY r.ConditionCode , r.ConditionDescription
	
		UNION

		SELECT
			 IsUnknownMember                 = 1 
			,ConditionTypeCode               = 'N/A' 
			,ConditionTypeName			     = 'N/A'
			
		) as Source 
	ON (
		 ISNULL(Source.ConditionTypeCode, 'Not Available') = ISNULL(Target.ConditionTypeCode, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
	)
WHEN MATCHED THEN UPDATE
	SET Target.[ConditionTypeName]				= Source.[ConditionTypeName]
	,Target.AuditModifyDateTime			= GETDATE()						
	,Target.AuditModifyDetails			= 'Merge in [ODS].[ConditionType] table' 
WHEN NOT MATCHED THEN 
		INSERT([IsUnknownMember], [ConditionTypeCode], [ConditionTypeName],AuditCreateDateTime	,AuditModifyDetails)
		VALUES(Source.[IsUnknownMember], Source.[ConditionTypeCode], Source.[ConditionTypeName], GETDATE() ,'New add in ODS.usp_LoadConditionType proc'	);


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ConditionType';

