﻿CREATE PROCEDURE
[ODS].[usp_LoadLPSOTransaction]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#LPSOTransactionWorking') IS NOT NULL)
DROP TABLE #LPSOTransactionWorking

CREATE TABLE #LPSOTransactionWorking
(
    GroupKey									  BIGINT          NOT NULL
    ,SigningDate								  DATETIME        NOT NULL
    ,SigningNumber								  INT             NOT NULL
	,SigningBureauVersionNumber                   INT             NULL
    ,BrokerSigningDate							  DATETIME        NULL
    ,BrokerSigningNumber						  INT             NULL
    ,ProcessingDate								  DATETIME        NULL
    ,ProcessingPeriodDate						  DATETIME        NULL
    ,SettlementDate								  DATETIME        NULL
    ,ActualPaymentDate							  DATETIME        NULL
    ,CategoryCode								  INT             NOT NULL
	,Category									  VARCHAR(255)    NOT NULL 
    ,BusinessCategoryCode						  VARCHAR(15)     NULL
	,BusinessCategory							  VARCHAR(255)    NULL
    ,RiskClassCode								  VARCHAR(15)     NULL
	,RiskClass									  VARCHAR(255)    NULL
    ,FilCode									  VARCHAR(15)     NULL
    ,Fil										  VARCHAR(255)    NULL
	,DTICode									  VARCHAR(15)     NULL
    ,QualCatCode								  VARCHAR(1)      NULL
    ,QualCat									  VARCHAR(255)    NULL
	,GQDTransactionTypeCode						  VARCHAR(255)    NULL
    ,OriginalCCY								  VARCHAR(15)     NULL
    ,AmountInSettlementCCY						  NUMERIC(38,12)  NOT NULL
	,AmountExcIPTOverseasTaxInSettlementCCY		  NUMERIC(38,12)  
    ,VATAmountInSettlementCCY					  NUMERIC(38,12)  NOT NULL
    ,DelinkedAmountInSettlementCCY				  NUMERIC(38,12)  NOT NULL
	,IPTOverseasTax								  NUMERIC(38, 12) NULL
	,IPTUKTax									  NUMERIC(38, 12) NULL
    ,OriginalCCYToSettlementCCYRate				  NUMERIC(19,12)  NOT NULL
    --Treat + and - as separate totals, because otherwise we lose information when the sum is 0
    ,PositiveAmountInOriginalCCY				  NUMERIC(38,12)  NULL
	,PositiveAmountExcIPTOverseasTaxInOriginalCCY NUMERIC(38,12)  NULL
    ,PositiveVATAmountInOriginalCCY				  NUMERIC(38,12)  NULL
    ,PositiveDelinkedAmountInOriginalCCY		  NUMERIC(38,12)  NULL
	,PositiveIPTOverseasTaxAmountInOriginalCCY	  NUMERIC(38, 12) NULL
	,PositiveIPTUKTaxAmountInOriginalCCY		  NUMERIC(38, 12) NULL
    ,NegativeAmountInOriginalCCY				  NUMERIC(38,12)  NULL
	,NegativeAmountExcIPTOverseasTaxInOriginalCCY NUMERIC(38,12)  NULL
    ,NegativeVATAmountInOriginalCCY				  NUMERIC(38,12)  NULL
    ,NegativeDelinkedAmountInOriginalCCY		  NUMERIC(38,12)  NULL
	,NegativeIPTOverseasTaxAmountInOriginalCCY	  NUMERIC(38, 12) NULL
	,NegativeIPTUKTaxAmountInOriginalCCY		  NUMERIC(38, 12) NULL
    ,SectionReference							  VARCHAR(255)    NOT NULL
    ,SyndicateNumber							  INT             NOT NULL
    ,SettlementCCY								  VARCHAR(255)    NOT NULL
    ,OriginalAcquisitionCostMultiplier			  NUMERIC(19,12)  NULL
    ,ExternalAcquisitionCostMultiplier			  NUMERIC(19,12)  NOT NULL
    ,InternalAcquisitionCostMultiplier			  NUMERIC(19,12)  NOT NULL
    ,LPSOBrokerReference						  VARCHAR (255)   NULL
    ,FK_YOA										  BIGINT          NOT NULL
    ,FK_ClaimExposure							  BIGINT          NULL
)

/*Working table*/
INSERT INTO #LPSOTransactionWorking
(
    GroupKey
    ,SigningDate
    ,SigningNumber
    ,SigningBureauVersionNumber
    ,BrokerSigningDate
    ,BrokerSigningNumber
    ,ProcessingDate
    ,ProcessingPeriodDate
    ,SettlementDate
    ,ActualPaymentDate
    ,CategoryCode
	,Category
    ,BusinessCategoryCode
	,BusinessCategory
    ,RiskClassCode
	,RiskClass
    ,FilCode
	,Fil
    ,DTICode
    ,QualCatCode	
	,QualCat
	,GQDTransactionTypeCode
    ,OriginalCCY
    ,OriginalCCYToSettlementCCYRate
    ,AmountInSettlementCCY
    ,VATAmountInSettlementCCY
    ,DelinkedAmountInSettlementCCY
	,IPTOverseasTax                        
	,IPTUKTax                              
    ,SectionReference
    ,SyndicateNumber
    ,SettlementCCY
    ,OriginalAcquisitionCostMultiplier
    ,ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier
	,LPSOBrokerReference
    ,FK_YOA
    ,FK_ClaimExposure
)
SELECT 
GroupKey                                = 0
,SigningDate                            = fte.SigningDate 
,SigningNumber                          = fte.SigningNumber 
,SigningBureauVersionNumber             = fte.SigningBureauVersionNumber
,BrokerSigningDate                      = fte.BrokerSigningDate 
,BrokerSigningNumber                    = fte.BrokerSigningNumber
,ProcessingDate                         = fte.ProcessingDate 
,ProcessingPeriodDate                   = fte.ProcessingPeriodDate 
,SettlementDate                         = ft.SettlementDate 
,ActualPaymentDate                      = fte.ActualPaymentDate 
,CategoryCode                           = fte.CategoryCode 
,Category                               = fte.Category
,BusinessCategoryCode                   = fte.BusinessCategoryCode
,BusinessCategory                       = fte.BusinessCategory
,RiskClassCode                          = fte.RiskClassCode
,RiskClass                              = fte.RiskClass
,FilCode                                = fte.FilCode
,Fil                                    = fte.Fil
,DTICode                                = fte.DTICode
,QualCatCode                            = fte.QualCatCode
,QualCat                                = fte.QualCat
,GQDTransactionTypeCode                 = fte.GQDTransactionTypeCode
,OriginalCCY                            = ft.OriginalCurrency
,OriginalCCYToSettlementCCYRate         = ft.OriginalCCYToSettlementCCYRate 
,AmountInSettlementCCY                  = fte.AmountInSettlementCCY 
,VATAmountInSettlementCCY               = fte.VATAmountInSettlementCCY 
,DelinkedAmountInSettlementCCY          = fte.DelinkedAmountInSettlementCCY
,IPTOverseasTax                         = fte.IPTOverseasTax
,IPTUKTax                               = fte.IPTUKTax
,SectionReference                       = ft.SectionReference
,SyndicateNumber                        = fte.SyndicateNumber
,SettlementCCY                          = ft.SettlementCurrency
,OriginalAcquisitionCostMultiplier      = fte.OriginalAcquisitionCostMultiplier 
                                          
,ExternalAcquisitionCostMultiplier      = 0 --Set later
,InternalAcquisitionCostMultiplier      = 0 --Set later
,LPSOBrokerReference					= fte.LPSOBrokerReference
,FK_YOA                                 = ISNULL(yoa.PK_YOA, 0)
,FK_ClaimExposure                       = ce.PK_ClaimExposure
FROM
BeazleyIntelligenceDataContract.Outbound.vw_FinancialTransaction ft with (nolock) 
INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_FinancialTransactionExtension fte with (nolock) ON
fte.TransactionSourceId = ft.TransactionSourceId
LEFT OUTER JOIN
ODS.YOA yoa with (nolock) ON
fte.YearOfAccount = yoa.PK_YOA
LEFT OUTER JOIN
ODS.ClaimExposure ce with (nolock) ON
fte.ClaimExposureSourceId = ce.SCMReference			--Changed for CCv9 - used to be:	REPLACE(fte.ClaimExposureSourceId, fte.OriginatingBureau, '') = ce.SCMReference
													--									AND fte.OriginatingBureau = ce.OriginatingBureau
WHERE ft.SourceSystem = 'Eurobase'
--AND ft.IsActive = 1



CREATE NONCLUSTERED INDEX IX_TMP_LPSOTransactionWorking
ON #LPSOTransactionWorking ([CategoryCode])
INCLUDE ([AmountInSettlementCCY],[VATAmountInSettlementCCY],[DelinkedAmountInSettlementCCY],[SectionReference])

CREATE NONCLUSTERED INDEX IX_TMP_LPSOTransactionWorking2
ON #LPSOTransactionWorking ([SectionReference])

/*Dummy BBR sections 
  Apply the BBR multipliers*/
INSERT INTO #LPSOTransactionWorking
(
    GroupKey
    ,SigningDate
    ,SigningNumber
    ,SigningBureauVersionNumber
    ,BrokerSigningDate
    ,BrokerSigningNumber
    ,ProcessingDate
    ,ProcessingPeriodDate
    ,CategoryCode
	,Category
    ,BusinessCategoryCode
	,BusinessCategory
    ,RiskClassCode
	,RiskClass
    ,FilCode
	,Fil
    ,DTICode
    ,QualCatCode
	,QualCat
	,GQDTransactionTypeCode
    ,OriginalCCY
    ,OriginalCCYToSettlementCCYRate
    ,AmountInSettlementCCY
    ,VATAmountInSettlementCCY
    ,DelinkedAmountInSettlementCCY
	,IPTOverseasTax                        
	,IPTUKTax                               
    ,SectionReference
    ,SyndicateNumber
    ,SettlementCCY
    ,OriginalAcquisitionCostMultiplier
    ,ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier
	,LPSOBrokerReference
    ,FK_YOA
    ,FK_ClaimExposure
)
SELECT
 GroupKey                               = ltw.GroupKey
,SigningDate                            = ltw.SigningDate
,SigningNumber                          = ltw.SigningNumber
,SigningBureauVersionNumber             = ltw.SigningBureauVersionNumber
,BrokerSigningDate                      = ltw.BrokerSigningDate
,BrokerSigningNumber                    = ltw.BrokerSigningNumber
,ProcessingDate                         = ltw.ProcessingDate
,ProcessingPeriodDate                   = ltw.ProcessingPeriodDate
,CategoryCode                           = ltw.CategoryCode
,Category                               = ltw.Category
,BusinessCategoryCode                   = ltw.BusinessCategoryCode
,BusinessCategory                       = ltw.BusinessCategory
,RiskClassCode                          = ltw.RiskClassCode --Check if this needs to change
,RiskClass                              = ltw.RiskClass
,FilCode                                = ltw.FilCode
,Fil                                    = ltw.Fil
,DTICode                                = ltw.DTICode
,QualCatCode                            = ltw.QualCatCode
,QualCat                                = ltw.QualCat
,GQDTransactionTypeCode                 = ltw.GQDTransactionTypeCode
,OriginalCCY                            = ltw.OriginalCCY
,OriginalCCYToSettlementCCYRate         = ltw.OriginalCCYToSettlementCCYRate
,AmountInSettlementCCY                  = ltw.AmountInSettlementCCY 
,VATAmountInSettlementCCY               = ltw.VATAmountInSettlementCCY
,DelinkedAmountInSettlementCCY          = ltw.DelinkedAmountInSettlementCCY 
,IPTOverseasTax                         = ltw.IPTOverseasTax
,IPTUKTax                               = ltw.IPTUKTax
,SectionReference                       = s_bbr.SectionReference
,SyndicateNumber                        = ltw.SyndicateNumber
,SettlementCCY                          = ltw.SettlementCCY
,OriginalAcquisitionCostMultiplier      = ltw.OriginalAcquisitionCostMultiplier
,ExternalAcquisitionCostMultiplier      = ltw.ExternalAcquisitionCostMultiplier
,InternalAcquisitionCostMultiplier      = ltw.InternalAcquisitionCostMultiplier
,LPSOBrokerReference					= ltw.LPSOBrokerReference
,FK_YOA                                 = ltw.FK_YOA
,FK_ClaimExposure                       = ltw.FK_ClaimExposure
FROM
#LPSOTransactionWorking ltw
INNER JOIN
ODS.Section s with (nolock) ON
ltw.SectionReference = s.SectionReference
INNER JOIN
ODS.Section s_bbr with (nolock) ON
s_bbr.FK_BreachResponseParentSection = s.PK_Section

/*Apply the BBR multipliers*/
UPDATE lt SET
AmountInSettlementCCY           = lt.AmountInSettlementCCY              * s.BreachResponseMultiplier
,VATAmountInSettlementCCY       = lt.VATAmountInSettlementCCY           * s.BreachResponseMultiplier
,DelinkedAmountInSettlementCCY  = lt.DelinkedAmountInSettlementCCY      * s.BreachResponseMultiplier
,IPTOverseasTax					= lt.IPTOverseasTax				        * s.BreachResponseMultiplier		
,IPTUKTax						= lt.IPTUKTax					        * s.BreachResponseMultiplier		
FROM
#LPSOTransactionWorking lt
INNER JOIN
ODS.Section s ON
lt.SectionReference = s.SectionReference
WHERE
s.BreachResponseMultiplier IS NOT NULL


/*Set or default the external multiplier and set the internal multiplier
BUSA SL signings prior to 2011 included internal commissions*/
UPDATE lt SET
ExternalAcquisitionCostMultiplier       = CASE 
                                            WHEN 
                                            tf.DepartmentName = 'Specialty Lines' AND s.CarrierIndicator = 'BUSA' AND s.FK_YOA < 2011
                                            AND lt.OriginalAcquisitionCostMultiplier IS NOT NULL
                                            AND lt.OriginalAcquisitionCostMultiplier > x.InternalAcquisitionCostMultiplier
                                            THEN
                                            lt.OriginalAcquisitionCostMultiplier - x.InternalAcquisitionCostMultiplier
                                            ELSE
                                            coalesce(lt.OriginalAcquisitionCostMultiplier, y.ExternalAcquisitionCostMultiplier,0)
                                          END
,InternalAcquisitionCostMultiplier      = x.InternalAcquisitionCostMultiplier
FROM
#LPSOTransactionWorking lt
INNER JOIN
ODS.Section s with (nolock) ON
lt.SectionReference = s.SectionReference
INNER JOIN 
(
    SELECT
    FK_Section                              = sep.FK_Section
    ,InternalAcquisitionCostMultiplier      = sep.InternalAcquisitionCostMultiplier
    FROM    
    ODS.SectionEntityPerspective sep with (nolock) 
    INNER JOIN
    ODS.EntityPerspective ep with (nolock) ON
    sep.FK_EntityPerspective = ep.PK_EntityPerspective
    AND ep.EntityPerspective = 'Eurobase View'
) x ON
s.PK_Section = x.FK_Section
INNER JOIN
ODS.TriFocus tf with (nolock) ON
s.FK_TriFocus = tf.PK_TriFocus
LEFT OUTER JOIN
(
    SELECT  
    FK_Section                              = s.PK_Section                     
    ,InternalAcquisitionCostMultiplier      = sep.InternalAcquisitionCostMultiplier
	,[AcquisitionCostTypeDescription]
	,ExternalAcquisitionCostMultiplier
    FROM
    ODS.Section  s       with (nolock)
    INNER JOIN
    ODS.SectionEntityPerspective sep with (nolock) ON
    s.PK_Section = sep.FK_Section
    INNER JOIN
    ODS.EntityPerspective ep with (nolock) ON
    sep.FK_EntityPerspective = ep.PK_EntityPerspective
    AND ep.EntityPerspective = 'Eurobase View'
	INNER JOIN ODS.SectionAcquisitionCost sac	with (nolock) 
	on s.PK_Section=sac.FK_Section
	INNER JOIN ODS.AcquisitionCostType act with (nolock) 
	on sac.FK_AcquisitionCostType=act.PK_AcquisitionCostType
    AND sac.TaxDescription = act.TaxDescription
	where [AcquisitionCostTypeDescription] like 'BROKERAGE'
) y ON
s.PK_Section = y.FK_Section

/*For premium transactions, gross up acquisition costs*/
UPDATE lt SET
AmountInSettlementCCY           		= lt.AmountInSettlementCCY          / (1 - lt.ExternalAcquisitionCostMultiplier - lt.InternalAcquisitionCostMultiplier)
,VATAmountInSettlementCCY       		= lt.VATAmountInSettlementCCY       / (1 - lt.ExternalAcquisitionCostMultiplier - lt.InternalAcquisitionCostMultiplier)
,DelinkedAmountInSettlementCCY  		= lt.DelinkedAmountInSettlementCCY  / (1 - lt.ExternalAcquisitionCostMultiplier - lt.InternalAcquisitionCostMultiplier)
,AmountExcIPTOverseasTaxInSettlementCCY = (lt.AmountInSettlementCCY - ISNULL(lt.IPTOverseasTax, 0)) 
												/ (1 - lt.ExternalAcquisitionCostMultiplier - lt.InternalAcquisitionCostMultiplier)
FROM
#LPSOTransactionWorking lt
WHERE
lt.CategoryCode IN (1, 2, 3)

/*Convert settlement currency amounts to original currency and populate +/- fields*/
UPDATE lt SET
PositiveAmountInOriginalCCY                     = CASE WHEN lt.AmountInSettlementCCY > 0            		THEN lt.AmountInSettlementCCY           		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveVATAmountInOriginalCCY                 = CASE WHEN lt.VATAmountInSettlementCCY > 0         		THEN lt.VATAmountInSettlementCCY        		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveDelinkedAmountInOriginalCCY            = CASE WHEN lt.DelinkedAmountInSettlementCCY > 0    		THEN lt.DelinkedAmountInSettlementCCY   		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveIPTOverseasTaxAmountInOriginalCCY      = CASE WHEN lt.IPTOverseasTax > 0							THEN lt.IPTOverseasTax				    		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveIPTUKTaxAmountInOriginalCCY	        = CASE WHEN lt.IPTUKTax > 0									THEN lt.IPTUKTax					    		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,PositiveAmountExcIPTOverseasTaxInOriginalCCY	= CASE WHEN lt.AmountExcIPTOverseasTaxInSettlementCCY > 0   THEN lt.AmountExcIPTOverseasTaxInSettlementCCY	* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeAmountInOriginalCCY                    = CASE WHEN lt.AmountInSettlementCCY < 0            		THEN lt.AmountInSettlementCCY           		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeVATAmountInOriginalCCY                 = CASE WHEN lt.VATAmountInSettlementCCY < 0         		THEN lt.VATAmountInSettlementCCY        		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeDelinkedAmountInOriginalCCY            = CASE WHEN lt.DelinkedAmountInSettlementCCY < 0    		THEN lt.DelinkedAmountInSettlementCCY   		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeIPTOverseasTaxAmountInOriginalCCY      = CASE WHEN lt.IPTOverseasTax < 0							THEN lt.IPTOverseasTax				    		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeIPTUKTaxAmountInOriginalCCY	        = CASE WHEN lt.IPTUKTax < 0									THEN lt.IPTUKTax					    		* lt.OriginalCCYToSettlementCCYRate ELSE 0 END
,NegativeAmountExcIPTOverseasTaxInOriginalCCY	= CASE WHEN lt.AmountExcIPTOverseasTaxInSettlementCCY < 0   THEN lt.AmountExcIPTOverseasTaxInSettlementCCY  * lt.OriginalCCYToSettlementCCYRate ELSE 0 END
FROM
#LPSOTransactionWorking lt

UPDATE lt SET
GroupKey        =       CONVERT(BIGINT,HASHBYTES('SHA2_256',--Utility.udf_ComputeIdentity
                        (
                            lt.SectionReference
                            + '|~|' + ISNULL(CONVERT(varchar, lt.SigningDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.SigningNumber AS varchar(50)), '')
                            + '|~|' + ISNULL(CAST(lt.SigningBureauVersionNumber AS varchar(50)), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.BrokerSigningDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.BrokerSigningNumber AS varchar(50)), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ProcessingDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ProcessingPeriodDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.SettlementDate, 120), '')
                            + '|~|' + ISNULL(CONVERT(varchar, lt.ActualPaymentDate, 120), '')
                            + '|~|' + ISNULL(CAST(lt.CategoryCode AS varchar(50)), '')
                            + '|~|' + ISNULL(lt.BusinessCategoryCode, '')
                            + '|~|' + ISNULL(lt.RiskClassCode, '')
                            + '|~|' + ISNULL(lt.OriginalCCY, '')
                            + '|~|' + ISNULL(lt.FilCode, '')
                            + '|~|' + ISNULL(lt.DTICode, '')
                            + '|~|' + ISNULL(lt.QualCatCode, '')
                            + '|~|' + ISNULL(CAST(lt.OriginalCCYToSettlementCCYRate AS varchar(50)), '')
                            + '|~|' + ISNULL(lt.SettlementCCY, '')
                            + '|~|' + ISNULL(CAST(lt.FK_YOA AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.FK_ClaimExposure AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.ExternalAcquisitionCostMultiplier AS varchar(255)), '')
                            + '|~|' + ISNULL(CAST(lt.InternalAcquisitionCostMultiplier AS varchar(255)), '')
                       )))-- , 0)
FROM
#LPSOTransactionWorking lt

CREATE INDEX IX_tmpLPSOTransactionWorking ON #LPSOTransactionWorking (GroupKey)


ALTER TABLE ODS.LPSOTransaction NOCHECK CONSTRAINT ALL
--Grouping on GroupKey guarantees unique values for all the fields due to the way that GroupKey is generated,
--so we use MAX() to take one of the values

MERGE ODS.LPSOTransaction AS TARGET
USING(
SELECT 
PK_LPSOTransaction							  = x.PK_LPSOTransaction
,SigningDate								  = MAX(x.SigningDate)
,SigningNumber								  = MAX(x.SigningNumber)
,SigningBureauVersionNumber                   = MAX(x.SigningBureauVersionNumber)
,BrokerSigningDate							  = MAX(x.BrokerSigningDate)
,BrokerSigningNumber						  = MAX(x.BrokerSigningNumber)
,ProcessingDate								  = MAX(x.ProcessingDate)
,ProcessingPeriodDate						  = MAX(x.ProcessingPeriodDate)
,SettlementDate								  = MAX(x.SettlementDate)
,ActualPaymentDate							  = MAX(x.ActualPaymentDate)
,CategoryCode								  = MAX(x.CategoryCode)
,Category									  = MAX(x.Category)
,BusinessCategoryCode						  = MAX(x.BusinessCategoryCode)
,BusinessCategory							  = MAX(x.BusinessCategory)
,RiskClassCode								  = MAX(x.RiskClassCode)
,RiskClass									  = MAX(x.RiskClass)
,FilCode									  = MAX(x.FilCode)
,Fil										  = MAX(x.Fil)
,DTICode									  = MAX(x.DTICode)
,QualCatCode								  = MAX(x.QualCatCode)
,QualCat									  = MAX(x.QualCat)
,OriginalCCYToSettlementCCYRate				  = MAX(x.OriginalCCYToSettlementCCYRate)
,PositiveAmountInOriginalCCY				  = SUM(x.PositiveAmountInOriginalCCY)				/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,PositiveVATAmountInOriginalCCY				  = SUM(x.PositiveVATAmountInOriginalCCY)				/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,PositiveDelinkedAmountInOriginalCCY		  = SUM(x.PositiveDelinkedAmountInOriginalCCY)		/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,PositiveIPTOverseasTaxAmountInOriginalCCY	  = SUM(x.PositiveIPTOverseasTaxAmountInOriginalCCY)	/ MAX(s.TotalWrittenIfNotSignedMultiplier)	
,PositiveIPTUKTaxAmountInOriginalCCY		  = SUM(x.PositiveIPTUKTaxAmountInOriginalCCY)		/ MAX(s.TotalWrittenIfNotSignedMultiplier)	
,PositiveAmountExcIPTOverseasTaxInOriginalCCY = SUM(x.PositiveAmountExcIPTOverseasTaxInOriginalCCY)	/ MAX(s.TotalWrittenIfNotSignedMultiplier)	
,NegativeAmountInOriginalCCY				  = SUM(x.NegativeAmountInOriginalCCY)				/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,NegativeVATAmountInOriginalCCY				  = SUM(x.NegativeVATAmountInOriginalCCY)				/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,NegativeDelinkedAmountInOriginalCCY		  = SUM(x.NegativeDelinkedAmountInOriginalCCY)		/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,NegativeIPTOverseasTaxAmountInOriginalCCY	  = SUM(x.NegativeIPTOverseasTaxAmountInOriginalCCY)	/ MAX(s.TotalWrittenIfNotSignedMultiplier)	
,NegativeIPTUKTaxAmountInOriginalCCY		  = SUM(x.NegativeIPTUKTaxAmountInOriginalCCY)		/ MAX(s.TotalWrittenIfNotSignedMultiplier)
,NegativeAmountExcIPTOverseasTaxInOriginalCCY = SUM(x.NegativeAmountExcIPTOverseasTaxInOriginalCCY)	/ MAX(s.TotalWrittenIfNotSignedMultiplier)	
,GQDDate									  = MAX(x.GQDDate)
,ExternalAcquisitionCostMultiplier			  = MAX(x.ExternalAcquisitionCostMultiplier)
,InternalAcquisitionCostMultiplier			  = MAX(x.InternalAcquisitionCostMultiplier)
,FK_Section									  = MAX(x.FK_Section)
,FK_SettlementCurrency						  = MAX(x.FK_SettlementCurrency)
,FK_OriginalCurrency						  = MAX(x.FK_OriginalCurrency)
,FK_YOA										  = MAX(x.FK_YOA)
,FK_GQDTransactionType						  = MAX(x.FK_GQDTransactionType)
,SpecialPurposeSyndicateApplies				  = CAST(MAX(CAST(s.SpecialPurposeSyndicateApplies AS int)) AS bit)
,LPSOBrokerReference						  = MAX(x.LPSOBrokerReference)
,FK_DevelopmentPeriod						  = MAX(x.FK_DevelopmentPeriod)
,FK_ClaimExposure							  = MAX(x.FK_ClaimExposure)
FROM
(
    SELECT
    /*Utility functions inlined in the interests of performance*/
    PK_LPSOTransaction                            = lw.GroupKey
    ,SigningDate                                  = lw.SigningDate
    ,SigningNumber                                = lw.SigningNumber
    ,SigningBureauVersionNumber                   = lw.SigningBureauVersionNumber
    ,BrokerSigningDate                            = lw.BrokerSigningDate
    ,BrokerSigningNumber                          = lw.BrokerSigningNumber
    ,ProcessingDate                               = lw.ProcessingDate
    ,ProcessingPeriodDate                         = lw.ProcessingPeriodDate
    ,SettlementDate                               = lw.SettlementDate
    ,ActualPaymentDate                            = lw.ActualPaymentDate
    ,CategoryCode                                 = lw.CategoryCode
    ,Category                                     = lw.Category
    ,BusinessCategoryCode                         = lw.BusinessCategoryCode
    ,BusinessCategory                             = lw.BusinessCategory
    ,RiskClassCode                                = lw.RiskClassCode
    ,RiskClass                                    = lw.RiskClass
    ,FilCode                                      = lw.FilCode
    ,Fil                                          = lw.Fil
    ,DTICode                                      = lw.DTICode
    ,QualCatCode                                  = lw.QualCatCode
    ,QualCat                                      = lw.QualCat
    ,OriginalCCYToSettlementCCYRate               = lw.OriginalCCYToSettlementCCYRate
    ,PositiveAmountInOriginalCCY                  = lw.PositiveAmountInOriginalCCY
    ,PositiveVATAmountInOriginalCCY               = lw.PositiveVATAmountInOriginalCCY
    ,PositiveDelinkedAmountInOriginalCCY          = lw.PositiveDelinkedAmountInOriginalCCY 
	,PositiveIPTOverseasTaxAmountInOriginalCCY	  = lw.PositiveIPTOverseasTaxAmountInOriginalCCY	
	,PositiveIPTUKTaxAmountInOriginalCCY		  = lw.PositiveIPTUKTaxAmountInOriginalCCY	
	,PositiveAmountExcIPTOverseasTaxInOriginalCCY = lw.PositiveAmountExcIPTOverseasTaxInOriginalCCY
    ,NegativeAmountInOriginalCCY                  = lw.NegativeAmountInOriginalCCY
    ,NegativeVATAmountInOriginalCCY               = lw.NegativeVATAmountInOriginalCCY
    ,NegativeDelinkedAmountInOriginalCCY          = lw.NegativeDelinkedAmountInOriginalCCY
	,NegativeIPTOverseasTaxAmountInOriginalCCY	  = lw.NegativeIPTOverseasTaxAmountInOriginalCCY	
	,NegativeIPTUKTaxAmountInOriginalCCY		  = lw.NegativeIPTUKTaxAmountInOriginalCCY
	,NegativeAmountExcIPTOverseasTaxInOriginalCCY = lw.NegativeAmountExcIPTOverseasTaxInOriginalCCY
    ,GQDDate                                      = CASE  
                                                      WHEN s.IsFacility = 0 THEN COALESCE(s.TermsOfTradeDate, lw.ActualPaymentDate, lw.ProcessingPeriodDate)
                                                      ELSE COALESCE(lw.ActualPaymentDate, lw.ProcessingPeriodDate)
                                                     END
    ,ExternalAcquisitionCostMultiplier            = lw.ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier            = lw.InternalAcquisitionCostMultiplier
	,LPSOBrokerReference						  = lw.LPSOBrokerReference
    ,FK_Section                                   = s.PK_Section
    ,FK_SettlementCurrency                        = sc.PK_SettlementCurrency
    ,FK_OriginalCurrency                          = oc.PK_OriginalCurrency
    ,FK_YOA                                       = lw.FK_YOA
    ,FK_GQDTransactionType                        = ISNULL(gqd.PK_GQDTransactionType, 0)
    ,FK_DevelopmentPeriod                         = ISNULL(dp.PK_DevelopmentPeriod, 0)
    ,FK_ClaimExposure                             = lw.FK_ClaimExposure    
	FROM
    #LPSOTransactionWorking lw
    INNER JOIN
    ODS.Section s with (nolock) ON
    lw.SectionReference = s.SectionReference
    INNER JOIN
    ODS.SettlementCurrency sc with (nolock) ON
    lw.SettlementCCY = sc.CurrencyCode
    INNER JOIN
    ODS.OriginalCurrency oc with (nolock) ON
    lw.OriginalCCY = oc.CurrencyCode
    INNER JOIN 
    ODS.YOA yoa with (nolock) ON
    lw.FK_YOA = yoa.PK_YOA
	LEFT OUTER JOIN
    ODS.GQDTransactionType gqd with (nolock) ON
    lw.GQDTransactionTypeCode = gqd.GQDTransactionTypeCode
    LEFT OUTER JOIN
    ODS.DevelopmentPeriod dp with (nolock) ON
    DATEDIFF(MM, yoa.FirstDate, lw.ProcessingPeriodDate) + 1 = dp.DevelopmentMonth
) x
INNER JOIN
ODS.Section s ON
x.FK_Section = s.PK_Section
GROUP BY
x.PK_LPSOTransaction
) AS SOURCE

 ON  TARGET.PK_LPSOTransaction                              = SOURCE.PK_LPSOTransaction 
 
 WHEN MATCHED THEN

UPDATE SET 

  TARGET.PK_LPSOTransaction                              = SOURCE.PK_LPSOTransaction 
 ,TARGET.SigningDate                                     = SOURCE.SigningDate 
 ,TARGET.SigningNumber                                   = SOURCE.SigningNumber
 ,TARGET.SigningBureauVersionNumber                      = SOURCE.SigningBureauVersionNumber
 ,TARGET.BrokerSigningDate                               = SOURCE.BrokerSigningDate
 ,TARGET.BrokerSigningNumber                             = SOURCE.BrokerSigningNumber
 ,TARGET.ProcessingDate                                  = SOURCE.ProcessingDate
 ,TARGET.ProcessingPeriodDate                            = SOURCE.ProcessingPeriodDate
 ,TARGET.SettlementDate                                  = SOURCE.SettlementDate
 ,TARGET.ActualPaymentDate                               = SOURCE.ActualPaymentDate
 ,TARGET.CategoryCode                                    = SOURCE.CategoryCode 
 ,TARGET.Category                                        = SOURCE.Category
 ,TARGET.BusinessCategoryCode                            = SOURCE.BusinessCategoryCode
 ,TARGET.BusinessCategory                                = SOURCE.BusinessCategory
 ,TARGET.RiskClassCode                                   = SOURCE.RiskClassCode
 ,TARGET.RiskClass                                       = SOURCE.RiskClass
 ,TARGET.FilCode                                         = SOURCE.FilCode
 ,TARGET.Fil                                             = SOURCE.Fil
 ,TARGET.DTICode                                         = SOURCE.DTICode
 ,TARGET.QualCatCode                                     = SOURCE.QualCatCode
 ,TARGET.QualCat                                         = SOURCE.QualCat
 ,TARGET.OriginalCCYToSettlementCCYRate                  = SOURCE.OriginalCCYToSettlementCCYRate
 ,TARGET.PositiveAmountInOriginalCCY                     = SOURCE.PositiveAmountInOriginalCCY
 ,TARGET.PositiveVATAmountInOriginalCCY                  = SOURCE.PositiveVATAmountInOriginalCCY
 ,TARGET.PositiveDelinkedAmountInOriginalCCY             = SOURCE.PositiveDelinkedAmountInOriginalCCY
 ,TARGET.PositiveIPTOverseasTaxAmountInOriginalCCY	     = SOURCE.PositiveIPTOverseasTaxAmountInOriginalCCY	
 ,TARGET.PositiveIPTUKTaxAmountInOriginalCCY	         = SOURCE.PositiveIPTUKTaxAmountInOriginalCCY	
 ,TARGET.PositiveAmountExcIPTOverseasTaxInOriginalCCY    = SOURCE.PositiveAmountExcIPTOverseasTaxInOriginalCCY
 ,TARGET.NegativeAmountInOriginalCCY                     = SOURCE.NegativeAmountInOriginalCCY
 ,TARGET.NegativeVATAmountInOriginalCCY                  = SOURCE.NegativeVATAmountInOriginalCCY
 ,TARGET.NegativeDelinkedAmountInOriginalCCY             = SOURCE.NegativeDelinkedAmountInOriginalCCY
 ,TARGET.NegativeIPTOverseasTaxAmountInOriginalCCY	     = SOURCE.NegativeIPTOverseasTaxAmountInOriginalCCY	   
 ,TARGET.NegativeIPTUKTaxAmountInOriginalCCY	         = SOURCE.NegativeIPTUKTaxAmountInOriginalCCY	
 ,TARGET.NegativeAmountExcIPTOverseasTaxInOriginalCCY    = SOURCE.NegativeAmountExcIPTOverseasTaxInOriginalCCY
 ,TARGET.GQDDate                                         = SOURCE.GQDDate
 ,TARGET.ExternalAcquisitionCostMultiplier	             = SOURCE.ExternalAcquisitionCostMultiplier
 ,TARGET.InternalAcquisitionCostMultiplier               = SOURCE.InternalAcquisitionCostMultiplier
 ,TARGET.FK_Section                                      = SOURCE.FK_Section
 ,TARGET.FK_SettlementCurrency                           = SOURCE.FK_SettlementCurrency
 ,TARGET.FK_OriginalCurrency                             = SOURCE.FK_OriginalCurrency
 ,TARGET.FK_YOA                                          = SOURCE.FK_YOA
 ,TARGET.FK_GQDTransactionType                           = SOURCE.FK_GQDTransactionType
 ,TARGET.SpecialPurposeSyndicateApplies                  = SOURCE.SpecialPurposeSyndicateApplies
 ,TARGET.LPSOBrokerReference                             = SOURCE.LPSOBrokerReference
 ,TARGET.FK_DevelopmentPeriod                            = SOURCE.FK_DevelopmentPeriod
 ,TARGET.FK_ClaimExposure                                = SOURCE.FK_ClaimExposure
 ,TARGET.AuditModifyDateTime	                         = GETDATE()						
 ,TARGET.AuditModifyDetails	                             = 'Merge in [ODS].[LPSOTransaction] table' 


 WHEN NOT MATCHED BY TARGET THEN 

 INSERT (
     PK_LPSOTransaction 
    ,SigningDate 
    ,SigningNumber
    ,SigningBureauVersionNumber
    ,BrokerSigningDate
    ,BrokerSigningNumber
    ,ProcessingDate
    ,ProcessingPeriodDate
    ,SettlementDate
    ,ActualPaymentDate
    ,CategoryCode 
    ,Category
    ,BusinessCategoryCode
    ,BusinessCategory
    ,RiskClassCode
    ,RiskClass
    ,FilCode
    ,Fil
    ,DTICode
    ,QualCatCode
    ,QualCat
    ,OriginalCCYToSettlementCCYRate
    ,PositiveAmountInOriginalCCY
    ,PositiveVATAmountInOriginalCCY
    ,PositiveDelinkedAmountInOriginalCCY
	,PositiveIPTOverseasTaxAmountInOriginalCCY	
	,PositiveIPTUKTaxAmountInOriginalCCY	
	,PositiveAmountExcIPTOverseasTaxInOriginalCCY
    ,NegativeAmountInOriginalCCY
    ,NegativeVATAmountInOriginalCCY
    ,NegativeDelinkedAmountInOriginalCCY
	,NegativeIPTOverseasTaxAmountInOriginalCCY	   
	,NegativeIPTUKTaxAmountInOriginalCCY	
	,NegativeAmountExcIPTOverseasTaxInOriginalCCY
	,GQDDate
    ,ExternalAcquisitionCostMultiplier
    ,InternalAcquisitionCostMultiplier
    ,FK_Section
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_YOA
    ,FK_GQDTransactionType
    ,SpecialPurposeSyndicateApplies
	,LPSOBrokerReference
    ,FK_DevelopmentPeriod
    ,FK_ClaimExposure
	,AuditModifyDetails
	)

	VALUES (

 SOURCE.PK_LPSOTransaction 
,SOURCE.SigningDate 
,SOURCE.SigningNumber
,SOURCE.SigningBureauVersionNumber
,SOURCE.BrokerSigningDate
,SOURCE.BrokerSigningNumber
,SOURCE.ProcessingDate
,SOURCE.ProcessingPeriodDate
,SOURCE.SettlementDate
,SOURCE.ActualPaymentDate
,SOURCE.CategoryCode 
,SOURCE.Category
,SOURCE.BusinessCategoryCode
,SOURCE.BusinessCategory
,SOURCE.RiskClassCode
,SOURCE.RiskClass
,SOURCE.FilCode
,SOURCE.Fil
,SOURCE.DTICode
,SOURCE.QualCatCode
,SOURCE.QualCat
,SOURCE.OriginalCCYToSettlementCCYRate
,SOURCE.PositiveAmountInOriginalCCY
,SOURCE.PositiveVATAmountInOriginalCCY
,SOURCE.PositiveDelinkedAmountInOriginalCCY
,SOURCE.PositiveIPTOverseasTaxAmountInOriginalCCY	
,SOURCE.PositiveIPTUKTaxAmountInOriginalCCY	
,SOURCE.PositiveAmountExcIPTOverseasTaxInOriginalCCY
,SOURCE.NegativeAmountInOriginalCCY
,SOURCE.NegativeVATAmountInOriginalCCY
,SOURCE.NegativeDelinkedAmountInOriginalCCY
,SOURCE.NegativeIPTOverseasTaxAmountInOriginalCCY	   
,SOURCE.NegativeIPTUKTaxAmountInOriginalCCY	
,SOURCE.NegativeAmountExcIPTOverseasTaxInOriginalCCY
,SOURCE.GQDDate
,SOURCE.ExternalAcquisitionCostMultiplier
,SOURCE.InternalAcquisitionCostMultiplier
,SOURCE.FK_Section
,SOURCE.FK_SettlementCurrency
,SOURCE.FK_OriginalCurrency
,SOURCE.FK_YOA
,SOURCE.FK_GQDTransactionType
,SOURCE.SpecialPurposeSyndicateApplies
,SOURCE.LPSOBrokerReference
,SOURCE.FK_DevelopmentPeriod
,SOURCE.FK_ClaimExposure
,'New in [ODS].[LPSOTransaction] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

ALTER TABLE ODS.LPSOTransaction CHECK CONSTRAINT ALL

ALTER TABLE ODS.LPSOTransactionLine NOCHECK CONSTRAINT ALL

--Work out each syndicate's contribution to the total - this becomes the line

MERGE ODS.LPSOTransactionLine AS TARGET
USING
(
SELECT
FK_LPSOTransaction                      = l.PK_LPSOTransaction
,FK_Syndicate                           = syn.PK_Syndicate 
--Need to cast to floats here otherwise we lose accuracy after the 6th decimal place
,PositiveLineMultiplier                 = CASE
                                            WHEN MAX(l.PositiveAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveAmountInOriginalCCY) as float) 
                                                 / CAST(MAX(l.PositiveAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeLineMultiplier                 = CASE
                                            WHEN MAX(l.NegativeAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeAmountInOriginalCCY) AS float)
                                                 / CAST(MAX(l.NegativeAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) AS float)
                                          END
,PositiveVATLineMultiplier              = CASE
                                            WHEN MAX(l.PositiveVATAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveVATAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.PositiveVATAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeVATLineMultiplier              = CASE
                                            WHEN MAX(l.NegativeVATAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeVATAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.NegativeVATAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,PositiveDelinkedLineMultiplier         = CASE
                                            WHEN MAX(l.PositiveDelinkedAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveDelinkedAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.PositiveDelinkedAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeDelinkedLineMultiplier         = CASE
                                            WHEN MAX(l.NegativeDelinkedAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeDelinkedAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.NegativeDelinkedAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,PositiveIPTOverseasTaxLineMultiplier	= CASE
                                            WHEN MAX(l.PositiveIPTOverseasTaxAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveIPTOverseasTaxAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.PositiveIPTOverseasTaxAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeIPTOverseasTaxLineMultiplier	= CASE
                                            WHEN MAX(l.NegativeIPTOverseasTaxAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeIPTOverseasTaxAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.NegativeIPTOverseasTaxAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,PositiveIPTUKTaxLineMultiplier			= CASE
                                            WHEN MAX(l.PositiveIPTUKTaxAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveIPTUKTaxAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.PositiveIPTUKTaxAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeIPTUKTaxLineMultiplier			= CASE
                                            WHEN MAX(l.NegativeIPTUKTaxAmountInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeIPTUKTaxAmountInOriginalCCY) as float) 
                                                / CAST(MAX(l.NegativeIPTUKTaxAmountInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
										  END
,PositiveExcIPTOverseasTaxLineMultiplier = CASE
                                            WHEN MAX(l.PositiveAmountExcIPTOverseasTaxInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.PositiveAmountExcIPTOverseasTaxInOriginalCCY) as float) 
                                                 / CAST(MAX(l.PositiveAmountExcIPTOverseasTaxInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) as float)
                                          END
,NegativeExcIPTOverseasTaxLineMultiplier = CASE
                                            WHEN MAX(l.NegativeAmountExcIPTOverseasTaxInOriginalCCY) = 0
                                            THEN 0
                                            ELSE CAST(SUM(lw.NegativeAmountExcIPTOverseasTaxInOriginalCCY) AS float)
                                                 / CAST(MAX(l.NegativeAmountExcIPTOverseasTaxInOriginalCCY * s.WrittenIfNotSignedOrderMultiplier) AS float)
                                          END										  
--INTO testFT.LPSOTransactionLineNew
FROM
#LPSOTransactionWorking lw
INNER JOIN
ODS.LPSOTransaction l with (nolock) ON
lw.GroupKey = l.PK_LPSOTransaction
INNER JOIN
ODS.Section s with (nolock) ON
l.FK_Section = s.PK_Section
INNER JOIN
ODS.Syndicate syn with (nolock) ON
lw.SyndicateNumber = syn.SyndicateNumber
INNER JOIN
/*Only interested in creating lines where "real" lines exist for the section*/
ODS.SectionLine sl with (nolock) ON
s.PK_Section = sl.FK_Section
AND syn.PK_Syndicate = sl.FK_Syndicate
GROUP BY
l.PK_LPSOTransaction
,syn.PK_Syndicate
) AS SOURCE

 ON TARGET.FK_LPSOTransaction                      = SOURCE.FK_LPSOTransaction
AND TARGET.FK_Syndicate                            = SOURCE.FK_Syndicate
WHEN MATCHED THEN

UPDATE SET

 TARGET.FK_LPSOTransaction                      = SOURCE.FK_LPSOTransaction
,TARGET.FK_Syndicate                            = SOURCE.FK_Syndicate
,TARGET.PositiveLineMultiplier                  = SOURCE.PositiveLineMultiplier
,TARGET.NegativeLineMultiplier                  = SOURCE.NegativeLineMultiplier
,TARGET.PositiveVATLineMultiplier               = SOURCE.PositiveVATLineMultiplier
,TARGET.NegativeVATLineMultiplier               = SOURCE.NegativeVATLineMultiplier
,TARGET.PositiveDelinkedLineMultiplier          = SOURCE.PositiveDelinkedLineMultiplier
,TARGET.NegativeDelinkedLineMultiplier          = SOURCE.NegativeDelinkedLineMultiplier
,TARGET.PositiveIPTOverseasTaxLineMultiplier    = SOURCE.PositiveIPTOverseasTaxLineMultiplier
,TARGET.NegativeIPTOverseasTaxLineMultiplier    = SOURCE.NegativeIPTOverseasTaxLineMultiplier
,TARGET.PositiveIPTUKTaxLineMultiplier          = SOURCE.PositiveIPTUKTaxLineMultiplier
,TARGET.NegativeIPTUKTaxLineMultiplier          = SOURCE.NegativeIPTUKTaxLineMultiplier
,TARGET.PositiveExcIPTOverseasTaxLineMultiplier = SOURCE.PositiveExcIPTOverseasTaxLineMultiplier
,TARGET.NegativeExcIPTOverseasTaxLineMultiplier = SOURCE.NegativeExcIPTOverseasTaxLineMultiplier
,TARGET.AuditModifyDateTime	                    = GETDATE()						
,TARGET.AuditModifyDetails	                    = 'Merge in [ODS].[LPSOTransactionLine] table' 

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(FK_LPSOTransaction
,FK_Syndicate
,PositiveLineMultiplier
,NegativeLineMultiplier
,PositiveVATLineMultiplier
,NegativeVATLineMultiplier
,PositiveDelinkedLineMultiplier
,NegativeDelinkedLineMultiplier
,PositiveIPTOverseasTaxLineMultiplier
,NegativeIPTOverseasTaxLineMultiplier
,PositiveIPTUKTaxLineMultiplier
,NegativeIPTUKTaxLineMultiplier
,PositiveExcIPTOverseasTaxLineMultiplier
,NegativeExcIPTOverseasTaxLineMultiplier
,AuditModifyDetails
)
VALUES
(
SOURCE.FK_LPSOTransaction
,SOURCE.FK_Syndicate
,SOURCE.PositiveLineMultiplier
,SOURCE.NegativeLineMultiplier
,SOURCE.PositiveVATLineMultiplier
,SOURCE.NegativeVATLineMultiplier
,SOURCE.PositiveDelinkedLineMultiplier
,SOURCE.NegativeDelinkedLineMultiplier
,SOURCE.PositiveIPTOverseasTaxLineMultiplier
,SOURCE.NegativeIPTOverseasTaxLineMultiplier
,SOURCE.PositiveIPTUKTaxLineMultiplier
,SOURCE.NegativeIPTUKTaxLineMultiplier
,SOURCE.PositiveExcIPTOverseasTaxLineMultiplier
,SOURCE.NegativeExcIPTOverseasTaxLineMultiplier
,'New in [ODS].[LPSOTransactionLine] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

ALTER TABLE ODS.LPSOTransactionLine CHECK CONSTRAINT ALL

/*Update earliest and latest LPSO signing date and number on section*/
;WITH CTELPSO 
AS
(
    SELECT
    FK_Section                      = l.FK_Section
    ,SigningDate                    = l.SigningDate
    ,SigningNumber                  = l.SigningNumber
    ,SequenceId                     = ROW_NUMBER() OVER(
                                        PARTITION BY l.FK_Section
                                        ORDER BY SigningDate ASC, SigningNumber ASC)
    ,ReverseSequenceId              = ROW_NUMBER() OVER(
                                        PARTITION BY l.FK_Section
                                        ORDER BY SigningDate DESC, SigningNumber DESC)
    FROM
    ODS.LPSOTransaction l with (nolock) 
    WHERE
    l.CategoryCode IN (1,2,3)
)
UPDATE s SET
EarliestLPSOPremiumSigningDate        = lpso_earliest.SigningDate
,EarliestLPSOPremiumSigningNumber     = lpso_earliest.SigningNumber
,LatestLPSOPremiumSigningDate         = lpso_latest.SigningDate
,LatestLPSOPremiumSigningNumber       = lpso_latest.SigningNumber
,EarliestLPSOPremiumSigningDateName	  = IIF(YEAR(lpso_earliest.SigningDate)< 1990 OR YEAR(lpso_earliest.SigningDate)>2050,NULL,FORMAT(lpso_earliest.SigningDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](lpso_earliest.SigningDate)
,EarliestLPSOPremiumSigningNumberName = isnull(CONVERT([varchar](255),lpso_earliest.SigningNumber),'')
,LatestLPSOPremiumSigningDateName	  = IIF(YEAR(lpso_latest.SigningDate)< 1990 OR YEAR(lpso_latest.SigningDate)>2050,NULL,FORMAT(lpso_latest.SigningDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](lpso_latest.SigningDate)
,LatestLPSOPremiumSigningNumberName	  = isnull(CONVERT([varchar](255),lpso_latest.SigningNumber),'')
FROM
ODS.Section s
INNER JOIN
CTELPSO lpso_earliest ON
s.PK_Section = lpso_earliest.FK_Section
AND lpso_earliest.SequenceId = 1
INNER JOIN
CTELPSO lpso_latest ON
s.PK_Section = lpso_latest.FK_Section
AND lpso_latest.ReverseSequenceId = 1

IF (OBJECT_ID('tempdb..#LPSOTransactionWorking') IS NOT NULL)
DROP TABLE #LPSOTransactionWorking;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'LPSOTransaction';
EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'LPSOTransactionLine';