﻿

CREATE PROCEDURE [ODS].[usp_LoadReinsuranceContractNonFac]
AS

SET NOCOUNT ON

--Clear Previous Data
DELETE FROM ODS.ReinsuranceContractNonFac;

--EuroBase Non-Facultative Policies
INSERT INTO ODS.ReinsuranceContractNonFac
(
     ContractReference
    ,ContractShortName
    ,ContractDescription
    ,ContractType
    ,ContractPolicyType
    ,PeriodFromDate
    ,PeriodToDate
    ,SignedOrderMultiplier
    ,OverriderCommission
    ,YearOfAccount
    ,Reinstatements
    ,Adjustable
    ,SumInsuredLimit
    ,SumInsuredCurrency
    ,ExcessLimit
    ,ProfitCommission
    ,SlipROE
    ,SlipROE_CAD
    ,SlipROE_EUR
)
SELECT
 ContractReference		= rcnf.ContractReference		
,ContractShortName		= rcnf.ContractShortName		
,ContractDescription	= rcnf.ContractDescription	
,ContractType			= rcnf.ContractType			
,ContractPolicyType		= rcnf.ContractPolicyType		
,PeriodFromDate			= rcnf.PeriodFromDate			
,PeriodToDate	        = rcnf.PeriodToDate	        
,SignedOrderMultiplier  = rcnf.SignedOrderMultiplier  
,OverriderCommission	= rcnf.OverriderCommission	
,YearOfAccount			= rcnf.YearOfAccount			
,Reinstatements			= rcnf.Reinstatements			
,AdjustableIndicator	= rcnf.Adjustable
,SumInsuredLimit		= rcnf.SumInsuredLimit		
,SumInsuredCCY			= rcnf.SumInsuredCurrency			
,ExcessLimit			= rcnf.ExcessLimit			
,ProfitCommission		= rcnf.ProfitCommission		
,SlipROE				= rcnf.SlipROE				
,SlipROE_CAD			= rcnf.SlipROE_CAD			
,SlipROE_EUR			= rcnf.SlipROE_EUR			
FROM 
BeazleyIntelligenceDataContract.Outbound.vw_ReinsuranceContractNonFac rcnf
WHERE rcnf.SourceSystem = 'Eurobase'
--AND rcnf.IsActive = 1 

ORDER BY
 rcnf.ContractReference;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceContractNonFac';