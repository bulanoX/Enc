﻿


CREATE PROC [ODS].[usp_LoadDataAsAt]
AS

SET NOCOUNT ON

DECLARE @ProcessSourceSystem AS TABLE 
(
    ProcessName     varchar(255)    NOT NULL
    ,SourceSystem   varchar(255)    NOT NULL
    ,IsCore         bit             NOT NULL
)

INSERT INTO @ProcessSourceSystem
(
    ProcessName  
    ,SourceSystem 
    ,IsCore
)
VALUES  ('BeazleyIntelligence_Extract_Eurobase','Eurobase',1)
        ,('BeazleyIntelligence_Extract_BeazleyProReporting','BeazleyPro',1)
        --,('BeazleyIntelligence_Extract_ClaimCenter','ClaimCenter',1)
		,('BeazleyIntelligenceDataContract_ClaimCenter','ClaimCenter',1)
        ,('BeazleyIntelligence_Extract_Datamart','Datamart',0)
        --,('BeazleyIntelligence_Extract_KnowledgeCenter','KnowledgeCenter',0)
        ,('BeazleyIntelligence_Extract_ULR','ULR',0)
        ,('BeazleyIntelligence_Extract_DocumentManagement','DocumentManagement',0)
        ,('BeazleyIntelligence_Extract_BeazleyDocumentsReporting','BeazleyDocumentsReporting',0)
        ,('BeazleyIntelligence_Extract_BeazleyAuthorityExceptions','BeazleyAuthorityExceptions',0)
        ,('BeazleyIntelligence_Extract_CRM','CRM',0)
        ,('BeazleyIntelligence_Extract_MDS','MDS',0)
        ,('BeazleyIntelligence_Extract_BICI_AccessDB','BICI Access DB',0)
        ,('BeazleyIntelligence_Extract_SharePointBI','SharePointBI',0)
        ,('BeazleyIntelligence_Extract_SharePointBeazleyCustom','SharePoint BeazleyCustom',0)
     -- ,('BeazleyIntelligence_Extract_Unirisx','Unirisx',1)
		    ,('BeazleyIntelligence_Load_Unirisx','Unirisx',1)
        ,('BeazleyIntelligence_Process_BeazleyProData','BeazleyPro',1)



TRUNCATE TABLE ODS.DataAsAt

INSERT INTO ODS.DataAsAt
(
    CoreSystemAsAtDate
    ,EurobaseAsAtDate
    ,BeazleyProAsAtDate
    ,ClaimCenterAsAtDate
    --,KnowledgeCenterAsAtDate
    ,UnirisxAsAtDate
)
SELECT 
CoreDataAsAt                = MIN(CASE WHEN src.IsCore = 1 THEN rep.LastSuccessfulRun ELSE NULL END)
,EurobaseDataAsAt           = MIN(CASE WHEN src.SourceSystem = 'Eurobase' THEN rep.LastSuccessfulRun ELSE NULL END)
,BeazleyProDataAsAt         = MIN(CASE WHEN src.SourceSystem = 'BeazleyPro' THEN rep.LastSuccessfulRun ELSE NULL END)
,ClaimCenterDataAsAt        = MAX(CASE WHEN src.SourceSystem = 'ClaimCenter' THEN rep.LastSuccessfulRun ELSE NULL END)
--,KnowledgeCenterDataAsAt    = MIN(CASE WHEN src.SourceSystem = 'KnowledgeCenter' THEN rep.LastSuccessfulRun ELSE NULL END)
,UnirisxDataAsAt            = MIN(CASE WHEN src.SourceSystem = 'Unirisx' THEN rep.LastSuccessfulRun ELSE NULL END)

FROM 
BeazleyIntelligence.[Control].CubeReport rep
INNER JOIN 
@ProcessSourceSystem src ON 
rep.ProcessName = src.ProcessName;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'DataAsAt';