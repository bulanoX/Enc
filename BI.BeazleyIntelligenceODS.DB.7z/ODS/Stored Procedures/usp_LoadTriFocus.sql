﻿
CREATE PROC [ODS].[usp_LoadTriFocus]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.TriFocus

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

	
;MERGE ODS.TriFocus
AS TARGET
USING  (    SELECT       IsUnknownMember                = 0
                        ,TriFocusCode                   = tf.TriFocusCode
						,TriFocusName                   = tf.[Name]
						,DepartmentName                 = tf.DepartmentName_Name
						,EurobaseDepartmentName         = tf.EurobaseDepartmentName
						,Division						= tf.Division
		
		    FROM Staging_MDS.MDS_Staging.TriFocus tf
			WHERE TF.TriFocusCode IS NOT NULL 

			UNION 
            SELECT    IsUnknownMember         = 1
			         ,TriFocusCode            = 'N/A'
                     ,TriFocusName            = 'N/A'
			         ,DepartmentName          = 'N/A'
					 ,EurobaseDepartmentName  = 'N/A'
			         ,Division                = 'N/A'
		) AS SOURCE
ON   SOURCE.TriFocusCode = TARGET.TriFocusCode

WHEN MATCHED THEN

UPDATE SET
Target.IsUnknownMember				= source.IsUnknownMember,
TARGET.TriFocusCode                 = source.TriFocusCode,
TARGET.TriFocusName                 = source.TriFocusName,
TARGET.DepartmentName               = source.DepartmentName,
TARGET.EurobaseDepartmentName       = source.EurobaseDepartmentName,
TARGET.Division                     = source.Division,
target.AuditModifyDateTime	        = GETDATE(),						
target.AuditModifyDetails	        = 'Merge in ODS.usp_LoadTrifocus'


WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(IsUnknownMember,
 [TriFocusCode],
 [TriFocusName],
 [DepartmentName],
 [EurobaseDepartmentName],
 [Division],
 [AuditCreateDateTime],
 [AuditModifyDetails]
)

VALUES
(IsUnknownMember,
 [TriFocusCode],
 [TriFocusName],
 [DepartmentName],
 [EurobaseDepartmentName],
 [Division]
 ,GETDATE()
 ,'New add in ODS.usp_LoadTrifocus'	
);