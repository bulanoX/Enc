﻿CREATE PROCEDURE [ODS].[usp_LoadClaimExposureSection]
AS
BEGIN

--------------------------------------------------------------------------------------
	/*Create temp table to hold mappings*/
	----------------------------------------------------------------------------------
	IF (OBJECT_ID('tempdb..#ClaimExposureSection') IS NOT NULL)
	DROP TABLE #ClaimExposureSection

	CREATE TABLE #ClaimExposureSection
	(
		FK_ClaimExposure        bigint          NOT NULL
		,FK_Section             bigint          NOT NULL	
		,TypeId					int				NULL
		,Algorithm_type         nvarchar(100)   NOT NULL
		,SectionSequenceId      int             NULL
	);

	ALTER TABLE #ClaimExposureSection 
	ADD CONSTRAINT PK_#ClaimExposureSection 
	PRIMARY KEY NONCLUSTERED (FK_ClaimExposure, FK_Section);


	----------------------------------------------------------------------------------
	/*Create temp table for Unirisx mappings*/
	----------------------------------------------------------------------------------

	IF (OBJECT_ID('tempdb..#UnirisxSectionToPolicyRetrieveMapping') IS NOT NULL)
	DROP TABLE #UnirisxSectionToPolicyRetrieveMapping

	CREATE TABLE #UnirisxSectionToPolicyRetrieveMapping
	(
		 PolicyRetrieveSectionReference	varchar(100) NOT NULL
		,PolicyReference				varchar(100) NOT NULL
		,SectionReference				varchar(100) NOT NULL
	);

	INSERT INTO #UnirisxSectionToPolicyRetrieveMapping
	(
		 PolicyRetrieveSectionReference
		,PolicyReference
		,SectionReference
	)
	SELECT	
		 PolicyRetrieveSectionReference	= REPLACE(se.PolicyRetrieveSectionReference, '--', '-')
		,PolicyReference				= se.PolicyReference
		,SectionReference				= se.SectionSourceId
	FROM
		BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension se
	WHERE
		se.SourceSystem = 'Unirisx';

	CREATE UNIQUE CLUSTERED INDEX UC_UnirisxSectionToPolicyRetrieveMapping 
	ON #UnirisxSectionToPolicyRetrieveMapping (PolicyRetrieveSectionReference, SectionReference);

			-----Etrek replatforming  = -d - Unirisx - Etrek replatforming ------
	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT 
		 FK_ClaimExposure	= ce.PK_ClaimExposure
		,FK_Section			= s.PK_Section
		,2
		,'d - Unirisx - Etrek replatforming'
		,NULL
	FROM
		ODS.ClaimExposure ce
		
		INNER JOIN
		(
			SELECT
				 ExposureReference	= cex.ClaimExposureSourceId
				,PrimarySectionName	= cex.PrimarySectionName
				,PolicyReference	= c.PolicyNumber
			
			FROM
				BeazleyIntelligenceDataContract.Outbound.vw_Claim c
				INNER JOIN
				BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cex
				ON 
				cex.SourceSystem		 = c.SourceSystem AND
				cex.ClaimSourceId		 = c.ClaimSourceId
			WHERE
				cex.SourceSystem = 'Claimcenter' 
		        AND ISNULL(c.IsRetired,0) = 0

		)
		AS cee
		ON cee.ExposureReference = ce.ExposureReference

		INNER JOIN
		#UnirisxSectionToPolicyRetrieveMapping umap
		ON umap.PolicyRetrieveSectionReference = cee.PrimarySectionName
		AND umap.PolicyReference = cee.PolicyReference
		INNER JOIN
		ODS.Section s
		ON s.SectionReference = umap.SectionReference
		INNER JOIN 
		ODS.TriFocus tr
		ON s.FK_TriFocus = tr.PK_TriFocus

	WHERE	
		 s.SourceSystem = 'Unirisx'
		AND s.OriginatingSourceSystem = 'Etrek'
		AND tr.DepartmentName = 'Property'
		AND MigratedPolicy = 'Yes'

------------------------------------- Algorithm_type = a - SplitLines------------------
	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
		,Algorithm_type      
		,SectionSequenceId
	)
	SELECT 
		 ce.PK_ClaimExposure
		,s.PK_Section
		,TypeId = -2
		,'a - SplitLines'
		,ces.SectionSequenceId
	FROM 
		BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureSection ces
		INNER JOIN 
		ODS.ClaimExposure ce 
		ON ce.ExposureReference = ces.ClaimExposureSourceId 
		INNER JOIN
		ODS.Section s 
		ON s.SectionReference = ces.SectionSourceId
	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		AND ces.ClaimSourceSystem = 'ClaimCenter'

-------------------------------------------- Algorithm_type = i - Staging_MDS --------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
		,Algorithm_type	
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure	= ce.PK_ClaimExposure
		,FK_Section			= s.PK_Section
		,TypeId				= 0
		,'i - Staging_MDS'
		,NULL
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		Staging_MDS.MDS_Staging.ClaimExposureToSectionMappingOverride AS cesmo
		ON cesmo.ccv9ExposureReference = ce.ExposureReference
		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = cesmo.NewSectionReference
		
	WHERE	
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		and
		cesmo.StartDateInclusive <= CAST(CAST(GETDATE() as DATE) as VARCHAR)
		AND
		cesmo.EndDateInclusive >= CAST(CAST(GETDATE() as DATE) as VARCHAR)

----------------------------------- Algorithm_type = c - AsIs -------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
		,Algorithm_type 
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,1
		,'c - AsIs'
		,NULL
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		(
			SELECT	ClaimExposureSourceId, PrimarySectionName
			FROM	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension
			WHERE	SourceSystem = 'Claimcenter'
		) AS oce
		ON oce.ClaimExposureSourceId = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = oce.PrimarySectionName
		
	WHERE	
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)

----------------------------------- Algorithm_type = b - Legacy -----------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT 
		 l.PK_ClaimExposure_V9
		,l.FK_Section		
		,TypeId	= -1
		,'b - Legacy'
		,NULL
	FROM 
		Utility.ClaimExposureSection_Legacy l 
		INNER JOIN 
		ODS.ClaimExposure ce 
		ON ce.PK_ClaimExposure = l.PK_ClaimExposure_V9
		LEFT JOIN
		#ClaimExposureSection ces 
		ON ces.FK_ClaimExposure = l.PK_ClaimExposure_V9
	WHERE
		ces.FK_ClaimExposure IS NULL

----------------------------------------- Algorithm_type = d - Unirisx------------------

	--------------------------------------------------------------------------------------------------
	/* For Unirisx, we need to join through the PolicyRetrieveSectionReference and the PolicyNumber */
	--------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT 
		 FK_ClaimExposure	= ce.PK_ClaimExposure
		,FK_Section			= s.PK_Section
		,2
		,'d - Unirisx'
		,NULL
	FROM
		ODS.ClaimExposure ce
		
		INNER JOIN
		(
			SELECT
				 ExposureReference	= cex.ClaimExposureSourceId
				,PrimarySectionName	= cex.PrimarySectionName
				,PolicyReference	= c.PolicyNumber
			FROM
				BeazleyIntelligenceDataContract.Outbound.vw_Claim c
				INNER JOIN
				BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cex
				ON 
				cex.SourceSystem		 = c.SourceSystem AND
				cex.ClaimSourceId		 = c.ClaimSourceId
			WHERE
				cex.SourceSystem = 'Claimcenter' 
		        AND ISNULL(c.IsRetired,0) = 0

		)
		AS cee
		ON cee.ExposureReference = ce.ExposureReference

		INNER JOIN
		#UnirisxSectionToPolicyRetrieveMapping umap
		ON 	umap.PolicyRetrieveSectionReference = cee.PrimarySectionName
		AND umap.PolicyReference = cee.PolicyReference

		INNER JOIN
		ODS.Section s
		ON s.SectionReference = umap.SectionReference

	WHERE	
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)


------------------------------------------- Algorithm_type = e - BeazleyPro, FDR , Etrek ------
-----------------------------------------------------------------------------------------------
-- For BeazleyPro add '-01' to the section coming from V9 just to be sure we have a match
-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,3
		,'e - BeazleyPro, FDR, Etrek'
		,NULL
	FROM 
		ODS.ClaimExposure ce 

		INNER JOIN 
		(
			SELECT	
				 ExposureReference	= ClaimExposureSourceId
				,SectionReference	= CASE WHEN CHARINDEX('-',PrimarySectionName) > 0 THEN PrimarySectionName ELSE PrimarySectionName + '-01' END
			FROM
				BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension
			WHERE
				SourceSystem = 'Claimcenter'
		)
		AS oce
		ON oce.ExposureReference = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = oce.SectionReference

		INNER JOIN 
		ODS.Policy p 
		ON p.PK_Policy = s.FK_Policy

		
	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		AND
		p.SourceSystem IN ('BeazleyPro','FDR','Etrek');

------------------------------------------------------------------------------------------------------
-- Policy starts with 'V' and Section with 'W'
------------------------------------------------------------------------------------------------------
INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)

SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,3
		,'e2 - BeazleyPro, FDR, Etrek'
		,NULL

FROM ODS.ClaimExposure ce 

		INNER JOIN 
		(
			SELECT	
				  ExposureReference	= cee.ClaimExposureSourceId
				 ,ClaimReference = cee.ClaimSourceId
				 ,PolicyNumber   = c.PolicyNumber
				 ,sectionreference = c.PolicyNumber + '-' + RIGHT(cee.PrimarySectionName, 2)
			FROM
				BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee
				INNER JOIN BeazleyIntelligenceDatacontract.Outbound.vw_Claim c ON cee.ClaimSourceId = c.ClaimSourceId
			WHERE
				cee.SourceSystem = 'Claimcenter'	
		)
		AS oce
		ON oce.ExposureReference = ce.ExposureReference 

   		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = oce.PolicyNumber

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = oce.sectionreference 

	WHERE ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		AND p.SourceSystem IN ('BeazleyPro')
		
------------------------------------------------------- Algorithm_type = f - Eurobase ------------------------------------------------

DROP TABLE IF EXISTS #bbr_lookup_temp 
SELECT distinct [bbr_cob_code_fees]
               ,[bbr_cob_code_fees_int]
INTO #bbr_lookup_temp
FROM [Staging_Eurobase].[Eurobase_Staging].[bbr_lookup]
WHERE [bbr_cob_code_fees] <> [bbr_cob_code_fees_int]


--------------------------------------------------------------------------------------------------------------------------------------------------------- 
	-- For Eurobase, 1st check - the bbr claims on BBR_Lookup table and use the Trifocus from the parent and the Area Code from the policy (US or non-US). 
----------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)

SELECT DISTINCT t.PK_ClaimExposure, 
                s.PK_Section,
			    3,
				'f - Eurobase - BBR claims',
				NULL
FROM (
			SELECT  PK_ClaimExposure,
		            PrimarySectionName,
			        (LEFT(ocee.PrimarySectionName, 10) + t.bbr_cob_code_fees_int) as ToBe_SectionReference

			FROM (
						SELECT	cc.PolicyNumber, cc.ClaimSourceId
						FROM	BeazleyIntelligenceDatacontract.Outbound.vw_Claim cc
						WHERE	cc.SourceSystem = 'ClaimCenter' AND ISNULL(cc.IsRetired,0) = 0
				  )	oc
				INNER JOIN ODS.Claim c ON c.ClaimReference = oc.ClaimSourceId 
				INNER JOIN ODS.ClaimExposure ce ON c.PK_Claim = ce.FK_Claim
			    INNER JOIN BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension ocee with (nolock) on ce.exposureReference = ocee.ClaimExposureSourceId
				INNER JOIN #bbr_lookup_temp t on RIGHT(ocee.PrimarySectionName, 2) = t.bbr_cob_code_fees_int OR RIGHT(ocee.PrimarySectionName, 2) = t.bbr_cob_code_fees
			WHERE ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
) t 
INNER JOIN ODS.Section s on s.SectionReference = t.ToBe_SectionReference


---------------------------------------------------------------------------------------------------------------
	-- For Eurobase, 2nd check  - if a claim has a SCM Reference then use the claim-policy linked table
---------------------------------------------------------------------------------------------------------------

INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)

SELECT t.PK_ClaimExposure,
       s.PK_Section,
	   3,
	   'f - Eurobase - SCMReference - PolicyLink01'
	   ,NULL
FROM (
		SELECT DISTINCT ce.PK_ClaimExposure,
			            euro.cpl_pol_policy_reference 
		FROM   ODS.ClaimExposure ce 
		INNER JOIN [Staging_Eurobase].Eurobase_Staging.claim_policy_link_01 euro on ce.SCMReference = (euro.cpl_cla_orig_bureau + euro.cpl_cla_uni_claim_ref )
		WHERE ce.PK_ClaimExposure NOT IN (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
     )t
INNER JOIN ODS.Section s on s.SectionReference = t.cpl_pol_policy_reference


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
	-- For Eurobase, 3rd check  - use Reference_LogTable use the Old Reference and the NewReference -> for cases where the reference changed as a result of a changed Cob Code.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
SELECT DISTINCT ce.PK_ClaimExposure,
                s.PK_Section,
	            3,
                'f - Reference_Log' ,
				NULL
FROM ODS.ClaimExposure ce 
          INNER JOIN ODS.Claim c ON c.PK_Claim = ce.FK_Claim
		  INNER JOIN BeazleyIntelligenceDatacontract.Outbound.vw_Claim oc ON c.claimReference = oc.claimSourceId
		  INNER JOIN BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension ocee with (nolock) on ce.exposureReference = ocee.ClaimExposureSourceId

		  INNER JOIN ODS.Policy p  ON p.PolicyReference = oc.PolicyNumber
		  INNER JOIN (SELECT  ref_old_reference,
								ref_new_reference
							  FROM(
										Select   ref_old_reference,
												 ref_new_reference,
												 ref_update_date,
												 row_number() over (partition by ref_old_reference, ref_new_reference order by ref_update_date desc) as rn
										from [Staging_Eurobase].[Eurobase_Staging].[reference_log] 
									) t
						WHERE RN = 1 ) ref on ocee.PrimarySectionName = ref.ref_old_reference
           INNER JOIN ODS.Section s ON s.SectionReference = ref.ref_new_reference
WHERE ce.PK_ClaimExposure NOT IN (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)

----------------------------------------------------------------------------------------------- 
	-- For Eurobase, take the first section, from the policy number found in the Outbound.Claim
-----------------------------------------------------------------------------------------------
	
	IF OBJECT_ID('tempdb..#x') is not null
		drop table #x

	CREATE TABLE #x (
		FK_ClaimExposure bigint,
		FK_Section		bigint,
		SourceSystem	varchar(250)
	)
	
	INSERT INTO #x (FK_ClaimExposure, FK_Section, SourceSystem)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,SourceSystem					= p.SourceSystem
	FROM 
		(
			SELECT	cc.PolicyNumber, cc.ClaimSourceId
			FROM	BeazleyIntelligenceDatacontract.Outbound.vw_Claim cc
			WHERE	cc.SourceSystem = 'ClaimCenter' 
					AND ISNULL(cc.IsRetired,0) = 0
		)
		oc
		INNER JOIN 
		ODS.Claim c
		ON c.ClaimReference = oc.ClaimSourceId --Now we have the claim record in the ODS

		INNER JOIN 
		ODS.ClaimExposure ce 
		ON c.PK_Claim = ce.FK_Claim

		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = oc.PolicyNumber

		INNER JOIN 
		ODS.Section s 
		ON s.FK_Policy = p.PK_Policy
		AND s.SectionSequenceId = 1

	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure);
		

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = x.FK_ClaimExposure
		,FK_Section                     = x.FK_Section
		,TypeId							= 3
		,Algorithm_type					= 'f - Eurobase'
		,SectionSequenceId              = NULL
	FROM #x x
	WHERE SourceSystem = 'Eurobase';

----------------------------------------------------------------------------------------------- 
	-- For Eurobase, use the first 12 characters from the SectionReference sent by v9
-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
		
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,5
		,'f - Eurobase - use first 12 characters'
		,NULL
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		(
			SELECT	ClaimExposureSourceId, LEFT(PrimarySectionName,12) AS PrimarySectionName
			FROM	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension
			WHERE	SourceSystem = 'Claimcenter' 
		)
		AS oce
		ON oce.ClaimExposureSourceId = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON LEFT(s.SectionReference,12) = oce.PrimarySectionName

		INNER JOIN 
		ODS.Policy p 
		ON p.PK_Policy = s.FK_Policy

	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		AND
		p.SourceSystem = 'Eurobase';

------------------------------------------------------------------------------------------------------------------------ 
	-- For Eurobase, use the first 9 characters from the SectionReference sent by v9, BUT ignore some COBs that might match
------------------------------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT 
		 FK_ClaimExposure
		,FK_Section
		,6
		,'f - Eurobase - use first 9 characters'
		,NULL
	FROM
	(
		SELECT
			 FK_ClaimExposure	= ce.PK_ClaimExposure
			,FK_Section			= s.PK_Section
			,RN					= ROW_NUMBER() OVER(PARTITION BY ce.PK_ClaimExposure 
													ORDER BY CASE 
																WHEN RIGHT(s.SectionReference,2) IN ('BR','LG','LV','MO','MU','UC','UD','UE','UF','UG','UJ','UK','UL','UM','UP','UR','UT','UU','UX','UZ','YO','YZ') 
																THEN 1 -- these ones will have a row_number > 1 when there are more than 2 rows, because we want to ignore them
																ELSE 0 
															 END)
		FROM 
			ODS.ClaimExposure ce 
			INNER JOIN 
			(
				SELECT	ClaimExposureSourceId, LEFT(PrimarySectionName , 9) AS PrimarySectionName, PrimarySectionName PRT
				FROM	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension
				WHERE	SourceSystem = 'Claimcenter' 
			)
			AS oce
			ON oce.ClaimExposureSourceId = ce.ExposureReference

			INNER JOIN 
			ODS.Section s 
			ON LEFT(s.SectionReference, 9) = oce.PrimarySectionName

			INNER JOIN 
			ODS.Policy p 
			ON p.PK_Policy = s.FK_Policy

		
		WHERE
			ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
			AND
			p.SourceSystem = 'Eurobase'
	) AS T
	WHERE 
		T.RN = 1;

------------------------------------------------------------------------------------------------------------------------ 
	-- For Eurobase, Join also on the first 8 characters of policyNumber to take the section reference
------------------------------------------------------------------------------------------------------------------------
	
	IF OBJECT_ID('tempdb..#y') is not null
		DROP TABLE #y

	CREATE TABLE #y (
		FK_ClaimExposure bigint,
		FK_Section		bigint,
		SourceSystem	varchar(250)
	)

	INSERT INTO #y(FK_ClaimExposure, FK_Section, SourceSystem)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
	--	,TypeId							= 7
	--	,Algorithm_type					= 'f - Eurobase - join on first 8 characters'
		,SourceSystem					= p.SourceSystem
	FROM 
		(
			SELECT	cc.PolicyNumber, cc.ClaimSourceId
			FROM	BeazleyIntelligenceDatacontract.Outbound.vw_Claim cc
			WHERE	cc.SourceSystem = 'ClaimCenter' 
					
					AND ISNULL(cc.IsRetired,0) = 0
		)
		oc
		INNER JOIN 
		ODS.Claim c
		ON c.ClaimReference = oc.ClaimSourceId --Now we have the claim record in the ODS

		INNER JOIN 
		ODS.ClaimExposure ce 
		ON c.PK_Claim = ce.FK_Claim

		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = LEFT(oc.PolicyNumber,8)

		INNER JOIN 
		ODS.Section s 
		ON s.FK_Policy = p.PK_Policy
		AND s.SectionSequenceId = 1

	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
	
	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = y.FK_ClaimExposure
		,FK_Section                     = y.FK_Section
		,TypeId							= 7
		,Algorithm_type					= 'f - Eurobase - join on first 8 characters'
		,NULL
	FROM #y y
	WHERE SourceSystem = 'Eurobase';


--------------------------------------- Algorithm_type = g - Match on PolicyNumber from Claim ------------------
--------------------------------------------------------------------------------------------------
	-- For the remaining ones just look at the policy found in the Claim and take its first section
---------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,7
		,'g - Match on PolicyNumber from Claim'
		,NULL
	FROM 
		(
			SELECT	cc.PolicyNumber, cc.ClaimSourceId
			FROM	BeazleyIntelligenceDatacontract.Outbound.vw_Claim cc
			WHERE	cc.SourceSystem = 'ClaimCenter' 
					AND ISNULL(cc.IsRetired,0) = 0
		)
		oc
		INNER JOIN 
		ODS.Claim c
		ON c.ClaimReference = oc.ClaimSourceId --Now we have the claim record in the ODS

		INNER JOIN 
		ODS.ClaimExposure ce 
		ON c.PK_Claim = ce.FK_Claim

		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = oc.PolicyNumber

		INNER JOIN 
		ODS.Section s 
		ON s.FK_Policy = p.PK_Policy
		AND s.SectionSequenceId = 1

	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
		

--------------------------------------------- Algorithm_type = h - default to the unknown member'------
-----------------------------------------------------------------------------------------------
	--If nothing worked just default to the unknown meber of the ODS.Section table
-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
		,Algorithm_type
		,SectionSequenceId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,8
		,'h - default to the unknown member'
		,NULL
	FROM 
		ODS.ClaimExposure ce 

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = 'N/A'

	WHERE
		ce.PK_ClaimExposure not in (select fk_claimexposure from #ClaimExposureSection group by fk_claimexposure)
	

	-----------------------------------------------------------------------------------------------
	/* Final insert */
	-----------------------------------------------------------------------------------------------

	--TRUNCATE TABLE ODS.ClaimExposureSection
	DROP TABLE IF EXISTS #ClaimExposureSection_final

	SELECT   FK_ClaimExposure               = ces.FK_ClaimExposure
			,FK_Section                     = s.PK_Section
			,FK_TriFocus                    = s.FK_TriFocus
			,FK_QuoteFilter                 = s.FK_QuoteFilter
			,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
			,FK_Policy                      = s.FK_Policy
			,FK_CRMBroker                   = s.FK_CRMBroker
			,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
			,FK_InternalWrittenBinderStatus = s.FK_InternalWrittenBinderStatus
			,FK_ServiceCompany				= s.FK_ServiceCompany
			,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
			,SectionSequenceId              = ces.SectionSequenceId
	INTO #ClaimExposureSection_final
	FROM #ClaimExposureSection ces
    INNER JOIN ODS.Section s  ON s.PK_Section = ces.FK_Section		


 MERGE ODS.ClaimExposureSection target
USING 
#ClaimExposureSection_final source
ON  target.FK_ClaimExposure = source.FK_ClaimExposure
AND target.Fk_Section = source.FK_Section

WHEN MATCHED THEN
UPDATE SET 
target.[FK_Section]						 = source.[FK_Section],
target.[FK_TriFocus]					 = source.[FK_TriFocus],
target.[FK_QuoteFilter]					 = source.[FK_QuoteFilter],
target.[FK_HiddenStatusFilter]			 = source.[FK_HiddenStatusFilter],
target.[FK_Policy]						 = source.[FK_Policy],
target.[FK_CRMBroker]					 = source.[FK_CRMBroker],
target.[FK_UnderwritingPlatform]         = source.[FK_UnderwritingPlatform],
target.[FK_InternalWrittenBinderStatus]  = source.[FK_InternalWrittenBinderStatus],
target.[SpecialPurposeSyndicateApplies]  = source.[SpecialPurposeSyndicateApplies],
target.[FK_ServiceCompany]               = source.[FK_ServiceCompany],
target.SectionSequenceId                 = source.SectionSequenceId,
target.AuditModifyDateTime	             = GETDATE(),						
target.AuditModifyDetails	             = 'Merge in ODS.usp_LoaClaimExposureSection proc'

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
		 FK_ClaimExposure
		,FK_Section
		,FK_TriFocus
		,FK_QuoteFilter
		,FK_HiddenStatusFilter
		,FK_Policy
		,FK_CRMBroker
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,SpecialPurposeSyndicateApplies
		,FK_ServiceCompany
		,SectionSequenceId
		,AuditCreateDateTime	 
		,AuditModifyDetails	

)  
VALUES
(source.[FK_ClaimExposure],
 source.[FK_Section],
 source.[FK_TriFocus],
 source.[FK_QuoteFilter],
 source.[FK_HiddenStatusFilter],
 source.[FK_Policy],
 source.[FK_CRMBroker],
 source.[FK_UnderwritingPlatform],
 source.[FK_InternalWrittenBinderStatus],
 source.[SpecialPurposeSyndicateApplies],
 source.[FK_ServiceCompany],
 source.SectionSequenceId,
 GETDATE(),
 'New add in ODS.usp_LoaClaimExposureSection proc');
	

	IF (OBJECT_ID('tempdb..#ClaimExposureSection') IS NOT NULL)
		DROP TABLE #ClaimExposureSection

	IF OBJECT_ID('tempdb..#x') is not null
		DROP TABLE #x

	IF OBJECT_ID('tempdb..#y') is not null
		DROP TABLE #y
/*
	----------------------------------------------------------------------------------
	/*Create temp table to hold mappings*/
	----------------------------------------------------------------------------------
	IF (OBJECT_ID('tempdb..#ClaimExposureSection') IS NOT NULL)
	DROP TABLE #ClaimExposureSection

	CREATE TABLE #ClaimExposureSection
	(
		FK_ClaimExposure        bigint          NOT NULL
		,FK_Section             bigint          NOT NULL	
		,TypeId					int				NULL
	);

	ALTER TABLE #ClaimExposureSection 
	ADD CONSTRAINT PK_#ClaimExposureSection 
	PRIMARY KEY NONCLUSTERED (FK_ClaimExposure);
	----------------------------------------------------------------------------------
	/* Zero - override the value coming from ClaimCenter 

	=>	in the future this will be changed directly in CC, v9 after Go live, 
		and after that it should be removed from here */
	----------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
	)
	SELECT
		 FK_ClaimExposure	= ce.PK_ClaimExposure
		,FK_Section			= s.PK_Section
		,TypeId				= 0
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		Staging_MDS.MDS_Staging.ClaimExposureToSectionMappingOverride AS cesmo
		ON cesmo.ccv9ExposureReference = ce.ExposureReference
		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = cesmo.NewSectionReference
	WHERE
		cesmo.StartDateInclusive <= CAST(CAST(GETDATE() as DATE) as VARCHAR)
		AND
		cesmo.EndDateInclusive >= CAST(CAST(GETDATE() as DATE) as VARCHAR)

	----------------------------------------------------------------------------------
	/* First, try to use the value from ClaimCenter "as is" */
	----------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section		
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,1
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		(
			SELECT	ClaimExposureSourceId, PrimarySectionName
			FROM	BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension
			WHERE	SourceSystem = 'Claimcenter' AND IsActive = 1
		) AS oce
		ON oce.ClaimExposureSourceId = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = oce.PrimarySectionName

		LEFT JOIN
		#ClaimExposureSection ces
		ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE	
		ces.FK_ClaimExposure IS NULL;
	
	----------------------------------------------------------------------------------
	/*Create temp table for Unirisx mappings*/
	----------------------------------------------------------------------------------

	IF (OBJECT_ID('tempdb..#UnirisxSectionToPolicyRetrieveMapping') IS NOT NULL)
	DROP TABLE #UnirisxSectionToPolicyRetrieveMapping

	CREATE TABLE #UnirisxSectionToPolicyRetrieveMapping
	(
		 PolicyRetrieveSectionReference	varchar(100) NOT NULL
		,PolicyReference				varchar(100) NOT NULL
		,SectionReference				varchar(100) NOT NULL
	);

	INSERT INTO #UnirisxSectionToPolicyRetrieveMapping
	(
		 PolicyRetrieveSectionReference
		,PolicyReference
		,SectionReference
	)
	SELECT	
		 PolicyRetrieveSectionReference	= REPLACE(se.PolicyRetrieveSectionReference, '--', '-')
		,PolicyReference				= se.PolicyReference
		,SectionReference				= se.SectionSourceId
	FROM
		BeazleyIntelligenceDataContract.Outbound.SectionExtension se
	WHERE
		se.SourceSystem = 'Unirisx'
		AND se.IsActive = 1;

	CREATE UNIQUE CLUSTERED INDEX UC_UnirisxSectionToPolicyRetrieveMapping 
	ON #UnirisxSectionToPolicyRetrieveMapping (PolicyRetrieveSectionReference, SectionReference);

	--------------------------------------------------------------------------------------------------
	/* For Unirisx, we need to join through the PolicyRetrieveSectionReference and the PolicyNumber */
	--------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT 
		 FK_ClaimExposure	= ce.PK_ClaimExposure
		,FK_Section			= s.PK_Section
		,2
	FROM
		ODS.ClaimExposure ce
		
		INNER JOIN
		(
			SELECT
				 ExposureReference	= cex.ClaimExposureSourceId
				,PrimarySectionName	= cex.PrimarySectionName
				,PolicyReference	= c.PolicyNumber
			FROM
				BeazleyIntelligenceDataContract.Outbound.Claim c
				INNER JOIN
				BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension cex
				ON 
				cex.SourceSystem		 = c.SourceSystem AND
				cex.ClaimSourceId		 = c.ClaimSourceId 
			WHERE
				cex.SourceSystem = 'Claimcenter' 
				AND cex.IsActive = 1 
				AND c.IsActive = 1
		)
		AS cee
		ON cee.ExposureReference = ce.ExposureReference

		INNER JOIN
		#UnirisxSectionToPolicyRetrieveMapping umap
		ON 	umap.PolicyRetrieveSectionReference = cee.PrimarySectionName
		AND umap.PolicyReference = cee.PolicyReference

		INNER JOIN
		ODS.Section s
		ON s.SectionReference = umap.SectionReference

		LEFT JOIN
		#ClaimExposureSection ces
		ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE	
		ces.FK_ClaimExposure IS NULL;

	-----------------------------------------------------------------------------------------------
	-- For BeazleyPro add '-01' to the section coming from V9 just to be sure we have a match
	-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,3
	FROM 
		ODS.ClaimExposure ce 

		INNER JOIN 
		(
			SELECT	
				 ExposureReference	= ClaimExposureSourceId
				,SectionReference	= CASE WHEN CHARINDEX('-',PrimarySectionName) > 0 THEN PrimarySectionName ELSE PrimarySectionName + '-01' END
			FROM
				BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension
			WHERE
				SourceSystem = 'Claimcenter'
				AND IsActive = 1
		)
		AS oce
		ON oce.ExposureReference = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = oce.SectionReference

		INNER JOIN 
		ODS.Policy p 
		ON p.PK_Policy = s.FK_Policy

		LEFT JOIN
		#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE
		ces.FK_ClaimExposure IS NULL
		AND
		p.SourceSystem IN ('BeazleyPro','FDR','Etrek');

		
	-----------------------------------------------------------------------------------------------
	-- For Eurobase, take the first section, from the policy number found in the Outbound.Claim
	-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,3
	FROM 
		(
			SELECT	cc.PolicyNumber, cc.ClaimSourceId
			FROM	BeazleyIntelligenceDatacontract.Outbound.Claim cc
			WHERE	cc.SourceSystem = 'ClaimCenter' AND cc.IsActive = 1
		)
		oc
		INNER JOIN 
		ODS.Claim c
		ON c.ClaimReference = oc.ClaimSourceId --Now we have the claim record in the ODS

		INNER JOIN 
		ODS.ClaimExposure ce 
		ON c.PK_Claim = ce.FK_Claim

		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = oc.PolicyNumber

		INNER JOIN 
		ODS.Section s 
		ON s.FK_Policy = p.PK_Policy
		AND s.SectionSequenceId = 1

		LEFT JOIN
		#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE
		ces.FK_ClaimExposure IS NULL
		AND
		p.SourceSystem = 'Eurobase';

	-----------------------------------------------------------------------------------------------
	-- For Eurobase, use the first 12 characters from the SectionReference sent by v9
	-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,5
	FROM 
		ODS.ClaimExposure ce 
		INNER JOIN 
		(
			SELECT	ClaimExposureSourceId, LEFT(PrimarySectionName,12) AS PrimarySectionName
			FROM	BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension
			WHERE	SourceSystem = 'Claimcenter' AND IsActive = 1
		)
		AS oce
		ON oce.ClaimExposureSourceId = ce.ExposureReference

		INNER JOIN 
		ODS.Section s 
		ON LEFT(s.SectionReference,12) = oce.PrimarySectionName

		INNER JOIN 
		ODS.Policy p 
		ON p.PK_Policy = s.FK_Policy

		LEFT JOIN
		#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE
		ces.FK_ClaimExposure IS NULL
		AND
		p.SourceSystem = 'Eurobase';

	------------------------------------------------------------------------------------------------------------------------
	-- For Eurobase, use the first 9 characters from the SectionReference sent by v9, BUT ignore some COBs that might match
	------------------------------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT 
		 FK_ClaimExposure
		,FK_Section
		,6
	FROM
	(
		SELECT
			 FK_ClaimExposure	= ce.PK_ClaimExposure
			,FK_Section			= s.PK_Section
			,RN					= ROW_NUMBER() OVER(PARTITION BY ce.PK_ClaimExposure 
													ORDER BY CASE 
																WHEN RIGHT(s.SectionReference,2) IN ('BR','LG','LV','MO','MU','UC','UD','UE','UF','UG','UJ','UK','UL','UM','UP','UR','UT','UU','UX','UZ','YO','YZ') 
																THEN 1 -- these ones will have a row_number > 1 when there are more than 2 rows, because we want to ignore them
																ELSE 0 
															 END)
		FROM 
			ODS.ClaimExposure ce 
			INNER JOIN 
			(
				SELECT	ClaimExposureSourceId, LEFT(PrimarySectionName , 9) AS PrimarySectionName, PrimarySectionName PRT
				FROM	BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension
				WHERE	SourceSystem = 'Claimcenter' AND IsActive = 1
			)
			AS oce
			ON oce.ClaimExposureSourceId = ce.ExposureReference

			INNER JOIN 
			ODS.Section s 
			ON LEFT(s.SectionReference, 9) = oce.PrimarySectionName

			INNER JOIN 
			ODS.Policy p 
			ON p.PK_Policy = s.FK_Policy

			LEFT JOIN
			#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
		WHERE
			ces.FK_ClaimExposure IS NULL
			AND
			p.SourceSystem = 'Eurobase'
	) AS T
	WHERE 
		T.RN = 1;

	--------------------------------------------------------------------------------------------------
	-- For the remaining ones just look at the policy found in the Claim and take its first section
	---------------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,7
	FROM 
		(
			SELECT	cc.PolicyNumber, cc.ClaimSourceId
			FROM	BeazleyIntelligenceDatacontract.Outbound.Claim cc
			WHERE	cc.SourceSystem = 'ClaimCenter' AND cc.IsActive = 1
		)
		oc
		INNER JOIN 
		ODS.Claim c
		ON c.ClaimReference = oc.ClaimSourceId --Now we have the claim record in the ODS

		INNER JOIN 
		ODS.ClaimExposure ce 
		ON c.PK_Claim = ce.FK_Claim

		INNER JOIN 
		ODS.Policy p 
		ON p.PolicyReference = oc.PolicyNumber

		INNER JOIN 
		ODS.Section s 
		ON s.FK_Policy = p.PK_Policy
		AND s.SectionSequenceId = 1

		LEFT JOIN
		#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE
		ces.FK_ClaimExposure IS NULL;
		
	-----------------------------------------------------------------------------------------------
	--If nothing worked just default to the unknown meber of the ODS.Section table
	-----------------------------------------------------------------------------------------------

	INSERT INTO #ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,TypeId
	)
	SELECT
		 FK_ClaimExposure               = ce.PK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,8
	FROM 
		ODS.ClaimExposure ce 

		INNER JOIN 
		ODS.Section s 
		ON s.SectionReference = 'N/A'

		LEFT JOIN
		#ClaimExposureSection ces ON ces.FK_ClaimExposure = ce.PK_ClaimExposure
	WHERE
		ces.FK_ClaimExposure IS NULL
	
	-----------------------------------------------------------------------------------------------
	/* Final insert */
	-----------------------------------------------------------------------------------------------
	TRUNCATE TABLE ODS.ClaimExposureSection

	INSERT INTO ODS.ClaimExposureSection
	(
		 FK_ClaimExposure
		,FK_Section
		,FK_TriFocus
		,FK_QuoteFilter
		,FK_HiddenStatusFilter
		,FK_Policy
		,FK_CRMBroker
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,FK_ServiceCompany
		,SpecialPurposeSyndicateApplies
	)
	SELECT
		 FK_ClaimExposure               = ces.FK_ClaimExposure
		,FK_Section                     = s.PK_Section
		,FK_TriFocus                    = s.FK_TriFocus
		,FK_QuoteFilter                 = s.FK_QuoteFilter
		,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
		,FK_Policy                      = s.FK_Policy
		,FK_CRMBroker                   = s.FK_CRMBroker
		,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus = s.FK_InternalWrittenBinderStatus
		,FK_ServiceCompany				= s.FK_ServiceCompany
		,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
	FROM 
		#ClaimExposureSection ces

		INNER JOIN 
		ODS.Section s 
		ON s.PK_Section = ces.FK_Section	

	
	IF (OBJECT_ID('tempdb..##ClaimExposureSection') IS NOT NULL)
	DROP TABLE #ClaimExposureSection
*/

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimExposureSection';

END
GO