﻿CREATE PROC [ODS].[usp_LoadClaimCostCategory]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ClaimCostCategory
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE FROM ODS.ClaimCostCategory WHERE ClaimCostCategory NOT IN (SELECT Code FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimCostCategory )
MERGE ODS.ClaimCostCategory target
USING
(
    SELECT
        ClaimCostCategory               = c.Code --REPLACE(c.Code,'Beazley Fees1', 'Beazley Fees')
        ,ClaimCostCategoryGroup         = c.ClaimCostCategoryGroup
        ,CCCostCategoryName             = c.CCCostCategoryName
        ,IsDeductibleCategory           = c.IsDeductibleCategory
    FROM
    BeazleyIntelligenceDataContract.Outbound.vw_ClaimCostCategory c
    WHERE 
    ISNULL(c.AuditModifyDatetime, c.AuditCreateDateTime) >= @LastAuditDate
) source
ON target.ClaimCostCategory = source.ClaimCostCategory
WHEN MATCHED THEN
UPDATE SET
    target.ClaimCostCategoryGroup  = source.ClaimCostCategoryGroup
    ,target.CCCostCategoryName     = source.CCCostCategoryName
    ,target.IsDeductibleCategory   = source.IsDeductibleCategory
    ,target.AuditModifyDateTime	   = GETDATE()						
    ,target.AuditModifyDetails	   = 'Merge in [ODS].[usp_LoadClaimCostCategory] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
     ClaimCostCategory
    ,ClaimCostCategoryGroup
    ,CCCostCategoryName
    ,IsDeductibleCategory
    ,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
     source.ClaimCostCategory
    ,source.ClaimCostCategoryGroup
    ,source.CCCostCategoryName
    ,source.IsDeductibleCategory
    ,GETDATE()
	,'New add in [ODS].[usp_LoadClaimCostCategory] proc'	
)
;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimCostCategory';