﻿CREATE PROCEDURE [ODS].[usp_LoadSectionRiskClass]
AS

SET NOCOUNT ON



IF OBJECT_ID('tempdb..#SectionRiskClass') IS NOT NULL
DROP TABLE #SectionRiskClass

CREATE TABLE #SectionRiskClass
(
    FK_Section                              bigint          NOT NULL
    ,FK_RiskCLass							bigint          NOT NULL
    ,RiskPercentage							NUMERIC (19, 12) NULL,
)

-- Load data when we have 1:1 mapping between Section and RiskClass -> RiskPercentage = 1

	INSERT INTO #SectionRiskClass
		(
		  [FK_Section]
		 ,[FK_RiskClass]
		 ,[RiskPercentage]
		 )
	SELECT 
		
		 FK_Section         = s.PK_Section 
		,FK_RiskClass		= r.PK_RiskClass
		,RiskPercentage		= 1
	FROM 

		BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass sr

		INNER JOIN
				(
					SELECT SectionSourceId
					FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass 
					GROUP BY SectionSourceId
					HAVING COUNT(*) = 1 
					) d ON d.SectionSourceId = sr.SectionSourceId
		
		INNER JOIN ODS.Section s ON sr.SectionSourceId = s.SectionReference
		
		INNER JOIN ODS.RiskClass r ON r.RiskClassCode = sr.RiskClassCode	
		GROUP BY s.PK_Section ,r.PK_RiskClass

-- Load data when we have 1:n mapping between Section and RiskClass -> we take RiskPercentage when sum(RiskClassPercentage) for a section = 100

	INSERT INTO #SectionRiskClass
		(
		  [FK_Section]
		 ,[FK_RiskClass]
		 ,[RiskPercentage]
		 )
	SELECT 
		
		 FK_Section         = s.PK_Section 
		,FK_RiskClass		= r.PK_RiskClass
		,RiskPercentage		=  SUM(CAST(sr.RiskClassPercentage AS NUMERIC(19,12))/CAST(100 AS NUMERIC(19,12)))
	
	FROM 

		BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass sr

		INNER JOIN
				(
					SELECT 
							 SectionSourceId	
							,RiskClassPercentageAgg = SUM(RiskClassPercentage) 				
					FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass 
					GROUP BY SectionSourceId
					HAVING COUNT(*) > 1 
					) d ON d.SectionSourceId = sr.SectionSourceId
		
		INNER JOIN ODS.Section s ON sr.SectionSourceId = s.SectionReference
		
		INNER JOIN ODS.RiskClass r ON r.RiskClassCode = sr.RiskClassCode

	WHERE  NOT EXISTS (SELECT FK_Section FROM #SectionRiskClass st WHERE st.FK_Section = s.PK_Section)
		   AND RiskClassPercentageAgg  = 100
	GROUP BY s.PK_Section ,r.PK_RiskClass

-- Load data when we have 1:n mapping between Section and RiskClass -> we calculate RiskPercentage when sum for a section <> 100

	INSERT INTO #SectionRiskClass
			(
			  [FK_Section]
			 ,[FK_RiskClass]
			 ,[RiskPercentage]
			 )
	SELECT 
		
		 FK_Section         = s.PK_Section 
		,FK_RiskClass		= r.PK_RiskClass
		,RiskPercentage		=  CASE WHEN SUM(RiskClassPercentageAgg) = 0 THEN CAST(1 as NUMERIC (19, 12))/COUNT(*) OVER (PARTITION BY s.PK_Section )
									ELSE SUM(cast(sr.RiskClassPercentage as NUMERIC (19, 12))/cast(NULLIF(RiskClassPercentageAgg,0) as NUMERIC (19, 12)))
							   END
	FROM 

		BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass sr

		INNER JOIN
				(
					SELECT 
							 SectionSourceId	
							,RiskClassPercentageAgg = SUM(RiskClassPercentage) 				
					FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass 
					GROUP BY SectionSourceId
					HAVING COUNT(*) > 1 
					) d ON d.SectionSourceId = sr.SectionSourceId
		
		INNER JOIN ODS.Section s ON sr.SectionSourceId = s.SectionReference
		
		INNER JOIN ODS.RiskClass r ON r.RiskClassCode = sr.RiskClassCode

	WHERE  NOT EXISTS (SELECT FK_Section FROM #SectionRiskClass st WHERE st.FK_Section = s.PK_Section) 
		   AND RiskClassPercentageAgg  <> 100
	GROUP BY s.PK_Section ,r.PK_RiskClass
			
	MERGE ODS.SectionRiskClass AS target
	USING #SectionRiskClass source 
	ON  target.FK_Section = source.FK_Section
	AND target.FK_RiskClass = source.FK_RiskClass
	WHEN MATCHED THEN
	UPDATE SET
	target.RiskPercentage			  = source.RiskPercentage
	,target.AuditModifyDateTime	      = GETDATE()						
	,target.AuditModifyDetails	      = 'Merge in ODS.usp_LoadSectionRiskClass proc' 
	WHEN NOT MATCHED BY SOURCE THEN DELETE
	WHEN NOT MATCHED BY TARGET THEN
	INSERT
	(
	FK_Section 
	,FK_RiskClass
	,RiskPercentage		
	,AuditCreateDateTime	 
	,AuditModifyDetails	 
	)
	VALUES
	(
	 source.FK_Section 
	,source.FK_RiskClass
	,source.RiskPercentage		
	,GETDATE()
	,'New add in ODS.usp_LoadSectionRiskClass proc'	
	);


	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'SectionRiskClass';