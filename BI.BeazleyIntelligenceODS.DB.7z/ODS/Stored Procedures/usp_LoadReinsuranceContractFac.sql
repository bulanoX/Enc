﻿

CREATE PROCEDURE [ODS].[usp_LoadReinsuranceContractFac]
AS

SET NOCOUNT ON

DECLARE		@LastAuditDate DATETIME2(7)

SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime, AuditCreateDateTime))
FROM		ODS.ReinsuranceContractFac

SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');

--Clear Previous Data
--DELETE FROM ODS.ReinsuranceContractFac;

MERGE ODS.ReinsuranceContractFac as TARGET

USING 
(
SELECT
 ContractReference		= rcf.ContractReference		
,ContractShortName		= rcf.ContractShortName		
,ContractDescription	= rcf.ContractDescription	
,ContractType			= rcf.ContractType			
,ContractPolicyType		= rcf.ContractPolicyType		
,PeriodFromDate			= rcf.PeriodFromDate			
,PeriodToDate			= rcf.PeriodToDate			
,SignedOrderMultiplier	= rcf.SignedOrderMultiplier	
,OverriderCommission	= rcf.OverriderCommission	

FROM 
BeazleyIntelligenceDataContract.Outbound.vw_ReinsuranceContractFac rcf
WHERE rcf.SourceSystem = 'Eurobase'
--AND rcf.IsActive = 1 
--AND (rcf.AuditModifyDateTime	 > @LastAuditDate OR rcf.AuditCreateDateTime	    > @LastAuditDate)
ORDER BY 
	CAST(rcf.ReinsuranceContractFacSourceId AS INT) ---CAST for ordering as INT not VARCHAR. ReinsuranceContractFacSourceId is populating with fac_number from Source System
OFFSET 0 ROWS
) AS SOURCE

ON TARGET.ContractReference = SOURCE.ContractReference


WHEN MATCHED THEN

UPDATE SET

 TARGET.ContractReference		= SOURCE.ContractReference		
,TARGET.ContractShortName		= SOURCE.ContractShortName		
,TARGET.ContractDescription	    = SOURCE.ContractDescription	
,TARGET.ContractType			= SOURCE.ContractType			
,TARGET.ContractPolicyType		= SOURCE.ContractPolicyType		
,TARGET.PeriodFromDate			= SOURCE.PeriodFromDate			
,TARGET.PeriodToDate			= SOURCE.PeriodToDate			
,TARGET.SignedOrderMultiplier	= SOURCE.SignedOrderMultiplier	
,TARGET.OverriderCommission	    = SOURCE.OverriderCommission
,TARGET.AuditModifyDateTime     = GETDATE()
,TARGET.AuditModifyDetails      = 'Merge in [ODS].[ReinsuranceContractFac] table'

WHEN NOT MATCHED BY TARGET THEN

INSERT
(
ContractReference
    ,ContractShortName
    ,ContractDescription
    ,ContractType
    ,ContractPolicyType
    ,PeriodFromDate
    ,PeriodToDate
    ,SignedOrderMultiplier
    ,OverriderCommission
	,AuditModifyDetails

 )
 VALUES
 (
	 SOURCE.ContractReference
    ,SOURCE.ContractShortName
    ,SOURCE.ContractDescription
    ,SOURCE.ContractType
    ,SOURCE.ContractPolicyType
    ,SOURCE.PeriodFromDate
    ,SOURCE.PeriodToDate
    ,SOURCE.SignedOrderMultiplier
    ,SOURCE.OverriderCommission
	,'New in [ODS].[ReinsuranceContractFac] table' 
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceContractFac';