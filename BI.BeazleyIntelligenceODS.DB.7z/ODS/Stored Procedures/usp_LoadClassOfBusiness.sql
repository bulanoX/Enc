﻿

CREATE PROCEDURE  [ODS].[usp_LoadClassOfBusiness]
AS

SET NOCOUNT ON

DELETE FROM ODS.ClassOfBusiness WHERE ClassOfBusinessCode NOT IN (SELECT ISNULL(Utility.udf_ProcessString(ClassOfBusinessCode, 1), '')  FROM Staging_MDS.dbo.vw_cob_codes ) AND IsUnknownMember= 0

MERGE ODS.ClassOfBusiness AS t
USING (

	SELECT 
			 src.IsUnknownMember
			,src.ClassOfBusinessCode
			,src.ClassOfBusiness
			,src.ClassOfBusinessGroup
			,src.EffectiveFrom
			,src.EffectiveTo
			,src.TerrorismClass
	FROM (

			SELECT  DISTINCT
				 IsUnknownMember			= 0
				,ClassOfBusinessCode        = ISNULL(Utility.udf_ProcessString(ClassOfBusinessCode, 1), '') 
				,ClassOfBusiness            = Utility.udf_ConvertTitleCase(Utility.udf_ProcessString(ClassOfBusiness, 1),
											'BICI~BUSA~BBR~TRIA~ATIA~TRIEA~CI/XT~ PE~PCL~ MM~BBB~RWI~WCA~EPL~ML~SBC~ US~US ~UK ~ UK~FAC~PA ~PA ~TMB~SA ~ CF ~ BI~PD/BI~GL ~GL/~ GL~GA ~FTC/MTC~OPPI'
											,'acilit~inder~ailroad~mpairment~scellaneous~nufactur~alicious~urplus~rial~ompanies')
				,ClassOfBusinessGroup       = Utility.udf_ProcessString(ClassOfBusinessGroup, 1)
				,EffectiveFrom              = Utility.udf_LaterDate(Utility.udf_ProcessEurobaseDate(EffectiveFrom), '1/1/1990')
				,EffectiveTo                = Utility.udf_ProcessEurobaseDate(EffectiveTo)
				,TerrorismClass             = CASE WHEN LEFT(ClassOfBusinessCode, 1) IN ('U', 'X') THEN 1 ELSE 0 END      
			FROM Staging_MDS.dbo.vw_cob_codes

			UNION
	
			SELECT
				 IsUnknownMember                 = 1
				,ClassOfBusinessCode             = 'N/A' 
				,ClassOfBusiness                 = 'N/A'
				,ClassOfBusinessGroup			 = NULL
				,EffectiveFrom					 = NULL
				,EffectiveTo					 = NULL
				,TerrorismClass                  = 0
		) src
		LEFT JOIN  ODS.ClassOfBusiness cb ON src.ClassOfBusinessCode = cb.ClassOfBusinessCode
											-- AND src.IsUnknownMember = cb.IsUnknownMember
		WHERE (cb.ClassOfBusinessCode IS NULL
		      OR (	cb.ClassOfBusiness			<> src.ClassOfBusiness
					OR cb.ClassOfBusinessGroup	<> src.ClassOfBusinessGroup
					OR cb.EffectiveFrom 		<> src.EffectiveFrom
					OR cb.EffectiveTo 			<> src.EffectiveTo
					OR cb.TerrorismClass		<> src.TerrorismClass)
					)
					
	
		) AS s
		(
		 IsUnknownMember
		,ClassOfBusinessCode 
		,ClassOfBusiness
		,ClassOfBusinessGroup
		,EffectiveFrom 
		,EffectiveTo 
		,TerrorismClass
		)
		ON s.ClassOfBusinessCode = t.ClassOfBusinessCode
	--	AND s.IsUnknownMember	 = t.IsUnknownMember
		
WHEN MATCHED THEN
UPDATE
SET  
	 t.ClassOfBusiness			= s.ClassOfBusiness
	,t.ClassOfBusinessGroup	 	= s.ClassOfBusinessGroup
	,t.EffectiveFrom 			= s.EffectiveFrom
	,t.EffectiveTo 				= s.EffectiveTo
	,t.TerrorismClass			= s.TerrorismClass
	,t.AuditModifyDateTime		= GETDATE()						
	,t.AuditModifyDetails		= 'Merge in [ODS].[ClassOfBusiness] table' 


WHEN NOT MATCHED BY TARGET THEN 
INSERT 
(
     IsUnknownMember
	,ClassOfBusinessCode
    ,ClassOfBusiness
    ,ClassOfBusinessGroup
    ,EffectiveFrom
    ,EffectiveTo
    ,TerrorismClass
	,AuditModifyDetails
)
VALUES ( 
         s.IsUnknownMember
		,s.ClassOfBusinessCode 
		,s.ClassOfBusiness
		,s.ClassOfBusinessGroup
		,s.EffectiveFrom 
		,s.EffectiveTo 
		,s.TerrorismClass
		,'New add in [ODS].[ClassOfBusiness] table'
		);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClassOfBusiness';