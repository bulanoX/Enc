﻿

CREATE PROCEDURE [ODS].[usp_LoadYOA]
AS

SET NOCOUNT ON


DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.YOA

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


IF OBJECT_ID('tempdb..#YOATemp') IS NOT NULL
DROP TABLE #YOATemp

CREATE TABLE #YOATemp 
(
    [PK_YOA]				BIGINT			NOT NULL,
	[FirstDate]				DATETIME		NOT NULL,
	[YOAName]				VARCHAR(255)	NOT NULL,
	[MaxDevelopmentMonth]	INT				NOT NULL,
)


/*Unknown member YOA*/
INSERT INTO #YOATemp
(
	PK_YOA
	,FirstDate
	,YOAName
	,MaxDevelopmentMonth
)
SELECT
PK_YOA                      = 0
,FirstDate                  = '1/1/1753'
,YOAName                    = 'N/A'
,MaxDevelopmentMonth        = 0


INSERT INTO #YOATemp
(
     PK_YOA
     ,FirstDate
     ,YOAName
     ,MaxDevelopmentMonth
)
SELECT
PK_YOA                  = YEAR(d.PK_Date)
,FirstDate              = d.PK_Date
,YOAName                = YEAR(d.PK_Date)
,MaxDevelopmentMonth    = Utility.udf_GreaterOf(DATEDIFF(MM, d.PK_Date, GETDATE()) + 1, 0)
FROM
ODS.DimDate d
WHERE
d.[DayOfYear] = 1
AND YEAR(d.PK_Date) <> 1753
ORDER BY
YEAR(d.PK_Date)


MERGE ODS.YOA AS TARGET
USING 
#YOATemp AS SOURCE
ON (
		ISNULL(Source.PK_YOA, 'Not Available') = ISNULL(Target.PK_YOA, 'Not Available')
)
WHEN MATCHED THEN
UPDATE SET
   target.FirstDate					= source.FirstDate
   ,target.YOAName					= source.YOAName
   ,target.MaxDevelopmentMonth		= source.MaxDevelopmentMonth
   ,target.AuditModifyDateTime		= GETDATE()						
   ,target.AuditModifyDetails		= 'Merge in ODS.usp_LoadYOA proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    PK_YOA
    ,FirstDate
    ,YOAName
	,MaxDevelopmentMonth
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.PK_YOA
    ,source.FirstDate
    ,source.YOAName
	,source.MaxDevelopmentMonth
	,GETDATE()
	,'New add in ODS.usp_LoadYOA proc'	
)
WHEN NOT MATCHED BY SOURCE THEN 
DELETE
;