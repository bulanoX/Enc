﻿

CREATE PROCEDURE [ODS].[usp_LoadWorkflowStatus]
AS

SET NOCOUNT ON


DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.WorkflowStatus

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


IF OBJECT_ID('tempdb..#WorkflowStatus') IS NOT NULL
DROP TABLE #WorkflowStatus

CREATE TABLE #WorkflowStatus 
(
    [IsUnknownMember]		BIT NOT NULL,
    [WorkflowStatusCode]    VARCHAR (255) NOT NULL,
    [WorkflowStatusName]    VARCHAR (255) NOT NULL,
)

-----Unknown Member WorkflowStatus
INSERT INTO #WorkflowStatus
(
	IsUnknownMember
	,WorkflowStatusCode
	,WorkflowStatusName
)
SELECT
IsUnknownMember         = 1
,WorkflowStatusCode     = 'N/A' 
,WorkflowStatusName     = 'N/A'     


INSERT INTO #WorkflowStatus
(
    IsUnknownMember
    ,WorkflowStatusCode
    ,WorkflowStatusName
)
SELECT DISTINCT
IsUnknownMember              = 0
,WorkflowStatusCode          = bw.WorkflowStatusCode
,WorkflowStatus              = bw.WorkflowStatus
FROM
BeazleyIntelligenceDataContract.Outbound.vw_BusinessWorkflow bw
--WHERE bw.IsActive = 1


MERGE ODS.WorkflowStatus AS TARGET
USING 
#WorkflowStatus AS SOURCE
ON (
		ISNULL(Source.WorkflowStatusCode, 'Not Available') = ISNULL(Target.WorkflowStatusCode, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
)
WHEN MATCHED THEN
UPDATE SET
    target.WorkflowStatusCode		= source.WorkflowStatusCode
   ,target.WorkflowStatusName       = source.WorkflowStatusName
   ,target.AuditModifyDateTime		= GETDATE()						
   ,target.AuditModifyDetails		= 'Merge in ODS.usp_LoadWorkflowStatus proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    IsUnknownMember
    ,WorkflowStatusCode
    ,WorkflowStatusName
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.IsUnknownMember
    ,source.WorkflowStatusCode
    ,source.WorkflowStatusName
	,GETDATE()
	,'New add in ODS.usp_LoadWorkflowStatus proc'	
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;