﻿
CREATE PROCEDURE [ODS].[usp_LoadSectionLine]
AS
BEGIN

--TRUNCATE TABLE ODS.SectionLine

	IF OBJECT_ID('tempdb..#SectionLine') IS NOT NULL
	DROP TABLE #SectionLine
	
	CREATE TABLE #SectionLine 
	(
	    [FK_Section]						BIGINT			NOT NULL,
		[FK_Syndicate]						BIGINT			NOT NULL,
		[WrittenLineMultiplier]				NUMERIC(19, 12) NOT NULL,
		[SignedLineMultiplier]				NUMERIC(19, 12) NULL,
		[WrittenIfNotSignedLineMultiplier]	NUMERIC(19, 12) NOT NULL,
		[HashbytesId]						BIGINT			NULL
	)

	/*Load section lines*/
	INSERT INTO #SectionLine
	(
		FK_Section
		,FK_Syndicate
		,WrittenLineMultiplier
		,SignedLineMultiplier
		,WrittenIfNotSignedLineMultiplier
	)
	SELECT
		FK_Section                                  = s.PK_Section 
		,FK_Syndicate                               = syn.PK_Syndicate 
		,WrittenLineMultiplier                      = isnull(sl.WrittenLineMultiplier,1) 
		,SignedLineMultiplier                       = sl.SignedLineMultiplier 
		,WrittenIfNotSignedLineMultiplier           = sl.WrittenIfNotSignedLineMultiplier

	FROM Staging.SectionLine sl 

	INNER JOIN 
		(
			SELECT
				SectionReference
				,PK_Section
			FROM Staging.Section--ODS.Section 
		) s 
	ON sl.SectionReference = s.SectionReference

	INNER JOIN ODS.Syndicate syn 
	ON sl.SyndicateNumber = syn.SyndicateNumber


MERGE ODS.SectionLine target
USING 
#SectionLine source
ON (
	ISNULL(Source.FK_Section, 'Not Available') = ISNULL(Target.FK_Section, 'Not Available')
AND ISNULL(Source.FK_Syndicate, 'Not Available') = ISNULL(Target.FK_Syndicate, 'Not Available')
)

WHEN MATCHED THEN
UPDATE SET
   target.WrittenLineMultiplier             = source.WrittenLineMultiplier
   ,target.SignedLineMultiplier             = source.SignedLineMultiplier
   ,target.WrittenIfNotSignedLineMultiplier	= source.WrittenIfNotSignedLineMultiplier
   ,target.HashbytesId						= source.HashbytesId
   ,target.AuditModifyDateTime				= GETDATE()						
   ,target.AuditModifyDetails				= 'Merge in ODS.usp_LoadSectionLine proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    FK_Section
    ,FK_Syndicate
    ,WrittenLineMultiplier
    ,SignedLineMultiplier
	,WrittenIfNotSignedLineMultiplier
	,HashbytesId
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.FK_Section
    ,source.FK_Syndicate
    ,source.WrittenLineMultiplier
    ,source.SignedLineMultiplier
	,source.WrittenIfNotSignedLineMultiplier
	,HashbytesId
	,GETDATE()
	,'New add in ODS.usp_LoadSectionLine proc'	
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;
END
