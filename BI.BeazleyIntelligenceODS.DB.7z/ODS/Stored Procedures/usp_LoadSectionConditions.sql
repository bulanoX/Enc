﻿CREATE PROCEDURE [ODS].[usp_LoadSectionConditions]
AS

SET NOCOUNT ON

BEGIN
	
	TRUNCATE TABLE [ODS].[SectionConditions]

	INSERT INTO [ODS].[SectionConditions]
		(
		  [FK_Section]
		 ,[FK_ConditionType]
		 )
	SELECT 
		
		 FK_Section         = s.PK_Section 
		,FK_ConditionType	= c.PK_ConditionType
	FROM 

		BeazleyIntelligenceDataContract.Outbound.vw_SectionConditions sc
		
		INNER JOIN ODS.Section s ON sc.SectionSourceId = s.SectionReference
		
		INNER JOIN ODS.ConditionType c ON c.ConditionTypeCode = SC.ConditionCode	

		GROUP BY s.PK_Section ,c.PK_ConditionType

	
	EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'SectionConditions';
		
END