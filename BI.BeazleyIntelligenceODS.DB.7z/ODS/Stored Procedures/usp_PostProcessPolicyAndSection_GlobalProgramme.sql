﻿
CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_GlobalProgramme]
AS

SET NOCOUNT ON


 /* BI-5135 Start*/
 

IF (OBJECT_ID('tempdb..#GlobalProgramme')) IS NOT NULL
DROP TABLE #GlobalProgramme

CREATE TABLE #GlobalProgramme
(
     FK_Policy            		BIGINT		 NOT NULL
	,FK_Section           		BIGINT 		 NOT NULL
	,TrifocusName        		VARCHAR(255) NOT NULL
    ,GblPgmId          			VARCHAR(255) NULL
	,GblPgmName 				VARCHAR(255) NULL
	,GblPgmPolicyType			VARCHAR(255) NULL
	,GblPgmUnderwriter        	VARCHAR(255) NULL           
	,GblPgmProducingOffice 		VARCHAR(255) NULL
	,rnk						INT          NULL
    PRIMARY KEY (FK_Section)
)

--Load Eurobase data
INSERT INTO #GlobalProgramme
 (
	 FK_Policy
	,FK_Section  
	,TrifocusName
	,GblPgmId                  
	,GblPgmName             
	,GblPgmPolicyType                          
	,GblPgmUnderwriter                     
	,GblPgmProducingOffice  
	,rnk
	)
SELECT 
	 FK_Policy        		= s.FK_Policy
	,FK_Section				= s.PK_Section
	,TrifocusName			= t.TrifocusName
	,GblPgmId 				= g.GblPgmId                
	,GblPgmName  			= g.GblPgmName           
	,GblPgmPolicyType 		= g.GblPgmPolicyType                         
	,GblPgmUnderwriter 		= g.GblPgmUnderwriter                    
	,GblPgmProducingOffice	= g.GblPgmProducingOffice
	,rnk 					= 1
FROM BeazleyIntelligenceDataContract.Outbound.vw_GlobalProgramme g

INNER JOIN ODS.Section s 
ON g.SourceSystem = s.SourceSystem
AND g.RiskReference = s.SectionReference

INNER JOIN ODS.Trifocus t
ON s.FK_Trifocus = t.PK_Trifocus

WHERE g.SourceSystem = 'Eurobase'

-- Load Eurobase data for sections not sent in DataContract
INSERT INTO #GlobalProgramme
 (
	 FK_Policy
	,FK_Section 
	,TrifocusName	
	,GblPgmId                  
	,GblPgmName             
	,GblPgmPolicyType                          
	,GblPgmUnderwriter                     
	,GblPgmProducingOffice 
	,rnk
	)
SELECT 
	 FK_Policy				= s.FK_Policy
	,FK_Section 	     	= s.PK_Section
	,TrifocusName			= t.TrifocusName
	,GblPgmId 				= g.GblPgmId                
	,GblPgmName  			= g.GblPgmName           
	,GblPgmPolicyType 		= g.GblPgmPolicyType                         
	,GblPgmUnderwriter 		= g.GblPgmUnderwriter                    
	,GblPgmProducingOffice	= g.GblPgmProducingOffice
	,rnk					= 1					

FROM #GlobalProgramme g

INNER JOIN ODS.Section s 
ON  g.FK_Policy = s.FK_Policy

INNER JOIN ODS.Trifocus t
ON s.FK_Trifocus = t.PK_Trifocus

INNER JOIN ODS.section sg 
ON sg.PK_Section = g.fk_section

WHERE s.SourceSystem = 'Eurobase'
AND s.PK_Section NOT IN (SELECT FK_Section FROM #GlobalProgramme)
AND SUBSTRING(sg.SectionReference, LEN(sg.SectionReference)-3, 1) = 'A'	

--Load other systems than Eurobase	
INSERT INTO #GlobalProgramme
 (
	 FK_Policy
	,FK_Section  
	,TrifocusName
	,GblPgmId                  
	,GblPgmName             
	,GblPgmPolicyType                          
	,GblPgmUnderwriter                     
	,GblPgmProducingOffice   
	,rnk
	)
SELECT 
	 FK_Policy 				= p.PK_Policy
	,FK_Section				= s.PK_Section
	,TrifocusName			= t.TrifocusName
	,GblPgmId 				= g.GblPgmId                
	,GblPgmName  			= g.GblPgmName           
	,GblPgmPolicyType 		= g.GblPgmPolicyType                         
	,GblPgmUnderwriter 		= g.GblPgmUnderwriter                    
	,GblPgmProducingOffice	= g.GblPgmProducingOffice
	,rnk = RANK () OVER (PARTITION BY s.FK_Policy ORDER BY  s.WrittenOrEstimatedPremiumInOriginalCCY DESC)
FROM BeazleyIntelligenceDataContract.Outbound.vw_GlobalProgramme g

INNER JOIN ODS.Policy p 
ON --g.SourceSystem = p.SourceSystem AND
 g.RiskReference = p.PolicyReference

INNER JOIN ODS.Section s		   
ON p.PK_Policy = s.FK_Policy

INNER JOIN ODS.Trifocus t
ON s.FK_Trifocus = t.PK_Trifocus

WHERE g.SourceSystem <> 'Eurobase'	
	
	
UPDATE s
SET  GblPgmId 				= g.GblPgmId                
	,GblPgmName  			= g.GblPgmName           
	,GblPgmPolicyType 		= g.GblPgmPolicyType                         
	,GblPgmUnderwriter 		= g.GblPgmUnderwriter                    
	,GblPgmProducingOffice	= g.GblPgmProducingOffice
	,IsGblPgm 				= CASE WHEN g.GblPgmId IS NULL THEN 'No' ELSE 'Yes' END
FROM ODS.Section s
INNER JOIN #GlobalProgramme g
ON s.PK_Section = g.FK_Section

UPDATE s
SET GblPgmMasterTriFocus = m.TrifocusName
FROM ODS.Section s
INNER JOIN #GlobalProgramme m
ON s.GblPgmId = m.GblPgmId
WHERE m.GblPgmPolicyType = 'Master'
AND m.rnk = 1


IF OBJECT_ID('tempdb..#GlobalProgramme') IS NOT NULL
DROP TABLE #GlobalProgramme

 /* BI-5135 End*/