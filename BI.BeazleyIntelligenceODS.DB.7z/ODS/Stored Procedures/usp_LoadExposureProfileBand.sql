﻿CREATE PROCEDURE [ODS].[usp_LoadExposureProfileBand]
AS

SET NOCOUNT ON

MERGE [ODS].[ExposureProfileBand] target
USING
(
	SELECT
	BandType        = epb.BandType
	,Department     = epb.Department_Name
	,BandMin        = epb.BandMin
	,BandMax        = epb.BandMax
	,BandName       = epb.BandName
	FROM
	Staging_MDS.MDS_Staging.ExposureProfileBand epb
) source
ON  target.BandType   = source.BandType
AND target.Department = source.Department
AND target.BandMin    = source.BandMin 

WHEN MATCHED THEN 
UPDATE 
SET 
   target.BandMax			   = source.BandMax
  ,target.BandName			   = source.BandName
  ,target.AuditModifyDateTime  = GETDATE()
  ,target.AuditModifyDetails   = 'Merge in [ODS].[usp_LoadExposureProfileBand] proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
   BandType			  
  ,Department			  
  ,BandMin				  
  ,BandMax				  
  ,BandName			  
  ,AuditCreateDateTime   
  ,AuditModifyDetails 
)  
VALUES
(
  source.BandType
  ,source.Department
  ,source.BandMin
  ,source.BandMax
  ,source.BandName
  ,GETDATE()
  ,'New add in [ODS].[usp_LoadExposureProfileBand] proc'
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

---- TEMP CODE.  NEED TO DEPLOY THESE LINES TO MDS (EVENTUALLY)
--DELETE ODS.ExposureProfileBand WHERE BandType = 'Premium'
--INSERT ODS.ExposureProfileBand
--(BandType, Department, BandMin, BandMax, BandName)
--SELECT 'Premium', 'Specialty Lines' , -1000000000000000000000,		0, 'Nil'			UNION
--SELECT 'Premium', 'Specialty Lines' , 0,		50000, '<=50k'			UNION
--SELECT 'Premium', 'Specialty Lines' ,  50000,  100000, '50k - 100k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 100000, 150000, '100k - 150k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 150000, 200000, '150k - 200k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 200000, 250000, '200k - 250k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 250000, 300000, '250k - 300k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 300000, 350000, '300k - 350k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 350000, 400000, '350k - 400k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 400000, 450000, '400k - 450k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 450000, 500000, '450k - 500k'	UNION
--SELECT 'Premium', 'Specialty Lines' , 500000, 1000000000000000000000, '500k+'

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ExposureProfileBand';