﻿CREATE PROCEDURE [ODS].[usp_LoadSyndicate]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#Syndicate') IS NOT NULL)
DROP TABLE #Syndicate

CREATE TABLE #Syndicate
(
    [SyndicateNumber] [int] NOT NULL,
	[SyndicateName] [varchar](255) NULL,
	[SyndicateGroupName] [varchar](255) NULL
)

INSERT INTO #Syndicate
(
    SyndicateNumber
    ,SyndicateName
    ,SyndicateGroupName
)
SELECT
SyndicateNumber             = s.SyndicateNumber
,SyndicateName              = Utility.udf_ProcessString(s.SyndicateName, 1)
,SyndicateGroupNumber       = CASE s.SyndicateNumber
                                WHEN 623 THEN '623/2623'
                                WHEN 2623 THEN '623/2623'
                                ELSE CAST(s.SyndicateNumber AS varchar(255))
                              END
FROM
Staging_MDS.dbo.vw_syndicate_control s

MERGE ODS.Syndicate AS TARGET

USING #Syndicate AS SOURCE

 ON TARGET.SyndicateNumber            = SOURCE.SyndicateNumber

WHEN MATCHED THEN

UPDATE SET 
 TARGET.SyndicateNumber       = SOURCE.SyndicateNumber
,TARGET.SyndicateName         = SOURCE.SyndicateName
,TARGET.SyndicateGroupName    = SOURCE.SyndicateGroupName
,TARGET.AuditModifyDateTime   = GETDATE()						
,TARGET.AuditModifyDetails	  = 'Merge in [ODS].[Syndicate] table' 

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 SyndicateNumber
    ,SyndicateName
	,SyndicateGroupName
	,AuditModifyDetails
)
VALUES
(
 SOURCE.SyndicateNumber
,SOURCE.SyndicateName
,SOURCE.SyndicateGroupName
,'New in [ODS].[Syndicate] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE;

IF (OBJECT_ID('tempdb..#Syndicate') IS NOT NULL)
DROP TABLE #Syndicate