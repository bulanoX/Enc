﻿
CREATE PROCEDURE [ODS].[usp_LoadClaimEstimate]
AS

SET NOCOUNT ON          



/*******************************************************************************************/
-- Insert data in ODS Claim Movement Estimate table
-- We generate a reverse sequence ID to easily detect the most up to date values for a claim
-- (i.e. where ReverseSequenceID = 1)
/*******************************************************************************************/

--Insert into temp table
DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ClaimEstimate
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF OBJECT_ID('tempdb..#ClaimEstimate') IS NOT NULL
DROP TABLE #ClaimEstimate

CREATE TABLE #ClaimEstimate
	(
	[BeazleyShareMultipler] [numeric](20, 4) NULL,
	[BlendAmtOriginalCCY] [numeric](20, 4) NULL,
	[BlendWeightingMultiplier] [numeric](19, 12) NULL,
	[CreateDate] [datetime] NOT NULL,
	[DateSinceBlend] [datetime2](7) NULL,
	[DateSinceMostLikely] [datetime2](7) NULL,
	[DateSincePessimistic] [datetime2](7) NULL,
	[ExpectedRecoveriesOriginalCCY] [numeric](19, 4) NULL,
	[ExposureOriginalCCY] [nvarchar](255) NULL,
	[ExposureStatusCode] [varchar](255) NULL,
	[FK_ClaimExposure] [bigint] NOT NULL,
	[MostLikelyOriginalCCY] [numeric](19, 4) NULL,
	[PessimisticOriginalCCY] [numeric](19, 4) NULL,
	[ReverseSequenceID] [int] NOT NULL
	)

TRUNCATE TABLE  #ClaimEstimate
INSERT INTO #ClaimEstimate

(
   FK_ClaimExposure                                    
  ,CreateDate                              
  ,MostLikelyOriginalCCY         
  ,PessimisticOriginalCCY        
  ,ExpectedRecoveriesOriginalCCY 
  ,BlendWeightingMultiplier                    
  ,ReverseSequenceID
  ,ExposureStatusCode    
  ,DateSincePessimistic
  ,DateSinceMostLikely
  ,DateSinceBlend   
  ,BlendAmtOriginalCCY      
  ,BeazleyShareMultipler    
  ,ExposureOriginalCCY 
)

SELECT  
        FK_ClaimExposure                    = ISNULL(ce.PK_ClaimExposure , 0)
       ,CreateDate                          = COALESCE(cee.[ClaimEstimateUpdateDate], cee.ClaimEstimateCreateDate)
       ,MostLikelyOriginalCCY               = cee.[MostLikelyOriginalCCY]                                                                                                                  
       ,PessimisticOriginalCCY              = cee.[PessimisticOriginalCCY]
       ,ExpectedRecoveriesOriginalCCY       = cee.[ExpectedRecoveriesOriginalCCY]
       ,BlendWeightingMultiplier            = COALESCE(Utility.udf_ProcessPercentage(cee.[BlendWeightingMultiplier], 1, 0, 1),0)
       ,ReverseSequenceID                   = ROW_NUMBER() OVER (PARTITION BY ISNULL(ce.PK_ClaimExposure , 0) ORDER BY cee.[ClaimEstimateCreateDate] DESC) 
	   ,ExposureStatusCode					= ce.ExposureStatusCode
	   ,DateSincePessimistic				= cee.DateSincePessimistic
	   ,DateSinceMostLikely					= cee.DateSinceMostLikely
	   ,DateSinceBlend						= cee.DateSinceBlend
	   ,BlendAmtOriginalCCY					= cee.BlendAmtOriginalCCY
	   ,BeazleyShareMultipler				= cee.BeazleyShareMultipler
	   ,ExposureOriginalCCY                 = cee.ExposureOriginalCCY
FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureEstimate cee 

INNER JOIN ODS.ClaimExposure ce 
ON ce.ExposureReference = cee.ClaimExposureSourceId

WHERE SourceSystem = 'ClaimCenter'

---- Remove deactivated data
--DELETE FROM ODS.ClaimEstimate
--WHERE FK_ClaimExposure NOT IN (SELECT PK_ClaimExposure FROM ODS.ClaimExposure)

--Merge into final table
MERGE ODS.ClaimEstimate target
USING 
#ClaimEstimate source
ON  target.FK_ClaimExposure = source.FK_ClaimExposure
AND target.ReverseSequenceID  = source.ReverseSequenceID

WHEN MATCHED THEN
UPDATE SET
	 target.FK_ClaimExposure              = source.FK_ClaimExposure                                    
	,target.CreateDate                    = source.CreateDate                              
	,target.MostLikelyOriginalCCY         = source.MostLikelyOriginalCCY         
	,target.PessimisticOriginalCCY        = source.PessimisticOriginalCCY        
	,target.ExpectedRecoveriesOriginalCCY = source.ExpectedRecoveriesOriginalCCY 
	,target.BlendWeightingMultiplier      = source.BlendWeightingMultiplier                    
	,target.ReverseSequenceID             = source.ReverseSequenceID
	,target.ExposureStatusCode            = source.ExposureStatusCode    
	,target.DateSincePessimistic          = source.DateSincePessimistic
	,target.DateSinceMostLikely           = source.DateSinceMostLikely
	,target.DateSinceBlend                = source.DateSinceBlend   
	,target.BlendAmtOriginalCCY           = source.BlendAmtOriginalCCY      
	,target.BeazleyShareMultipler         = source.BeazleyShareMultipler    
	,target.ExposureOriginalCCY           = source.ExposureOriginalCCY 
	,target.AuditModifyDateTime	          = GETDATE()						
    ,target.AuditModifyDetails	          = 'Merge in ODS.usp_LoadClaimEstimate proc' 

WHEN NOT MATCHED BY SOURCE THEN DELETE
WHEN NOT MATCHED BY TARGET THEN
INSERT
(	FK_ClaimExposure              
	,CreateDate                   
	,MostLikelyOriginalCCY        
	,PessimisticOriginalCCY       
	,ExpectedRecoveriesOriginalCCY
	,BlendWeightingMultiplier     
	,ReverseSequenceID
	,ExposureStatusCode    
	,DateSincePessimistic
	,DateSinceMostLikely
	,DateSinceBlend   
	,BlendAmtOriginalCCY      
	,BeazleyShareMultipler    
	,ExposureOriginalCCY 
	,AuditCreateDateTime
	,AuditModifyDetails

)
VALUES
	(source.FK_ClaimExposure              
	,source.CreateDate                   
	,source.MostLikelyOriginalCCY        
	,source.PessimisticOriginalCCY       
	,source.ExpectedRecoveriesOriginalCCY
	,source.BlendWeightingMultiplier     
	,source.ReverseSequenceID
	,source.ExposureStatusCode    
	,source.DateSincePessimistic
	,source.DateSinceMostLikely
	,source.DateSinceBlend   
	,source.BlendAmtOriginalCCY      
	,source.BeazleyShareMultipler    
	,source.ExposureOriginalCCY 
	,GETDATE()
	,'New add in ODS.usp_LoadClaimEstimate proc'	
)
;

/*******************************************************************************************/
-- Update FK_ClaimMovement with the closest claim movement related to each claim estimate record
/*******************************************************************************************/
UPDATE claimes 

SET claimes.FK_ClaimMovement = claimmov.PK_ClaimMovement  
   
FROM  ODS.ClaimEstimate claimes 

CROSS APPLY (
             SELECT TOP 1 claimov.PK_ClaimMovement
             FROM ODS.ClaimMovement claimov
             WHERE     claimov.FK_ClaimExposure = claimes.FK_ClaimExposure
                   AND claimov.FK_MovementPeriod <= claimes.FK_CreateDate --Use the keys to pick up everything on the same day, regardless of time
             ORDER BY claimov.MovementPeriod DESC
                     ,claimov.MovementGroupSequenceId DESC 
					 ,claimov.PK_ClaimMovement
             ) claimmov
             
  
/*******************************************************************************************/
--Update CreateDate to replicate the logic from V5 which is not implemented in V9. Below is the code line from V5
--CreateDate                        = DATEADD(hh,1,x.CreateDate)                                       -- Add 1 hour to resolve cases where the financial table rows have been inserted before the changelog rows  in CC
/*******************************************************************************************/
  
UPDATE		claimes 
SET			claimes.CreateDate = DATEADD(hour, 1, CreateDate)
FROM		ODS.ClaimEstimate claimes 

 
/***************************************************************************************************************/
-- Update FK_ClaimMovementEstimate with the closest claim estimate values related to each claim movement record
/***************************************************************************************************************/
UPDATE claimov

SET claimov.FK_ClaimEstimate = claimes.PK_ClaimEstimate
   
FROM   ODS.ClaimMovement claimov

OUTER APPLY (
             SELECT TOP 1 claimes.PK_ClaimEstimate
             FROM ODS.ClaimEstimate claimes
             WHERE     claimes.FK_ClaimExposure = claimov.FK_ClaimExposure
                   AND claimes.FK_CreateDate <= claimov.FK_MovementPeriod --Use the keys to pick up everything on the same day, regardless of time
             ORDER BY claimes.CreateDate DESC                    
             ) claimes;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimEstimate';