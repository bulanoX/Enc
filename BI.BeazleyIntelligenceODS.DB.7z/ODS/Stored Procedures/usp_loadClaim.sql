﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_LoadClaim]
AS
BEGIN

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Claim
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')
--select @LastAuditDate

-- Remove deactivated data
DELETE FROM ODS.Claim WHERE ClaimReference NOT IN (SELECT DISTINCT ClaimReference FROM  BeazleyIntelligenceDataContract.Outbound.vw_Claim )

MERGE ODS.Claim target
USING 
(
SELECT 
	ClaimReference                      = c.ClaimReference
	,OriginatingBureau                  = ''--NULL -- removed from V9 from Claim -- c.OriginatingBureau
	,NotificationDate                   = c.NotificationDate
	,AgreementPartyDetails              = c.AgreementPartyDetails
	,AppianReference					= c.AppianReference
	,ClaimGlobalProgrammeID             = ce.ClaimGlobalProgrammeID
	,ClaimURL                           = ce.ClaimURL
	,ClaimOpenedDate                    = c.ClaimOpenedDate
	,ClaimClosedDate                    = c.ClaimClosedDate
	,ClaimsUnderwritingPlatform         = c.UnderwritingPlatform
	,InHouseClaimIndicator              = 0                  -- removed in V9
	,LossFromDate                       = c.LossFromDate
	,LossToDate                         = c.LossToDate
	,ClaimMadeFromDate                  = c.ClaimMadeFromDate
	,AccidentYear						= CASE WHEN c.ClaimMadeFromDate IS NOT NULL THEN YEAR(c.ClaimMadeFromDate)
                                            WHEN c.ClaimMadeFromDate IS NULL AND c.NotificationDate IS NOT NULL THEN YEAR(c.NotificationDate)
                                            ELSE YEAR(c.ClaimOpenedDate)
                                          END
	,ClaimDescription                   = c.ClaimDescription
	,ClaimNarrative                     = ce.ClaimNarrative
	,SlipPositionCode                   = REPLACE(ce.SlipPositionCode, 'unknown', 'Unknown')
	,SlipPosition                       = ce.SlipPosition
	,HasSCMData                         = ISNULL(ce.HasSCMData, 0)
	,HasRealExposures                   = ISNULL(ce.HasRealExposures ,0) 
	,LimitCCY                           = c.LimitCurrency
	,LimitInLimitCCY                    = c.LimitAmountInLimitCCY
	,EstimatedLossWithinTheRetentionCCY = c.EstimatedLossWithinTheRetentionCCY
	,EstimatedLossWithinTheRetention	= c.EstimatedLossWithinTheRetention
	,DeductibleCCY                      = c.DeductibleCurrency
	,EachClaimDeductibleInDeductibleCCY = c.EachClaimDeductibleInDeductibleCCY
	,InsuranceFund						= c.InsuranceFund
	,AggregateDeductibleInDeductibleCCY = c.AggregateDeductibleInDeductibleCCY
	,SCMReadOnly                        = ce.SCMReadOnly -- removed in V9 
	,ExternalClaimsService              = ce.ExternalClaimsService
	,ClaimCreatedBy						= c.ClaimCreatedBy
	,FK_PrimaryClaimAssociation         = 0  --- updated in sp: [usp_LoadClaimClaimAssociation]
	,FK_AccountingCalendar              = ISNULL(ac.PK_AccountingCalendar, 0)
	,ClaimStatus						= c.ClaimStatus
	,ClaimStatusCode					= CASE 
											WHEN Utility.udf_ProcessString(c.ClaimStatus,0) = 'Closed' THEN 'C'
											WHEN Utility.udf_ProcessString(c.ClaimStatus,0) = 'Open'   THEN 'O'
										 END
	,ClaimReopenedFlag					= ISNULL(c.ClaimReopenedFlag, 0)
	,ClosedOutcome                      = c.ClosedOutcome
	,BeazleyGroupPaper					= c.BeazleyGroupPaper
	,ClaimType							= c.ClaimType
	,LocationOfLossCountry				= c.LocationOfLossCountry
	,LocationOfLossState				= c.LocationOfLossState
	,UCR								= c.UCR	      
	,ConflictOfInterest					= ISNULL(c.ConflictOfInterest, '')        
	,LineOfBusiness                     = c.LineOfBusiness
	,LitigationHold						= c.LitigationHold
	,AnonymizationStatus				= c.AnonymizationStatus
	,HashbytesId						= c.HashbytesId

	FROM BeazleyIntelligenceDataContract.Outbound.vw_Claim c
	
	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_ClaimExtension ce
	ON c.SourceSystem = ce.SourceSystem
	AND c.ClaimSourceId = ce.ClaimSourceId

	LEFT JOIN ODS.AccountingCalendar ac 
	ON ac.AccountingCalendarName = ISNULL(c.AccountingCalendar, 'N/A') 

	WHERE c.SourceSystem = 'ClaimCenter'
	AND ISNULL(c.IncidentReport, 0) = 0
	AND ISNULL(c.IsRetired, 0) = 0
	AND (	(c.AuditCreateDatetime > @LastAuditDate OR c.AuditModifyDatetime > @LastAuditDate)
		OR (ce.AuditCreateDatetime > @LastAuditDate OR ce.AuditModifyDatetime > @LastAuditDate))
	--AND c.IsActive = 1

) source
ON  target.ClaimReference = source.ClaimReference
AND target.OriginatingBureau  = source.OriginatingBureau

WHEN MATCHED THEN
UPDATE SET
 target.NotificationDate                   = source.NotificationDate                  
,target.AgreementPartyDetails              = source.AgreementPartyDetails   
,target.AppianReference					   = source.AppianReference
,target.ClaimGlobalProgrammeID             = source.ClaimGlobalProgrammeID
,target.ClaimURL                           = source.ClaimURL                          
,target.ClaimOpenedDate                    = source.ClaimOpenedDate                   
,target.ClaimClosedDate                    = source.ClaimClosedDate      
,target.ClaimsUnderwritingPlatform         = source.ClaimsUnderwritingPlatform
,target.InHouseClaimIndicator              = source.InHouseClaimIndicator             
,target.LossFromDate                       = source.LossFromDate                      
,target.LossToDate                         = source.LossToDate                        
,target.ClaimMadeFromDate                  = source.ClaimMadeFromDate   
,target.AccidentYear					   = source.AccidentYear
,target.ClaimDescription                   = source.ClaimDescription                  
,target.ClaimNarrative                     = source.ClaimNarrative                    
,target.SlipPositionCode                   = source.SlipPositionCode                  
,target.SlipPosition                       = source.SlipPosition                      
,target.HasSCMData                         = source.HasSCMData                        
,target.HasRealExposures                   = source.HasRealExposures                  
,target.LimitCCY                           = source.LimitCCY                          
,target.LimitInLimitCCY                    = source.LimitInLimitCCY    
,target.EstimatedLossWithinTheRetentionCCY = source.EstimatedLossWithinTheRetentionCCY
,target.EstimatedLossWithinTheRetention	   = source.EstimatedLossWithinTheRetention
,target.DeductibleCCY                      = source.DeductibleCCY                     
,target.EachClaimDeductibleInDeductibleCCY = source.EachClaimDeductibleInDeductibleCCY
,target.InsuranceFund                      = source.InsuranceFund
,target.AggregateDeductibleInDeductibleCCY = source.AggregateDeductibleInDeductibleCCY
,target.SCMReadOnly                        = source.SCMReadOnly                       
,target.ExternalClaimsService              = source.ExternalClaimsService             
,target.ClaimCreatedBy			           = source.ClaimCreatedBy						
,target.FK_PrimaryClaimAssociation         = source.FK_PrimaryClaimAssociation        
,target.FK_AccountingCalendar              = source.FK_AccountingCalendar             
,target.ClaimStatus			               = source.ClaimStatus						
,target.ClaimStatusCode			           = source.ClaimStatusCode					
,target.ClaimReopenedFlag		           = source.ClaimReopenedFlag					
,target.ClosedOutcome                      = source.ClosedOutcome  
,target.BeazleyGroupPaper                  = source.BeazleyGroupPaper
,target.ClaimType                          = source.ClaimType
,target.LocationOfLossCountry              = source.LocationOfLossCountry
,target.LocationOfLossState                = source.LocationOfLossState
,target.UCR                                = source.UCR       
,target.ConflictOfInterest                 = source.ConflictOfInterest      
,target.LineOfBusiness                     = source.LineOfBusiness
,target.LitigationHold					   = source.LitigationHold
,target.AnonymizationStatus				   = source.AnonymizationStatus
,target.HashbytesId                        = source.HashbytesId  
,target.AuditModifyDateTime	               = GETDATE()						
,target.AuditModifyDetails	               = 'Merge in ODS.usp_LoadClaim proc'

WHEN NOT MATCHED BY TARGET THEN
INSERT
(    ClaimReference                     
	,OriginatingBureau                 
	,NotificationDate                  
	,AgreementPartyDetails             
	,AppianReference
	,ClaimGlobalProgrammeID
	,ClaimURL                          
	,ClaimOpenedDate                   
	,ClaimClosedDate      
	,ClaimsUnderwritingPlatform
	,InHouseClaimIndicator             
	,LossFromDate                      
	,LossToDate                        
	,ClaimMadeFromDate 
	,AccidentYear
	,ClaimDescription                  
	,ClaimNarrative                    
	,SlipPositionCode                  
	,SlipPosition                      
	,HasSCMData                        
	,HasRealExposures                  
	,LimitCCY                          
	,LimitInLimitCCY   
	,EstimatedLossWithinTheRetentionCCY
	,EstimatedLossWithinTheRetention
	,DeductibleCCY                     
	,EachClaimDeductibleInDeductibleCCY
	,InsuranceFund
	,AggregateDeductibleInDeductibleCCY
	,SCMReadOnly                       
	,ExternalClaimsService             
	,ClaimCreatedBy						
	,FK_PrimaryClaimAssociation        
	,FK_AccountingCalendar             
	,ClaimStatus						
	,ClaimStatusCode					
	,ClaimReopenedFlag					
	,ClosedOutcome  
	,BeazleyGroupPaper
	,ClaimType
	,LocationOfLossCountry
	,LocationOfLossState
	,UCR       
	,ConflictOfInterest      
	,LineOfBusiness
	,LitigationHold
	,AnonymizationStatus
	,HashbytesId      
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
     source.ClaimReference                     
	,source.OriginatingBureau                 
	,source.NotificationDate                  
	,source.AgreementPartyDetails   
	,source.AppianReference
	,source.ClaimGlobalProgrammeID
	,source.ClaimURL                          
	,source.ClaimOpenedDate                   
	,source.ClaimClosedDate      
	,source.ClaimsUnderwritingPlatform
	,source.InHouseClaimIndicator             
	,source.LossFromDate                      
	,source.LossToDate                        
	,source.ClaimMadeFromDate 
	,source.AccidentYear
	,source.ClaimDescription                  
	,source.ClaimNarrative                    
	,source.SlipPositionCode                  
	,source.SlipPosition                      
	,source.HasSCMData                        
	,source.HasRealExposures                  
	,source.LimitCCY                          
	,source.LimitInLimitCCY    
	,source.EstimatedLossWithinTheRetentionCCY
	,source.EstimatedLossWithinTheRetention
	,source.DeductibleCCY                     
	,source.EachClaimDeductibleInDeductibleCCY
	,source.InsuranceFund
	,source.AggregateDeductibleInDeductibleCCY
	,source.SCMReadOnly                       
	,source.ExternalClaimsService             
	,source.ClaimCreatedBy						
	,source.FK_PrimaryClaimAssociation        
	,source.FK_AccountingCalendar             
	,source.ClaimStatus						
	,source.ClaimStatusCode					
	,source.ClaimReopenedFlag					
	,source.ClosedOutcome  
	,source.BeazleyGroupPaper
	,source.ClaimType
	,source.LocationOfLossCountry
	,source.LocationOfLossState
	,source.UCR       
	,source.ConflictOfInterest 
	,source.LineOfBusiness
	,source.LitigationHold
	,source.AnonymizationStatus
	,source.HashbytesId      
	,GETDATE()
	,'New add in ODS.usp_LoadClaim proc'
)
;

    EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Claim';

END
GO

