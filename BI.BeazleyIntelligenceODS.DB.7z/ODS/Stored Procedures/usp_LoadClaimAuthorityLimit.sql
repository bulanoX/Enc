﻿CREATE PROCEDURE [ODS].[usp_LoadClaimAuthorityLimit]
AS

SET NOCOUNT ON

;MERGE ODS.ClaimAuthorityLimit  AS Target
USING (
	  
		 SELECT 
		 IsUnknownMember				= 0
		,ClaimCenterUserId              = cal.UserSourceId
		,ClaimCenterUser                = MAX(Utility.udf_ProcessString(cal.[UserName],1))
		,AuthorityType					= AuthorityType
		,CoverageType
		,AuthorityLimitUSD              = CASE WHEN ISNULL(MIN(cal.[AuthorityLimitInOriginalCurrency]), 0) <= 0.01 THEN 0 ELSE ISNULL(MIN(cal.[AuthorityLimitInOriginalCurrency]), 0) END
		,AuthorityLimitForApprovalsUSD  = COALESCE(Utility.udf_ProcessPercentage(MIN(0),1,0,1),1) 
										  *
										  CASE WHEN ISNULL(MIN(cal.[AuthorityLimitInOriginalCurrency]), 0) <= 0.01 THEN 0 ELSE ISNULL(MIN(cal.[AuthorityLimitInOriginalCurrency]), 0) END  

		FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimAuthorityLimit cal

		WHERE cal.SourceSystem = 'ClaimCenter'

		GROUP BY  cal.UserSourceId
				 ,AuthorityType
				 ,CoverageType
	

		UNION

		SELECT
			 IsUnknownMember                 = 1 
			,ClaimCenterUserId              = -1
			,ClaimCenterUser                = 'N/A' 
			,AuthorityType			        = 'N/A'
			,CoverageType					= 'N/A'
			,AuthorityLimitUSD              = 0
			,AuthorityLimitForApprovalsUSD  = 0 
			
		) as Source 
	ON (
		ISNULL(Source.ClaimCenterUserId, 0) = ISNULL(Target.ClaimCenterUserId, 0)
	AND ISNULL(Source.AuthorityType, 'Not Available') = ISNULL(Target.AuthorityType, 'Not Available')
	AND ISNULL(Source.CoverageType, 'Not Available') = ISNULL(Target.CoverageType, 'Not Available')	
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
	)
WHEN MATCHED THEN UPDATE
	SET Target.[ClaimCenterUser]				= Source.[ClaimCenterUser],
		Target.[AuthorityLimitUSD]				= Source.[AuthorityLimitUSD] ,
		Target.[AuthorityLimitForApprovalsUSD]	= Source.[AuthorityLimitForApprovalsUSD],
		Target.[AuditModifyDateTime]	        = GETDATE(),						
        Target.[AuditModifyDetails]	            = 'Merge in ODS.usp_LoadClaimAuthorityLimit proc'
WHEN NOT MATCHED BY TARGET THEN 
		INSERT([IsUnknownMember], [ClaimCenterUserId], [ClaimCenterUser],[AuthorityType], [CoverageType],[AuthorityLimitUSD],[AuthorityLimitForApprovalsUSD], [AuditCreateDateTime], [AuditModifyDetails])
		VALUES(Source.[IsUnknownMember], Source.[ClaimCenterUserId], Source.[ClaimCenterUser], Source.[AuthorityType], Source.[CoverageType], Source.[AuthorityLimitUSD],Source.[AuthorityLimitForApprovalsUSD], GETDATE(), 'New add in ODS.usp_LoadClaimAuthorityLimit proc')
WHEN NOT MATCHED BY SOURCE THEN DELETE;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimAuthorityLimit';