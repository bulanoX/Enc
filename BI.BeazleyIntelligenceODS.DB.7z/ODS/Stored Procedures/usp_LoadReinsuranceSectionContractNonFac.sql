﻿
CREATE PROCEDURE [ODS].[usp_LoadReinsuranceSectionContractNonFac]
AS
--Declarations
SET NOCOUNT ON

--Clear existing data
TRUNCATE TABLE ODS.ReinsuranceSectionContractNonFac;

--Non-Fac Policies **********************************************************************
INSERT INTO ODS.ReinsuranceSectionContractNonFac
    (
     FK_Section
    ,FK_ReinsuranceContract
    ,SequenceNumber
    ,CededPercentage
    ,Proportion
    )
SELECT DISTINCT
--Keys
 FK_Section			  	= sec.PK_Section
,FK_ReinsuranceContract	= ric.PK_ReinsuranceContract
--Data
,SequenceNumber			= prl.SequenceNumber	
,CededPercentage		= Utility.udf_ProcessPercentage(ISNULL(prl.CededPercentage	,0) ,1,0,0)
,Proportion				= Utility.udf_ProcessPercentage(ISNULL(prl.Proportion	,0) ,1,0,0)
FROM 
[Staging_MDS].[dbo].[vw_policy_reinsurance_link] prl
INNER JOIN
ODS.Section sec ON
prl.SectionReference = sec.SectionReference
INNER JOIN
ODS.ReinsuranceContractNonFac ric ON
prl.SectionReferenceReinsurance = ric.ContractReference;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceSectionContractNonFac';