﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_LoadClaimMovementLine]   
AS
BEGIN

	DROP TABLE IF EXISTS #ClaimMovementLine

	SELECT FK_ClaimMovement        = cm.PK_ClaimMovement     
		   ,FK_Section              = ISNULL(s.PK_Section, 0)                           
		   ,FK_Syndicate            = ss.PK_Syndicate                     
		   ,FK_SlipLineNumber       = cml.SlipLineNumber                                   
		   ,LineMultiplier			= COALESCE(Utility.udf_ProcessPercentage(cml.LineMultiplier, 1, 0, 1), 0) -- cml.LineMultiplier 
		   ,cml.SectionSourceId
		   ,cml.SyndicateNumber
	INTO #ClaimMovementLine
	FROM 
		(
			SELECT
				* 
			FROM BeazleyIntelligenceDataContract.outbound.vw_ClaimMovementLine 
			WHERE SourceSystem = 'ClaimCenter'
		) cml
	LEFT JOIN 
		(
			SELECT
				HashbytesId
				,ClaimSourceId
				,ClaimExposureSourceId
				,MovementReferenceSourceId
				,SequenceNumber
			FROM BeazleyIntelligenceDataContract.outbound.vw_ClaimExposureMovement
			WHERE SourceSystem = 'ClaimCenter'
		) cem
	LEFT JOIN
		(
			SELECT
				PK_ClaimMovement,
				HashbytesId
  			FROM ODS.ClaimMovement
		) cm on cm.HashbytesId = cem.HashbytesId
	ON      cml.ClaimExposureSourceId = cem.ClaimExposureSourceId
		and cml.MovementReferenceSourceId = cem.MovementReferenceSourceId
		and cml.SequenceNumber = cem.SequenceNumber

	LEFT JOIn ODS.Section s 
	on s.sectionreference = cml.sectionsourceid
	LEFT JOIN ODS.syndicate ss 
	on cast(ss.syndicatenumber as nvarchar(255)) = cml.syndicatenumber
	
	---- consume data from ClaimMovementLine - pushed by ClaimCenter
	--INSERT INTO ODS.ClaimMovementLine
	--([FK_ClaimMovement], [FK_Section], [FK_Syndicate], [FK_SlipLineNumber], [LineMultiplier])
	--SELECT DISTINCT
	--	[FK_ClaimMovement], [FK_Section], [FK_Syndicate], [FK_SlipLineNumber] , ([LineMultiplier])   
	--FROM #ClaimMovementline
	--Where [FK_ClaimMovement] IS NOT NULL

-- use data from legacy table if was not pushed and used in previous step
	INSERT INTO #ClaimMovementline
	([FK_ClaimMovement], [FK_Section], [FK_Syndicate], [FK_SlipLineNumber], [LineMultiplier])
	SELECT DISTINCT
					[FK_ClaimMovement], 
					[FK_Section], 
					[FK_Syndicate], 
					/*[FK_SlipLineNumber] =*/ 0, 
					SUM([LineMultiplier])   
	FROM Utility.ClaimMovementline_Legacy l
		INNER JOIN ODS.CLaimMovement cm on cm.PK_ClaimMovement = l.FK_ClaimMovement
		INNER JOIN ODS.Section s on l.Fk_Section = s.pk_Section
	WHERE l.[FK_ClaimMovement] NOT IN
		(
			SELECT 
				[FK_ClaimMovement]
			FROM #ClaimMovementLine
			GROUP BY [FK_ClaimMovement]
		)
	GROUP BY [FK_ClaimMovement], [FK_Section], [FK_Syndicate]

	INSERT INTO #ClaimMovementline
	([FK_ClaimMovement], [FK_Section], [FK_Syndicate], [FK_SlipLineNumber], [LineMultiplier] , [SectionSourceId], [SyndicateNumber])
	SELECT
		FK_ClaimMovement        = cm.PK_ClaimMovement     
	   ,FK_Section              = ces.FK_Section                           
	   ,FK_Syndicate            = sl.FK_Syndicate                     
	   ,FK_SlipLineNumber       = 0        
	   ,LineMultiplier        = cast(CASE   WHEN cm.movementtype = 'SCM' and ISNULL(cm.BeazleyShare, 0) <> 0 THEN CAST(cm.BeazleyShare AS DECIMAL(19,6)) / 100 * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)
											WHEN cm.movementtype = 'SCM' and ISNULL(cm.BeazleyShare, 0) = 0 AND ISNULL(ce.Signed, 0) <> 0 then CAST(ce.Signed AS DECIMAL(19,6)) / 100 * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)
											WHEN cm.movementtype = 'SCM' AND ISNULL(sl.WrittenIfNotSignedLineMultiplier, 0) <> 0 THEN sl.WrittenIfNotSignedLineMultiplier

											WHEN cm.movementtype <> 'SCM' AND c.claimType IN ('Embedded Claim') THEN  isnull(cast(case when ce.ordernumber = 0 then 100 
											                                                                                           else ce.OrderNumber end / 100 as numeric(19,12)), ce.WrittenIfNotSignedOrderMultiplier) * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)
												
											WHEN c.claimType IN ('Special Processing Claim') AND ISNULL(cm.BeazleyShare, 0) <> 0  THEN CAST(cm.BeazleyShare AS DECIMAL(19,6)) / 100 * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)
											WHEN c.claimType IN ('Special Processing Claim') and ISNULL(cm.BeazleyShare, 0) = 0 AND ISNULL(ce.Signed, 0) <> 0 THEN CAST(ce.Signed AS DECIMAL(19,6)) / 100 * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)
											WHEN c.claimType IN ('Special Processing Claim') AND ISNULL(sl.WrittenIfNotSignedLineMultiplier, 0) <> 0 THEN sl.WrittenIfNotSignedLineMultiplier
											WHEN cm.movementtype <> 'SCM' AND ce.ECFEntryWithoutSCM =1 THEN ISNULL(CAST(cm.BeazleyShare AS DECIMAL(19,6)) / 100 * (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier),	(sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier))												
											WHEN cm.movementtype <> 'SCM' AND ce.ECFEntryWithoutSCM =0 THEN (sl.WrittenIfNotSignedLineMultiplier / s.WrittenIfNotSignedLineMultiplier)  /* ISNULL(sy.SyndicateMultiplier, 1)*/

							          ELSE 1
								END as NUMERIC(19,12))
								* 1/ G.SectionNo
		,SectionSourceId = 0
		,SyndicateNumber = 0
	FROM ODS.ClaimMovement cm
		INNER JOIN	ODS.ClaimExposureSection ces ON	cm.FK_ClaimExposure = ces.FK_ClaimExposure
		INNER JOIN
					(
						SELECT
							FK_ClaimExposure ,
							SectionNo = COUNT(*)
						FROM ODS.ClaimExposureSection
						GROUP BY FK_ClaimExposure
					) AS G 
					ON g.FK_ClaimExposure = cm.FK_ClaimExposure
		INNER JOIN ODS.ClaimExposure ce ON ce.PK_ClaimExposure = cm.FK_ClaimExposure
        INNER JOIN ODS.Claim c ON ce.FK_claim = c.PK_Claim
		INNER JOIN ODS.SectionLine sl ON	ces.FK_Section = sl.FK_Section 
		INNER JOIN ODS.Section s ON s.PK_Section = sl.FK_Section
   WHERE cm.PK_ClaimMovement NOT IN
		(
			SELECT 
				[FK_ClaimMovement]
			FROM #ClaimMovementline
			WHERE FK_ClaimMovement IS NOT NULL
			GROUP BY [FK_ClaimMovement]
		)


DELETE FROM #ClaimMovementline WHERE FK_ClaimMovement is null


MERGE ODS.ClaimMovementline target
USING 
#ClaimMovementline source
ON  target.[FK_ClaimMovement]  = source.[FK_ClaimMovement]
AND target.[FK_Section]        = source.[FK_Section]
AND target.[FK_Syndicate]      = source.[FK_Syndicate]
AND target.[FK_SlipLineNumber] = source.[FK_SlipLineNumber]

WHEN MATCHED THEN
UPDATE SET
target.[LineMultiplier]         = source.[LineMultiplier]
,target.AuditModifyDateTime	    = GETDATE()						
,target.AuditModifyDetails	    = 'Merge in ODS.usp_LoadClaimMovementLine' 

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN
INSERT
(  FK_ClaimMovement 
  ,FK_Section    
  ,FK_Syndicate     
  ,FK_SlipLineNumber
  ,LineMultiplier
  ,AuditCreateDateTime
  ,AuditModifyDetails
)
VALUES
( 
   source.[FK_ClaimMovement] 
  ,source.[FK_Section]       
  ,source.[FK_Syndicate]     
  ,source.[FK_SlipLineNumber]
  ,source.LineMultiplier
  ,GETDATE()
  ,'New add in ODS.usp_LoadClaimMovementLine'	
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimMovementline';


END
GO


