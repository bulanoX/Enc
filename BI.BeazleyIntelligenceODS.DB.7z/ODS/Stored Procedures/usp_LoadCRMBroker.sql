 CREATE PROCEDURE [ODS].[usp_LoadCRMBroker]
 
 AS
 
 SET NOCOUNT ON
 
 IF (OBJECT_ID('tempdb..#CRMBroker') IS NOT NULL)
 DROP TABLE #CRMBroker
 
 CREATE TABLE #CRMBroker
 (
     PK_CRMBroker            bigint                  NOT NULL
     ,CRMBrokerId            uniqueidentifier        NOT NULL
     ,AccountNumber          varchar(255)            NULL
     ,BrokerName             varchar(255)            NULL
     ,BrokerCountry          varchar(255)            NULL
     ,BrokerCity             varchar(255)            NULL
     ,StateOrProvince        varchar(255)            NULL
     ,CRMBrokerLinkId        nvarchar(255)           NULL
     ,FK_CRMBrokerParent     bigint                  NULL
     ,HierarchyLevel         int                     NULL
     ,RecordUsed				bit                     NOT NULL
     ,PRIMARY KEY (PK_CRMBroker)
 )
 
 IF (OBJECT_ID('tempdb..#Include') IS NOT NULL)
 DROP TABLE #Include
 
 CREATE TABLE #Include
 (
     PK_CRMBroker            bigint                  NOT NULL
     ,PRIMARY KEY (PK_CRMBroker)
 )
  
 TRUNCATE TABLE #CRMBroker
 INSERT INTO #CRMBroker
 (
     PK_CRMBroker
     ,CRMBrokerId
     ,AccountNumber
     ,BrokerName
     ,BrokerCountry
     ,BrokerCity
     ,StateOrProvince
     ,CRMBrokerLinkId
     ,FK_CRMBrokerParent
     ,RecordUsed
 )
 
 SELECT DISTINCT
 PK_CRMBroker                = CONVERT(BIGINT,HASHBYTES('SHA2_256',CAST(a.AccountId AS varchar(255))))
 ,CRMBrokerId                = a.AccountId
 ,AccountNumber              = a.AccountNumber
 ,BrokerName                 = CAST(a.BrokerName AS varchar(255))  --CAST(a.Name AS varchar(255)) --
 ,BrokerCountry              = a.CountryName  --a.beazley_countryidName --
 ,BrokerCity                 = a.Address1_City
 ,StateOrProvince            = a.Address1_StateOrProvince
 ,CRMBrokerLinkId            = a.Beazley_BrokerTradeId
 ,FK_CRMBrokerParent         = CASE
                                 WHEN a.ParentAccountId IS NULL THEN NULL
                                 ELSE CONVERT(BIGINT,HASHBYTES('SHA2_256',(CAST(a.ParentAccountId AS varchar(255)))))
                               END
 ,RecordUsed					= CASE
                                 WHEN x.BranchBeazleyTradeId IS NOT NULL OR cips.CRMBrokerName IS NOT NULL THEN 1
                                 ELSE 0
                               END
 
 FROM
 --Staging_CRM.CRM_Staging.Account a 
 BeazleyIntelligenceDataContract.Outbound.vw_Account a --BI-7953
 LEFT OUTER JOIN
 (	   
 	--Non-strategic source system data to BeazleyPro data
 	SELECT DISTINCT
 	 BranchBeazleyTradeId	= CAST(mdc.BrokerBeazleyTradeId AS VARCHAR(255))
 	FROM 
 	Staging_DataContract.DataContract_Staging.Policy mdc
 	WHERE 
 	mdc.BrokerBeazleyTradeId IS NOT NULL
 	AND mdc.SourceSystemName NOT IN ( 'FDR','USHVH' ) 
 
     UNION 
 
     SELECT DISTINCT
 	 BranchBeazleyTradeId	= uni.CRMBrokerName
 	FROM 
 	BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension uni
 	WHERE 
 	uni.CRMBrokerName IS NOT NULL
 	AND uni.SourceSystem IN ('Unirisx')
 
 	UNION 
 
     SELECT DISTINCT
 	 BranchBeazleyTradeId	= uni.BrokerBeazleyTradeId
 	FROM 
 	BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension uni
 	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section s on uni.PolicyReference = s.PolicyReference
 	WHERE 
 	uni.BrokerBeazleyTradeId IS NOT NULL
 	AND uni.SourceSystem IN ('Gamechanger', 'FDR', 'myBeazley', 'USHVH', 'BeazleyPro')
 	AND CASE WHEN uni.SourceSystem = 'myBeazley' AND s.ProductName = 'Canada' THEN 'Exclude myBeazley' ELSE  s.ProductName END =  s.ProductName
 
 	UNION 
 
     SELECT DISTINCT
 	 PlacingBranchTradeId	= uni.PlacingBranchTradeId
 	FROM 
 	BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension uni
 	WHERE 
 	uni.PlacingBranchTradeId IS NOT NULL
 	AND uni.SourceSystem = 'BeazleyPro'
 
 	UNION 
 
     SELECT DISTINCT
 	 ProducingBranchTradeId	= uni.ProducingBranchTradeId
 	FROM 
 	BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension uni
 	WHERE 
 	uni.ProducingBranchTradeId IS NOT NULL
 	AND uni.SourceSystem = 'BeazleyPro'
 
 ) x ON
  a.Beazley_BrokerTradeId = x.BranchBeazleyTradeId
  
 LEFT OUTER JOIN 
 (
 	SELECT DISTINCT
 		CRMBrokerName	= pe.CRMBrokerName
 	FROM 
 	BeazleyIntelligenceDataContract.Outbound.vw_PolicyExtension pe
 	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section s on pe.PolicyReference = s.PolicyReference
 	WHERE 
 	pe.CRMBrokerName IS NOT NULL
 	and len(CRMBrokerName) = 36
 	AND pe.SourceSystem IN ('CIPS', 'myBeazley')
 	AND CASE WHEN pe.SourceSystem = 'myBeazley' then 'Canada' else  s.ProductName end =  s.ProductName
 ) cips
  on a.AccountId = cips.CRMBrokerName
  
 ;WITH CTECRMBroker AS
 (
     --Work from the leaves up - if a leaf is included, all ancestors also need to be included
     SELECT
     PK_CRMBroker                = b.PK_CRMBroker
     ,FK_CRMBrokerParent         = b.FK_CRMBrokerParent
     ,IncludeFlag                = b.RecordUsed
     FROM
     #CRMBroker b
     WHERE
     NOT EXISTS
     (
         SELECT
         1
         FROM
         #CRMBroker child
         WHERE
         child.FK_CRMBrokerParent = b.PK_CRMBroker
     )
     UNION ALL
     SELECT
     PK_CRMBroker                = parent.PK_CRMBroker
     ,FK_CRMBrokerParent         = parent.FK_CRMBrokerParent
     ,IncludeFlag                = CAST(CASE
                                     WHEN cte.IncludeFlag = 1 THEN 1
                                     WHEN parent.RecordUsed = 1 THEN 1
                                     ELSE 0
                                   END AS bit)
     FROM
     CTECRMBroker cte
     INNER JOIN
     #CRMBroker parent ON
     cte.FK_CRMBrokerParent = parent.PK_CRMBroker
 )
 INSERT INTO #Include
 (
     PK_CRMBroker
 )
 SELECT DISTINCT
 PK_CRMBroker        = cte.PK_CRMBroker
 FROM
 CTECRMBroker cte
 WHERE
 cte.IncludeFlag = 1
 OPTION (MAXRECURSION 0)
 
 /*Set hierarchy level - root is always 1*/
 ;WITH CTECRMBroker AS
 (
     SELECT
     PK_CRMBroker                    = b.PK_CRMBroker
     ,FK_CRMBrokerParent             = b.FK_CRMBrokerParent
     ,HierarchyLevel                 = 1
     FROM
     #Include i
     INNER JOIN
     #CRMBroker b ON
     i.PK_CRMBroker = b.PK_CRMBroker
     WHERE
     b.FK_CRMBrokerParent IS NULL
     UNION ALL
     SELECT
     PK_CRMBroker                    = b.PK_CRMBroker
     ,FK_CRMBrokerParent             = b.FK_CRMBrokerParent
     ,HierarchyLevel                 = cte.HierarchyLevel + 1
     FROM
     #Include i
     INNER JOIN
     #CRMBroker b ON
     i.PK_CRMBroker = b.PK_CRMBroker
     INNER JOIN
     CTECRMBroker cte ON 
     b.FK_CRMBrokerParent = cte.PK_CRMBroker
 )
 UPDATE b SET
 HierarchyLevel          = cte.HierarchyLevel
 FROM
 #CRMBroker b
 INNER JOIN
 CTECRMBroker cte ON
 b.PK_CRMBroker = cte.PK_CRMBroker
 
 --/*BI-7953*/
 ----DELETE FROM ODS.CRMBroker WHERE CRMBrokerId NOT IN (SELECT AccountId FROM Staging_CRM.CRM_Staging.Account) AND PK_CRMBroker <> 0
 --DELETE FROM ODS.CRMBroker WHERE CRMBrokerId NOT IN (SELECT AccountId FROM BeazleyIntelligenceDataContract.Outbound.vw_Account) AND PK_CRMBroker <> 0
 --/*BI-7953*/
 
 
 
 MERGE ODS.CRMBroker AS TARGET
 USING (
 
 	SELECT
 	 s.PK_CRMBroker 
 	,s.IsUnknownMember
 	,s.CRMBrokerId
 	,s.AccountNumber
 	,s.BrokerName
 	,s.BrokerCountry
 	,s.BrokerCity
 	,s.StateOrProvince
 	,s.CRMBrokerLinkId
 	,s.HierarchyLevel
 	,s.FK_CRMBrokerParent
 	
 	FROM (
 		SELECT
 			PK_CRMBroker            = b.PK_CRMBroker
 			,IsUnknownMember        = 0 
 			,CRMBrokerId            = b.CRMBrokerId
 			,AccountNumber          = b.AccountNumber
 			,BrokerName             = b.BrokerName
 			,BrokerCountry          = b.BrokerCountry
 			,BrokerCity             = b.BrokerCity
 			,StateOrProvince        = b.StateOrProvince
 			,CRMBrokerLinkId        = b.CRMBrokerLinkId
 			,HierarchyLevel         = b.HierarchyLevel
 			,FK_CRMBrokerParent     = b.FK_CRMBrokerParent
 			FROM 	#CRMBroker b
 					INNER JOIN
 					#Include i ON
 					b.PK_CRMBroker = i.PK_CRMBroker
 
 			UNION
 
 			SELECT 
 			PK_CRMBroker            = 0
 			,IsUnknownMember        = 1
 			,CRMBrokerId            = '00000000-0000-0000-0000-000000000000'
 			,AccountNumber          = 'N/A'
 			,BrokerName             = 'N/A'
 			,BrokerCountry          = 'N/A'
 			,BrokerCity             = 'N/A'
 			,StateOrProvince        = 'N/A'
 			,CRMBrokerLinkId        = null
 			,HierarchyLevel         = 0
 			,FK_CRMBrokerParent     = null
 
 			) AS s
 			--LEFT JOIN ODS.CRMBroker cb ON s.PK_CRMBroker = cb.PK_CRMBroker
 			--WHERE  cb.PK_CRMBroker is null
 			--       OR (	 
 			--			   cb.PK_CRMBroker      <> s.PK_CRMBroker    
 			--			OR cb.IsUnknownMember   <> s.IsUnknownMember 
 			--			OR cb.CRMBrokerId       <> s.CRMBrokerId     
 			--			OR cb.AccountNumber     <> s.AccountNumber   
 			--			OR cb.BrokerName        <> s.BrokerName      
 			--			OR cb.BrokerCountry     <> s.BrokerCountry   
 			--			OR cb.BrokerCity        <> s.BrokerCity      
 			--			OR cb.StateOrProvince   <> s.StateOrProvince 
 			--			OR cb.CRMBrokerLinkId   <> s.CRMBrokerLinkId 
 			--			OR cb.HierarchyLevel    <> s.HierarchyLevel  
 
 			--			)
  		) 
 				
 		AS SOURCE
 		(
 		PK_CRMBroker 
 	,IsUnknownMember
 	,CRMBrokerId
 	,AccountNumber
 	,BrokerName
 	,BrokerCountry
 	,BrokerCity
 	,StateOrProvince
 	,CRMBrokerLinkId
 	,HierarchyLevel
 	,FK_CRMBrokerParent
 		)
 
 ON  TARGET.PK_CRMBroker       = SOURCE.PK_CRMBroker
 
 WHEN MATCHED THEN
 
 UPDATE SET 
  TARGET.IsUnknownMember     = SOURCE.IsUnknownMember
 ,TARGET.CRMBrokerId         = SOURCE.CRMBrokerId
 ,TARGET.AccountNumber       = SOURCE.AccountNumber
 ,TARGET.BrokerName          = SOURCE.BrokerName
 ,TARGET.BrokerCountry       = SOURCE.BrokerCountry
 ,TARGET.BrokerCity          = SOURCE.BrokerCity
 ,TARGET.StateOrProvince     = SOURCE.StateOrProvince
 ,TARGET.CRMBrokerLinkId     = SOURCE.CRMBrokerLinkId
 ,TARGET.HierarchyLevel      = SOURCE.HierarchyLevel
 ,TARGET.FK_CRMBrokerParent  = SOURCE.FK_CRMBrokerParent
 ,TARGET.AuditModifyDateTime	= GETDATE()						
 ,TARGET.AuditModifyDetails	= 'Merge in [ODS].[CRMBroker] table' 
 
 WHEN NOT MATCHED BY TARGET THEN 
 
 INSERT
 (
 	 PK_CRMBroker
     ,IsUnknownMember
 	,CRMBrokerId
     ,AccountNumber
     ,BrokerName
     ,BrokerCountry
     ,BrokerCity
     ,StateOrProvince
     ,CRMBrokerLinkId
     ,HierarchyLevel
     ,FK_CRMBrokerParent
 	,AuditModifyDetails
 )
 VALUES(
  SOURCE.PK_CRMBroker
 ,SOURCE.IsUnknownMember
 ,SOURCE.CRMBrokerId            
 ,SOURCE.AccountNumber          
 ,SOURCE.BrokerName             
 ,SOURCE.BrokerCountry          
 ,SOURCE.BrokerCity             
 ,SOURCE.StateOrProvince        
 ,SOURCE.CRMBrokerLinkId        
 ,SOURCE.HierarchyLevel         
 ,SOURCE.FK_CRMBrokerParent
 ,'New in [ODS].[CRMBroker] table' 
 )
 WHEN NOT MATCHED BY SOURCE THEN DELETE
 ;
 		  
 IF (OBJECT_ID('tempdb..#CRMBroker') IS NOT NULL)
 DROP TABLE #CRMBroker
 
 IF (OBJECT_ID('tempdb..#Include') IS NOT NULL)
 DROP TABLE #Include;
 
 EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'CRMBroker';
 