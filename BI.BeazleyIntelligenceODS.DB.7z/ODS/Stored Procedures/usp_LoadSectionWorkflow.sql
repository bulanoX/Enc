﻿CREATE PROCEDURE 
[ODS].[usp_LoadSectionWorkflow]
AS BEGIN

	SET NOCOUNT ON

	DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM		ODS.SectionWorkflow

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

	--print		CASE WHEN OBJECT_NAME(@@PROCID) IS NULL THEN 'Custom script' ELSE CONCAT(OBJECT_SCHEMA_NAME(@@PROCID), '.' ,OBJECT_NAME(@@PROCID)) END + ':'
	--print		concat('@LastAuditDate = ', @LastAuditDate)
	--select	@LastAuditDate

	DROP TABLE IF EXISTS #SectionWorkflow

	CREATE TABLE #SectionWorkflow				(
				WorkflowCycleSequenceId			int             NULL
				,WorkflowSequenceID				int             NOT NULL
				,ReverseWorkflowSequenceId		int             NOT NULL
				/*A primitive way of getting values without seconds is to use smalldatetime and 
				truncate the values to the nearest minute. If smarter rounding is required, we can write a 
				function to do this instead*/
				,StatusFromDate					smalldatetime	NOT NULL
				,StatusToDate					smalldatetime   NULL
				,WorkflowStatusCode				varchar(255)    NOT NULL
				,BusinessHoursElapsed			numeric(19,12)  NULL
				,NonBusinessHoursElapsed		numeric(19,12)  NULL
				,TotalHoursElapsed				numeric(19,12)  NULL
				,WorkflowReasonCode				varchar(255)    NULL
				,WorkflowReason					varchar(255)    NULL
				,FK_Section						bigint          NOT NULL
				,FK_StatusChangeUnderwriter		bigint          NOT NULL
				,FK_WorkflowStatus				bigint          NOT NULL
				,PRIMARY KEY (FK_Section, WorkflowSequenceId)
	)


	DROP TABLE IF EXISTS #SectionWorkflowCycle

	CREATE TABLE #SectionWorkflowCycle			(   
				CycleSequenceId                 int             NOT NULL
				,CycleFromDate                  datetime        NOT NULL
				,CycleToDate                    datetime        NULL
				,WorkflowStartSequenceId        int             NOT NULL
				,WorkflowEndSequenceId          int             NULL
				,BusinessHoursElapsed           numeric(19,12)  NULL
				,NonBusinessHoursElapsed        numeric(19,12)  NULL
				,TotalHoursElapsed              numeric(19,12)  NULL
				,QueryBusinessHoursElapsed      numeric(19,12)  NULL
				,QueryNonBusinessHoursElapsed   numeric(19,12)  NULL
				,QueryTotalHoursElapsed         numeric(19,12)  NULL
				,NetBusinessHoursElapsed        numeric(19,12)  NULL
				,NetNonBusinessHoursElapsed     numeric(19,12)  NULL
				,NetTotalHoursElapsed           numeric(19,12)  NULL
				,SLAHours                       numeric(19,12)  NULL
				,OverSLAHours                   numeric(19,12)  NULL
				,WithinSLA                      varchar(255)    NULL
				,IsActivation                   bit             NOT NULL
				,CapitaEntryTimeHours           numeric(19,12)  NULL
				,CapitaQCTimeHours              numeric(19,12)  NULL
				,CapitaTotalTimeHours           numeric(19,12)  NULL
				,FK_Section                      bigint         NOT NULL
				,FK_CycleStartUnderwriter       bigint          NOT NULL
				,FK_CycleEndUnderwriter         bigint          NOT NULL
				,FK_WorkflowCycle               bigint          NOT NULL
	)             

	INSERT INTO #SectionWorkflow
	(
				FK_Section
				,WorkflowSequenceID
				,ReverseWorkflowSequenceId
				,FK_WorkflowStatus
				,WorkflowStatusCode
				,StatusFromDate
				,StatusToDate
				,NonBusinessHoursElapsed
				,BusinessHoursElapsed
				,TotalHoursElapsed
				,WorkflowReasonCode
				,WorkflowReason
				,FK_StatusChangeUnderwriter
	)
	SELECT		FK_Section                          = s.PK_Section 
				,WorkflowSequenceId                 = ROW_NUMBER() OVER(PARTITION BY bw.SectionSourceId ORDER BY bw.WorkflowStatusFromDate ASC)
				,ReverseWorkflowSequenceId          = ROW_NUMBER() OVER(PARTITION BY bw.SectionSourceId ORDER BY bw.WorkflowStatusFromDate DESC)
				,FK_WorkflowStatus                  = ws.PK_WorkflowStatus
				,WorkflowStatusCode                 = ws.WorkflowStatusCode  
				,StatusFromDate                     = bw.WorkflowStatusFromDate
				,StatusToDate						= bw.WorkflowStatusToDate
				,NonBusinessHoursElapsed			= bw.NonWorkingSecondsElapsed / CAST(3600 AS NUMERIC(19,12))      -- Or divide into UPDATE ???
				,BusinessHoursElapsed				= bw.WorkingSecondsElapsed / CAST(3600 AS NUMERIC(19,12))         -- ???
				,TotalHoursElapsed					= (bw.NonWorkingSecondsElapsed + bw.WorkingSecondsElapsed) / CAST(3600 AS NUMERIC(19,12)) -- ???
				,WorkflowReasonCode                 = bw.WorkflowReasonCode
				,WorkflowReason                     = bw.WorkflowReason
				,FK_StatusChangeUnderwriter         = ISNULL(uw.PK_UnderwriterWorkflow, 0)
	FROM		BeazleyIntelligenceDataContract.Outbound.vw_BusinessWorkflow bw with (nolock) 
	INNER JOIN	ODS.Section s with (nolock) 
			ON	bw.SectionSourceId = s.SectionReference
	INNER JOIN	ODS.WorkflowStatus ws with (nolock) 
			ON	bw.WorkflowStatusCode = ws.WorkflowStatusCode
	--BI-6535
	--LEFT JOIN	(
	--			SELECT		PK_Underwriter              = PK_Underwriter, 
	--						UnderwriterUserInitials     = UnderwriterUserInitials,
	--						UnderwriterName             = UnderwriterName
	--			FROM		ODS.Underwriter u 
	--			WHERE		UnderwriterUserInitials is not null 
	
	--			UNION 
	
	--			SELECT		PK_Underwriter              = [Utility].[udf_ComputeIdentity]((isnull(upper(ebu.UnderwriterUserInitials),'')+'|~|')+isnull(upper(ebu.Underwriter),''),0),
	--						UnderwriterInitials         = ebu.UnderwriterInitials,
	--						Underwriter                 = ebu.Underwriter
	--			FROM		Staging_MDS.dbo.vw_user_details ebu
	--			LEFT JOIN	Staging_MDS.MDS_Staging.UnderwriterLocation ul
	--					ON	ebu.Underwriter = ul.UnderwriterName
	--			WHERE		NOT EXISTS (
	--									SELECT 		1 
	--									FROM		ODS.Underwriter u 
	--									WHERE		u.UnderwriterName = ebu.Underwriter 
	--											AND u.UnderwriterInitials = ebu.UnderwriterInitials
	--						)
	--					AND ebu.UnderwriterInitials IS NOT NULL
	--) u		ON	bw.WorkflowStatusChangeUnderwriterName = u.UnderwriterUserInitials

	--BI-7896

	LEFT JOIN	ODS.UnderwriterWorkflow uw with (nolock) 
			ON	bw.WorkflowStatusChangeUnderwriterName = uw.UnderwriterUserInitials

		--AND (bw.AuditCreateDatetime > @LastAuditDate OR bw.AuditModifyDatetime > @LastAuditDate)
		

	/*Create the cycles
	A cycle is defined by the starting status and the next record with the ending status,
	if one exists.

	Cycles can be any of the following status "jumps":

	Q -> NULL
	N -> NULL
	E -> NULL
	R -> NULL
	L -> NULL
	N -> E
	E -> L
	L -> R
	R -> L

	Cycles should never overlap; e.g. the data should not give us this situation
	1. N
	2. L
	3. E
	which would result in an overlap between 'N -> E' and 'L -> NULL'

	Only the earlier/earliest of the overlapping cycles will be loaded.

	If the source data does not follow the rules, this will cause additional cycles to be created erroneously.
	For example, if we have this situation:

	1. N
	2. L

	We will get the following cycles:
	1. N -> NULL
	2. L -> NULL

	Because N -> L is not a "real" cycle.

	Each workflow status record then attaches to the cycle with the latest CycleFromDate preceding 
	or equal to the date of the status. A complex workflow might look as follows:

	(source data: 1:N 2:E 3:I 4:A 5:I 6:A 7:L 8:R 9:I)

	The first number is the CycleSequenceId, the indented number is the WorkflowSequenceId

	1. N -> E
		1. N
	2. E -> L
		2. E
		3. I
		4. A
		5. I
		6. A
	3. L -> R
		7. L
	4. R -> NULL
		8. R
		9. I

	Notice that the ending status of cycle 1 attaches to cycle 2. This is because the "latest CycleFromDate preceding or equal to the date of the status" 
	rule will cause this to happen. This behaviour is by design, because the time spent in the starting status of the cycle should go against that cycle,
	but the time spent in the ending status should not.

	The duration of the cycles is worked out as follows:
		1. Total duration (business/non business time) - Sum of all attaching workflow records
		2. Query duration (business/non business time) - Sum of all attaching status 'I' records
		3. Net duration (business/non business time) - Total duration - query duration.
    
	The net duration is what is used to define whether a cycle is within SLA
	*/

	INSERT INTO #SectionWorkflowCycle	(
				FK_Section
				,CycleSequenceId
				,FK_CycleStartUnderwriter
				,FK_CycleEndUnderwriter
				,FK_WorkflowCycle
				,CycleFromDate
				,CycleToDate
				,WorkflowStartSequenceId
				,WorkflowEndSequenceId
				,IsActivation
	)
	SELECT		FK_Section                              = sw.FK_Section
				,CycleSequenceId                        = ROW_NUMBER() OVER (PARTITION BY sw.FK_Section ORDER BY sw.WorkflowSequenceId)
				,FK_CycleStartUnderwriter               = sw.FK_StatusChangeUnderwriter
				,FK_CycleEndUnderwriter                 = ISNULL(sw2.FK_StatusChangeUnderwriter, 0)
				,FK_WorkflowCycle                       = wc.PK_WorkflowCycle 
				,CycleFromDate                          = sw.StatusFromDate
				,CycleToDate                            = ISNULL(sw2.StatusFromDate, GETDATE())
				,WorkflowStartSequenceId                = sw.WorkflowSequenceID
				,WorkflowEndSequenceId                  = sw2.WorkflowSequenceID
				,IsActivation                           = wc.IsActivation
	FROM		#SectionWorkflow sw
	LEFT JOIN	(
				SELECT		FK_Section                              = sw.FK_Section
							,CycleStartWorkflowSequenceId           = sw.WorkflowSequenceID
							,CycleEndWorkflowSequenceId             = MIN(pw2.WorkflowSequenceID)
				FROM		#SectionWorkflow sw
				INNER JOIN	ODS.WorkflowCycle wc with (nolock) 
						ON	sw.WorkflowStatusCode = wc.WorkflowCycleStartStatus
				INNER JOIN	#SectionWorkflow pw2 
						ON	sw.FK_Section = pw2.FK_Section
						AND wc.WorkflowCycleEndStatus = pw2.WorkflowStatusCode	
						AND pw2.WorkflowSequenceID > sw.WorkflowSequenceID
				GROUP BY	sw.FK_Section, sw.WorkflowSequenceID
	) x ON		sw.FK_Section = x.FK_Section
			AND sw.WorkflowSequenceID = x.CycleStartWorkflowSequenceId
	LEFT JOIN	#SectionWorkflow sw2 
			ON	sw.FK_Section = sw2.FK_Section
			AND x.CycleEndWorkflowSequenceId = sw2.WorkflowSequenceID
	INNER JOIN	ODS.WorkflowCycle wc with (nolock) 
			ON	sw.WorkflowStatusCode = wc.WorkflowCycleStartStatus
			AND (
					sw2.WorkflowStatusCode = wc.WorkflowCycleEndStatus 
					OR (sw2.WorkflowStatusCode IS NULL AND wc.WorkflowCycleEndStatus IS NULL)
				)


	UPDATE		sw 
			SET	WorkflowCycleSequenceId = swc.CycleSequenceId 
	FROM		#SectionWorkflow sw
	INNER JOIN	#SectionWorkflowCycle swc 
			ON	sw.FK_Section = swc.FK_Section
			AND sw.WorkflowSequenceID >= swc.WorkflowStartSequenceId
			AND (sw.WorkflowSequenceID < swc.WorkflowEndSequenceId OR swc.WorkflowEndSequenceId IS NULL)

	/*Delete workflow records which don't belong to a cycle - this should only happen
	when the initial status is 'I' or 'A' which is a data issue*/

	DELETE		sw
	FROM		#SectionWorkflow sw
	WHERE		sw.WorkflowCycleSequenceId IS NULL

	/*Delete cycles which have no workflow records - this should only happen
	where cycles overlap, which is a data issue*/

	DELETE		swc
	FROM		#SectionWorkflowCycle swc
	LEFT JOIN	#SectionWorkflow sw 
			ON	swc.FK_Section = sw.FK_Section
			AND sw.WorkflowCycleSequenceId = swc.CycleSequenceId
	WHERE		sw.FK_Section IS NULL


	UPDATE		swc 
	SET			BusinessHoursElapsed                    = x.BusinessHoursElapsed
				,NonBusinessHoursElapsed                = x.NonBusinessHoursElapsed
				,TotalHoursElapsed                      = x.TotalHoursElapsed
				,QueryBusinessHoursElapsed              = x.QueryBusinessHoursElapsed
				,QueryNonBusinessHoursElapsed           = x.QueryNonBusinessHoursElapsed
				,QueryTotalHoursElapsed                 = x.QueryTotalHoursElapsed
				,NetBusinessHoursElapsed                = x.BusinessHoursElapsed - x.QueryBusinessHoursElapsed
				,NetNonBusinessHoursElapsed             = x.NonBusinessHoursElapsed - x.QueryNonBusinessHoursElapsed
				,NetTotalHoursElapsed                   = x.TotalHoursElapsed - x.QueryTotalHoursElapsed
	FROM		#SectionWorkflowCycle swc
	INNER JOIN	(
				SELECT		FK_Section							= sw.FK_Section
							,WorkflowCycleSequenceId			= sw.WorkflowCycleSequenceId
							,BusinessHoursElapsed				= SUM(sw.BusinessHoursElapsed)
							,NonBusinessHoursElapsed			= SUM(sw.NonBusinessHoursElapsed)
							,TotalHoursElapsed					= SUM(sw.TotalHoursElapsed)
							,QueryBusinessHoursElapsed			= SUM(CASE
																			WHEN sw.WorkflowStatusCode = 'I'
																			THEN sw.BusinessHoursElapsed
																			ELSE 0
																	END)
							,QueryNonBusinessHoursElapsed		= SUM(CASE
																			WHEN sw.WorkflowStatusCode = 'I'
																			THEN sw.NonBusinessHoursElapsed
																			ELSE 0
																	END)
							,QueryTotalHoursElapsed				= SUM(CASE
																			WHEN sw.WorkflowStatusCode = 'I'
																			THEN sw.TotalHoursElapsed
																			ELSE 0
																	END)
				FROM		#SectionWorkflow sw
				GROUP BY	sw.FK_Section, sw.WorkflowCycleSequenceId
	) x		ON	swc.FK_Section = x.FK_Section
			AND swc.CycleSequenceId = x.WorkflowCycleSequenceId

	/*Set SLA hours*/
	UPDATE		swc SET
				SLAHours                = st.TargetHours
				,OverSLAHours           = CASE
											   WHEN st.TargetHours >= swc.NetBusinessHoursElapsed THEN 0
												ELSE swc.NetBusinessHoursElapsed - st.TargetHours
											END
	FROM		#SectionWorkflowCycle swc
	INNER JOIN	ODS.WorkflowCycle wc 
			ON	swc.FK_WorkflowCycle = wc.PK_WorkflowCycle
	INNER JOIN	ODS.Section s 
			ON	swc.FK_Section = s.PK_Section
	INNER JOIN	ODS.TriFocus tf 
			ON	s.FK_TriFocus = tf.PK_TriFocus
	INNER JOIN	Staging_MDS.dbo.vw_sla_targets st 
			ON	st.Departament = tf.EurobaseDepartmentName
			AND st.ActivationType =  CASE 
											WHEN wc.WorkflowCycleStartStatus = 'E' THEN 'N'
											WHEN wc.WorkflowCycleStartStatus = 'R' THEN 'R'
										END
    
	UPDATE		swc 
			SET	WithinSLA = CASE    
								WHEN OverSLAHours IS NULL THEN 'N/A'
								WHEN OverSLAHours <= 0 THEN 'Yes'
								WHEN OverSLAHours > 0 THEN 'No'
							END
	FROM		#SectionWorkflowCycle swc

	/*Prorate Capita time*/
	UPDATE		swc 
			SET	CapitaEntryTimeHours    = s.CapitaEntryTimeHours / x.NumberOfActivations
				,CapitaQCTimeHours		= s.CapitaQCTimeHours / x.NumberOfActivations
				,CapitaTotalTimeHours	= s.CapitaTotalTimeHours / x.NumberOfActivations
	FROM		#SectionWorkflowCycle swc
	INNER JOIN	ODS.Section s 
			ON	swc.FK_Section = s.PK_Section
	INNER JOIN	(
				SELECT		FK_Section              = swc.FK_Section
							,NumberOfActivations    = COUNT(1)
				FROM		#SectionWorkflowCycle swc
				WHERE		swc.IsActivation = 1
				GROUP BY	swc.FK_Section
	) x		ON	swc.FK_Section = x.FK_Section
	WHERE		swc.IsActivation = 1;




	MERGE ODS.SectionWorkflowCycle AS TARGET
	USING	(
				SELECT		CycleSequenceId                         = swc.CycleSequenceId
							,CycleFromDate                          = swc.CycleFromDate
							,CycleToDate                            = swc.CycleToDate
							,BusinessHoursElapsed                   = swc.BusinessHoursElapsed
							,NonBusinessHoursElapsed                = swc.NonBusinessHoursElapsed
							,TotalHoursElapsed                      = swc.TotalHoursElapsed
							,QueryBusinessHoursElapsed              = swc.QueryBusinessHoursElapsed
							,QueryNonBusinessHoursElapsed           = swc.QueryNonBusinessHoursElapsed
							,QueryTotalHoursElapsed                 = swc.QueryTotalHoursElapsed
							,NetBusinessHoursElapsed                = swc.NetBusinessHoursElapsed
							,NetNonBusinessHoursElapsed             = swc.NetNonBusinessHoursElapsed
							,NetTotalHoursElapsed                   = swc.NetTotalHoursElapsed
							,SLAHours                               = swc.SLAHours
							,OverSLAHours                           = swc.OverSLAHours
							,WithinSLA                              = swc.WithinSLA
							,IsActivation                           = swc.IsActivation
							,CapitaEntryTimeHours                   = swc.CapitaEntryTimeHours
							,CapitaQCTimeHours                      = swc.CapitaQCTimeHours
							,CapitaTotalTimeHours                   = swc.CapitaTotalTimeHours
							,FK_Section                             = swc.FK_Section
							,FK_CycleStartUnderwriter               = swc.FK_CycleStartUnderwriter
							,FK_CycleEndUnderwriter                 = swc.FK_CycleEndUnderwriter
							,FK_WorkflowCycle                       = swc.FK_WorkflowCycle
							,FK_YOA                                 = s.FK_YOA
							,FK_SettlementCurrency                  = s.FK_SettlementCurrency
							,FK_OriginalCurrency                    = s.FK_OriginalCurrency
							,FK_TriFocus                            = s.FK_TriFocus
							,FK_CRMBroker                           = s.FK_CRMBroker
							,FK_QuoteFilter                         = s.FK_QuoteFilter
							,FK_HiddenStatusFilter                  = s.FK_HiddenStatusFilter
							,FK_Policy                              = s.FK_Policy
							,SpecialPurposeSyndicateApplies         = s.SpecialPurposeSyndicateApplies
							,FK_UnderwritingPlatform				= s.FK_UnderwritingPlatform
							,FK_InternalWrittenBinderStatus			= s.FK_InternalWrittenBinderStatus
							,FK_ServiceCompany						= s.FK_ServiceCompany
				FROM		#SectionWorkflowCycle swc
				INNER JOIN	ODS.Section s with (nolock) 
						ON	swc.FK_Section = s.PK_Section
				) AS source
	ON  target.FK_Section			= source.FK_Section
	AND target.[CycleSequenceId]	= source.[CycleSequenceId]

	WHEN MATCHED THEN
		UPDATE SET	-- target.CycleSequenceId                         = source.CycleSequenceId                         
					target.CycleFromDate                          	= source.CycleFromDate                          
					,target.CycleToDate                            	= source.CycleToDate                            
					,target.BusinessHoursElapsed                   	= source.BusinessHoursElapsed                   
					,target.NonBusinessHoursElapsed                	= source.NonBusinessHoursElapsed                
					,target.TotalHoursElapsed                      	= source.TotalHoursElapsed                      
					,target.QueryBusinessHoursElapsed              	= source.QueryBusinessHoursElapsed              
					,target.QueryNonBusinessHoursElapsed           	= source.QueryNonBusinessHoursElapsed           
					,target.QueryTotalHoursElapsed                 	= source.QueryTotalHoursElapsed                 
					,target.NetBusinessHoursElapsed                	= source.NetBusinessHoursElapsed                
					,target.NetNonBusinessHoursElapsed             	= source.NetNonBusinessHoursElapsed             
					,target.NetTotalHoursElapsed                   	= source.NetTotalHoursElapsed                   
					,target.SLAHours                               	= source.SLAHours                               
					,target.OverSLAHours                           	= source.OverSLAHours                           
					,target.WithinSLA                              	= source.WithinSLA                              
					,target.IsActivation                           	= source.IsActivation                           
					,target.CapitaEntryTimeHours                   	= source.CapitaEntryTimeHours                   
					,target.CapitaQCTimeHours                      	= source.CapitaQCTimeHours                      
					,target.CapitaTotalTimeHours                   	= source.CapitaTotalTimeHours                   
					--,target.FK_Section                             	= source.FK_Section                             
					,target.FK_CycleStartUnderwriter               	= source.FK_CycleStartUnderwriter               
					,target.FK_CycleEndUnderwriter                 	= source.FK_CycleEndUnderwriter                 
					,target.FK_WorkflowCycle                       	= source.FK_WorkflowCycle                       
					,target.FK_YOA                                 	= source.FK_YOA                                 
					,target.FK_SettlementCurrency                  	= source.FK_SettlementCurrency                  
					,target.FK_OriginalCurrency                    	= source.FK_OriginalCurrency                    
					,target.FK_TriFocus                            	= source.FK_TriFocus                            
					,target.FK_CRMBroker                           	= source.FK_CRMBroker                           
					,target.FK_QuoteFilter                         	= source.FK_QuoteFilter                         
					,target.FK_HiddenStatusFilter                  	= source.FK_HiddenStatusFilter                  
					,target.FK_Policy                              	= source.FK_Policy                              
					,target.SpecialPurposeSyndicateApplies         	= source.SpecialPurposeSyndicateApplies         
					,target.FK_UnderwritingPlatform					= source.FK_UnderwritingPlatform				
					,target.FK_InternalWrittenBinderStatus			= source.FK_InternalWrittenBinderStatus			
					,target.FK_ServiceCompany						= source.FK_ServiceCompany						
					,target.AuditModifyDateTime						= GETDATE()						
					,target.AuditModifyDetails						= 'Merge in ODS.usp_LoadSectionWorkflow proc' 

	WHEN NOT MATCHED BY TARGET THEN
	INSERT		(    
					CycleSequenceId
					,CycleFromDate
					,CycleToDate
					,BusinessHoursElapsed
					,NonBusinessHoursElapsed
					,TotalHoursElapsed
					,QueryBusinessHoursElapsed
					,QueryNonBusinessHoursElapsed
					,QueryTotalHoursElapsed
					,NetBusinessHoursElapsed
					,NetNonBusinessHoursElapsed
					,NetTotalHoursElapsed
					,SLAHours
					,OverSLAHours
					,WithinSLA
					,IsActivation
					,CapitaEntryTimeHours
					,CapitaQCTimeHours
					,CapitaTotalTimeHours
					,FK_Section
					,FK_CycleStartUnderwriter
					,FK_CycleEndUnderwriter
					,FK_WorkflowCycle
					,FK_YOA
					,FK_SettlementCurrency
					,FK_OriginalCurrency
					,FK_TriFocus
					,FK_CRMBroker
					,FK_QuoteFilter
					,FK_HiddenStatusFilter
					,FK_Policy
					,SpecialPurposeSyndicateApplies
					,FK_UnderwritingPlatform
					,FK_InternalWrittenBinderStatus
					,FK_ServiceCompany     
					,AuditCreateDateTime
					,AuditModifyDetails
	)
	VALUES		(
					 source.CycleSequenceId
					,source.CycleFromDate
					,source.CycleToDate
					,source.BusinessHoursElapsed
					,source.NonBusinessHoursElapsed
					,source.TotalHoursElapsed
					,source.QueryBusinessHoursElapsed
					,source.QueryNonBusinessHoursElapsed
					,source.QueryTotalHoursElapsed
					,source.NetBusinessHoursElapsed
					,source.NetNonBusinessHoursElapsed
					,source.NetTotalHoursElapsed
					,source.SLAHours
					,source.OverSLAHours
					,source.WithinSLA
					,source.IsActivation
					,source.CapitaEntryTimeHours
					,source.CapitaQCTimeHours
					,source.CapitaTotalTimeHours
					,source.FK_Section
					,source.FK_CycleStartUnderwriter
					,source.FK_CycleEndUnderwriter
					,source.FK_WorkflowCycle
					,source.FK_YOA
					,source.FK_SettlementCurrency
					,source.FK_OriginalCurrency
					,source.FK_TriFocus
					,source.FK_CRMBroker
					,source.FK_QuoteFilter
					,source.FK_HiddenStatusFilter
					,source.FK_Policy
					,source.SpecialPurposeSyndicateApplies
					,source.FK_UnderwritingPlatform
					,source.FK_InternalWrittenBinderStatus
					,source.FK_ServiceCompany      
					,GETDATE()
					,'New add in ODS.usp_LoadSectionWorkflow proc'	
	)
	WHEN NOT MATCHED BY SOURCE THEN 
					DELETE
	;




	MERGE ODS.SectionWorkflow AS TARGET
	USING	(
				SELECT		WorkflowSequenceID                      = sw.WorkflowSequenceID
							,ReverseWorkflowSequenceId              = sw.ReverseWorkflowSequenceId
							,StatusFromDate                         = sw.StatusFromDate 
							,StatusToDate                           = sw.StatusToDate
							,BusinessHoursElapsed                   = sw.BusinessHoursElapsed
							,NonBusinessHoursElapsed                = sw.NonBusinessHoursElapsed
							,TotalHoursElapsed                      = sw.TotalHoursElapsed 
							,WorkflowReasonCode                     = sw.WorkflowReasonCode
							,WorkflowReason                         = sw.WorkflowReason
							,FK_WorkflowStatus                      = sw.FK_WorkflowStatus
							,FK_SectionWorkflowCycle                = swc.PK_SectionWorkflowCycle 
							,FK_StatusChangeUnderwriter             = sw.FK_StatusChangeUnderwriter
							,FK_Section                             = sw.FK_Section
							,FK_YOA                                 = s.FK_YOA
							,FK_SettlementCurrency                  = s.FK_SettlementCurrency
							,FK_OriginalCurrency                    = s.FK_OriginalCurrency
							,FK_TriFocus                            = s.FK_TriFocus
							,FK_CRMBroker                           = s.FK_CRMBroker
							,FK_QuoteFilter                         = s.FK_QuoteFilter
							,FK_HiddenStatusFilter                  = s.FK_HiddenStatusFilter
							,FK_Policy                              = s.FK_Policy
							,SpecialPurposeSyndicateApplies         = s.SpecialPurposeSyndicateApplies
							,FK_UnderwritingPlatform				= s.FK_UnderwritingPlatform
							,FK_InternalWrittenBinderStatus			= s.FK_InternalWrittenBinderStatus
							,FK_ServiceCompany						= s.FK_ServiceCompany
				FROM		#SectionWorkflow sw
				INNER JOIN	ODS.SectionWorkflowCycle swc with (nolock) 
						ON	sw.FK_Section = swc.FK_Section
						AND sw.WorkflowCycleSequenceId = swc.CycleSequenceId
				INNER JOIN	ODS.Section s with (nolock) 
						ON	swc.FK_Section = s.PK_Section
				) AS source
	ON  target.[FK_SectionWorkflowCycle]	= source.[FK_SectionWorkflowCycle]
	AND target.[WorkflowSequenceID]			= source.[WorkflowSequenceID]

	WHEN MATCHED THEN
		UPDATE SET	-- target.WorkflowSequenceID 					= source.WorkflowSequenceID
					target.ReverseWorkflowSequenceId           = source.ReverseWorkflowSequenceId
					,target.StatusFromDate                      = source.StatusFromDate
					,target.StatusToDate                        = source.StatusToDate
					,target.BusinessHoursElapsed                = source.BusinessHoursElapsed
					,target.NonBusinessHoursElapsed             = source.NonBusinessHoursElapsed
					,target.TotalHoursElapsed                   = source.TotalHoursElapsed
					,target.WorkflowReasonCode                  = source.WorkflowReasonCode
					,target.WorkflowReason                      = source.WorkflowReason
					,target.FK_WorkflowStatus                   = source.FK_WorkflowStatus
					--,target.FK_SectionWorkflowCycle             = source.FK_SectionWorkflowCycle
					,target.FK_StatusChangeUnderwriter          = source.FK_StatusChangeUnderwriter
					,target.FK_Section                          = source.FK_Section
					,target.FK_YOA                              = source.FK_YOA
					,target.FK_SettlementCurrency               = source.FK_SettlementCurrency
					,target.FK_OriginalCurrency                 = source.FK_OriginalCurrency
					,target.FK_TriFocus                         = source.FK_TriFocus
					,target.FK_CRMBroker                        = source.FK_CRMBroker
					,target.FK_QuoteFilter                      = source.FK_QuoteFilter
					,target.FK_HiddenStatusFilter               = source.FK_HiddenStatusFilter
					,target.FK_Policy                           = source.FK_Policy
					,target.SpecialPurposeSyndicateApplies      = source.SpecialPurposeSyndicateApplies
					,target.FK_UnderwritingPlatform             = source.FK_UnderwritingPlatform
					,target.FK_InternalWrittenBinderStatus      = source.FK_InternalWrittenBinderStatus
					,target.FK_ServiceCompany                   = source.FK_ServiceCompany                            
					,target.AuditModifyDateTime						= GETDATE()						
					,target.AuditModifyDetails						= 'Merge in ODS.usp_LoadSectionWorkflow proc' 
	WHEN NOT MATCHED BY TARGET THEN
	INSERT		(    
					WorkflowSequenceID
					,ReverseWorkflowSequenceId
					,StatusFromDate
					,StatusToDate
					,BusinessHoursElapsed
					,NonBusinessHoursElapsed
					,TotalHoursElapsed
					,WorkflowReasonCode
					,WorkflowReason
					,FK_WorkflowStatus
					,FK_SectionWorkflowCycle
					,FK_StatusChangeUnderwriter
					,FK_Section
					,FK_YOA
					,FK_SettlementCurrency
					,FK_OriginalCurrency
					,FK_TriFocus
					,FK_CRMBroker
					,FK_QuoteFilter
					,FK_HiddenStatusFilter
					,FK_Policy
					,SpecialPurposeSyndicateApplies
					,FK_UnderwritingPlatform
					,FK_InternalWrittenBinderStatus
					,FK_ServiceCompany
					,AuditCreateDateTime
					,AuditModifyDetails
	)
	VALUES		(
					 source.WorkflowSequenceID
					,source.ReverseWorkflowSequenceId
					,source.StatusFromDate
					,source.StatusToDate
					,source.BusinessHoursElapsed
					,source.NonBusinessHoursElapsed
					,source.TotalHoursElapsed
					,source.WorkflowReasonCode
					,source.WorkflowReason
					,source.FK_WorkflowStatus
					,source.FK_SectionWorkflowCycle
					,source.FK_StatusChangeUnderwriter
					,source.FK_Section
					,source.FK_YOA
					,source.FK_SettlementCurrency
					,source.FK_OriginalCurrency
					,source.FK_TriFocus
					,source.FK_CRMBroker
					,source.FK_QuoteFilter
					,source.FK_HiddenStatusFilter
					,source.FK_Policy
					,source.SpecialPurposeSyndicateApplies
					,source.FK_UnderwritingPlatform
					,source.FK_InternalWrittenBinderStatus
					,source.FK_ServiceCompany
					,GETDATE()
					,'New add in ODS.usp_LoadSectionWorkflow proc'	
	)
	WHEN NOT MATCHED BY SOURCE THEN 
					DELETE
	;

	/*Update latest status on Section*/
	UPDATE		s 
			SET	FK_CurrentWorkflowStatus            = sw.FK_WorkflowStatus
				,CurrentWorkflowStatusFromDate      = sw.StatusFromDate
				,FK_CurrentWorkflowStatusFromDate   = IIF(YEAR(sw.StatusFromDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, sw.StatusFromDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](sw.StatusFromDate)
				,CurrentWorkflowStatusFromDateName	= IIF(YEAR(sw.StatusFromDate )< 1990 OR YEAR(sw.StatusFromDate)>2050,NULL,FORMAT(sw.StatusFromDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](sw.StatusFromDate)
	FROM		ODS.Section s
	INNER JOIN	ODS.SectionWorkflowCycle swc 
			ON	s.PK_Section = swc.FK_Section
	INNER JOIN	ODS.SectionWorkflow sw 
			ON	swc.PK_SectionWorkflowCycle = sw.FK_SectionWorkflowCycle
			AND sw.ReverseWorkflowSequenceId = 1

	--Clean up
	DROP TABLE IF EXISTS #SectionWorkflow

	DROP TABLE IF EXISTS #SectionWorkflowCycle
END