﻿

CREATE PROCEDURE [ODS].[usp_LoadSectionSpecialCategorySection]
AS

SET NOCOUNT ON


IF (OBJECT_ID('tempdb..#SectionSpecialCategorySection') IS NOT NULL)
DROP TABLE #SectionSpecialCategorySection

CREATE TABLE #SectionSpecialCategorySection
(
    [FK_Section] [bigint] NOT NULL,
	[FK_SpecialCategorySection] [bigint] NOT NULL,
)

INSERT INTO #SectionSpecialCategorySection
(
    FK_Section
    ,FK_SpecialCategorySection
)
SELECT DISTINCT
FK_Section                      = s.PK_Section
,FK_SpecialCategorySection      = spec.PK_SpecialCategorySection
FROM
Staging_MDS.dbo.vw_special_policy sp
INNER JOIN
ODS.Section s ON
sp.PolicyReference = s.SectionReference
INNER JOIN
ODS.SpecialCategorySection spec ON
Utility.udf_ProcessString(sp.[Description], 1) = spec.SpecialCategory


/*Dummy BBR sections inherit from parent*/
INSERT INTO #SectionSpecialCategorySection
(
    FK_Section
    ,FK_SpecialCategorySection
)
SELECT
FK_Section                      = s_bbr.PK_Section
,FK_SpecialCategorySection      = sscs.FK_SpecialCategorySection
FROM
#SectionSpecialCategorySection sscs
INNER JOIN
ODS.Section s ON
sscs.FK_Section = s.PK_Section
INNER JOIN
ODS.Section s_bbr ON
s_bbr.FK_BreachResponseParentSection = s.PK_Section

INSERT INTO #SectionSpecialCategorySection
(
    FK_Section
    ,FK_SpecialCategorySection
)
SELECT
FK_Section                      = p.PK_Section
,FK_SpecialCategorySection      = 0
FROM
ODS.Section p
WHERE
NOT EXISTS (SELECT 1 FROM #SectionSpecialCategorySection psc WHERE p.PK_Section = psc.FK_Section)


MERGE ODS.SectionSpecialCategorySection AS TARGET

USING #SectionSpecialCategorySection AS SOURCE

 ON TARGET.FK_Section                 = SOURCE.FK_Section
AND TARGET.FK_SpecialCategorySection  = SOURCE.FK_SpecialCategorySection

 WHEN MATCHED THEN
 
 UPDATE SET

 TARGET.FK_Section                  = SOURCE.FK_Section
,TARGET.FK_SpecialCategorySection   = SOURCE.FK_SpecialCategorySection
,TARGET.AuditModifyDateTime         = GETDATE()
,TARGET.AuditModifyDetails          = 'Merge in [ODS].[SectionSpecialCategorySection] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT 
(
 FK_Section
,FK_SpecialCategorySection
,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_Section
,SOURCE.FK_SpecialCategorySection
,'New in [ODS].[SectionSpecialCategorySection] table'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#SectionSpecialCategorySection') IS NOT NULL)
DROP TABLE #SectionSpecialCategorySection