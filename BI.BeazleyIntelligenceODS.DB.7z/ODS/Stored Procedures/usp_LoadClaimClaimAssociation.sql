﻿
CREATE PROCEDURE [ODS].[usp_LoadClaimClaimAssociation]
AS



SET NOCOUNT ON

--DELETE cca
--FROM ODS.ClaimClaimAssociation cca
--LEFT JOIN ODS.Claim c
--ON cca.FK_Claim = c.PK_Claim
--LEFT JOIN ODS.ClaimAssociation ca
--ON cca.FK_ClaimAssociation = ca.PK_ClaimAssociation
--LEFT JOIN BeazleyIntelligenceDataContract.Outbound.vw_ClaimAssociation vca
--ON c.ClaimReference = vca.ClaimSourceId
--WHERE (c.PK_Claim IS NULL OR ca.PK_ClaimAssociation IS NULL OR vca.ClaimSourceId IS NULL)
--AND cca.IsUnknownMember<>1


--DECLARE @LastAuditDate DATETIME2(7)

--SELECT 
--	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
--FROM ODS.ClaimClaimAssociation
--SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')
/* Insert ClaimClaimAssociation data*/

MERGE ODS.ClaimClaimAssociation target
USING(
     SELECT DISTINCT      
       FK_Claim              = cc.PK_Claim
      ,FK_ClaimAssociation   = COALESCE(ccassoc.PK_ClaimAssociation,0)
      ,AssociationSequenceId = 0
      ,AssociationPrimary    = ca.AssociationPrimary
      ,IsUnknownMember       = 0
	 FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimAssociation ca
     
     INNER JOIN ODS.Claim cc
     ON cc.ClaimReference = ca.ClaimSourceId
     
     LEFT OUTER JOIN ODS.ClaimAssociation ccassoc
     ON  COALESCE(ca.AssociationReason,'Unknown') = ccassoc.AssociationReason
     AND COALESCE(ca.AssociationName,'Unknown') = ccassoc.AssociationName

     WHERE
     ca.SourceSystem = 'ClaimCenter'
	 -- AND (	(cc.AuditCreateDatetime > @LastAuditDate OR cc.AuditModifyDatetime > @LastAuditDate)
		--OR (ccassoc.AuditCreateDatetime > @LastAuditDate OR ccassoc.AuditModifyDatetime > @LastAuditDate)
  --      OR (ca.AuditCreateDatetime > @LastAuditDate OR ca.AuditModifyDatetime > @LastAuditDate))
    
	--This part can't be added for the moment as in ODS.Claim we don't have PK_claim = 0 for the Unknown member and the merge fails      
	--To be uncommented after PK_CLaim = 0 and PK_ClaimAssociation = 0 for Unknown will be added 
    --UNION

    --SELECT
    --   FK_Claim              = 0
    --  ,FK_ClaimAssociation   = 0
    --  ,AssociationSequenceId = 0
    --  ,AssociationPrimary    = 0
    --  ,IsUnknownMember       = 1
) source
ON  target.FK_Claim			   = source.FK_Claim
AND target.FK_ClaimAssociation = source.FK_ClaimAssociation
AND target.AssociationPrimary  = source.AssociationPrimary


WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
 FK_Claim             
,FK_ClaimAssociation  
,AssociationSequenceId
,AssociationPrimary
,IsUnknownMember
,AuditCreateDateTime
,AuditModifyDetails
)
VALUES
(
 source.FK_Claim             
,source.FK_ClaimAssociation  
,source.AssociationSequenceId
,source.AssociationPrimary
,source.IsUnknownMember
,GETDATE()
,'New add in [ODS].[usp_LoadClaimClaimAssociation] proc'	
)


WHEN NOT MATCHED BY SOURCE THEN DELETE;


/*Update primary association key*/

UPDATE c 
SET FK_PrimaryClaimAssociation = 0
   ,ClaimAssociationIndicator  = 0
FROM ODS.Claim c

UPDATE c 
SET FK_PrimaryClaimAssociation = PK_ClaimClaimAssociation
   ,ClaimAssociationIndicator  = 1 
FROM ODS.Claim c
CROSS APPLY (SELECT TOP 1 PK_ClaimClaimAssociation
FROM ODS.ClaimClaimAssociation cca 
WHERE c.PK_Claim = cca.FK_Claim
AND cca.FK_ClaimAssociation <> 0
ORDER BY AssociationPrimary DESC, ISNULL(AuditModifyDateTime,AuditCreateDateTime) DESC) cca


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimClaimAssociation';
GO









