﻿

CREATE PROCEDURE [ODS].[usp_LoadTriFocusYOA]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#TriFocusYOA') IS NOT NULL)
DROP TABLE #TriFocusYOA

CREATE TABLE #TriFocusYOA
(
    [FK_TriFocus] [bigint] NOT NULL,
	[FK_YOA] [bigint] NOT NULL,
	[LloydsClassCode] [varchar](255) NULL,
	[LloydsClass] [varchar](255) NULL,
	[BusinessPlanULRMultiplier] [numeric](19, 12) NULL
)


INSERT INTO #TriFocusYOA
(
     FK_TriFocus
     ,FK_YOA
     ,LloydsClassCode
     ,LloydsClass
     ,BusinessPlanULRMultiplier
)
SELECT
FK_TriFocus                     = tf.PK_TriFocus
,FK_YOA                         = yoa.PK_YOA
,LloydsClassCode                = lcc.Lloyds_Class_Code
,LloydsClass                    = lcc.Lloyds_Class_Name
,BusinessPlanULRMultiplier      = ulr.Business_Plan_ULR
FROM
Staging_Datamart.Datamart_Staging.Lloyds_Class_Code_Mapping lcc
FULL OUTER JOIN
(Select * from (select *, Rowid = row_number() over(partition by ul.TriFocus_Group,ul.YOA order by ul.extract_uniquekey desc ) 
from  Staging_Datamart.Datamart_Staging.Benchmark_and_Business_Plan_ULRs ul) x where x.Rowid = 1) ulr ON
lcc.TriFocus_Group = ulr.TriFocus_Group
AND lcc.YOA = ulr.YOA
INNER JOIN
ODS.TriFocus tf ON
ISNULL(lcc.TriFocus_Group, ulr.TriFocus_Group) = tf.TriFocusName
INNER JOIN
ODS.YOA yoa ON
ISNULL(lcc.YOA, ulr.YOA) = yoa.PK_YOA


MERGE ODS.TriFocusYOA AS TARGET

USING #TriFocusYOA AS SOURCE

 ON TARGET.FK_TriFocus  = SOURCE.FK_TriFocus
AND TARGET.FK_YOA       = SOURCE.FK_YOA

 WHEN MATCHED THEN
 
 UPDATE SET

 TARGET.FK_TriFocus                 = SOURCE.FK_TriFocus
,TARGET.FK_YOA                      = SOURCE.FK_YOA
,TARGET.LloydsClassCode             = SOURCE.LloydsClassCode
,TARGET.LloydsClass                 = SOURCE.LloydsClass
,TARGET.BusinessPlanULRMultiplier   = SOURCE.BusinessPlanULRMultiplier
,TARGET.AuditModifyDateTime         = GETDATE()
,TARGET.AuditModifyDetails          = 'Merge in [ODS].[TriFocusYOA] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT 
(
 FK_TriFocus
,FK_YOA
,LloydsClassCode
,LloydsClass
,BusinessPlanULRMultiplier
,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_TriFocus
,SOURCE.FK_YOA
,SOURCE.LloydsClassCode
,SOURCE.LloydsClass
,SOURCE.BusinessPlanULRMultiplier           
,'New in [ODS].[TriFocusYOA] table'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#TriFocusYOA') IS NOT NULL)
DROP TABLE #TriFocusYOA