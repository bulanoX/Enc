﻿CREATE PROCEDURE [ODS].[usp_LoadArea]
AS


SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Area

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE FROM ODS.Area WHERE AreaCode NOT IN (SELECT DISTINCT AreaCode FROM Staging_MDS.dbo.vw_area_codes UNION ALL SELECT DISTINCT AreaCode FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionTerritory UNION ALL SELECT 'N/A' )
DELETE FROM ODS.Area WHERE FK_ParentArea NOT IN (SELECT DISTINCT PK_Area FROM ODS.Area)

IF (OBJECT_ID('tempdb..#Area') IS NOT NULL)
DROP TABLE #Area

CREATE TABLE #Area (
	--[PK_Area]  AS (isnull([Utility].[udf_ComputeIdentity](upper([AreaCode]),[IsUnknownMember]),(0))) PERSISTED NOT NULL,
	[IsUnknownMember] bit NOT NULL DEFAULT(0),
	[AreaCode] [varchar](255) NOT NULL,
	[Area] [varchar](255) NULL,
	[ContinentCode] [varchar](255) NULL,
	[Continent] [varchar](255) NULL,
	[AreaCountryCode] [varchar](255) NULL,
	[ESICategory] [varchar](255) NULL,
	[FK_ParentArea] [bigint] NOT NULL)


INSERT INTO #Area
(
	IsUnknownMember
    ,AreaCode
    ,Area
    ,ContinentCode
    ,Continent
    ,AreaCountryCode
    ,ESICategory
    ,FK_ParentArea
)
SELECT
IsUnknownMember		= 0
,AreaCode           = a.AreaCode
,Area               = Utility.udf_ProcessString(a.[Description], 1)
,ContinentCode      = Utility.udf_ProcessString(c.ContinentCode, 1)
,Continent          = Utility.udf_ProcessString(c.[Description], 1)
,AreaCountryCode    = Utility.udf_ProcessString(ac.CountryCode, 1)
,ESICategory        = CASE
                        WHEN Utility.udf_ProcessString(a.[Description], 1) = 'UNITED KINGDOM' THEN 'United Kingdom'
                        WHEN Utility.udf_ProcessString(a.[Description], 1) = 'FRANCE' THEN 'France'
                        WHEN Utility.udf_ProcessString(a.[Description], 1) = 'GERMANY' THEN 'Germany'
                        WHEN Utility.udf_ProcessString(a.[Description], 1) = 'ITALY' THEN 'Italy'
                        WHEN Utility.udf_ProcessString(c.[Description], 1) = 'EUROPE' THEN 'Other Europe'
                        ELSE 'Non-Europe'
                      END
,FK_ParentArea      = 0 
FROM
Staging_MDS.dbo.vw_area_codes a
LEFT OUTER JOIN 
Staging_MDS.dbo.vw_area_country_code ac ON
a.AreaCode = ac.AreaCode
LEFT OUTER JOIN
Staging_MDS.dbo.vw_continent_codes c ON
LEFT(a.AreaCode, 1) = c.ContinentCode

UNION ALL 

--Unknown member
SELECT
	 IsUnkownMember   = 1
	,AreaCode         = 'N/A' 
	,Area             = 'N/A' 
	,ContinentCode    = NULL
	,Continent        = NULL
	,AreaCountryCode  = NULL
	,ESICategory      = NULL
	,FK_ParentArea    = 0 

-- Territory
INSERT INTO #Area
(
     AreaCode
    ,Area
    ,ContinentCode
    ,Continent
    ,AreaCountryCode
    ,ESICategory
    ,FK_ParentArea
)

SELECT DISTINCT 
 AreaCode           = terr.AreaCode
,Area               = terr.Area
,ContinentCode      = NULL
,Continent          = NULL
,AreaCountryCode    = NULL
,ESICategory        = NULL
,FK_ParentArea      = 0 
 
FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionTerritory terr

WHERE NOT EXISTS (SELECT 1 FROM #Area are WHERE are.AreaCode = terr.AreaCode)
AND terr.Area <> ''
AND ISNULL(terr.AuditModifyDateTime, terr.AuditCreateDateTime) >= @LastAuditDate
--AND terr.IsActive = 1

;MERGE ods.Area  AS Target
USING #Area as Source 
	ON (
		ISNULL(Source.AreaCode, 'Not Available') = ISNULL(Target.AreaCode, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
	)
WHEN MATCHED THEN UPDATE
	SET Target.[Area]                   = Source.[Area], 
		Target.[ContinentCode]          = Source.[ContinentCode], 
		Target.[Continent]              = Source.[Continent], 
		Target.[AreaCountryCode]        = Source.[AreaCountryCode], 
		Target.[ESICategory]            = Source.[ESICategory], 
		Target.[FK_ParentArea]          = Source.[FK_ParentArea],
		Target.AuditModifyDateTime	    = GETDATE(),						
        Target.AuditModifyDetails	    = 'Merge in ODS.usp_LoadArea'
WHEN NOT MATCHED BY TARGET THEN 
		INSERT(
		[IsUnknownMember], 
		[AreaCode], 
		[Area], 
		[ContinentCode], 
		[Continent], 
		[AreaCountryCode], 
		[ESICategory], 
		[FK_ParentArea],
		[AuditCreateDateTime],
		[AuditModifyDetails]
		)
		VALUES(
		Source.[IsUnknownMember], 
		Source.[AreaCode], 
		Source.[Area], 
		Source.[ContinentCode], 
		Source.[Continent], 
		Source.[AreaCountryCode], 
		Source.[ESICategory], 
		Source.[FK_ParentArea],
		GETDATE(),
		'New add in ODS.usp_LoadArea')
;

IF (OBJECT_ID('tempdb..#Area') IS NOT NULL)
DROP TABLE #Area

-----------------------------------

UPDATE a SET
FK_ParentArea = CASE
                    WHEN LEN(a.AreaCode) = 1 OR a.AreaCode = 'BXX' THEN a.PK_Area --Continents are the root of the tree
                    WHEN ap.PK_Area = a.PK_Area THEN 0 --Nothing should be its own parent unless it's a continent or the N/A member
                    ELSE ISNULL(ap.PK_Area, 0) --If it doesn't have a parent, the N/A member should be its parent
                END
FROM
ODS.Area a
LEFT OUTER JOIN
Staging_DocumentManagement.DocumentManagement_Staging.Territory t ON
a.AreaCode = t.EurobaseCode COLLATE Latin1_General_CI_AS
AND t.TerrID IN (SELECT TerrID FROM Staging_DocumentManagement.DocumentManagement_Staging.TerritoryLink)
LEFT OUTER JOIN
Staging_DocumentManagement.DocumentManagement_Staging.TerritoryLink tl ON
t.TerrID = tl.TerrID
AND t.TerrID <> tl.ParentTerrID --Discard records where the code is its own parent
LEFT OUTER JOIN
Staging_DocumentManagement.DocumentManagement_Staging.Territory tp ON
tl.ParentTerrID = tp.TerrID
LEFT OUTER JOIN
ODS.Area ap ON
tp.EurobaseCode COLLATE Latin1_General_CI_AS = ap.AreaCode
WHERE
a.PK_Area <> 0;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Area';