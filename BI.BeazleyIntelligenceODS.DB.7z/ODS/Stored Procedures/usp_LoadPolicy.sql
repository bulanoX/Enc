﻿
CREATE procedure [ODS].[usp_LoadPolicy]
as

begin 
	--TRUNCATE TABLE ODS.Policy

	/*Insert policy records*/
	INSERT INTO ODS.Policy
	(
		PolicyReference
		,SourceSystem
		,SourceSystemKey
 		,AdditionalInsuredParty
		,Address0
		,Address1
		,Address2
		,Address3
		,Address4
		,AdmittedNonAdmitted
		,AffinityIdentifier
		,AgressoBrokerID
		,AnnualRevenues
		,AnySectionIsBreachResponseDummy
		,AnySectionIsSynergy
		,AttachmentPoint
		,BrokerAccessPolicyNumber
		,BrokerNetworkName
		,CapitaBrokerID	
		,Cedant		
		,Coinsurance
		,ContractBasis	
		,CoverholderName
		,DomicileCountry
		,EarliestRationaleQuestionnaireDate	
		,EarliestRationaleDate
		,ErpExpirationDate
		,ExpiringPolicy
		,EndorsementNumber
		,FundType	
		,InitiativeUS
		,InsuranceType	
		,InsuredParty
		 ,InsuredLegalTradingName 
		,IsBID
		,IsBoundQuote
		,IsBrokerAccessReferral
		,IsNewYorkFreeTradeZone
		,IsQuote
		,IsRenewal
		,IsRunOff
		,LargeRiskExemption
		,LeadFeesPercentage
		,MarketSegment
		,MarketSegmentCode
		,McareAssessment
		,MethodOfPlacement
		,MethodOfPlacementCode
		,NetworkEndDate
		,NetworkStartDate
		,PatientCompensationFund
		,PlacingBrokerContact
		,PolicyReferenceMOPCode
		,PolicyReferenceMOPCodeRiskNumber
		,PolicyReferenceRiskNumber
		,PolicyReferenceYOA
		,PolicyType
		,PolicyURL
		,PolicyURLLabel
		,PrimarySectionBinderType
		,ProducingBrokerContact
		,ReinsuredParty
		,RenewingPolicy
		,RiskType
		,RunOffDate
		,ServiceCompanyLocation
		,SourceSystemInsuredId
		,TaxPercentage
		,TriaPercentage
		,UPIFlag
		,UniqueMarketReference
		,USMiscMedLifeSciencesPolicyCOBCode
		,USMiscMedLifeSciencesPolicyCOB
		,FK_AccountingCalendar
		,FK_CRMBroker
		,FK_CRMProducingBroker
		,FK_PartyBrokerNoticeOfClaim
		,FK_PartyBrokerPlacing
		,FK_PartyBrokerProducing
		,FK_PartyBrokerServiceOfSuit
		,FK_PartyInsured
		,FK_QuoteFilter
		,FK_ServiceCompany
		,FK_Submission
		,FK_UnderwritingPlatform
		,FK_YOA
		,FK_ExpiringPolicy
		,FK_RenewingPolicy
		,HashBytesId
		,AuditModifyDateTime
		,AuditCreateDateTime
		,AuditModifyDetails
   
	)
	SELECT
		PolicyReference                     = p.PolicyReference
		,SourceSystem                       = p.SourceSystem
		,SourceSystemKey					= p.SourceSystemKey
		,AdditionalInsuredParty				= p.AdditionalInsuredParty
		,Address0							= p.Address0
		,Address1							= p.Address1
		,Address2							= p.Address2
		,Address3							= p.Address3
		,Address4							= p.Address4
		,AdmittedNonAdmitted				= p.AdmittedNonAdmitted
		,AffinityIdentifier					= p.AffinityIdentifier
		,AgressoBrokerID					= p.AgressoBrokerID
		,AnnualRevenues						= p.AnnualRevenues
		,AnySectionIsBreachResponseDummy	= p.AnySectionIsBreachResponseDummy
		,AnySectionIsSynergy				= p.AnySectionIsSynergy
		,AttachmentPoint					= p.AttachmentPoint
		,BrokerAccessPolicyNumber			= p.BrokerAccessPolicyNumber
		,BrokerNetworkName					= p.BrokerNetworkName
		,CapitaBrokerID						= p.CapitaBrokerID	
		,Cedant								= p.Cedant
		,Coinsurance						= p.Coinsurance
		,ContractBasis						= p.ContractBasis
		,CoverholderName					= p.CoverholderName
		,DomicileCountry                    = p.DomicileCountry
		,EarliestRationaleQuestionnaireDate	= p.EarliestRationaleQuestionnaireDate	
		,EarliestRationaleDate				= p.EarliestRationaleDate	
		,ErpExpirationDate					= p.ErpExpirationDate			
		,ExpiringPolicy						= p.ExpiringPolicy
		,EndorsementNumber					= p.EndorsementNumber
		,FundType							= p.FundType
		,InitiativeUS						= p.InitiativeUS
		,InsuranceType						= p.InsuranceType
		,InsuredParty						= p.InsuredParty
		 ,InsuredLegalTradingName			= p.InsuredLegalTradingName 
		,IsBID								= p.IsBID
		,IsBoundQuote						= p.IsBoundQuote
		,IsBrokerAccessReferral				= p.IsBrokerAccessReferral
		,IsNewYorkFreeTradeZone				= p.IsNewYorkFreeTradeZone
		,IsQuote							= p.IsQuote
		,IsRenewal							= ISNULL(p.IsRenewal, 0)
		,IsRunOff							= p.IsRunOff
		,LargeRiskExemption					= p.LargeRiskExemption
		,LeadFeesPercentage					= p.LeadFeesPercentage
		,MarketSegment						= p.MarketSegment
		,MarketSegmentCode					= p.MarketSegmentCode
		,McareAssessment					= p.McareAssessment
		,MethodOfPlacement					= p.MethodOfPlacement
		,MethodOfPlacementCode				= p.MethodOfPlacementCode
		,NetworkEndDate						= p.NetworkEndDate
		,NetworkStartDate					= p.NetworkStartDate
		,PatientCompensationFund			= p.PatientCompensationFund
		,PlacingBrokerContact				= p.PlacingBrokerContact
		,PolicyReferenceMOPCode				= p.PolicyReferenceMOPCode
		,PolicyReferenceMOPCodeRiskNumber	= p.PolicyReferenceMOPCodeRiskNumber
		,PolicyReferenceRiskNumber			= p.PolicyReferenceRiskNumber
		,PolicyReferenceYOA					= p.PolicyReferenceYOA
		,PolicyType							= p.PolicyType
		,PolicyURL							= p.PolicyURL
		,PolicyURLLabel						= p.PolicyURLLabel
		,PrimarySectionBinderType			= p.PrimarySectionBinderType
		,ProducingBrokerContact				= p.ProducingBrokerContact
		,ReinsuredParty						= p.ReinsuredParty
		,RenewingPolicy						= p.RenewingPolicy
		,RiskType                           = p.RiskType
		,RunOffDate							= p.RunOffDate
		,ServiceCompanyLocation				= p.ServiceCompanyLocation
		,SourceSystemInsuredId				= p.SourceSystemInsuredId
		,TaxPercentage						= p.TaxPercentage
		,TriaPercentage						= p.TriaPercentage
		,UPIFlag							= p.UPIFlag
		,UniqueMarketReference				= p.UniqueMarketReference
		,USMiscMedLifeSciencesPolicyCOBCode = p.USMiscMedLifeSciencesPolicyCOBCode
		,USMiscMedLifeSciencesPolicyCOB		= p.USMiscMedLifeSciencesPolicyCOB
		,FK_AccountingCalendar				= ISNULL(p.FK_AccountingCalendar, 0)
		,FK_CRMBroker						= ISNULL(p.FK_CRMBroker					  , 0)
		,FK_CRMProducingBroker				= ISNULL(p.FK_CRMProducingBroker		  , 0)
		,FK_PartyBrokerNoticeOfClaim		= ISNULL(p.FK_PartyBrokerNoticeOfClaim	  , 0)
		,FK_PartyBrokerPlacing				= ISNULL(p.FK_PartyBrokerPlacing		  , 0)
		,FK_PartyBrokerProducing			= ISNULL(p.FK_PartyBrokerProducing		  , 0)
		,FK_PartyBrokerServiceOfSuit		= ISNULL(p.FK_PartyBrokerServiceOfSuit	  , 0)
		,FK_PartyInsured					= ISNULL(p.FK_PartyInsured				  , 0)
		,FK_QuoteFilter						= ISNULL(p.FK_QuoteFilter				  , 0)
		,FK_ServiceCompany					= ISNULL(p.FK_ServiceCompany			  , 0)
		,FK_Submission						= ISNULL(p.FK_Submission				  , 0)
		,FK_UnderwritingPlatform			= ISNULL(p.FK_UnderwritingPlatform		  , 0)
		,FK_YOA								= ISNULL(p.FK_YOA						  , 0)		
		,FK_ExpiringPolicy					= p.FK_ExpiringPolicy
		,FK_RenewingPolicy					= p.FK_RenewingPolicy
		
		,HashBytesId						= p.HashBytesId
		,AuditModifyDateTime				= p.AuditModifyDateTime
		,AuditCreateDateTime				= p.AuditCreateDateTime
		,AuditModifyDetails					= p.AuditModifyDetails

	FROM  Staging.Policy p

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Policy';

end

