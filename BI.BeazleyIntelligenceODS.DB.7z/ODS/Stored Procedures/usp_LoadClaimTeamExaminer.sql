﻿

CREATE PROCEDURE [ODS].[usp_LoadClaimTeamExaminer]
AS

IF OBJECT_ID ('tempdb..#Group') IS NOT NULL 
DROP TABLE #Group

IF OBJECT_ID ('tempdb..#Temp') IS NOT NULL 
DROP TABLE #Temp

IF OBJECT_ID ('tempdb..#CTETeam') IS NOT NULL 
DROP TABLE #CTETeam

CREATE TABLE #Temp
(
	 Code				[int]			NOT NULL
	,ParentTeamName		[varchar](255)	NULL
	,ChildTeamName		[varchar](255)	NOT NULL
)

CREATE TABLE #Group
(
	ParentTeamName		[varchar](255) NOT NULL
)

CREATE TABLE #CTETeam
(
	 ChildTeamName		[varchar](255) NOT NULL
	,ParentTeamName		[varchar](255) NULL
	,HierarchyLevel		[int]
)


--Select Hierarchy from MDS imported view
INSERT INTO #Temp
(
	 Code
	,ParentTeamName
	,ChildTeamName
)
SELECT 
	 Code				= c.Code
	,ParentTeamName		= c.ParentTeamName
	,ChildTeamName		= c.ChildTeamName 

FROM Staging_MDS.mds_staging.ClaimExaminerTeam c
WHERE ChildTeamName IS NOT NULL
--where c.ParentTeamName <> 'Group Head of Claims'

--insert nodes that are not defined ad child for other nodes - possible root nodes
INSERT INTO #Group
(
	ParentTeamName
)
SELECT
	ParentTeamName		= t.ParentTeamName		

FROM #Temp t
	
LEFT JOIN #Temp s 
ON t.ParentTEamName = s.ChildTeamName

WHERE s.ParentTeamName IS NULL

GROUP BY t.ParentTeamName
HAVING COUNT(*) > 1

--select * from #Group
--if there are more than one potential root node -> insert a virtual root node as parent for these potential nodes
IF ((SELECT COUNT(*) FROM #group) >= 1)

INSERT INTO #Temp
(
	Code
   ,ParentTeamName
   ,ChildTeamName
)

-- virtual root as parent for potential root nodes
SELECT
	 Code				= 0-- -1
	,ParentTeamName		= null--'ALL'--'Virtual Root - Team O'
	,ChildTeamName		= g.ParentTeamName

FROM #Group g
/*
UNION
-- Virtual root doesn't have parent
SELECT
	 Code				= 0
	,ParentTeamName		= ''
	,ChildTeamName		= 'Virtual Root - Team O'
*/

/*Set hierarchy level - root is always 1*/
;WITH CTETeam AS
(
    SELECT
		 ChildTeamName					= c.ChildTeamName
		,ParentTeamName					= c.ParentTeamName
		,HierarchyLevel                 = 1
    FROM #Temp c
    
	WHERE  ParentTeamName is null--= 'ALL'    -- get the root node (the one without parent)
    
	UNION ALL

    SELECT
		 ChildTeamName					= c.ChildTeamName
		,ParentTeamName					= c.ParentTeamName
		,HierarchyLevel                 = cte.HierarchyLevel + 1
    FROM #Temp  c

	INNER JOIN CTETeam cte 
	ON c.ParentTeamName = cte.ChildTeamName
)
INSERT INTO #CTETeam
		(
		 ChildTeamName
		,ParentTeamName
		,HierarchyLevel
		)
SELECT 
		 ChildTeamName
		,ParentTeamName
		,HierarchyLevel		
FROM CTETeam b


MERGE ODS.ClaimTeamExaminer AS t
USING (

	SELECT  src.PK_ClaimTeamExaminer
			, src.IsUnknownMember
			, src.TeamName
			, src.HierarchyLevel
			, src.FK_ClaimTeamExaminerParent
			, src.ParentTeamName
	FROM (
			SELECT 	 
				 PK_ClaimTeamExaminer				= CONVERT(BIGINT,HASHBYTES('SHA2_256',CAST(b.ChildTeamName AS VARCHAR(255))))	
				,IsUnknownMember					= 0
				,TeamName							= b.ChildTeamName 		
				,HierarchyLevel						= b.HierarchyLevel 
				,FK_ClaimTeamExaminerParent			= CASE
														WHEN b.ParentTeamName is null THEN null--0-- = 'ALL' then -1
														ELSE CONVERT(BIGINT,HASHBYTES('SHA2_256',CAST(b.ParentTeamName AS VARCHAR(255))))
													  END
				,ParentTeamName						= b.ParentTeamName	

			FROM #CTETeam b

			UNION
	
   			SELECT
				[PK_ClaimTeamExaminer]			= 0
				,[IsUnknownMember]				= 1
				,[TeamName]						= 'N/A'
				,[HierarchyLevel]				= 0
				,[FK_ClaimTeamExaminerParent]	= null		
				,[ParentTeamName]				= null
			) src
			LEFT OUTER JOIN ODS.ClaimTeamExaminer ct ON ct.PK_ClaimTeamExaminer = src.PK_ClaimTeamExaminer
			WHERE  ct.PK_ClaimTeamExaminer IS NULL
			       OR (	 
						ct.IsUnknownMember					<> src.IsUnknownMember
						OR ct.TeamName	 					<> src.TeamName
						OR ct.HierarchyLevel 				<> src.HierarchyLevel
						OR ct.FK_ClaimTeamExaminerParent 	<> src.FK_ClaimTeamExaminerParent
						OR ct.ParentTeamName				<> src.ParentTeamName
						)
	
		) AS s
		(
			 PK_ClaimTeamExaminer
			,IsUnknownMember
			,TeamName
			,HierarchyLevel
			,FK_ClaimTeamExaminerParent
			,ParentTeamName
		)
		ON s.PK_ClaimTeamExaminer = t.PK_ClaimTeamExaminer
		
WHEN MATCHED THEN
UPDATE
SET  t.IsUnknownMember				= s.IsUnknownMember
	,t.TeamName	 					= s.TeamName
	,t.HierarchyLevel 				= s.HierarchyLevel
	,t.FK_ClaimTeamExaminerParent 	= s.FK_ClaimTeamExaminerParent
	,t.ParentTeamName				= s.ParentTeamName
	,t.AuditModifyDateTime			= GETDATE()						
	,t.AuditModifyDetails			= 'Merge in [ODS].[ClaimTeamExaminer] table' 


WHEN NOT MATCHED BY TARGET THEN 
INSERT 
(
     PK_ClaimTeamExaminer
	,IsUnknownMember
	,TeamName
	,HierarchyLevel
	,FK_ClaimTeamExaminerParent
	,ParentTeamName
	,AuditModifyDetails
)
VALUES (
		 s.PK_ClaimTeamExaminer
		,s.IsUnknownMember
		,s.TeamName
		,s.HierarchyLevel
		,s.FK_ClaimTeamExaminerParent
		,s.ParentTeamName
		, 'New in [ODS].[ClaimTeamExaminer] table' 
		);

IF (OBJECT_ID('tempdb..#Group') IS NOT NULL)
DROP TABLE #Group

IF (OBJECT_ID('tempdb..#Temp') IS NOT NULL)
DROP TABLE #Temp

IF (OBJECT_ID('tempdb..#CTETeam') IS NOT NULL)
DROP TABLE #CTETeam;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimTeamExaminer';

