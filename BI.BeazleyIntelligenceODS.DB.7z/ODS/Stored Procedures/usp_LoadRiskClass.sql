﻿	
CREATE PROCEDURE [ODS].[usp_LoadRiskClass]
AS

SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#RiskClass') IS NOT NULL)
DROP TABLE #RiskClass

CREATE TABLE #RiskClass
(	[IsUnknownMember] [bit] DEFAULT ((0)) NULL,
	[RiskClassCode] [varchar](255) NOT NULL,
	[RiskClassName] [varchar](255) NULL,
)

/*Unknown member RiskClass */
   INSERT INTO #RiskClass
	(
		 [IsUnknownMember]
		,[RiskClassCode]
		,[RiskClassName]
	) 
	SELECT
		 [IsUnknownMember]      = 1
		,[RiskClassCode]		= 'N/A'
		,[RiskClassName]		= 'N/A'

;WITH CTE_RiskClass (RiskClassCode, RiskClassName, RowNo)
AS
(
	SELECT DISTINCT
		 RiskClassCode	= LTRIM(RTRIM(r.RiskClassCode))
		,RiskClassName	= r.RiskClassDescription
		,RowNo			= ROW_NUMBER() OVER (PARTITION BY LTRIM(RTRIM(r.RiskClassCode)) ORDER BY r.RiskClassDescription)
	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionRiskClass r
	WHERE ISNULL(r.RiskClassCode,'') <> ''
	
)

INSERT INTO #RiskClass
(
	 RiskClassCode
	,RiskClassName
)
SELECT 
	 RiskClassCode	= r.RiskClassCode
	,RiskClassName	= r.RiskClassName
FROM CTE_RiskClass r
WHERE r.RowNo = 1

MERGE ODS.RiskClass AS TARGET

USING #RiskClass AS SOURCE

 ON TARGET.RiskClassCode    = SOURCE.RiskClassCode

WHEN MATCHED THEN

UPDATE SET 
  
  TARGET.IsUnknownMember                = SOURCE.IsUnknownMember
 ,TARGET.RiskClassCode                  = SOURCE.RiskClassCode
 ,TARGET.RiskClassName                  = SOURCE.RiskClassName
 ,TARGET.AuditModifyDateTime            = GETDATE()
 ,TARGET.AuditModifyDetails             = 'Merge in [ODS].[RiskClass] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     IsUnknownMember
	,RiskClassCode
	,RiskClassName
	,AuditModifyDetails

)
VALUES
(
     SOURCE.IsUnknownMember
	,SOURCE.RiskClassCode
	,SOURCE.RiskClassName
	,'New in [ODS].[RiskClass] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#RiskClass') IS NOT NULL)
DROP TABLE #RiskClass;


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'RiskClass';