﻿CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_PMD]
AS

   ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   -- PMD, syndicates: 6050 and 6107
   -- The proposed approach is to use the MDS to capture the rules and logic used to identify which policies are included within each SPA syndicate number. 
   -- The approach needs to be flexible to allow the ability for the user to update new SPA syndicate numbers within the MDS and for these new SPA?s to be updated within the ODS without additional development coding.
   -- Rules
   -- Rule 1: The new ODS.SectionSPA needs to be cleared out before any BI load
   -- Rule 2: When the checked section YOA, TriFocus, Product, MarketSegment and ReinsuranceIndicator match a row within the logic in the MDS mapping table,
   --		  add a new row in the ODS.SectionSPA table entering the FK_Section and populating the rest of the values (SPASyndicate Number & SPASyndicateMultiplier).
   --		  If the MDS column is blank = not applicable
   -- Rule 3: One single section can match multiple rows in the MDS mapping table (one to many) 
   --		  If this happens add the foreign key section as per the number of matches and display each matched SPASyndicateNumber and SPASyndicateMultiplier
   ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

   ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   -- STEP 1: Create #PolicySection table and populate with data; columns included: FK_Section, YOA, TriFocusName, Product, MarketSegmentCode, ReinsuranceIndicator;
   -- STEP 2: Create #SPASyndicateMultiplier table and populate with data from Staging_MDS.MDS_Staging.SPASyndicateMultiplier; 
   -- STEP 3: Create #SectionSPA(FK_Section, SPASyndicateNumber, SPASyndicateMultiplier) and populate with data according to mapping rules for 6050 and 6107 syndicates;
   -- STEP 4: Insert into ODS.SectionSPA table data from #SectionSPA.
   ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


IF OBJECT_ID('tempdb..#PolicySection') IS NOT NULL
DROP TABLE #PolicySection

IF OBJECT_ID('tempdb..#SPASyndicateMultiplier') IS NOT NULL
DROP TABLE #SPASyndicateMultiplier

IF OBJECT_ID('tempdb..#SectionSPA') IS NOT NULL
DROP TABLE #SectionSPA


CREATE TABLE #PolicySection
(
    FK_Section					bigint				NOT NULL
    ,YOA						bigint				NOT NULL
	,TriFocusName				varchar(255)        NOT NULL
	,Product					varchar(255)        NULL
	,MarketSegmentCode			varchar(255)        NULL
	,ReinsuranceIndicator		varchar(255)        NULL
)

INSERT INTO #PolicySection
(
    FK_Section
    ,YOA
	,TriFocusName
	,Product
	,MarketSegmentCode
	,ReinsuranceIndicator
)

SELECT
FK_Section				= s.PK_Section
,YOA					= p.FK_YOA
,TriFocusName			= tf.TriFocusName
,Product				= s.Product
,MarketSegmentCode		= p.MarketSegmentCode
,ReinsuranceIndicator	= s.ReinsuranceIndicator

FROM
ODS.Policy p

INNER JOIN ODS.Section s
ON p.PK_Policy = s.FK_Policy

INNER JOIN ODS.TriFocus tf
ON s.FK_TriFocus = tf.PK_TriFocus

CREATE TABLE #SPASyndicateMultiplier
(
    SPASyndicateNumber			bigint				NOT NULL
    ,YOA						bigint				NOT NULL
	,TriFocusLogic				varchar(255)        NOT NULL
	,TriFocus					varchar(255)        NOT NULL
	,Product					varchar(255)        NULL
	,MarketSegment				varchar(255)        NULL
	,RIIndicator				varchar(255)        NULL
	,SPASyndicateMultiplier		numeric(19,12)		NOT NULL
)

INSERT INTO #SPASyndicateMultiplier
(
    SPASyndicateNumber
    ,YOA
	,TriFocusLogic
	,TriFocus
	,Product
	,MarketSegment
	,RIIndicator
	,SPASyndicateMultiplier
)

SELECT
SPASyndicateNumber				= spa.SPASyndicateNumber
,YOA				            = spa.YOA
,TriFocusLogic					= spa.TriFocusLogic
,TriFocus						= spa.TriFocus
,Product						= spa.Product
,MarketSegment					= spa.MarketSegment
,RIIndicator					= spa.RIIndicator
,SPASyndicateMultiplier			= spa.SPASyndicateMultiplier

FROM
Staging_MDS.MDS_Staging.SPASyndicateMultiplier spa
WHERE SPASyndicateNumber    IS NOT NULL
AND YOA					    IS NOT NULL 
AND TriFocusLogic		    IS NOT NULL
AND TriFocus				IS NOT NULL
AND SPASyndicateMultiplier  IS NOT NULL


CREATE TABLE #SectionSPA
(
    FK_Section					bigint				NOT NULL
    ,SPASyndicateNumber			bigint				NOT NULL
	,SPASyndicateMultiplier		numeric(19,12)		NOT NULL
)

INSERT INTO #SectionSPA
(
    FK_Section
    ,SPASyndicateNumber
	,SPASyndicateMultiplier
)

SELECT 
FK_Section					= ps.FK_Section
,SPASyndicateNumber			= spa.SPASyndicateNumber
,SPASyndicateMultiplier		= spa.SPASyndicateMultiplier

FROM 
#PolicySection ps

INNER JOIN #SPASyndicateMultiplier spa
ON ps.YOA = spa.YOA
AND ps.TriFocusName = spa.TriFocus
AND (spa.Product IS NULL OR ps.Product = spa.Product)
AND (spa.MarketSegment IS NULL OR ps.MarketSegmentCode = spa.MarketSegment)
AND (spa.RIIndicator IS NULL OR ps.ReinsuranceIndicator = spa.RIIndicator)

WHERE
spa.TriFocusLogic = 'IN'

UNION ALL

SELECT
FK_Section					= ps.FK_Section
,SPASyndicateNumber			= spa.SPASyndicateNumber
,SPASyndicateMultiplier		= spa.SPASyndicateMultiplier

FROM
#PolicySection ps

INNER JOIN #SPASyndicateMultiplier spa
ON ps.YOA = spa.YOA
AND ps.TriFocusName	<> spa.TriFocus
AND (spa.Product IS NULL OR ps.Product = spa.Product)
AND (spa.MarketSegment IS NULL OR ps.MarketSegmentCode = spa.MarketSegment)
AND (spa.RIIndicator IS NULL OR ps.ReinsuranceIndicator = spa.RIIndicator)

WHERE
spa.TriFocusLogic = 'NOT IN'

MERGE ODS.SectionSPA AS TARGET

USING #SectionSPA AS SOURCE

 ON TARGET.FK_Section         = SOURCE.FK_Section
AND TARGET.SPASyndicateNumber = SOURCE.SPASyndicateNumber

WHEN MATCHED THEN

UPDATE SET 
 TARGET.FK_Section                 = SOURCE.FK_Section
,TARGET.SPASyndicateNumber         = SOURCE.SPASyndicateNumber
,TARGET.SPASyndicateMultiplier     = SOURCE.SPASyndicateMultiplier
,TARGET.AuditModifyDateTime        = GETDATE()						
,TARGET.AuditModifyDetails	       = 'Merge in [ODS].[SectionSPA] table' 

WHEN NOT MATCHED BY SOURCE THEN DELETE

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 FK_Section
    ,SPASyndicateNumber
	,SPASyndicateMultiplier
	,AuditModifyDetails
)
VALUES
(
 SOURCE.FK_Section
,SOURCE.SPASyndicateNumber
,SOURCE.SPASyndicateMultiplier
,'New in [ODS].[SectionSPA] table' 
);

IF OBJECT_ID('tempdb..#PolicySection') IS NOT NULL
DROP TABLE #PolicySection

IF OBJECT_ID('tempdb..#SPASyndicateMultiplier') IS NOT NULL
DROP TABLE #SPASyndicateMultiplier

IF OBJECT_ID('tempdb..#SectionSPA') IS NOT NULL
DROP TABLE #SectionSPA