﻿
CREATE PROCEDURE [ODS].[usp_LoadSlipLineNumber]
AS

SET NOCOUNT ON

	DECLARE		@LastAuditDate DATETIME2(7)

	SELECT		@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime))
	FROM		ODS.SlipLineNumber

	SET			@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


	DELETE		sln
	FROM		ODS.SlipLineNumber sln
	LEFT JOIN	BeazleyIntelligenceDataContract.Outbound.vw_ClaimMovementLine claimmov
	ON			sln.PK_SlipLineNumber = claimmov.SlipLineNumber 
	WHERE		claimmov.SlipLineNumber IS NULL


	;MERGE	ODS.SlipLineNumber	AS TARGET
			USING
			(
				SELECT	DISTINCT 
						PK_SlipLineNumber	= claimmov.SlipLineNumber 
				FROM	BeazleyIntelligenceDataContract.Outbound.vw_ClaimMovementLine AS claimmov
				WHERE	claimmov.SlipLineNumber <> 0
					AND	claimmov.SourceSystem = 'ClaimCenter'
					AND	(claimmov.AuditCreateDatetime > @LastAuditDate OR claimmov.AuditModifyDatetime > @LastAuditDate)

				UNION
			
				SELECT	PK_SlipLineNumber	= 0
			)					
			AS SOURCE

			ON	SOURCE.PK_SlipLineNumber = TARGET.PK_SlipLineNumber

	/*WHEN MATCHED statement not needed*/ 

	WHEN	NOT MATCHED BY TARGET THEN
			INSERT
			(
				PK_SlipLineNumber
				,AuditCreateDateTime
				,AuditModifyDetails
			)
			VALUES
			(
				SOURCE.PK_SlipLineNumber
				,GETDATE()
				,'New add in ODS.usp_LoadSlipLineNumber'	
			)
	;