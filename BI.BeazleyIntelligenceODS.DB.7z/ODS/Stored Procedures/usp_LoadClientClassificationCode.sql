﻿


CREATE PROCEDURE [ODS].[usp_LoadClientClassificationCode]
AS

SET NOCOUNT ON

DROP TABLE IF EXISTS #ClientClassification

CREATE TABLE #ClientClassification(
	[IsUnknownMember]					[bit] NOT NULL DEFAULT (0),
	[ClientClassificationCode]			[varchar](255) NULL,
	[ClientClassification]				[varchar](255) NULL,
	)

INSERT INTO #ClientClassification
(
	 ClientClassificationCode
	,ClientClassification
)
SELECT 	
		 ClientClassificationCode	= acc.AccountClassificationCode
		,ClientClassification		= acc.AccountClassificationShortDescription
FROM 
		Staging_MDS.dbo.vw_account_classification_codes acc	

INSERT INTO #ClientClassification
(
	 ClientClassificationCode
	,ClientClassification
)			
SELECT 	
		 ClientClassificationCode	= rdu.SourceValue
		 ,ClientClassification		= rdu.TargetValue
FROM 

		[Staging_MDS].[MDS_Staging].[UnirisxReferenceDataSourceTarget] rdu 	
WHERE rdu.entitytypeid = 8
	 AND NOT EXISTS 
			(SELECT 1 FROM #ClientClassification cc WHERE cc.ClientClassificationCode = rdu.SourceValue)


INSERT INTO #ClientClassification
(    
     IsUnknownMember
	,ClientClassificationCode
	,ClientClassification
)	
SELECT
	 IsUnkownMember 				= 1
	,ClientClassificationCode       = 'N/A' 
	,ClientClassification			= 'Not Applicable' 

MERGE ODS.ClientClassificationCode AS t
USING #ClientClassification AS s
	ON s.ClientClassificationCode = t.ClientClassificationCode
	   AND s.IsUnknownMember  = t.IsUnknownMember
		   
WHEN MATCHED THEN
UPDATE
SET  t.ClientClassification		= s.ClientClassification
	 ,t.AuditModifyDateTime		= GETDATE()						
	 ,t.AuditModifyDetails		= 'Merge in [ODS].[ClientClassificationCode] table' 

WHEN NOT MATCHED BY TARGET THEN 
INSERT 
(
     IsUnknownMember
	,ClientClassificationCode
	,ClientClassification
	,AuditModifyDetails
)
VALUES (
		 s.IsUnknownMember
		,s.ClientClassificationCode
		,s.ClientClassification
		,'New add in [ODS].[ClientClassificationCode] table'
		);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClientClassificationCode';
		   