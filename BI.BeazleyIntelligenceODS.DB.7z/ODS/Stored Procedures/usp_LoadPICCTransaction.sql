﻿
CREATE PROCEDURE [ODS].[usp_LoadPICCTransaction]
AS

SET NOCOUNT ON

DECLARE	@LastAuditDate DATETIME2(7)

SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.PICCTransaction

SET	@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF (OBJECT_ID('tempdb..#PICCTransaction') IS NOT NULL)
DROP TABLE #PICCTransaction

CREATE TABLE #PICCTransaction
(
    [PICCPeriodId] [int] NOT NULL,
	[PICCPeriod] [varchar](255) NOT NULL,
	[PICCAmountInOriginalCCY] [numeric](19, 4) NOT NULL,
	[SortOrder] [int] NOT NULL,
	[FK_Section] [bigint] NOT NULL,
	[FK_Date] [datetime] NOT NULL,
	[FK_YOA] [bigint] NOT NULL,
	[FK_SettlementCurrency] [bigint] NOT NULL,
	[FK_OriginalCurrency] [bigint] NOT NULL,
	[FK_LocalCurrency] [bigint] NOT NULL,
	[FK_TriFocus] [bigint] NOT NULL,
	[FK_Policy] [bigint] NOT NULL,
	[FK_HiddenStatusFilter] [bigint] NOT NULL,
	[FK_QuoteFilter] [bigint] NOT NULL,
	[FK_CRMBroker] [bigint] NOT NULL,
	[SpecialPurposeSyndicateApplies] [bit] NOT NULL,
	[FK_UnderwritingPlatform] [bigint] NOT NULL,
	[FK_InternalWrittenBinderStatus] [bigint] NOT NULL,
	[FK_ServiceCompany] [bigint] NOT NULL,
)

            
INSERT INTO #PICCTransaction
(
    FK_Section
    ,PICCPeriodID
    ,PICCPeriod
    ,PICCAmountInOriginalCCY
    ,SortOrder
    ,FK_Date
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_YOA
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,SpecialPurposeSyndicateApplies
	,FK_LocalCurrency
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
)
SELECT
FK_Section                      = s.PK_Section
,PICCPeriodId                   = picc.ID
,PICCPeriod                     = picc.Period
,PICCAmountInOriginalCCY        = picc.Amount * ISNULL(s.BreachResponseMultiplier, 1)
,SortOrder                      = CASE
                                    WHEN LOWER(picc.Period) LIKE 'jan%' THEN 1
                                    WHEN LOWER(picc.Period) LIKE 'feb%' THEN 2
                                    WHEN LOWER(picc.Period) LIKE 'mar%' THEN 3
                                    WHEN LOWER(picc.Period) LIKE 'apr%' THEN 4
                                    WHEN LOWER(picc.Period) LIKE 'may%' THEN 5
                                    WHEN LOWER(picc.Period) LIKE 'jun%' THEN 6
                                    WHEN LOWER(picc.Period) LIKE 'jul%' THEN 7
                                    WHEN LOWER(picc.Period) LIKE 'aug%' THEN 8
                                    WHEN LOWER(picc.Period) LIKE 'sep%' THEN 9
                                    WHEN LOWER(picc.Period) LIKE 'oct%' THEN 10
                                    WHEN LOWER(picc.Period) LIKE 'nov%' THEN 11
                                    WHEN LOWER(picc.Period) LIKE 'dec%' THEN 12
                                    ELSE 99
                                  END
,FK_Date                        = s.FK_InceptionDate
,FK_SettlementCurrency          = s.FK_SettlementCurrency
,FK_OriginalCurrency            = s.FK_OriginalCurrency
,FK_TriFocus                    = s.FK_TriFocus
,FK_CRMBroker                   = s.FK_CRMBroker
,FK_YOA                         = p.FK_YOA
,FK_Policy                      = p.PK_Policy
,FK_QuoteFilter                 = s.FK_QuoteFilter
,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= s.FK_ServiceCompany
FROM
Staging_Datamart.Datamart_Staging.PICC picc
INNER JOIN
ODS.Section s ON
picc.PolicyRef = s.SectionReference
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE ISNULL(s.AuditModifyDateTime, s.AuditCreateDateTime) >= @LastAuditDate
OR ISNULL(p.AuditModifyDateTime, p.AuditCreateDateTime) >= @LastAuditDate

/*Dummy BBR sections*/
INSERT INTO #PICCTransaction
(
    FK_Section
    ,PICCPeriodID
    ,PICCPeriod
    ,PICCAmountInOriginalCCY
    ,SortOrder
    ,FK_Date
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_YOA
    ,FK_Policy
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,SpecialPurposeSyndicateApplies
	,FK_LocalCurrency
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
)
SELECT
FK_Section                      = s_bbr.PK_Section
,PICCPeriodID                   = p.PICCPeriodId
,PICCPeriod                     = p.PICCPeriod
,PICCAmountInOriginalCCY        = (p.PICCAmountInOriginalCCY / CASE WHEN s.BreachResponseMultiplier =  0 THEN 1 ELSE s.BreachResponseMultiplier END ) * s_bbr.BreachResponseMultiplier
,SortOrder                      = p.SortOrder
,FK_Date                        = p.FK_Date
,FK_SettlementCurrency          = p.FK_SettlementCurrency
,FK_OriginalCurrency            = p.FK_OriginalCurrency
,FK_TriFocus                    = p.FK_TriFocus
,FK_CRMBroker                   = p.FK_CRMBroker
,FK_YOA                         = p.FK_YOA
,FK_Policy                      = p.FK_Policy
,FK_QuoteFilter                 = p.FK_QuoteFilter
,FK_HiddenStatusFilter          = p.FK_HiddenStatusFilter
,SpecialPurposeSyndicateApplies = p.SpecialPurposeSyndicateApplies
,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
,FK_UnderwritingPlatform		= p.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= p.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= p.FK_ServiceCompany
FROM
#PICCTransaction p
INNER JOIN
ODS.Section s ON
p.FK_Section = s.PK_Section
INNER JOIN
ODS.Section s_bbr ON
s_bbr.FK_BreachResponseParentSection = s.PK_Section
WHERE ISNULL(s.AuditModifyDateTime, s.AuditCreateDateTime) >= @LastAuditDate

DELETE FROM ODS.PICCTransaction WHERE FK_Section NOT IN (SELECT PK_Section FROM ODS.Section)

MERGE ODS.PICCTransaction AS TARGET

USING #PICCTransaction AS SOURCE

 ON TARGET.PICCPeriodId    = SOURCE.PICCPeriodId
AND TARGET.FK_Section      = SOURCE.FK_Section

WHEN MATCHED THEN

UPDATE SET 

  TARGET.PICCPeriodId                   = SOURCE.PICCPeriodId
 ,TARGET.PICCPeriod                     = SOURCE.PICCPeriod
 ,TARGET.PICCAmountInOriginalCCY        = SOURCE.PICCAmountInOriginalCCY
 ,TARGET.SortOrder                      = SOURCE.SortOrder
 ,TARGET.FK_Section                     = SOURCE.FK_Section
 ,TARGET.FK_Date                        = SOURCE.FK_Date
 ,TARGET.FK_YOA                         = SOURCE.FK_YOA
 ,TARGET.FK_SettlementCurrency          = SOURCE.FK_SettlementCurrency
 ,TARGET.FK_OriginalCurrency            = SOURCE.FK_OriginalCurrency
 ,TARGET.FK_LocalCurrency               = SOURCE.FK_LocalCurrency
 ,TARGET.FK_TriFocus                    = SOURCE.FK_TriFocus
 ,TARGET.FK_Policy                      = SOURCE.FK_Policy
 ,TARGET.FK_HiddenStatusFilter          = SOURCE.FK_HiddenStatusFilter
 ,TARGET.FK_QuoteFilter                 = SOURCE.FK_QuoteFilter
 ,TARGET.FK_CRMBroker                   = SOURCE.FK_CRMBroker
 ,TARGET.SpecialPurposeSyndicateApplies = SOURCE.SpecialPurposeSyndicateApplies
 ,TARGET.FK_UnderwritingPlatform        = SOURCE.FK_UnderwritingPlatform
 ,TARGET.FK_InternalWrittenBinderStatus = SOURCE.FK_InternalWrittenBinderStatus
 ,TARGET.FK_ServiceCompany              = SOURCE.FK_ServiceCompany
 ,TARGET.AuditModifyDateTime            = GETDATE()
 ,TARGET.AuditModifyDetails             = 'Merge in [ODS].[PICCTransaction] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
	 PICCPeriodId
	,PICCPeriod
	,PICCAmountInOriginalCCY
	,SortOrder
	,FK_Section
	,FK_Date
	,FK_YOA
	,FK_SettlementCurrency
	,FK_OriginalCurrency
	,FK_LocalCurrency
	,FK_TriFocus
	,FK_Policy
	,FK_HiddenStatusFilter
	,FK_QuoteFilter
	,FK_CRMBroker
	,SpecialPurposeSyndicateApplies
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
	,AuditModifyDetails

)
VALUES
(
	 SOURCE.PICCPeriodId
	,SOURCE.PICCPeriod
	,SOURCE.PICCAmountInOriginalCCY
	,SOURCE.SortOrder
	,SOURCE.FK_Section
	,SOURCE.FK_Date
	,SOURCE.FK_YOA
	,SOURCE.FK_SettlementCurrency
	,SOURCE.FK_OriginalCurrency
	,SOURCE.FK_LocalCurrency
	,SOURCE.FK_TriFocus
	,SOURCE.FK_Policy
	,SOURCE.FK_HiddenStatusFilter
	,SOURCE.FK_QuoteFilter
	,SOURCE.FK_CRMBroker
	,SOURCE.SpecialPurposeSyndicateApplies
	,SOURCE.FK_UnderwritingPlatform
	,SOURCE.FK_InternalWrittenBinderStatus
	,SOURCE.FK_ServiceCompany
	,'New in [ODS].[PICCTransaction] table' 
);

IF (OBJECT_ID('tempdb..#PICCTransaction') IS NOT NULL)
DROP TABLE #PICCTransaction;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'PICCTransaction';
GO


