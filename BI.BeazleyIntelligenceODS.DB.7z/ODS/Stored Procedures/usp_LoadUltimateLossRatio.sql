﻿CREATE PROCEDURE [ODS].[usp_LoadUltimateLossRatio]
AS BEGIN
    SET NOCOUNT ON

    DECLARE     @LastAuditDate DATETIME2(7)

    SELECT      @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
    FROM        ODS.UltimateLossRatio

    SET         @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01');


    MERGE       ODS.UltimateLossRatio AS TARGET
	USING	    (
                    SELECT      GroupId                        = DENSE_RANK() OVER (ORDER BY x.FK_YOA, x.FK_Syndicate, x.FK_TriFocus, x.FK_SettlementCurrency, x.FK_SpecialCategoryCatastrophe, x.FK_SpecialCategorySection)
                                ,FK_YOA                         = x.FK_YOA
                                ,FK_Syndicate                   = x.FK_Syndicate
                                ,FK_TriFocus                    = x.FK_TriFocus
                                ,FK_DevelopmentPeriod           = x.FK_DevelopmentPeriod
                                ,FK_SettlementCurrency          = x.FK_SettlementCurrency
                                ,FK_SpecialCategoryCatastrophe  = x.FK_SpecialCategoryCatastrophe
                                ,FK_SpecialCategorySection      = x.FK_SpecialCategorySection
                                ,GrossUltimatePremiumPosition   = x.GrossUltimatePremiumPosition
                                ,GrossUltimateIncurredPosition  = x.GrossUltimateIncurredPosition
                    FROM        (
                                        SELECT      FK_YOA                             = yoa.PK_YOA
                                                    ,FK_Syndicate                       = s.PK_Syndicate
                                                    ,FK_TriFocus                        = tf.PK_TriFocus
                                                    ,FK_DevelopmentPeriod               = d.PK_DevelopmentPeriod
                                                    ,FK_SettlementCurrency              = sc.PK_SettlementCurrency
                                                    ,FK_SpecialCategoryCatastrophe      = ISNULL(spec_cat.PK_SpecialCategoryCatastrophe, 0)
                                                    ,FK_SpecialCategorySection          = ISNULL(spec_sec.PK_SpecialCategorySection, 0)
                                                    ,DevelopmentMonth                   = d.DevelopmentMonth
                                                    ,GrossUltimatePremiumPosition       = SUM(ulr.Gross_Prem * 1E6)
                                                    ,GrossUltimateIncurredPosition      = SUM(ulr.Gross_ULI * 1E6)
                                        FROM        Staging_ULR.ULR_Staging.vwUwerEst ulr
                                        INNER JOIN  ODS.TriFocus tf 
                                                ON  ulr.Triangle_group COLLATE Latin1_General_CI_AS = tf.TriFocusName
                                        INNER JOIN  ODS.SettlementCurrency sc 
                                                ON  ulr.CCY COLLATE Latin1_General_CI_AS = sc.CurrencyCode
                                        INNER JOIN  ODS.YOA yoa 
                                                ON  ulr.[Year] = yoa.PK_YOA
                                        INNER JOIN  ODS.Syndicate s 
                                                ON  ulr.Synd = s.SyndicateNumber
                                        INNER JOIN  ODS.DevelopmentPeriod d 
                                                ON  ulr.[Month] = d.DevelopmentMonth
                                        LEFT JOIN   ODS.SpecialCategoryCatastrophe spec_cat 
                                                ON  ulr.Special COLLATE Latin1_General_CI_AS = spec_cat.SpecialCategory
                                        LEFT JOIN   ODS.SpecialCategorySection spec_sec 
                                                ON  ulr.Special COLLATE Latin1_General_CI_AS = spec_sec.SpecialCategory
                                        WHERE       (ulr.Gross_Prem <> 0 OR ulr.Gross_ULI <> 0)
                                        GROUP BY    yoa.PK_YOA
                                                    ,s.PK_Syndicate
                                                    ,tf.PK_TriFocus
                                                    ,d.PK_DevelopmentPeriod
                                                    ,sc.PK_SettlementCurrency
                                                    ,ISNULL(spec_cat.PK_SpecialCategoryCatastrophe, 0)
                                                    ,ISNULL(spec_sec.PK_SpecialCategorySection, 0)
                                                    ,d.DevelopmentMonth
                    ) x
    ) AS source   ON    target.FK_YOA                           = source.FK_YOA
                    AND target.FK_Syndicate                     = source.FK_Syndicate
                    AND target.FK_TriFocus                      = source.FK_TriFocus
                    AND target.FK_DevelopmentPeriod             = source.FK_DevelopmentPeriod
                    AND target.FK_SettlementCurrency            = source.FK_SettlementCurrency
                    AND target.FK_SpecialCategoryCatastrophe    = source.FK_SpecialCategoryCatastrophe
                    AND target.FK_SpecialCategorySection        = source.FK_SpecialCategorySection
    WHEN MATCHED THEN
		UPDATE SET	target.GroupId                          = source.GroupId
                    ,target.GrossUltimatePremiumPosition    = source.GrossUltimatePremiumPosition
                    ,target.GrossUltimateIncurredPosition   = source.GrossUltimateIncurredPosition
                    ,target.AuditModifyDateTime			    = GETDATE()						
					,target.AuditModifyDetails				= 'Merge in ODS.usp_LoadUltimateLossRatio proc'         
    WHEN NOT MATCHED BY TARGET THEN
	    INSERT		(  
                        GroupId, FK_YOA, FK_Syndicate, FK_TriFocus, FK_DevelopmentPeriod, FK_SettlementCurrency, FK_SpecialCategoryCatastrophe
                        ,FK_SpecialCategorySection, GrossUltimatePremiumPosition, GrossUltimateIncurredPosition
                        ,AuditCreateDateTime, AuditModifyDetails
                    )
        VALUES      (
                        source.GroupId, source.FK_YOA, source.FK_Syndicate, source.FK_TriFocus, source.FK_DevelopmentPeriod, source.FK_SettlementCurrency 
                        ,source.FK_SpecialCategoryCatastrophe, source.FK_SpecialCategorySection, source.GrossUltimatePremiumPosition, source.GrossUltimateIncurredPosition
                        ,GETDATE(), 'New add in ODS.usp_LoadUltimateLossRatio proc'	
                    )
    WHEN NOT MATCHED BY SOURCE THEN 
					DELETE
	;


END