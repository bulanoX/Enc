﻿CREATE PROC [ODS].[usp_LoadDocumentType]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.DocumentType

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE d FROM ODS.DocumentType d
WHERE DocumentTypeName NOT IN (SELECT DISTINCT DocumentType FROM BeazleyIntelligenceDataContract.Outbound.vw_Document UNION ALL SELECT DISTINCT ContentType 
FROM Staging_BeazleyDocumentsReporting.BeazleyDocumentsReporting_Staging.Documents )

MERGE ODS.DocumentType AS target
USING (		
/* Populate ods document type table from Beazley docs */ 
SELECT DISTINCT
DocumentTypeName            = d.ContentType 
FROM
Staging_BeazleyDocumentsReporting.BeazleyDocumentsReporting_Staging.Documents d
--WHERE ISNULL(ModifiedOn,CreatedOn) > @LastAuditDate

UNION

/* CIPS document type into ods type table*/
SELECT DISTINCT
       DocumentTypeName = doc.DocumentType
FROM
BeazleyIntelligenceDataContract.Outbound.vw_Document doc
WHERE (doc.AuditCreateDatetime > @LastAuditDate OR doc.AuditModifyDatetime > @LastAuditDate)
AND doc.SourceSystem IN ('Unirisx', 'CIPS')
) source
ON target.DocumentTypeName = source.DocumentTypeName
WHEN MATCHED THEN UPDATE SET
target.AuditModifyDateTime	      = GETDATE()						
,target.AuditModifyDetails	      = 'Merge in ODS.usp_LoadDocumentType proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
DocumentTypeName
,AuditCreateDateTime
,AuditModifyDetails)
VALUES
(
source.DocumentTypeName
,GETDATE()
,'New add in ODS.usp_LoadDocumentType proc'	
);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'DocumentType';