﻿CREATE PROCEDURE [ODS].[usp_LoadSectionControlQuestionAnswer]
AS

SET NOCOUNT ON

	DECLARE	@LastAuditDate DATETIME2(7)
	
	SELECT @LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
	FROM ODS.SectionControlQuestionAnswer
	
	SET	@LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')	
	
	DROP TABLE IF EXISTS #SectionQuestionAnswer

	CREATE TABLE #SectionQuestionAnswer
	(
		[SectionReference] [nvarchar](255) NOT NULL,
		[QuestionSourceId] [varchar](255)  NULL,
		[QuestionType] [varchar](255) NOT NULL,
		[QuestionName] [varchar](1600) NULL,
		[Answer] [nvarchar](max) NULL	
	) 

	DROP TABLE IF EXISTS #Section

	CREATE TABLE #Section
	(
		[PK_Section] [bigint] NOT NULL,
		[SectionReference] [varchar](255) NOT NULL,
		[FK_Policy] [bigint] NOT NULL,
		[FK_UnderwritingPlatform] [bigint] NOT NULL,
		[FK_InternalWrittenBinderStatus] [bigint] NOT NULL,
		[FK_ServiceCompany] [bigint] NOT NULL,
		[FK_LocalCurrency] [bigint] NULL,
		[FK_SettlementCurrency] [bigint] NOT NULL,
		[FK_OriginalCurrency] [bigint] NOT NULL,
		[FK_TriFocus] [bigint] NOT NULL,
		[FK_CRMBroker] [bigint] NOT NULL,
		[FK_QuoteFilter] [bigint] NOT NULL,
		[FK_HiddenStatusFilter] [bigint] NOT NULL,
		[SpecialPurposeSyndicateApplies] [bit] NOT NULL,
		[FK_YOA] [bigint] NOT NULL,
		[SourceSystem] [varchar](255) NOT NULL		
	) 
	   	  	
	INSERT INTO #SectionQuestionAnswer
	(
		SectionReference
		,QuestionSourceId
		,QuestionType
		,QuestionName
		,Answer
	)
	SELECT
		 SectionReference			= sqa.SectionReference
		,QuestionSourceId			= IIF(sqa.SourceSystem IN ( 'Eurobase', 'myBeazley'),sqa.QuestionSourceId,NULL)
		,QuestionType				= sqa.QuestionType
		,QuestionName				= IIF(sqa.SourceSystem ='Unirisx', CAST(QuestionName AS VARCHAR(1600)),NULL)
		,Answer						= sqa.Answer	
	
	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionQuestionAnswer sqa
	WHERE sqa.SourceSystem IN ( 'Eurobase', 'myBeazley','Unirisx')
	AND ISNULL(sqa.AuditModifyDateTime, sqa.AuditCreateDateTime) >= @LastAuditDate
		
	CREATE NONCLUSTERED INDEX IX_SectionQuestionAnswerQuestionSourceId		ON #SectionQuestionAnswer (QuestionSourceId);  
	CREATE NONCLUSTERED INDEX IX_SectionQuestionAnswerQuestionName		ON #SectionQuestionAnswer (QuestionName);
	CREATE NONCLUSTERED INDEX IX_SectionQuestionAnswerSectionReference		ON #SectionQuestionAnswer (SectionReference);
		
	INSERT INTO #Section
	(
		PK_Section
		,SectionReference
		,FK_Policy
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,FK_ServiceCompany
		,FK_LocalCurrency			
		,FK_SettlementCurrency
		,FK_OriginalCurrency
		,FK_TriFocus
		,FK_CRMBroker
		,FK_QuoteFilter
		,FK_HiddenStatusFilter
		,SpecialPurposeSyndicateApplies	
		,FK_YOA
		,SourceSystem		
	)

	
	SELECT
		 PK_Section							= s.PK_Section
		,SectionReference					= s.SectionReference
		,FK_Policy							= s.FK_Policy
		,FK_UnderwritingPlatform			= s.FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus		= s.FK_InternalWrittenBinderStatus
		,FK_ServiceCompany					= s.FK_ServiceCompany
		,FK_LocalCurrency					= s.FK_LocalCurrency			
		,FK_SettlementCurrency				= s.FK_SettlementCurrency
		,FK_OriginalCurrency				= s.FK_OriginalCurrency
		,FK_TriFocus						= s.FK_TriFocus
		,FK_CRMBroker						= s.FK_CRMBroker
		,FK_QuoteFilter						= s.FK_QuoteFilter
		,FK_HiddenStatusFilter				= s.FK_HiddenStatusFilter
		,SpecialPurposeSyndicateApplies		= s.SpecialPurposeSyndicateApplies	
		,FK_YOA								= p.FK_YOA
		,SourceSystem						= p.SourceSystem		
	FROM ODS.Section s
	INNER JOIN ODS.Policy p
	ON s.FK_Policy = p.PK_Policy
	WHERE p.sourcesystem in ('Eurobase', 'myBeazley', 'Unirisx')
	AND s.SectionReference IN (SELECT SectionReference FROM #SectionQuestionAnswer )

CREATE NONCLUSTERED INDEX IX_SectionSectionReference		ON #Section (SectionReference, SourceSystem);
	
IF (OBJECT_ID('tempdb..#SectionControlQuestionAnswer') IS NOT NULL)
DROP TABLE #SectionControlQuestionAnswer
	
	CREATE TABLE #SectionControlQuestionAnswer
	(
    [PK_SectionControlQuestionAnswer]       [varchar](255) NULL,
	[StringAnswer]                          [varchar](max) NULL,
	[IntAnswer]                             [int] NULL,
	[NumericAnswer]                         [decimal](38, 16) NULL,
	[DateAnswer]                            [datetime] NULL,
	[AnswerCount]                           [int] NOT NULL,
	[FK_Section]                            [bigint] NOT NULL,
	[FK_TriFocus]                           [bigint] NOT NULL,
	[FK_ControlQuestion]                    [bigint] NOT NULL,
	[FK_YOA]                                [bigint] NOT NULL,
	[FK_SettlementCurrency]                 [bigint] NOT NULL,
	[FK_OriginalCurrency]                   [bigint] NOT NULL,
	[FK_LocalCurrency]                      [bigint] DEFAULT ((0)) NOT NULL,
	[FK_HiddenStatusFilter]                 [bigint] NOT NULL,
	[FK_QuoteFilter]                        [bigint] NOT NULL,
	[FK_Policy]                             [bigint] NOT NULL,
	[FK_CRMBroker]                          [bigint] NOT NULL,
	[SpecialPurposeSyndicateApplies]        [bit] NOT NULL,
	[SectionControlQuestionAnswerCombined]  [varchar](max) NULL,
	[ContractCertaintyAnswerCode]           [int] NULL,
	[FK_UnderwritingPlatform]               [bigint] NOT NULL,
	[FK_InternalWrittenBinderStatus]        [bigint] NOT NULL,
	[FK_ServiceCompany]                     [bigint] NOT NULL
	)
	
	INSERT INTO #SectionControlQuestionAnswer
	(
		FK_Section
		,FK_ControlQuestion
		,FK_YOA
		,FK_SettlementCurrency
		,FK_OriginalCurrency
		,FK_TriFocus
		,FK_CRMBroker
		,FK_QuoteFilter
		,FK_HiddenStatusFilter
		,FK_Policy
		,SpecialPurposeSyndicateApplies
		,IntAnswer
		,StringAnswer
		,NumericAnswer
		,DateAnswer
		,AnswerCount
		,ContractCertaintyAnswerCode
		,FK_LocalCurrency
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,FK_ServiceCompany
	)
	SELECT DISTINCT
		FK_Section                      = s.PK_Section
		,FK_ControlQuestion             = cq.PK_ControlQuestion
		,FK_YOA                         = s.FK_YOA
		,FK_SettlementCurrency          = s.FK_SettlementCurrency
		,FK_OriginalCurrency            = s.FK_OriginalCurrency
		,FK_TriFocus                    = s.FK_TriFocus
		,FK_CRMBroker                   = s.FK_CRMBroker
		,FK_QuoteFilter                 = s.FK_QuoteFilter
		,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
		,FK_Policy                      = s.FK_Policy
		,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
		,IntAnswer                      = NULL 
		,StringAnswer                   = CASE
											WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																									CASE 
																										WHEN sqa.Answer = 'Y' THEN 'Y'
																										WHEN sqa.Answer = 'N' THEN 'N'
																										WHEN sqa.Answer = 'X' THEN 'N/A'
																										ELSE ''
																									END
											WHEN cqt.ControlQuestionType= 'Rationale' THEN Utility.udf_ProcessString(sqa.Answer, 1)
											ELSE NULL
										END
		,NumericAnswer                  = CASE
												WHEN cqt.ControlQuestionType = 'Rate Change'  THEN 1 / Utility.udf_ProcessPercentage(sqa.Answer, 0, 0, 1)
											
											END
		,DateAnswer                     = NULL
		,AnswerCount                    = CASE
												WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																							CASE 
																								WHEN sqa.Answer = 'Y' THEN 1 
																								ELSE 0 
																							END
												ELSE 1
											END
		,ContractCertaintyAnswerCode    = CASE
												WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																							CASE 
																								WHEN sqa.Answer = 'Y' THEN 1
																								WHEN sqa.Answer = 'N' THEN 2
																								WHEN sqa.Answer = 'X' THEN 3
																								ELSE 4
																							  END
												ELSE NULL
											END
		,FK_LocalCurrency				= ISNULL(s.FK_LocalCurrency,0)
		,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
		,FK_ServiceCompany				= s.FK_ServiceCompany
	
	FROM #SectionQuestionAnswer sqa

	INNER JOIN ODS.ControlQuestionType cqt 
	ON cqt.ControlQuestionType = sqa.QuestionType

	INNER JOIN #Section s 
	ON sqa.SectionReference = s.SectionReference

	INNER JOIN ODS.ControlQuestion cq 
	ON sqa.QuestionSourceId = cq.QuestionNumber
	AND cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
	WHERE s.sourcesystem in ('Eurobase', 'myBeazley') 
	

	/** Unirisk Control Questions **/

INSERT INTO #SectionControlQuestionAnswer
	(
		FK_Section
		,FK_ControlQuestion
		,FK_YOA
		,FK_SettlementCurrency
		,FK_OriginalCurrency
		,FK_TriFocus
		,FK_CRMBroker
		,FK_QuoteFilter
		,FK_HiddenStatusFilter
		,FK_Policy
		,SpecialPurposeSyndicateApplies
		,IntAnswer
		,StringAnswer
		,NumericAnswer
		,DateAnswer
		,AnswerCount
		,ContractCertaintyAnswerCode
		,FK_LocalCurrency
		,FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus
		,FK_ServiceCompany
	)
	--- Contract Certainty and Rate Change
	SELECT DISTINCT
		 FK_Section                     = sec.PK_Section
		,FK_ControlQuestion             = cq.PK_ControlQuestion
		,FK_YOA                         = sec.FK_YOA
		,FK_SettlementCurrency          = sec.FK_SettlementCurrency
		,FK_OriginalCurrency            = sec.FK_OriginalCurrency
		,FK_TriFocus                    = sec.FK_TriFocus
		,FK_CRMBroker                   = sec.FK_CRMBroker
		,FK_QuoteFilter                 = sec.FK_QuoteFilter
		,FK_HiddenStatusFilter          = sec.FK_HiddenStatusFilter
		,FK_Policy                      = sec.FK_Policy
		,SpecialPurposeSyndicateApplies = sec.SpecialPurposeSyndicateApplies
		,IntAnswer                      = NULL 
		,StringAnswer                   = CASE
												WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN sqa.Answer																									
												ELSE NULL
										   END
		,NumericAnswer                  =  CASE
												WHEN cqt.ControlQuestionType = 'Rate Change' THEN sqa.Answer
												ELSE NULL
										   END
		,DateAnswer                     = NULL 
		,AnswerCount                    = CASE
												WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																										CASE 
																											WHEN sqa.Answer = 'Y' THEN 1 
																											ELSE 0 
																										END
												ELSE 1
										  END                                    
		,ContractCertaintyAnswerCode    = CASE
												WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																										CASE 
																											WHEN sqa.Answer = 'Y' THEN 1
																											WHEN sqa.Answer = 'N'  THEN 2
																											WHEN sqa.Answer = 'N/A'  THEN 3
																											ELSE 4
																										END
												ELSE NULL
										   END
		,FK_LocalCurrency				= ISNULL(sec.FK_LocalCurrency,0)
		,FK_UnderwritingPlatform		= sec.FK_UnderwritingPlatform
		,FK_InternalWrittenBinderStatus	= sec.FK_InternalWrittenBinderStatus
		,FK_ServiceCompany				= sec.FK_ServiceCompany

	FROM #SectionQuestionAnswer sqa

	INNER JOIN ODS.ControlQuestionType cqt 
	ON cqt.ControlQuestionType = sqa.QuestionType

	INNER JOIN #Section sec 
	ON sqa.SectionReference = sec.SectionReference

	INNER JOIN ODS.ControlQuestion cq 
	ON  sqa.QuestionName = cq.ControlQuestion
	AND cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
	WHERE sec.SourceSystem ='Unirisx'


	CREATE NONCLUSTERED INDEX IX_SectionControlQuestionAnswer		ON #SectionControlQuestionAnswer (FK_Section, FK_ControlQuestion);
DELETE FROM ODS.SectionControlQuestionAnswer WHERE FK_Section NOT IN (SELECT PK_Section FROM ODS.Section)
DELETE FROM ODS.SectionControlQuestionAnswer WHERE FK_Policy NOT IN (SELECT PK_Policy FROM ODS.Policy)
DELETE FROM ODS.SectionControlQuestionAnswer WHERE FK_CRMBroker NOT IN (SELECT PK_CRMBroker FROM ODS.CRMBroker)
DELETE FROM ODS.SectionControlQuestionAnswer WHERE FK_UnderwritingPlatform NOT IN (SELECT PK_UnderwritingPlatform FROM ODS.UnderwritingPlatform)
DELETE FROM ODS.SectionControlQuestionAnswer WHERE FK_ServiceCompany NOT IN (SELECT PK_ServiceCompany FROM ODS.ServiceCompany)

MERGE ODS.SectionControlQuestionAnswer AS TARGET

USING #SectionControlQuestionAnswer AS SOURCE

 ON TARGET.FK_Section              = SOURCE.FK_Section
AND TARGET.FK_ControlQuestion      = SOURCE.FK_ControlQuestion

WHEN MATCHED THEN

UPDATE SET 

 TARGET.StringAnswer                            = SOURCE.StringAnswer                          
,TARGET.IntAnswer                               = SOURCE.IntAnswer                             
,TARGET.NumericAnswer                           = SOURCE.NumericAnswer                         
,TARGET.DateAnswer                              = SOURCE.DateAnswer                            
,TARGET.AnswerCount                             = SOURCE.AnswerCount                           
,TARGET.FK_Section                              = SOURCE.FK_Section                            
,TARGET.FK_TriFocus                             = SOURCE.FK_TriFocus                           
,TARGET.FK_ControlQuestion                      = SOURCE.FK_ControlQuestion                    
,TARGET.FK_YOA                                  = SOURCE.FK_YOA                                
,TARGET.FK_SettlementCurrency                   = SOURCE.FK_SettlementCurrency                 
,TARGET.FK_OriginalCurrency                     = SOURCE.FK_OriginalCurrency                   
,TARGET.FK_LocalCurrency                        = SOURCE.FK_LocalCurrency                      
,TARGET.FK_HiddenStatusFilter                   = SOURCE.FK_HiddenStatusFilter                 
,TARGET.FK_QuoteFilter                          = SOURCE.FK_QuoteFilter                        
,TARGET.FK_Policy                               = SOURCE.FK_Policy                             
,TARGET.FK_CRMBroker                            = SOURCE.FK_CRMBroker                          
,TARGET.SpecialPurposeSyndicateApplies          = SOURCE.SpecialPurposeSyndicateApplies        
,TARGET.ContractCertaintyAnswerCode             = SOURCE.ContractCertaintyAnswerCode           
,TARGET.FK_UnderwritingPlatform                 = SOURCE.FK_UnderwritingPlatform               
,TARGET.FK_InternalWrittenBinderStatus          = SOURCE.FK_InternalWrittenBinderStatus        
,TARGET.FK_ServiceCompany                       = SOURCE.FK_ServiceCompany                     
,TARGET.AuditModifyDateTime                     = GETDATE()
,TARGET.AuditModifyDetails                      = 'Merge in [ODS].[SectionControlQuestionAnswer] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
 StringAnswer                          
,IntAnswer                             
,NumericAnswer                         
,DateAnswer                            
,AnswerCount                           
,FK_Section                            
,FK_TriFocus                           
,FK_ControlQuestion                    
,FK_YOA                                
,FK_SettlementCurrency                 
,FK_OriginalCurrency                   
,FK_LocalCurrency                      
,FK_HiddenStatusFilter                 
,FK_QuoteFilter                        
,FK_Policy                             
,FK_CRMBroker                          
,SpecialPurposeSyndicateApplies        
,ContractCertaintyAnswerCode           
,FK_UnderwritingPlatform               
,FK_InternalWrittenBinderStatus        
,FK_ServiceCompany                     
,[AuditModifyDetails]
)
VALUES
(
 SOURCE.StringAnswer                          
,SOURCE.IntAnswer                             
,SOURCE.NumericAnswer                         
,SOURCE.DateAnswer                            
,SOURCE.AnswerCount                           
,SOURCE.FK_Section                            
,SOURCE.FK_TriFocus                           
,SOURCE.FK_ControlQuestion                    
,SOURCE.FK_YOA                                
,SOURCE.FK_SettlementCurrency                 
,SOURCE.FK_OriginalCurrency                   
,SOURCE.FK_LocalCurrency                      
,SOURCE.FK_HiddenStatusFilter                 
,SOURCE.FK_QuoteFilter                        
,SOURCE.FK_Policy                             
,SOURCE.FK_CRMBroker                          
,SOURCE.SpecialPurposeSyndicateApplies        
,SOURCE.ContractCertaintyAnswerCode           
,SOURCE.FK_UnderwritingPlatform               
,SOURCE.FK_InternalWrittenBinderStatus        
,SOURCE.FK_ServiceCompany                     
,'New in [ODS].[SectionControlQuestionAnswer] table' 
);

/*
INSERT INTO ODS.SectionControlQuestionAnswer
(
    FK_Section
    ,FK_ControlQuestion
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,FK_Policy
    ,SpecialPurposeSyndicateApplies
    ,IntAnswer
    ,StringAnswer
    ,NumericAnswer
    ,DateAnswer
    ,AnswerCount
    ,ContractCertaintyAnswerCode
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
)
SELECT
	FK_Section                      = s.PK_Section
	,FK_ControlQuestion             = cq.PK_ControlQuestion
	,FK_YOA                         = p.FK_YOA
	,FK_SettlementCurrency          = s.FK_SettlementCurrency
	,FK_OriginalCurrency            = s.FK_OriginalCurrency
	,FK_TriFocus                    = s.FK_TriFocus
	,FK_CRMBroker                   = s.FK_CRMBroker
	,FK_QuoteFilter                 = s.FK_QuoteFilter
	,FK_HiddenStatusFilter          = s.FK_HiddenStatusFilter
	,FK_Policy                      = s.FK_Policy
	,SpecialPurposeSyndicateApplies = s.SpecialPurposeSyndicateApplies
	,IntAnswer                      = NULL 
	,StringAnswer                   = CASE
										WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																								CASE 
																									WHEN sqa.Answer = 'Y' THEN 'Y'
																									WHEN sqa.Answer = 'N' THEN 'N'
																									WHEN sqa.Answer = 'X' THEN 'N/A'
																									ELSE ''
																								END
										WHEN cqt.ControlQuestionType= 'Rationale' THEN Utility.udf_ProcessString(sqa.Answer, 1)
										ELSE NULL
									END
	,NumericAnswer                  = CASE
											WHEN cqt.ControlQuestionType = 'Rate Change'  THEN 1 / Utility.udf_ProcessPercentage(sqa.Answer, 0, 0, 1)
											
										END
	,DateAnswer                     = NULL
	,AnswerCount                    = CASE
											WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																						CASE 
																							WHEN sqa.Answer = 'Y' THEN 1 
																							ELSE 0 
																						END
											ELSE 1
										END
	,ContractCertaintyAnswerCode    = CASE
											WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																						CASE 
																							WHEN sqa.Answer = 'Y' THEN 1
																							WHEN sqa.Answer = 'N' THEN 2
																							WHEN sqa.Answer = 'X' THEN 3
																							ELSE 4
																						  END
											ELSE NULL
										END

	,FK_UnderwritingPlatform		= s.FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus	= s.FK_InternalWrittenBinderStatus
	,FK_ServiceCompany				= s.FK_ServiceCompany
FROM BeazleyIntelligenceDataContract.Outbound.SectionQuestionAnswer sqa

INNER JOIN ODS.ControlQuestionType cqt 
ON cqt.ControlQuestionType = sqa.QuestionType

INNER JOIN ODS.Section s 
ON sqa.SectionReference = s.SectionReference

INNER JOIN ODS.Policy p 
ON s.FK_Policy = p.PK_Policy

INNER JOIN ODS.ControlQuestion cq 
ON sqa.QuestionSourceId = cq.QuestionNumber
AND cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType

WHERE sqa.SourceSystem IN ( 'Eurobase', 'myBeazley')
	and sqa.IsActive = 1


/** Unirisk Control Questions **/

INSERT INTO ODS.SectionControlQuestionAnswer
(
    FK_Section
    ,FK_ControlQuestion
    ,FK_YOA
    ,FK_SettlementCurrency
    ,FK_OriginalCurrency
    ,FK_TriFocus
    ,FK_CRMBroker
    ,FK_QuoteFilter
    ,FK_HiddenStatusFilter
    ,FK_Policy
    ,SpecialPurposeSyndicateApplies
    ,IntAnswer
    ,StringAnswer
    ,NumericAnswer
    ,DateAnswer
    ,AnswerCount
    ,ContractCertaintyAnswerCode
    ,FK_LocalCurrency
	,FK_UnderwritingPlatform
	,FK_InternalWrittenBinderStatus
	,FK_ServiceCompany
)

--- Contract Certainty and Rate Change
SELECT
 FK_Section                     = sec.PK_Section
,FK_ControlQuestion             = cq.PK_ControlQuestion
,FK_YOA                         = pol.FK_YOA
,FK_SettlementCurrency          = sec.FK_SettlementCurrency
,FK_OriginalCurrency            = sec.FK_OriginalCurrency
,FK_TriFocus                    = sec.FK_TriFocus
,FK_CRMBroker                   = sec.FK_CRMBroker
,FK_QuoteFilter                 = sec.FK_QuoteFilter
,FK_HiddenStatusFilter          = sec.FK_HiddenStatusFilter
,FK_Policy                      = sec.FK_Policy
,SpecialPurposeSyndicateApplies = sec.SpecialPurposeSyndicateApplies
,IntAnswer                      = NULL 
,StringAnswer                   = CASE
										WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN sqa.Answer																									
										ELSE NULL
								   END
,NumericAnswer                  =  CASE
										WHEN cqt.ControlQuestionType = 'Rate Change' THEN sqa.Answer
										ELSE NULL
                                   END
,DateAnswer                     = NULL 
,AnswerCount                    = CASE
										WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																								CASE 
																								    WHEN sqa.Answer = 'Y' THEN 1 
																								    ELSE 0 
																								END
										ELSE 1
								  END                                    
,ContractCertaintyAnswerCode    = CASE
										WHEN cqt.ControlQuestionType = 'Contract Certainty' THEN 
																								CASE 
																								    WHEN sqa.Answer = 'Y' THEN 1
																								    WHEN sqa.Answer = 'N'  THEN 2
																								    WHEN sqa.Answer = 'N/A'  THEN 3
																								    ELSE 4
																								END
										ELSE NULL
                                   END
,FK_LocalCurrency				= ISNULL(sec.FK_LocalCurrency,0)
,FK_UnderwritingPlatform		= sec.FK_UnderwritingPlatform
,FK_InternalWrittenBinderStatus	= sec.FK_InternalWrittenBinderStatus
,FK_ServiceCompany				= sec.FK_ServiceCompany
FROM 
BeazleyIntelligenceDataContract.Outbound.SectionQuestionAnswer sqa

INNER JOIN ODS.ControlQuestionType cqt 
ON cqt.ControlQuestionType = sqa.QuestionType

INNER JOIN ODS.Section sec 
ON sqa.SectionReference = sec.SectionReference

INNER JOIN ODS.Policy pol 
ON sec.FK_Policy = pol.PK_Policy

INNER JOIN ODS.ControlQuestion cq 
ON  sqa.QuestionName = cq.ControlQuestion
AND cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType

WHERE sqa.SourceSystem = 'Unirisx'
	and sqa.IsActive = 1
*/