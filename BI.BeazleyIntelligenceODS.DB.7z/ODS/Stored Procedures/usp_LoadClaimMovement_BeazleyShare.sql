﻿



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_LoadClaimMovement_BeazleyShare]   
AS
BEGIN
	TRUNCATE TABLE ODS.ClaimMovement_BeazleyShare
	
	
	/***********************************************************************************************************/
	/*  ClaimMovement  

		1. DUMMY MOVEMENTS are created  only for non -SCM
		2. LocalCurrency
			- Singapore financial team uses LocalCCY and  OriginalCCYToLocalCCYRate (taken from OriginalCCYtoGroupCCYRate)
			- PK for localCCY is taken by join on SettlementCurrency
			- we need to be aware is that this field (OriginalCCYtoGroupCCYRate) has only 4 digits after the comma.
			- ODS.LocalCurrency table has 2 more values  compared with ODS.SettlementCurrency:
					a. N\A (UNKNOWN)
					b. SGD (singapore dollar)
			- all SCM have Local Currency by default N\A
		3. Multi Currency Change
			- BI code populates 
						- ActualOriginalCurrency
						- ActualOriginalAmount
						- Actual OriginalAmountType
			- BI propagates to RedCube
						- ActualOriginalCurrency					 --> does not exist in DataCOntract - managed in ODS
						- ActualOriginalAmount						 --> does not exist in DataCOntract - managed in ODS
						- Actual OriginalAmountType					 --> does not exist in DataCOntract - managed in ODS
						- [ActualToSettlementExchangeRate]			 -> pushed in dataContract by CC V9 
						- [EstimatedSettlementAmount]				 -> pushed in dataContract by CC V9 
						
			- in ODS the BI code  will do these for each claim no matter if they are of multi-currency or not (because they may at some point become multi-currency):
                                  i.      copy the OriginalCCY in ActualOriginalCCY field
								 ii.      copy the OriginalAmount in ActualOriginalAmount field
								iii.      copy the SettlementCCY in OriginalCCY field
								 iv.      copy the SettlementAmount in OriginalAmount field
                                  v.      propagate ActualOriginalCCY and ActualOriginalAmount in fact tables
			- rates [OutstandingOriginalCCYToSettlementCCYRate] and [PaidOriginalCCYToSettlementCCYRate]	are defaulted to 1
			- added field ActualOriginalAmountType with possibel values:
								- Indemnity
								- Fees
								- Defence
			- amounts in Original CCY are  equal to the ones in Settlement CCY
		4. update rates which are 0 with 1 in order not to break in ODS.PostPorcessClaimExposure or in Red.FaclClaimMovement 
		5. ToDateOutstanding... fields
			-- we calculate the ToDateOutstanding... fields for:
					-- non SCM movements from migration
					-- non SCM from UI (after go live)
					-- SCM  from UI (after go live)
			-- for SCM movements from migration we take the ToDateOutstanding... fields as pushed by CC V9
		6. MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
		7. after go live this is the way to see if the movement is for SCM or not: go to Exposure level and  check if ISNULL(ce.SCMReference, '') = '' --> non SCM
		8. CC Team to send all states of the transactions as BI flow takes only the latest
		9. Read-only claims should be sent to BI: [SCMReadOnly] flag should be set to 1 in ODS.Claim for these cases
	   10. old claims (not starting with BEAZ) were migrated into V5 from other sources and is accepted that they have data quality issues -> impact on Sequence Number
	   11. there is an accepted 5 hours delay between Eurobase and ClaimCenter V5 due to flow between them -> impact on Date fields liek MovementDate
	   12. payment marked as non erroding 
						-> in V5 reserve was not decreased by this payment. in V9 there is the assumption that every single payment is not erroding.
						- i have asked that for payments that should errode (substracted from reserve) to  receive from CC V9
											- 0 in the payment amount field 
											- information in the ClaimNarrative field about the payment amount and the fact that in V5 was marked as erroding
	   13. ODS V5 is filtering 
						- transactions on claim level 
						- transactions with claim cost category 
									- Beazley Fees 
									- Embeded...
	   14. transactions on last Mvement for each Exposure should reconcile
	 */

	 /*
		Claim
		1. SCM claims with the same policy number and UniqueClaimRerference are grouped in V9 and all the exposures attached in V5 to them will be all attached to the new created Claim
			Example V5:
							C1  - E1
							    - E2
							C2  - E3
							C3  - E4
								- E5
								- E6

				V9:  new claim created: C23
						C23 - E1
						    - E2
						    - E3
						    - E4
						    - E5
						    - E6
			
		2. in V9 all grouped claims start with BEAZG
		3. PK_Claim  has changed because is calculated from ClaimReference
		4. in V5 
				ClaimReference = SCMrefernce for SCM/ ClaimNumber for non SCM
				BeazleyCLaimReference = ClaimNumber
				SCMReference = SCMrefernce for SCM/ blank for non SCM
		5. in V9 
				ClaimReference = ClaimNumber 
				BeazleyCLaimReference = NULL
				SCMReference = SCMrefernce for SCM/ blank for non SCM

	 */

	 /*
		ClaimExposure
		1. all non SCM exposures should have the same ExposureReference and PK_ClaimExposure in both V5 and v9
		2. all SCM exposurers have different Exposure reference 
					- in V5: SCMReference + '-' + SectionSequenceId				 
					- in V9: ClaimReference  + '-' + SectionSequenceId
		2. Exposures created automatically in the migration process (only non SCM)
				- (did not exist in V5 in cc_exposure and fo the dummuy exposures were created in V5 code) should have flag HasRealExposures set to 1
				-  exception in V5: ExposureReference = ClaimReference + '-00'
		3. Exposures from grouped SCM claims have in field ThirdPartyClaimReference the ClaimReference assocaited in V5

	 */

	 /*
		ClaimExposureSection

		1. in V5 one exposure can be associated with muultiple sections and one section can be associated with multiple exposures
		2. in V9 one section can be associated to multiple exposures
		3. in V9 so far Exposure appear only once in CES table
		4. policies and  Sections with SourceSystem = 'CLaimCEnter' were mandatory to be in ODS.Section and ODS.Policy in order to identify the policy from claim level
		5. for all exposures not associated with sections teh code searches the claim and gets the policy pushed at claim level; 
				it searches the policy in ODS.Policy and it takes the first Section from that policy
		6.  is used for filling ODS.CLaimMovementLine
		7. is used to update fields in post processing at Exposure level from Section level

	 */	

	 /*
		Deletes in V5:
		1. all Claims and Exposures without Movements are deleted
		2. all Claims and Exposures for which the Exposure is not associated with a Section are deleted


		Deletes in V9:
		1. all Claims and Exposures without Movements are deleted
	 */
	/***********************************************************************************************************/

	IF (OBJECT_ID('tempdb..#ClaimMovement')) IS NOT NULL DROP TABLE #ClaimMovement

	/***********************************************************************************************************/
	/*    Create temp table to stage claims movements. This table will get populated with SCM and CC movs      */
	/***********************************************************************************************************/
	IF (OBJECT_ID('tempdb..#ClaimMovement')) IS NOT NULL DROP TABLE #ClaimMovement

	CREATE TABLE #ClaimMovement
	(
		IDTY                                                    int             IDENTITY(1,1)
		,[FK_OriginalCurrency]                                  varchar(255)    NOT NULL
		,ChequeIssueDate                                        datetime        NULL
		,ChequeNumber                                           varchar(255)    NULL
		,ChequePayee                                            varchar(255)    NULL
		,ClaimTeamExaminer										varchar(255)    NULL
		,ExposureStatusCode                                     varchar(255)    NULL
		,FeesOnlyEntry                                          bit             NOT NULL    DEFAULT(0)
		,FK_ClaimCostCategory                                   bigint          NOT NULL
		,FK_ClaimExposure                                       bigint          NOT NULL
		,FK_DevelopmentPeriod                                   bigint          NULL
		,FK_LocalCurrency										bigint          NOT NULL
		,FK_SettlementCurrency                                  bigint          NOT NULL
		,InvoiceNumber                                          varchar(255)    NULL
		,LPSOSigningDate                                        datetime        NULL
		,LPSOSigningNumber                                      int             NULL        
		,MovementApprovalUser                                   varchar(255)    NULL
		,MovementCreateUser                                     varchar(255)    NULL
		,MovementCreationDate                                   datetime        NULL
		,MovementDate                                           datetime        NULL
		,MovementGroupId                                        int             NULL
		,MovementGroupSequenceId                                int             NULL
		,MovementNarrative                                      varchar(MAX)    NULL
		,MovementNarrativeFlag                                  bit             NULL
		,MovementPaidDefenceInOriginalCCY                       numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidDefenceInSettlementCCY                     numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidFeesInOriginalCCY                          numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidFeesInSettlementCCY                        numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementPaidIndemnityInOriginalCCY                     numeric(19,4)   NOT NULL    DEFAULT(0) /* All movements - both SCM and CC paids are deltas */
		,MovementPaidIndemnityInSettlementCCY                   numeric(19,4)   NOT NULL    DEFAULT(0) /* All movements - both SCM and CC paids are deltas */
		,MovementOutstandingDefenceInOriginalCCY                numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingDefenceInSettlementCCY              numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingFeesInOriginalCCY                   numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingFeesInSettlementCCY                 numeric(19,4)   NOT NULL    DEFAULT(0)
		,MovementOutstandingIndemnityInOriginalCCY              numeric(19,4)   NOT NULL    DEFAULT(0) /* CC only - CC outstandings are always a delta */
		,MovementOutstandingIndemnityInSettlementCCY            numeric(19,4)   NOT NULL    DEFAULT(0) /* CC only - CC outstandings are always a delta */
		,MovementPeriod                                         datetime        NULL
		,MovementReference                                      varchar(255)    NOT NULL
		,MovementType                                           varchar(255)    NOT NULL
		,OriginalCCYToLocalCCYRate								numeric(19,12)  NOT NULL
		,OutstandingOriginalCCYToSettlementCCYRate              numeric(19,12)  NOT NULL
		,PaidOriginalCCYToSettlementCCYRate                     numeric(19,12)  NOT NULL
		,PrimaryExaminerOrCreateUserId                          int             NULL
		,RecoveryCategory                                       varchar(255)    NULL
		,SequenceNumber                                         int             NOT NULL
		,SequenceNumberOrderId                                  int             NOT NULL    DEFAULT 0
		,TBAFlag                                                bit             NULL
		,TBAIndicator                                           varchar(255)    NULL
		,ToDateOutstandingDefenceInOriginalCCY                  numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingDefenceInSettlementCCY                numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingFeesInOriginalCCY                     numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingFeesInSettlementCCY                   numeric(19,4)   NOT NULL    DEFAULT(0)
		,ToDateOutstandingIndemnityInOriginalCCY                numeric(19,4)   NOT NULL    DEFAULT(0) /* SCM only - SCM outstandings are always a position */
		,ToDateOutstandingIndemnityInSettlementCCY              numeric(19,4)   NOT NULL    DEFAULT(0) /* SCM only - SCM outstandings are always a position */
		,UseForLastMovementBanding                              bit             NOT NULL    DEFAULT(1)
		,XChangingChecker                                       varchar(255)    NULL
		,CCClaimCostCategory									nvarchar(255)	NULL
		,AuditCreateDateTime                                    datetime2       NULL
		,ActualOriginalCurrency 								VARCHAR(3)		NULL		   --MultiCCY change --
		,ActualOriginalAmount 									NUMERIC(19,4)	NULL		   --MultiCCY change --
		,EstimatedSettlementAmount 								NUMERIC(19,4)	NULL		   --MultiCCY change --
		,ActualToSettlementExchangeRate							NUMERIC(19,4)	NULL		   --MultiCCY change --
		,DoesNotErodeReserves                                   bit             null
		,ActualOriginalAmountType								varchar(255)    NULL
		,BeazleyShare											NUMERIC(19,4)	NULL
	)			

	TRUNCATE TABLE #ClaimMovement
	
	INSERT INTO #ClaimMovement
	(
		[SequenceNumber]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]
		,[ToDateOutstandingFeesInOriginalCCY]
		,[ToDateOutstandingDefenceInOriginalCCY]
		,[MovementPaidIndemnityInOriginalCCY]
		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]
		,[ToDateOutstandingIndemnityInSettlementCCY]
		,[ToDateOutstandingFeesInSettlementCCY]
		,[ToDateOutstandingDefenceInSettlementCCY]
		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,MovementOutstandingIndemnityInOriginalCCY	
		,MovementOutstandingFeesInOriginalCCY		
		,MovementOutstandingDefenceInOriginalCCY	
		,MovementOutstandingIndemnityInSettlementCCY
		,MovementOutstandingFeesInSettlementCCY		
		,MovementOutstandingDefenceInSettlementCCY	
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[MovementNarrativeFlag]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		--,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]
		,[ClaimTeamExaminer]
		,[MovementCreationDate]
		,[CCClaimCostCategory]
		,[AuditCreateDateTime]               
		,ActualOriginalCurrency 								  --MultiCCY change --
		,ActualOriginalAmount 									  --MultiCCY change --
		,EstimatedSettlementAmount 								  --MultiCCY change --
		,ActualToSettlementExchangeRate							  --MultiCCY change --
		,DoesNotErodeReserves
		,ActualOriginalAmountType
		,BeazleyShare
	)
	SELECT				
	 		[SequenceNumber]								 	  =	 [SequenceNumber]								
			,[MovementReference]							 	  =	 [MovementReference]							
			,[MovementGroupId]									  = DENSE_RANK() OVER 
																		(ORDER BY 
																			T.FK_ClaimExposure
																			,T.FK_SettlementCurrency
																		)  
																					
			,[MovementGroupSequenceId]						   = ROW_NUMBER() OVER
																	(PARTITION BY 
																			T.FK_ClaimExposure
																			,T.FK_SettlementCurrency
																	ORDER BY 
																			CASE 
																				WHEN MovementType = 'SCM' THEN MovementDate	--isnull([MovementPeriod], movementdate)
																			END	
																			-- Specifically for claims which have YA, YB and YC movements, YC needs to come 
																			-- before YB. This only applies to multi-original currency claims, where these movements
																			-- indicate the change from the original CCY to EUR
																			,CASE 
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YA%' THEN 1
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YC%' THEN 2
																			 WHEN MovementType = 'SCM' AND T.MovementReference LIKE 'YB%' THEN 3
																			END
																			,T.SequenceNumber
																			,T.MovementReference
																			,T.FK_OriginalCurrency
																		) 
																								
			,[SequenceNumberOrderId]							  =  0 -- updated below (dependant on MovementSequenceNumberId)					
			,[OutstandingOriginalCCYToSettlementCCYRate]	 	  =	 [OutstandingOriginalCCYToSettlementCCYRate]	
			,[PaidOriginalCCYToSettlementCCYRate]			 	  =	 [PaidOriginalCCYToSettlementCCYRate]			
			,[MovementDate]									 	  =	 ISNULL([MovementDate], '1/1/1753')									
			,[MovementPeriod]								 	  =	 isnull([MovementPeriod]						, movementdate)
			,[ToDateOutstandingIndemnityInOriginalCCY]		 	  =	 ISNULL([ToDateOutstandingIndemnityInOriginalCCY]		,0)
			,[ToDateOutstandingFeesInOriginalCCY]			 	  =	 ISNULL([ToDateOutstandingFeesInOriginalCCY]			,0)
			,[ToDateOutstandingDefenceInOriginalCCY]		 	  =	 ISNULL([ToDateOutstandingDefenceInOriginalCCY]			,0)
			,[MovementPaidIndemnityInOriginalCCY]			 	  =	 ISNULL([MovementPaidIndemnityInOriginalCCY]			,0)
			,[MovementPaidFeesInOriginalCCY]				 	  =	 ISNULL([MovementPaidFeesInOriginalCCY]					,0)
			,[MovementPaidDefenceInOriginalCCY]				 	  =	 ISNULL([MovementPaidDefenceInOriginalCCY]				,0)
			,[ToDateOutstandingIndemnityInSettlementCCY]	 	  =	 ISNULL([ToDateOutstandingIndemnityInSettlementCCY]		,0)
			,[ToDateOutstandingFeesInSettlementCCY]			 	  =	 ISNULL([ToDateOutstandingFeesInSettlementCCY]			,0)
			,[ToDateOutstandingDefenceInSettlementCCY]		 	  =	 ISNULL([ToDateOutstandingDefenceInSettlementCCY]		,0)
			,[MovementPaidIndemnityInSettlementCCY]			 	  =	 ISNULL([MovementPaidIndemnityInSettlementCCY]			,0) 
			,[MovementPaidFeesInSettlementCCY]				 	  =	 ISNULL([MovementPaidFeesInSettlementCCY]				,0)
			,[MovementPaidDefenceInSettlementCCY]			 	  =	 ISNULL([MovementPaidDefenceInSettlementCCY]			,0)
			,[MovementType]									 	  =	 ISNULL([MovementType]	,'')
			,MovementOutstandingIndemnityInOriginalCCY			  =	 ISNULL(MovementOutstandingIndemnityInOriginalCCY		,0)
			,MovementOutstandingFeesInOriginalCCY				  =	 ISNULL(MovementOutstandingFeesInOriginalCCY			,0)
			,MovementOutstandingDefenceInOriginalCCY			  =	 ISNULL(MovementOutstandingDefenceInOriginalCCY			,0)
			,MovementOutstandingIndemnityInSettlementCCY		  =	 ISNULL(MovementOutstandingIndemnityInSettlementCCY		,0)
			,MovementOutstandingFeesInSettlementCCY				  =	 ISNULL(MovementOutstandingFeesInSettlementCCY			,0)
			,MovementOutstandingDefenceInSettlementCCY		  	  =  ISNULL(MovementOutstandingDefenceInSettlementCCY		,0)
			,[MovementApprovalUser]							 	  =	 [MovementApprovalUser]							
			,[MovementCreateUser]							 	  =	 [MovementCreateUser]							
			,[MovementNarrative]							 	  =	 [MovementNarrative]							
			,[MovementNarrativeFlag]							  = CASE  WHEN UPPER(MovementNarrative)		LIKE 'RATE OF EXCHANGE REVISION AT%'
																	         OR UPPER(MovementNarrative)	LIKE 'EURO TRANSITION CLAIM CONVERSION MOVEMENT%'
																	         OR UPPER(MovementNarrative)	LIKE 'RE-DENOMINATION MOVEMENT CREATED BY ESL%'
																	         OR UPPER(MovementNarrative)    = 'N/A'
																	         OR UPPER(MovementNarrative)    = 'DUMMY MOVEMENT' 
																	 THEN 1 ELSE 0 END								
			,[ChequeIssueDate]								 	  =	 [ChequeIssueDate]								
			,[ChequeNumber]									 	  =	 [ChequeNumber]									
			,[InvoiceNumber]								 	  =	 [InvoiceNumber]								
			,[ChequePayee]									 	  =	 [ChequePayee]									
			,[TBAIndicator]									 	  =	 [TBAIndicator]									
			,[TBAFlag]										 	  =	 [TBAFlag]										
			,[FeesOnlyEntry]									  =	 [FeesOnlyEntry]								
			,[LPSOSigningDate]								 	  =	 [LPSOSigningDate]								
			,[LPSOSigningNumber]							 	  =	 [LPSOSigningNumber]							
	
			,[XChangingChecker]								 	  =	 [XChangingChecker]				
			,[PrimaryExaminerOrCreateUserId]				 	  =	 [PrimaryExaminerOrCreateUserId]
			,[ExposureStatusCode]							 	  =	 [ExposureStatusCode]			
			,[RecoveryCategory]								 	  =	 [RecoveryCategory]				
			,[FK_ClaimCostCategory]							 	  =	 [FK_ClaimCostCategory]			
			,[FK_ClaimExposure]								 	  =	 [FK_ClaimExposure]				
			,[FK_SettlementCurrency]						 	  =	 [FK_SettlementCurrency]		
			,[FK_OriginalCurrency]							 	  =	 [FK_OriginalCurrency]			
			,[FK_LocalCurrency]								 	  =	 [FK_LocalCurrency]				
			,[FK_DevelopmentPeriod]							 	  =	 [FK_DevelopmentPeriod]			
			,[OriginalCCYToLocalCCYRate]						  =	 [OriginalCCYToLocalCCYRate]	
			,[ClaimTeamExaminer]							 	  =	 [ClaimTeamExaminer]			
			,[MovementCreationDate]								  =	 [MovementCreationDate]	
			,[CCClaimCostCategory]								  =  [ClaimCostCategory]	
			,[AuditCreateDateTime]								  =	 [AuditCreateDateTime]	            
			,ActualOriginalCurrency 							  =	 ActualOriginalCurrency 			   --MultiCCY change --
			,ActualOriginalAmount 								  =	 ActualOriginalAmount				   --MultiCCY change --
			,EstimatedSettlementAmount 							  =	 EstimatedSettlementAmount 			   --MultiCCY change --
			,ActualToSettlementExchangeRate						  =	 ActualToSettlementExchangeRate	   --MultiCCY change --
			,DoesNotErodeReserves                                 =  ISNULL(t.DoesNotErodeReserves, 0)
			,ActualOriginalAmountType							  =  ActualOriginalAmountType
			,BeazleyShare										  =  SignedLine
	FROM
	(						 
		SELECT
			 [SourceSystem]									   = cm.sourcesystem
			,[SequenceNumber]								   =  ROW_NUMBER() OVER (PARTITION BY [PK_ClaimExposure] order by isnull([MovementPeriod], movementdate), MovementDate, cm.SequenceNumber)      --   cme.SequenceNumber						
																
			,[MovementReference]							   = CASE 
																	WHEN ISNULL(cee.SCMReference, '') = '' THEN ISNULL(cm.MovementType, '') 
																	ELSE cm.MovementReferenceSourceId
																END-- according to  V5 code - in order to pass regression						

			,[OutstandingOriginalCCYToSettlementCCYRate]	   =  1 -- MultiCCY change--
																	/*
																	CASE	
																		WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY , 0) <> 0 THEN 
																														CASE 
																															WHEN ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)		= 0 THEN 1
																															WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)	= 0 THEN 1
																															ELSE cm.MovementReserveIndemnityAmountInOriginalCCY / cm.ToDateOutstandingIndemnityInReservingCCY 
																														END
																		WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY , 0) <> 0 THEN 
																														CASE 
																															WHEN ISNULL(cm.ToDateOutstandingFeesInReservingCCY, 0)		= 0 THEN 1
																															WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0)	= 0 THEN 1
																															ELSE cm.MovementReserveFeesAmountInOriginalCCY / cm.ToDateOutstandingFeesInReservingCCY 
																														END
																		WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY , 0) <> 0 THEN 
																														CASE 
																															WHEN ISNULL(cm.ToDateOutstandingDefenceInReservingCCY, 0)		= 0 THEN 1
																															WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0)	= 0 THEN 1
																															ELSE cm.MovementReserveDefenceAmountInOriginalCCY / cm.ToDateOutstandingDefenceInReservingCCY 
																														END
																		ELSE 1
																	END
																	*/
			,[PaidOriginalCCYToSettlementCCYRate]			   = 1 -- MultiCCY change -- ISNULL(cm.PaidOriginalCCYToSettlementCCYRate, 1)		
			,[MovementDate]									   = cm.MovementDate								
			,[MovementPeriod]								   = cm.MovementPeriod							
			
			,[ToDateOutstandingIndemnityInOriginalCCY]		   =	CASE 	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)--MultiCCY change -- ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY  ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			,[ToDateOutstandingFeesInOriginalCCY]			   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)--MultiCCY change --ISNULL(cm.MovementReserveFeesAmountInOriginalCCY	    ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			,[ToDateOutstandingDefenceInOriginalCCY]		   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)--MultiCCY change --ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)	
																		ELSE 0 
																	END--NULL -- marked as REMOVED 
			
			,[MovementPaidIndemnityInOriginalCCY]			   =  ISNULL(cm.ToDatePaidIndemnityInReservingCCY, 0)	--MultiCCY change --	ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)     
			,[MovementPaidFeesInOriginalCCY]				   =  ISNULL(cm.ToDatePaidFeesInReservingCCY	 , 0)	--MultiCCY change --	ISNULL(cm.MovementPaidFeesInOriginalCCY     , 0)     
			,[MovementPaidDefenceInOriginalCCY]				   =  ISNULL(cm.ToDatePaidDefenceInReservingCCY  , 0)	--MultiCCY change --	ISNULL(cm.MovementPaidDefenceInOriginalCCY  ,	0) 
																											  
			,[ToDateOutstandingIndemnityInSettlementCCY]	   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)	 
																		ELSE 0 
																	END --0-- updated below
			,[ToDateOutstandingFeesInSettlementCCY]			   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)	 
																		ELSE 0 
																	END --0-- updated below
			,[ToDateOutstandingDefenceInSettlementCCY]		   =	CASE  	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
																		WHEN MovementType = 'SCM' THEN ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)	 
																		ELSE 0  
																	END --0-- updated below
			
			,[MovementPaidIndemnityInSettlementCCY]			   = ISNULL(cm.ToDatePaidIndemnityInReservingCCY, 0)			-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidIndemnityInSettlementCCY]
			,[MovementPaidFeesInSettlementCCY]				   = ISNULL(cm.ToDatePaidFeesInReservingCCY	 , 0)				-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidFeesInSettlementCCY]
			,[MovementPaidDefenceInSettlementCCY]			   = ISNULL(cm.ToDatePaidDefenceInReservingCCY  , 0)			-- need to be remapped in phase 2 after DataContract is extended with field [MovementPaidDefenceInSettlementCCY]
			,[MovementType]									   = ISNULL(cm.MovementType, '')
						
															    
			,MovementOutstandingIndemnityInOriginalCCY		   = ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)		--MultiCCY change -- ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY  ,0)
			,MovementOutstandingFeesInOriginalCCY			   = ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)		--MultiCCY change -- ISNULL(cm.MovementReserveFeesAmountInOriginalCCY	    ,0)
			,MovementOutstandingDefenceInOriginalCCY		   = ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)		--MultiCCY change -- ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY    ,0)

			,MovementOutstandingIndemnityInSettlementCCY 	   =  ISNULL(cm.ToDateOutstandingIndemnityInReservingCCY, 0)	-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingIndemnityInSettlementCCY]
			,MovementOutstandingFeesInSettlementCCY			   =  ISNULL(cm.ToDateOutstandingFeesInReservingCCY	 , 0)		-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingFeesInSettlementCCY]
			,MovementOutstandingDefenceInSettlementCCY		   =  ISNULL(cm.ToDateOutstandingDefenceInReservingCCY  , 0)	-- need to be remapped in phase 2 after DataContract is extended with field [MovementOutstandingDefenceInSettlementCCY]
						
			,[MovementApprovalUser]							   = cme.MovementApprovalUser						

			,[MovementCreateUser]							   = cme.MovementCreateUser						

			,[MovementNarrative]							   = cm.MovementNarrative						
			,[ChequeIssueDate]								   = cme.ChequeIssueDate							
			,[ChequeNumber]									   = cme.ChequeNumber								
			,[InvoiceNumber]								   = cme.InvoiceNumber							
			,[ChequePayee]									   = cme.ChequePayee								
			,[TBAIndicator]									   = 0 -- marked as REMOVED -- cm.TBAIndicator								
			,[TBAFlag]										   = 0 -- marked as REMOVED -- CASE WHEN cm.TBAIndicator IS NOT NULL THEN 1 ELSE 0 END						
			,[FeesOnlyEntry]								   = CASE 
																	  WHEN cm.MovementNarrative LIKE '%fee%only%entry%' THEN 1
																	  ELSE 0
																 END    						
			,[LPSOSigningDate]								   = NULL -- marked as REMOVED -- cme.LPSOSigningDate		-- getdate()--					
			,[LPSOSigningNumber]							   = NULL -- marked as REMOVED -- cme.LPSOSigningNumber						
			,[UseForLastMovementBanding]					   = NULL -- updated below (dependant on MovementGroupId and MovementSequenceNumberId)
			,[XChangingChecker]								   = NULL -- marked as REMOVED -- cme.XChangingChecker							
			,[PrimaryExaminerOrCreateUserId]				   = cee.PrimaryExaminerClaimCenterId		
			,[ExposureStatusCode]							   = CASE 
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Closed' THEN 'C'
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Open'   THEN 'O'
																	WHEN (ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Closed' 
																			AND ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Open') THEN 'C'
																 END -- ce.ExposureStatusCode						
			,[RecoveryCategory]								   = cme.RecoveryCategory							
			,[FK_ClaimCostCategory]							   = ISNULL(ccc.PK_ClaimCostCategory, 3604417689521802688)				
			,[FK_ClaimExposure]								   = ISNULL(oce.PK_ClaimExposure, 0)
			,[FK_SettlementCurrency]						   = ISNULL(sc.PK_SettlementCurrency, (SELECT PK_SettlementCurrency FROM ODS.SettlementCurrency where CurrencyCode = 'USD'))			
			,[FK_OriginalCurrency]							   = ISNULL(oc.PK_OriginalCurrency, (SELECT PK_OriginalCurrency FROM ODS.OriginalCurrency where CurrencyCode = 'USD'))			
			,[FK_LocalCurrency]								   = CASE 
																	WHEN cm.MovementType = 'SCM' THEN 0
																	ELSE ISNULL(lc.PK_LocalCurrency, 0) 		 -- after regression of OriginalCCYToLocalCCYRate - Singapore financial team uses this		
																 END
			,[FK_DevelopmentPeriod]							   = ISNULL(dp.PK_DevelopmentPeriod, 0)							
			,[OriginalCCYToLocalCCYRate]					   = ISNULL(cm.OriginalCCYtoGroupCCYRate , 1) -- after regression of OriginalCCYToLocalCCYRate - Singapore financial team uses this --MultiCCY change -- ISNULL(cm.PaidOriginalCCYToSettlementCCYRate, 1) ---cem.[Outbound].[DiaryEntry]   --- to be provided  by CC V9 team !!!
			,[ClaimTeamExaminer]							   = NULL -- marked as REMOVED -- cee.ClaimTeamExaminer						
			,[MovementCreationDate]							   = ISNULL(cme.TransactionCreatedOn	, cm.MovementDate)--cm.MovementDate	
			,[ClaimCostCategory]							   = cme.ClaimCostCategory	
			,[AuditCreateDateTime]							   = cm.[AuditCreateDateTime]
			,ActualOriginalCurrency 						   = cm.OriginalCurrency    --MultiCCY change 
			,ActualOriginalAmount 							   = CASE					--MultiCCY change 
																	WHEN ISNULL(cm.MovementType, '') = 'Reserve' THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0)		
																														ELSE 0
																													END
																	WHEN ISNULL(cm.MovementType, '') in ('Payment' , 'Recovery') THEN
																													CASE 
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0)		
																														ELSE 0
																													END		
																	
																	WHEN ISNULL(cm.MovementType, '') = 'SCM'	THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0)		
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0 THEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0)
																														ELSE 0
																													END												
																	ELSE 0
																END													
																													
			,EstimatedSettlementAmount 						   = cm.EstimatedSettlementAmount		  --MultiCCY change -- 
			,ActualToSettlementExchangeRate					   = cm.ActualToSettlementExchangeRate	  --MultiCCY change -- 
			,DoesNotErodeReserves                              = CASE 
																	WHEN cm.Movementtype = 'SCM' THEN 1 
																	ELSE cm.DoesNotErodeReserves
																END
			,ActualOriginalAmountType						   = CASE 
																	WHEN ISNULL(cm.MovementType, '') = 'SCM'	THEN 
																													CASE 
																														WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0 THEN 'Indemnity-Reserve(SCM)'		
																														WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0		THEN 'Fees-Reserve(SCM)'	
																														WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0	THEN 'Defence-Reserve(SCM)'		
																														WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0			THEN 'Indemnity-Payment(SCM)'
																														WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0				THEN 'Fees-Payment(SCM)'
																														WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0			THEN 'Defence-Payment(SCM)'
																														ELSE NULL
																													END			
																	WHEN ISNULL(cm.MovementReserveIndemnityAmountInOriginalCCY, 0) <> 0 THEN 'Indemnity'
																	WHEN ISNULL(cm.MovementReserveFeesAmountInOriginalCCY, 0) <> 0		THEN 'Fees'	
																	WHEN ISNULL(cm.MovementReserveDefenceAmountInOriginalCCY, 0) <> 0	THEN 'Defence'		
																	 
																	WHEN ISNULL(cm.MovementPaidIndemnityInOriginalCCY, 0) <> 0			THEN 'Indemnity'
																	WHEN ISNULL(cm.MovementPaidFeesInOriginalCCY, 0) <> 0				THEN 'Fees'	
																	WHEN ISNULL(cm.MovementPaidDefenceInOriginalCCY, 0) <> 0			THEN 'Defence'	
																	ELSE NULL
																END		
			,SignedLine										   = cme.SignedLine		
		FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement cm 

		INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovementExtension cme
		ON	    cm.[SourceSystem]					= cme.[SourceSystem]
			AND cm.[ClaimExposureSourceId]			= cme.[ClaimExposureSourceId]		
			--AND cm.[IsActive]						= cme.[IsActive]			
			AND cm.[MovementReferenceSourceId]		= cme.[MovementReferenceSourceId]	
			AND cm.[SequenceNumber]					= cme.[SequenceNumber]				
			AND cm.[OriginalCurrency]				= cme.[OriginalCurrency]			
			AND cm.[SettlementCurrency]				= cme.[SettlementCurrency]			

		INNER JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce
		ON	    ce.[SourceSystem]					= cme.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cme.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cme.[IsActive]			

		LEFT JOIN  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee
		ON	    ce.[SourceSystem]					= cee.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cee.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cee.[IsActive]	
		
		INNER JOIN 
			(
				select 
					ExposureReference --= OriginatingBureau + LEFT(ExposureReference, charindex('-', ExposureReference) - 1)
					,OriginatingBureau
					,ExposureSequenceId
					,PK_ClaimExposure
					,FK_ClaimTeamExaminer
					,FK_YOA
				from ODS.ClaimExposure
				) oce 
		ON oce.ExposureReference = ce.ClaimExposureSourceId
		AND oce.OriginatingBureau = ce.OriginatingBureau

		LEFT JOIN ODS.SettlementCurrency sc 
		ON cm.SettlementCurrency = sc.CurrencyCode

		
		LEFT JOIN ODS.OriginalCurrency oc 
		--ON cm.OriginalCurrency = oc.CurrencyCode
		ON cm.SettlementCurrency = oc.CurrencyCode--MultiCCY change --

		LEFT JOIN ODS.LocalCurrency lc 
		ON cm.SettlementCurrency = lc.CurrencyCode
		
		
		LEFT JOIN ODS.ClaimCostCategory ccc 
		ON cme.ClaimCostCategory = ccc.CCCostCategoryName
		
		LEFT JOIN ODS.YOA yoa 
		ON oce.FK_YOA = yoa.PK_YOA

		LEFT OUTER JOIN ODS.DevelopmentPeriod dp 
		ON DATEDIFF(MM, yoa.FirstDate, cm.MovementPeriod) + 1 = dp.DevelopmentMonth

		WHERE cm.SourceSystem = 'ClaimCenter'
			--and cm.IsActive = 1


		UNION ALL
		
			SELECT
			--ce.ClaimExposureSourceId,
			[SourceSystem]									   = ce.sourcesystem
			,[SequenceNumber]								   = 0 					
			,[MovementReference]							   = 'DUMMY MOVEMENT' 	
			,[OutstandingOriginalCCYToSettlementCCYRate]	   = 1
			,[PaidOriginalCCYToSettlementCCYRate]			   = 1	
			,[MovementDate]									   = ce.ExposureOpenedDate								
			,[MovementPeriod]								   = ISNULL(CAST('01 ' + ap.AccountingPeriodName AS datetime), ce.ExposureOpenedDate) --1st of accounting period, as long as it exists in the accounting period table									
			,[ToDateOutstandingIndemnityInOriginalCCY]		   = NULL
			,[ToDateOutstandingFeesInOriginalCCY]			   = NULL    
			,[ToDateOutstandingDefenceInOriginalCCY]		   = NULL	         		
			,[MovementPaidIndemnityInOriginalCCY]			   = 0
			,[MovementPaidFeesInOriginalCCY]				   = 0			   
			,[MovementPaidDefenceInOriginalCCY]				   = 0				  
			,[ToDateOutstandingIndemnityInSettlementCCY]	   = 0-- updated below
			,[ToDateOutstandingFeesInSettlementCCY]			   = 0-- updated below
			,[ToDateOutstandingDefenceInSettlementCCY]		   = 0-- updated below		
			,[MovementPaidIndemnityInSettlementCCY]			   = 0 -- seem to be updated in post processing cme.MovementPaidIndemnityInSettlementCCY		
			,[MovementPaidFeesInSettlementCCY]				   = 0 -- seem to be updated in post processing cme.MovementPaidFeesInSettlementCCY			
			,[MovementPaidDefenceInSettlementCCY]			   = 0 -- seem to be updated in post processing cme.MovementPaidDefenceInSettlementCCY		
			,[MovementType]									   = 'N/A'																					    
			,MovementOutstandingIndemnityInOriginalCCY		   = 0
			,MovementOutstandingFeesInOriginalCCY			   = 0
			,MovementOutstandingDefenceInOriginalCCY		   = 0
			,MovementOutstandingIndemnityInSettlementCCY 	   = 0
			,MovementOutstandingFeesInSettlementCCY			   = 0
			,MovementOutstandingDefenceInSettlementCCY		   = 0						
			,[MovementApprovalUser]							   = NULL					
			,[MovementCreateUser]							   = NULL				
			,[MovementNarrative]							   = 'DUMMY MOVEMENT'						
			,[ChequeIssueDate]								   = NULL							
			,[ChequeNumber]									   = NULL							
			,[InvoiceNumber]								   = NULL						
			,[ChequePayee]									   = NULL							
			,[TBAIndicator]									   = 0 							
			,[TBAFlag]										   = 0					
			,[FeesOnlyEntry]								   = 0    						
			,[LPSOSigningDate]								   = NULL 			
			,[LPSOSigningNumber]							   = NULL 
			,[UseForLastMovementBanding]					   = NULL -- updated below (dependant on MovementGroupId and MovementSequenceNumberId)
			,[XChangingChecker]								   = NULL						
			,[PrimaryExaminerOrCreateUserId]				   = NULL	
			,[ExposureStatusCode]							   = CASE 
																	WHEN Utility.udf_ProcessString(ce.ExposureStatus,0) = 'Closed' THEN 'C'
																	WHEN Utility.udf_ProcessString(ce.ExposureStatus,0) = 'Open'   THEN 'O'
																	WHEN (ISNULL(Utility.udf_ProcessString(ce.ExposureStatus,0), '') <> 'Closed' 
																			AND ISNULL(Utility.udf_ProcessString(ce.ExposureStatus,0), '') <> 'Open') THEN 'C'
																 END					
			,[RecoveryCategory]								   = NULL							
			,[FK_ClaimCostCategory]							   = ISNULL(ccc.PK_ClaimCostCategory, 3604417689521802688)				
			,[FK_ClaimExposure]								   = ISNULL(oce.PK_ClaimExposure, 0)
			,[FK_SettlementCurrency]						   = ISNULL(sc.PK_SettlementCurrency, (SELECT PK_SettlementCurrency FROM ODS.SettlementCurrency where CurrencyCode = 'USD'))					
			,[FK_OriginalCurrency]							   = ISNULL(oc.PK_OriginalCurrency, (SELECT PK_OriginalCurrency FROM ODS.OriginalCurrency where CurrencyCode = 'USD'))
			,[FK_LocalCurrency]								   = ISNULL(lc.PK_LocalCurrency,2) 				
			,[FK_DevelopmentPeriod]							   = ISNULL(dp.PK_DevelopmentPeriod, 0)							
			,[OriginalCCYToLocalCCYRate]					   = ISNULL(cm.OriginalCCYtoGroupCCYRate , 1)
			,[ClaimTeamExaminer]							   = NULL				
			,[MovementCreationDate]							   = ce.ExposureOpenedDate	
			,[ClaimCostCategory]							   = 'NO FINANCIALS'
			,[AuditCreateDateTime]							   = ISNULL(cm.[AuditCreateDateTime], ce.[AuditCreateDateTime])
			,ActualOriginalCurrency 						   = cm.OriginalCurrency    --MultiCCY change -- 
			,ActualOriginalAmount 							   = 0						--MultiCCY change -- 						
			,EstimatedSettlementAmount 						   = 0 --MultiCCY change -- cm.EstimatedSettlementAmount
			,ActualToSettlementExchangeRate					   = 1 --MultiCCY change -- cm.ActualToSettlementExchangeRate
			,DoesNotErodeReserves                              = 1
			,ActualOriginalAmountType						   = NULL
			,SignedLine										   = NULL
		FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce

		--INNER JOIN  BeazleyIntelligenceDataContract.Outbound.ClaimExposureExtension cee
		--ON	    ce.[SourceSystem]					= cee.[SourceSystem]
		--	AND ce.[ClaimExposureSourceId]			= cee.[ClaimExposureSourceId]		
		--	AND ce.[IsActive]						= cee.[IsActive]	
		
		LEFT JOIN BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureMovement cm 
		ON	    ce.[SourceSystem]					= cm.[SourceSystem]
			AND ce.[ClaimExposureSourceId]			= cm.[ClaimExposureSourceId]		
			--AND ce.[IsActive]						= cm.[IsActive]			
			AND cm.sequenceNumber= 1
		
		INNER JOIN 
			(
				select 
					ExposureReference --= OriginatingBureau + LEFT(ExposureReference, charindex('-', ExposureReference) - 1)
					,OriginatingBureau
					,ExposureSequenceId
					,PK_ClaimExposure
					,FK_ClaimTeamExaminer
					,FK_YOA
					,FK_Claim
					,SCMReference
				from ODS.ClaimExposure
				) oce 
		ON oce.ExposureReference = ce.ClaimExposureSourceId
		AND oce.OriginatingBureau = ce.OriginatingBureau

		LEFT JOIN ODS.SettlementCurrency sc 
		ON cm.SettlementCurrency = sc.CurrencyCode

		
		LEFT JOIN ODS.OriginalCurrency oc 
		--ON cm.OriginalCurrency = oc.CurrencyCode
		ON cm.SettlementCurrency = oc.CurrencyCode  --MultiCCY change --
		

		LEFT JOIN ODS.LocalCurrency lc 
		ON cm.SettlementCurrency = lc.CurrencyCode
		
		
		LEFT JOIN ODS.ClaimCostCategory ccc 
		ON ccc.ClaimCostCategory = 'NO FINANCIALS'	
		
		LEFT JOIN	ODS.Claim c 
		ON	oce.FK_Claim = c.PK_Claim

		LEFT JOIN	ODS.AccountingCalendar ac 
		ON	c.FK_AccountingCalendar = ac.PK_AccountingCalendar

		LEFT OUTER JOIN	ODS.AccountingPeriod ap 
		ON	ac.PK_AccountingCalendar = ap.FK_AccountingCalendar	AND
			ce.ExposureOpenedDate >= ap.PeriodStart	AND 
			ce.ExposureOpenedDate < ap.PeriodEnd --Make sure we put the dummy movement into the correct accounting period

		LEFT JOIN ODS.YOA yoa 
		ON oce.FK_YOA = yoa.PK_YOA 


		LEFT OUTER JOIN ODS.DevelopmentPeriod dp 
		ON DATEDIFF(MM, yoa.FirstDate, cm.MovementPeriod) + 1 = dp.DevelopmentMonth

		WHERE ce.SourceSystem = 'ClaimCenter'
			--and ce.IsActive = 1
			AND ISNULL(oce.SCMReference, '') = ''

	) AS T




	UPDATE claimmovcurr
	SET claimmovcurr.UseForLastMovementBanding = CASE
												-- For SCMs, if the movement reference hasn't changed, then we don't use the movement for calculating bandings
												WHEN claimmovcurr.MovementType = 'SCM' AND claimmovcurr.MovementReference = claimmovprev.MovementReference 
													THEN 0
												-- If the movement narrative contains any of the following strings, then we don't use the movement for calculating bandings
												WHEN claimmovcurr.MovementNarrativeFlag = 1
													THEN 0 
												ELSE 1
												END
    
	FROM #ClaimMovement claimmovcurr

	INNER JOIN #ClaimMovement claimmovprev 
	ON  claimmovcurr.MovementGroupId         = claimmovprev.MovementGroupId
	AND claimmovcurr.MovementGroupSequenceId = claimmovprev.MovementGroupSequenceId + 1

	WHERE claimmovcurr.MovementType = 'SCM' 

	/*
	UPDATE claimmov SET
	/*Decrease reserves on manual payment records*/
	 claimmov.MovementOutstandingIndemnityInOriginalCCY  = claimmov.MovementPaidIndemnityInOriginalCCY    * -1
	,claimmov.MovementOutstandingFeesInOriginalCCY       = claimmov.MovementPaidFeesInOriginalCCY         * -1
	,claimmov.MovementOutstandingDefenceInOriginalCCY    = claimmov.MovementPaidDefenceInOriginalCCY      * -1

	/*Decrease reserves on manual payment records for Settlement*/
	,claimmov.MovementOutstandingIndemnityInSettlementCCY  = claimmov.MovementPaidIndemnityInSettlementCCY    * -1
	,claimmov.MovementOutstandingFeesInSettlementCCY       = claimmov.MovementPaidFeesInSettlementCCY         * -1
	,claimmov.MovementOutstandingDefenceInSettlementCCY    = claimmov.MovementPaidDefenceInSettlementCCY      * -1
	FROM 
	#ClaimMovement claimmov
	WHERE   
	claimmov.MovementType <> 'SCM' 
	AND claimmov.MovementType <> 'Reserve'
	---AND claimmov.DoesNotErodeReserves = 0;  -- commented due to field not existing in V9


	-- Outstandings to-date
	;WITH CTEOutstandingsToDate AS
	(
	 SELECT
		 MovementGroupId                               = claimmov.MovementGroupId                                                  
		,MovementGroupSequenceId                       = claimmov.MovementGroupSequenceId                                       
		,ToDateOutstandingIndemnityInOriginalCCY       = ISNULL(claimmov.MovementOutstandingIndemnityInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingIndemnityInOriginalCCY, 0))     
		,ToDateOutstandingFeesInOriginalCCY            = ISNULL(claimmov.MovementOutstandingFeesInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingFeesInOriginalCCY, 0))          
		,ToDateOutstandingDefenceInOriginalCCY         = ISNULL(claimmov.MovementOutstandingDefenceInOriginalCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingDefenceInOriginalCCY, 0))
		,ToDateOutstandingIndemnityInSettlementCCY     = ISNULL(claimmov.MovementOutstandingIndemnityInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingIndemnityInSettlementCCY, 0))     
		,ToDateOutstandingFeesInSettlementlCCY         = ISNULL(claimmov.MovementOutstandingFeesInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingFeesInSettlementCCY, 0))          
		,ToDateOutstandingDefenceInSettlementCCY       = ISNULL(claimmov.MovementOutstandingDefenceInSettlementCCY, 0) + SUM(ISNULL(claimmov2.MovementOutstandingDefenceInSettlementCCY, 0))  
	 FROM #ClaimMovement claimmov

	 inner JOIN #ClaimMovement claimmov2 
	 ON claimmov.MovementGroupId          = claimmov2.MovementGroupId
	 AND claimmov.MovementGroupSequenceId > claimmov2.MovementGroupSequenceId

	-- WHERE claimmov.IsSCMMovement = 0
	 GROUP BY claimmov.MovementGroupId
			 ,claimmov.MovementGroupSequenceId
			 ,claimmov.MovementOutstandingIndemnityInOriginalCCY
			 ,claimmov.MovementOutstandingFeesInOriginalCCY
			 ,claimmov.MovementOutstandingDefenceInOriginalCCY
			 ,claimmov.MovementOutstandingIndemnityInSettlementCCY 
			 ,claimmov.MovementOutstandingFeesInSettlementCCY
			 ,claimmov.MovementOutstandingDefenceInSettlementCCY
	)


	UPDATE claimmov
	SET
	 claimmov.ToDateOutstandingIndemnityInOriginalCCY      = ISNULL(outstadingdt.ToDateOutstandingIndemnityInOriginalCCY, 0)
	,claimmov.ToDateOutstandingFeesInOriginalCCY           = ISNULL(outstadingdt.ToDateOutstandingFeesInOriginalCCY	  , 0)
	,claimmov.ToDateOutstandingDefenceInOriginalCCY        = ISNULL(outstadingdt.ToDateOutstandingDefenceInOriginalCCY  , 0)
	,claimmov.ToDateOutstandingIndemnityInSettlementCCY    = ISNULL(outstadingdt.ToDateOutstandingIndemnityInSettlementCCY	, 0)
	,claimmov.ToDateOutstandingFeesInSettlementCCY         = ISNULL(outstadingdt.ToDateOutstandingFeesInSettlementlCCY		, 0)
	,claimmov.ToDateOutstandingDefenceInSettlementCCY      = ISNULL(outstadingdt.ToDateOutstandingDefenceInSettlementCCY	, 0)
	FROM #ClaimMovement claimmov

	INNER JOIN CTEOutstandingsToDate outstadingdt 
	ON  claimmov.MovementGroupId         = outstadingdt.MovementGroupId
	AND claimmov.MovementGroupSequenceId = outstadingdt.MovementGroupSequenceId    

	*/
	/***********************************************************************************************************/
	/*   Update sequence order - movements need to be shown in reverse chronological order in the front-end    */
	/***********************************************************************************************************/
	UPDATE claimmov 
	SET
	   claimmov.SequenceNumberOrderId  = claimmov1.LastMovementGroupSequenceId + 1 - claimmov.MovementGroupSequenceId

	FROM #ClaimMovement claimmov

	INNER JOIN
		(
		 SELECT MovementGroupId          = claimmov.MovementGroupId                  
			,LastMovementGroupSequenceId = MAX(claimmov.MovementGroupSequenceId) 
		 FROM #ClaimMovement claimmov
		 GROUP BY claimmov.MovementGroupId
		) claimmov1 
	ON claimmov.MovementGroupId = claimmov1.MovementGroupId

	/*update rates which are 0 with 1 in order not to break in ODS.PostPorcessClaimExposure or in Red.FaclClaimMovement */
	UPDATE #ClaimMovement
	SET OriginalCCYToLocalCCYRate = 1
	WHERE OriginalCCYToLocalCCYRate = 0

	UPDATE #ClaimMovement
	SET OutstandingOriginalCCYToSettlementCCYRate = 1
	WHERE OutstandingOriginalCCYToSettlementCCYRate = 0

	UPDATE #ClaimMovement
	SET PaidOriginalCCYToSettlementCCYRate = 1
	WHERE PaidOriginalCCYToSettlementCCYRate = 0

	-- we calculate the ToDateOutstanding... fields for:
			-- non SCM movements from migration
			-- non SCM from UI (after go live)
			-- SCM  from UI (after go live)
	INSERT INTO  ODS.ClaimMovement_BeazleyShare  
	(
		[SequenceNumber]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]
		,[ToDateOutstandingFeesInOriginalCCY]
		,[ToDateOutstandingDefenceInOriginalCCY]
		,[MovementPaidIndemnityInOriginalCCY]
		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]
		,[ToDateOutstandingIndemnityInSettlementCCY]
		,[ToDateOutstandingFeesInSettlementCCY]
		,[ToDateOutstandingDefenceInSettlementCCY]
		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]
		,[ClaimTeamExaminer]
		,[MovementCreationDate]            
		,ActualOriginalCurrency 			   --MultiCCY change --
		,ActualOriginalAmount 				   --MultiCCY change --
		,EstimatedSettlementAmount 			   --MultiCCY change --
		,ActualToSettlementExchangeRate		   --MultiCCY change --
		,ActualOriginalAmountType
		,BeazleyShare
	)
	SELECT distinct
		[SequenceNumber]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]	     = SUM([ToDateOutstandingIndemnityInOriginalCCY])		OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[ToDateOutstandingFeesInOriginalCCY]		     = SUM([ToDateOutstandingFeesInOriginalCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[ToDateOutstandingDefenceInOriginalCCY]	     = SUM([ToDateOutstandingDefenceInOriginalCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND  CURRENT ROW) 
		,[MovementPaidIndemnityInOriginalCCY]


		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]


		,[ToDateOutstandingIndemnityInSettlementCCY]	  = SUM([ToDateOutstandingIndemnityInSettlementCCY])	OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 
		,[ToDateOutstandingFeesInSettlementCCY]			  = SUM([ToDateOutstandingFeesInSettlementCCY])			OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 
		,[ToDateOutstandingDefenceInSettlementCCY]		  = SUM([ToDateOutstandingDefenceInSettlementCCY])		OVER (PARTITION BY FK_ClaimExposure, MovementGroupId   ORDER BY  [MovementGroupSequenceId]  ROWS BETWEEN UNBOUNDED PRECEDING  AND CURRENT ROW) 

 

		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]
		,[ClaimTeamExaminer]
		,[MovementCreationDate]            
		,ActualOriginalCurrency 				   --MultiCCY change --
		,ActualOriginalAmount 					   --MultiCCY change --
		,EstimatedSettlementAmount 				   --MultiCCY change --
		,ActualToSettlementExchangeRate			   --MultiCCY change --
		,ActualOriginalAmountType
		,BeazleyShare
	FROM
	(
		SELECT
			[SequenceNumber]
			,[MovementReference]
			,[MovementGroupId]
			,[MovementGroupSequenceId]
			,[SequenceNumberOrderId]
			,[OutstandingOriginalCCYToSettlementCCYRate]
			,[PaidOriginalCCYToSettlementCCYRate]
			,[MovementDate]
			,[MovementPeriod]
			,[ToDateOutstandingIndemnityInOriginalCCY]	     = (LAG(ToDateOutstandingIndemnityInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)	)		+ MovementOutstandingIndemnityInOriginalCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidIndemnityInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingFeesInOriginalCCY]		     = (LAG(ToDateOutstandingFeesInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingFeesInOriginalCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidFeesInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingDefenceInOriginalCCY]	     = (LAG(ToDateOutstandingDefenceInOriginalCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingDefenceInOriginalCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidDefenceInOriginalCCY
																																																							ELSE 0 
																																																						END
			,[MovementPaidIndemnityInOriginalCCY]


			,[MovementPaidFeesInOriginalCCY]
			,[MovementPaidDefenceInOriginalCCY]


			,[ToDateOutstandingIndemnityInSettlementCCY]	  = (LAG(ToDateOutstandingIndemnityInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid))		+ MovementOutstandingIndemnityInSettlementCCY		- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidIndemnityInSettlementCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingFeesInSettlementCCY]			  = (LAG(ToDateOutstandingFeesInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)		)		+ MovementOutstandingFeesInSettlementCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidFeesInSettlementCCY
																																																							ELSE 0 
																																																						END
			,[ToDateOutstandingDefenceInSettlementCCY]		  = (LAG(ToDateOutstandingDefenceInSettlementCCY, 1,0) OVER (ORDER BY movementgroupsequenceid)	)		+ MovementOutstandingDefenceInSettlementCCY			- CASE
																																																							WHEN MovementType = 'Payment' AND DoesNotErodeReserves = 0 THEN MovementPaidDefenceInSettlementCCY
																																																							ELSE 0 
																																																						END

 

			,[MovementPaidIndemnityInSettlementCCY]
			,[MovementPaidFeesInSettlementCCY]
			,[MovementPaidDefenceInSettlementCCY]
			,[MovementType]
			,[MovementApprovalUser]
			,[MovementCreateUser]
			,[MovementNarrative]
			,[ChequeIssueDate]
			,[ChequeNumber]
			,[InvoiceNumber]
			,[ChequePayee]
			,[TBAIndicator]
			,[TBAFlag]
			,[FeesOnlyEntry]
			,[LPSOSigningDate]
			,[LPSOSigningNumber]
			,[UseForLastMovementBanding]
			,[XChangingChecker]
			,[PrimaryExaminerOrCreateUserId]
			,[ExposureStatusCode]
			,[RecoveryCategory]
			,[FK_ClaimCostCategory]
			,[FK_ClaimExposure]
			,[FK_SettlementCurrency]
			,[FK_OriginalCurrency]
			,[FK_LocalCurrency]
			,[FK_DevelopmentPeriod]
			,[OriginalCCYToLocalCCYRate]
			,[ClaimTeamExaminer]
			,[MovementCreationDate]            
			,ActualOriginalCurrency 								   --MultiCCY change --
			,ActualOriginalAmount 									   --MultiCCY change --
			,EstimatedSettlementAmount 								   --MultiCCY change --
			,ActualToSettlementExchangeRate							   --MultiCCY change --
			,ActualOriginalAmountType
			,BeazleyShare
		FROM #ClaimMovement
		WHERE MovementType <> 'SCM' 	 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM
			
	) as T

	-- for SCM movements from migration we take the ToDateOutstanding... fields as pushed by CC V9
	INSERT INTO  ODS.ClaimMovement_BeazleyShare  
	(
		[SequenceNumber]
		,[MovementReference]
		,[MovementGroupId]
		,[MovementGroupSequenceId]
		,[SequenceNumberOrderId]
		,[OutstandingOriginalCCYToSettlementCCYRate]
		,[PaidOriginalCCYToSettlementCCYRate]
		,[MovementDate]
		,[MovementPeriod]
		,[ToDateOutstandingIndemnityInOriginalCCY]
		,[ToDateOutstandingFeesInOriginalCCY]
		,[ToDateOutstandingDefenceInOriginalCCY]
		,[MovementPaidIndemnityInOriginalCCY]
		,[MovementPaidFeesInOriginalCCY]
		,[MovementPaidDefenceInOriginalCCY]
		,[ToDateOutstandingIndemnityInSettlementCCY]
		,[ToDateOutstandingFeesInSettlementCCY]
		,[ToDateOutstandingDefenceInSettlementCCY]
		,[MovementPaidIndemnityInSettlementCCY]
		,[MovementPaidFeesInSettlementCCY]
		,[MovementPaidDefenceInSettlementCCY]
		,[MovementType]
		,[MovementApprovalUser]
		,[MovementCreateUser]
		,[MovementNarrative]
		,[ChequeIssueDate]
		,[ChequeNumber]
		,[InvoiceNumber]
		,[ChequePayee]
		,[TBAIndicator]
		,[TBAFlag]
		,[FeesOnlyEntry]
		,[LPSOSigningDate]
		,[LPSOSigningNumber]
		,[UseForLastMovementBanding]
		,[XChangingChecker]
		,[PrimaryExaminerOrCreateUserId]
		,[ExposureStatusCode]
		,[RecoveryCategory]
		,[FK_ClaimCostCategory]
		,[FK_ClaimExposure]
		,[FK_SettlementCurrency]
		,[FK_OriginalCurrency]
		,[FK_LocalCurrency]
		,[FK_DevelopmentPeriod]
		,[OriginalCCYToLocalCCYRate]
		,[ClaimTeamExaminer]
		,[MovementCreationDate]           
		,ActualOriginalCurrency 								   --MultiCCY change --
		,ActualOriginalAmount 									   --MultiCCY change --
		,EstimatedSettlementAmount 								   --MultiCCY change --
		,ActualToSettlementExchangeRate							   --MultiCCY change --
		,ActualOriginalAmountType
		,BeazleyShare
	)
	SELECT distinct
			[SequenceNumber]
			,[MovementReference]
			,[MovementGroupId]
			,[MovementGroupSequenceId]
			,[SequenceNumberOrderId]
			,[OutstandingOriginalCCYToSettlementCCYRate]
			,[PaidOriginalCCYToSettlementCCYRate]
			,[MovementDate]
			,[MovementPeriod]
			,[ToDateOutstandingIndemnityInOriginalCCY]	  
			,[ToDateOutstandingFeesInOriginalCCY]		  
			,[ToDateOutstandingDefenceInOriginalCCY]	  
			,[MovementPaidIndemnityInOriginalCCY]


			,[MovementPaidFeesInOriginalCCY]
			,[MovementPaidDefenceInOriginalCCY]


			,[ToDateOutstandingIndemnityInSettlementCCY]	
			,[ToDateOutstandingFeesInSettlementCCY]			
			,[ToDateOutstandingDefenceInSettlementCCY]		

 

			,[MovementPaidIndemnityInSettlementCCY]
			,[MovementPaidFeesInSettlementCCY]
			,[MovementPaidDefenceInSettlementCCY]
			,[MovementType]
			,[MovementApprovalUser]
			,[MovementCreateUser]
			,[MovementNarrative]
			,[ChequeIssueDate]
			,[ChequeNumber]
			,[InvoiceNumber]
			,[ChequePayee]
			,[TBAIndicator]
			,[TBAFlag]
			,[FeesOnlyEntry]
			,[LPSOSigningDate]
			,[LPSOSigningNumber]
			,[UseForLastMovementBanding]
			,[XChangingChecker]
			,[PrimaryExaminerOrCreateUserId]
			,[ExposureStatusCode]
			,[RecoveryCategory]
			,[FK_ClaimCostCategory]
			,[FK_ClaimExposure]
			,[FK_SettlementCurrency]
			,[FK_OriginalCurrency]
			,[FK_LocalCurrency]
			,[FK_DevelopmentPeriod]
			,[OriginalCCYToLocalCCYRate]
			,[ClaimTeamExaminer]
			,[MovementCreationDate]           
			,ActualOriginalCurrency 								   --MultiCCY change --
			,ActualOriginalAmount 									   --MultiCCY change --
			,EstimatedSettlementAmount 								   --MultiCCY change --
			,ActualToSettlementExchangeRate							   --MultiCCY change --
			,ActualOriginalAmountType
			,BeazleyShare
		FROM #ClaimMovement
		WHERE MovementType = 'SCM' 		 -- MovementType = 'SCM' is from migration, from UI will come only with Reserve and Payment even if is SCM	
			
	
END