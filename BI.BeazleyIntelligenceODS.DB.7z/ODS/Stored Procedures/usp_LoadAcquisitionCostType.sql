﻿CREATE PROCEDURE [ODS].[usp_LoadAcquisitionCostType]
 AS
 
 SET NOCOUNT ON
 


  
 ;MERGE ODS.AcquisitionCostType AS Target
 USING (
 SELECT 
 AcquisitionCostTypeCode                 = dq.Code
 ,AcquisitionCostTypeDescription         = dq.[Description]
 ,AcquisitionCostTypeInternalExternal    = 'External'
 ,TaxDescription                         = ISNULL(t.TaxDescription,'N/A')
 FROM
 Staging_MDS.dbo.vw_deduction_quals dq  
 LEFT JOIN (SELECT DISTINCT AcquisitionCostTypeCode, TaxDescription FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionAcquisitionCost ) t
 ON t.AcquisitionCostTypeCode=dq.Code
 UNION ALL
 SELECT
 AcquisitionCostTypeCode                 = 'XC'
 ,AcquisitionCostTypeDescription         = 'BUSA Commission'
 ,AcquisitionCostTypeInternalExternal    = 'Internal'
 ,TaxDescription = 'N/A'
 UNION ALL
 SELECT
 AcquisitionCostTypeCode                 = 'XR'
 ,AcquisitionCostTypeDescription         = 'BICI Ceding Commission'
 ,AcquisitionCostTypeInternalExternal    = 'Internal'
 ,TaxDescription = 'N/A'
 -- Add Unirisx AcquisitionCostTypes
 UNION ALL
 SELECT
 AcquisitionCostTypeCode                 = 'UD'
 ,AcquisitionCostTypeDescription         = 'DISCOUNTS'
 ,AcquisitionCostTypeInternalExternal    = 'External'
 ,TaxDescription = 'N/A'
 UNION ALL
 SELECT
 AcquisitionCostTypeCode                 = 'UDT'
 ,AcquisitionCostTypeDescription         = 'DEDUCTIONS/TAX'
 ,AcquisitionCostTypeInternalExternal    = 'External'
 ,TaxDescription = 'N/A'
 --BI-2235
 UNION ALL
 SELECT																				
 AcquisitionCostTypeCode                 = 'Y'
 ,AcquisitionCostTypeDescription         = 'LLOYD’S BROKER COMMISSION'
 ,AcquisitionCostTypeInternalExternal    = 'External'
 ,TaxDescription = 'N/A'
 WHERE NOT EXISTS (SELECT 1 FROM Staging_MDS.dbo.vw_deduction_quals dq WHERE dq.Code='Y')
 
 ) AS Source 
 	ON (
 		ISNULL(Source.AcquisitionCostTypeCode, 'Not Available') = ISNULL(Target.AcquisitionCostTypeCode, 'Not Available')
		AND ISNULL(Source.TaxDescription, 'Not Available') = ISNULL(Target.TaxDescription, 'Not Available')
 	)
 WHEN MATCHED THEN UPDATE
 	SET Target.[AcquisitionCostTypeCode]					= Source.[AcquisitionCostTypeCode],
 		Target.[AcquisitionCostTypeDescription]				= Source.[AcquisitionCostTypeDescription],
 		Target.[AcquisitionCostTypeInternalExternal]		= Source.[AcquisitionCostTypeInternalExternal],
        Target.AuditModifyDateTime	                        = GETDATE(),						
        Target.AuditModifyDetails	                        = 'Merge in ODS.usp_LoadAcquisitionCostType proc'
 WHEN NOT MATCHED BY TARGET THEN 
 		INSERT([AcquisitionCostTypeCode], [AcquisitionCostTypeDescription], [AcquisitionCostTypeInternalExternal],[TaxDescription],[AuditCreateDateTime],[AuditModifyDetails] )
 		VALUES(Source.[AcquisitionCostTypeCode], Source.[AcquisitionCostTypeDescription], Source.[AcquisitionCostTypeInternalExternal],[TaxDescription], GETDATE(), 'New add in  ODS.usp_LoadAcquisitionCostType proc'	)
 WHEN NOT MATCHED BY SOURCE THEN DELETE;
 
 
 IF (OBJECT_ID('tempdb..#AcquisitionCostType') IS NOT NULL)
 DROP TABLE #AcquisitionCostType;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'AcquisitionCostType';
GO


