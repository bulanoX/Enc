﻿CREATE PROC [ODS].[usp_LoadClaimDeductibleTracking]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ClaimDeductibleTracking
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

IF (OBJECT_ID('tempdb..#DeductibleTracking') IS NOT NULL)
DROP TABLE #DeductibleTracking

CREATE TABLE #DeductibleTracking
(
    FK_Claim                        bigint          NOT NULL
    ,DeductiblePaymentType          varchar(255)    NOT NULL
    ,BeazleyPaid                    bit             NOT NULL
    ,Recoverable                    bit             NOT NULL
	--,InsuredPaid                    bit             NOT NULL  
    ,PaymentDate                    datetime        NULL
    ,DeductibleAmount               numeric(19,2)   NOT NULL
	--,DeductibleNarrative            varchar(255)    NULL
    ,FK_ClaimCostCategory           bigint          NOT NULL

)

INSERT INTO #DeductibleTracking
(
    FK_Claim
    ,DeductiblePaymentType
    ,BeazleyPaid
    ,Recoverable
	--,InsuredPaid
    ,PaymentDate
    ,DeductibleAmount
	--,DeductibleNarrative
    ,FK_ClaimCostCategory  
)
SELECT
	FK_Claim                        = oc.PK_Claim
	,DeductiblePaymentType          = cdt.DeductiblePaymentType
	,BeazleyPaid                    = cdt.IsBeazleyPaid
	,Recoverable                    = cdt.IsRecovered
	--,InsuredPaid					= ISNULL(cdt.IsInsuredPaid ,0)
	,PaymentDate                    = cdt.PaymentDate
	,DeductibleAmount               = cdt.DeductibleAmount
	--,DeductibleNarrative            = NULL--cdt.DeductibleNarrative
	,FK_ClaimCostCategory           = ccc.PK_ClaimCostCategory
FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimDeductibleTracking cdt

INNER JOIN ODS.ClaimCostCategory ccc 
ON cdt.ClaimCostCategory = ccc.CCCostCategoryName

INNER JOIN ODS.Claim oc 
ON cdt.ClaimSourceId = oc.ClaimReference

WHERE cdt.SourceSystem = 'ClaimCenter'
AND(
ISNULL(cdt.AuditModifyDatetime, cdt.AuditCreateDateTime) >= @LastAuditDate
OR ISNULL(ccc.AuditModifyDatetime, ccc.AuditCreateDateTime) >= @LastAuditDate
OR ISNULL(oc.AuditModifyDatetime, oc.AuditCreateDateTime) >= @LastAuditDate
)
--AND cdt.IsActive = 1

-- Remove deactivated data
DELETE FROM ODS.ClaimDeductibleTracking  
WHERE [FK_Claim] NOT IN (SELECT PK_Claim FROM ODS.Claim)


          
MERGE ODS.ClaimDeductibleTracking target
USING 
(SELECT
	FK_Claim                    = dt.FK_Claim
	,DeductiblePaymentType      = dt.DeductiblePaymentType
	,BeazleyPaid                = dt.BeazleyPaid
	,Recoverable                = dt.Recoverable
	--,InsuredPaid                = ISNULL(dt.InsuredPaid, 0)
	,PaymentDate                = dt.PaymentDate
	,DeductibleAmount           = SUM(dt.DeductibleAmount)
	--,DeductibleNarrative        = dt.DeductibleNarrative
	,FK_ClaimCostCategory       = dt.FK_ClaimCostCategory
FROM #DeductibleTracking dt

GROUP BY
	dt.FK_Claim
	,dt.DeductiblePaymentType
	,dt.BeazleyPaid
	,dt.Recoverable
	--,dt.InsuredPaid
	,dt.PaymentDate
	--,dt.DeductibleNarrative
	,dt.FK_ClaimCostCategory) source
ON  target.FK_Claim               = source.FK_Claim
AND target.DeductiblePaymentType  = source.DeductiblePaymentType
AND target.BeazleyPaid            = source.BeazleyPaid
AND target.Recoverable            = source.Recoverable
AND target.PaymentDate            = source.PaymentDate
AND target.FK_ClaimCostCategory   = source.FK_ClaimCostCategory


WHEN MATCHED THEN
UPDATE SET
	 target.DeductibleAmount              = source.DeductibleAmount                                   
	,target.AuditModifyDateTime	          = GETDATE()						
    ,target.AuditModifyDetails	          = 'Merge in ODS.usp_LoadClaimDeductibleTracking proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(	FK_Claim
    ,DeductiblePaymentType
    ,BeazleyPaid
    ,Recoverable
	,PaymentDate
    ,DeductibleAmount
	,FK_ClaimCostCategory
	,AuditCreateDateTime
	,AuditModifyDetails

)
VALUES
	(source.FK_Claim
    ,source.DeductiblePaymentType
    ,source.BeazleyPaid
    ,source.Recoverable
	,source.PaymentDate
    ,source.DeductibleAmount
	,source.FK_ClaimCostCategory
	,GETDATE()
	,'New add in ODS.usp_LoadClaimDeductibleTracking proc'	
)
;

UPDATE c SET
HasDeductibleTrackingData = 1
FROM ODS.Claim c

INNER JOIN ODS.ClaimDeductibleTracking cd 
ON c.PK_Claim = cd.FK_Claim

IF (OBJECT_ID('tempdb..#DeductibleTracking') IS NOT NULL)
DROP TABLE #DeductibleTracking;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimDeductibleTracking';