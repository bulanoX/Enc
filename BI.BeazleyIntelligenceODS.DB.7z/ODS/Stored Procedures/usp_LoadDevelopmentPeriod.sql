﻿

CREATE PROCEDURE [ODS].[usp_LoadDevelopmentPeriod]
AS

SET NOCOUNT ON

DECLARE @MaxPeriod int
SELECT @MaxPeriod = MAX(MaxDevelopmentMonth)  + 3  FROM ODS.YOA --To create reversal records for ULR, we need periods up to 1 quarter in future

;WITH CTEPeriods AS
(
    SELECT
    DevelopmentMonth               = 1
    ,DevelopmentQuarter            = 1
    ,DevelopmentYear               = 1
    UNION ALL
    SELECT
    DevelopmentMonth               = cte.DevelopmentMonth + 1
    ,DevelopmentQuarter            = CAST(CEILING(CAST(cte.DevelopmentMonth + 1 AS float) / 3) AS int)
    ,DevelopmentYear               = CAST(CEILING(CAST(cte.DevelopmentMonth + 1 AS float) / 12) AS int)
    FROM
    CTEPeriods cte
    WHERE
    cte.DevelopmentMonth < @MaxPeriod
)
INSERT INTO ODS.DevelopmentPeriod
(
     DevelopmentMonth
     ,DevelopmentMonthName
     ,DevelopmentQuarter
     ,DevelopmentQuarterName
     ,DevelopmentYear
     ,DevelopmentYearName
)
SELECT
 DevelopmentMonth               = cte.DevelopmentMonth
 ,DevelopmentMonthName          = 'Month ' + CAST(cte.DevelopmentMonth AS varchar(4))
 ,DevelopmentQuarter            = cte.DevelopmentQuarter
 ,DevelopmentQuarterName        = 'Quarter ' + CAST(cte.DevelopmentQuarter AS varchar(4))
 ,DevelopmentYear               = cte.DevelopmentYear
 ,DevelopmentYearName           = 'Year ' + CAST(cte.DevelopmentYear AS varchar(4))
FROM
CTEPeriods cte
OPTION(MAXRECURSION 0);

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'DevelopmentPeriod';