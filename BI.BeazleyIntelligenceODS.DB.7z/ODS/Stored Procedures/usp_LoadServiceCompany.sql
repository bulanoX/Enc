﻿
CREATE PROCEDURE [ODS].[usp_LoadServiceCompany]
AS
SET NOCOUNT ON

IF (OBJECT_ID('tempdb..#ServiceCompany') IS NOT NULL)
DROP TABLE #ServiceCompany

CREATE TABLE #ServiceCompany
(	[IsUnknownMember] [bit] DEFAULT ((0)) NULL,
	[ServiceCompanyCode] [varchar](255) NOT NULL,
	[ServiceCompanyName] [varchar](255) NOT NULL,
)

/*Unknown member ServiceCompany */
   INSERT INTO #ServiceCompany
	(
		[IsUnknownMember]
		,[ServiceCompanyCode]
		,[ServiceCompanyName]
	) 
	SELECT
		[IsUnknownMember]           = 1
		,[ServiceCompanyCode]		= 'N/A'
		,[ServiceCompanyName]		= 'N/A'

INSERT INTO #ServiceCompany
(
	ServiceCompanyCode
	,ServiceCompanyName
)
SELECT DISTINCT
	ServiceCompanyCode	= s.ServiceCompanyCode
	,ServiceCompanyName	= s.ServiceCompanyName
FROM 
	Staging_MDS.MDS_Staging.ServiceCompany AS s

MERGE ODS.ServiceCompany AS TARGET

USING #ServiceCompany AS SOURCE

 ON TARGET.ServiceCompanyCode    = SOURCE.ServiceCompanyCode

WHEN MATCHED THEN

UPDATE SET 
  TARGET.IsUnknownMember                = SOURCE.IsUnknownMember
 ,TARGET.ServiceCompanyCode             = SOURCE.ServiceCompanyCode
 ,TARGET.ServiceCompanyName             = SOURCE.ServiceCompanyName
 ,TARGET.AuditModifyDateTime            = GETDATE()
 ,TARGET.AuditModifyDetails             = 'Merge in [ODS].[ServiceCompany] table'

WHEN NOT MATCHED BY TARGET THEN 

INSERT
(
     IsUnknownMember
	,ServiceCompanyCode
	,ServiceCompanyName
	,AuditModifyDetails

)
VALUES
(
     SOURCE.IsUnknownMember
	,SOURCE.ServiceCompanyCode
	,SOURCE.ServiceCompanyName
	,'New in [ODS].[ServiceCompany] table' 
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;

IF (OBJECT_ID('tempdb..#ServiceCompany') IS NOT NULL)
DROP TABLE #ServiceCompany