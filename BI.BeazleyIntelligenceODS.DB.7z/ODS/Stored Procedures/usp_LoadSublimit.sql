﻿CREATE PROCEDURE [ODS].[usp_LoadSublimit]
AS

SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Sublimit

SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')


IF OBJECT_ID('tempdb..#SublimitTemp') IS NOT NULL
DROP TABLE #SublimitTemp

CREATE TABLE #SublimitTemp 
(
    [IsUnknownMember]		BIT NOT NULL,
	[SublimitCode]			VARCHAR(255) NOT NULL,
	[SublimitName]			VARCHAR(255) NULL
)

-- Insert Unknown member
INSERT INTO #SublimitTemp
(
	IsUnknownMember
	,SublimitCode
	,SublimitName
) 
SELECT
	IsUnknownMember       = 1
	,SublimitCode		  = 'N/A'
	,SublimitName         = 'N/A'

;WITH CTE_Sublimit (SublimitCode, SublimitName, RowNo)
AS
(
	SELECT DISTINCT
		 SublimitCode	= LTRIM(RTRIM(sl.LimitCode))
		,SublimitName	= sl.LimitName
		,RowNo			= ROW_NUMBER() OVER (PARTITION BY LTRIM(RTRIM(sl.LimitCode)) ORDER BY sl.LimitName)
	FROM BeazleyIntelligenceDataContract.Outbound.vw_SectionLimit sl
	WHERE ISNULL(sl.LimitCode,'') <> ''
	--	AND sl.SourceSystem IN ('Eurobase','Unirisx','Gamechanger','CIPS' , 'myBeazley')
	--	AND (sl.AuditCreateDatetime > @LastAuditDate OR sl.AuditModifyDatetime > @LastAuditDate)
) 

INSERT INTO #SublimitTemp
(
	IsUnknownMember
	,SublimitCode
	,SublimitName
)
SELECT 
	IsUnknownMember = 0
	,SublimitCode	= sl.SublimitCode
	,SublimitName	= sl.SublimitName
FROM CTE_Sublimit sl
WHERE sl.RowNo = 1




MERGE ODS.Sublimit AS TARGET
USING 
#SublimitTemp AS SOURCE
ON (
		ISNULL(Source.SublimitCode, 'Not Available') = ISNULL(Target.SublimitCode, 'Not Available')
	AND ISNULL(Source.IsUnknownMember, 'Not Available') = ISNULL(Target.IsUnknownMember, 'Not Available')
)
WHEN MATCHED THEN
UPDATE SET
   target.SublimitCode				= source.SublimitCode
   ,target.SublimitName             = source.SublimitName
   ,target.AuditModifyDateTime		= GETDATE()						
   ,target.AuditModifyDetails		= 'Merge in ODS.usp_LoadSublimit proc' 

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    IsUnknownMember
    ,SublimitCode
    ,SublimitName
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
    source.IsUnknownMember
    ,source.SublimitCode
    ,source.SublimitName
	,GETDATE()
	,'New add in ODS.usp_LoadSublimit proc'	
)
WHEN NOT MATCHED BY SOURCE THEN DELETE
;