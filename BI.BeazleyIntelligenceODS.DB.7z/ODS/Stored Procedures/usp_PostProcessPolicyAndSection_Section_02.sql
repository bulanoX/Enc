﻿CREATE PROC [ODS].[usp_PostProcessPolicyAndSection_Section_02]
AS

SET NOCOUNT ON


/*Days between quote/bind and earliest rationale date*/
UPDATE s SET
DaysBetweenQBAndPERDate                = DATEDIFF(DAY, s.QuoteOrBindDate, p.EarliestRationaleDate)
,DaysBetweenQBAndPERDateName		   = [ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, p.EarliestRationaleDate))
FROM
ODS.Section s
INNER JOIN
ODS.Policy p ON
s.FK_Policy = p.PK_Policy
WHERE
p.PK_Policy <> 0


/*Update IsSlipAttached field in section*/

UPDATE sec

SET IsSlipAttached = 'Yes'

FROM ODS.Section sec

INNER JOIN ODS.Document doc ON
sec.PK_Section = doc.FK_Section

INNER JOIN ods.DocumentType doctype ON
doc.FK_DocumentType = doctype.PK_DocumentType

WHERE doctype.DocumentTypeName = 'Slips'

-- Default to N/A the rest of the sections of a policy where there is at least one slip attached in one section already.
UPDATE s

SET IsSlipAttached = CASE WHEN s.IsSlipAttached = 'Yes' THEN 'Yes' 
                     ELSE      'N/A' 
                     END

FROM ODS.Section s

INNER JOIN ODS.Policy p ON
s.FK_Policy = p.PK_Policy

INNER JOIN(
	        SELECT DISTINCT p.PK_Policy

	        FROM ODS.Policy p
	        
            INNER JOIN ODS.Section s
	        ON  p.PK_Policy = s.FK_Policy
	        AND s.IsSlipAttached = 'Yes'
           )sa ON
p.PK_Policy = sa.PK_Policy



/* 
Update the BeazleyOfficeLocationDerived, BeazleyOfficeLocationDerivedCountry/Region fields in the ODS.Section table 
The quality of the BeazleyOfficeLocation field in the source systems is not great so we have implemented these new 
derived fields and populated them with the rules below to support the BI Qlik dashboards.

Rule 1	Do not display the BeazleyOfficeLocation from Eurobase for policies which have another source system policy reference (rekeyed).			
Rule 2	If the section reference matches the source system listed in the 'Source system' tab, use the allocated country.				
Rule 3	If the binder type = 4, look up to the service company location tab. Look up the facility left 6 characters and match to the allocated country.				
Rule 4	If the section reference matches the section reference displayed in the location from section LVL, select the corresponding country.				
Rule 5	Look up to the UW defaults, match the UW to the allocated location.
Rule 6  For the remaining values use the BeazleyOfficeLocation already extracted from the source system				

-- Used for testing
SELECT 
     SectionReference
    ,BeazleyOfficeLocation
    ,BeazleyOfficeLocationDerived
    ,BeazleyOfficeLocationDerivedCountry
    ,BeazleyOfficeLocationDerivedRegion
	,pol.SourceSystem

FROM ODS.Section sec

INNER JOIN ODS.Policy pol
ON sec.FK_Policy = pol.PK_Policy

WHERE BeazleyOfficeLocationDerived IS NOT NULL
AND pol.IsQuote = 0


--Reset
UPDATE sec
SET sec.BeazleyOfficeLocationDerived = NULL
FROM ODS.Section sec

*/

-- Rule 02: If the section reference matches the source system listed in the 'Source system' tab, use the allocated country.

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = src.Country_Name

FROM ODS.Section sec

INNER JOIN ODS.Policy pol
ON sec.FK_Policy = pol.PK_Policy

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationSourceSystemRule] src
ON pol.SourceSystem = RTRIM(LTRIM(src.SourceSystem_Name))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 03: If the binder type = 4, look up to the service company location tab. Look up the facility left 6 characters and match to the allocated country

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = bin.Country_Name

FROM ODS.Section sec

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationServiceCompanyLocationRule] bin
ON LEFT(sec.Facility,6) = RTRIM(LTRIM(LEFT(bin.FacilityReference,6)))

WHERE sec.BinderType = '4'
  AND sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 04: If the section reference matches the section reference displayed in the location from section LVL, select the corresponding country

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = offi.Country_Name

FROM ODS.Section sec

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationFromSectionLVLRule] offi
ON sec.SectionReference = RTRIM(LTRIM(offi.SectionReference))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 05: look up to the UW defaults, match the UW to the allocated location
UPDATE sec

SET sec.BeazleyOfficeLocationDerived = offi.Country_Name

FROM ODS.Section sec

INNER JOIN ODS.Underwriter und
ON sec.FK_Underwriter = und.PK_Underwriter

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationUnderwriterDefaultsRule] offi
ON und.UnderwriterName = RTRIM(LTRIM(offi.Underwriter))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 01:
UPDATE sec

SET sec.BeazleyOfficeLocationDerived = s_source.BeazleyOfficeLocation

FROM ODS.Section sec

INNER JOIN ODS.Policy p 
ON sec.FK_Policy = p.PK_Policy

INNER JOIN ODS.Section s_source
ON sec.PK_Section = s_source.FK_LinkedSynergySection

WHERE sec.PK_Section <> 0
  AND p.SourceSystem = 'Eurobase'
  AND sec.BeazleyOfficeLocationDerived IS NULL
  AND COALESCE(s_source.BeazleyOfficeLocation,'')<>''

  -- Rule 06:
--UPDATE sec

--SET sec.BeazleyOfficeLocationDerived = sec.BeazleyOfficeLocation

--FROM ODS.Section sec

--WHERE sec.PK_Section <> 0
--  AND sec.BeazleyOfficeLocationDerived IS NULL
--  AND COALESCE(sec.BeazleyOfficeLocation,'')<>''


  ---- Now calculate the country and region fields based on the mapping tables in the staging schema.

  UPDATE sec

  SET sec.[FK_OfficeLocationCountry]		  = 0 --co.PK_OfficeLocationCountry 
     ,sec.[FK_OfficeLocationRegion]			  = 0 -- re.PK_OfficeLocationRegion
	 ,sec.BeazleyOfficeLocationDerivedRegion  = RTRIM(LTRIM(re.[Name]))
	 ,sec.BeazleyOfficeLocationDerivedCountry = RTRIM(LTRIM(co.[Name]))
  FROM ODS.Section sec

  LEFT OUTER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationCountry] co --UC.OfficeLocationCountry co
  ON sec.BeazleyOfficeLocationDerived = RTRIM(LTRIM(co.[Name]))

  LEFT OUTER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationRegion] re --UC.OfficeLocationRegion re
  ON RTRIM(LTRIM(co.[Region_Code])) = RTRIM(LTRIM(re.[Code]))
    

UPDATE s
SET	s.KeyBrokerName			= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerName
									WHEN s.CarrierIndicator IN ('BUSA','BAIC','BUSB','BESI') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerName
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerName
	
								END
	,s.KeyBrokerSourceId	= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerNumber
									WHEN s.CarrierIndicator IN ('BUSA','BAIC','BUSB','BESI') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerNumber
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerNumber
	
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
LEFT JOIN  ODS.PartyBroker pb 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerPlacing
LEFT JOIN ODS.PartyBroker pb_producing 
	ON pb_producing.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Placing Broker'	
WHERE s.sourcesystem IN ('BeazleyAccess','FDR','myBeazley','BeazleyTrade IDL','EazyPro','Etrek','Eurobase','US High Value Homeowners', 'USHVH','Unirisx')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')


UPDATE s
SET	s.KeyBrokerName			= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerName
									WHEN  s.sourcesystem = 'Unirisx' then
										 CASE  --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
											   --WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
											   --THEN 'BOWRING MARSH'
											  WHEN pb.BrokerName = 'BEAZLEY POOL RE'
											  THEN 'N/A'
										 ELSE pb.BrokerName
										 END	
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerName
		
								END
	,s.KeyBrokerSourceId	= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerNumber
									WHEN  s.sourcesystem = 'Unirisx' THEN
									      CASE --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
												  /*WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
													   THEN (
													SELECT TOP 1  BrokerNumber
													FROM  BeazleyIntelligenceODS.ODS.PartyBroker PB
													INNER JOIN BeazleyIntelligenceODS.ODS.policy p on p.FK_PartyBrokerProducing = pb.PK_PartyBroker
													WHERE BrokerName = 'BOWRING MARSH'
													AND SourceSystem = 'Unirisx')
													*/

												WHEN pb.BrokerName = 'BEAZLEY POOL RE'
												THEN 0
										  ELSE pb.BrokerNumber
										  END
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerNumber
								
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.PartyBroker pb 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  ODS.PartyBroker pb_placing 
	ON pb_placing.PK_PartyBroker = p.FK_PartyBrokerPlacing
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Producing Broker'
WHERE s.sourcesystem IN ('myBeazley', 'Unirisx','Eurobase')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')

UPDATE s
SET	s.KeyBrokerName	= 'Unknown'
FROM ODS.Section s
WHERE s.KeyBrokerName IS NULL
	  OR s.KeyBrokerName = 'N/A'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR s.KeyBrokerName = ''

UPDATE s
SET	s.KeyBrokerSourceId	= 'Unknown'
FROM ODS.Section s
WHERE s.KeyBrokerSourceId IS NULL
	  OR s.KeyBrokerSourceId = 'N/A' 
	  OR s.KeyBrokerSourceId = '0'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR ISNULL(s.KeyBrokerName,'') = ''


UPDATE s
SET	s.KeyBrokerName			= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerName
									WHEN s.CarrierIndicator IN ('BUSA','BAIC') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerName
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='Non BICI/BUSA/BAIC' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerName
	
								END
	,s.KeyBrokerSourceId	= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerNumber
									WHEN s.CarrierIndicator IN ('BUSA','BAIC') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerNumber
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='Non BICI/BUSA/BAIC' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerNumber
	
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
LEFT JOIN  ODS.PartyBroker pb 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerPlacing
LEFT JOIN ODS.PartyBroker pb_producing 
	ON pb_producing.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Placing Broker'	
WHERE s.sourcesystem IN ('BeazleyAccess','FDR','myBeazley','BeazleyTrade IDL','EazyPro','Etrek','Eurobase','US High Value Homeowners', 'USHVH','Unirisx')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')


UPDATE s
SET	s.KeyBrokerName			= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerName
									WHEN  s.sourcesystem = 'Unirisx' then
										 CASE  --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
											   --WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
											   --THEN 'BOWRING MARSH'
											  WHEN pb.BrokerName = 'BEAZLEY POOL RE'
											  THEN 'N/A'
										 ELSE pb.BrokerName
										 END	
									WHEN s.CarrierIndicator ='Non BICI/BUSA/BAIC' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerName
		
								END
	,s.KeyBrokerSourceId	= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerNumber
									WHEN  s.sourcesystem = 'Unirisx' THEN
									      CASE --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
												  /*WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
													   THEN (
													SELECT TOP 1  BrokerNumber
													FROM  BeazleyIntelligenceODS.ODS.PartyBroker PB
													INNER JOIN BeazleyIntelligenceODS.ODS.policy p on p.FK_PartyBrokerProducing = pb.PK_PartyBroker
													WHERE BrokerName = 'BOWRING MARSH'
													AND SourceSystem = 'Unirisx')
													*/

												WHEN pb.BrokerName = 'BEAZLEY POOL RE'
												THEN 0
										  ELSE pb.BrokerNumber
										  END
									WHEN s.CarrierIndicator ='Non BICI/BUSA/BAIC' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerNumber
								
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM ODS.Policy p 	
INNER JOIN ODS.Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.PartyBroker pb 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  ODS.PartyBroker pb_placing 
	ON pb_placing.PK_PartyBroker = p.FK_PartyBrokerPlacing
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Producing Broker'
WHERE s.sourcesystem IN ('myBeazley', 'Unirisx','Eurobase')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')

UPDATE s
SET	s.KeyBrokerName	= 'Unknown'
FROM ODS.Section s
WHERE s.KeyBrokerName IS NULL
	  OR s.KeyBrokerName = 'N/A'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR s.KeyBrokerName = ''

UPDATE s
SET	s.KeyBrokerSourceId	= 'Unknown'
FROM ODS.Section s
WHERE s.KeyBrokerSourceId IS NULL
	  OR s.KeyBrokerSourceId = 'N/A' 
	  OR s.KeyBrokerSourceId = '0'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR ISNULL(s.KeyBrokerName,'') = ''



-- Update ESG Trifocus
UPDATE s
SET LinkedESGTrifocus = t.TriFocusName
FROM ODS.Section s
INNER JOIN ODS.TriFocus t ON s.FK_LinkedESGTrifocus = t.PK_TriFocus
where ISNULL(FK_LinkedESGTrifocus, 0) <> 0

UPDATE sec
SET	  NotifiedIndividualsExcDuplicates          = NotifiedIndividuals      
     ,NotifiedIndividualsNameExcDuplicates		= NotifiedIndividualsName
FROM 
ODS.Section sec

UPDATE l
SET  NumberOfSectionsExcLBS = 0
	,NotifiedIndividualsExcDuplicates          = CASE WHEN s.NotifiedIndividuals IS NULL THEN NULL ELSE 0 END    
    ,NotifiedIndividualsNameExcDuplicates	   = NULL
FROM ODS.Section s
INNER JOIN ODS.Section l 
ON s.FK_Policy = l.FK_Policy 
AND s.FK_ClassOfBusiness = l.FK_ClassOfBusiness
AND ISNULL(s.LimitAmountInLimitCCY,0) = ISNULL(l.LimitAmountInLimitCCY,0)
AND ISNULL(s.ExcessAmountInLimitCCY,0) = ISNULL(l.ExcessAmountInLimitCCY,0)
AND ISNULL(s.DeductibleAmountInLimitCCY,0) = ISNULL(l.DeductibleAmountInLimitCCY,0)
INNER JOIN ODS.UnderwritingPlatform ups
ON ups.PK_UnderwritingPlatform = s.FK_UnderwritingPlatform
INNER JOIN ODS.UnderwritingPlatform upl
ON upl.PK_UnderwritingPlatform = l.FK_UnderwritingPlatform
WHERE ups.UnderwritingPlatformCode IN ('SYND','LBSM','LBSF')
AND upl.UnderwritingPlatformCode = 'LBS'

UPDATE s
SET RemappedDivision = ISNULL(r.DivisionOverride ,t.Division)
FROM ODS.Section s
INNER JOIN ODS.TriFocus t ON s.FK_TriFocus = t.PK_TriFocus
LEFT JOIN  Staging_MDS.MDS_Staging.RemappedDivision r ON t.TriFocusName = r.Trifocus_Name
AND (CASE WHEN r.SourceSystem_Name IS NOT NULL THEN r.SourceSystem_Name ELSE ISNULL(s.SourceSystem,'') END) =ISNULL(s.SourceSystem,'')
AND (CASE WHEN r.Product IS NOT NULL THEN r.Product ELSE ISNULL(s.Product,'') END) = ISNULL(s.Product,'')
AND (CASE WHEN r.Coverage IS NOT NULL THEN r.Coverage ELSE ISNULL(s.CoverageName,'') END) = ISNULL(s.CoverageName,'')
AND (CASE WHEN r.OfficeLocation IS NOT NULL THEN r.OfficeLocation ELSE ISNULL(s.BeazleyOfficeLocation,'') END) = ISNULL(s.BeazleyOfficeLocation,'')

