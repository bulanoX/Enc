CREATE PROC [ODS].[usp_PostProcessPolicyAndSection]
AS

SET NOCOUNT ON


DROP TABLE IF EXISTS #Policy
CREATE TABLE #Policy
(
	
PK_Policy										BIGINT           NOT NULL,
 FK_Submission									BIGINT            NULL,
 FK_CRMBroker									BIGINT            NULL,
 FK_PartyBrokerProducing						BIGINT            NULL,
 FK_PartyBrokerPlacing							BIGINT            NULL,
 PolicyReference								VARCHAR (255)    NOT NULL,
 ExpiringPolicy									VARCHAR (255)   NULL,
 BrokerContactName								NVARCHAR (255)  NULL,
 SubmittingBrokerContactName					 NVARCHAR (255)  NULL,
 SourceSystem									 VARCHAR (255)   NOT NULL,
 FACEvidenced									BIT NULL,
 NotifiedIndividualsMaximum						INT NULL,
 IsQuote										BIT NULL,
 AdmittedNonAdmitted							 VARCHAR (255)   NULL,
 AnySectionHasExceptionDocument					BIT NULL,    
 EarliestRationaleQuestionnaireDate				DATETIME        NULL,
 EarliestRationaleDocumentDate					 DATETIME        NULL,
 EarliestRationaleDate							 DATETIME        NULL,
 RationaleCompletionMethod						 VARCHAR (255)   NULL,
 EarliestExceptionDocumentDate					DATETIME        NULL,
 EarliestFirstLiveDate							 DATETIME        NULL,
 LatestFirstLiveDate							DATETIME        NULL,
 ConsecutiveNumberOfPolicyRenewals				INT NULL,
 BrokerAccessPolicyNumber						VARCHAR (255)   NULL,

)

INSERT INTO #Policy
(
	PK_Policy							
	 ,FK_Submission						
	 ,FK_CRMBroker						
	 ,FK_PartyBrokerProducing			
	 ,FK_PartyBrokerPlacing				
	 ,PolicyReference					
	 ,ExpiringPolicy						
	 ,BrokerContactName					
	 ,SubmittingBrokerContactName		
	 ,SourceSystem						
	 ,FACEvidenced						
	 ,NotifiedIndividualsMaximum			
	 ,IsQuote							
	 ,AdmittedNonAdmitted				
	 ,AnySectionHasExceptionDocument		
	 ,EarliestRationaleQuestionnaireDate
	 ,EarliestRationaleDocumentDate		
	 ,EarliestRationaleDate				
	 ,RationaleCompletionMethod			
	 ,EarliestExceptionDocumentDate		
	 ,EarliestFirstLiveDate				
	 ,LatestFirstLiveDate				
	 ,ConsecutiveNumberOfPolicyRenewals
	 ,BrokerAccessPolicyNumber			
	
)
SELECT 
	PK_Policy							
	, FK_Submission						
	, FK_CRMBroker						
	, FK_PartyBrokerProducing			
	, FK_PartyBrokerPlacing				
	, PolicyReference					
	, ExpiringPolicy						
	, BrokerContactName					
	, SubmittingBrokerContactName		
	, SourceSystem						
	, FACEvidenced						
	, NotifiedIndividualsMaximum			
	, IsQuote							
	, AdmittedNonAdmitted				
	, AnySectionHasExceptionDocument		
	, EarliestRationaleQuestionnaireDate
	, EarliestRationaleDocumentDate		
	, EarliestRationaleDate				
	, RationaleCompletionMethod			
	, EarliestExceptionDocumentDate		
	, EarliestFirstLiveDate				
	, LatestFirstLiveDate				
	, ConsecutiveNumberOfPolicyRenewals
	, BrokerAccessPolicyNumber			
	
	
FROM ODS.Policy p


DROP TABLE IF EXISTS #Section
CREATE TABLE #Section
(
 PK_Section														BIGINT           NOT NULL,
 FK_Policy														BIGINT            NULL,
 FK_Trifocus													BIGINT            NULL,
 FK_ExceptionDocumentDate 										DATETIME         NULL,         
 FK_ContractCertaintyDocumentDate								DATETIME         NULL,
 FK_ExpiryDateInForce											DATETIME         NULL,
 FK_FirstLiveDate												DATETIME         NULL,
 FK_Facility													BIGINT            NULL,
 FK_Underwriter													BIGINT            NULL,
 FK_LinkedSynergySection										BIGINT            NULL,
 FK_OfficeLocationCountry										BIGINT            NULL,
 FK_OfficeLocationRegion										BIGINT            NULL,
 FK_LinkedESGTrifocus											BIGINT            NULL,
 FK_ClassOfBusiness												BIGINT            NULL,
 FK_UnderwritingPlatform										BIGINT            NULL,
 SectionReference												VARCHAR (255)    NOT NULL,
 Product														VARCHAR (255)    NULL,
 EngineeringConstructionExpiryDate								DATETIME         NULL,
 EngineeringConstructionExpiryDateName							VARCHAR (50)     NULL,
 USQuakeMultiplier												NUMERIC (19, 12) NULL,
 USWindMultiplier												NUMERIC (19, 12) NULL,
 USNonCatMultiplier												NUMERIC (19, 12) NULL,
 NonUSCatMultiplier												NUMERIC (19, 12) NULL,
 NonUSNonCatMultiplier											NUMERIC (19, 12) NULL,
 OccurrenceTerrorism											INT              NULL,
 OccurrenceSabotage												INT              NULL,
 OccurrenceRsccmd												INT              NULL,
 OccurrenceInsurrection											INT              NULL,
 OccurrenceRevolution      										INT              NULL,
 OccurrenceRebellion       										INT              NULL,
 OccurrenceMutiny          										INT              NULL,
 OccurrenceCoupDEtat       										INT              NULL,
 OccurrenceWar             										INT              NULL,
 OccurrenceCivilWar												INT              NULL,        
 HoursClause													INT              NULL,        
 OccurrenceTerrorismName										VARCHAR (100)    NULL,
 OccurrenceSabotageName    										VARCHAR (100)    NULL,
 OccurrenceRSCCMDName      										VARCHAR (100)    NULL,
 OccurrenceInsurrectionName										VARCHAR (100)    NULL,
 OccurrenceRevolutionName  										VARCHAR (100)    NULL,
 OccurrenceRebellionName   										VARCHAR (100)    NULL,
 OccurrenceMutinyName      										VARCHAR (100)    NULL,
 OccurrenceCoupDEtatName   										VARCHAR (100)    NULL,
 OccurrenceWarName         										VARCHAR (100)    NULL,
 OccurrenceCivilWarName    										VARCHAR (100)    NULL,
 HoursClauseName												VARCHAR (100)    NULL,
 HasRationaleDocument											BIT              NULL,
 RationaleDocumentDate											DATETIME         NULL,
 HasRationaleDocumentName										VARCHAR (100)    NULL,
 RationaleDocumentDateName										VARCHAR (100)    NULL,
 RationaleDateName												VARCHAR (100)    NULL,
 HasExceptionDocument											BIT				 NULL,
 ExceptionDocumentDate											DATETIME         NULL,
 HasExceptionDocumentName										VARCHAR (100)    NULL,
 ExceptionDocumentDateName									    VARCHAR (100)    NULL,
 RationaleCompletionMethod										VARCHAR (255)    NULL,
 HasContractCertaintyDocument									BIT				NULL,  
 ContractCertaintyDocumentDate									DATETIME         NULL,
 DaysBetweenQBAndCCDocumentDate									INT              NULL,
 ContractCertaintyDocumentDateName								VARCHAR (50)     NULL,
 DaysBetweenQBAndCCDocumentDateName								VARCHAR (100)    NULL,
 HasContractCertaintyDocumentName								VARCHAR (100)    NULL,
 ContractCertaintyPrimaryCompleteDate							DATETIME         NULL,
 LatestPICCPeriod												VARCHAR (255)    NULL,
 MissingPICCTransactions										INT              NULL,   
 HasMissingPICCTransactions										BIT				NULL,              
 MissingPICCTransactionsName									 VARCHAR (100)    NULL,
 HasMissingPICCTransactionsName									VARCHAR (100)    NULL,
 ExpiryDateInForce													 DATETIME         NULL,
 ExternalAcquisitionCostMultiplier								NUMERIC (19, 12) NULL,
 ExternalAcquisitionCostMultiplierName							VARCHAR (50)     NULL,
 OriginalEPITotalAcquisitionCostMultiplier						NUMERIC (19, 12) NULL,
 RateChangeControlComplete										BIT NULL,
 RationaleQuestionnaireComplete									BIT NULL,
 RationaleQuestionnaireDate										DATETIME         NULL,
 RationaleDate													DATETIME         NULL,
 RationaleQuestionnaireCompleteName								VARCHAR (100)    NULL,
 RateChangeControlCompleteName									VARCHAR (100)    NULL,
 RationaleQuestionnaireDateName									VARCHAR (50)     NULL,
 RateChangeExposureMultiplier									NUMERIC (19, 12) NULL,       
 RateChangeRiskMultiplier										NUMERIC (19, 12) NULL,      
 RateChangeDeductibleMultiplier									NUMERIC (19, 12) NULL,
 RateChangeLimitMultiplier										NUMERIC (19, 12) NULL,    
 RateChangeTermsAndConditionsMultiplier							NUMERIC (19, 12) NULL,
 RateChangeOtherMultiplier										NUMERIC (19, 12) NULL,
 HasTreatyAggsTerritory											BIT				NULL,
 HasTreatyAggsTerritoryName										VARCHAR (100)    NULL,
 FirstLiveDate     												DATETIME         NULL,
 FirstLiveDateName												VARCHAR (50)     NULL,
 IsSynergySection												BIT					 NULL,
 HasUnderwriterAuthorityException								BIT				NULL,
 HasUnderwriterAuthorityExceptionName							VARCHAR (100)    NULL,
 ContractCertaintyStatus										VARCHAR (255)    NOT NULL,
 ContractCertaintyStatusSortOrder								INT NULL,
 ContractCertaintyPreBindComplete								BIT NULL,
 ContractCertaintyPreBindOnTime									BIT NULL,
 ContractCertaintyPreBindOnTimeName								VARCHAR (100)    NULL,
 ContractCertaintyPreBindCompleteName							VARCHAR (100)    NULL,
 ContractCertaintyPreBindSignatureDate							DATETIME         NULL,
 ContractCertaintyRequired										BIT				NULL,
 ContractCertaintyRequiredName									VARCHAR (100)    NULL,
 ExpiryDate														DATETIME         NULL,
 QuoteOrBindDate												DATETIME         NULL,
 ExpectedPICCTransactions										INT NULL,
 IsDeclaration													BIT NULL,
 IsFacility														BIT NULL,
 BinderType														VARCHAR (255)    NULL,
 IsBreachResponseDummy											BIT NULL,
 SectionReferenceSectionIdentifier								VARCHAR (255)    NULL,
 IsBeazleyLead													BIT NULL,
 SourceSystem													VARCHAR (255)    NULL,
 IsBeazleyLeadName												VARCHAR (100)    NULL,
 NumberOfBeazleyLed												INT NULL,
 NotifiedIndividuals											INT NULL,
 IsUnknownMember												BIT NULL,
 CarrierIndicator												VARCHAR (255)    NULL,
 IsRenewal														BIT NULL,
 KeyBrokerName													VARCHAR (255)    NULL,
 KeyBrokerSourceId												VARCHAR (255)    NULL,
 KeyBrokerSubGroup												VARCHAR (255)    NULL,
 KeyBrokerGroup													VARCHAR (255)    NULL,
 KeyBrokerCity													VARCHAR (255)    NULL,
 KeyBrokerCountry												VARCHAR (255)    NULL,
 EarliestLPSOPremiumSigningNumberName							VARCHAR (255)    NULL,
 EarliestLPSOPremiumSigningNumber								INT NULL,
 LatestLPSOPremiumSigningNumberName								VARCHAR (255)    NULL,
 LatestLPSOPremiumSigningNumber									INT NULL,
 DaysBetweenQBAndPERDate										INT NULL,
 DaysBetweenQBAndPERDateName									VARCHAR (100)    NULL,
 IsSlipAttached													VARCHAR (255) NULL,
 BeazleyOfficeLocationDerived									VARCHAR (255) NULL,
 Facility														VARCHAR (255)    NULL,
 BeazleyOfficeLocationDerivedRegion								VARCHAR (255)    NULL,
 BeazleyOfficeLocationDerivedCountry							VARCHAR (255)    NULL,
 LinkedESGTrifocus												NVARCHAR (255)   NULL,
 NotifiedIndividualsExcDuplicates								INT NULL,
 NotifiedIndividualsNameExcDuplicates							NVARCHAR (150)   NULL,
 NotifiedIndividualsName										NVARCHAR (150)   NULL,
 NumberOfSectionsExcLBS											INT NULL,
 LimitAmountInLimitCCY											NUMERIC (19, 4)  NULL,
 ExcessAmountInLimitCCY											NUMERIC (19, 4)  NULL,
 DeductibleAmountInLimitCCY										NUMERIC (19, 4)  NULL,
 RemappedDivision												VARCHAR (255)    NULL,
 CoverageName													VARCHAR (255)    NULL,
 BeazleyOfficeLocation											VARCHAR (255)    NULL
)

INSERT INTO #Section
(
PK_Section														
,FK_Policy														
,FK_Trifocus													
,FK_ExceptionDocumentDate 										
,FK_ContractCertaintyDocumentDate								
,FK_ExpiryDateInForce											
,FK_FirstLiveDate												
,FK_Facility													
,FK_Underwriter													
,FK_LinkedSynergySection										
,FK_OfficeLocationCountry										
,FK_OfficeLocationRegion										
,FK_LinkedESGTrifocus											
,FK_ClassOfBusiness												
,FK_UnderwritingPlatform										
,SectionReference												
,Product														
,EngineeringConstructionExpiryDate								
,EngineeringConstructionExpiryDateName							
,USQuakeMultiplier												
,USWindMultiplier												
,USNonCatMultiplier												
,NonUSCatMultiplier												
,NonUSNonCatMultiplier											
,OccurrenceTerrorism											
,OccurrenceSabotage												
,OccurrenceRsccmd												
,OccurrenceInsurrection											
,OccurrenceRevolution      										
,OccurrenceRebellion       										
,OccurrenceMutiny          										
,OccurrenceCoupDEtat       										
,OccurrenceWar             										
,OccurrenceCivilWar												
,HoursClause													
,OccurrenceTerrorismName										
,OccurrenceSabotageName    										
,OccurrenceRSCCMDName      										
,OccurrenceInsurrectionName										
,OccurrenceRevolutionName  										
,OccurrenceRebellionName   										
,OccurrenceMutinyName      										
,OccurrenceCoupDEtatName   										
,OccurrenceWarName         										
,OccurrenceCivilWarName    										
,HoursClauseName												
,HasRationaleDocument											
,RationaleDocumentDate											
,HasRationaleDocumentName										
,RationaleDocumentDateName										
,RationaleDateName												
,HasExceptionDocument											
,ExceptionDocumentDate											
,HasExceptionDocumentName										
,ExceptionDocumentDateName									    
,RationaleCompletionMethod										
,HasContractCertaintyDocument									
,ContractCertaintyDocumentDate									
,DaysBetweenQBAndCCDocumentDate									
,ContractCertaintyDocumentDateName								
,DaysBetweenQBAndCCDocumentDateName								
,HasContractCertaintyDocumentName								
,ContractCertaintyPrimaryCompleteDate							
,LatestPICCPeriod												
,MissingPICCTransactions										
,HasMissingPICCTransactions										
,MissingPICCTransactionsName									
,HasMissingPICCTransactionsName									
,ExpiryDateInForce												
,ExternalAcquisitionCostMultiplier								
,ExternalAcquisitionCostMultiplierName							
,OriginalEPITotalAcquisitionCostMultiplier						
,RateChangeControlComplete										
,RationaleQuestionnaireComplete									
,RationaleQuestionnaireDate										
,RationaleDate													
,RationaleQuestionnaireCompleteName								
,RateChangeControlCompleteName									
,RationaleQuestionnaireDateName									
,RateChangeExposureMultiplier									
,RateChangeRiskMultiplier										
,RateChangeDeductibleMultiplier									
,RateChangeLimitMultiplier										
,RateChangeTermsAndConditionsMultiplier							
,RateChangeOtherMultiplier										
,HasTreatyAggsTerritory											
,HasTreatyAggsTerritoryName										
,FirstLiveDate     												
,FirstLiveDateName												
,IsSynergySection												
,HasUnderwriterAuthorityException								
,HasUnderwriterAuthorityExceptionName							
,ContractCertaintyStatus										
,ContractCertaintyStatusSortOrder								
,ContractCertaintyPreBindComplete								
,ContractCertaintyPreBindOnTime									
,ContractCertaintyPreBindOnTimeName								
,ContractCertaintyPreBindCompleteName							
,ContractCertaintyPreBindSignatureDate							
,ContractCertaintyRequired										
,ContractCertaintyRequiredName									
,ExpiryDate														
,QuoteOrBindDate												
,ExpectedPICCTransactions										
,IsDeclaration													
,IsFacility														
,BinderType														
,IsBreachResponseDummy											
,SectionReferenceSectionIdentifier								
,IsBeazleyLead													
,SourceSystem													
,IsBeazleyLeadName												
,NumberOfBeazleyLed												
,NotifiedIndividuals											
,IsUnknownMember												
,CarrierIndicator												
,IsRenewal														
,KeyBrokerName													
,KeyBrokerSourceId												
,KeyBrokerSubGroup												
,KeyBrokerGroup													
,KeyBrokerCity													
,KeyBrokerCountry												
,EarliestLPSOPremiumSigningNumberName							
,EarliestLPSOPremiumSigningNumber								
,LatestLPSOPremiumSigningNumberName								
,LatestLPSOPremiumSigningNumber									
,DaysBetweenQBAndPERDate										
,DaysBetweenQBAndPERDateName									
,IsSlipAttached													
,BeazleyOfficeLocationDerived									
,Facility														
,BeazleyOfficeLocationDerivedRegion								
,BeazleyOfficeLocationDerivedCountry							
,LinkedESGTrifocus												
,NotifiedIndividualsExcDuplicates								
,NotifiedIndividualsNameExcDuplicates							
,NotifiedIndividualsName										
,NumberOfSectionsExcLBS											
,LimitAmountInLimitCCY											
,ExcessAmountInLimitCCY											
,DeductibleAmountInLimitCCY										
,RemappedDivision												
,CoverageName													
,BeazleyOfficeLocation	
--,IsGblPgm
)
SELECT 

PK_Section														
,FK_Policy														
,FK_Trifocus													
,FK_ExceptionDocumentDate 										
,FK_ContractCertaintyDocumentDate								
,FK_ExpiryDateInForce											
,FK_FirstLiveDate												
,FK_Facility													
,FK_Underwriter													
,FK_LinkedSynergySection										
,FK_OfficeLocationCountry										
,FK_OfficeLocationRegion										
,FK_LinkedESGTrifocus											
,FK_ClassOfBusiness												
,FK_UnderwritingPlatform										
,SectionReference												
,Product														
,EngineeringConstructionExpiryDate								
,EngineeringConstructionExpiryDateName							
,USQuakeMultiplier												
,USWindMultiplier												
,USNonCatMultiplier												
,NonUSCatMultiplier												
,NonUSNonCatMultiplier											
,OccurrenceTerrorism											
,OccurrenceSabotage												
,OccurrenceRsccmd												
,OccurrenceInsurrection											
,OccurrenceRevolution      										
,OccurrenceRebellion       										
,OccurrenceMutiny          										
,OccurrenceCoupDEtat       										
,OccurrenceWar             										
,OccurrenceCivilWar												
,HoursClause													
,OccurrenceTerrorismName										
,OccurrenceSabotageName    										
,OccurrenceRSCCMDName      										
,OccurrenceInsurrectionName										
,OccurrenceRevolutionName  										
,OccurrenceRebellionName   										
,OccurrenceMutinyName      										
,OccurrenceCoupDEtatName   										
,OccurrenceWarName         										
,OccurrenceCivilWarName    										
,HoursClauseName												
,HasRationaleDocument											
,RationaleDocumentDate											
,HasRationaleDocumentName										
,RationaleDocumentDateName										
,RationaleDateName												
,HasExceptionDocument											
,ExceptionDocumentDate											
,HasExceptionDocumentName										
,ExceptionDocumentDateName									    
,RationaleCompletionMethod										
,HasContractCertaintyDocument									
,ContractCertaintyDocumentDate									
,DaysBetweenQBAndCCDocumentDate									
,ContractCertaintyDocumentDateName								
,DaysBetweenQBAndCCDocumentDateName								
,HasContractCertaintyDocumentName								
,ContractCertaintyPrimaryCompleteDate							
,LatestPICCPeriod												
,MissingPICCTransactions										
,HasMissingPICCTransactions										
,MissingPICCTransactionsName									
,HasMissingPICCTransactionsName									
,ExpiryDateInForce												
,ExternalAcquisitionCostMultiplier								
,ExternalAcquisitionCostMultiplierName							
,OriginalEPITotalAcquisitionCostMultiplier						
,RateChangeControlComplete										
,RationaleQuestionnaireComplete									
,RationaleQuestionnaireDate										
,RationaleDate													
,RationaleQuestionnaireCompleteName								
,RateChangeControlCompleteName									
,RationaleQuestionnaireDateName									
,RateChangeExposureMultiplier									
,RateChangeRiskMultiplier										
,RateChangeDeductibleMultiplier									
,RateChangeLimitMultiplier										
,RateChangeTermsAndConditionsMultiplier							
,RateChangeOtherMultiplier										
,HasTreatyAggsTerritory											
,HasTreatyAggsTerritoryName										
,FirstLiveDate     												
,FirstLiveDateName												
,IsSynergySection												
,HasUnderwriterAuthorityException								
,HasUnderwriterAuthorityExceptionName							
,ContractCertaintyStatus										
,ContractCertaintyStatusSortOrder								
,ContractCertaintyPreBindComplete								
,ContractCertaintyPreBindOnTime									
,ContractCertaintyPreBindOnTimeName								
,ContractCertaintyPreBindCompleteName							
,ContractCertaintyPreBindSignatureDate							
,ContractCertaintyRequired										
,ContractCertaintyRequiredName									
,ExpiryDate														
,QuoteOrBindDate												
,ExpectedPICCTransactions										
,IsDeclaration													
,IsFacility														
,BinderType														
,IsBreachResponseDummy											
,SectionReferenceSectionIdentifier								
,IsBeazleyLead													
,SourceSystem													
,IsBeazleyLeadName												
,NumberOfBeazleyLed												
,NotifiedIndividuals											
,IsUnknownMember												
,CarrierIndicator												
,IsRenewal														
,KeyBrokerName													
,KeyBrokerSourceId												
,KeyBrokerSubGroup												
,KeyBrokerGroup													
,KeyBrokerCity													
,KeyBrokerCountry												
,EarliestLPSOPremiumSigningNumberName							
,EarliestLPSOPremiumSigningNumber								
,LatestLPSOPremiumSigningNumberName								
,LatestLPSOPremiumSigningNumber									
,DaysBetweenQBAndPERDate										
,DaysBetweenQBAndPERDateName									
,IsSlipAttached													
,BeazleyOfficeLocationDerived									
,Facility														
,BeazleyOfficeLocationDerivedRegion								
,BeazleyOfficeLocationDerivedCountry							
,LinkedESGTrifocus												
,NotifiedIndividualsExcDuplicates								
,NotifiedIndividualsNameExcDuplicates							
,NotifiedIndividualsName										
,NumberOfSectionsExcLBS											
,LimitAmountInLimitCCY											
,ExcessAmountInLimitCCY											
,DeductibleAmountInLimitCCY										
,RemappedDivision												
,CoverageName													
,BeazleyOfficeLocation		
--,IsGblPgm
FROM ODS.Section s with (nolock) 


CREATE NONCLUSTERED INDEX [IDX_#Section] ON #Section ([PK_Section] ASC) INCLUDE ([FK_Policy]  ) WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#Policy] ON #Policy ([Pk_Policy] ASC)   WITH (FILLFACTOR = 90)
CREATE NONCLUSTERED INDEX [IDX_#Policy_SourceSystem] ON #Policy ([SourceSystem] ASC)   WITH (FILLFACTOR = 90)



UPDATE p SET
FACEvidenced       = 1
FROM
#Policy p
INNER JOIN
(
    SELECT
    FK_Policy                   = s.FK_Policy
    ,CountFACCoverNote          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Cover Note' THEN 1 ELSE 0 END)
    ,CountFACOrderForm          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Order Form' THEN 1 ELSE 0 END)
    ,CountFACRationale          = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Rationale' THEN 1 ELSE 0 END)
    ,CountFACSecurity           = SUM(CASE WHEN dt.DocumentTypeName = 'FAC Security Approval (Pre Bind)' THEN 1 ELSE 0 END)
    FROM
     #Section s
    INNER JOIN
    ODS.Document d with (nolock)  ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt with (nolock)  ON
    d.FK_DocumentType = dt.PK_DocumentType
    GROUP BY
    s.FK_Policy
) x ON
p.PK_Policy = x.FK_Policy
WHERE
x.CountFACCoverNote > 0
AND x.CountFACOrderForm > 0
AND x.CountFACRationale > 0
AND x.CountFACSecurity > 0



-- Update BrokerContactName and SubmittingBrokerContactName in Policy table -- BI 121
UPDATE p SET
p.BrokerContactName				    = se.BrokerContactName  
,p.SubmittingBrokerContactName      = se.SubmittingBrokerContactName	 
FROM
#Policy p
LEFT OUTER JOIN ODS.SubmissionExtension se
ON p.FK_Submission = se.FK_Submission  


/*Update SourceSystem = USHVH to US High Value Homeowners*/

UPDATE p SET
p.SourceSystem = 'US High Value Homeowners'
from #Policy p
where p.SourceSystem = 'USHVH'



/* Update "NotifiedIndividualsMaxim" in Policy */
UPDATE p SET
NotifiedIndividualsMaximum = s.NotifiedIndividualsMaximum
						 
FROM
#Policy p
INNER JOIN
(SELECT  FK_Policy , MAX(NotifiedIndividuals) as NotifiedIndividualsMaximum  FROM #Section
GROUP BY FK_Policy ) s 
ON s.FK_Policy=p.PK_policy



UPDATE s SET
EngineeringConstructionExpiryDate = de.EntryDate
,EngineeringConstructionExpiryDateName      = IIF(YEAR(de.EntryDate)< 1990 OR YEAR(de.EntryDate)>2050,NULL,FORMAT(de.EntryDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](de.EntryDate)
FROM
 #Section s
INNER JOIN
ODS.DiaryEntry de ON
de.FK_Section = s.PK_Section
WHERE
de.EntryTypeCode = 'RCOMDT'



/*Update Cat/Non Cat premium percentages*/

UPDATE s SET
USQuakeMultiplier           = y.USQuakeMultiplier
,USWindMultiplier           = y.USWindMultiplier
,USNonCatMultiplier         = y.USNonCatMultiplier
,NonUSCatMultiplier         = y.NonUSCatMultiplier
,NonUSNonCatMultiplier      = y.NonUSNonCatMultiplier
FROM
 #Section s
INNER JOIN
(
    SELECT
    FK_Section                  = pvt.FK_Section
    ,USQuakeMultiplier          = pvt.XUSQUA
    ,USWindMultiplier           = pvt.XUSWIN
    ,USNonCatMultiplier         = pvt.XUSOTH
    ,NonUSCatMultiplier         = pvt.XINCAT
    ,NonUSNonCatMultiplier      = pvt.XINOTH
    FROM
    (
        SELECT
        FK_Section              = de.FK_Section
        ,EntryTypeCode          = de.EntryTypeCode
        ,EntryValue             = Utility.udf_ProcessPercentage(de.EntryValue, 0, 0, 0)
        FROM  
        ODS.DiaryEntry de
    ) x
    PIVOT
    (
        SUM(x.EntryValue)
        FOR
        x.EntryTypeCode IN
        (
            [XUSQUA]
            ,[XUSWIN]
            ,[XUSOTH]
            ,[XINCAT]
            ,[XINOTH]
        )
    ) pvt
) y ON
s.PK_Section = y.FK_Section




/*Update hours clauses*/
UPDATE s SET 
OccurrenceTerrorism         = x.OccurrenceTerrorism
,OccurrenceSabotage         = x.OccurrenceSabotage
,OccurrenceRsccmd           = x.OccurrenceRsccmd
,OccurrenceInsurrection     = x.OccurrenceInsurrection
,OccurrenceRevolution       = x.OccurrenceRevolution
,OccurrenceRebellion        = x.OccurrenceRebellion
,OccurrenceMutiny           = x.OccurrenceMutiny
,OccurrenceCoupDEtat        = x.OccurrenceCoupDEtat
,OccurrenceWar              = x.OccurrenceWar
,OccurrenceCivilWar         = x.OccurrenceCivilWar
,HoursClause                = x.HoursClause
,OccurrenceTerrorismName    = format(x.OccurrenceTerrorism, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceTerrorism)
,OccurrenceSabotageName     = format(x.OccurrenceSabotage, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceSabotage)
,OccurrenceRSCCMDName       = format(x.OccurrenceRSCCMD, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceRSCCMD)
,OccurrenceInsurrectionName = format(x.OccurrenceInsurrection, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceInsurrection)
,OccurrenceRevolutionName   = format(x.OccurrenceRevolution, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceRevolution)
,OccurrenceRebellionName    = format(x.OccurrenceRebellion, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceRebellion)
,OccurrenceMutinyName       = format(x.OccurrenceMutiny, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceMutiny)
,OccurrenceCoupDEtatName    = format(x.OccurrenceCoupDEtat, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceCoupDEtat)
,OccurrenceWarName          = format(x.OccurrenceWar, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceWar)
,OccurrenceCivilWarName     = format(x.OccurrenceCivilWar, '###,###,###,###')--[ODS].[udf_FormatInt](x.OccurrenceCivilWar)
,HoursClauseName            = format(x.HoursClause, '###,###,###,###')--[ODS].[udf_FormatInt](x.HoursClause)
FROM
 #Section s
INNER JOIN
(
    SELECT
    FK_Section                  = pvt.FK_Section
    ,OccurrenceTerrorism        = pvt.[OTERR]            
    ,OccurrenceSabotage         = pvt.[OSABOT]
    ,OccurrenceRSCCMD           = pvt.[ORSCCM]
    ,OccurrenceInsurrection     = pvt.[OINSUR]
    ,OccurrenceRevolution       = pvt.[OREVOL]
    ,OccurrenceRebellion        = pvt.[OREBEL]
    ,OccurrenceMutiny           = pvt.[OMUTIN]
    ,OccurrenceCoupDEtat        = pvt.[OCOUP]
    ,OccurrenceWar              = pvt.[OWAR]
    ,OccurrenceCivilWar         = pvt.[OCIVW]
    ,HoursClause                = pvt.[HC]
    FROM
    (
        SELECT
        FK_Section              = de.FK_Section
        ,EntryTypeCode          = de.EntryTypeCode
        ,EntryValue             = de.EntryValue
        FROM  
        ODS.DiaryEntry de
    ) x
    PIVOT
    (
        SUM(x.EntryValue)
        FOR
        x.EntryTypeCode IN
        (
            [OTERR]
            ,[OSABOT]
            ,[ORSCCM]
            ,[OINSUR]
            ,[OREVOL]
            ,[OREBEL]
            ,[OMUTIN]
            ,[OCOUP]
            ,[OWAR]
            ,[OCIVW]
            ,[HC]
        )
    ) pvt
) x ON
s.PK_Section = x.FK_Section
          

/*Originally from [usp_LoadDocument]*/
-- Update Rationale document fields in section table
UPDATE s SET  
HasRationaleDocument        = x.HasRationaleDocument
,RationaleDocumentDate      = x.RationaleDocumentDate
,HasRationaleDocumentName	= IIF(x.HasRationaleDocument = 1 , 'Yes' , 'No')  -- --[ODS].[udf_FormatBitAsYesNo](x.HasRationaleDocument)
,RationaleDocumentDateName	= IIF(YEAR(x.RationaleDocumentDate)< 1990 OR YEAR(x.RationaleDocumentDate)>2050,NULL,FORMAT(x.RationaleDocumentDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](x.RationaleDocumentDate)
,RationaleDateName			= CASE WHEN s.RationaleQuestionnaireDate>x.RationaleDocumentDate AND YEAR(x.RationaleDocumentDate)<>1753 THEN FORMAT(x.RationaleDocumentDate, 'dd-MMM-yyyy')
					               WHEN s.RationaleQuestionnaireDate<x.RationaleDocumentDate AND YEAR(s.RationaleQuestionnaireDate)<>1753  THEN FORMAT(s.RationaleQuestionnaireDate, 'dd-MMM-yyyy')
					               ELSE FORMAT(ISNULL(s.RationaleQuestionnaireDate,x.RationaleDocumentDate),'dd-MMM-yyyy') END--[ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,x.RationaleDocumentDate))

FROM 
 #Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasRationaleDocument               = 1
    ,RationaleDocumentDate              = MIN(d.DocumentCreateDate)
    FROM
     #Section s
    INNER JOIN
    ODS.Document d with (nolock)  ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt with (nolock)  ON
    d.FK_DocumentType = dt.PK_DocumentType
    WHERE
    UPPER(dt.DocumentTypeName) LIKE '%UW%RATIONALE%'
    OR UPPER(dt.DocumentTypeName) LIKE '%UNDERWRITER%RATIONALE%'
    GROUP BY 
    s.PK_Section
            
) x
ON s.PK_Section = x.FK_Section

-- Reset Rational document fields for Unirisx non primary sections

UPDATE s SET  
 HasRationaleDocument       = 0
,RationaleDocumentDate      = NULL
,HasRationaleDocumentName	= 'No'--[ODS].[udf_FormatBitAsYesNo](0)
,RationaleDocumentDateName	= NULL--[ODS].[udf_FormatDateTime](NULL)
,RationaleDateName			= IIF(YEAR(s.RationaleQuestionnaireDate)< 1990 OR YEAR(s.RationaleQuestionnaireDate)>2050,NULL,FORMAT(s.RationaleQuestionnaireDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate](s.RationaleQuestionnaireDate,NULL))

FROM  #Section s

INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_SectionExtension unisecex
ON s.SectionReference = unisecex.SectionReference
AND unisecex.IsPrimarySection <> 1

WHERE unisecex.SourceSystem = 'Unirisx'
--AND unisecex.IsActive = 1

-- Update exception document fields in section table
UPDATE s SET  
HasExceptionDocument        = x.HasExceptionDocument
,ExceptionDocumentDate      = x.ExceptionDocumentDate
,FK_ExceptionDocumentDate   = IIF(YEAR(x.ExceptionDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, x.ExceptionDocumentDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](x.ExceptionDocumentDate)
,HasExceptionDocumentName	= IIF(x.HasExceptionDocument = 1 , 'Yes' , 'No')  --ODS].[udf_FormatBitAsYesNo](x.HasExceptionDocument)
,ExceptionDocumentDateName  = IIF(YEAR(x.ExceptionDocumentDate)< 1990 OR YEAR(x.ExceptionDocumentDate)>2050,NULL,FORMAT(x.ExceptionDocumentDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](x.ExceptionDocumentDate)
FROM 
 #Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasExceptionDocument               = 1
    ,ExceptionDocumentDate              = MIN(d.DocumentCreateDate)
    FROM
     #Section s
    INNER JOIN
    ODS.Document d with (nolock)  ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt with (nolock)  ON
    d.FK_DocumentType = dt.PK_DocumentType
    WHERE
    UPPER(dt.DocumentTypeName) LIKE 'EXCEPTION%SIGN%OFF'
    GROUP BY 
    s.PK_Section
            
) x
ON s.PK_Section = x.FK_Section

UPDATE s SET
RationaleCompletionMethod       = CASE 
                                    WHEN p.SourceSystem NOT IN ('Eurobase','Unirisx') OR p.IsQuote = 1 THEN 'N/A'
                                    WHEN s.HasRationaleDocument = 1 THEN 'Document'
                                    ELSE 'Incomplete'
                                  END
FROM
 #Section s
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
WHERE
s.PK_Section <> 0



-- Update contract certainty document fields in section table
UPDATE s SET  
HasContractCertaintyDocument        = x.HasContractCertaintyDocument
,ContractCertaintyDocumentDate      = x.ContractCertaintyDocumentDate
,DaysBetweenQBAndCCDocumentDate     = DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate)
,FK_ContractCertaintyDocumentDate   = IIF(YEAR(x.ContractCertaintyDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, x.ContractCertaintyDocumentDate),DATEADD(DAY, -53690, 0))--[Utility].[udf_GenerateDateKey](x.ContractCertaintyDocumentDate)
,ContractCertaintyDocumentDateName  = IIF(YEAR(x.ContractCertaintyDocumentDate)< 1990 OR YEAR(x.ContractCertaintyDocumentDate)>2050,NULL,FORMAT(x.ContractCertaintyDocumentDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](x.ContractCertaintyDocumentDate)
,DaysBetweenQBAndCCDocumentDateName = format(DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate), '###,###,###,###')--[ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate))
,HasContractCertaintyDocumentName   = IIF(x.HasContractCertaintyDocument = 1 , 'Yes' , 'No')  --([ODS].[udf_FormatBitAsYesNo](x.HasContractCertaintyDocument)) --BI-8376
FROM 
 #Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasContractCertaintyDocument       = 1
    ,ContractCertaintyDocumentDate      = MIN(d.DocumentCreateDate)
    FROM
     #Section s
    INNER JOIN
    ODS.Document d with (nolock)  ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt with (nolock) ON
    d.FK_DocumentType = dt.PK_DocumentType
	INNER JOIN #Policy p ON
	s.FK_Policy = p.PK_Policy
    WHERE
    UPPER(dt.DocumentTypeName) = 'CONTRACT CERTAINTY'
	AND p.SourceSystem = 'Eurobase'
    GROUP BY 
    s.PK_Section, p.SourceSystem
            
) x
ON s.PK_Section = x.FK_Section 

-- Update contract certainty document fields in section table - for Unirisx sourcesystem - BI 676
UPDATE s SET  
HasContractCertaintyDocument        = x.HasContractCertaintyDocument
,ContractCertaintyDocumentDate      = x.ContractCertaintyDocumentDate
,DaysBetweenQBAndCCDocumentDate     = DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate)
,ContractCertaintyDocumentDateName  = IIF(YEAR(x.ContractCertaintyDocumentDate)< 1990 OR YEAR(x.ContractCertaintyDocumentDate)>2050,NULL,FORMAT(x.ContractCertaintyDocumentDate, 'dd-MMM-yyyy'))--[ODS].[udf_FormatDateTime](x.ContractCertaintyDocumentDate)
,DaysBetweenQBAndCCDocumentDateName = format(DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate), '###,###,###,###')--[ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, x.ContractCertaintyDocumentDate))
,HasContractCertaintyDocumentName   = IIF(x.HasContractCertaintyDocument = 1 , 'Yes' , 'No')  --([ODS].[udf_FormatBitAsYesNo](x.HasContractCertaintyDocument)) --BI-8376

FROM 
 #Section s
INNER JOIN 
(          
    SELECT 
     FK_Section                         = s.PK_Section 
    ,HasContractCertaintyDocument       = 1
    ,ContractCertaintyDocumentDate      = MIN(d.UploadedDateTime)
    FROM
     #Section s
    INNER JOIN
    ODS.Document d ON
    s.PK_Section = d.FK_Section
    INNER JOIN
    ODS.DocumentType dt ON
    d.FK_DocumentType = dt.PK_DocumentType
	INNER JOIN #Policy p ON
	s.FK_Policy = p.PK_Policy
    WHERE
    dt.DocumentTypeName = 'CONTRACT CERTAINTY'
	AND p.SourceSystem = 'Unirisx'
	AND s.ContractCertaintyPrimaryCompleteDate IS NULL
    GROUP BY 
    s.PK_Section, p.SourceSystem
            
) x
ON s.PK_Section = x.FK_Section 


/*Originally from usp_LoadPICCTransaction*/
/*Update latest PICC period in section (latest by ID), missing tansactions, and flag*/



UPDATE s SET
LatestPICCPeriod                = picc.PICCPeriod
 --This is supposed to come out NULL if Expected is NULL. If we're not expecting any, we don't care if we
 --have any for the purposes of calculating the number of missing transactions
,MissingPICCTransactions        = ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0)
,HasMissingPICCTransactions     = CASE 
                                    WHEN ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0) > 0 THEN 1
                                    ELSE 0
                                   END
,MissingPICCTransactionsName    = IIF((ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0)) = 0, '0', format(ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0), '###,###,###,###'))--[ODS].[udf_FormatInt](ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0))
,HasMissingPICCTransactionsName      =  IIF((CASE WHEN ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0) > 0 THEN 1 ELSE 0 END) = 1 , 'Yes' , 'No')  --
                                   -- [ODS].[udf_FormatBitAsYesNo](CASE 
                                   -- WHEN ExpectedPICCTransactions - ISNULL(m.NumberOfTransactions, 0) > 0 THEN 1
                                   -- ELSE 0
                                   --END)
FROM
#Section s 
LEFT OUTER JOIN
(
    SELECT
    FK_Section                  = picc.FK_Section
    ,MaxPICCPeriodId            = MAX(picc.PICCPeriodId)
    ,NumberOfTransactions       = COUNT(1)
    FROM
    ODS.PICCTransaction picc with (nolock) 
    GROUP BY
    picc.FK_Section
) AS m ON
s.PK_Section = m.FK_Section
LEFT OUTER JOIN
ODS.PICCTransaction picc ON
m.FK_Section = picc.FK_Section AND
m.MaxPICCPeriodId = picc.PICCPeriodId

-- For Unirisx Marine Oslo the users manually update the OriginalNetEPI, 
-- this logic allows us to display both gross and net OriginalEPI amounts 
-- AS they are on the UI screen
-- Update OriginalEPITotalAcquisitionCostMultiplier with the ExternalAcquisitionCostMultiplier value
-- in the section table where this value is not populated already 
/* Update IsBeazleyLead with 1 for the claims that have SourceSystem ='ClaimCenter' in  #Section  BI-6313*/
UPDATE s
SET IsBeazleyLead = 1
FROM  #Section s 
WHERE SourceSystem ='ClaimCenter'


UPDATE #Section
SET IsBeazleyLeadName				= IIF(IsBeazleyLead = 1 , 'Yes' , 'No')  --([ODS].[udf_FormatBitAsYesNo]([IsBeazleyLead]))
	,NumberOfBeazleyLed             = (case when [IsUnknownMember]=(1) then (0) else CONVERT([int],[IsBeazleyLead]) end)
WHERE SourceSystem ='ClaimCenter'  --BI-8376


/*Update "ExpiryDateInForce" on section table*/

UPDATE s SET 
ExpiryDateInForce = CASE 
						WHEN p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger','RulebookUS')
                        OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
						OR p.SourceSystem = 'CIPS' 
						THEN DATEADD(DAY, -1, ExpiryDate) 
						ELSE ExpiryDate
					END
,FK_ExpiryDateInForce  = IIF(YEAR(CASE 
						            WHEN  p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger','RulebookUS')
                                    OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
						            OR p.SourceSystem = 'CIPS'  
						            THEN DATEADD(DAY, -1, ExpiryDate) 
						            ELSE ExpiryDate END) 
                           BETWEEN 1990 AND 2050,
                           DATEDIFF(DAY, 0, CASE 
						                    WHEN  p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger','RulebookUS')
                                             OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
						                     OR p.SourceSystem = 'CIPS'  
						                    THEN DATEADD(DAY, -1, ExpiryDate) 
						                    ELSE ExpiryDate END),DATEADD(DAY, -53690, 0))
     --                   [Utility].[udf_GenerateDateKey](CASE 
					--	WHEN  p.SourceSystem IN ('BeazleyPro','US High Value Homeowners','FDR', 'GameChanger')
     --                   OR (p.SourceSystem = 'myBeazley' AND s.Product = 'Canada')
					--	OR p.SourceSystem = 'CIPS'  
					--	THEN DATEADD(DAY, -1, ExpiryDate) 
					--	ELSE ExpiryDate
					--END)
FROM
 #Section s
INNER JOIN
#Policy p
ON p.PK_Policy = s.FK_policy
INNER JOIN
ODS.Trifocus t
ON t.PK_Trifocus = s.FK_Trifocus




/*Originally from usp_LoadSectionAcquisitionCost*/
UPDATE s SET 
ExternalAcquisitionCostMultiplier				= x.ExternalAcquisitionCostMultiplier
,ExternalAcquisitionCostMultiplierName			= CAST(ROUND(CAST(x.ExternalAcquisitionCostMultiplier AS FLOAT) * 100, 2 ) as varchar(50)) + '%'--([ODS].[udf_FormatMultiplierAsPercentage](x.ExternalAcquisitionCostMultiplier,(2))) --BI-8376
FROM
 #Section s
INNER JOIN
(
    SELECT
    FK_Section                              = actp.FK_Section
    ,FK_EntityPerspective                   = actp.FK_EntityPerspective
    ,ExternalAcquisitionCostMultiplier      = SUM(actp.AcquisitionCostMultiplier)
    FROM
    ODS.AcquisitionCostType act with (nolock) 
    INNER JOIN
    ODS.SectionAcquisitionCost actp with (nolock) ON
    actp.FK_AcquisitionCostType = act.PK_AcquisitionCostType
	AND actp.TaxDescription = act.TaxDescription
    WHERE
    act.AcquisitionCostTypeInternalExternal = 'External'
    GROUP BY
    actp.FK_Section
    ,actp.FK_EntityPerspective
) x ON
s.PK_Section = x.FK_Section /*We don't need to (and can't) join on EntityPerspective here, 
as for *external* costs the value for every EP that exists for the section is the same*/
WHERE isnull(s.Product,'N/A') NOT IN ('Surety Quota Share', 'Universal Product Incubator-BPS Embedded') --for these 2 products, we let the value from Outbound.vw_Section


/*Update internal acquisition costs*/
UPDATE sep SET
InternalAcquisitionCostMultiplier       = x.InternalAcquisitionCostMultiplier
FROM
ODS.SectionEntityPerspective sep
INNER JOIN
(
    SELECT
    FK_Section                              = s.PK_Section
    ,FK_EntityPerspective                   = sac.FK_EntityPerspective
    ,InternalAcquisitionCostMultiplier      = SUM(sac.AcquisitionCostMultiplier)
    FROM
    ODS.AcquisitionCostType act with (nolock) 
    INNER JOIN
    ODS.SectionAcquisitionCost sac with (nolock) ON
    sac.FK_AcquisitionCostType = act.PK_AcquisitionCostType
	AND sac.TaxDescription = act.TaxDescription
    INNER JOIN
     #Section s ON
    sac.FK_Section = s.PK_Section
    WHERE
    act.AcquisitionCostTypeInternalExternal = 'Internal'
    GROUP BY
    s.PK_Section
    ,sac.FK_EntityPerspective
) x ON
sep.FK_Section = x.FK_Section
AND sep.FK_EntityPerspective = x.FK_EntityPerspective

-- For Unirisx Marine Oslo the users manually update the OriginalNetEPI, 
-- this logic allows us to display both gross and net OriginalEPI amounts 
-- AS they are on the UI screen
-- Update OriginalEPITotalAcquisitionCostMultiplier with the ExternalAcquisitionCostMultiplier value
-- in the section table where this value is not populated already 


UPDATE s SET
OriginalEPITotalAcquisitionCostMultiplier   = s.ExternalAcquisitionCostMultiplier
FROM
 #Section s
WHERE OriginalEPITotalAcquisitionCostMultiplier IS NULL

  

/*Originally from usp_LoadSectionControlQuestionAnswer*/
IF (OBJECT_ID('tempdb..#ControlQuestionsComplete')) IS NOT NULL
DROP TABLE #ControlQuestionsComplete

CREATE TABLE #ControlQuestionsComplete
(
    FK_Section                  bigint          NOT NULL
    ,ControlQuestionType        varchar(255)    NOT NULL
    ,NumberOfQuestions          int             NOT NULL
    ,NumberOfAnswers            int             NOT NULL
    PRIMARY KEY (FK_Section, ControlQuestionType)
)



INSERT INTO #ControlQuestionsComplete
(
    FK_Section
    ,ControlQuestionType
    ,NumberOfQuestions
    ,NumberOfAnswers
)
SELECT
FK_Section                      = s.PK_Section
,ControlQuestionType            = x.ControlQuestionType
,NumberOfQuestions              = x.NumberOfQuestions
,NumberOfAnswers                = ISNULL(y.NumberOfAnswers,0) 
FROM
 #Section s
CROSS JOIN
(
    SELECT
    ControlQuestionType     = cqt.ControlQuestionType 
    ,NumberOfQuestions      = COUNT(1)
    FROM
    ODS.ControlQuestion cq
    INNER JOIN
    ODS.ControlQuestionType cqt ON
    cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
    GROUP BY
    cqt.ControlQuestionType
) x
LEFT OUTER JOIN
(
    SELECT
    FK_Section              = scqa.FK_Section
    ,ControlQuestionType    = cqt.ControlQuestionType
    ,NumberOfAnswers        = SUM(scqa.AnswerCount)
    FROM
    ODS.ControlQuestionType cqt with (nolock) 
    INNER JOIN
    ODS.ControlQuestion cq with (nolock) ON
    cqt.PK_ControlQuestionType = cq.FK_ControlQuestionType
    INNER JOIN
    ODS.SectionControlQuestionAnswer scqa with (nolock) ON
    cq.PK_ControlQuestion = scqa.FK_ControlQuestion
    GROUP BY
    scqa.FK_Section
    ,cqt.ControlQuestionType
) y ON
s.PK_Section = y.FK_Section
AND x.ControlQuestionType = y.ControlQuestionType

--peste 6 min with udf_FormatBitAsYesNo / 2:32 min fara udf_FormatBitAsYesNo
UPDATE s SET
RateChangeControlComplete               = CASE WHEN cqc_rc.NumberOfAnswers = cqc_rc.NumberOfQuestions THEN 1 ELSE s.RateChangeControlComplete END
,RationaleQuestionnaireComplete         = CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN 1 ELSE 0 END
,RationaleQuestionnaireDate             = CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END
,RationaleDate							= [Utility].[udf_EarlierDate]((CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END),s.RationaleDocumentDate)
,RationaleQuestionnaireCompleteName		= CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN 'Yes' ELSE 'No' END--([ODS].[udf_FormatBitAsYesNo](CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN 1 ELSE 0 END)) --BI-8376
,RateChangeControlCompleteName          = CASE WHEN cqc_rc.NumberOfAnswers = cqc_rc.NumberOfQuestions THEN 'Yes' ELSE CASE WHEN s.RateChangeControlComplete = 1 THEN 'YES' ELSE 'No' END END --([ODS].[udf_FormatBitAsYesNo](CASE WHEN cqc_rc.NumberOfAnswers = cqc_rc.NumberOfQuestions THEN 1 ELSE s.RateChangeControlComplete END)) --BI-8376
,RationaleQuestionnaireDateName         = IIF(YEAR(CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END)< 1990 OR YEAR(CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END)>2050,NULL,FORMAT(CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END, 'dd-MMM-yyyy'))--([ODS].[udf_FormatDateTime](CASE WHEN cqc_r.NumberOfAnswers = cqc_r.NumberOfQuestions THEN s.RationaleQuestionnaireDate ELSE NULL END)) --BI-8376
FROM
 #Section s
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_rc ON
s.PK_Section = cqc_rc.FK_Section
AND cqc_rc.ControlQuestionType = 'Rate Change'
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_r ON
s.PK_Section = cqc_r.FK_Section
AND cqc_r.ControlQuestionType = 'Rationale'
WHERE s.PK_Section <> 0
  AND p.SourceSystem <> 'Unirisx'

/* Update RateChangeControlComplete field for Unirisx     */
UPDATE s SET
RateChangeControlComplete               = s.RateChangeControlComplete 
FROM
 #Section s
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
#ControlQuestionsComplete cqc_rc ON
s.PK_Section = cqc_rc.FK_Section
AND cqc_rc.ControlQuestionType = 'Rate Change'
WHERE s.PK_Section <> 0
  AND p.SourceSystem = 'Unirisx'
  

SELECT ControlQuestion,PK_ControlQuestion,FK_ControlQuestionType
INTO #ControlQuestion
FROM ODS.ControlQuestion cq with (nolock) 
INNER JOIN ODS.ControlQuestionType cqt with (nolock) ON
cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType 
 WHERE   cqt.ControlQuestionType = 'Rate Change'
 AND
( ControlQuestion LIKE 'Exposure%' OR
ControlQuestion LIKE 'Risk%' OR 
ControlQuestion LIKE 'Deductible%' OR
ControlQuestion LIKE 'Limit%' OR
ControlQuestion LIKE 'Terms%' OR
ControlQuestion LIKE 'Other%' )
  --4 min
/*Update rate change*/
UPDATE s SET 
RateChangeExposureMultiplier                    = rc.RateChangeExposureMultiplier
,RateChangeRiskMultiplier                       = rc.RateChangeRiskMultiplier
,RateChangeDeductibleMultiplier                 = rc.RateChangeDeductibleMultiplier
,RateChangeLimitMultiplier                      = rc.RateChangeLimitMultiplier
,RateChangeTermsAndConditionsMultiplier         = rc.RateChangeTermsAndConditionsMultiplier
,RateChangeOtherMultiplier                      = rc.RateChangeOtherMultiplier
FROM
 #Section s
INNER JOIN
(
    SELECT
    FK_Section                                  = scqa.FK_Section
    ,RateChangeExposureMultiplier               = SUM(CASE WHEN cq.ControlQuestion LIKE 'Exposure%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeRiskMultiplier                   = SUM(CASE WHEN cq.ControlQuestion LIKE 'Risk%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeDeductibleMultiplier             = SUM(CASE WHEN cq.ControlQuestion LIKE 'Deductible%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeLimitMultiplier                  = SUM(CASE WHEN cq.ControlQuestion LIKE 'Limit%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeTermsAndConditionsMultiplier     = SUM(CASE WHEN cq.ControlQuestion LIKE 'Terms%' THEN scqa.NumericAnswer ELSE NULL END)
    ,RateChangeOtherMultiplier                  = SUM(CASE WHEN cq.ControlQuestion LIKE 'Other%' THEN scqa.NumericAnswer ELSE NULL END)
    FROM
    ODS.SectionControlQuestionAnswer scqa
    INNER JOIN
    #ControlQuestion cq ON
    scqa.FK_ControlQuestion = cq.PK_ControlQuestion
    --INNER JOIN
    --ODS.ControlQuestionType cqt ON
    --cq.FK_ControlQuestionType = cqt.PK_ControlQuestionType
    --WHERE
    --cqt.ControlQuestionType = 'Rate Change'
    GROUP BY
    scqa.FK_Section
) rc ON
s.PK_Section = rc.FK_Section

IF (OBJECT_ID('tempdb..#ControlQuestionsComplete')) IS NOT NULL
DROP TABLE #ControlQuestionsComplete



/*Originally from usp_LoadSectionTerritory*/
UPDATE s SET
HasTreatyAggsTerritory = 1
,HasTreatyAggsTerritoryName					= 'Yes'--[ODS].[udf_FormatBitAsYesNo](1)
FROM
 #Section s
INNER JOIN
ODS.SectionTerritory st ON
s.PK_Section = st.FK_Section



/*Originally from usp_LoadSectionWorkFlow*/
/*Update first live date on Section.
For pre-Synergy, we take the earlier of the first live date and the date entered (which has already
been written to the "First Live Date" field for non-Synergy policies in usp_LoadSection*/
UPDATE s SET
FirstLiveDate               = CASE s.IsSynergySection
                                WHEN 1 THEN x.StatusFromDate
                                ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
                              END
,FK_FirstLiveDate			=  IIF(YEAR(CASE s.IsSynergySection WHEN 1 THEN x.StatusFromDate ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate) END) BETWEEN 1990 AND 2050, 
                                        DATEDIFF(DAY, 0, CASE s.IsSynergySection WHEN 1 THEN x.StatusFromDate ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate) END),DATEADD(DAY, -53690, 0))--
                --                                                ([Utility].[udf_GenerateDateKey](
																--CASE s.IsSynergySection
																--	WHEN 1 THEN x.StatusFromDate
																--	ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
																--END)) --BI-8376
,FirstLiveDateName                         =  CASE WHEN s.IsSynergySection = 1 THEN FORMAT(x.StatusFromDate, 'dd-MMM-yyyy')
		                                           ELSE CASE WHEN	x.StatusFromDate>s.FirstLiveDate AND YEAR(s.FirstLiveDate)<>1753 THEN FORMAT(s.FirstLiveDate, 'dd-MMM-yyyy')
					                               WHEN x.StatusFromDate<s.FirstLiveDate AND YEAR(x.StatusFromDate)<>1753  THEN FORMAT(x.StatusFromDate, 'dd-MMM-yyyy')
					                               ELSE NULL END END
                   --                                                     ([ODS].[udf_FormatDateTime](
																			--CASE s.IsSynergySection
																			--	WHEN 1 THEN x.StatusFromDate
																			--	ELSE Utility.udf_EarlierDate(x.StatusFromDate, s.FirstLiveDate)
																			--END)) --BI-8376
FROM
 #Section s
INNER JOIN
(
    SELECT
    FK_Section          = swc.FK_Section
    ,StatusFromDate     = sw.StatusFromDate
    ,SequenceId         = ROW_NUMBER() OVER
                            (PARTITION BY swc.FK_Section
                             ORDER BY sw.StatusFromDate ASC) 
    FROM
    ODS.SectionWorkflow sw with (nolock) 
    INNER JOIN
    ODS.WorkflowStatus ws with (nolock) ON
    sw.FK_WorkflowStatus = ws.PK_WorkflowStatus
    INNER JOIN
    ODS.SectionWorkflowCycle swc with (nolock) ON
    sw.FK_SectionWorkflowCycle = swc.PK_SectionWorkflowCycle
    WHERE
    ws.WorkflowStatusCode = 'L'
) x ON
s.PK_Section = x.FK_Section
AND x.SequenceId = 1



/*Originally from usp_LoadUnderwriterAuthorityException*/
-- Update policy related fields
UPDATE s SET
HasUnderwriterAuthorityException = 1
,HasUnderwriterAuthorityExceptionName		= 'Yes'--[ODS].[udf_FormatBitAsYesNo](1)
FROM
 #Section s
INNER JOIN ODS.UnderwriterAuthorityException uae ON
s.PK_Section = uae.FK_section



/*Contract certainty

1. If the status is "Primary Complete - Document to be loaded" and the status was 
never "Primary Complete" and no document has been loaded, the status should report "Incomplete".

2. If the status was never "Primary Complete" and the "Days Between QB And CC Document Date" > 21, 
the "Pre-Bind On Time" field should report "Not On Time".

*/



UPDATE s SET
ContractCertaintyStatus                 = 'Incomplete'
,ContractCertaintyStatusSortOrder       = 5
,ContractCertaintyPreBindComplete       = 0
,ContractCertaintyPreBindOnTime         = 0
,ContractCertaintyPreBindCompleteName   = 'Incomplete' --BI-8376
FROM
 #Section s
WHERE
ContractCertaintyStatus = 'Primary Complete - Document to be loaded'
AND HasContractCertaintyDocument = 0
AND ContractCertaintyPrimaryCompleteDate IS NULL

UPDATE s SET
ContractCertaintyPreBindOnTime			= 0
FROM
 #Section s
INNER JOIN
#Policy  p ON
s.FK_Policy = p.PK_Policy
WHERE  p.SourceSystem NOT IN ('Eurobase', 'Unirisx')
AND s.ContractCertaintyPrimaryCompleteDate IS NULL
AND s.DaysBetweenQBAndCCDocumentDate > 21
AND s.ContractCertaintyStatus <> 'No Status'


UPDATE s SET
ContractCertaintyPreBindOnTime = 0
FROM
 #Section s
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
WHERE  p.SourceSystem IN ('Eurobase', 'Unirisx')
AND (
	DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPrimaryCompleteDate ) IS NULL
	OR DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPrimaryCompleteDate  ) > 1
	)
AND (
	 DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPreBindSignatureDate  ) IS NULL
     OR DATEDIFF(DAY, QuoteOrBindDate, ContractCertaintyPreBindSignatureDate  ) > 1
	 OR HasContractCertaintyDocument = 0
	 OR s.DaysBetweenQBAndCCDocumentDate > 21
	 )



	 
UPDATE s SET
ContractCertaintyRequired				= CASE
										    WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 1 --Open market
										    WHEN s.IsFacility = 1 AND ISNULL(f.BinderType, '0') <> '4' THEN 1
										    WHEN s.IsDeclaration = 1 AND f.BinderType = '4' THEN 1
										    ELSE 0
										  END
,ContractCertaintyRequiredName          = IIF((CASE
													WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 1 --Open market
													WHEN s.IsFacility = 1 AND ISNULL(f.BinderType, '0') <> '4' THEN 1
													WHEN s.IsDeclaration = 1 AND f.BinderType = '4' THEN 1
													ELSE 0
													END) = 1, 'Contract Certainty Required','Contract Certainty Not Required') 
                --                                ([ODS].[udf_FormatBit](
																--	CASE
																--		WHEN s.IsFacility = 0 AND s.IsDeclaration = 0 THEN 1 --Open market
																--		WHEN s.IsFacility = 1 AND ISNULL(f.BinderType, '0') <> '4' THEN 1
																--		WHEN s.IsDeclaration = 1 AND f.BinderType = '4' THEN 1
																--		ELSE 0
																--	END,
																--'Contract Certainty Required','Contract Certainty Not Required','Contract Certainty Not Required')) --BI-8376
FROM
 #Section s 
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
LEFT OUTER JOIN
 #Section f ON
s.FK_Facility = f.PK_Section
WHERE
s.PK_Section <> 0
AND s.IsBreachResponseDummy = 0
AND p.SourceSystem = 'Eurobase'
AND s.SectionReferenceSectionIdentifier IN ('A', 'J')
AND NOT EXISTS
(
    SELECT
    1
    FROM
     #Section s1
    WHERE
    s1.SectionReferenceSectionIdentifier = 'A'
    AND s1.ContractCertaintyStatus IN
    (
        'Primary Complete'
        ,'Primary Complete - Document to be loaded'
        ,'Controls Compliant'
        ,'Fully Compliant'
    )
    AND
    s.SectionReferenceSectionIdentifier = 'A'
    AND s.ContractCertaintyStatus IN ('Incomplete', 'No Status')
    AND s.FK_Policy = s1.FK_Policy
)



----/* BI-9254 */

--UPDATE s 
--SET IsGblPgm = 'Yes'  
--FROM  #Section s 
--INNER JOIN 
--ODS.GlobalProgrammeRisk gpr 
--ON s.PK_Section = gpr.FK_Section 

----/*BI-9254*/


UPDATE p SET
AnySectionHasExceptionDocument                  = CASE WHEN x.ExceptionDocumentCount > 0 THEN 1 ELSE 0 END
,EarliestRationaleQuestionnaireDate             = COALESCE(p.EarliestRationaleQuestionnaireDate,x.EarliestRationaleQuestionnaireDate) -- do not update it for unirisx, we update this value in the polciy proc
,EarliestRationaleDocumentDate                  = x.EarliestRationaleDocumentDate
,EarliestRationaleDate                          = COALESCE(p.EarliestRationaleDate,x.EarliestRationaleDate)
,RationaleCompletionMethod                      = CASE
                                                    WHEN x.SectionCount = x.RationaleNACount THEN 'N/A'
                                                    WHEN x.RationaleQuestionnaireCount > 0 AND x.RationaleDocumentCount > 0 THEN 'Questionnaire and Document'
                                                    WHEN x.RationaleQuestionnaireCount > 0 THEN 'Questionnaire'
                                                    WHEN x.RationaleDocumentCount > 0 THEN 'Document'
                                                    ELSE 'Incomplete'
                                                  END
,EarliestExceptionDocumentDate                  = x.EarliestExceptionDocumentDate
,EarliestFirstLiveDate                          = x.EarliestFirstLiveDate
,LatestFirstLiveDate                            = x.LatestFirstLiveDate
FROM
#Policy p
INNER JOIN
(
    SELECT
    FK_Policy                           = s.FK_Policy
    ,RenewalCount                       = SUM(CAST(s.IsRenewal AS int))
    ,RationaleQuestionnaireCount        = SUM(CAST(s.RationaleQuestionnaireComplete AS int))
    ,RationaleDocumentCount             = SUM(CAST(s.HasRationaleDocument AS int))
    ,ExceptionDocumentCount             = SUM(CAST(s.HasExceptionDocument AS int))
    ,EarliestRationaleQuestionnaireDate = MIN(s.RationaleQuestionnaireDate)
    ,EarliestRationaleDocumentDate      = MIN(s.RationaleDocumentDate)
    ,EarliestRationaleDate              = MIN([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate]))
    ,EarliestExceptionDocumentDate      = MIN(s.ExceptionDocumentDate)
    ,SectionCount                       = COUNT(1)
    ,RationaleNACount                   = SUM(CASE WHEN s.RationaleCompletionMethod = 'N/A' THEN 1 ELSE 0 END)
    ,EarliestFirstLiveDate              = MIN(s.FirstLiveDate)
    ,LatestFirstLiveDate                = MAX(s.FirstLiveDate)
    FROM
    #Section s 
    GROUP BY
    s.FK_Policy
) x ON
p.PK_Policy = x.FK_Policy
WHERE
p.PK_Policy <> 0


/*
Update ContractCertaintyRequired flag
Contract certainty is required for:
 - All open market policies (i.e. not a facility or a dec)
 - External facilities, not external decs (external is where binder type <> 4)
 - Internal decs, but not internal facilities  (internal is where binder type = 4)
 - Eurobase sections only
 - "Real" sections only
 - Sections A&J only
 - Not 'A' sections where another 'A' section has been completed
*/




--added for ticket: Categorisation of Admitted/Non-Admitted/Lloyds business across source systems (516)
UPDATE p SET
AdmittedNonAdmitted   
			      = CASE
                        WHEN s.CarrierIndicator in ('BICI', 'BAIC') THEN 'Admitted'
                        WHEN s.CarrierIndicator in ('BUSA', 'BESI', 'BUSB') THEN 'Non-Admitted'
						WHEN s.CarrierIndicator = 'Non US carrier' THEN 'Lloyds'
                    END
FROM
#Policy p
INNER JOIN #Section s on  p.PK_Policy = s.FK_Policy
INNER JOIN ODS.TriFocus tf with (nolock) ON s.FK_TriFocus = tf.PK_TriFocus
WHERE p.SourceSystem NOT IN ('BeazleyPro', 'Gamechanger', 'myBeazley')
OR (p.SourceSystem = 'myBeazley' AND s.Product = 'MyBeazley Broker Access PCG' )


																				
UPDATE s
SET	 s.KeyBrokerName			= crm.BrokerName
	,s.KeyBrokerSourceId	= crm.AccountNumber
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM #Policy p 	
INNER JOIN #Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.CRMBroker crm with (nolock) 
	ON crm.PK_CRMBroker = p.FK_CRMBroker
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k with (nolock) 
	ON p.SourceSystem = k.SourceSystem 
	   AND  k.SourceBrokerName = crm.BrokerName 
	   AND k.MappingRule_Name = 'CRM Broker'
WHERE s.sourcesystem IN ('BeazleyPro', 'FDR', 'GameChanger','US High Value Homeowners', 'USHVH', 'CIPS')

--12 min with udf_FormatBitAsYesNo / 3 min without udf_FormatBitAsYesNo
update	#Section
set		FK_ExceptionDocumentDate                   = IIF(YEAR(ExceptionDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ExceptionDocumentDate),DATEADD(DAY, -53690, 0))--([Utility].[udf_GenerateDateKey]([ExceptionDocumentDate])) 
		,FK_ContractCertaintyDocumentDate          = IIF(YEAR(ContractCertaintyDocumentDate) BETWEEN 1990 AND 2050, DATEDIFF(DAY, 0, ContractCertaintyDocumentDate),DATEADD(DAY, -53690, 0))--([Utility].[udf_GenerateDateKey]([ContractCertaintyDocumentDate]))  
		,RationaleDate                             = ([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate])) 
		,EarliestLPSOPremiumSigningNumberName      = (isnull(CONVERT([varchar](255),[EarliestLPSOPremiumSigningNumber]),''))
		,HasRationaleDocumentName                  = IIF(HasRationaleDocument = 1 , 'Yes' , 'No')  ----([ODS].[udf_FormatBitAsYesNo]([HasRationaleDocument]))
		,HasTreatyAggsTerritoryName                = IIF(HasTreatyAggsTerritory = 1 , 'Yes' , 'No')--([ODS].[udf_FormatBitAsYesNo]([HasTreatyAggsTerritory]))
		,HasUnderwriterAuthorityExceptionName      = IIF(HasUnderwriterAuthorityException = 1 , 'Yes' , 'No') --([ODS].[udf_FormatBitAsYesNo]([HasUnderwriterAuthorityException])) 
		,LatestLPSOPremiumSigningNumberName        = (isnull(CONVERT([varchar](255),[LatestLPSOPremiumSigningNumber]),''))
		,HasExceptionDocumentName                  = IIF(HasExceptionDocument = 1 , 'Yes' , 'No') --([ODS].[udf_FormatBitAsYesNo]([HasExceptionDocument]))
		,RationaleDateName                         = CASE WHEN RationaleQuestionnaireDate>RationaleDocumentDate AND YEAR(RationaleDocumentDate)<>1753 THEN FORMAT(RationaleDocumentDate, 'dd-MMM-yyyy')
					                                      WHEN RationaleQuestionnaireDate<RationaleDocumentDate AND YEAR(RationaleQuestionnaireDate)<>1753  THEN FORMAT(RationaleQuestionnaireDate, 'dd-MMM-yyyy')
					                                      ELSE FORMAT(ISNULL(RationaleQuestionnaireDate,RationaleDocumentDate),'dd-MMM-yyyy') END--([ODS].[udf_FormatDateTime]([Utility].[udf_EarlierDate]([RationaleQuestionnaireDate],[RationaleDocumentDate])))                                             
		,HasContractCertaintyDocumentName          = IIF(HasContractCertaintyDocument = 1 , 'Yes' , 'No')--([ODS].[udf_FormatBitAsYesNo]([HasContractCertaintyDocument])) 
		,ContractCertaintyPreBindOnTimeName        = IIF(ContractCertaintyPreBindOnTime = 1, 'On Time','Not On Time') --([ODS].[udf_FormatBit]([ContractCertaintyPreBindOnTime],'On Time','Not On Time','Not On Time')) 



 /* BI-5937 Start*/
 
 -- Update ConsecutiveNumberOfPolicyRenewals in ODS.Policy
 
 
 ;WITH cte_exp_p AS (

    SELECT   p.PK_Policy
			,p.PolicyReference
			,p.ExpiringPolicy
			,ConsecutiveNumberOfPolicyRenewals = CASE WHEN p.ExpiringPolicy IS NULL THEN 0 ELSE 1 END
	FROM #Policy p
	LEFT JOIN #Policy e on p.ExpiringPolicy = e.PolicyReference
	WHERE p.IsQuote = 0
	and e.PolicyReference is null

    UNION ALL

    SELECT   p.PK_Policy
			,p.PolicyReference
			,p.ExpiringPolicy
			,ConsecutiveNumberOfPolicyRenewals = e.ConsecutiveNumberOfPolicyRenewals + 1
	FROM #Policy p
	     INNER JOIN  cte_exp_p e on p.ExpiringPolicy = e.PolicyReference
    WHERE p.IsQuote = 0
)

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = c.ConsecutiveNumberOfPolicyRenewals
FROM cte_exp_p c
     INNER JOIN #Policy p ON c.PK_Policy = p.PK_Policy
WHERE c.ConsecutiveNumberOfPolicyRenewals <> 0

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = REVERSE(SUBSTRING(REVERSE(PolicyReference),0,CHARINDEX('_',REVERSE(PolicyReference)))) - 1
FROM  #Policy p
WHERE SourceSystem = 'CIPS'


UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = CASE WHEN ISNUMERIC(RIGHT(BrokerAccessPolicyNumber, 1)) = 1 AND BrokerAccessPolicyNumber LIKE ('%Renewal%') THEN RIGHT(BrokerAccessPolicyNumber, 1)
	                                                WHEN BrokerAccessPolicyNumber NOT LIKE ('%Renewal%') THEN 0 
													ELSE 1 END
FROM #Policy p with (nolock)
WHERE BrokerAccessPolicyNumber IS NOT NULL
AND SourceSystem = 'Unirisx'


;with cte_bapn AS (
SELECT PolicyReference,
       ROW_NUMBER () OVER (PARTITION BY p.BrokerAccessPolicyNumber ORDER BY p.PolicyReference) as RowNo,
	   BrokerAccessPolicyNumber
FROM  #Policy p with (nolock) 
WHERE p.BrokerAccessPolicyNumber IN (
										SELECT p.BrokerAccessPolicyNumber
										FROM #Policy p with (nolock) 
												 INNER JOIN BeazleyIntelligenceLanding.Unirisx_FullSet.Policy up on p.PolicyReference = up.PolicyReference
										WHERE SourceSystem = 'unirisx'
											AND p.BrokerAccessPolicyNumber like 'BFR%'
											AND (up.UniquePolicyReference LIKE '%PCG' OR up.UniquePolicyReference LIKE '%Broker Access')
										GROUP BY   p.BrokerAccessPolicyNumber
										HAVING COUNT(p.BrokerAccessPolicyNumber) > 1
										--ORDER BY BrokerAccessPolicyNumber, PolicyReference									
									)
					)

UPDATE p
SET ConsecutiveNumberOfPolicyRenewals = t.RowNo - 1
FROM #Policy p with (nolock) 
INNER JOIN cte_bapn t on p.PolicyReference = t.PolicyReference 
WHERE p.BrokerAccessPolicyNumber IS NOT NULL
AND p.SourceSystem = 'Unirisx'


/*Days between quote/bind and earliest rationale date*/
UPDATE s SET
DaysBetweenQBAndPERDate                = DATEDIFF(DAY, s.QuoteOrBindDate, p.EarliestRationaleDate)
,DaysBetweenQBAndPERDateName		   = format(DATEDIFF(DAY, s.QuoteOrBindDate, p.EarliestRationaleDate), '###,###,###,###')--[ODS].[udf_FormatInt](DATEDIFF(DAY, s.QuoteOrBindDate, p.EarliestRationaleDate))
FROM
#Section s
INNER JOIN
#Policy p ON
s.FK_Policy = p.PK_Policy
WHERE
p.PK_Policy <> 0


/*Update IsSlipAttached field in section*/

UPDATE sec

SET IsSlipAttached = 'Yes'

FROM #Section sec

INNER JOIN ODS.Document doc with (nolock) ON
sec.PK_Section = doc.FK_Section

INNER JOIN ods.DocumentType doctype with (nolock) ON
doc.FK_DocumentType = doctype.PK_DocumentType

WHERE doctype.DocumentTypeName = 'Slips'

-- Default to N/A the rest of the sections of a policy where there is at least one slip attached in one section already.
UPDATE s

SET IsSlipAttached = CASE WHEN s.IsSlipAttached = 'Yes' THEN 'Yes' 
                     ELSE      'N/A' 
                     END

FROM #Section s

INNER JOIN #Policy p ON
s.FK_Policy = p.PK_Policy

INNER JOIN(
	        SELECT DISTINCT p.PK_Policy

	        FROM #Policy p
	        
            INNER JOIN #Section s
	        ON  p.PK_Policy = s.FK_Policy
	        AND s.IsSlipAttached = 'Yes'
           )sa ON
p.PK_Policy = sa.PK_Policy



/* 
Update the BeazleyOfficeLocationDerived, BeazleyOfficeLocationDerivedCountry/Region fields in the ODS.Section table 
The quality of the BeazleyOfficeLocation field in the source systems is not great so we have implemented these new 
derived fields and populated them with the rules below to support the BI Qlik dashboards.

Rule 1	Do not display the BeazleyOfficeLocation from Eurobase for policies which have another source system policy reference (rekeyed).			
Rule 2	If the section reference matches the source system listed in the 'Source system' tab, use the allocated country.				
Rule 3	If the binder type = 4, look up to the service company location tab. Look up the facility left 6 characters and match to the allocated country.				
Rule 4	If the section reference matches the section reference displayed in the location from section LVL, select the corresponding country.				
Rule 5	Look up to the UW defaults, match the UW to the allocated location.
Rule 6  For the remaining values use the BeazleyOfficeLocation already extracted from the source system				

-- Used for testing
SELECT 
     SectionReference
    ,BeazleyOfficeLocation
    ,BeazleyOfficeLocationDerived
    ,BeazleyOfficeLocationDerivedCountry
    ,BeazleyOfficeLocationDerivedRegion
	,pol.SourceSystem

FROM ODS.Section sec

INNER JOIN ODS.Policy pol
ON sec.FK_Policy = pol.PK_Policy

WHERE BeazleyOfficeLocationDerived IS NOT NULL
AND pol.IsQuote = 0


--Reset
UPDATE sec
SET sec.BeazleyOfficeLocationDerived = NULL
FROM ODS.Section sec

*/

-- Rule 02: If the section reference matches the source system listed in the 'Source system' tab, use the allocated country.

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = src.Country_Name

FROM #Section sec

INNER JOIN #Policy pol
ON sec.FK_Policy = pol.PK_Policy

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationSourceSystemRule] src with (nolock) 
ON pol.SourceSystem = RTRIM(LTRIM(src.SourceSystem_Name))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 03: If the binder type = 4, look up to the service company location tab. Look up the facility left 6 characters and match to the allocated country

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = bin.Country_Name

FROM #Section sec

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationServiceCompanyLocationRule] bin with (nolock) 
ON LEFT(sec.Facility,6) = RTRIM(LTRIM(LEFT(bin.FacilityReference,6)))

WHERE sec.BinderType = '4'
  AND sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 04: If the section reference matches the section reference displayed in the location from section LVL, select the corresponding country

UPDATE sec

SET sec.BeazleyOfficeLocationDerived = offi.Country_Name

FROM #Section sec

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationFromSectionLVLRule] offi with (nolock) 
ON sec.SectionReference = RTRIM(LTRIM(offi.SectionReference))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 05: look up to the UW defaults, match the UW to the allocated location
UPDATE sec

SET sec.BeazleyOfficeLocationDerived = offi.Country_Name

FROM #Section sec

INNER JOIN ODS.Underwriter und with (nolock) 
ON sec.FK_Underwriter = und.PK_Underwriter

INNER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationUnderwriterDefaultsRule] offi with (nolock) 
ON und.UnderwriterName = RTRIM(LTRIM(offi.Underwriter))

WHERE sec.BeazleyOfficeLocationDerived IS NULL

-- Rule 01:
UPDATE sec

SET sec.BeazleyOfficeLocationDerived = s_source.BeazleyOfficeLocation

FROM #Section sec

INNER JOIN #Policy p 
ON sec.FK_Policy = p.PK_Policy

INNER JOIN #Section s_source
ON sec.PK_Section = s_source.FK_LinkedSynergySection

WHERE sec.PK_Section <> 0
  AND p.SourceSystem = 'Eurobase'
  AND sec.BeazleyOfficeLocationDerived IS NULL
  AND COALESCE(s_source.BeazleyOfficeLocation,'')<>''

  -- Rule 06:
--UPDATE sec

--SET sec.BeazleyOfficeLocationDerived = sec.BeazleyOfficeLocation

--FROM ODS.Section sec

--WHERE sec.PK_Section <> 0
--  AND sec.BeazleyOfficeLocationDerived IS NULL
--  AND COALESCE(sec.BeazleyOfficeLocation,'')<>''


  ---- Now calculate the country and region fields based on the mapping tables in the staging schema.

  UPDATE sec

  SET sec.[FK_OfficeLocationCountry]		  = 0 --co.PK_OfficeLocationCountry 
     ,sec.[FK_OfficeLocationRegion]			  = 0 -- re.PK_OfficeLocationRegion
	 ,sec.BeazleyOfficeLocationDerivedRegion  = RTRIM(LTRIM(re.[Name]))
	 ,sec.BeazleyOfficeLocationDerivedCountry = RTRIM(LTRIM(co.[Name]))
  FROM #Section sec

  LEFT OUTER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationCountry] co --UC.OfficeLocationCountry co
  ON sec.BeazleyOfficeLocationDerived = RTRIM(LTRIM(co.[Name]))

  LEFT OUTER JOIN [Staging_MDS].[MDS_Staging].[UCOfficeLocationRegion] re --UC.OfficeLocationRegion re
  ON RTRIM(LTRIM(co.[Region_Code])) = RTRIM(LTRIM(re.[Code]))
    

UPDATE s
SET	s.KeyBrokerName			= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerName
									WHEN s.CarrierIndicator IN ('BUSA','BAIC','BUSB','BESI') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerName
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerName
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerName
	
								END
	,s.KeyBrokerSourceId	= CASE  WHEN s.sourcesystem = 'Eurobase' 
									AND pb.BrokerName <> 'BPR XCHANGING BROKER' AND pb.BrokerName NOT LIKE 'BSIL%' AND pb.BrokerName NOT LIKE 'BSOL%'
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='BICI' AND s.sourcesystem in ('BeazleyAccess','FDR')
										THEN pb.BrokerNumber
									WHEN s.CarrierIndicator IN ('BUSA','BAIC','BUSB','BESI') AND s.sourcesystem in ('BeazleyAccess','FDR','myBeazley','US High Value Homeowners', 'USHVH')
										THEN pb.BrokerNumber
									WHEN s.sourcesystem = 'Unirisx' AND (p.FK_PartyBrokerProducing = 0 OR p.FK_PartyBrokerProducing IS NULL
																		 OR pb_producing.BrokerName = 'BEAZLEY POOL RE' )
										 THEN pb.BrokerNumber
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('BeazleyTrade IDL','EazyPro','Etrek','myBeazley') 
										THEN pb.BrokerNumber
	
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM #Policy p 	
INNER JOIN #Section s 
	ON p.PK_Policy = s.FK_Policy
LEFT JOIN  ODS.PartyBroker pb with (nolock) 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerPlacing
LEFT JOIN ODS.PartyBroker pb_producing with (nolock) 
	ON pb_producing.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k with (nolock) 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Placing Broker'	
WHERE s.sourcesystem IN ('BeazleyAccess','FDR','myBeazley','BeazleyTrade IDL','EazyPro','Etrek','Eurobase','US High Value Homeowners', 'USHVH','Unirisx')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')


UPDATE s
SET	s.KeyBrokerName			= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerName
									WHEN  s.sourcesystem = 'Unirisx' then
										 CASE  --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
											   --WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
											   --THEN 'BOWRING MARSH'
											  WHEN pb.BrokerName = 'BEAZLEY POOL RE'
											  THEN 'N/A'
										 ELSE pb.BrokerName
										 END	
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerName
		
								END
	,s.KeyBrokerSourceId	= 
								CASE WHEN s.sourcesystem = 'Eurobase' 
									 AND ( pb_placing.BrokerName = 'BPR XCHANGING BROKER' OR pb_placing.BrokerName LIKE 'BSIL%' OR pb_placing.BrokerName LIKE 'BSOL%')
										 THEN pb.BrokerNumber
									WHEN  s.sourcesystem = 'Unirisx' THEN
									      CASE --this was a very specific situation with 1 policy written for it
                                               --in the future, if souch cases will appear, they will be treated here, in the same way 
											   --(below code it's removed as we don't have anymore this producing broker)
												  /*WHEN pb.BrokerName = 'OZPRIZE INSURANCE SPECIALISTS PTY LIMITED'
													   THEN (
													SELECT TOP 1  BrokerNumber
													FROM  BeazleyIntelligenceODS.ODS.PartyBroker PB
													INNER JOIN BeazleyIntelligenceODS.ODS.policy p on p.FK_PartyBrokerProducing = pb.PK_PartyBroker
													WHERE BrokerName = 'BOWRING MARSH'
													AND SourceSystem = 'Unirisx')
													*/

												WHEN pb.BrokerName = 'BEAZLEY POOL RE'
												THEN 0
										  ELSE pb.BrokerNumber
										  END
									WHEN s.CarrierIndicator ='Non US carrier' AND s.sourcesystem in ('myBeazley') 
										 THEN  pb.BrokerNumber
								
								END
	,s.KeyBrokerSubGroup	= k.KeyBrokerSubGroup
	,s.KeyBrokerGroup		= k.KeyBrokerGroup
	,s.KeyBrokerCity		= k.KeyBrokerCity
	,s.KeyBrokerCountry		= k.KeyBrokerCountry
FROM #Policy p 	
INNER JOIN #Section s 
	ON p.PK_Policy = s.FK_Policy
INNER JOIN ODS.PartyBroker pb with (nolock) 
	ON pb.PK_PartyBroker = p.FK_PartyBrokerProducing
LEFT JOIN  ODS.PartyBroker pb_placing with (nolock) 
	ON pb_placing.PK_PartyBroker = p.FK_PartyBrokerPlacing 
LEFT JOIN  Staging_MDS.MDS_Staging.KeyBrokerMapping k 
	ON p.SourceSystem = k.SourceSystem 
	   AND k.SourceBrokerName = pb.BrokerName 
	   AND k.MappingRule_Name = 'Producing Broker'
WHERE s.sourcesystem IN ('myBeazley', 'Unirisx','Eurobase')
	  AND ( s.KeyBrokerName IS NULL
			OR s.KeyBrokerName = 'N/A')

UPDATE s
SET	s.KeyBrokerName	= 'Unknown'
FROM #Section s
WHERE s.KeyBrokerName IS NULL
	  OR s.KeyBrokerName = 'N/A'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR s.KeyBrokerName = ''

UPDATE s
SET	s.KeyBrokerSourceId	= 'Unknown'
FROM #Section s
WHERE s.KeyBrokerSourceId IS NULL
	  OR s.KeyBrokerSourceId = 'N/A' 
	  OR s.KeyBrokerSourceId = '0'
	  OR ISNUMERIC(s.KeyBrokerName) = 1
	  OR ISNULL(s.KeyBrokerName,'') = ''




-- Update ESG Trifocus
UPDATE s
SET LinkedESGTrifocus = t.TriFocusName
FROM #Section s
INNER JOIN ODS.TriFocus t ON s.FK_LinkedESGTrifocus = t.PK_TriFocus
where ISNULL(FK_LinkedESGTrifocus, 0) <> 0

UPDATE sec
SET	  NotifiedIndividualsExcDuplicates          = NotifiedIndividuals      
     ,NotifiedIndividualsNameExcDuplicates		= NotifiedIndividualsName
FROM 
#Section sec

UPDATE l
SET  NumberOfSectionsExcLBS = 0
	,NotifiedIndividualsExcDuplicates          = CASE WHEN s.NotifiedIndividuals IS NULL THEN NULL ELSE 0 END    
    ,NotifiedIndividualsNameExcDuplicates	   = NULL
FROM #Section s
INNER JOIN #Section l 
ON s.FK_Policy = l.FK_Policy 
AND s.FK_ClassOfBusiness = l.FK_ClassOfBusiness
AND ISNULL(s.LimitAmountInLimitCCY,0) = ISNULL(l.LimitAmountInLimitCCY,0)
AND ISNULL(s.ExcessAmountInLimitCCY,0) = ISNULL(l.ExcessAmountInLimitCCY,0)
AND ISNULL(s.DeductibleAmountInLimitCCY,0) = ISNULL(l.DeductibleAmountInLimitCCY,0)
INNER JOIN ODS.UnderwritingPlatform ups
ON ups.PK_UnderwritingPlatform = s.FK_UnderwritingPlatform
INNER JOIN ODS.UnderwritingPlatform upl
ON upl.PK_UnderwritingPlatform = l.FK_UnderwritingPlatform
WHERE ups.UnderwritingPlatformCode IN ('SYND','LBSM','LBSF')
AND upl.UnderwritingPlatformCode = 'LBS'

UPDATE s
SET RemappedDivision = ISNULL(r.DivisionOverride ,t.Division)
FROM #Section s
INNER JOIN ODS.TriFocus t ON s.FK_TriFocus = t.PK_TriFocus
LEFT JOIN  Staging_MDS.MDS_Staging.RemappedDivision r ON t.TriFocusName = r.Trifocus_Name
AND (CASE WHEN r.SourceSystem_Name IS NOT NULL THEN r.SourceSystem_Name ELSE ISNULL(s.SourceSystem,'') END) =ISNULL(s.SourceSystem,'')
AND (CASE WHEN r.Product IS NOT NULL THEN r.Product ELSE ISNULL(s.Product,'') END) = ISNULL(s.Product,'')
AND (CASE WHEN r.Coverage IS NOT NULL THEN r.Coverage ELSE ISNULL(s.CoverageName,'') END) = ISNULL(s.CoverageName,'')
AND (CASE WHEN r.OfficeLocation IS NOT NULL THEN r.OfficeLocation ELSE ISNULL(s.BeazleyOfficeLocation,'') END) = ISNULL(s.BeazleyOfficeLocation,'')

-- UPDATE ODS.Policy

UPDATE TARGET SET

	  TARGET.BrokerContactName					 = SOURCE.BrokerContactName
	 ,TARGET.SubmittingBrokerContactName		 = SOURCE.SubmittingBrokerContactName
	 ,TARGET.SourceSystem						 = SOURCE.SourceSystem
	 ,TARGET.FACEvidenced						 = SOURCE.FACEvidenced
	 ,TARGET.NotifiedIndividualsMaximum			 = SOURCE.NotifiedIndividualsMaximum
	 ,TARGET.AdmittedNonAdmitted				 = SOURCE.AdmittedNonAdmitted
	 ,TARGET.AnySectionHasExceptionDocument		 = SOURCE.AnySectionHasExceptionDocument
	 ,TARGET.EarliestRationaleQuestionnaireDate	 = SOURCE.EarliestRationaleQuestionnaireDate
	 ,TARGET.EarliestRationaleDocumentDate		 = SOURCE.EarliestRationaleDocumentDate
	 ,TARGET.EarliestRationaleDate				 = SOURCE.EarliestRationaleDate
	 ,TARGET.RationaleCompletionMethod			 = SOURCE.RationaleCompletionMethod
	 ,TARGET.EarliestExceptionDocumentDate		 = SOURCE.EarliestExceptionDocumentDate
	 ,TARGET.EarliestFirstLiveDate				 = SOURCE.EarliestFirstLiveDate
	 ,TARGET.LatestFirstLiveDate				 = SOURCE.LatestFirstLiveDate
	 ,TARGET.ConsecutiveNumberOfPolicyRenewals	 = SOURCE.ConsecutiveNumberOfPolicyRenewals
 FROM ODS.Policy target
INNER JOIN  #Policy source
ON target.PK_Policy = source.PK_Policy


-- UPDATE ODS.Section
	EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'DROP', @SchemaName = 'ODS'

	ALTER TABLE ODS.Section NOCHECK CONSTRAINT ALL
 
UPDATE target
SET
 TARGET.FK_ExceptionDocumentDate 														= SOURCE.FK_ExceptionDocumentDate
, TARGET.FK_ContractCertaintyDocumentDate												= SOURCE.FK_ContractCertaintyDocumentDate
, TARGET.FK_ExpiryDateInForce															= SOURCE.FK_ExpiryDateInForce
, TARGET.FK_FirstLiveDate																= SOURCE.FK_FirstLiveDate
, TARGET.FK_OfficeLocationCountry														= SOURCE.FK_OfficeLocationCountry
, TARGET.FK_OfficeLocationRegion														= SOURCE.FK_OfficeLocationRegion
, TARGET.EngineeringConstructionExpiryDate												= SOURCE.EngineeringConstructionExpiryDate
, TARGET.EngineeringConstructionExpiryDateName											= SOURCE.EngineeringConstructionExpiryDateName
, TARGET.USQuakeMultiplier																= SOURCE.USQuakeMultiplier
, TARGET.USWindMultiplier																= SOURCE.USWindMultiplier
, TARGET.USNonCatMultiplier																= SOURCE.USNonCatMultiplier
, TARGET.NonUSCatMultiplier																= SOURCE.NonUSCatMultiplier
, TARGET.NonUSNonCatMultiplier															= SOURCE.NonUSNonCatMultiplier
, TARGET.OccurrenceTerrorism															= SOURCE.OccurrenceTerrorism
, TARGET.OccurrenceSabotage																= SOURCE.OccurrenceSabotage
, TARGET.OccurrenceRsccmd																= SOURCE.OccurrenceRsccmd
, TARGET.OccurrenceInsurrection															= SOURCE.OccurrenceInsurrection
, TARGET.OccurrenceRevolution      														= SOURCE.OccurrenceRevolution
, TARGET.OccurrenceRebellion       														= SOURCE.OccurrenceRebellion
, TARGET.OccurrenceMutiny          														= SOURCE.OccurrenceMutiny
, TARGET.OccurrenceCoupDEtat       														= SOURCE.OccurrenceCoupDEtat
, TARGET.OccurrenceWar             														= SOURCE.OccurrenceWar
, TARGET.OccurrenceCivilWar																= SOURCE.OccurrenceCivilWar
, TARGET.HoursClause																	= SOURCE.HoursClause
, TARGET.OccurrenceTerrorismName														= SOURCE.OccurrenceTerrorismName
, TARGET.OccurrenceSabotageName    														= SOURCE.OccurrenceSabotageName
, TARGET.OccurrenceRSCCMDName      														= SOURCE.OccurrenceRSCCMDName
, TARGET.OccurrenceInsurrectionName														= SOURCE.OccurrenceInsurrectionName
, TARGET.OccurrenceRevolutionName  														= SOURCE.OccurrenceRevolutionName
, TARGET.OccurrenceRebellionName   														= SOURCE.OccurrenceRebellionName
, TARGET.OccurrenceMutinyName      														= SOURCE.OccurrenceMutinyName
, TARGET.OccurrenceCoupDEtatName   														= SOURCE.OccurrenceCoupDEtatName
, TARGET.OccurrenceWarName         														= SOURCE.OccurrenceWarName
, TARGET.OccurrenceCivilWarName    														= SOURCE.OccurrenceCivilWarName
, TARGET.HoursClauseName																= SOURCE.HoursClauseName
, TARGET.HasRationaleDocument															= SOURCE.HasRationaleDocument
, TARGET.RationaleDocumentDate															= SOURCE.RationaleDocumentDate
, TARGET.HasRationaleDocumentName														= SOURCE.HasRationaleDocumentName
, TARGET.RationaleDocumentDateName														= SOURCE.RationaleDocumentDateName
, TARGET.RationaleDateName																= SOURCE.RationaleDateName
, TARGET.HasExceptionDocument															= SOURCE.HasExceptionDocument
, TARGET.ExceptionDocumentDate															= SOURCE.ExceptionDocumentDate
, TARGET.HasExceptionDocumentName														= SOURCE.HasExceptionDocumentName
, TARGET.ExceptionDocumentDateName									    				= SOURCE.ExceptionDocumentDateName
, TARGET.RationaleCompletionMethod														= SOURCE.RationaleCompletionMethod
, TARGET.HasContractCertaintyDocument													= SOURCE.HasContractCertaintyDocument
, TARGET.ContractCertaintyDocumentDate													= SOURCE.ContractCertaintyDocumentDate
, TARGET.DaysBetweenQBAndCCDocumentDate													= SOURCE.DaysBetweenQBAndCCDocumentDate
, TARGET.ContractCertaintyDocumentDateName												= SOURCE.ContractCertaintyDocumentDateName
, TARGET.DaysBetweenQBAndCCDocumentDateName												= SOURCE.DaysBetweenQBAndCCDocumentDateName
, TARGET.HasContractCertaintyDocumentName												= SOURCE.HasContractCertaintyDocumentName
, TARGET.LatestPICCPeriod																= SOURCE.LatestPICCPeriod
, TARGET.MissingPICCTransactions														= SOURCE.MissingPICCTransactions
, TARGET.HasMissingPICCTransactions														= SOURCE.HasMissingPICCTransactions
, TARGET.MissingPICCTransactionsName													= SOURCE.MissingPICCTransactionsName
, TARGET.HasMissingPICCTransactionsName													= SOURCE.HasMissingPICCTransactionsName
, TARGET.ExpiryDateInForce																= SOURCE.ExpiryDateInForce
, TARGET.ExternalAcquisitionCostMultiplier												= SOURCE.ExternalAcquisitionCostMultiplier
, TARGET.ExternalAcquisitionCostMultiplierName											= SOURCE.ExternalAcquisitionCostMultiplierName
, TARGET.OriginalEPITotalAcquisitionCostMultiplier										= SOURCE.OriginalEPITotalAcquisitionCostMultiplier
, TARGET.RateChangeControlComplete														= SOURCE.RateChangeControlComplete
, TARGET.RationaleQuestionnaireComplete													= SOURCE.RationaleQuestionnaireComplete
, TARGET.RationaleQuestionnaireDate														= SOURCE.RationaleQuestionnaireDate
, TARGET.RationaleDate																	= SOURCE.RationaleDate
, TARGET.RationaleQuestionnaireCompleteName												= SOURCE.RationaleQuestionnaireCompleteName
, TARGET.RateChangeControlCompleteName													= SOURCE.RateChangeControlCompleteName
, TARGET.RationaleQuestionnaireDateName													= SOURCE.RationaleQuestionnaireDateName
, TARGET.RateChangeExposureMultiplier													= SOURCE.RateChangeExposureMultiplier
, TARGET.RateChangeRiskMultiplier														= SOURCE.RateChangeRiskMultiplier
, TARGET.RateChangeDeductibleMultiplier													= SOURCE.RateChangeDeductibleMultiplier
, TARGET.RateChangeLimitMultiplier														= SOURCE.RateChangeLimitMultiplier
, TARGET.RateChangeTermsAndConditionsMultiplier											= SOURCE.RateChangeTermsAndConditionsMultiplier
, TARGET.RateChangeOtherMultiplier														= SOURCE.RateChangeOtherMultiplier
, TARGET.HasTreatyAggsTerritory															= SOURCE.HasTreatyAggsTerritory
, TARGET.HasTreatyAggsTerritoryName														= SOURCE.HasTreatyAggsTerritoryName
, TARGET.FirstLiveDate     																= SOURCE.FirstLiveDate
, TARGET.FirstLiveDateName																= SOURCE.FirstLiveDateName
, TARGET.HasUnderwriterAuthorityException												= SOURCE.HasUnderwriterAuthorityException
, TARGET.HasUnderwriterAuthorityExceptionName											= SOURCE.HasUnderwriterAuthorityExceptionName
, TARGET.ContractCertaintyStatus														= SOURCE.ContractCertaintyStatus
, TARGET.ContractCertaintyStatusSortOrder												= SOURCE.ContractCertaintyStatusSortOrder
, TARGET.ContractCertaintyPreBindComplete												= SOURCE.ContractCertaintyPreBindComplete
, TARGET.ContractCertaintyPreBindOnTime													= SOURCE.ContractCertaintyPreBindOnTime
, TARGET.ContractCertaintyPreBindOnTimeName												= SOURCE.ContractCertaintyPreBindOnTimeName
, TARGET.ContractCertaintyPreBindCompleteName											= SOURCE.ContractCertaintyPreBindCompleteName
, TARGET.ContractCertaintyRequired														= SOURCE.ContractCertaintyRequired
, TARGET.ContractCertaintyRequiredName													= SOURCE.ContractCertaintyRequiredName
, TARGET.IsBeazleyLead																	= SOURCE.IsBeazleyLead
, TARGET.IsBeazleyLeadName																= SOURCE.IsBeazleyLeadName
, TARGET.NumberOfBeazleyLed																= SOURCE.NumberOfBeazleyLed
, TARGET.KeyBrokerName																	= SOURCE.KeyBrokerName
, TARGET.KeyBrokerSourceId																= SOURCE.KeyBrokerSourceId
, TARGET.KeyBrokerSubGroup																= SOURCE.KeyBrokerSubGroup
, TARGET.KeyBrokerGroup																	= SOURCE.KeyBrokerGroup
, TARGET.KeyBrokerCity																	= SOURCE.KeyBrokerCity
, TARGET.KeyBrokerCountry																= SOURCE.KeyBrokerCountry
, TARGET.EarliestLPSOPremiumSigningNumberName											= SOURCE.EarliestLPSOPremiumSigningNumberName
, TARGET.LatestLPSOPremiumSigningNumberName												= SOURCE.LatestLPSOPremiumSigningNumberName
, TARGET.DaysBetweenQBAndPERDate														= SOURCE.DaysBetweenQBAndPERDate
, TARGET.DaysBetweenQBAndPERDateName													= SOURCE.DaysBetweenQBAndPERDateName
, TARGET.IsSlipAttached																	= SOURCE.IsSlipAttached
, TARGET.BeazleyOfficeLocationDerived													= SOURCE.BeazleyOfficeLocationDerived
, TARGET.BeazleyOfficeLocationDerivedRegion												= SOURCE.BeazleyOfficeLocationDerivedRegion
, TARGET.BeazleyOfficeLocationDerivedCountry											= SOURCE.BeazleyOfficeLocationDerivedCountry
, TARGET.LinkedESGTrifocus																= SOURCE.LinkedESGTrifocus
, TARGET.NotifiedIndividualsExcDuplicates												= SOURCE.NotifiedIndividualsExcDuplicates
, TARGET.NotifiedIndividualsNameExcDuplicates											= SOURCE.NotifiedIndividualsNameExcDuplicates
, TARGET.RemappedDivision																= SOURCE.RemappedDivision
, TARGET.NumberOfSectionsExcLBS                                                         = SOURCE.NumberOfSectionsExcLBS
--, TARGET.IsGblPgm																		= SOURCE.IsGblPgm
FROM
ODS.Section target
INNER JOIN #Section source
ON target.PK_Section = source.PK_Section

DROP TABLE IF EXISTS #Section
DROP TABLE IF EXISTS #Policy

	ALTER TABLE ODS.Section CHECK CONSTRAINT ALL

	EXEC Utility.usp_DropRecreateTableIndexes @TableName = 'Section' , @Action = 'CREATE', @SchemaName = 'ODS'
GO
