﻿CREATE PROCEDURE [ODS].[usp_LoadUnderwritingPlatform]
AS
SET NOCOUNT ON


IF OBJECT_ID('tempdb..#UnderwritingPlatform') IS NOT NULL
DROP TABLE #UnderwritingPlatform

CREATE TABLE #UnderwritingPlatform
(
    [IsUnknownMember]            [bit] DEFAULT ((0)) NULL,
    [IsBID]                      [bit] NOT NULL,
    [IsFiltered]                 [bit] DEFAULT ((0)) NOT NULL,
    [UnderwritingPlatformCode]   [varchar] (255) NOT NULL,
    [UnderwritingPlatformName]   [varchar] (255) NOT NULL,
   
)

INSERT INTO #UnderwritingPlatform
(
    IsUnknownMember
    ,IsBID 
    ,IsFiltered	
    ,UnderwritingPlatformCode
    ,UnderwritingPlatformName 
)

SELECT IsUnknownMember
	   ,IsBID 
	   ,IsFiltered	
       ,UnderwritingPlatformCode
       ,UnderwritingPlatformName 
FROM (
	SELECT 
		    IsUnknownMember
			,IsBID 
		   ,IsFiltered	
		   ,UnderwritingPlatformCode
		   ,UnderwritingPlatformName
		   ,UWPlatformRowNumber       = ROW_NUMBER() OVER(PARTITION BY UnderwritingPlatformCode ORDER BY LEN(UnderwritingPlatformName) DESC)
	FROM
		   (
			SELECT DISTINCT
					IsUnknownMember            = 0
					,IsBID                     = CASE WHEN UWP.UnderwritingPlatformCode = 'BID' THEN 1 ELSE 0 END
					,IsFiltered				   = CASE WHEN UWP.UnderwritingPlatformCode = 'SPA' THEN 1 ELSE 0 END
					,UnderwritingPlatformCode  = MUP.UnderwritingPlatformCode
					,UnderwritingPlatformName  = MUP.UnderwritingPlatformName
				
			FROM 
					BeazleyIntelligenceDataContract.Outbound.vw_Section AS UWP
					INNER JOIN Staging_MDS.MDS_Staging.UnderwritingPlatform MUP
                    ON UWP.UnderwritingPlatformCode = MUP.UnderwritingPlatformCode

			WHERE   UWP.SourceSystem IN ('Eurobase', 'Unirisx', 'myBeazley','GameChanger', 'BeazleyPro')
					AND UWP.UnderwritingPlatformCode IS NOT NULL
					AND UnderwritingPlatform IS NOT NULL					
		
			UNION

			SELECT 
					 IsUnknownMember            = 0
			 		,IsBID						= 0 
					,IsFiltered					= 0
					,UnderwritingPlatformCode	= 'MULTI'
					,UnderwritingPlatformName	= 'Multiple Underwriting Platforms'

			UNION

			SELECT
		            IsUnknownMember             = 1
		           ,IsBID					    = 0
		           ,IsFiltered				    = 0
		           ,UnderwritingPlatformCode    = 'N/A'
		           ,UnderwritingPlatformName	= 'N/A'

				) UWPT
		  )a 
WHERE 
     UWPlatformRowNumber = 1



MERGE [ODS].UnderwritingPlatform target
USING
#UnderwritingPlatform source
ON  target.UnderwritingPlatformCode		= source.UnderwritingPlatformCode
AND target.IsUnknownMember	= source.IsUnknownMember

WHEN MATCHED THEN 
UPDATE 
SET 
 target.IsUnknownMember    			= source.IsUnknownMember
,target.IsBID						= source.IsBID
,target.IsFiltered					= source.IsFiltered
,target.UnderwritingPlatformCode	= source.UnderwritingPlatformCode
,target.UnderwritingPlatformName	= source.UnderwritingPlatformName
,target.AuditModifyDateTime         = GETDATE()
,target.AuditModifyDetails          = 'Merge in [ODS].[usp_LoadUnderwritingPlatform] proc' 


WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
	IsUnknownMember
	,IsBID
	,IsFiltered
	,UnderwritingPlatformCode
	,UnderwritingPlatformName
	,AuditCreateDateTime   
	,AuditModifyDetails 
)
VALUES
(
	 source.IsUnknownMember
	,source.IsBID
	,source.IsFiltered
	,source.UnderwritingPlatformCode
	,source.UnderwritingPlatformName
	,GETDATE()
	,'New add in [ODS].[usp_LoadUnderwritingPlatform] proc'
)

WHEN NOT MATCHED BY SOURCE THEN DELETE
;