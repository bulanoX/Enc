﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [ODS].[usp_LoadClaimExposure]
AS
BEGIN

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.ClaimExposure
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

-- Remove deactivated data
DELETE FROM ODS.ClaimExposure 
WHERE   ExposureReference NOT IN (SELECT ClaimExposureSourceId FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure)
		OR OriginatingBureau NOT IN (SELECT OriginatingBureau  FROM  BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure )
		OR FK_Claim NOT IN  (SELECT PK_Claim FROM ODS.Claim)

MERGE ODS.ClaimExposure target
USING 
(
SELECT distinct
	 FK_Claim													= C.PK_Claim --'from join using ODS.Claim on BeazleyClaimReference'--------- ce.FK_Claim
	,AllegationOfDiscrimination									= cee.AllegationOfDiscrimination
	,AnyNonMovingNoteIndicator									= COALESCE(NULLIF(cen.NonMovingNoteBrokerIndicator,0), NULLIF(cen.NonMovingNoteInsuredIndicator,0), NULLIF(cen.NonMovingNoteOtherIndicatoR,0), NULLIF(cen.NonMovingNoteXCSIndicator,0), 0)--NULL--'update using #ClaimExposure and #ExposureNote'---------cee.AnyNonMovingNoteIndicator
	,AreaOfPractice												= ce.AreaOfPractice
	,AreaOfPracticeCode											= ce.AreaOfPracticeCode
	,AmountOfOriginalLossFund                                   = cee.AmountOfOriginalLossFund
	,BatteryBrand                                               = cee.BatteryBrand
	,BBRServicesManager											= cee.BBRServicesManager
	,BBRServicesNoteIndicator									= ISNULL(cen.BBRServicesNoteIndicator, 0)
	,BadFaithIndicator											= cee.BadFaithIndicator
	,BadFaithNoteIndicator                                      = cen.BadFaithNoteIndicator
	,BeazleyCat													= cec.NatCatName --ce.BeazleyCat
	,BeazleyCatCode												= cec.BeazleyCatCode --ce.BeazleyCatCode
	,BeazleyCatDateOfLoss										= CASE WHEN cec.BeazleyCatCode IN ('B', 'LF') THEN NULL ELSE cec.BeazleyCatDateOfLossTo  END --ce.BeazleyCatDateOfLoss
	,BeazleyCatDateOfLossTo										= CASE WHEN cec.BeazleyCatCode IN ('B', 'LF') THEN NULL ELSE cec.NatCatEndDate           END --cee.BeazleyCatDateOfLossTo
	,BeazleyCatLongDescription									= cec.BeazleyCatLongDescription --ce.BeazleyCatLongDescription
	,BinderReference											= ce.BinderReference
	,BinderYOA													= ce.BinderYOA
	,BlendWeightingMultiplier									= COALESCE(Utility.udf_ProcessPercentage(cees.[BlendWeightingMultiplier], 1, 0, 1), 0) --ISNULL(cees.BlendWeightingMultiplier/100, 1)
	,BlockIndicator												= case when cec.BeazleyCatCode = 'B' or cec.NatCatName = 'BLOCK' then 1
																	   when ce.Product = 'Block Entry' then 1
																	   when ce.ClaimantName like '%block%' or ce.ClaimantName like '%bordereaux%' or ce.ClaimantName like '%bdx%' or ce.ClaimantName like '%bordereau%' then 1
																	   when cee.MatterName like '%block%' or cee.MatterName like '%bordereaux%' or cee.MatterName like '%bdx%' or cee.MatterName like '%bordereau%' then 1
																	   else 0
																  end
	,BodilyDeathEmotionalIndicator								= cee.BodilyDeathEmotionalIndicator
	,BondLimit                                                  = cee.BondLimit
	,BondLimitCurrency                                          = cee.BondLimitCurrency
	,BooksAndRecordDemand                                       = cee.BooksAndRecordDemand
	,BreachStatus												= cee.BreachStatus
	,BreachedInformationType									= cee.BreachedInformationType
	,BrokerContactName											= ce.BrokerContactName
	,BrokerReference1											= cee.BrokerReference1
	,BrokerReference2											= cee.BrokerReference2
	,CallCentreAndCreditMonitoringExpiryDate					= cee.CallCentreAndCreditMonitoringExpiryDate
	,CargoCommodity                                             = cee.CargoCommodity
	,CargoConveyance                                            = cee.CargoConveyance
	,CatCodeEndsInLF											= CASE WHEN cec.BeazleyCatCode LIKE '%LF' THEN 1 ELSE 0 END --'update using cee.BeazleyCatCode'---------cee.CatCodeEndsInLF
	,Category													= ISNULL(ce.Category, 'Unknown')
	,CauseOfAction												= cee.CauseOfAction
	,CauseOfLoss												= ce.CauseOfLoss
	,CauseOfLossCode											= ce.CauseOfLossCode
	,CauseOfLossSecondary										= ce.CauseOfLossSecondary
	,CauseOfLossSecondaryCode									= ce.CauseOfLossSecondaryCode			
	,CashAdvanceMade                                            = cee.CashAdvanceMade
	,ClaimOrCircumstance										= cee.ClaimOrCircumstance
	,ClaimsDepartment                                           = ctm.ClaimsDepartment
	,ClaimsTeam                                                 = ctm.ClaimsTeam
	,ClaimsSubTeam												= ctm.ClaimsSubTeam
	,ClaimTeamExaminer											= NULL --marked as removed - cee.ClaimTeamExaminer
	,ClaimantClientStatus                                       = cee.ClaimantClientStatus
	,ClaimantGender												= cee.ClaimantGender
	,ClaimantJobCategory										= cee.ClaimantJobCategory
	,ClaimantJobStatus											= NULL --marked as moved maybe phase 2 - cee.ClaimantJobStatus
	,ClaimantName												= ce.ClaimantName
	,ClaimantSalary												= cee.ClaimantSalary
	,ClaimantSalaryName											= cee.ClaimantSalary
	,ClaimantType												= cee.ClaimantType
	,ClashCatCode												= cecc.ClashCode
	,ClashCatDateOfLoss											= CASE WHEN cecc.ClashCode IN ('B', 'LF') THEN NULL ELSE cecc.ClashCatBeginDate END
	,ClashCatDescription                                        = cecc.ClashCatDescription
	,ClashCatName                                               = cecc.ClashCatName
	,ClientBreakdown											= cee.ClientBreakdown
	,ClosedClaimsInBlock										= cee.ClosedClaimsInBlock
	,ComplexFlag												= cee.ComplexFlag
	--,ConflictOfInterest										= ISNULL(co.ConflictOfInterest, '')
    ,Consultation                                               = ce.Consultation
	,ConsultationNoteIndicator									= ISNULL(cen.ConsultationNoteIndicator, 0)
	,ConsultationUser                                           = ce.ConsultationUser
	,CoverageAgreedDate											= cee.CoverageAgreedDate
	,CoverageDenialIndicator									= cee.CoverageDenialIndicator
	,CoverageIssues												= ce.CoverageIssues
	,CoverageTrigger                                            = cee.CoverageTrigger
	,DateCoverageLetterIssued                                   = ce.DateCoverageLetterIssued
	,DateOfDenial												= ce.DateOfDenial
	,DenialReason												= ce.DenialReason
	,DamageTheory												= cee.DamageTheory
	,DateClaimPaid                                              = NULL
	,DateOfAct                                                  = cee.DateOfAct 
	,DateSinceInitialEstimate									= cee.DateSinceInitialEstimate
	,DateSinceNotReviewed										= cee.DateSinceNotReviewed
	,DateSinceQuantified										= cee.DateSinceQuantified 
	,DefendantOrPlaintiff										= cee.DefendantOrPlaintiff
	,DelegatedPartner                                           = cee.DelegatedPartner
	,DerivativeDemand                                           = cee.DerivativeDemand
	,DerivativeSuit                                             = cee.DerivativeSuit
 	,DeviceEncrypted											= cee.DeviceEncrypted
	,DiscoveryDate												= cee.DiscoveryDate
	,DiscoveryDetails                                           = cee.DiscoveryDetails
	,DispositionOfMatter                                        = ce.DispositionOfMatter
	,DutyToDefend                                               = ce.DutyToDefend
	,ECFIndicator												= CASE WHEN co.UCR IS NOT NULL THEN 1 ELSE 0 END -- Set to 1 when claim.UCR has data(new dev received from Steph) -- ISNULL(cee.ECFIndicator, 0)
	,ECFEntryWithoutSCM											= CASE WHEN (LEN(RTRIM(ISNULL(c.UCR, ''))) > 0 OR LEN(RTRIM(ISNULL(cee.UniqueClaimReference, ''))) > 0) 
																		AND LEN(RTRIM(ISNULL(cee.SCMReference, ''))) = 0 
		   					  											AND ac.AccountingCalendarName  = 'Lloyd’s Finance' THEN 1 ELSE 0 END
	,EndOfWaitingPeriod                                         = cee.EndOfWaitingPeriod
	,EscalatedClaim                                             = ce.EscalatedClaim
	,EvaluationNoteIndicator									= ISNULL(cen.EvaluationNoteIndicator, 0)
	,EventSetting                                               = cee.EventSetting
	,ExGratiaRequested                                          = ce.ExGratiaRequested
	,ExposureClosedDate											= ce.ExposureClosedDate
	,ExposureDescription										= ce.ExposureDescription
	,ExposureHasMovements                                       = NULL -- is populated in PostProcessClaimExposure procedure
	,ExposureOpenedDate											= ce.ExposureOpenedDate
	,ExposureReference											= ce.ClaimExposureSourceId
	,ExposureReopenedDate										= cee.ExposureReopenedDate
	,ExposureReopenedReason										= cee.ExposureReopenedReason
	,ExposureSequenceId											= ce.ClaimExposureSequenceId
	,ExposureStatus												= ce.ExposureStatus
	,ExposureStatusCode											= CASE 
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Closed' THEN 'C'
																	WHEN Utility.udf_ProcessString(ce.ExposureStatusCode,0) = 'Open'   THEN 'O'
																	WHEN (ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Closed' 
																			AND ISNULL(Utility.udf_ProcessString(ce.ExposureStatusCode,0), '') <> 'Open') THEN 'C'
																 END
	,ExposureUpdatedDate										= ce.ExposureUpdatedDate
	,ExternalAdjuster											= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. - cee.ExternalAdjuster
	--,ExternalAdjusterReference								= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. - cee.ExternalAdjusterReference
	,Fil1Code													= cee.Fil1Code
	,FileNoteIndicator											= ISNULL(cen.FileNoteIndicator, 0)
	,FinalExGratiaDecision                                      = ce.FinalExGratiaDecision
	--,FirstExposureClosedDate									= ce.FirstExposureClosedDate
	,FirstPartyCyberLossTypes									= cee.FirstPartyCyberLossTypes
	,ThirdPartyCyberLossTypes									= cee.ThirdPartyCyberLossTypes
	,CyberGroupingExtortion									    = cee.CyberGroupingExtortion	
    ,RansomwarePayment										    = cee.RansomwarePayment
    ,TotalAmountOfRansomwarePayment                             = cee.TotalAmountOfRansomwarePayment
    ,RansomwarePaymentCurrency                                  = cee.RansomwarePaymentCurrency
    ,ReportedToCompliance                                       = cee.ReportedToCompliance
    ,ClassActionCountry                                         = cee.ClassActionCountry
    ,State                                                      = cee.State
    ,RegulatoryInquiry                                          = cee.RegulatoryInquiry
    ,TotalAmountOfFine                                          = cee.TotalAmountOfFine
    ,FineCurrency                                               = cee.FineCurrency
    ,AmountOfBusinessInterruptionSubmission                     = cee.AmountOfBusinessInterruptionSubmission
    ,BusinessInterruptionSubmissionCurrency                     = cee.BusinessInterruptionSubmissionCurrency
    ,AmountOfBusinessInterruptionLossRecognized                 = cee.AmountOfBusinessInterruptionLossRecognized
    ,BusinessInterruptionLossRecognizedCurrency                 = cee.BusinessInterruptionLossRecognizedCurrency
    ,AmountOfDataRecoverySubmission                             = cee.AmountOfDataRecoverySubmission
    ,DataRecoverySubmissionCurrency                             = cee.DataRecoverySubmissionCurrency
    ,AmountOfDataRecoveryLossRecognized                         = cee.AmountOfDataRecoveryLossRecognized
    ,DataRecoveryLossRecognizedCurrency                         = cee.DataRecoveryLossRecognizedCurrency
	,FlaggedNoteIndicator										= ISNULL(cen.FlaggedNoteIndicator, 0)
	,FlaggedNoteOrReasonIndicator								= CASE WHEN cen.FlaggedNoteIndicator = 1 THEN 1 ELSE 0 END --cee.FlaggedNoteOrReasonIndicator
	,FlaggedReason												= cee.FlaggedReason
	,FlaggedReasonIndicator										= CASE 
																	WHEN ce.CoverageIssues = 0 AND ce.OtherReasonToFlag = 0 AND ce.PotentialLargeClaim = 0 THEN 'No'
																	WHEN ce.CoverageIssues = 1 OR  ce.OtherReasonToFlag = 1 OR  ce.PotentialLargeClaim = 1 THEN 'Yes'
																	ELSE 'No'
																  END 
	,GrossLoss                                                  = cee.GrossLoss
	,GrossLossAsAtDate                                          = cee.GrossLossAsAtDate
	,GrossLossCurrency                                          = cee.GrossLossCurrency
	,ISOLossType												= ce.ISOLossType								-- iso.ISOLossType
	,ISOLossTypeCode											= ce.ISOLossTypeCode                            -- iso.ISOLossTypeCode
	,IMO                                                        = cee.IMO
	,IncidentAction												= cee.IncidentAction
	,IndustryAreaOfPracticeSecondaryCode						= ce.IndustryAreaOfPracticeSecondaryCode
	,IndustryAreaOfPracticeSecondaryName						= ce.IndustryAreaOfPracticeSecondaryName
	,InjuryType                                                 = cee.InjuryType
	,InsuredName												= ce.InsuredName
	,InsuredSCMName												= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. -cee.InsuredSCMName
	,InsurersRepresentative										= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. -cee.InsurersRepresentative
	--,InsurersRepresentativeReference							= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. -cee.InsurersRepresentativeReference
	,InsuringClause												= cee.InsuringClause
	,IsMultiSection												= 0 -- marked as removed  - ISNULL(ce.IsMultiSection, 0) 
	,IsNewYorkFreeTradeZone										= 0 -- marked as removed  - ISNULL(cee.IsNewYorkFreeTradeZone, 0)
	,IsRealExposure												= 1 -- NULL--'update depending on SCM/Non-SCM'---------cee.IsRealExposure
	,LastBureauShare                                            = 0
	,LastMovementNarrative										= cee.LastMovementNarrative
	,LastMovementTBAFlag										= ISNULL(cee.LastMovementTBAFlag, 0)
	,LastMovementTBAIndicator									= cee.LastMovementTBAIndicator
	,LatestBadFaithNote                                         = cen.LatestBadFaithNote
    ,LatestBadFaithNoteUpdatedDate                              = cen.LatestBadFaithNoteUpdatedDate
	,LatestBBRServicesNote										= cen.LatestBBRServicesNote
	,LatestBBRServicesNoteUpdatedDate							= cen.LatestBBRServicesNoteUpdatedDate
	,LatestCMSNote												= NULL -- marked as removed  - cee.LatestCMSNote
	,LatestCMSNoteUpdatedDate									= NULL -- marked as removed  - cee.LatestCMSNoteUpdatedDate
	,LatestConsultationNote										= cen.LatestConsultationNote
	,LatestConsultationNoteUpdatedDate							= cen.LatestConsultationNoteUpdatedDate
	,LatestEvaluationNote										= cen.LatestEvaluationNote
	,LatestEvaluationNoteUpdatedDate							= cen.LatestEvaluationNoteUpdatedDate
	,LatestFileNote												= cen.LatestFileNote
	,LatestFileNoteUpdatedDate									= cen.LatestFileNoteUpdatedDate
	,LatestFlaggedNote											= cen.LatestFlaggedNote
	,LatestFlaggedNoteUpdatedDate								= cen.LatestFlaggedNoteUpdatedDate
	,LatestLitigationNote										= cen.LatestLitigationNote
	,LatestLitigationNoteUpdatedDate							= cen.LatestLitigationNoteUpdatedDate
	,LatestLossFundFileNote										= cen.LatestLossFundFileNote
	,LatestLossFundFileNoteUpdatedDate							= cen.LatestLossFundFileNoteUpdatedDate
	,LatestMergedClaimNote                                      = cen.LatestMergedClaimNote
	,LatestMergedClaimNoteUpdatedDate                           = cen.LatestMergedClaimNoteUpdatedDate
	,LatestNonMovingNoteBroker									= cen.LatestNonMovingNoteBroker
	,LatestNonMovingNoteBrokerUpdatedDate						= cen.LatestNonMovingNoteBrokerUpdatedDate
	,LatestNonMovingNoteInsured									= cen.LatestNonMovingNoteInsured
	,LatestNonMovingNoteInsuredUpdatedDate						= cen.LatestNonMovingNoteInsuredUpdatedDate
	,LatestNonMovingNoteOther									= cen.LatestNonMovingNoteOther
	,LatestNonMovingNoteOtherUpdatedDate						= cen.LatestNonMovingNoteOtherUpdatedDate
	,LatestNonMovingNoteXCS										= cen.LatestNonMovingNoteXCS
	,LatestNonMovingNoteXCSUpdatedDate							= cen.LatestNonMovingNoteXCSUpdatedDate
	,LatestPeerReviewNote										= substring(cen.LatestPeerReviewNote,1,8000) 
	,LatestPeerReviewNoteUpdatedDate							= cen.LatestPeerReviewNoteUpdatedDate
	,LatestRecoverySubrogationNote								= cen.LatestRecoverySubrogationNote
	,LatestRecoverySubrogationNoteUpdatedDate					= cen.LatestRecoverySubrogationNoteUpdatedDate
	,LatestRoundtabledNote                                      = cen.LatestRoundtabledNote
	,LatestRoundtabledNoteUpdatedDate                           = cen.LatestRoundtabledNoteUpdatedDate
	,LatestTriageNote											= cen.LatestTriageNote
	,LatestTriageNoteUpdatedDate								= cen.LatestTriageNoteUpdatedDate
	,LatestUnderwritingCommitteeNote							= cen.LatestUnderwritingCommitteeNote
	,LatestUnderwritingCommitteeNoteUpdatedDate					= cen.LatestUnderwritingCommitteeNoteUpdatedDate
	,LawAndJurisdiction											= cee.LawAndJurisdiction
	,LevelOfDelegatedAuthority                                  = cee.LevelOfDelegatedAuthority
	,LevelOfDelegatedAuthorityCurrency                          = cee.LevelOfDelegatedAuthorityCurrency
	,LineOfBusiness												= ce.LineOfBusiness
	,LinkedSCMReference											= NULL --marked as removed - cee.LinkedSCMReference
	,LinkedSynergySection										= NULL --marked as removed - cee.LinkedSynergySection
	,LitigationCounsel                                          = ce.LitigationCounsel  
	,LitigationNoteIndicator									= ISNULL(cen.LitigationNoteIndicator, 0)
	,LitigationStateCode										= cee.LitigationStateCode
	,LitigationStatus											= cee.LitigationStatus
	,LossDetails												= NULL --Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. - ce.LossDetails
	
	,LossFundCurrency                                           = cee.LossFundCurrency
	,LossFundFileNoteIndicator									= ISNULL(cen.LossFundFileNoteIndicator, 0)
	,LossFundHolderReceivedFund                                 = cee.LossFundHolderReceivedFund
	,LossLocationAddressLine1									= cee.LossLocationAddressLine1
	,LossLocationAddressLine2									= cee.LossLocationAddressLine2 --marked as removed  
	,LossLocationCity											= cee.LossLocationCity
	,LossLocationCountry										= cee.LossLocationCountry
	,LossLocationCounty											= cee.LossLocationCounty
	,LossLocationDescription									= cee.LossLocationDescription --Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value.
	,LossLocationPostalCode										= cee.LossLocationPostalCode
	,LossLocationState											= cee.LossLocationState
	,LossLocationStateCode										= cee.LossLocationStateCode
	,LossType                                                   = cee.LossType
	,MainGroupsOfClaimants										= cee.MainGroupsOfClaimants
	,MarketCat													= Utility.udf_ProcessString(m_cat.ShortDescription,1) -- marked as removed  - ce.MarketCat
	,MarketCatCode												= ISNULL(cec.MarketCatCode, Utility.udf_ProcessString(b_cat.MarketCatCode,1))
	,MarketCatDateOfLoss										= CASE 
																		WHEN ISNULL(cec.MarketCatCode, Utility.udf_ProcessString(b_cat.MarketCatCode,1)) IN ('B', 'LF') THEN NULL 
																		ELSE Utility.udf_ProcessEurobaseDate(m_cat.LossDateFrom) 
																	END -- marked as removed  - ce.MarketCatDateOfLoss
	,MarketCatLongDescription									= Utility.udf_ProcessString(m_cat.GroupDescription,1) -- marked as removed - ce.MarketCatLongDescription
	,MarketCatQualifier											= CASE
																		WHEN cec.MarketCatCode IS NOT NULL THEN 'MCC' --Market cat code
																		WHEN Utility.udf_ProcessString(b_cat.MarketCatCode,1) IS NOT NULL THEN 'BMC' --Beazley market cat
																	END -- marked as removed - ce.MarketCatQualifier
	,MatterName													= cee.MatterName
	,Media                                                      = cee.Media
	,MedicareIndicator											= 0 -- marked as moved maybe phase 2 - ISNULL(cee.MedicareIndicator, 0)
	,MedipayIndicator											= 0 -- marked as moved maybe phase 2 - ISNULL(cee.MedipayIndicator, 0)
	,MergedClaimNoteIndicator                                   = ISNULL(cen.MergedClaimNoteIndicator,0)
	,NAIC														= ce.NAIC
	,NAICCode													= ce.NAICCode
	,NetLoss                                                    = cee.NetLoss
	,NetLossAsAtDate                                            = cee.NetLossAsAtDate
	,NetLossCurrency                                            = cee.NetLossCurrency
	,NIARecordTypeCode											= NULL -- marked as removed  - cee.NIARecordTypeCode
	,NonMovingNoteBrokerIndicator								= ISNULL(cen.NonMovingNoteBrokerIndicator, 0)
	,NonMovingNoteInsuredIndicator								= ISNULL(cen.NonMovingNoteInsuredIndicator, 0)
	,NonMovingNoteOtherIndicator								= ISNULL(cen.NonMovingNoteOtherIndicator, 0)
	,NonMovingNoteXCSIndicator									= ISNULL(cen.NonMovingNoteXCSIndicator, 0)
	,NumberOfCallCentreCalls									= cee.NumberOfCallCentreCalls
	,NumberOfClaimants											= cee.NumberOfClaimants
	,NumberOfCodesActivated										= cee.NumberOfCodesActivated
	,NumberOfPeopleNotified										= cee.NumberOfPeopleNotified
	,NumberOfPeopleOfferedCreditMonitoring						= cee.NumberOfPeopleOfferedCreditMonitoring
	,OpenClaimsInBlock											= cee.OpenClaimsInBlock
	,OrderNumber												= ce.OrderNumber
	,OrigExGratiaRequest                                        = ce.OrigExGratiaRequest
	,OriginalInsured											= cee.OriginalInsured
	,OriginalPolicyLimit                                        = cee.OriginalPolicyLimit
	,OriginalPolicyLimitCurrency                                = cee.OriginalPolicyLimitCurrency                         
	,OriginalSigningDate										= cee.OriginalSigningDate
	,OriginalSigningNumber										= cee.OriginalSigningNumber
	,OriginatingBureau											= ce.OriginatingBureau
	,OtherReasonToFlag											= ce.OtherReasonToFlag
	,OwnershipIssues                                            = ctm.OwnershipIssues
	,OwnershipStatus                                            = ctm.OwnershipStatus
	,PatientCompensationFund                                    = cee.PatientCompensationFund
	,PeerReviewNoteIndicator									= ISNULL(cen.PeerReviewNoteIndicator, 0)
	,PointOfLoss                                                = cee.PointOfLoss
	,Pollutant                                                  = cee.Pollutant
	,PossibleInjuredPerson										= cee.PossibleInjuredPerson
	,PossibleInjuredPersonDateOfBirth							= cee.PossibleInjuredPersonDateOfBirth
	,PossibleInjuredPersonGender								= cee.PossibleInjuredPersonGender
	,PossibleInjuredPersonHasSSN								= ISNULL(cee.PossibleInjuredPersonHasSSN, 0)
	,PotentialLargeClaim										= ce.PotentialLargeClaim
	,PractitionerFacilityReportingRequired                      = cee.PractitionerFacilityReportingRequired
	,PrimaryContributaryCause									= NULL -- marked as removed  - cee.PrimaryContributaryCause
	,PrimaryDefenceAttorney										= cee.PrimaryDefenceAttorney
	,PrimaryDefenceLawFirm										= cee.PrimaryDefenceLawFirm
	,PrimaryDPRReviewer                                         = ctm.PrimaryDPRReviewer
	,PrimaryExaminer											= ce.PrimaryExaminer
	,PrimaryExaminerClaimCenterId								= cee.PrimaryExaminerClaimCenterId
	,PrimaryExaminerGroup                                       = ce.PrimaryExaminerGroup
	,PrimaryInsuredState										= NULL -- marked as removed  - cee.PrimaryInsuredState
	,PrimaryLegacyReference										= cee.PrimaryLegacyReference
	,OriginatingSourceSystem									= cee.OriginatingSourceSystem
	,PrimarySectionAgressoReference								= cee.PrimarySectionAgressoReference
	,PrimarySectionReference                                    = cee.PrimarySectionName
	,ProceedingsType											= NULL -- marked as moved maybe phase 2 - cee.ProceedingsType
	,Product													= ce.Product
	--,ProjectCategory											= CASE WHEN CHARINDEX(':', ce.CauseOfLoss) > 0 THEN LEFT(ce.CauseOfLoss, CHARINDEX(':',ce.CauseOfLoss) - 1) END --NULL--'update using CauseOfLoss (NAME from ClaimCenter_Staging.cctl_losscause)'---------cee.ProjectCategory
	,ProjectDeliveryMethod										= cee.ProjectDeliveryMethod   -- CC team send values for it, marked as KEEP
	,ProjectSubType												= cee.ProjectSubType
	,ProjectType												= cee.ProjectType
	--,ProjectType												= CASE WHEN CHARINDEX(':', ce.CauseOfLoss) > 0 THEN LTRIM(RIGHT(ce.CauseOfLoss, LEN(ce.CauseOfLoss) - CHARINDEX(':', ce.CauseOfLoss))) END--NULL--'update using CauseOfLoss (NAME from ClaimCenter_Staging.cctl_losscause)'---------cee.ProjectType
	,PropertyClaimsServicesCode									= cec.PropertyClaimsServicesCode
	,ProsecutionMethod                                          = cee.ProsecutionMethod
	,RIShareMultiplier											= NULL -- marked as removed  - cee.RISharePercentage----'mapped using ClaimCenter_Staging.cc_policy'---------cee.RIShareMultiplier
	,ReasonOfEscalation                                         = ce.ReasonOfEscalation
	,ReconciliationComments                                     = cee.ReconciliationComments
	,ReconciliationStatus                                       = cee.ReconciliationStatus
	,RecoverySubrogationNoteIndicator							= ISNULL(cen.RecoverySubrogationNoteIndicator, 0)
	,RegulatoryInvestigationOrAction                            = cee.RegulatoryInvestigationOrAction
	,TypeOfBuyer												= cee.TypeOfBuyer
	,PartyOfTheClaim											= cee.PartyOfTheClaim
	,MultipliedDamagesClaimed									= cee.MultipliedDamagesClaimed
	,SellerFraudClaimed											= cee.SellerFraudClaimed
	,FounderLedTarget											= cee.FounderLedTarget
	,ReleaseType                                                = cee.ReleaseType
	,ReportingTags												= cee.ReportingTags
	,RequestingBrokerage                                        = ce.RequestingBrokerage
	,RestructuredDebt                                           = cee.RestructuredDebt
	,Reviewed													= cee.Reviewed
	,RiskClass													= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. - ce.RiskClass
	,RiskClassCode												= ce.RiskClassCode
	,RiskDetails                                                = cee.RiskDetails
	,Role                                                       = ctm.Role
	,Roundtabled                                                = ce.RoundTabled 
	,RoundtabledDate                                            = ce.RoundTabledDate
	,RoundtabledNoteIndicator                                   = ISNULL(cen.RoundtabledNoteIndicator, 0)
	,SCMReference												= cee.SCMReference
	,SecondaryContributaryCause									= NULL -- marked as removed  - cee.SecondaryContributaryCause
	,SecondaryDPRReviewer                                       = ctm.SecondaryDPRReviewer
	,SecondaryExaminer											= cee.SecondaryExaminer
	,SecondaryInsuringClause                                    = cee.SecondaryInsuringClause
	,ReKeyReference												= cee.ReKeyReference 
	,ReKeySource												= cee.ReKeySource 
	,SecondarySectionReference                                  = ces.SectionReference
	,SendBBRQuestionnaire										= ISNULL(cee.SendBBRQuestionnaire, 0)
	,Severity													= cee.Severity
	,Signed														= ce.Signed
	,SIUIndicator												= ISNULL(cee.SIUIndicator, 0)
	,Source                                                     = cee.Source
	,StackingAggregateReference									= NULL -- marked as removed  - cee.StackingAggregateReference
	,StackingAggregateType										= NULL -- marked as removed  - cee.StackingAggregateType
	,Strategy													= cee.Strategy
	,SuretyDetails                                              = cee.SuretyDetails  
	,ThirdPartyClaimReference									= cee.ThirdPartyClaimReference
	,ThreatVector												= cee.ThreatVector
	,TimeBar                                                    = cee.TimeBar
	,TotalWorkloadWeightingIndicator							= NULL -- marked as removed  - cee.TotalWorkloadWeightingIndicator
	,TradingContractConditions                                  = cee.TradingContractConditions
	,TransportationLiability                                    = cee.TransportationLiability
	,TreatyContract                                             = cee.TreatyContract
	,TreatyInsuredEffectiveDate									= cee.TreatyInsuredEffectiveDate
	,TreatyInsuredExpiryDate									= cee.TreatyInsuredExpiryDate
	,TreatyInsuredName											= cee.TreatyInsuredName
	,TreatyInsuredPolicyNumber									= cee.TreatyInsuredPolicyNumber
	,TriagedMidClaim                                            = ce.TriagedMidClaim  
	,TriagedMidClaimType                                        = ce.TriagedMidClaimType
	,TriageNoteIndicator										= ISNULL(cen.TriageNoteIndicator, 0)
	,TrustFundCode												= cee.TrustFundCode
	,TrustFundCountryCode										= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. -cee.TrustFundCountryCode
	,TrustFundStateCode											= NULL -- Kept only to maintain logic in ODS to process SCM messages. From Claim Center we will pass a NULL value. -cee.TrustFundStateCode
	,TypeOfLoss													= cee.TypeOfLoss
	,USUnderwritingCoverageCode									= cee.USUnderwritingCoverageCode
	,UnderwritingCommitteeNoteIndicator							= ISNULL(cen.UnderwritingCommitteeNoteIndicator, 0)
	,UniqueClaimReference										= cee.UniqueClaimReference
	,VendorCausedIncident										= ISNULL(cee.VendorCausedIncident, 0)
	,VesselManufacturer                                         = cee.VesselManufacturer
	,VesselModel                                                = cee.VesselModel
	,VesselName													= cee.VesselName
	,VesselType                                                 = cee.VesselType
	,Voyage														= cee.Voyage
	,WageAndHourAllegation										= cee.WageAndHourAllegation
	,WaitingPeriod                                              = cee.WaitingPeriod
	,WarIndicator												= NULL -- marked as removed  - cee.WarIndicator
	,WorkOrigin                                                 = cee.WorkOrigin
	,WrittenIfNotSignedOrderMultiplier							= ISNULL(ce.WrittenIfNotSignedOrderMultiplier, 1) --1 -- marked as removed - 
	,FK_ClaimEstimateAsAtCloseDate								= 0
	,FK_ClaimMovementAsAtCloseDate								= 0
	,FK_ClaimTeamExaminer										=  CASE WHEN cee.claimteamexaminer IS NOT NULL THEN CONVERT(BIGINT,HASHBYTES('SHA2_256',(ClaimTeamExaminer))) ELSE 0 END--NULL--'udf_ComputeIdentity'---------cee.FK_ClaimTeamExaminer
	,FK_GQDTransactionType										= 0 -- marked as removed GQDTransactionType
	,FK_LastMovement											= 0 -- updated in post process
	,FK_LastMovementLocalCurrency								= 0 -- updated in post process
	,FK_LastMovementOriginalCurrency							= 0 -- updated in post process
	,FK_LastMovementSettlementCurrency							= 0 -- updated in post process
	,FK_PartyBroker												= CASE WHEN (ce.BrokerContactName IS NULL OR LEN(ce.BrokerContactName) < 3) THEN 0 ELSE DENSE_RANK() OVER (ORDER BY ce.BrokerContactName) END --ISNULL(pb.PK_PartyBroker, 0)
	,FK_PrimaryClassOfBusiness									= 0 -- updated in post process
	,FK_PrimaryTriFocus											= 0 -- updated in post process
	,FK_PrimaryUnderwriter										= 0 -- updated in post process
	,FK_QuantifiedStatus										= 0 -- marked as removed QuantifiedStatus
	,FK_SpecialCategoryCatastrophe								= ISNULL(spec.PK_SpecialCategoryCatastrophe, 0)
	,FK_YOA														= ISNULL(yoa.PK_YOA, 0)
	,HashbytesId												= ce.HashbytesId
	
	FROM BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposure ce
	INNER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureExtension cee ON
		ce.SourceSystem = cee.SourceSystem
		AND ce.ClaimExposureSourceId = cee.ClaimExposureSourceId
		--AND ce.IsActive = cee.IsActive
	INNER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_Claim co ON
		ce.SourceSystem = co.SourceSystem
		AND ce.ClaimSourceId = co.ClaimSourceId
		--AND ce.IsActive = co.IsActive
	LEFT JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureEstimate cees ON
	    ce.ClaimExposureSourceId = cees.ClaimExposureSourceId
		--AND ce.IsActive = cees.IsActive
		AND ce.SourceSystem = cees.SourceSystem  
	LEFT OUTER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExtension coe ON
		ce.SourceSystem = coe.SourceSystem
		AND ce.ClaimSourceId = coe.ClaimSourceId
		--AND ce.IsActive = coe.IsActive
		--AND ClaimCreatedBy = 'Migration User'
	LEFT OUTER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureCatastrophe cec ON
		cec.SourceSystem = ce.SourceSystem
		AND cec.CatastropheSourceId = ce.ClaimExposureNatCatastropheSourceId
		--AND cec.IsActive = ce.IsActive
	LEFT OUTER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureCatastrophe cecc ON
		cecc.SourceSystem = ce.SourceSystem
		AND cecc.CatastropheSourceId = ce.ClaimExposureClashCatastropheSourceId
		--AND cecc.IsActive = ce.IsActive
	LEFT OUTER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureNote cen ON
		ce.SourceSystem = cen.SourceSystem
		AND ce.ClaimSourceId = cen.ClaimSourceId
		AND ce.ClaimExposureSourceId = cen.ClaimExposureSourceId
		--AND ce.IsActive = cen.IsActive
    LEFT OUTER JOIN 
	BeazleyIntelligenceDataContract.Outbound.vw_ClaimExposureSection ces ON
	        ce.ClaimSourceId = ces.ClaimSourceId
		AND ce.ClaimExposureSourceId = ces.ClaimExposureSourceId
		AND ces.SectionSequenceId = 2
	INNER JOIN 
	ODS.Claim c ON
		c.ClaimReference = co.ClaimReference
	LEFT OUTER JOIN 
	ODS.YOA yoa ON
		ce.YearOfAccount = yoa.PK_YOA
	LEFT OUTER JOIN
	Staging_MDS.dbo.vw_special_claim_ref sc ON
		cec.BeazleyCatCode = Utility.udf_ProcessString(sc.ClaimRefGroupCode, 1) AND sc.[Include] = 'Y'
	LEFT OUTER JOIN
	ODS.SpecialCategoryCatastrophe spec ON
		Utility.udf_ProcessString(sc.[Description], 1) = spec.SpecialCategory
	--LEFT OUTER JOIN
	--ODS.PartyBroker pb ON
		--coe.BrokerNumber = pb.BrokerNumber
	LEFT OUTER JOIN 
	Staging_MDS.dbo.vw_claim_group_codes b_cat ON
		b_cat.ClaimGroupCode = cec.BeazleyCatCode
	LEFT OUTER JOIN 
	Staging_MDS.dbo.vw_claim_group_codes m_cat ON
		m_cat.ClaimGroupCode = ISNULL(cec.MarketCatCode, Utility.udf_ProcessString(b_cat.MarketCatCode,1))
	--LEFT OUTER JOIN
	--Staging_MDS.MDS_Staging.ISOLossType iso ON
		--iso.PrimaryCauseOfLoss = ce.CauseOfLoss AND ISNULL(iso.SecondaryCauseOfLoss, '') = ISNULL(ce.CauseOfLossSecondary, '') AND iso.Discrimination  = ISNULL(ce.Discrimination, 'N/A')
	LEFT OUTER JOIN
	Staging_MDS.MDS_Staging.ClaimsTeamMapping ctm ON
		ce.PrimaryExaminer = ctm.ClaimsExaminer
	LEFT JOIN ODS.AccountingCalendar ac 
		ON ac.PK_AccountingCalendar=c.FK_AccountingCalendar
	WHERE ce.SourceSystem = 'ClaimCenter'
	AND ISNULL(co.IsRetired, 0) = 0

		----delta development
		AND (	
				(ce.AuditCreateDatetime > @LastAuditDate OR ce.AuditModifyDatetime > @LastAuditDate)
				OR (cee.AuditCreateDatetime > @LastAuditDate OR cee.AuditModifyDatetime > @LastAuditDate)
				OR (co.AuditCreateDatetime > @LastAuditDate OR co.AuditModifyDatetime > @LastAuditDate)
				OR (cees.AuditCreateDatetime > @LastAuditDate OR cees.AuditModifyDatetime > @LastAuditDate)
				OR (coe.AuditCreateDatetime > @LastAuditDate OR coe.AuditModifyDatetime > @LastAuditDate)
				OR (cec.AuditCreateDatetime > @LastAuditDate OR cec.AuditModifyDatetime > @LastAuditDate)
				OR (cecc.AuditCreateDatetime > @LastAuditDate OR cecc.AuditModifyDatetime > @LastAuditDate)
				OR (cen.AuditCreateDatetime > @LastAuditDate OR cen.AuditModifyDatetime > @LastAuditDate)
				OR (ctm.EnterDateTime > @LastAuditDate OR ctm.LastChgDateTime > @LastAuditDate)  
			)
) source
ON  target.ExposureReference = source.ExposureReference
AND target.OriginatingBureau  = source.OriginatingBureau

WHEN MATCHED THEN
UPDATE SET
 target.FK_Claim                                           = source.FK_Claim       
,target.AllegationOfDiscrimination                         = source.AllegationOfDiscrimination
,target.AnyNonMovingNoteIndicator                          = source.AnyNonMovingNoteIndicator
,target.AreaOfPractice                                     = source.AreaOfPractice
,target.AreaOfPracticeCode                                 = source.AreaOfPracticeCode 
,target.AmountOfOriginalLossFund                           = source.AmountOfOriginalLossFund
,target.BatteryBrand                                       = source.BatteryBrand
,target.BBRServicesManager                                 = source.BBRServicesManager 
,target.BBRServicesNoteIndicator                           = source.BBRServicesNoteIndicator 
,target.BadFaithIndicator                                  = source.BadFaithIndicator
,target.BadFaithNoteIndicator                              = source.BadFaithNoteIndicator
,target.BeazleyCat                                         = source.BeazleyCat
,target.BeazleyCatCode                                     = source.BeazleyCatCode
,target.BeazleyCatDateOfLoss                               = source.BeazleyCatDateOfLoss 
,target.BeazleyCatDateOfLossTo                             = source.BeazleyCatDateOfLossTo 
,target.BeazleyCatLongDescription                          = source.BeazleyCatLongDescription
,target.BinderReference                                    = source.BinderReference
,target.BinderYOA										   = source.BinderYOA
,target.BlendWeightingMultiplier                           = source.BlendWeightingMultiplier 
,target.BlockIndicator                                     = source.BlockIndicator
,target.BodilyDeathEmotionalIndicator                      = source.BodilyDeathEmotionalIndicator
,target.BondLimit                                          = source.BondLimit
,target.BondLimitCurrency                                  = source.BondLimitCurrency
,target.BooksAndRecordDemand                               = source.BooksAndRecordDemand
,target.BreachStatus                                       = source.BreachStatus
,target.BreachedInformationType                            = source.BreachedInformationType
,target.BrokerContactName                                  = source.BrokerContactName
,target.BrokerReference1                                   = source.BrokerReference1 
,target.BrokerReference2                                   = source.BrokerReference2 
,target.CallCentreAndCreditMonitoringExpiryDate            = source.CallCentreAndCreditMonitoringExpiryDate 
,target.CargoCommodity                                     = source.CargoCommodity
,target.CargoConveyance                                    = source.CargoConveyance
,target.CatCodeEndsInLF                                    = source.CatCodeEndsInLF
,target.Category                                           = source.Category
,target.CauseOfAction                                      = source.CauseOfAction
,target.CauseOfLoss                                        = source.CauseOfLoss 
,target.CauseOfLossCode                                    = source.CauseOfLossCode
,target.CauseOfLossSecondary                               = source.CauseOfLossSecondary
,target.CauseOfLossSecondaryCode                           = source.CauseOfLossSecondaryCode
,target.CashAdvanceMade                                    = source.CashAdvanceMade
,target.ClaimOrCircumstance                                = source.ClaimOrCircumstance
,target.ClaimsDepartment                                   = source.ClaimsDepartment
,target.ClaimsTeam                                         = source.ClaimsTeam
,target.ClaimsSubTeam									   = source.ClaimsSubTeam
,target.ClaimTeamExaminer                                  = source.ClaimTeamExaminer
,target.ClaimantClientStatus                               = source.ClaimantClientStatus
,target.ClaimantGender                                     = source.ClaimantGender
,target.ClaimantJobCategory                                = source.ClaimantJobCategory
,target.ClaimantJobStatus                                  = source.ClaimantJobStatus
,target.ClaimantName                                       = source.ClaimantName
,target.ClaimantSalary                                     = source.ClaimantSalary
,target.ClaimantSalaryName                                 = source.ClaimantSalaryName
,target.ClaimantType                                       = source.ClaimantType
,target.ClashCatCode                                       = source.ClashCatCode
,target.ClashCatDateOfLoss                                 = source.ClashCatDateOfLoss 
,target.ClashCatDescription                                = source.ClashCatDescription
,target.ClashCatName                                       = source.ClashCatName
,target.ClientBreakdown                                    = source.ClientBreakdown
,target.ClosedClaimsInBlock                                = source.ClosedClaimsInBlock
,target.ComplexFlag                                        = source.ComplexFlag 
,target.Consultation									   = source.Consultation
,target.ConsultationNoteIndicator                          = source.ConsultationNoteIndicator
,target.ConsultationUser                                   = source.ConsultationUser
,target.CoverageAgreedDate                                 = source.CoverageAgreedDate 
,target.CoverageDenialIndicator                            = source.CoverageDenialIndicator
,target.CoverageIssues                                     = source.CoverageIssues
,target.CoverageTrigger                                    = source.CoverageTrigger
,target.DateCoverageLetterIssued                           = source.DateCoverageLetterIssued
,target.DateOfDenial                                       = source.DateOfDenial
,target.DenialReason                                       = source.DenialReason
,target.DamageTheory                                       = source.DamageTheory
,target.DateClaimPaid                                      = source.DateClaimPaid
,target.DateOfAct                                          = source.DateOfAct
,target.DateSinceInitialEstimate                           = source.DateSinceInitialEstimate
,target.DateSinceNotReviewed                               = source.DateSinceNotReviewed
,target.DateSinceQuantified                                = source.DateSinceQuantified 
,target.DefendantOrPlaintiff                               = source.DefendantOrPlaintiff
,target.DelegatedPartner                                   = source.DelegatedPartner
,target.DerivativeDemand                                   = source.DerivativeDemand
,target.DerivativeSuit                                     = source.DerivativeSuit
,target.DeviceEncrypted                                    = source.DeviceEncrypted
,target.DiscoveryDate                                      = source.DiscoveryDate
,target.DiscoveryDetails                                   = source.DiscoveryDetails
,target.DispositionOfMatter                                = source.DispositionOfMatter
,target.DutyToDefend                                       = source.DutyToDefend
,target.ECFIndicator                                       = source.ECFIndicator
,target.ECFEntryWithoutSCM                                 = source.ECFEntryWithoutSCM
,target.EndOfWaitingPeriod                                 = source.EndOfWaitingPeriod
,target.EscalatedClaim                                     = source.EscalatedClaim
,target.EvaluationNoteIndicator                            = source.EvaluationNoteIndicator
,target.EventSetting                                       = source.EventSetting
,target.ExGratiaRequested                                  = source.ExGratiaRequested
,target.ExposureClosedDate                                 = source.ExposureClosedDate 
,target.ExposureDescription                                = source.ExposureDescription
,target.ExposureHasMovements                               = source.ExposureHasMovements
,target.ExposureOpenedDate                                 = source.ExposureOpenedDate 
,target.ExposureReference                                  = source.ExposureReference
,target.ExposureReopenedDate                               = source.ExposureReopenedDate 
,target.ExposureReopenedReason                             = source.ExposureReopenedReason 
,target.ExposureSequenceId                                 = source.ExposureSequenceId 
,target.ExposureStatus                                     = source.ExposureStatus
,target.ExposureStatusCode                                 = source.ExposureStatusCode
,target.ExposureUpdatedDate                                = source.ExposureUpdatedDate
,target.ExternalAdjuster                                   = source.ExternalAdjuster 
,target.Fil1Code                                           = source.Fil1Code
,target.FileNoteIndicator                                  = source.FileNoteIndicator
,target.FinalExGratiaDecision                              = source.FinalExGratiaDecision
,target.FirstPartyCyberLossTypes                           = source.FirstPartyCyberLossTypes
,target.ThirdPartyCyberLossTypes						   = source.ThirdPartyCyberLossTypes
,target.CyberGroupingExtortion							   = source.CyberGroupingExtortion	
,target.RansomwarePayment								   = source.RansomwarePayment
,target.TotalAmountOfRansomwarePayment                     = source.TotalAmountOfRansomwarePayment
,target.RansomwarePaymentCurrency                          = source.RansomwarePaymentCurrency
,target.ReportedToCompliance                               = source.ReportedToCompliance
,target.ClassActionCountry                                 = source.ClassActionCountry
,target.State                                              = source.State
,target.RegulatoryInquiry                                  = source.RegulatoryInquiry
,target.TotalAmountOfFine                                  = source.TotalAmountOfFine
,target.FineCurrency                                       = source.FineCurrency
,target.AmountOfBusinessInterruptionSubmission             = source.AmountOfBusinessInterruptionSubmission
,target.BusinessInterruptionSubmissionCurrency             = source.BusinessInterruptionSubmissionCurrency
,target.AmountOfBusinessInterruptionLossRecognized         = source.AmountOfBusinessInterruptionLossRecognized
,target.BusinessInterruptionLossRecognizedCurrency         = source.BusinessInterruptionLossRecognizedCurrency
,target.AmountOfDataRecoverySubmission                     = source.AmountOfDataRecoverySubmission
,target.DataRecoverySubmissionCurrency                     = source.DataRecoverySubmissionCurrency
,target.AmountOfDataRecoveryLossRecognized                 = source.AmountOfDataRecoveryLossRecognized
,target.DataRecoveryLossRecognizedCurrency                 = source.DataRecoveryLossRecognizedCurrency
,target.FlaggedNoteIndicator                               = source.FlaggedNoteIndicator 
,target.FlaggedNoteOrReasonIndicator                       = source.FlaggedNoteOrReasonIndicator 
,target.FlaggedReason                                      = source.FlaggedReason 
,target.FlaggedReasonIndicator                             = source.FlaggedReasonIndicator
,target.GrossLoss                                          = source.GrossLoss
,target.GrossLossAsAtDate                                  = source.GrossLossAsAtDate
,target.GrossLossCurrency                                  = source.GrossLossCurrency
,target.ISOLossType                                        = source.ISOLossType 
,target.ISOLossTypeCode                                    = source.ISOLossTypeCode
,target.IMO                                                = source.IMO
,target.IncidentAction                                     = source.IncidentAction
,target.IndustryAreaOfPracticeSecondaryCode                = source.IndustryAreaOfPracticeSecondaryCode
,target.IndustryAreaOfPracticeSecondaryName                = source.IndustryAreaOfPracticeSecondaryName
,target.InjuryType                                         = source.InjuryType
,target.InsuredName                                        = source.InsuredName 
,target.InsuredSCMName                                     = source.InsuredSCMName
,target.InsurersRepresentative                             = source.InsurersRepresentative 
,target.InsuringClause                                     = source.InsuringClause
,target.IsMultiSection                                     = source.IsMultiSection
,target.IsNewYorkFreeTradeZone                             = source.IsNewYorkFreeTradeZone 
,target.IsRealExposure                                     = source.IsRealExposure
,target.LastBureauShare                                    = source.LastBureauShare
,target.LastMovementNarrative                              = source.LastMovementNarrative
,target.LastMovementTBAFlag                                = source.LastMovementTBAFlag
,target.LastMovementTBAIndicator                           = source.LastMovementTBAIndicator 
,target.LatestBadFaithNote                                 = source.LatestBadFaithNote
,target.LatestBadFaithNoteUpdatedDate					   = source.LatestBadFaithNoteUpdatedDate
,target.LatestBBRServicesNote                              = source.LatestBBRServicesNote
,target.LatestBBRServicesNoteUpdatedDate                   = source.LatestBBRServicesNoteUpdatedDate 
,target.LatestCMSNote                                      = source.LatestCMSNote 
,target.LatestCMSNoteUpdatedDate                           = source.LatestCMSNoteUpdatedDate 
,target.LatestConsultationNote                             = source.LatestConsultationNote 
,target.LatestConsultationNoteUpdatedDate                  = source.LatestConsultationNoteUpdatedDate
,target.LatestEvaluationNote                               = source.LatestEvaluationNote 
,target.LatestEvaluationNoteUpdatedDate                    = source.LatestEvaluationNoteUpdatedDate
,target.LatestFileNote                                     = source.LatestFileNote
,target.LatestFileNoteUpdatedDate                          = source.LatestFileNoteUpdatedDate
,target.LatestFlaggedNote                                  = source.LatestFlaggedNote
,target.LatestFlaggedNoteUpdatedDate                       = source.LatestFlaggedNoteUpdatedDate 
,target.LatestLitigationNote						       = source.LatestLitigationNote
,target.LatestLitigationNoteUpdatedDate					   = source.LatestLitigationNoteUpdatedDate
,target.LatestLossFundFileNote                             = source.LatestLossFundFileNote
,target.LatestLossFundFileNoteUpdatedDate                  = source.LatestLossFundFileNoteUpdatedDate
,target.LatestMergedClaimNote                              = source.LatestMergedClaimNote
,target.LatestMergedClaimNoteUpdatedDate                   = source.LatestMergedClaimNoteUpdatedDate
,target.LatestNonMovingNoteBroker                          = source.LatestNonMovingNoteBroker
,target.LatestNonMovingNoteBrokerUpdatedDate               = source.LatestNonMovingNoteBrokerUpdatedDate 
,target.LatestNonMovingNoteInsured                         = source.LatestNonMovingNoteInsured 
,target.LatestNonMovingNoteInsuredUpdatedDate              = source.LatestNonMovingNoteInsuredUpdatedDate
,target.LatestNonMovingNoteOther                           = source.LatestNonMovingNoteOther 
,target.LatestNonMovingNoteOtherUpdatedDate                = source.LatestNonMovingNoteOtherUpdatedDate
,target.LatestNonMovingNoteXCS                             = source.LatestNonMovingNoteXCS 
,target.LatestNonMovingNoteXCSUpdatedDate                  = source.LatestNonMovingNoteXCSUpdatedDate
,target.LatestPeerReviewNote                               = source.LatestPeerReviewNote 
,target.LatestPeerReviewNoteUpdatedDate                    = source.LatestPeerReviewNoteUpdatedDate
,target.LatestRecoverySubrogationNote                      = source.LatestRecoverySubrogationNote
,target.LatestRecoverySubrogationNoteUpdatedDate           = source.LatestRecoverySubrogationNoteUpdatedDate
,target.LatestRoundtabledNote                              = source.LatestRoundtabledNote
,target.LatestRoundtabledNoteUpdatedDate                   = source.LatestRoundtabledNoteUpdatedDate
,target.LatestTriageNote                                   = source.LatestTriageNote 
,target.LatestTriageNoteUpdatedDate                        = source.LatestTriageNoteUpdatedDate
,target.LatestUnderwritingCommitteeNote                    = source.LatestUnderwritingCommitteeNote
,target.LatestUnderwritingCommitteeNoteUpdatedDate         = source.LatestUnderwritingCommitteeNoteUpdatedDate 
,target.LawAndJurisdiction                                 = source.LawAndJurisdiction 
,target.LevelOfDelegatedAuthority                          = source.LevelOfDelegatedAuthority
,target.LevelOfDelegatedAuthorityCurrency                  = source.LevelOfDelegatedAuthorityCurrency
,target.LineOfBusiness                                     = source.LineOfBusiness
,target.LinkedSCMReference                                 = source.LinkedSCMReference 
,target.LinkedSynergySection                               = source.LinkedSynergySection
,target.LitigationCounsel                                  = source.LitigationCounsel   
,target.LitigationNoteIndicator 						   = source.LitigationNoteIndicator
,target.LitigationStateCode                                = source.LitigationStateCode
,target.LitigationStatus                                   = source.LitigationStatus 
,target.LossDetails                                        = source.LossDetails
,target.LossFundCurrency                                   = source.LossFundCurrency
,target.LossFundFileNoteIndicator                          = source.LossFundFileNoteIndicator
,target.LossFundHolderReceivedFund                         = source.LossFundHolderReceivedFund
,target.LossLocationAddressLine1                           = source.LossLocationAddressLine1 
,target.LossLocationAddressLine2                           = source.LossLocationAddressLine2 
,target.LossLocationCity                                   = source.LossLocationCity 
,target.LossLocationCountry                                = source.LossLocationCountry
,target.LossLocationCounty                                 = source.LossLocationCounty 
,target.LossLocationDescription                            = source.LossLocationDescription
,target.LossLocationPostalCode                             = source.LossLocationPostalCode
,target.LossLocationState                                  = source.LossLocationState
,target.LossLocationStateCode                              = source.LossLocationStateCode
,target.LossType                                           = source.LossType
,target.MainGroupsOfClaimants                              = source.MainGroupsOfClaimants
,target.MarketCat                                          = source.MarketCat 
,target.MarketCatCode                                      = source.MarketCatCode 
,target.MarketCatDateOfLoss                                = source.MarketCatDateOfLoss
,target.MarketCatLongDescription                           = source.MarketCatLongDescription 
,target.MarketCatQualifier                                 = source.MarketCatQualifier 
,target.MatterName                                         = source.MatterName
,target.Media                                              = source.Media
,target.MedicareIndicator                                  = source.MedicareIndicator
,target.MedipayIndicator                                   = source.MedipayIndicator 
,target.MergedClaimNoteIndicator                           = source.MergedClaimNoteIndicator
,target.NAIC                                               = source.NAIC
,target.NAICCode                                           = source.NAICCode
,target.NetLoss                                            = source.NetLoss
,target.NetLossAsAtDate                                    = source.NetLossAsAtDate
,target.NetLossCurrency                                    = source.NetLossCurrency
,target.NIARecordTypeCode                                  = source.NIARecordTypeCode
,target.NonMovingNoteBrokerIndicator                       = source.NonMovingNoteBrokerIndicator 
,target.NonMovingNoteInsuredIndicator                      = source.NonMovingNoteInsuredIndicator
,target.NonMovingNoteOtherIndicator                        = source.NonMovingNoteOtherIndicator
,target.NonMovingNoteXCSIndicator                          = source.NonMovingNoteXCSIndicator
,target.NumberOfCallCentreCalls                            = source.NumberOfCallCentreCalls
,target.NumberOfClaimants                                  = source.NumberOfClaimants
,target.NumberOfCodesActivated                             = source.NumberOfCodesActivated 
,target.NumberOfPeopleNotified                             = source.NumberOfPeopleNotified 
,target.NumberOfPeopleOfferedCreditMonitoring              = source.NumberOfPeopleOfferedCreditMonitoring
,target.OpenClaimsInBlock                                  = source.OpenClaimsInBlock
,target.OrderNumber                                        = source.OrderNumber
,target.OrigExGratiaRequest                                = source.OrigExGratiaRequest
,target.OriginalInsured                                    = source.OriginalInsured
,target.OriginalPolicyLimit                                = source.OriginalPolicyLimit
,target.OriginalPolicyLimitCurrency                        = source.OriginalPolicyLimitCurrency
,target.OriginalSigningDate                                = source.OriginalSigningDate
,target.OriginalSigningNumber                              = source.OriginalSigningNumber
,target.OriginatingBureau                                  = source.OriginatingBureau
,target.OtherReasonToFlag                                  = source.OtherReasonToFlag
,target.OwnershipIssues                                    = source.OwnershipIssues
,target.OwnershipStatus                                    = source.OwnershipStatus
,target.PatientCompensationFund                            = source.PatientCompensationFund
,target.PeerReviewNoteIndicator                            = source.PeerReviewNoteIndicator
,target.PointOfLoss                                        = source.PointOfLoss
,target.Pollutant                                          = source.Pollutant
,target.PossibleInjuredPerson                              = source.PossibleInjuredPerson
,target.PossibleInjuredPersonDateOfBirth                   = source.PossibleInjuredPersonDateOfBirth 
,target.PossibleInjuredPersonGender                        = source.PossibleInjuredPersonGender
,target.PossibleInjuredPersonHasSSN                        = source.PossibleInjuredPersonHasSSN
,target.PotentialLargeClaim                                = source.PotentialLargeClaim
,target.PractitionerFacilityReportingRequired              = source.PractitionerFacilityReportingRequired
,target.PrimaryContributaryCause                           = source.PrimaryContributaryCause 
,target.PrimaryDefenceAttorney                             = source.PrimaryDefenceAttorney 
,target.PrimaryDefenceLawFirm                              = source.PrimaryDefenceLawFirm  
,target.PrimaryDPRReviewer                                 = source.PrimaryDPRReviewer
,target.PrimaryExaminer                                    = source.PrimaryExaminer
,target.PrimaryExaminerClaimCenterId                       = source.PrimaryExaminerClaimCenterId 
,target.PrimaryExaminerGroup                               = source.PrimaryExaminerGroup
,target.PrimaryInsuredState                                = source.PrimaryInsuredState
,target.PrimaryLegacyReference							   = source.PrimaryLegacyReference      
,target.OriginatingSourceSystem							   = source.OriginatingSourceSystem
,target.PrimarySectionAgressoReference                     = source.PrimarySectionAgressoReference 
,target.PrimarySectionReference                            = source.PrimarySectionReference  
,target.ProceedingsType                                    = source.ProceedingsType
,target.Product                                            = source.Product        
,target.ProjectDeliveryMethod                              = source.ProjectDeliveryMethod
,target.ProjectSubType                                     = source.ProjectSubType
,target.ProjectType                                        = source.ProjectType 
,target.PropertyClaimsServicesCode                         = source.PropertyClaimsServicesCode 
,target.ProsecutionMethod                                  = source.ProsecutionMethod
,target.RIShareMultiplier                                  = source.RIShareMultiplier 
,target.ReasonOfEscalation                                 = source.ReasonOfEscalation
,target.ReconciliationComments                             = source.ReconciliationComments
,target.ReconciliationStatus                               = source.ReconciliationStatus
,target.RecoverySubrogationNoteIndicator                   = source.RecoverySubrogationNoteIndicator
,target.RegulatoryInvestigationOrAction                    = source.RegulatoryInvestigationOrAction
,target.TypeOfBuyer										   = source.TypeOfBuyer
,target.PartyOfTheClaim									   = source.PartyOfTheClaim
,target.MultipliedDamagesClaimed						   = source.MultipliedDamagesClaimed
,target.SellerFraudClaimed								   = source.SellerFraudClaimed
,target.FounderLedTarget								   = source.FounderLedTarget
,target.ReleaseType                                        = source.ReleaseType
,target.ReportingTags                                      = source.ReportingTags
,target.RequestingBrokerage                                = source.RequestingBrokerage
,target.RestructuredDebt                                   = source.RestructuredDebt
,target.Reviewed                                           = source.Reviewed
,target.RiskClass                                          = source.RiskClass 
,target.RiskClassCode                                      = source.RiskClassCode 
,target.RiskDetails                                        = source.RiskDetails
,target.Role                                               = source.Role
,target.Roundtabled                                        = source.Roundtabled
,target.RoundtabledDate                                    = source.RoundtabledDate 
,target.RoundtabledNoteIndicator                           = source.RoundtabledNoteIndicator
,target.SCMReference                                       = source.SCMReference
,target.SecondaryContributaryCause                         = source.SecondaryContributaryCause 
,target.SecondaryDPRReviewer                               = source.SecondaryDPRReviewer
,target.SecondaryExaminer                                  = source.SecondaryExaminer
,target.SecondaryInsuringClause                            = source.SecondaryInsuringClause
,target.ReKeyReference 									   = source.ReKeyReference 
,target.ReKeySource										   = source.ReKeySource
,target.SecondarySectionReference                          = source.SecondarySectionReference
,target.SendBBRQuestionnaire                               = source.SendBBRQuestionnaire 
,target.Severity                                           = source.Severity
,target.Signed                                             = source.Signed
,target.SIUIndicator                                       = source.SIUIndicator
,target.Source                                             = source.Source
,target.StackingAggregateReference                         = source.StackingAggregateReference 
,target.StackingAggregateType                              = source.StackingAggregateType
,target.Strategy                                           = source.Strategy
,target.SuretyDetails                                      = source.SuretyDetails
,target.ThirdPartyClaimReference                           = source.ThirdPartyClaimReference 
,target.ThreatVector                                       = source.ThreatVector
,target.TimeBar                                            = source.TimeBar
,target.TotalWorkloadWeightingIndicator                    = source.TotalWorkloadWeightingIndicator
,target.TradingContractConditions                          = source.TradingContractConditions
,target.TransportationLiability                            = source.TransportationLiability
,target.TreatyContract                                     = source.TreatyContract
,target.TreatyInsuredEffectiveDate                         = source.TreatyInsuredEffectiveDate 
,target.TreatyInsuredExpiryDate                            = source.TreatyInsuredExpiryDate
,target.TreatyInsuredName                                  = source.TreatyInsuredName
,target.TreatyInsuredPolicyNumber                          = source.TreatyInsuredPolicyNumber
,target.TriagedMidClaim                                    = source.TriagedMidClaim 
,target.TriagedMidClaimType                                = source.TriagedMidClaimType 
,target.TriageNoteIndicator                                = source.TriageNoteIndicator
,target.TrustFundCode                                      = source.TrustFundCode 
,target.TrustFundCountryCode                               = source.TrustFundCountryCode 
,target.TrustFundStateCode                                 = source.TrustFundStateCode 
,target.TypeOfLoss                                         = source.TypeOfLoss
,target.USUnderwritingCoverageCode                         = source.USUnderwritingCoverageCode 
,target.UnderwritingCommitteeNoteIndicator                 = source.UnderwritingCommitteeNoteIndicator 
,target.UniqueClaimReference                               = source.UniqueClaimReference 
,target.VendorCausedIncident                               = source.VendorCausedIncident 
,target.VesselManufacturer                                 = source.VesselManufacturer
,target.VesselModel                                        = source.VesselModel
,target.VesselName                                         = source.VesselName
,target.VesselType                                         = source.VesselType
,target.Voyage                                             = source.Voyage
,target.WageAndHourAllegation                              = source.WageAndHourAllegation
,target.WaitingPeriod                                      = source.WaitingPeriod
,target.WarIndicator                                       = source.WarIndicator
,target.WorkOrigin                                         = source.WorkOrigin
,target.WrittenIfNotSignedOrderMultiplier                  = source.WrittenIfNotSignedOrderMultiplier
,target.FK_ClaimEstimateAsAtCloseDate                      = source.FK_ClaimEstimateAsAtCloseDate
,target.FK_ClaimMovementAsAtCloseDate                      = source.FK_ClaimMovementAsAtCloseDate 
,target.FK_ClaimTeamExaminer                               = source.FK_ClaimTeamExaminer 
,target.FK_GQDTransactionType                              = source.FK_GQDTransactionType 
,target.FK_LastMovement                                    = source.FK_LastMovement 
,target.FK_LastMovementLocalCurrency                       = source.FK_LastMovementLocalCurrency
,target.FK_LastMovementOriginalCurrency                    = source.FK_LastMovementOriginalCurrency 
,target.FK_LastMovementSettlementCurrency                  = source.FK_LastMovementSettlementCurrency 
,target.FK_PartyBroker                                     = source.FK_PartyBroker
,target.FK_PrimaryClassOfBusiness                          = source.FK_PrimaryClassOfBusiness 
,target.FK_PrimaryTriFocus                                 = source.FK_PrimaryTriFocus
,target.FK_PrimaryUnderwriter                              = source.FK_PrimaryUnderwriter 
,target.FK_QuantifiedStatus                                = source.FK_QuantifiedStatus 
,target.FK_SpecialCategoryCatastrophe                      = source.FK_SpecialCategoryCatastrophe 
,target.FK_YOA                                             = source.FK_YOA 
,target.HashbytesId                                        = source.HashbytesId         
,target.AuditModifyDateTime								   = GETDATE()						
,target.AuditModifyDetails								   = 'Merge in ODS.usp_LoadClaimExposure proc' 


WHEN NOT MATCHED BY TARGET THEN
INSERT
(    
	 FK_Claim
	,AllegationOfDiscrimination
	,AnyNonMovingNoteIndicator
	,AreaOfPractice
	,AreaOfPracticeCode 
	,AmountOfOriginalLossFund
	,BatteryBrand
	,BBRServicesManager 
	,BBRServicesNoteIndicator 
	,BadFaithIndicator
	,BadFaithNoteIndicator
	,BeazleyCat
	,BeazleyCatCode
	,BeazleyCatDateOfLoss 
	,BeazleyCatDateOfLossTo 
	,BeazleyCatLongDescription
	,BinderReference
	,BinderYOA
	,BlendWeightingMultiplier 
	,BlockIndicator
	,BodilyDeathEmotionalIndicator
	,BondLimit
	,BondLimitCurrency
	,BooksAndRecordDemand
	,BreachStatus
	,BreachedInformationType
	,BrokerContactName
	,BrokerReference1 
	,BrokerReference2 
	,CallCentreAndCreditMonitoringExpiryDate 
	,CargoCommodity
	,CargoConveyance
	,CatCodeEndsInLF
	,Category
	,CauseOfAction
	,CauseOfLoss 
	,CauseOfLossCode
	,CauseOfLossSecondary
	,CauseOfLossSecondaryCode
	,CashAdvanceMade
	,ClaimOrCircumstance
	,ClaimsDepartment
	,ClaimsTeam
	,ClaimsSubTeam
	,ClaimTeamExaminer
	,ClaimantClientStatus
	,ClaimantGender
	,ClaimantJobCategory
	,ClaimantJobStatus
	,ClaimantName
	,ClaimantSalary
	,ClaimantSalaryName
	,ClaimantType
	,ClashCatCode
	,ClashCatDateOfLoss 
	,ClashCatDescription
	,ClashCatName
	,ClientBreakdown
	,ClosedClaimsInBlock
	,ComplexFlag 
    ,Consultation
	,ConsultationNoteIndicator
	,ConsultationUser
	,CoverageAgreedDate 
	,CoverageDenialIndicator
	,CoverageIssues
	,CoverageTrigger
	,DateCoverageLetterIssued
	,DateOfDenial
	,DenialReason
	,DamageTheory
	,DateClaimPaid
	,DateOfAct
	,DateSinceInitialEstimate
	,DateSinceNotReviewed
	,DateSinceQuantified 
	,DefendantOrPlaintiff
	,DelegatedPartner
	,DerivativeDemand
	,DerivativeSuit
	,DeviceEncrypted
	,DiscoveryDate
	,DiscoveryDetails
	,DispositionOfMatter
	,DutyToDefend
	,ECFIndicator
	,ECFEntryWithoutSCM
	,EndOfWaitingPeriod
	,EscalatedClaim
	,EvaluationNoteIndicator
	,EventSetting
	,ExGratiaRequested
	,ExposureClosedDate 
	,ExposureDescription
	,ExposureHasMovements
	,ExposureOpenedDate 
	,ExposureReference
	,ExposureReopenedDate 
	,ExposureReopenedReason 
	,ExposureSequenceId 
	,ExposureStatus
	,ExposureStatusCode
	,ExposureUpdatedDate
	,ExternalAdjuster 
	,Fil1Code
	,FileNoteIndicator
	,FinalExGratiaDecision
	,FirstPartyCyberLossTypes
	,ThirdPartyCyberLossTypes
	,CyberGroupingExtortion									   	
    ,RansomwarePayment										   
    ,TotalAmountOfRansomwarePayment                             
    ,RansomwarePaymentCurrency                                  
    ,ReportedToCompliance                                       
    ,ClassActionCountry                                        
    ,State                                                      
    ,RegulatoryInquiry                                         
    ,TotalAmountOfFine                                          
    ,FineCurrency                                               
    ,AmountOfBusinessInterruptionSubmission                    
    ,BusinessInterruptionSubmissionCurrency                     
    ,AmountOfBusinessInterruptionLossRecognized                 
    ,BusinessInterruptionLossRecognizedCurrency                 
    ,AmountOfDataRecoverySubmission                             
    ,DataRecoverySubmissionCurrency                             
    ,AmountOfDataRecoveryLossRecognized                         
    ,DataRecoveryLossRecognizedCurrency                         
	,FlaggedNoteIndicator 
	,FlaggedNoteOrReasonIndicator 
	,FlaggedReason 
	,FlaggedReasonIndicator
	,GrossLoss
	,GrossLossAsAtDate
	,GrossLossCurrency
	,ISOLossType 
	,ISOLossTypeCode
	,IMO
	,IncidentAction
	,IndustryAreaOfPracticeSecondaryCode
	,IndustryAreaOfPracticeSecondaryName
	,InjuryType
	,InsuredName 
	,InsuredSCMName
	,InsurersRepresentative 
	,InsuringClause
	,IsMultiSection
	,IsNewYorkFreeTradeZone 
	,IsRealExposure
	,LastBureauShare
	,LastMovementNarrative
	,LastMovementTBAFlag
	,LastMovementTBAIndicator 
	,LatestBadFaithNote
    ,LatestBadFaithNoteUpdatedDate
	,LatestBBRServicesNote
	,LatestBBRServicesNoteUpdatedDate 
	,LatestCMSNote 
	,LatestCMSNoteUpdatedDate 
	,LatestConsultationNote 
	,LatestConsultationNoteUpdatedDate
	,LatestEvaluationNote 
	,LatestEvaluationNoteUpdatedDate
	,LatestFileNote
	,LatestFileNoteUpdatedDate
	,LatestFlaggedNote
	,LatestFlaggedNoteUpdatedDate 
	,LatestLitigationNote	
	,LatestLitigationNoteUpdatedDate
	,LatestLossFundFileNote
	,LatestLossFundFileNoteUpdatedDate
	,LatestMergedClaimNote
	,LatestMergedClaimNoteUpdatedDate
	,LatestNonMovingNoteBroker
	,LatestNonMovingNoteBrokerUpdatedDate 
	,LatestNonMovingNoteInsured 
	,LatestNonMovingNoteInsuredUpdatedDate
	,LatestNonMovingNoteOther 
	,LatestNonMovingNoteOtherUpdatedDate
	,LatestNonMovingNoteXCS 
	,LatestNonMovingNoteXCSUpdatedDate
	,LatestPeerReviewNote 
	,LatestPeerReviewNoteUpdatedDate
	,LatestRecoverySubrogationNote
	,LatestRecoverySubrogationNoteUpdatedDate
	,LatestRoundtabledNote
	,LatestRoundtabledNoteUpdatedDate
	,LatestTriageNote 
	,LatestTriageNoteUpdatedDate
	,LatestUnderwritingCommitteeNote
	,LatestUnderwritingCommitteeNoteUpdatedDate
	,LawAndJurisdiction 
	,LevelOfDelegatedAuthority
	,LevelOfDelegatedAuthorityCurrency
	,LineOfBusiness
	,LinkedSCMReference 
	,LinkedSynergySection
	,LitigationCounsel
	,LitigationNoteIndicator
	,LitigationStateCode
	,LitigationStatus 
	,LossDetails
	,LossFundCurrency
	,LossFundFileNoteIndicator
	,LossFundHolderReceivedFund
	,LossLocationAddressLine1 
	,LossLocationAddressLine2 
	,LossLocationCity 
	,LossLocationCountry
	,LossLocationCounty 
	,LossLocationDescription
	,LossLocationPostalCode
	,LossLocationState
	,LossLocationStateCode
	,LossType
	,MainGroupsOfClaimants
	,MarketCat 
	,MarketCatCode 
	,MarketCatDateOfLoss
	,MarketCatLongDescription 
	,MarketCatQualifier 
	,MatterName
	,Media
	,MedicareIndicator
	,MedipayIndicator 
	,MergedClaimNoteIndicator
	,NAIC
	,NAICCode
	,NetLoss
	,NetLossAsAtDate
	,NetLossCurrency
	,NIARecordTypeCode
	,NonMovingNoteBrokerIndicator 
	,NonMovingNoteInsuredIndicator
	,NonMovingNoteOtherIndicator
	,NonMovingNoteXCSIndicator
	,NumberOfCallCentreCalls
	,NumberOfClaimants
	,NumberOfCodesActivated 
	,NumberOfPeopleNotified 
	,NumberOfPeopleOfferedCreditMonitoring
	,OpenClaimsInBlock
	,OrderNumber
	,OrigExGratiaRequest
	,OriginalInsured
	,OriginalPolicyLimit
	,OriginalPolicyLimitCurrency
	,OriginalSigningDate
	,OriginalSigningNumber
	,OriginatingBureau
	,OtherReasonToFlag
	,OwnershipIssues
	,OwnershipStatus
	,PatientCompensationFund
	,PeerReviewNoteIndicator
	,PointOfLoss
	,Pollutant
	,PossibleInjuredPerson
	,PossibleInjuredPersonDateOfBirth 
	,PossibleInjuredPersonGender
	,PossibleInjuredPersonHasSSN
	,PotentialLargeClaim
	,PractitionerFacilityReportingRequired
	,PrimaryContributaryCause 
	,PrimaryDefenceAttorney 
	,PrimaryDefenceLawFirm  
	,PrimaryDPRReviewer
	,PrimaryExaminer
	,PrimaryExaminerClaimCenterId 
	,PrimaryExaminerGroup
	,PrimaryInsuredState
	,PrimaryLegacyReference
	,OriginatingSourceSystem
	,PrimarySectionAgressoReference 
	,PrimarySectionReference  
	,ProceedingsType
	,Product	
	,ProjectDeliveryMethod
	,ProjectSubType
	,ProjectType 
	,PropertyClaimsServicesCode 
	,ProsecutionMethod
	,RIShareMultiplier 
	,ReasonOfEscalation
	,ReconciliationComments
	,ReconciliationStatus
	,RecoverySubrogationNoteIndicator
	,RegulatoryInvestigationOrAction
	,TypeOfBuyer
	,PartyOfTheClaim
	,MultipliedDamagesClaimed
	,SellerFraudClaimed
	,FounderLedTarget
	,ReleaseType
	,ReportingTags
	,RequestingBrokerage
	,RestructuredDebt
	,Reviewed
	,RiskClass 
	,RiskClassCode 
	,RiskDetails
	,Role
	,Roundtabled
	,RoundtabledDate 
	,RoundtabledNoteIndicator
	,SCMReference
	,SecondaryContributaryCause 
	,SecondaryDPRReviewer
	,SecondaryExaminer
	,SecondaryInsuringClause
	,ReKeyReference
	,ReKeySource
	,SecondarySectionReference
	,SendBBRQuestionnaire 
	,Severity
	,Signed
	,SIUIndicator
	,Source
	,StackingAggregateReference 
	,StackingAggregateType
	,Strategy
	,SuretyDetails
	,ThirdPartyClaimReference 
	,ThreatVector
	,TimeBar
	,TotalWorkloadWeightingIndicator
	,TradingContractConditions
	,TransportationLiability
	,TreatyContract
	,TreatyInsuredEffectiveDate 
	,TreatyInsuredExpiryDate
	,TreatyInsuredName
	,TreatyInsuredPolicyNumber
	,TriagedMidClaim 
	,TriagedMidClaimType 
	,TriageNoteIndicator
	,TrustFundCode 
	,TrustFundCountryCode 
	,TrustFundStateCode 
	,TypeOfLoss
	,USUnderwritingCoverageCode 
	,UnderwritingCommitteeNoteIndicator 
	,UniqueClaimReference 
	,VendorCausedIncident 
	,VesselManufacturer
	,VesselModel
	,VesselName
	,VesselType
	,Voyage
	,WageAndHourAllegation
	,WaitingPeriod
	,WarIndicator
	,WorkOrigin
	,WrittenIfNotSignedOrderMultiplier
	,FK_ClaimEstimateAsAtCloseDate
	,FK_ClaimMovementAsAtCloseDate 
	,FK_ClaimTeamExaminer 
	,FK_GQDTransactionType 
	,FK_LastMovement 
	,FK_LastMovementLocalCurrency
	,FK_LastMovementOriginalCurrency 
	,FK_LastMovementSettlementCurrency 
	,FK_PartyBroker
	,FK_PrimaryClassOfBusiness 
	,FK_PrimaryTriFocus
	,FK_PrimaryUnderwriter 
	,FK_QuantifiedStatus 
	,FK_SpecialCategoryCatastrophe 
	,FK_YOA 
	,HashbytesId  
	,AuditCreateDateTime
	,AuditModifyDetails
)
VALUES
(
 source.FK_Claim       	
,source.AllegationOfDiscrimination
,source.AnyNonMovingNoteIndicator
,source.AreaOfPractice
,source.AreaOfPracticeCode 
,source.AmountOfOriginalLossFund
,source.BatteryBrand
,source.BBRServicesManager 
,source.BBRServicesNoteIndicator 
,source.BadFaithIndicator
,source.BadFaithNoteIndicator
,source.BeazleyCat
,source.BeazleyCatCode
,source.BeazleyCatDateOfLoss 
,source.BeazleyCatDateOfLossTo 
,source.BeazleyCatLongDescription
,source.BinderReference
,source.BinderYOA
,source.BlendWeightingMultiplier 
,source.BlockIndicator
,source.BodilyDeathEmotionalIndicator
,source.BondLimit
,source.BondLimitCurrency
,source.BooksAndRecordDemand
,source.BreachStatus
,source.BreachedInformationType
,source.BrokerContactName
,source.BrokerReference1 
,source.BrokerReference2 
,source.CallCentreAndCreditMonitoringExpiryDate 
,source.CargoCommodity
,source.CargoConveyance
,source.CatCodeEndsInLF
,source.Category
,source.CauseOfAction
,source.CauseOfLoss 
,source.CauseOfLossCode
,source.CauseOfLossSecondary
,source.CauseOfLossSecondaryCode
,source.CashAdvanceMade
,source.ClaimOrCircumstance
,source.ClaimsDepartment
,source.ClaimsTeam
,source.ClaimsSubTeam
,source.ClaimTeamExaminer
,source.ClaimantClientStatus
,source.ClaimantGender
,source.ClaimantJobCategory
,source.ClaimantJobStatus
,source.ClaimantName
,source.ClaimantSalary
,source.ClaimantSalaryName
,source.ClaimantType
,source.ClashCatCode
,source.ClashCatDateOfLoss 
,source.ClashCatDescription
,source.ClashCatName
,source.ClientBreakdown
,source.ClosedClaimsInBlock
,source.ComplexFlag 
,source.Consultation
,source.ConsultationNoteIndicator
,source.ConsultationUser
,source.CoverageAgreedDate 
,source.CoverageDenialIndicator
,source.CoverageIssues
,source.CoverageTrigger
,source.DateCoverageLetterIssued
,source.DateOfDenial
,source.DenialReason
,source.DamageTheory
,source.DateClaimPaid
,source.DateOfAct
,source.DateSinceInitialEstimate
,source.DateSinceNotReviewed
,source.DateSinceQuantified 
,source.DefendantOrPlaintiff
,source.DelegatedPartner
,source.DerivativeDemand
,source.DerivativeSuit
,source.DeviceEncrypted
,source.DiscoveryDate
,source.DiscoveryDetails
,source.DispositionOfMatter
,source.DutyToDefend
,source.ECFIndicator
,source.ECFEntryWithoutSCM
,source.EndOfWaitingPeriod
,source.EscalatedClaim
,source.EvaluationNoteIndicator
,source.EventSetting
,source.ExGratiaRequested
,source.ExposureClosedDate 
,source.ExposureDescription
,source.ExposureHasMovements
,source.ExposureOpenedDate 
,source.ExposureReference
,source.ExposureReopenedDate 
,source.ExposureReopenedReason 
,source.ExposureSequenceId 
,source.ExposureStatus
,source.ExposureStatusCode
,source.ExposureUpdatedDate
,source.ExternalAdjuster 
,source.Fil1Code
,source.FileNoteIndicator
,source.FinalExGratiaDecision
,source.FirstPartyCyberLossTypes
,source.ThirdPartyCyberLossTypes
,source.CyberGroupingExtortion	
,source.RansomwarePayment
,source.TotalAmountOfRansomwarePayment
,source.RansomwarePaymentCurrency
,source.ReportedToCompliance
,source.ClassActionCountry
,source.State
,source.RegulatoryInquiry
,source.TotalAmountOfFine
,source.FineCurrency
,source.AmountOfBusinessInterruptionSubmission
,source.BusinessInterruptionSubmissionCurrency
,source.AmountOfBusinessInterruptionLossRecognized
,source.BusinessInterruptionLossRecognizedCurrency
,source.AmountOfDataRecoverySubmission
,source.DataRecoverySubmissionCurrency
,source.AmountOfDataRecoveryLossRecognized
,source.DataRecoveryLossRecognizedCurrency
,source.FlaggedNoteIndicator 
,source.FlaggedNoteOrReasonIndicator 
,source.FlaggedReason 
,source.FlaggedReasonIndicator
,source.GrossLoss
,source.GrossLossAsAtDate
,source.GrossLossCurrency
,source.ISOLossType 
,source.ISOLossTypeCode
,source.IMO
,source.IncidentAction
,source.IndustryAreaOfPracticeSecondaryCode
,source.IndustryAreaOfPracticeSecondaryName
,source.InjuryType
,source.InsuredName 
,source.InsuredSCMName
,source.InsurersRepresentative 
,source.InsuringClause
,source.IsMultiSection
,source.IsNewYorkFreeTradeZone 
,source.IsRealExposure
,source.LastBureauShare
,source.LastMovementNarrative
,source.LastMovementTBAFlag
,source.LastMovementTBAIndicator 
,source.LatestBadFaithNote
,source.LatestBadFaithNoteUpdatedDate
,source.LatestBBRServicesNote
,source.LatestBBRServicesNoteUpdatedDate 
,source.LatestCMSNote 
,source.LatestCMSNoteUpdatedDate 
,source.LatestConsultationNote 
,source.LatestConsultationNoteUpdatedDate
,source.LatestEvaluationNote 
,source.LatestEvaluationNoteUpdatedDate
,source.LatestFileNote
,source.LatestFileNoteUpdatedDate
,source.LatestFlaggedNote
,source.LatestFlaggedNoteUpdatedDate 
,source.LatestLitigationNote	
,source.LatestLitigationNoteUpdatedDate
,source.LatestLossFundFileNote
,source.LatestLossFundFileNoteUpdatedDate
,source.LatestMergedClaimNote
,source.LatestMergedClaimNoteUpdatedDate
,source.LatestNonMovingNoteBroker
,source.LatestNonMovingNoteBrokerUpdatedDate 
,source.LatestNonMovingNoteInsured 
,source.LatestNonMovingNoteInsuredUpdatedDate
,source.LatestNonMovingNoteOther 
,source.LatestNonMovingNoteOtherUpdatedDate
,source.LatestNonMovingNoteXCS 
,source.LatestNonMovingNoteXCSUpdatedDate
,source.LatestPeerReviewNote 
,source.LatestPeerReviewNoteUpdatedDate
,source.LatestRecoverySubrogationNote
,source.LatestRecoverySubrogationNoteUpdatedDate
,source.LatestRoundtabledNote
,source.LatestRoundtabledNoteUpdatedDate
,source.LatestTriageNote 
,source.LatestTriageNoteUpdatedDate
,source.LatestUnderwritingCommitteeNote
,source.LatestUnderwritingCommitteeNoteUpdatedDate 
,source.LawAndJurisdiction 
,source.LevelOfDelegatedAuthority
,source.LevelOfDelegatedAuthorityCurrency
,source.LineOfBusiness
,source.LinkedSCMReference 
,source.LinkedSynergySection
,source.LitigationCounsel 
,source.LitigationNoteIndicator
,source.LitigationStateCode
,source.LitigationStatus 
,source.LossDetails
,source.LossFundCurrency
,source.LossFundFileNoteIndicator
,source.LossFundHolderReceivedFund
,source.LossLocationAddressLine1 
,source.LossLocationAddressLine2 
,source.LossLocationCity 
,source.LossLocationCountry
,source.LossLocationCounty 
,source.LossLocationDescription
,source.LossLocationPostalCode
,source.LossLocationState
,source.LossLocationStateCode
,source.LossType
,source.MainGroupsOfClaimants
,source.MarketCat 
,source.MarketCatCode 
,source.MarketCatDateOfLoss
,source.MarketCatLongDescription 
,source.MarketCatQualifier 
,source.MatterName
,source.Media
,source.MedicareIndicator
,source.MedipayIndicator 
,source.MergedClaimNoteIndicator
,source.NAIC
,source.NAICCode
,source.NetLoss
,source.NetLossAsAtDate
,source.NetLossCurrency
,source.NIARecordTypeCode
,source.NonMovingNoteBrokerIndicator 
,source.NonMovingNoteInsuredIndicator
,source.NonMovingNoteOtherIndicator
,source.NonMovingNoteXCSIndicator
,source.NumberOfCallCentreCalls
,source.NumberOfClaimants
,source.NumberOfCodesActivated 
,source.NumberOfPeopleNotified 
,source.NumberOfPeopleOfferedCreditMonitoring
,source.OpenClaimsInBlock
,source.OrderNumber
,source.OrigExGratiaRequest
,source.OriginalInsured
,source.OriginalPolicyLimit
,source.OriginalPolicyLimitCurrency
,source.OriginalSigningDate
,source.OriginalSigningNumber
,source.OriginatingBureau
,source.OtherReasonToFlag
,source.OwnershipIssues
,source.OwnershipStatus
,source.PatientCompensationFund
,source.PeerReviewNoteIndicator
,source.PointOfLoss
,source.Pollutant
,source.PossibleInjuredPerson
,source.PossibleInjuredPersonDateOfBirth 
,source.PossibleInjuredPersonGender
,source.PossibleInjuredPersonHasSSN
,source.PotentialLargeClaim
,source.PractitionerFacilityReportingRequired
,source.PrimaryContributaryCause 
,source.PrimaryDefenceAttorney 
,source.PrimaryDefenceLawFirm
,source.PrimaryDPRReviewer
,source.PrimaryExaminer
,source.PrimaryExaminerClaimCenterId 
,source.PrimaryExaminerGroup
,source.PrimaryInsuredState
,source.PrimaryLegacyReference
,source.OriginatingSourceSystem
,source.PrimarySectionAgressoReference 
,source.PrimarySectionReference  
,source.ProceedingsType
,source.Product        
,source.ProjectDeliveryMethod
,source.ProjectSubType
,source.ProjectType 
,source.PropertyClaimsServicesCode 
,source.ProsecutionMethod
,source.RIShareMultiplier 
,source.ReasonOfEscalation
,source.ReconciliationComments
,source.ReconciliationStatus
,source.RecoverySubrogationNoteIndicator
,source.RegulatoryInvestigationOrAction
,source.TypeOfBuyer
,source.PartyOfTheClaim
,source.MultipliedDamagesClaimed
,source.SellerFraudClaimed
,source.FounderLedTarget
,source.ReleaseType
,source.ReportingTags
,source.RequestingBrokerage
,source.RestructuredDebt
,source.Reviewed
,source.RiskClass 
,source.RiskClassCode 
,source.RiskDetails
,source.Role
,source.Roundtabled
,source.RoundtabledDate 
,source.RoundtabledNoteIndicator
,source.SCMReference
,source.SecondaryContributaryCause 
,source.SecondaryDPRReviewer
,source.SecondaryExaminer
,source.SecondaryInsuringClause
,source.ReKeyReference 
,source.ReKeySource
,source.SecondarySectionReference
,source.SendBBRQuestionnaire 
,source.Severity
,source.Signed
,source.SIUIndicator
,source.Source
,source.StackingAggregateReference 
,source.StackingAggregateType
,source.Strategy
,source.SuretyDetails
,source.ThirdPartyClaimReference 
,source.ThreatVector
,source.TimeBar
,source.TotalWorkloadWeightingIndicator
,source.TradingContractConditions
,source.TransportationLiability
,source.TreatyContract
,source.TreatyInsuredEffectiveDate 
,source.TreatyInsuredExpiryDate
,source.TreatyInsuredName
,source.TreatyInsuredPolicyNumber
,source.TriagedMidClaim 
,source.TriagedMidClaimType 
,source.TriageNoteIndicator
,source.TrustFundCode 
,source.TrustFundCountryCode 
,source.TrustFundStateCode 
,source.TypeOfLoss
,source.USUnderwritingCoverageCode 
,source.UnderwritingCommitteeNoteIndicator 
,source.UniqueClaimReference 
,source.VendorCausedIncident 
,source.VesselManufacturer
,source.VesselModel
,source.VesselName
,source.VesselType
,source.Voyage
,source.WageAndHourAllegation
,source.WaitingPeriod
,source.WarIndicator
,source.WorkOrigin
,source.WrittenIfNotSignedOrderMultiplier
,source.FK_ClaimEstimateAsAtCloseDate
,source.FK_ClaimMovementAsAtCloseDate 
,source.FK_ClaimTeamExaminer 
,source.FK_GQDTransactionType 
,source.FK_LastMovement 
,source.FK_LastMovementLocalCurrency
,source.FK_LastMovementOriginalCurrency 
,source.FK_LastMovementSettlementCurrency 
,source.FK_PartyBroker
,source.FK_PrimaryClassOfBusiness 
,source.FK_PrimaryTriFocus
,source.FK_PrimaryUnderwriter 
,source.FK_QuantifiedStatus 
,source.FK_SpecialCategoryCatastrophe 
,source.FK_YOA 
,source.HashbytesId         
,GETDATE()						
,'Merge in ODS.usp_LoadClaimExposure proc' 
)
;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ClaimExposure';

END
GO