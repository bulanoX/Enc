﻿CREATE PROCEDURE  [ODS].[usp_LoadTaxes]
AS


SET NOCOUNT ON

DECLARE @LastAuditDate DATETIME2(7)

SELECT 
	@LastAuditDate = MAX(ISNULL(AuditModifyDateTime,AuditCreateDateTime) )
FROM ODS.Taxes
SET @LastAuditDate = ISNULL(@LastAuditDate, '1900-01-01')

DELETE t 
FROM [ODS].[Taxes] t
WHERE t.FK_Section NOT IN (SELECT PK_Section FROM ODS.Section )

DELETE t
from ods.taxes t
inner join ods.section sec on t.FK_Section = sec.PK_Section
left join BeazleyIntelligenceDataContract.Outbound.vw_Taxes s on s.SectionSourceId = sec.SectionReference and t.TaxesId = s.TaxesID
where  s.SectionSourceId is null

MERGE [ODS].[Taxes] target
USING

(
SELECT 	DISTINCT	
		 FK_Section         = s.PK_Section 
		 ,FK_Policy			= s.FK_Policy
		 ,t.TaxesId
		 ,t.TaxableAmount    
		 ,t.TaxLocationOfRisk
		 ,t.Tax
		 ,t.TaxRate
		 ,t.VATNumber    
		 ,t.OriginalCCYToSettlementCCYRate
		 ,t.OriginalCurrency
		 ,t.SettlementCurrency

	FROM 
	BeazleyIntelligenceDataContract.Outbound.vw_Taxes t		
	INNER JOIN ODS.Section s 
	ON t.SectionSourceId = s.SectionReference	
	INNER JOIN BeazleyIntelligenceDataContract.Outbound.vw_Section vws
	ON vws.SectionReference = t.SectionSourceId
	AND vws.SourceSystem = t.SourceSystem
	WHERE ISNULL(t.AuditModifyDatetime, t.AuditCreateDateTime) >= @LastAuditDate
	) source
	ON target.FK_Section = source.FK_Section
	AND target.TaxesId = source.TaxesId
WHEN MATCHED THEN 
UPDATE 
SET 
target.FK_Policy						= source.FK_Policy
,target.TaxableAmount					= source.TaxableAmount
,target.TaxLocationOfRisk				= source.TaxLocationOfRisk
,target.Tax								= source.Tax
,target.TaxRate							= source.TaxRate
,target.VATNumber						= source.VATNumber
,target.OriginalCCYToSettlementCCYRate	= source.OriginalCCYToSettlementCCYRate
,target.OriginalCurrency				= source.OriginalCurrency
,target.SettlementCurrency				= source.SettlementCurrency
,target.AuditModifyDateTime				= GETDATE()						
,target.AuditModifyDetails				= 'Merge in [ODS].[usp_LoadTaxes] proc' 


WHEN NOT MATCHED BY TARGET THEN
INSERT
( 
FK_Section
,FK_Policy
,TaxesId
,TaxableAmount        
,TaxLocationOfRisk    
,Tax		
,TaxRate	
,VATNumber 
,OriginalCCYToSettlementCCYRate
,OriginalCurrency
,SettlementCurrency
,AuditCreateDateTime
,AuditModifyDetails)
VALUES
(
source.FK_Section
,source.FK_Policy
,source.TaxesId
,source.TaxableAmount
,source.TaxLocationOfRisk
,source.Tax
,source.TaxRate
,source.VATNumber
,source.OriginalCCYToSettlementCCYRate
,source.OriginalCurrency
,source.SettlementCurrency
,GETDATE()	
,'New add in [ODS].[usp_LoadTaxes] proc'
);


EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'Taxes';
