﻿
CREATE PROCEDURE [ODS].[usp_LoadReinsuranceSectionContractFac]
AS
--Declarations
SET NOCOUNT ON

--Clear existing data
TRUNCATE TABLE ODS.ReinsuranceSectionContractFac;

--Facultative Links  ******************************************************************** 
INSERT INTO ODS.ReinsuranceSectionContractFac
    ( 
     FK_Section
    ,FK_Syndicate
    ,FK_ReinsuranceContract
    ,SequenceNumber
    ,CededPercentage
    ,Proportion
    )
SELECT DISTINCT
--Keys
 FK_Section				= sec.PK_Section
,FK_Syndicate			= syn.PK_Syndicate
,FK_ReinsuranceContract	= ric.PK_ReinsuranceContract
--Data
,SequenceNumber			= pfl.FacPageNumber
,CededPercentage		= Utility.udf_ProcessPercentage(ISNULL(pfl.LineAmount,0), 1,0,0)
,Proportion				= Utility.udf_ProcessPercentage(ISNULL(pfl.Proportion,0) ,1,0,1)
FROM 
Staging_MDS.dbo.vw_policy_fac_link pfl
INNER JOIN
ODS.Section sec ON
pfl.PolicyReference = SEC.SectionReference
INNER JOIN
ODS.ReinsuranceContractFac ric ON
CAST(pfl.FacNumber AS VARCHAR(250)) = RIC.ContractReference
INNER JOIN
ODS.Syndicate syn ON
pfl.SynUserNumber = SYN.SyndicateNumber
ORDER BY
FK_Section,
FK_Syndicate,
FK_ReinsuranceContract;

EXEC Utility.usp_CheckForEmptyTables @SchemaName = 'ODS', @TableName = 'ReinsuranceSectionContractFac';